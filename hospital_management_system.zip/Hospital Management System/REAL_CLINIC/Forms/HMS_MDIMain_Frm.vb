﻿

Imports System.Windows.Forms
Imports HMS_Common.Common_Cls
Imports HMS_BL
Imports System.Data.SqlClient
Public Class HMS_MDIMain_Frm
    Dim Filename As String
    Dim con As SqlConnection
    Dim cmd As SqlCommand
    Private Com_BL As HMS_Common_BL_Cls
    Public WithEvents MDIChildfrm As Form


    Private Sub mnu_Lock_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnu_Lock.Click, TBtn_Lock.Click

        With Lock_Frm
            .ShowDialog(Me)
        End With

    End Sub


    Private Sub mnu_Pwdmanagement_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnu_Pwdmanagement.Click
        With Usermanagement_Frm
            .MdiParent = Me
            .Show()
            'Call Set_Parentform(Me, Usermanagement_Frm)
        End With
    End Sub
    Private Function HandleRegistry() As Boolean
        Dim firstRunDate As Date
        Dim st As Date = My.Computer.Registry.GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\HMSSoft", "Set", Nothing)
        firstRunDate = st
        If firstRunDate = Nothing Then
            firstRunDate = System.DateTime.Today.Date
            My.Computer.Registry.SetValue("HKEY_LOCAL_MACHINE\SOFTWARE\HMSSoft", "Set", firstRunDate)
        ElseIf (Now - firstRunDate).Days > 7 Then
            Return False
        End If
        Return True
    End Function
    Private Sub HMS_MDIMain_Frm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
           
            Dim menu_Bl As New Menumaster_BL_Cls
            Call menu_Bl.Fill_Menugroup(Tvw_Mainmenu, mnu_HMSoptions)
            Call Fill_Menuoptions(Tvw_Mainmenu, mnu_HMSoptions)

            If Me.Tvw_Mainmenu.Nodes.Count > 0 Then
                Me.Tvw_Mainmenu.ExpandAll()
                Me.Tvw_Mainmenu.TopNode = Tvw_Mainmenu.Nodes(0)
            End If
            Timer1.Enabled = True
            Txt_Menucommand.Focus()
        
        Catch ex As Exception

        End Try

    End Sub

    Private Sub HMS_MDIMain_Frm_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        e.Cancel = True
    End Sub

    Private Sub Tvw_Mainmenu_AfterSelect(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles Tvw_Mainmenu.AfterSelect
        Try
            Call Select_TreeviewMenuoption(Tvw_Mainmenu, Me)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Menucommand_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Menucommand.KeyDown


        Try

            If e.Shift = Keys.Alt Or e.KeyCode = Keys.ShiftKey Or e.KeyCode = Keys.Tab Or e.KeyCode = Keys.Capital Then
                Exit Sub
            End If

            If Navigator_Frm.Visible = False Then
                Exit Sub
            End If

            With Navigator_Frm.DGvw_Menulist

                If e.KeyCode = Keys.Escape Then
                    Txt_Menucommand.Text = ""
                    .DataSource = Nothing
                    Navigator_Frm.Hide()
                    Exit Sub
                End If

                If .Rows.Count = 0 Then Exit Sub

                If e.KeyCode = Keys.Up Then
                    If .CurrentRow.Index > 0 Then
                        .CurrentCell = .Item(0, .CurrentRow.Index - 1)
                    End If
                    If .CurrentRow.Displayed = False Then .FirstDisplayedScrollingRowIndex = .CurrentRow.Index
                    Exit Sub
                ElseIf e.KeyCode = Keys.Down Then
                    If .CurrentRow.Index < .Rows.Count Then
                        .CurrentCell = .Item(0, .CurrentRow.Index + 1)
                    End If
                    If .CurrentRow.Displayed = False Then .FirstDisplayedScrollingRowIndex = .CurrentRow.Index
                    Exit Sub
                ElseIf e.KeyCode = Keys.Return Then
                    Navigator_Frm.MDI_Form = Me
                    Navigator_Frm.Select()
                    Call Select_Navigatormenuoption(Navigator_Frm.DGvw_Menulist, Me)
                    Txt_Menucommand.Text = ""
                    .DataSource = Nothing
                    Navigator_Frm.Hide()
                    Exit Sub
                End If

            End With

        Catch ex As Exception

        End Try


    End Sub

    Private Sub Txt_Menucommand_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Menucommand.KeyPress
        Try

            If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(Asc("`"))

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Menucommand_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Menucommand.KeyUp
        Try

            With Navigator_Frm.DGvw_Menulist

                If Txt_Menucommand.Text.Trim = "" Then
                    .DataSource = Nothing
                    Navigator_Frm.Hide()
                    Exit Sub
                End If

                If e.KeyCode = Keys.Up Or e.KeyCode = Keys.Down Or e.KeyCode = Keys.Return Then
                    Exit Sub
                End If

                Dim Qry As String = ""

                Qry = " SELECT     Menu_Name, Menu_ID, Menu_Formname "
                Qry = Qry + " FROM  Menumaster_Vw "
                Qry = Qry + " WHERE (Menu_Name LIKE '" & Txt_Menucommand.Text.Trim & "%')"
                Qry = Qry + " ORDER BY Menu_Order"

                'Executing and Get data
                Com_BL = New HMS_Common_BL_Cls
                Dim Menu_Dtbl As DataTable = Nothing
                If Com_BL.Get_Data(Qry, Menu_Dtbl) Then

                    .DataSource = Nothing
                    .DataSource = Menu_Dtbl
                    .Refresh()
                    If .Rows.Count > 0 Then
                        If Not Navigator_Frm.Visible Then
                            Txt_Menucommand.Tag = Txt_Menucommand.SelectionStart
                            Navigator_Frm.Point_Frm = Get_Navigatorformlocation(Txt_Menucommand)
                            Navigator_Frm.MDI_Form = Me
                            Navigator_Frm.Show(Me)
                            Txt_Menucommand.Focus()
                            Txt_Menucommand.SelectionStart = Txt_Menucommand.Tag
                        End If
                        If .Columns.Count > 0 Then
                            .Columns(0).MinimumWidth = 500
                            For i_Ctr = 1 To .Columns.Count - 1
                                .Columns(i_Ctr).Width = 0
                            Next
                        End If
                    Else
                        .DataSource = Nothing
                        Navigator_Frm.Hide()
                        Exit Sub
                    End If
                Else
                    .DataSource = Nothing
                    Navigator_Frm.Hide()
                    Exit Sub
                End If
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub HMS_MDIMain_Frm_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        Try

            If Not Navigator_Frm.Visible Then Exit Sub
            Call Setnavigatorlocation(Navigator_Frm)

        Catch ex As Exception

        End Try

    End Sub

    Public Sub Setnavigatorlocation(ByRef Childform As Form)
        Dim Point_Frm As Point = New Point

        Try
            If Not Me.Visible Then
                Childform.Visible = False
            End If
            If Childform.Visible Then
                'Childform.Location = Getnavigatorlocation(Me, Navigator_Frm)
                Childform.DesktopLocation = Get_Navigatorformlocation(Txt_Menucommand)
            End If
        Catch ex As Exception
        Finally
            Point_Frm = Nothing
        End Try
    End Sub

    Private Sub HMS_MDIMain_Frm_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        Try

            If Not Navigator_Frm.Visible Then Exit Sub
            Call Setnavigatorlocation(Navigator_Frm)

        Catch ex As Exception

        End Try

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Try
            HMS_Timebar.Text = "System Time : " & Format(Now, "hh:mm:ss tt")

            If (Me.ActiveMdiChild Is Nothing) Then
                If (Me.ActiveControl Is Nothing) Then
                    Txt_Menucommand.Focus()
                End If
            End If
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Tvw_Mainmenu_NodeMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeNodeMouseClickEventArgs) Handles Tvw_Mainmenu.NodeMouseClick
        Try
            Dim Original As TreeNode = e.Node
            Tvw_Mainmenu.SelectedNode = Nothing
            Tvw_Mainmenu.SelectedNode = Original

        Catch ex As Exception

        End Try
    End Sub

    Private Sub HMS_MDIMain_Frm_MdiChildActivate(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.MdiChildActivate
        Try
            For Each ChildForm As Form In Me.MdiChildren
                AddHandler ChildForm.FormClosed, AddressOf Me.Childfrm_Closed
                AddHandler ChildForm.Load, AddressOf Me.Childfrm_Load
            Next
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Childfrm_Closed(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            Try
                If Me.TlStrp_menuHistoryutility.Items.Count <= 5 Then Exit Sub

                Dim Cl_Frm As Form = DirectCast(sender, Form)
                For Each TlStrpBtn As ToolStripButton In Me.TlStrp_menuHistoryutility.Items
                    If Cl_Frm.Name = TlStrpBtn.Tag Then
                        Me.TlStrp_menuHistoryutility.Items.Remove(TlStrpBtn)
                        Exit Sub
                    End If
                Next
            Catch ex As Exception

            End Try
        Catch ex As Exception

        End Try

    End Sub

    Public Sub Childfrm_Load(ByVal sender As Object, ByVal e As System.EventArgs)

        Try
            Dim Cl_Frm As Form = DirectCast(sender, Form)
            Dim Frmname As String = ""
            '--------------------------------------------------------------------------
            Frmname = Replace(Cl_Frm.Name, "_Frm", "")
            Frmname = Replace(Frmname, "_", " ")

            For Each TlStrpBtn As ToolStripButton In Me.TlStrp_Openedforms.Items
                TlStrpBtn.ForeColor = Color.White
            Next
            For Each TlStrpBtn As ToolStripButton In Me.TlStrp_Openedforms.Items
                If Cl_Frm.Name = TlStrpBtn.Tag Then
                    TlStrpBtn.ForeColor = Color.Cyan
                    Return
                End If
            Next
            '--------------------------------------------------------------------------
            Dim Childformexists As Boolean = False
            Dim btnSomething As New ToolStripButton
            Dim m As New Windows.Forms.Padding
            '--------------------------------------------------------------------------
            m.All = 1
            With btnSomething
                .Text = Frmname
                .Tag = Cl_Frm.Name
                .Name = Val(Cl_Frm.Tag)
                .ForeColor = Color.Cyan
                .DisplayStyle = ToolStripItemDisplayStyle.Text
                .Margin = m
            End With
            If Me.TlStrp_Openedforms.Items.Count >= 5 Then
                For Each TlStrpBtn As ToolStripButton In Me.TlStrp_Openedforms.Items
                    For Each ChildFrm As Form In Me.MdiChildren
                        If ChildFrm.Name = TlStrpBtn.Tag Then
                            Childformexists = True
                        End If
                    Next
                    If Not Childformexists Then
                        Me.TlStrp_Openedforms.Items.Remove(TlStrpBtn)
                        Exit For
                    End If
                Next
            End If
            TlStrp_Openedforms.Items.Add(btnSomething)
            '--------------------------------------------------------------------------

        Catch ex As Exception

        End Try

    End Sub

    Private Sub Tlbtn_Cascade_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tlbtn_Cascade.Click
        Me.LayoutMdi(MdiLayout.Cascade)
    End Sub

    Private Sub Tlbtn_Tilevertical_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tlbtn_Tilevertical.Click
        Me.LayoutMdi(MdiLayout.TileVertical)
    End Sub

    Private Sub Tlbtn_Tilehorizontal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tlbtn_Tilehorizontal.Click
        Me.LayoutMdi(MdiLayout.TileHorizontal)
    End Sub

    Private Sub Tlbtn_CloseAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tlbtn_CloseAll.Click
        For Each ChildForm As Form In Me.MdiChildren
            ChildForm.Close()
        Next
    End Sub

    Private Sub TlStrp_Openedforms_ItemClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles TlStrp_Openedforms.ItemClicked
        Try
            Dim btnSomething As ToolStripButton


            btnSomething = New ToolStripButton
            btnSomething = e.ClickedItem

            If Not Check_Userright(CInt(btnSomething.Name), Access_Type.View) Then
                Return
            End If

            Show_ChildForm(btnSomething.Tag, Me, btnSomething.Name)
            For Each TlStrpBtn As ToolStripButton In Me.TlStrp_Openedforms.Items
                TlStrpBtn.ForeColor = Color.White
            Next
            e.ClickedItem.ForeColor = Color.Cyan

        Catch ex As Exception

        End Try
    End Sub

    Private Sub TlStrp_menuHistoryutility_ItemClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles TlStrp_menuHistoryutility.ItemClicked
        Try
            If e.ClickedItem.Name = "Clearhistory" Then
                TlStrp_Openedforms.Items.Clear()

            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Splitter1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Splitter1.Click
        Try
            SplitContainer2.Visible = Not SplitContainer2.Visible
            Me.Refresh()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub mnu_ShowHideShortcutMenuToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnu_ShowHideShortcutMenuToolStripMenuItem.Click
        Try
            SplitContainer2.Visible = Not SplitContainer2.Visible
            Me.Refresh()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub mnu_LogOff_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnu_LogOff.Click
        Try

            Me.Hide()
            Me.Dispose()
            LoginForm.Show()
        Catch ex As Exception

        End Try
    End Sub

    Public Sub HMS_Menuoptons_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try
            Dim Selmenu As ToolStripMenuItem
            Selmenu = sender

            If Selmenu.Tag = "" Then Exit Sub

            Call Show_menuoption(Selmenu.Name, Selmenu.Tag, Me)

        Catch ex As Exception

        End Try
    End Sub

    Private Sub TBtn_Reports_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles TBtn_Reports.Click
        Try
            Call SendKeys.Send("^{F6}")
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Tbtn_Billing_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tbtn_Billing.Click
        Try
            Call SendKeys.Send("^{F5}")
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Tbtn_OPReg_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tbtn_OPReg.Click
        Try
            Call SendKeys.Send("^{F4}")
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Tbtn_Apointment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tbtn_Apointment.Click
        Try
            Call SendKeys.Send("^{F3}")
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Lbl_Nwkstatus_VisibleChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Lbl_Nwkstatus.VisibleChanged
        Try
            Timer2.Enabled = Lbl_Nwkstatus.Visible

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Timer2_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        Try
            If Timer2.Tag = 1 Then
                Lbl_Nwkstatus.ForeColor = Color.Transparent
                Timer2.Tag = 0
            Else
                Lbl_Nwkstatus.ForeColor = Color.Cyan
                Timer2.Tag = 1
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles AboutToolStripMenuItem.Click
        frmAbout.ShowDialog()
    End Sub
    Sub Backup()
        Try

            Dim destdir As String = "HospitalDB " & DateTime.Now.ToString("dd-MM-yyyy_HH-mm-ss") & ".bak"
            Dim objdlg As New SaveFileDialog
            objdlg.FileName = destdir
            objdlg.ShowDialog()
            Filename = objdlg.FileName
            Cursor = Cursors.WaitCursor
            Timer3.Enabled = True
            con = New SqlConnection(cs)
            con.Open()
            Dim cb As String = "backup database HospitalDB to disk='" & Filename & "'with init,stats=10"
            cmd = New SqlCommand(cb)
            cmd.Connection = con
            cmd.ExecuteReader()
            con.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub BackupToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles BackupToolStripMenuItem.Click
        Backup()
    End Sub

    Private Sub RestoreToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles RestoreToolStripMenuItem.Click
        Try
            With OpenFileDialog1
                .Filter = ("DB Backup File|*.bak;")
                .FilterIndex = 4
            End With
            'Clear the file name
            OpenFileDialog1.FileName = ""

            If OpenFileDialog1.ShowDialog() = DialogResult.OK Then
                Cursor = Cursors.WaitCursor
                Timer3.Enabled = True
                SqlConnection.ClearAllPools()
                con = New SqlConnection(cs)
                con.Open()
                Dim cb As String = "USE Master ALTER DATABASE HospitalDB SET Single_User WITH Rollback Immediate Restore database HospitalDB FROM disk='" & OpenFileDialog1.FileName & "' WITH REPLACE ALTER DATABASE HospitalDB SET Multi_User "
                cmd = New SqlCommand(cb)
                cmd.Connection = con
                cmd.ExecuteReader()
                con.Close()
                MessageBox.Show("Successfully performed", "Database Restore", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub mnu_Exit_Click(sender As System.Object, e As System.EventArgs) Handles mnu_Exit.Click
        Try
            If MessageBox.Show("Do you really want to logout from application?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                If MessageBox.Show("Do you want backup database before logout?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                    Backup()
                    LogOut()
                Else
                    LogOut()
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Sub LogOut()
        Me.Hide()
        Dim frm As LoginForm = New LoginForm
        frm.Show()
        frm.UsernameTextBox.Text = ""
        frm.PasswordTextBox.Text = ""
        frm.UsernameTextBox.Focus()
    End Sub
    Private Sub Timer3_Tick(sender As System.Object, e As System.EventArgs) Handles Timer3.Tick
        Cursor = Cursors.Default
        Timer3.Enabled = False
    End Sub

    Private Sub NotepadToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles NotepadToolStripMenuItem.Click
        Try
            System.Diagnostics.Process.Start("Notepad.exe")
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub CalculatorToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles CalculatorToolStripMenuItem.Click
        Try
            System.Diagnostics.Process.Start("Calc.exe")
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub WordpadToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles WordpadToolStripMenuItem.Click
        Try
            System.Diagnostics.Process.Start("Wordpad.exe")
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub MSWordToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles MSWordToolStripMenuItem.Click
        Try
            System.Diagnostics.Process.Start("Winword.exe")
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub TaskManagerToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles TaskManagerToolStripMenuItem.Click
        Try
            System.Diagnostics.Process.Start("TaskMgr.exe")
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub SystemInfoToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles SystemInfoToolStripMenuItem.Click
        frmSystemInfo.ShowDialog()
    End Sub

    Private Sub SMSToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles SMSToolStripMenuItem.Click
        frmSMSSetting.Reset()
        frmSMSSetting.ShowDialog()
    End Sub
End Class
