﻿Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls

Public Class Insuarance_Claim_Frm

#Region "Declarations"
    'Object of Employee Details Bussiness Layer


    Private Patient_BL As PatientInformation_BL_Cls
    Private Insurance_Master_BL As Insurance_Master_BL_Cls
    Private hms_helper As HMS_Helper = Nothing

    Private mTr_Mode As Tran_Mode

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing
    Private Ctrl_Point As Point

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_InsClaim_ID.BackColor = Color.White
                    Me.Txt_InsClaim_ID.ReadOnly = False

                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_InsClaim_ID.BackColor = Color.Silver
                    Me.Txt_InsClaim_ID.ReadOnly = True

            End Select
        End Set
    End Property


#End Region

#Region "Methods"
    'Clear Controls
    Public Sub Clear_Form()
        Try

            Txt_InsClaim_ID.Text = ""

            Txt_Company_Address.Text = ""

            Cmb_Approved.SelectedIndex = 0


            Txt_ClaimAmount.Text = ""

            Txt_RefNO.Text = ""

            Txt_CoverageAmt.Text = ""


            Dtp_Company_RegDt.Value = Tran_Date

            Tr_Mode = Tran_Mode.New_Mode
            Btn_Save.Enabled = True
            Btn_Delete.Enabled = False

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    'assigning values to controls
    Private Sub AssignToControl(ByVal dtbl As DataTable)
        Try

            Dim dr As DataTableReader = Nothing
            dr = dtbl.CreateDataReader()
            dr.Read()

            With dr
                Txt_InsClaim_ID.Text = .Item("IComp_ID").ToString

                Txt_Company_Address.Text = .Item("Address").ToString

                Cmb_Approved.SelectedValue = .Item("Contry").ToString

                Txt_ClaimAmount.Text = .Item("Contact Person").ToString

                Txt_RefNO.Text = .Item("Contact Person Email").ToString

                Txt_CoverageAmt.Text = .Item("Contact Person Mobile").ToString


                Dtp_Company_RegDt.Value = .Item("Reg Date").ToString


                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Save.Enabled = True
                Btn_Delete.Enabled = True


            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    'validating fields 
    Private Function Validate_Fields() As Boolean
        Try

            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If

            If Tr_Mode <> Tran_Mode.New_Mode Then
                If Txt_InsClaim_ID.Text.Trim = "" Then MessageBox.Show("Invalid Inusarance Company ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_InsClaim_ID.Focus() : Return False
            End If
            'validating all mandatory fields

            If Txt_Company_Address.Text.Trim = "" Then MessageBox.Show("Invalid Insurance Company Address, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Company_Address.Focus() : Return False

            If Cmb_Approved.SelectedIndex = 0 Then MessageBox.Show("Invalid Country, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_Approved.Focus() : Return False

            If Txt_ClaimAmount.Text.Trim = "" Then MessageBox.Show("Invalid Contact Person Name, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_ClaimAmount.Focus() : Return False
            If Txt_CoverageAmt.Text.Trim = "" Then MessageBox.Show("Invalid Contact Person Mobile Number, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_CoverageAmt.Focus() : Return False
            If Txt_RefNO.Text.Trim = "" Then MessageBox.Show("Invalid Contact Person Emial ID, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_RefNO.Focus() : Return False

            REM Seting default values


            REM Validatimg formats




            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    'Locate values from BL
    Public Function Locate_Values(ByVal IComp_ID As Integer) As Boolean
        Insurance_Master_BL = New Insurance_Master_BL_Cls
        Dim dtbl As DataTable = Nothing
        Try
            If Insurance_Master_BL.Get_Insurance_Master_Details(dtbl, IComp_ID) Then
                Call AssignToControl(dtbl)
                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Delete.Enabled = True
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Function


#End Region

    Private Sub Insuarance_Claim_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        Try

            If e.KeyCode = Keys.Enter Then SendKeyTab()

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Insuarance_Claim_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles MyBase.KeyPress
        Try
            If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Insuarance_Claim_Frm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try


            hms_helper = New Hms_Helperimpliments
            Call hms_helper.Fill_Insurance_Companies(Cmb_Insur_Comp, "<Select>")
            Call hms_helper.Fill_Insurance_Shemes(Cmb_Insur_Schem, "<Select>")

            With Cmb_Approved
                .Items.Add("Yes")
                .Items.Add("No")
            End With

            Txt_InsClaim_ID.Focus()
            Cmb_Approved.SelectedIndex = 0
            Dtp_Company_RegDt.Value = Tran_Date


        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try

            If Not Validate_Fields() Then Exit Sub

            'Variable declaration of BL 
            Insurance_Master_BL = New Insurance_Master_BL_Cls

            If Insurance_Master_BL.Save_Insurance_Master(Dtbl, Tr_Mode, Val(Txt_InsClaim_ID.Text.Trim)) Then
                If Dtbl.Rows(0).Item(0).ToString = "0" Then
                    MessageBox.Show("Insurance Company Details Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Else
                    MessageBox.Show("Insurance Company Details Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Txt_InsClaim_ID.Text = Dtbl.Rows(0).Item(1).ToString
                    Btn_Clear.Focus()
                End If

            Else
                MessageBox.Show("Insurance Company Details Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try
            Call Clear_Form()
            Txt_InsClaim_ID.Focus()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Pat_ID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_InsClaim_ID.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then Btn_FindID_Click(sender, e)
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Txt_Pat_ID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_InsClaim_ID.Validating
        Try

            If Txt_InsClaim_ID.Text.Trim <> "" Then
                If Not Locate_Values(Txt_InsClaim_ID.Text.Trim) Then
                    MessageBox.Show("Invalid Patient ID, Please Check ", _
                                    Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Txt_InsClaim_ID.Focus()
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Public Sub Btn_FindID_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_FindID.Click
        Try
            If Txt_InsClaim_ID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "150|75|200|200|200"
                'Sql = "Select  Name,Patient_ID,[Family Name], Address, [SS_No],City,State,Country from Get_Patient_Info_Vw " '"SELECT *  FROM    Patient_Info_Short_Vw"
                Sql = "select * from Insurance_Master_Vw where Br_code='" & Branch_Code & "' "
                Call ShowSearchengine(Txt_InsClaim_ID, Sql, 0, "IComp_Name", Colwidth, , 0)
            End If

            If Txt_InsClaim_ID.Text.Trim = "" Then
                Txt_InsClaim_ID.Focus() : Exit Sub
            End If

            'Locate Employee details 
            If Not Locate_Values(Txt_InsClaim_ID.Text.Trim) Then
                MessageBox.Show("Invalid Insurance Company ID, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Txt_InsClaim_ID.Focus() : Exit Sub
            Else

            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Try
            Me.Close()
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click
        Try


            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If
            Insurance_Master_BL = New Insurance_Master_BL_Cls
            Dim dtbl As DataTable = Nothing
            If MessageBox.Show("Are you sure want to delete the  record ", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                If Insurance_Master_BL.Del_Insurance_Master(dtbl, Txt_InsClaim_ID.Text.Trim) Then
                    If dtbl.Rows(0).Item(0).ToString = True Then
                        MessageBox.Show("Insurance Company Details Deleted", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                        Call Clear_Form()
                        Txt_InsClaim_ID.Focus()
                    Else
                        MessageBox.Show("You cannot delete this Insurance Company Details" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                Else
                    MessageBox.Show("You cannot delete this Insurance Company Details" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

#Region "A D D  New GenData"
    Private Sub Btn_New_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try

            Dim AddBtnCtrl As Control = CType(sender, Control)
            Call AddNewGendata(AddBtnCtrl)
        Catch ex As Exception

        End Try

    End Sub





#End Region

    Private Sub Txt_Company_Address_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Company_Address.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then Txt_Company_Address.Select(Len(Txt_Company_Address.Text), 0)
            If Len(Txt_Company_Address.Text) > 150 Then Txt_Company_Address.ScrollBars = ScrollBars.Both Else Txt_Company_Address.ScrollBars = ScrollBars.None
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Contact_Person_Mobile_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_CoverageAmt.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_CoverageAmt.Text, Data_Type.Integer_Type, 12))
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Cmb_Insur_Comp_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_Insur_Comp.SelectedIndexChanged
        Try
            If Not Locate_Insurance_Company(Cmb_Insur_Comp.SelectedValue) Then
                Txt_Company_Address.Text = ""
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Function Locate_Insurance_Company(ByVal IComp_ID As Integer) As Boolean
        Try
            hms_helper = New Hms_Helperimpliments
            Dim dtbl As DataTable = Nothing

            If hms_helper.Get_Insurance_Master_Details(dtbl, IComp_ID) Then
                With dtbl

                    Txt_Company_Address.Text = .Rows(0).Item("Address").ToString

                    Return True
                End With
            Else
                Return False
            End If

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Btn_Find1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find1.Click
        Try

            If Txt_PMRID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "200|50|300|70|"
                Sql = "SELECT [Patient Name], [S.S.No], ([Family Name] + Address + City) as Address, ACC_ID AS [PMR-ID]"
                Sql += "FROM Patient_Account_Vw WHERE ([Account Status] = 'Active') and Br_Code ='" & Branch_Code & "'"
                Call ShowSearchengine(Txt_PMRID, Sql, 3, "[Patient Name]", Colwidth, , 0)
            End If

            'Validating Mandatory fields for locating
            If Txt_PMRID.Text.Trim = "" Then
                'MessageBox.Show("Invalid Appointment ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_PMRID.Focus() : Exit Sub
            End If

            If Locate_PMR_info(Txt_PMRID.Text.Trim, Branch_Code) Then
                Cmb_Insur_Comp.Focus()
            Else
                MessageBox.Show("Invalid PMR ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Function Locate_PMR_info(ByVal PMR_ID As String, ByVal Br_Code As Integer) As Boolean
        Try

            '-----------------   Clear Medical Record   -----------------------------------

            Call Clear_Form()

            '----------------------------------------------------------------------------

            Dim Dtbl As DataTable = Nothing

            '-----------------  Locate Pateint Medical Record Master info   -------------
            If Not hms_helper.Get_PMR_Masterinfo(Dtbl, PMR_ID, Br_Code) Then Return False


            With Dtbl
                Txt_PMRID.Text = PMR_ID
                Patient_Info1.Patient_ID = .Rows(0).Item("Patient ID").ToString

            End With

            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Txt_PMRID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_PMRID.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then Btn_Find1_Click(e, sender)
        Catch ex As Exception

        End Try
    End Sub

End Class