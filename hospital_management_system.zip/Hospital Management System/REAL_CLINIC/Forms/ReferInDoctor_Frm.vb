﻿
Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls
Public Class ReferInDoctor_Frm
#Region "Declarations"
    'Object of Employee Details Bussiness Layer
    Private ReferDoctor_BL As ReferDoctorMaster_BL_Cls
    Private mTr_Mode As Tran_Mode
    Private StrQry As String

    Private Com_BL As HMS_Common_BL_Cls
    Private hms_helper As HMS_Helper = Nothing

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_Ref_DrID.BackColor = Color.White
                    Me.Txt_Ref_DrID.ReadOnly = False
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_Ref_DrID.BackColor = Color.Silver
                    Me.Txt_Ref_DrID.ReadOnly = True
            End Select
        End Set
    End Property

#End Region

#Region "Functions"
    Private Sub ShowInGrid()
        Try
            Com_BL = New HMS_Common_BL_Cls
            Dim Sr_Dtbl As DataTable = Nothing

            StrQry = "SELECT Doctor,Qualification,Hospital,[Permanent Address], [Communication Address],[Official Address],Country,Phone1, Phone2, Mobile1, Mobile2,RefinDoc_ID From ReferIn_Doctor_Vw"
            If Com_BL.Get_Data(StrQry, Sr_Dtbl) Then
                With Dgrd_ReferInDr
                    .DataSource = Nothing
                    .DataSource = Sr_Dtbl
                    .Refresh()
                    .Columns(0).MinimumWidth = 150
                    .Columns(1).MinimumWidth = 75
                    .Columns(2).MinimumWidth = 175
                    .Columns(3).AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells
                    .Columns(4).AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells
                    .Columns(5).AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells


                End With
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try
    End Sub

    Private Function Locate_Values(ByVal RefDr_ID As Integer) As Boolean
        Try

            'Initialising BL Object
            ReferDoctor_BL = New ReferDoctorMaster_BL_Cls

            Dtbl = Nothing
            Call Clear_Form()

            Txt_Ref_DrID.Text = RefDr_ID

            'Retreiving Refer Doctor Details and Assign the values to respective controls
            If ReferDoctor_BL.Get_ReferDoctorIn_Details(Dtbl, RefDr_ID) Then
                Return Assigntocontrols(Dtbl)
            Else
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        Finally
            Dr = Nothing
            Dtbl = Nothing
            ReferDoctor_BL = Nothing
        End Try
    End Function

    Private Function Assigntocontrols(ByVal D_Table As DataTable) As Boolean
        Try

            Dr = D_Table.CreateDataReader()
            Dr.Read()
            With Dr

                Txt_Ref_DrID.Text = .Item("RefinDoc_ID")
                Txt_Ref_DrID.Tag = .Item("RefinDoc_ID")
                Txt_Ref_DrName.Text = .Item("Doctor")
                Txt_RefInHopital.Text = .Item("Hospital")
                Txt_Ref_DrAdd.Text = .Item("Permanent Address")
                Txt_Ref_Comm_Address.Text = .Item("Communication Address")
                Txt_Ref_OffAddress.Text = .Item("Official Address")
                Cmb_Country.SelectedValue = .Item("Country ID").ToString
                Txt_Ref_DrMobile1.Text = .Item("Mobile1")
                Txt_Ref_DrMobile2.Text = .Item("Mobile2")
                Txt_Ref_DrPhone1.Text = .Item("Phone1")
                Txt_Ref_DrPhone2.Text = .Item("Phone2")
                Txt_Ref_DrQF.Text = .Item("Qualification")

            End With

            Return True
        Catch ex As Exception
            Return False
        Finally
            D_Table = Nothing
        End Try
    End Function

    Private Sub Clear_Form()
        Try
            Txt_Ref_DrID.Text = ""
            Txt_Ref_DrID.Tag = ""
            Txt_Ref_DrName.Text = ""
            Txt_RefInHopital.Text = ""
            Txt_Ref_DrAdd.Text = ""
            Txt_Ref_Comm_Address.Text = ""
            Txt_Ref_OffAddress.Text = ""
            Cmb_Country.SelectedIndex = 0
            Txt_Ref_DrPhone1.Text = ""
            Txt_Ref_DrPhone2.Text = ""
            Txt_Ref_DrMobile1.Text = ""
            Txt_Ref_DrMobile2.Text = ""
            Txt_Ref_DrQF.Text = ""
            Txt_Ref_DrID.Focus()
            Tr_Mode = Tran_Mode.New_Mode
            Btn_Delete.Enabled = False
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
       
    End Sub

    Private Function Validate_Fields() As Boolean
        Try
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If

            If Tr_Mode <> Tran_Mode.New_Mode Then
                If Txt_Ref_DrID.Text.Trim = "" Then MessageBox.Show("Invalid Doctor ID ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Ref_DrID.Focus() : Exit Function
            End If
            If Txt_Ref_DrName.Text.Trim = "" Then MessageBox.Show("Invalid Doctor Name ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Ref_DrName.Focus() : Exit Function
            If Txt_RefInHopital.Text.Trim = "" Then MessageBox.Show("Invalid Hospital Name, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_RefInHopital.Focus() : Exit Function
            If Txt_Ref_DrAdd.Text.Trim = "" Then MessageBox.Show("Invalid Address ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Ref_DrAdd.Focus() : Exit Function
            If Txt_Ref_DrPhone1.Text.Trim = "" Then MessageBox.Show("Invalid Phone Number ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Ref_DrPhone1.Focus() : Exit Function
            If Txt_Ref_DrMobile1.Text.Trim = "" Then MessageBox.Show("Invalid Mobile Number ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Ref_DrMobile1.Focus() : Exit Function
            If Txt_Ref_DrPhone1.Text.Trim = Txt_Ref_DrPhone2.Text.Trim Then MessageBox.Show("Both phone1 and phone2 can't be same ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Ref_DrPhone2.Focus() : Exit Function
            If Txt_Ref_DrMobile1.Text.Trim = Txt_Ref_DrMobile2.Text.Trim Then MessageBox.Show("Both mobile1 and mobile2 can't be same ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Ref_DrMobile2.Focus() : Exit Function
            If Txt_Ref_DrQF.Text.Trim = "" Then MessageBox.Show("Invalid Qualification ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Ref_DrQF.Focus() : Exit Function
            If Txt_Ref_DrMobile2.Text.Trim = "" Then Txt_Ref_DrMobile2.Text = "-"
            If Txt_Ref_DrPhone2.Text.Trim = "" Then Txt_Ref_DrPhone2.Text = "-"
            If Txt_Ref_Comm_Address.Text.Trim = "" Then Txt_Ref_Comm_Address.Text = "-"
            If Txt_Ref_OffAddress.Text.Trim = "" Then Txt_Ref_OffAddress.Text = "-"
            Return True
        Catch ex As Exception

        End Try
    End Function

#End Region

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try
            ReferDoctor_BL = New ReferDoctorMaster_BL_Cls
            'Validating Data controls
            If Not Validate_Fields() Then Exit Sub

            With ReferDoctor_BL
                .RefinDoc_ID = Val(Txt_Ref_DrID.Text.Trim)
                .RefinDoctor_Name = Txt_Ref_DrName.Text.Trim
                .RefInDoctor_Hospital = Txt_RefInHopital.Text.Trim
                .RefinDoctor_Addr1 = Txt_Ref_DrAdd.Text.Trim
                .RefinDoctor_Addr2 = Txt_Ref_Comm_Address.Text.Trim
                .RefinDoctor_Addr3 = Txt_Ref_OffAddress.Text.Trim
                .RefinDoctor_CountryID = Cmb_Country.SelectedValue
                .RefinDoctor_Phone1 = Txt_Ref_DrPhone1.Text.Trim
                .RefinDoctor_Phone2 = Txt_Ref_DrPhone2.Text.Trim
                .RefinDoctor_Mobile1 = Txt_Ref_DrMobile1.Text.Trim
                .RefinDoctor_Mobile2 = Txt_Ref_DrMobile2.Text.Trim
                .RefinDoctor_Qualification = Txt_Ref_DrQF.Text.Trim

                Dtbl = Nothing
                If ReferDoctor_BL.Save_ReferDoctor_In(Dtbl, Val(Txt_Ref_DrID.Text.Trim), Tr_Mode) Then
                    MessageBox.Show("Refer In Doctor Details Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Call Clear_Form()
                    If Assigntocontrols(Dtbl) Then
                        Tr_Mode = Tran_Mode.Edit_Mode
                        Btn_Delete.Enabled = True
                    End If
                    Call ShowInGrid()

                Else
                    MessageBox.Show("Refer In Doctor Details not Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
                Btn_Clear.Focus()
            End With
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Call Clear_Form()
    End Sub

    Private Sub ReferInDoctor_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.F2 Then Btn_Find_Click(sender, e)
        If e.KeyCode = Keys.Enter Then SendKeyTab()
    End Sub

    Private Sub ReferInDoctor_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub ReferInDoctor_Frm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'SendKeyTab()
        'SendKeyTab()
        Try
            hms_helper = New Hms_Helperimpliments
            Call hms_helper.Fill_GenData(Cmb_Country, Gendatatype.Country)
            Call Clear_Form()
            Call ShowInGrid()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try
            If Txt_Ref_DrID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "150|75|150|150"
                Sql = "SELECT Doctor,Qualification,Hospital,[Permanent Address], [Communication Address],[Official Address],Country,Phone1, Phone2, Mobile1, Mobile2,RefinDoc_ID From ReferIn_Doctor_Vw"
                Call ShowSearchengine(Txt_Ref_DrID, Sql, 11, "Doctor", Colwidth, , 0)
            End If

            'Validating Mandatory fields for locating
            If Txt_Ref_DrID.Text.Trim = "" Then
                Txt_Ref_DrID.Focus() : Exit Sub
            End If

            If Locate_Values(Txt_Ref_DrID.Text.Trim) Then
                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Delete.Enabled = True
            Else
                MessageBox.Show("Refer In Doctor does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_Ref_DrID_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Ref_DrID.KeyPress
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Ref_DrID.Text, Data_Type.Integer_Type, 12))
    End Sub

    Private Sub Txt_Ref_DrID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_Ref_DrID.Validating
        Try
            If Txt_Ref_DrID.Text.Trim <> "" And Me.Txt_Ref_DrID.Text.Trim <> Me.Txt_Ref_DrID.Tag Then
                If Locate_Values(Txt_Ref_DrID.Text.Trim) Then
                    Btn_Delete.Enabled = True
                    Tr_Mode = Tran_Mode.Edit_Mode
                    'Txt_Ref_DrID.Focus()
                Else
                    MessageBox.Show("In valid refer in doctor", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Btn_Delete.Enabled = False
                    Tr_Mode = Tran_Mode.New_Mode
                    e.Cancel = True
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click
        Try
            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If

            If Tr_Mode = Tran_Mode.New_Mode Then
                MessageBox.Show("You have to locate details before deleting the record", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

            If Txt_Ref_DrID.Text.Trim = "" Then
                MessageBox.Show("Invalid Doctor ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_Ref_DrID.Focus() : Exit Sub
            End If

            'Confirm before delete the record
            If MessageBox.Show("Are you sure wan't to delete the selected Doctor", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = Windows.Forms.DialogResult.No Then
                Exit Sub
            End If

            'Initialising BL Object
            ReferDoctor_BL = New ReferDoctorMaster_BL_Cls

            If ReferDoctor_BL.Delete_ReferDoctor(Txt_Ref_DrID.Text.Trim) Then
                Call Btn_Clear_Click(sender, e)
                Call ShowInGrid()
            Else
                MessageBox.Show("You cannot delete this Refer In Doctor details" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgrd_ReferInDr_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Dgrd_ReferInDr.DoubleClick
        Try
            With Dgrd_ReferInDr
                If .CurrentRow Is Nothing Then Exit Sub
                Txt_Ref_DrID.Text = .Item("RefinDoc_ID", .CurrentCell.RowIndex).Value.ToString.Trim
                Call Btn_Find_Click(sender, e)
                Txt_Ref_DrID.Focus()
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Close()
    End Sub

    Private Sub Txt_Ref_DrAdd_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Txt_Ref_DrAdd.GotFocus
        Txt_Ref_DrAdd.SelectionStart = Len(Txt_Ref_DrAdd.Text)
    End Sub

    Private Sub Txt_Ref_DrAdd_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Ref_DrAdd.TextChanged
        If Tr_Mode = Tran_Mode.New_Mode Then
            Txt_Ref_Comm_Address.Text = Txt_Ref_DrAdd.Text.Trim
        End If
    End Sub

    Private Sub Txt_Ref_DrID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Ref_DrID.TextChanged

    End Sub
End Class