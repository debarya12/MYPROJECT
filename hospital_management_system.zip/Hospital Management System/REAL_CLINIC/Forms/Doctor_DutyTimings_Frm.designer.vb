﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Doctor_DutyTimings_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Doctor_DutyTimings_Frm))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Delete = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.Btn_Find = New System.Windows.Forms.Button
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Panel4 = New System.Windows.Forms.Panel
        Me.Dgvw_DutyTimings = New System.Windows.Forms.DataGridView
        Me.Cmb_WeekdayOFF = New System.Windows.Forms.CheckedListBox
        Me.Cmb_Services = New System.Windows.Forms.ComboBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Pnl_Time = New System.Windows.Forms.Panel
        Me.Btn_Cancel = New System.Windows.Forms.Button
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label
        Me.Panel6 = New System.Windows.Forms.Panel
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Txt_Totime = New System.Windows.Forms.DateTimePicker
        Me.Txt_FromTime = New System.Windows.Forms.DateTimePicker
        Me.Btn_AddtoGrid = New System.Windows.Forms.Button
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Cmb_Weekdays = New System.Windows.Forms.ComboBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Cmb_StartDay = New System.Windows.Forms.ComboBox
        Me.Nmr_TimeIntervel = New System.Windows.Forms.NumericUpDown
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Txt_DoctorID = New System.Windows.Forms.TextBox
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Label14 = New System.Windows.Forms.Label
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Dtp_EndTime = New System.Windows.Forms.DateTimePicker
        Me.Dtp_StartTime = New System.Windows.Forms.DateTimePicker
        Me.Label15 = New System.Windows.Forms.Label
        Me.Employee_Info1 = New REAL_CLINIC.Employee_Info
        Me.Pnl_Header.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.Panel4.SuspendLayout()
        CType(Me.Dgvw_DutyTimings, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Pnl_Time.SuspendLayout()
        Me.Pnl_Tran_mode.SuspendLayout()
        Me.Panel6.SuspendLayout()
        CType(Me.Nmr_TimeIntervel, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = CType(resources.GetObject("Pnl_Header.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Header.Controls.Add(Me.Label1)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(736, 24)
        Me.Pnl_Header.TabIndex = 100
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(8, 1)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(252, 18)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "D o c t o r 's  D u t y    T i m i n g s "
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Delete)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(256, 479)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(229, 35)
        Me.Pnl_Common_Btn.TabIndex = 47
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(168, 3)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 16
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(113, 3)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear.TabIndex = 15
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Delete
        '
        Me.Btn_Delete.BackgroundImage = CType(resources.GetObject("Btn_Delete.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Delete.Location = New System.Drawing.Point(58, 3)
        Me.Btn_Delete.Name = "Btn_Delete"
        Me.Btn_Delete.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Delete.TabIndex = 14
        Me.Btn_Delete.Text = "&Delete"
        Me.Btn_Delete.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = CType(resources.GetObject("Btn_Save.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(3, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save.TabIndex = 13
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Btn_Find
        '
        Me.Btn_Find.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find.BackgroundImage = CType(resources.GetObject("Btn_Find.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find.ForeColor = System.Drawing.Color.White
        Me.Btn_Find.Location = New System.Drawing.Point(312, 36)
        Me.Btn_Find.Name = "Btn_Find"
        Me.Btn_Find.Size = New System.Drawing.Size(29, 21)
        Me.Btn_Find.TabIndex = 1
        Me.Btn_Find.TabStop = False
        Me.Btn_Find.Text = "F2"
        Me.Btn_Find.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(2, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(45, 13)
        Me.Label2.TabIndex = 50
        Me.Label2.Text = "Doctor"
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.FromArgb(CType(CType(19, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(153, Byte), Integer))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(373, 34)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(359, 18)
        Me.Label6.TabIndex = 121
        Me.Label6.Text = "Doctor Details"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.Transparent
        Me.Panel4.Controls.Add(Me.Dgvw_DutyTimings)
        Me.Panel4.Location = New System.Drawing.Point(3, 296)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(730, 179)
        Me.Panel4.TabIndex = 127
        '
        'Dgvw_DutyTimings
        '
        Me.Dgvw_DutyTimings.AllowUserToAddRows = False
        Me.Dgvw_DutyTimings.AllowUserToDeleteRows = False
        Me.Dgvw_DutyTimings.AllowUserToResizeColumns = False
        Me.Dgvw_DutyTimings.AllowUserToResizeRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(248, Byte), Integer))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.DarkBlue
        Me.Dgvw_DutyTimings.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.Dgvw_DutyTimings.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(236, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Dgvw_DutyTimings.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(75, Byte), Integer), CType(CType(116, Byte), Integer), CType(CType(165, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgvw_DutyTimings.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.Dgvw_DutyTimings.ColumnHeadersHeight = 20
        Me.Dgvw_DutyTimings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.Dgvw_DutyTimings.Location = New System.Drawing.Point(0, 0)
        Me.Dgvw_DutyTimings.Name = "Dgvw_DutyTimings"
        Me.Dgvw_DutyTimings.ReadOnly = True
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(179, Byte), Integer))
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgvw_DutyTimings.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.Dgvw_DutyTimings.RowHeadersVisible = False
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(CType(CType(219, Byte), Integer), CType(CType(227, Byte), Integer), CType(CType(249, Byte), Integer))
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.Color.DarkBlue
        Me.Dgvw_DutyTimings.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.Dgvw_DutyTimings.Size = New System.Drawing.Size(730, 177)
        Me.Dgvw_DutyTimings.TabIndex = 125
        '
        'Cmb_WeekdayOFF
        '
        Me.Cmb_WeekdayOFF.BackColor = System.Drawing.Color.White
        Me.Cmb_WeekdayOFF.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Cmb_WeekdayOFF.CheckOnClick = True
        Me.Cmb_WeekdayOFF.FormattingEnabled = True
        Me.Cmb_WeekdayOFF.Location = New System.Drawing.Point(102, 93)
        Me.Cmb_WeekdayOFF.Name = "Cmb_WeekdayOFF"
        Me.Cmb_WeekdayOFF.Size = New System.Drawing.Size(209, 82)
        Me.Cmb_WeekdayOFF.TabIndex = 3
        '
        'Cmb_Services
        '
        Me.Cmb_Services.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Services.FormattingEnabled = True
        Me.Cmb_Services.Location = New System.Drawing.Point(97, 12)
        Me.Cmb_Services.Name = "Cmb_Services"
        Me.Cmb_Services.Size = New System.Drawing.Size(220, 21)
        Me.Cmb_Services.TabIndex = 7
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(8, 20)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(55, 13)
        Me.Label3.TabIndex = 129
        Me.Label3.Text = "Services"
        '
        'Pnl_Time
        '
        Me.Pnl_Time.BackColor = System.Drawing.Color.FromArgb(CType(CType(19, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(153, Byte), Integer))
        Me.Pnl_Time.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Pnl_Time.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Time.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Time.Controls.Add(Me.Btn_Cancel)
        Me.Pnl_Time.Controls.Add(Me.Pnl_Tran_mode)
        Me.Pnl_Time.Controls.Add(Me.Panel6)
        Me.Pnl_Time.Controls.Add(Me.Btn_AddtoGrid)
        Me.Pnl_Time.Controls.Add(Me.Label5)
        Me.Pnl_Time.Controls.Add(Me.Label8)
        Me.Pnl_Time.Controls.Add(Me.Cmb_Weekdays)
        Me.Pnl_Time.Controls.Add(Me.Cmb_Services)
        Me.Pnl_Time.Controls.Add(Me.Label3)
        Me.Pnl_Time.ForeColor = System.Drawing.Color.White
        Me.Pnl_Time.Location = New System.Drawing.Point(3, 215)
        Me.Pnl_Time.Name = "Pnl_Time"
        Me.Pnl_Time.Size = New System.Drawing.Size(729, 75)
        Me.Pnl_Time.TabIndex = 7
        '
        'Btn_Cancel
        '
        Me.Btn_Cancel.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Cancel.BackgroundImage = CType(resources.GetObject("Btn_Cancel.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Cancel.ForeColor = System.Drawing.Color.White
        Me.Btn_Cancel.Location = New System.Drawing.Point(651, 40)
        Me.Btn_Cancel.Name = "Btn_Cancel"
        Me.Btn_Cancel.Size = New System.Drawing.Size(58, 23)
        Me.Btn_Cancel.TabIndex = 12
        Me.Btn_Cancel.Text = "Cancel"
        Me.Btn_Cancel.UseVisualStyleBackColor = False
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(635, 12)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(74, 22)
        Me.Pnl_Tran_mode.TabIndex = 145
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(3, 1)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(68, 16)
        Me.Lbl_Tran_Mode.TabIndex = 0
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.Transparent
        Me.Panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel6.Controls.Add(Me.Label13)
        Me.Panel6.Controls.Add(Me.Label4)
        Me.Panel6.Controls.Add(Me.Txt_Totime)
        Me.Panel6.Controls.Add(Me.Txt_FromTime)
        Me.Panel6.Location = New System.Drawing.Point(328, 36)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(263, 28)
        Me.Panel6.TabIndex = 144
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.ForeColor = System.Drawing.Color.White
        Me.Label13.Location = New System.Drawing.Point(142, 7)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(21, 13)
        Me.Label13.TabIndex = 147
        Me.Label13.Text = "To"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(5, 7)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(36, 13)
        Me.Label4.TabIndex = 146
        Me.Label4.Text = "From"
        '
        'Txt_Totime
        '
        Me.Txt_Totime.CustomFormat = "hh : mm tt"
        Me.Txt_Totime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Txt_Totime.Location = New System.Drawing.Point(173, 3)
        Me.Txt_Totime.Name = "Txt_Totime"
        Me.Txt_Totime.ShowUpDown = True
        Me.Txt_Totime.Size = New System.Drawing.Size(87, 21)
        Me.Txt_Totime.TabIndex = 10
        '
        'Txt_FromTime
        '
        Me.Txt_FromTime.CustomFormat = "hh : mm tt"
        Me.Txt_FromTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Txt_FromTime.Location = New System.Drawing.Point(47, 3)
        Me.Txt_FromTime.Name = "Txt_FromTime"
        Me.Txt_FromTime.ShowUpDown = True
        Me.Txt_FromTime.Size = New System.Drawing.Size(87, 21)
        Me.Txt_FromTime.TabIndex = 9
        '
        'Btn_AddtoGrid
        '
        Me.Btn_AddtoGrid.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_AddtoGrid.BackgroundImage = CType(resources.GetObject("Btn_AddtoGrid.BackgroundImage"), System.Drawing.Image)
        Me.Btn_AddtoGrid.ForeColor = System.Drawing.Color.White
        Me.Btn_AddtoGrid.Location = New System.Drawing.Point(593, 40)
        Me.Btn_AddtoGrid.Name = "Btn_AddtoGrid"
        Me.Btn_AddtoGrid.Size = New System.Drawing.Size(58, 23)
        Me.Btn_AddtoGrid.TabIndex = 11
        Me.Btn_AddtoGrid.Text = "Add"
        Me.Btn_AddtoGrid.UseVisualStyleBackColor = False
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(335, 12)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(247, 20)
        Me.Label5.TabIndex = 142
        Me.Label5.Text = "Timings"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(8, 43)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(70, 13)
        Me.Label8.TabIndex = 137
        Me.Label8.Text = "Week Days"
        '
        'Cmb_Weekdays
        '
        Me.Cmb_Weekdays.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Weekdays.FormattingEnabled = True
        Me.Cmb_Weekdays.Location = New System.Drawing.Point(97, 37)
        Me.Cmb_Weekdays.Name = "Cmb_Weekdays"
        Me.Cmb_Weekdays.Size = New System.Drawing.Size(119, 21)
        Me.Cmb_Weekdays.TabIndex = 8
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(0, 95)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(99, 13)
        Me.Label7.TabIndex = 133
        Me.Label7.Text = "Weekly Off Days"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(-1, 69)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(61, 13)
        Me.Label9.TabIndex = 137
        Me.Label9.Text = "Start Day"
        '
        'Cmb_StartDay
        '
        Me.Cmb_StartDay.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_StartDay.FormattingEnabled = True
        Me.Cmb_StartDay.Location = New System.Drawing.Point(102, 66)
        Me.Cmb_StartDay.Name = "Cmb_StartDay"
        Me.Cmb_StartDay.Size = New System.Drawing.Size(209, 21)
        Me.Cmb_StartDay.TabIndex = 2
        '
        'Nmr_TimeIntervel
        '
        Me.Nmr_TimeIntervel.Location = New System.Drawing.Point(455, 187)
        Me.Nmr_TimeIntervel.Name = "Nmr_TimeIntervel"
        Me.Nmr_TimeIntervel.Size = New System.Drawing.Size(52, 21)
        Me.Nmr_TimeIntervel.TabIndex = 6
        Me.Nmr_TimeIntervel.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(323, 193)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(130, 13)
        Me.Label10.TabIndex = 139
        Me.Label10.Text = "Appointment Intervel"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label12.Location = New System.Drawing.Point(508, 192)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(65, 13)
        Me.Label12.TabIndex = 141
        Me.Label12.Text = "( Minutes)"
        '
        'Txt_DoctorID
        '
        Me.Txt_DoctorID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_DoctorID.Location = New System.Drawing.Point(101, 36)
        Me.Txt_DoctorID.Name = "Txt_DoctorID"
        Me.Txt_DoctorID.Size = New System.Drawing.Size(210, 21)
        Me.Txt_DoctorID.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Label14)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.Dtp_EndTime)
        Me.Panel1.Controls.Add(Me.Dtp_StartTime)
        Me.Panel1.Location = New System.Drawing.Point(101, 183)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(209, 26)
        Me.Panel1.TabIndex = 4
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.ForeColor = System.Drawing.Color.Black
        Me.Label14.Location = New System.Drawing.Point(92, 5)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(21, 13)
        Me.Label14.TabIndex = 147
        Me.Label14.Text = "To"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Transparent
        Me.Panel2.Location = New System.Drawing.Point(243, 3)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(20, 22)
        Me.Panel2.TabIndex = 145
        '
        'Dtp_EndTime
        '
        Me.Dtp_EndTime.CustomFormat = "hh : mm tt"
        Me.Dtp_EndTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_EndTime.Location = New System.Drawing.Point(117, 2)
        Me.Dtp_EndTime.Name = "Dtp_EndTime"
        Me.Dtp_EndTime.ShowUpDown = True
        Me.Dtp_EndTime.Size = New System.Drawing.Size(87, 21)
        Me.Dtp_EndTime.TabIndex = 5
        '
        'Dtp_StartTime
        '
        Me.Dtp_StartTime.CustomFormat = "hh : mm tt"
        Me.Dtp_StartTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_StartTime.Location = New System.Drawing.Point(2, 1)
        Me.Dtp_StartTime.Name = "Dtp_StartTime"
        Me.Dtp_StartTime.ShowUpDown = True
        Me.Dtp_StartTime.Size = New System.Drawing.Size(87, 21)
        Me.Dtp_StartTime.TabIndex = 4
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.ForeColor = System.Drawing.Color.Black
        Me.Label15.Location = New System.Drawing.Point(5, 190)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(67, 13)
        Me.Label15.TabIndex = 146
        Me.Label15.Text = "Start Time"
        '
        'Employee_Info1
        '
        Me.Employee_Info1.BackColor = System.Drawing.Color.AliceBlue
        Me.Employee_Info1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Employee_Info1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Employee_Info1.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Employee_Info1.Location = New System.Drawing.Point(373, 55)
        Me.Employee_Info1.Name = "Employee_Info1"
        Me.Employee_Info1.Padding = New System.Windows.Forms.Padding(2)
        Me.Employee_Info1.Size = New System.Drawing.Size(359, 119)
        Me.Employee_Info1.TabIndex = 143
        '
        'Doctor_DutyTimings_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(736, 518)
        Me.Controls.Add(Me.Cmb_WeekdayOFF)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Employee_Info1)
        Me.Controls.Add(Me.Txt_DoctorID)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Nmr_TimeIntervel)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Cmb_StartDay)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Pnl_Time)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.Btn_Find)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Doctor_DutyTimings_Frm"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        CType(Me.Dgvw_DutyTimings, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Pnl_Time.ResumeLayout(False)
        Me.Pnl_Time.PerformLayout()
        Me.Pnl_Tran_mode.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        CType(Me.Nmr_TimeIntervel, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Delete As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Btn_Find As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Dgvw_DutyTimings As System.Windows.Forms.DataGridView
    Friend WithEvents Cmb_Services As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Time As System.Windows.Forms.Panel
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Cmb_StartDay As System.Windows.Forms.ComboBox
    Friend WithEvents Nmr_TimeIntervel As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Btn_AddtoGrid As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Weekdays As System.Windows.Forms.ComboBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Txt_FromTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Txt_Totime As System.Windows.Forms.DateTimePicker
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Btn_Cancel As System.Windows.Forms.Button
    Friend WithEvents Txt_DoctorID As System.Windows.Forms.TextBox
    Friend WithEvents Employee_Info1 As REAL_CLINIC.Employee_Info
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Dtp_EndTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents Dtp_StartTime As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Cmb_WeekdayOFF As System.Windows.Forms.CheckedListBox
End Class
