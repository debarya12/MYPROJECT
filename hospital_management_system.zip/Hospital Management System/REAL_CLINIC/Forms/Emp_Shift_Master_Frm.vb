﻿

Option Explicit On
Imports HMS_Common.Common_Cls
Imports HMS_BL
Public Class Emp_Shift_Master_Frm

#Region "Declarations"
    'Object of Employee Details Bussiness Layer
    Private Emp_Shift_BL As Emp_Shift_BL_Cls
    Private mTr_Mode As Tran_Mode

    Private hms_Helper As HMS_Helper

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_ShiftID.BackColor = Color.White
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_ShiftID.BackColor = Color.Silver
            End Select
        End Set
    End Property


#End Region
    Dim StartTime As Date = "06:00:00 AM"
    Dim EndTime As Date = "06:00:00 PM"
    Private Sub Close_Btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

#Region "Functions"

    Private Sub Clear_Form()
        Try

            Txt_ShiftID.Text = ""


            Tr_Mode = Tran_Mode.New_Mode
            Btn_Save.Enabled = True
            Btn_Delete.Enabled = False

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Sub Fill_Shift_Master_Grid()
        Try

            Emp_Shift_BL = New Emp_Shift_BL_Cls
            Dtbl = Nothing
            With Dgvw_Shift_Master

                If Emp_Shift_BL.Get_Shift_Master_Details(Dtbl) Then
                    .DataSource = Dtbl
                    .Columns(0).Width = 100
                    .Columns(1).Width = 150
                    .Columns(2).Width = 150

                    .Refresh()
                End If
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region



    Private Function Validate_Fields() As Boolean
        Try
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If

            If Not Validate_Transactionright(Tr_Mode, Me.Name) Then
                If Tr_Mode = Tran_Mode.New_Mode Then
                    MessageBox.Show("Save Permission Denied for this User" & vbCrLf & "Please Contact System Administrator ", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                ElseIf Tr_Mode = Tran_Mode.Edit_Mode Then
                    MessageBox.Show("Edit Permission Denied for this User" & vbCrLf & "Please Contact System Administrator ", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
            End If

            'Assigning Default values
            Return True

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try

    End Function

    Private Function Locate_Values(ByVal Desig_ID As Integer) As Boolean

        Try

            'Initialising BL Object
            Emp_Shift_BL = New Emp_Shift_BL_Cls
            Dtbl = Nothing
            Call Clear_Form()
            Tr_Mode = Tran_Mode.Edit_Mode
            Btn_Delete.Enabled = True

            'Retreiving Company Details and Assign the values to respective controls
            If Emp_Shift_BL.Get_Shift_Master(Dtbl, Desig_ID) Then
                With Dtbl
                    Txt_ShiftID.Text = .Rows(0).Item("Shift_ID")
                    Txt_FromTime.Text = .Rows(0).Item("Time_From")
                    Txt_Totime.Text = .Rows(0).Item("Time_To")
                End With
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        Finally
            Dr = Nothing
            Dtbl = Nothing
            Emp_Shift_BL = Nothing
        End Try

    End Function

    Private Sub Emp_Shift_Master_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then Call SendKeyTab()
        Catch ex As Exception

        End Try

    End Sub



    Private Sub Emp_Shift_Master_Frm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try

            Call Fill_Shift_Master_Grid()
            Txt_FromTime.Text = StartTime
            Txt_Totime.Text = EndTime
        Catch ex As Exception

        End Try
    End Sub


    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try


            If Not Validate_Fields() Then Exit Sub
            Dim Dtbl As DataTable

            'Initialising BL Object
            Emp_Shift_BL = New Emp_Shift_BL_Cls
            Dtbl = Nothing
            Emp_Shift_BL.Shift_ID = Val(Txt_ShiftID.Text)
            Emp_Shift_BL.Time_From = Format(Txt_FromTime.Value, "hh:mm tt").ToString
            Emp_Shift_BL.Time_To = Format(Txt_Totime.Value, "hh:mm tt").ToString

            If Emp_Shift_BL.Save_Emp_Shift_Master(Dtbl, Tr_Mode, Val(Txt_ShiftID.Text.Trim)) Then
                Txt_ShiftID.Text = Dtbl.Rows(0).Item("Shift_ID").ToString
                Tr_Mode = Tran_Mode.Edit_Mode
                MessageBox.Show("Employee Shift Master Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Btn_Clear.Focus()
                Call Fill_Shift_Master_Grid()
            End If

        Catch ex As Exception

        End Try
    End Sub



    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try

            Call Clear_Form()
            Txt_ShiftID.Focus()

        Catch ex As Exception

        End Try

    End Sub

    Private Sub Dgvw_Emp_DesigMaster_CellDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgvw_Shift_Master.CellDoubleClick
        Try
            With Dgvw_Shift_Master
                If .CurrentRow Is Nothing Then Exit Sub
                Txt_ShiftID.Text = .CurrentRow.Cells("Shift_ID").Value
                Call Locate_Values(Txt_ShiftID.Text)
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try

            'search engine
            If Txt_ShiftID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "100|300|5|"
                Sql = "Select * From Employee_Designation_Details_Vw "
                Call ShowSearchengine(Txt_ShiftID, Sql, 0, "[Designation]", Colwidth, , 0)
            End If


            'Validating Mandatory fields for locating
            If Txt_ShiftID.Text.Trim = "" Then
                'MessageBox.Show("Invalid Group ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_ShiftID.Focus() : Exit Sub
            End If

            If Locate_Values(Txt_ShiftID.Text) Then
                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Delete.Enabled = True
                Txt_ShiftID.Focus()
            Else
                MessageBox.Show("Group ID does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_DesigID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_ShiftID.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then Btn_Find_Click(sender, e)
        Catch ex As Exception

        End Try
    End Sub


    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click
        Try
            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If

            Emp_Shift_BL = New Emp_Shift_BL_Cls
            Dtbl = Nothing
            If MessageBox.Show("Are You Sure Delete the Selected Shift ", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.No Then Exit Sub

            If Emp_Shift_BL.Del_Emp_Shift(Dtbl, Txt_ShiftID.Text.Trim) Then
                If Dtbl.Rows(0).Item(0).ToString = "0" Then MessageBox.Show("Cancellation failed" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Exit Sub
                MessageBox.Show("Employee Shift Cancelled", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("You cannot delete this Shift" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

            Btn_Clear.Focus()
            Fill_Shift_Master_Grid()

        Catch ex As Exception

        End Try
    End Sub


    Private Sub Dgvw_Shift_Master_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgvw_Shift_Master.CellContentClick

    End Sub
End Class