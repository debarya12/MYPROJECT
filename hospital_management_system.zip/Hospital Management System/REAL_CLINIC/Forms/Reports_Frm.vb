﻿

Option Explicit On
Imports System.IO
Imports HMS_BL
Imports HMS_Common.Common_Cls
Public Class Reports_Frm

#Region "Declarations"
    'Object of Employee Details Bussiness Layer
    Private Rpt_BL As HMS_BL.Reports_BL_Cls
    Private mRpt_Vwr As ReportViewer_Cls
    Private hms_helper As HMS_Helper = Nothing

    Dim tvRoot As TreeNode
    Dim tvNode As TreeNode

    Dim Rpt_Ds As DataSet = Nothing

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing

    Dim Rpt_Formulafields As String = "Company| " & Company_Name & "|Branch|" & Branch_Name
    Dim Rpt_Filename As String = ""
    Dim Report_Heading As String = ""
    Dim Add_Query As String = ""
    Dim mReport_ID As String = ""
#End Region

    Private Property Report_ID() As String
        Get
            Return mReport_ID
        End Get
        Set(ByVal value As String)
            mReport_ID = value
        End Set
    End Property

    Private Sub Reports_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        Try
            If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Reports_Frm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            Call Fill_Reportgroup()
            Call Fill_Reportoptions()
            Me.Tvw_Reportoptions.ExpandAll()
            Me.Tvw_Reportoptions.Nodes(0).EnsureVisible()
            Call Set_Environment("")
            Dtp_1.Value = Today
            Dtp_2.Value = Today
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Show_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Show.Click
        Try
            If Report_ID.Trim = "" Then
                MessageBox.Show("Invalid Report Selection,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Sub
            End If

            If Not Date_Validation() Then MessageBox.Show("Date Mismatch ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Dtp_1.Focus() : Exit Sub

            'Initialising Report Objects
            mRpt_Vwr = New ReportViewer_Cls
            'Rpt_Ds = Nothing

            If Not File.Exists(Rpt_Filename) Then
                MessageBox.Show("Report File : (" & Rpt_Filename & ") does not exists" & vbCrLf & "Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            Call Show_Report(Report_ID)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Try
            Me.Close()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try
            Call Clear_Form()
            With Tvw_Reportoptions
                .SelectedNode = .Nodes(0)
                .Select()
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Tvw_Reportoptions_AfterSelect(ByVal sender As Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles Tvw_Reportoptions.AfterSelect
        Try
            Call Select_Report()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Pnl_Text_1_Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Pnl_Text_1_Btn_Find.Click
        Try
            If Pnl_Text_1_Btn_Find.Tag <> "" Then
                Txt_Box1.Text = ""
                Call Searchfield(Txt_Box1, Pnl_Text_1_Btn_Find.Tag)
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Pnl_Text_2_Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Pnl_Text_2_Btn_Find.Click
        Try
            Dim Dtbl As New DataTable
            hms_helper = New Hms_Helperimpliments
            If Pnl_Text_2_Btn_Find.Tag <> "" Then
                Txt_Box2.Text = ""
                Call Searchfield(Txt_Box2, Pnl_Text_2_Btn_Find.Tag)

                If hms_helper.Get_OutPatient_ID_Latest(Dtbl, Txt_Box2.Text, Dtp_1.Value, Branch_Code) Then
                    Txt_Box1.Text = Dtbl.Rows(0).Item("OPD_ID").ToString
                End If

            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Cmb_2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_2.SelectedIndexChanged
        Try

            If Report_ID = 26 Then
                Dim dtbl As DataTable = Nothing
                Dim Bank_Acc_tran_BL As BankAccount_BL_Cls
                Bank_Acc_tran_BL = New BankAccount_BL_Cls

                If Bank_Acc_tran_BL.Get_bankAccount_Numbers(dtbl, Cmb_1.SelectedValue, Cmb_2.SelectedValue, Branch_Code) Then

                    Call Populate_Accno(dtbl, Cmb_3)

                End If
            End If


        Catch ex As Exception

        End Try


    End Sub

    Private Sub Btn_Process_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Process.Click
        Try

            Call Report_Process(Report_ID)

        Catch ex As Exception

        End Try
    End Sub

#Region "Methods"

    Private Function Date_Validation() As Boolean
        Try
            If Pnl_Dtp_1.Visible = True And Pnl_Dtp_2.Visible = True Then
                If Dtp_1.Value > Dtp_2.Value Then Return False
            End If
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Populate_Accno(ByRef Acno_Dtbl As DataTable, ByRef Cmb As ComboBox) As Boolean

        Try
            Dim Dtbl As New DataTable
            Dim Dr As DataRow = Nothing

            With Dtbl
                .Columns.Add("Acc_no")
                .Columns.Add("BankAcc_ID")
            End With

            Dim i_Ctr As Int16 = 0
            With Acno_Dtbl
                Dr = Dtbl.NewRow
                Dr("Acc_no") = " < S E L E C T > "
                Dr("BankAcc_ID") = "0"
                Dtbl.Rows.Add(Dr)


                For i_Ctr = 0 To Acno_Dtbl.Rows.Count - 1
                    Dr = Dtbl.NewRow
                    Dr("Acc_no") = .Rows(i_Ctr).Item("Acc_no").ToString
                    Dr("BankAcc_ID") = .Rows(i_Ctr).Item("BankAcc_ID").ToString
                    Dtbl.Rows.Add(Dr)
                Next
            End With

            If Dtbl.Rows.Count > 1 Then
                With Cmb
                    .DataSource = Nothing
                    .DataSource = Dtbl
                    .DisplayMember = "Acc_no"
                    .ValueMember = "BankAcc_ID"
                    .SelectedIndex = 0
                End With
            End If

            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Clear_Form()
        Try


            Rpt_Formulafields = "Company| " & Company_Name & "|Branch|" & Branch_Name
            Report_ID = ""
            Rpt_Filename = ""
            Report_Heading = ""
            Add_Query = ""
            Rpt_Ds = Nothing
            Dr = Nothing
            Dtbl = Nothing
            Lbl_Heading.Text = ""

            Cmb_1.DataSource = Nothing
            Cmb_2.DataSource = Nothing
            Cmb_3.DataSource = Nothing
            Cmb_4.DataSource = Nothing


            Txt_Box1.Text = ""
            Txt_Box2.Text = ""


            If Pnl_Cmb_1.Visible Then
                If Cmb_1.Items.Count > 0 Then Cmb_1.SelectedIndex = 0
            End If

            If Pnl_Cmb_2.Visible Then
                If Cmb_2.Items.Count > 0 Then Cmb_2.SelectedIndex = 0
            End If


            If Pnl_Cmb_3.Visible Then
                If Cmb_3.Items.Count > 0 Then Cmb_3.SelectedIndex = 0
            End If


            If Pnl_Dtp_1.Visible Then
                Dtp_1.Value = Today
            End If
            If Pnl_Dtp_2.Visible Then
                Dtp_2.Value = Today
            End If
            Call Set_Default_Env()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Fill_Reportgroup()
        Try
            Dtbl = Nothing
            Dr = Nothing
            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Get_Reportgroup(Dtbl) Then
                tvRoot = Me.Tvw_Reportoptions.Nodes.Add("REPORTS")

                Dr = Dtbl.CreateDataReader
                With Dr
                    While Dr.Read
                        tvNode = tvRoot.Nodes.Add(Dr.Item(0), Dr.Item(1))
                        tvNode.ForeColor = Color.Maroon
                        tvNode.Name = "G" & Dr.Item(0).ToString
                        tvNode.NodeFont = New Font("Tahoma", 9, FontStyle.Bold)
                    End While
                End With

            End If


        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Fill_Reportoptions()
        Try
            Dtbl = Nothing
            Dr = Nothing
            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Get_Reportoptions(Dtbl) Then

                Dr = Dtbl.CreateDataReader

                With Tvw_Reportoptions
                    While Dr.Read
                        For i = 0 To .Nodes(0).Nodes.Count - 1
                            If .Nodes(0).Nodes(i).Name = "G" & Dr.Item("RptGrp_ID").ToString Then
                                tvRoot = .Nodes(0).Nodes(i)
                                tvNode = tvRoot.Nodes.Add(Dr.Item("Rpt_ID"), Dr.Item("Rpt_Name"))
                                tvNode.ForeColor = Color.DarkBlue
                                tvNode.Name = "R" & Dr.Item("Rpt_ID").ToString
                                tvNode.Tag = Dr.Item("Rpt_Filename").ToString

                                tvNode.NodeFont = New Font("Tahoma", 8, FontStyle.Regular)
                                '.Nodes(0).Nodes(i).Expand()
                            End If
                        Next
                    End While

                End With

            End If


        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Select_Report()
        Try
            Report_ID = ""
            Rpt_Filename = ""
            Lbl_Heading.Text = ""
            Set_Default_Env()

            With Tvw_Reportoptions
                Try
                    Lbl_Heading.Text = Lbl_Heading.Text + .SelectedNode.Text.ToUpper
                    Report_ID = .SelectedNode.Name

                    Rpt_Filename = .SelectedNode.Tag

                    If Rpt_Filename.Trim = "" Then Exit Sub

                    Rpt_Filename = IIf(Strings.Left(Rpt_Filename, 1) = "\", Strings.Right(Rpt_Filename, Len(Rpt_Filename) - 1), Rpt_Filename)
                    Rpt_Filename = File_Path & "\" & Rpt_Filename

                Catch ex As Exception

                End Try

                If Report_ID <> "" Then
                    If Strings.Left(Report_ID, 1) = "G" Then
                        Report_ID = "G"
                    ElseIf Strings.Left(Report_ID, 1) = "R" Then
                        Report_ID = Strings.Right(Report_ID, Len(Report_ID) - 1)
                    End If
                Else
                    Report_ID = "G"
                End If

                Call Set_Environment(Report_ID)


            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Set_Environment(ByVal Rpt_ID As String)
        Try
            Call Set_Default_Env()

            Select Case Rpt_ID
                Case 1

                Case 2
                    Call Set_Common_Env()
                Case 3
                    Call Set_Outpatient_Env()
                Case 5
                    Call Set_Common_Env()
                Case 6
                    Call Set_Common_Env()
                Case 7, 25, 4
                    Call Set_General_Sub_Env()
                Case 8
                    Call Set_Doctor_Env()
                Case 9
                    Call Set_Common_Env()
                Case 10
                    Call Set_Common_Env()
                Case 11
                    Call Set_Common_Env()
                Case 12
                    Call Set_Common_Env()
                Case 13
                    Call Set_PatientDiagnosis_Env()
                Case 14, 15
                    Call Set_Common_Env()
                Case 16
                    Call Set_Patient_Bill_Env()
                Case 17
                    Call Set_Employee_Env()
                Case 18
                    Call Set_Doctors_Dutytimings_Env()
                Case 19
                    Call Set_Doctors_LeaveReg_Env()
                Case 20
                    Call Set_IPReg_Env()
                Case 21
                    Call Set_Patient_Bill_Summary_Env()
                Case 22
                    Call Set_Dotorwise_OP_Collection_Env()
                Case 23
                    Call Set_Patient_Pendingbill_Env()
                Case 24
                    Call Set_Dotorwise_OP_Collection_Detailed_Env()
                Case 26
                    Call Set_Bank_Account_Tran_Ledger_Env()
                Case 27
                    Call Set_Employee_Account_Tran_Ledger_Env()
                Case 28
                    Call Set_Bank_Account_Outstanding_Env()
                Case 29
                    Call Set_Employee_Account_Outstanding_Env()
                Case 30
                    Call Set_Patient_Deposit_Ledger_Env()
                Case 31
                    Call Set_Patient_Discharge_Env()

                Case Else

            End Select
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Set_Default_Env()
        Try
            Pnl_Cmb_1.Visible = False
            Pnl_Cmb_2.Visible = False
            Pnl_Cmb_3.Visible = False
            Pnl_Cmb_4.Visible = False


            Pnl_Text_1.Visible = False
            Pnl_Text_2.Visible = False

            Pnl_Dtp_1.Visible = False
            Pnl_Dtp_2.Visible = False

            Pnl_Text_1_Btn_Find.Tag = ""
            Pnl_Text_1_Btn_Find.Enabled = False
            Pnl_Text_2_Btn_Find.Tag = ""
            Pnl_Text_2_Btn_Find.Enabled = False

            Dtp_1.Value = Today
            Dtp_2.Value = Today

            Btn_Show.Enabled = False
            Btn_Process.Enabled = False
            Lbl_Date1.Text = "From"
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Set_Common_Env()
        Try

            Pnl_Cmb_1.Visible = False
            Pnl_Cmb_2.Visible = False
            Pnl_Cmb_3.Visible = False
            Pnl_Cmb_4.Visible = False


            Pnl_Text_1.Visible = False
            Pnl_Text_2.Visible = False


            Pnl_Dtp_1.Visible = False
            Pnl_Dtp_2.Visible = False

            Btn_Show.Enabled = True
            Btn_Process.Enabled = False
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Set_General_Sub_Env()
        Try
            Btn_Show.Enabled = True
            Btn_Clear.Enabled = True

            Pnl_Dtp_1.Visible = True
            Pnl_Dtp_2.Visible = True


            hms_helper = New Hms_Helperimpliments
            If hms_helper.Fill_AccountMaster(Cmb_1, "     <       ALL     >   ") Then
                Pnl_Cmb_1.Visible = True
                Lbl_Cmb1.Text = "Account Head"
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Set_Patient_Discharge_Env()
        Try
            Btn_Show.Enabled = True
            Btn_Clear.Enabled = True

            Pnl_Dtp_1.Visible = True
            Pnl_Dtp_2.Visible = True

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Set_Patient_Pendingbill_Env()
        Try
            Btn_Show.Enabled = True
            Btn_Clear.Enabled = True

            Pnl_Dtp_1.Visible = True
            Pnl_Dtp_2.Visible = True
            Pnl_Text_1.Visible = True
            Pnl_Text_2.Visible = False

            Lbl_Txt1.Text = "PMR ID"
            Lbl_Txt2.Text = "Patient ID"
            Pnl_Text_1_Btn_Find.Tag = "OP_ID"
            Pnl_Text_1_Btn_Find.Enabled = True
            Pnl_Text_2_Btn_Find.Tag = "P_ID"
            Pnl_Text_2_Btn_Find.Enabled = True

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Set_PatientDiagnosis_Env()
        Try
            Btn_Show.Enabled = True
            Btn_Clear.Enabled = True

            Pnl_Dtp_1.Visible = True
            Pnl_Dtp_2.Visible = True

            Pnl_Cmb_1.Visible = True  'doctor  

            Pnl_Text_1.Visible = True
            Pnl_Text_2.Visible = True

            Lbl_Txt1.Text = "PMR ID"
            Lbl_Txt2.Text = "Patient ID"
            Pnl_Text_1_Btn_Find.Tag = "OP_ID"
            Pnl_Text_1_Btn_Find.Enabled = True
            Pnl_Text_2_Btn_Find.Tag = "P_ID"
            Pnl_Text_2_Btn_Find.Enabled = True

            hms_helper = New Hms_Helperimpliments
            If hms_helper.Fill_Doctors(Cmb_1, "     <       ALL     >   ") Then
                Pnl_Cmb_1.Visible = True
                Lbl_Cmb1.Text = "Doctor"
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Set_IPReg_Env()
        Try
            Btn_Show.Enabled = True
            Btn_Clear.Enabled = True

            Pnl_Dtp_1.Visible = True
            Pnl_Dtp_2.Visible = True

            Pnl_Cmb_1.Visible = True  'services
            Pnl_Cmb_2.Visible = True  'doctor
            Pnl_Cmb_3.Visible = True  'Dept


            Pnl_Text_1.Visible = True
            Pnl_Text_2.Visible = True


            Lbl_Txt1.Text = "OP ID"
            Lbl_Txt2.Text = "Patient ID"
            Pnl_Text_1_Btn_Find.Tag = "OP_ID"
            Pnl_Text_1_Btn_Find.Enabled = True
            Pnl_Text_2_Btn_Find.Tag = "P_ID"
            Pnl_Text_2_Btn_Find.Enabled = True

            hms_helper = New Hms_Helperimpliments
            Cmb_1.DataSource = Nothing
            If hms_helper.Fill_Doctors(Cmb_1, "     <       ALL     >   ") Then
                Pnl_Cmb_1.Visible = True
                Lbl_Cmb1.Text = "Doctor"
            End If

            Cmb_2.DataSource = Nothing
            If hms_helper.Fill_Service(Cmb_2, "     <       ALL     >   ") Then
                Pnl_Cmb_2.Visible = True
                Lbl_Cmb2.Text = "Services"
            End If

            Cmb_3.DataSource = Nothing
            If hms_helper.Fill_GenData(Cmb_3, Gendatatype.Department, "     <       ALL     >   ") Then
                Pnl_Cmb_3.Visible = True
                Lbl_Cmb3.Text = "Departments"
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Set_Outpatient_Env()
        Try


            Btn_Show.Enabled = True
            Btn_Clear.Enabled = True

            Pnl_Dtp_1.Visible = True
            Pnl_Dtp_2.Visible = True

            Pnl_Cmb_1.Visible = True  'services
            Pnl_Cmb_2.Visible = True  'doctor
            Pnl_Cmb_3.Visible = False  'Dept

            Pnl_Text_1.Visible = True
            Pnl_Text_2.Visible = True

            Lbl_Txt1.Text = "PMR ID"
            Lbl_Txt2.Text = "Patient ID"
            Pnl_Text_1_Btn_Find.Tag = "OP_ID"
            Pnl_Text_1_Btn_Find.Enabled = True
            Pnl_Text_2_Btn_Find.Tag = "P_ID"
            Pnl_Text_2_Btn_Find.Enabled = True

            hms_helper = New Hms_Helperimpliments
            If hms_helper.Fill_Doctors(Cmb_1, "     <       ALL     >   ") Then
                Pnl_Cmb_1.Visible = True
                Lbl_Cmb1.Text = "Doctor"
            End If

            If hms_helper.Fill_Service(Cmb_2, "     <       ALL     >   ") Then
                Pnl_Cmb_2.Visible = True
                Lbl_Cmb2.Text = "Services"
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Set_Patient_Bill_Env()
        Try


            hms_helper = New Hms_Helperimpliments
            Btn_Show.Enabled = True
            Btn_Clear.Enabled = True

            Pnl_Dtp_1.Visible = True
            Pnl_Dtp_2.Visible = True


            Pnl_Text_1.Visible = True
            Pnl_Text_2.Visible = True

            Pnl_Cmb_1.Visible = True
            Cmb_1.DataSource = Nothing
            Cmb_1.Items.Add("     <       ALL     >   ")
            Cmb_1.Items.Add("Paid")
            Cmb_1.Items.Add("UnPaid")
            Cmb_1.SelectedIndex = 0
            Lbl_Cmb1.Text = "Bill Status"

            Pnl_Cmb_2.Visible = True

            hms_helper.Fill_ExpenseMaster(Cmb_2, "     <       ALL     >   ")
            Cmb_1.SelectedIndex = 0
            Lbl_Cmb2.Text = "Expense Head"


            Lbl_Txt1.Text = "PMR ID"
            Lbl_Txt2.Text = "Patient ID"
            Pnl_Text_1_Btn_Find.Tag = "OP_ID"
            Pnl_Text_1_Btn_Find.Enabled = True
            Pnl_Text_2_Btn_Find.Tag = "P_ID"
            Pnl_Text_2_Btn_Find.Enabled = True
        Catch ex As Exception

        End Try


    End Sub

    Private Sub Set_Doctor_Env()
        Try
            Btn_Show.Enabled = True
            Btn_Clear.Enabled = True


            hms_helper = New Hms_Helperimpliments
            If hms_helper.Fill_GenData(Cmb_1, Gendatatype.Doctor_Category, "     <       ALL     >   ") Then
                Pnl_Cmb_1.Visible = True
                Lbl_Cmb1.Text = "Category"
            End If

            Pnl_Dtp_1.Visible = True
            Pnl_Dtp_2.Visible = True
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Set_Employee_Env()
        Try
            Btn_Show.Enabled = True
            Btn_Clear.Enabled = True


            hms_helper = New Hms_Helperimpliments
            If hms_helper.Fill_GenData(Cmb_1, Gendatatype.Employee_Category, "     <       ALL     >   ") Then
                Pnl_Cmb_1.Visible = True
                Lbl_Cmb1.Text = "Category"
            End If
            Pnl_Cmb_2.Visible = True
            Lbl_Cmb2.Text = "Gender"
            If Cmb_1.Items.Count > 0 Then Cmb_1.SelectedIndex = 0
            Cmb_2.DataSource = Nothing
            Cmb_2.Items.Add("     <       ALL     >   ")
            Cmb_2.Items.Add("Male")
            Cmb_2.Items.Add("Female")
            Cmb_2.SelectedIndex = 0

            Pnl_Dtp_1.Visible = False
            Pnl_Dtp_2.Visible = False
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Set_Doctors_Dutytimings_Env()
        Try
            Btn_Show.Enabled = True
            Btn_Clear.Enabled = True

            hms_helper = New Hms_Helperimpliments
            If hms_helper.Fill_Doctors(Cmb_1, "< All >") Then
                Pnl_Cmb_1.Visible = True
                Lbl_Cmb1.Text = "Doctor"
            End If
            If Cmb_1.Items.Count > 0 Then Cmb_1.SelectedIndex = 0

            Pnl_Dtp_1.Visible = True
            Pnl_Dtp_2.Visible = True
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Set_Doctors_LeaveReg_Env()
        Try


            Btn_Show.Enabled = True
            Btn_Clear.Enabled = True

            hms_helper = New Hms_Helperimpliments
            If hms_helper.Fill_Doctors(Cmb_1, "< All >") Then
                Pnl_Cmb_1.Visible = True
                Lbl_Cmb1.Text = "Doctor"
            End If
            If Cmb_1.Items.Count > 0 Then Cmb_1.SelectedIndex = 0

            hms_helper = New Hms_Helperimpliments
            If hms_helper.Fill_GenData(Cmb_2, Gendatatype.Leave_Type, "< All >") Then
                Pnl_Cmb_2.Visible = True
                Lbl_Cmb2.Text = "Leave Type"
            End If

            If Cmb_2.Items.Count > 0 Then Cmb_2.SelectedIndex = 0
            Pnl_Dtp_1.Visible = True
            Pnl_Dtp_2.Visible = True
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Set_Patient_Bill_Summary_Env()
        Try
            Btn_Show.Enabled = True
            Btn_Clear.Enabled = True
            Btn_Process.Enabled = True

            Pnl_Dtp_1.Visible = True
            Pnl_Dtp_2.Visible = True

            Pnl_Text_1.Visible = True

            Lbl_Txt1.Text = "PMR ID"

            Pnl_Text_1_Btn_Find.Tag = "OP_ID"
            Pnl_Text_1_Btn_Find.Enabled = True
          

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Set_Patient_Deposit_Ledger_Env()
        Try
            Btn_Show.Enabled = True
            Btn_Clear.Enabled = True
            Btn_Process.Enabled = False

            Pnl_Dtp_1.Visible = True
            Pnl_Dtp_2.Visible = True

            Pnl_Text_1.Visible = True

            Lbl_Txt1.Text = "PMR ID"

            Pnl_Text_1_Btn_Find.Tag = "OP_ID"
            Pnl_Text_1_Btn_Find.Enabled = True


        Catch ex As Exception

        End Try
    End Sub

    Private Sub Set_Dotorwise_OP_Collection_Env()
        Try
            Btn_Show.Enabled = True
            Btn_Clear.Enabled = True

            Pnl_Dtp_1.Visible = True
            Pnl_Dtp_2.Visible = True


            Pnl_Cmb_1.Visible = True
            hms_helper = New Hms_Helperimpliments
            Cmb_1.DataSource = Nothing
            If hms_helper.Fill_Doctors(Cmb_1, "     <       ALL     >   ") Then
                Pnl_Cmb_1.Visible = True
                Lbl_Cmb1.Text = "Doctor"
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Set_Dotorwise_OP_Collection_Detailed_Env()
        Try
            Btn_Show.Enabled = True
            Btn_Clear.Enabled = True

            Pnl_Dtp_1.Visible = True
            Pnl_Dtp_2.Visible = True
            Pnl_Cmb_2.Visible = True

            Pnl_Cmb_1.Visible = True
            hms_helper = New Hms_Helperimpliments
            Cmb_1.DataSource = Nothing
            If hms_helper.Fill_Doctors(Cmb_1, "     <       ALL     >   ") Then
                Pnl_Cmb_1.Visible = True
                Lbl_Cmb1.Text = "Doctor"
            End If

            Cmb_2.DataSource = Nothing


            Rpt_BL = New HMS_BL.Reports_BL_Cls
            Dim dtbl As DataTable = Nothing
            Cmb_2.Items.Clear()
            Pnl_Cmb_2.Visible = True
            Lbl_Cmb2.Text = "Particulars"
            Cmb_2.Items.Add("     <       ALL     >   ")
            If Rpt_BL.Get_Expense_Particulars(dtbl) Then

                For i = 0 To dtbl.Rows.Count - 1
                    Cmb_2.Items.Add(dtbl.Rows(i).Item(0).ToString)
                Next

            End If

            Cmb_2.SelectedIndex = 0
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Set_Bank_Account_Tran_Ledger_Env()
        Try
            hms_helper = New Hms_Helperimpliments
            Btn_Show.Enabled = True
            Btn_Clear.Enabled = True
            Btn_Process.Enabled = False

            Pnl_Dtp_1.Visible = True
            Pnl_Dtp_2.Visible = True

            Pnl_Cmb_1.Visible = True
            Cmb_1.DataSource = Nothing
            Cmb_2.DataSource = Nothing
            Cmb_3.DataSource = Nothing

            Call hms_helper.Fill_Investment_Banks(Cmb_1, "< Select >")
            Cmb_1.SelectedIndex = 0
            Lbl_Cmb1.Text = "Investment Banks"
            Pnl_Cmb_2.Visible = True

            Call hms_helper.Fill_GenData(Cmb_2, Gendatatype.BankAccount_Type, "< Select >")
            Cmb_2.SelectedIndex = 0
            Lbl_Cmb2.Text = "Account Type"

            Pnl_Cmb_3.Visible = True
            Lbl_Cmb3.Text = "Account Number"

        Catch ex As Exception

        End Try

    End Sub

    Private Sub Set_Employee_Account_Tran_Ledger_Env()

        Try
            hms_helper = New Hms_Helperimpliments
            Btn_Show.Enabled = True
            Btn_Clear.Enabled = True

            Pnl_Dtp_1.Visible = True
            Pnl_Dtp_2.Visible = True

            Pnl_Cmb_1.Visible = True
            Cmb_1.DataSource = Nothing


            Call hms_helper.Fill_Emp_Accounts(Cmb_1, "< Select >")
            Cmb_1.SelectedIndex = 0
            Lbl_Cmb1.Text = "Employee Name"
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Set_Employee_Account_Outstanding_Env()
        Try
            hms_helper = New Hms_Helperimpliments
            Btn_Show.Enabled = True
            Btn_Clear.Enabled = True
            Btn_Process.Enabled = True

            Pnl_Dtp_1.Visible = True
            Lbl_Date1.Text = "Demand Date"
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Set_Bank_Account_Outstanding_Env()
        Try
            hms_helper = New Hms_Helperimpliments
            Btn_Show.Enabled = True
            Btn_Clear.Enabled = True
            Btn_Process.Enabled = True

            Pnl_Dtp_1.Visible = True
            Lbl_Date1.Text = "Demand Date"

            Pnl_Cmb_1.Visible = True
            Cmb_1.DataSource = Nothing
            Cmb_2.DataSource = Nothing


            Call hms_helper.Fill_Investment_Banks(Cmb_1, "< Select >")
            Cmb_1.SelectedIndex = 0
            Lbl_Cmb1.Text = "Investment Banks"
            Pnl_Cmb_2.Visible = True

            Call hms_helper.Fill_GenData(Cmb_2, Gendatatype.BankAccount_Type, "< Select >")
            Cmb_2.SelectedIndex = 0
            Lbl_Cmb2.Text = "Account Type"

        Catch ex As Exception

        End Try

    End Sub

    Private Sub Show_Report(ByVal Rpt_ID As String)
        Try
            Select Case Rpt_ID

                Case 1

                Case 2
                    Call Show_GenCategory_Rpt()
                Case 3
                    Call Show_OutPatient_Details_Rpt()
                Case 4
                    Call Show_General_Reciept_Sub_Rpt()
                Case 5

                Case 6

                Case 7
                    Call Show_General_Sub_Rpt()
                Case 8
                    Call Show_Doctor_Details_Rpt()
                Case 9
                    Call Show_Specialisations_Details()
                Case 10
                    Call Get_Servicemaster_Details()
                Case 11
                    Call Get_Diagnosis_Details()
                Case 12
                    Call Get_Account_Master_Details()
                Case 13
                    Call Show_Patient_Daignosis()
                Case 14
                    Call Show_ExpMaster_Details()
                Case 15
                    Call Show_Expense_Charge()
                Case 16
                    Call Show_Patient_Bill()
                Case 17
                    Call Show_Employee_Details_Rpt()
                Case 18
                    Call Show_Doctor_Dutytimings_Rpt()
                Case 19
                    Call Show_Doctor_LeaveRegister_Rpt()
                Case 20
                    Call Show_IPReg_Details_Rpt()
                Case 21
                    Call Show_Patient_Bill_Summary()
                Case 22
                    Call Show_DoctorWise_OPCollection_Rpt()
                Case 23
                    Call Show_PatientWise_Pendingbills_Rpt()
                Case 24
                    Call Show_DoctorWise_OPCollection_Detailed_Rpt()
                Case 25
                    Call Show_General_Payment_Sub_Rpt()
                Case 26
                    Call Show_Bank_Tran_Ledger_Rpt()
                Case 27
                    Call Show_Employee_Acc_Ledger_Rpt()
                Case 28
                    Call Show_Bank_Outstanding_Rpt()
                Case 29
                    Call Show_Employee_Outstanding_Rpt()
                Case 30
                    Call Show_Patient_Deposit_Ledger_Rpt()
                Case 31
                    Call Show_Patient_Discharge_Rpt()
                Case Else

            End Select
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Show_GenCategory_Rpt()
        Try
            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Show_GenCategory(Rpt_Ds) Then
                If Not Isrecordexistsindataset(Rpt_Ds) Then
                    MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
                Report_Heading = "|Heading| General Category Details as on - " & Format(Tran_Date, "dd/MM/yyyy")
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading
                ' mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", , )
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Show_General_Sub_Rpt()
        Try
            Add_Query = ""
            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Get_General_Sub_Details(Rpt_Ds, Dtp_1.Value, Dtp_2.Value, IIf(Cmb_1.SelectedIndex = 0, "", Cmb_1.Text), Branch_Code, Add_Query) Then
                If Not Isrecordexistsindataset(Rpt_Ds) Then
                    MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If


                Report_Heading = "|Heading| Reciepts and Payments Between - " & Format(Dtp_1.Value, "dd/MM/yyyy") & " To " & Format(Dtp_2.Value, "dd/MM/yyyy")
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Show_Patient_Discharge_Rpt()
        Try
            Add_Query = ""
            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Show_Discharge_Details(Rpt_Ds, Add_Query) Then
                Report_Heading = "|Heading| Patient Discharge Details Between - " & Format(Dtp_1.Value, "dd/MM/yyyy") & " To " & Format(Dtp_2.Value, "dd/MM/yyyy")
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Show_General_Reciept_Sub_Rpt()
        Try
            Add_Query = ""
            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Get_General_Sub_Details(Rpt_Ds, Dtp_1.Value, Dtp_2.Value, IIf(Cmb_1.SelectedIndex = 0, "", Cmb_1.Text), Branch_Code, Add_Query) Then
                ''If Not Isrecordexistsindataset(Rpt_Ds) Then
                ''    MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                ''    Exit Sub
                ''End If


                Report_Heading = "|Heading| General Reciept Subsidary Between - " & Format(Dtp_1.Value, "dd/MM/yyyy") & " To " & Format(Dtp_2.Value, "dd/MM/yyyy")
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Show_General_Payment_Sub_Rpt()
        Try
            Add_Query = ""
            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Get_General_Sub_Details(Rpt_Ds, Dtp_1.Value, Dtp_2.Value, IIf(Cmb_1.SelectedIndex = 0, "", Cmb_1.Text), Branch_Code, Add_Query) Then
                ''If Not Isrecordexistsindataset(Rpt_Ds) Then
                ''    MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                ''    Exit Sub
                ''End If


                Report_Heading = "|Heading| General Payment Subsidary  Between - " & Format(Dtp_1.Value, "dd/MM/yyyy") & " To " & Format(Dtp_2.Value, "dd/MM/yyyy")
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Show_Doctor_Details_Rpt()
        Try
            Add_Query = ""
            If Pnl_Cmb_1.Visible And Cmb_1.SelectedIndex > 0 Then
                Add_Query = "Where [Doc_Category] = " & Cmb_1.SelectedValue & " "
            End If

            If Pnl_Dtp_1.Visible Then
                If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and [Emp_Admitdate] >= '" & Format(Dtp_1.Value, "MM/dd/yyyy") & " 'and [Emp_Admitdate] <=' " & Format(Dtp_2.Value, "MM/dd/yyyy") & "' "
                If Len(Add_Query) = 0 Then Add_Query = "Where [Emp_Admitdate] >= '" & Format(Dtp_1.Value, "MM/dd/yyyy") & "'  and [Emp_Admitdate] <= '" & Format(Dtp_2.Value, "MM/dd/yyyy") & "' "
            End If
            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Ger_Doctor_Details(Rpt_Ds, Add_Query) Then
                If Not Isrecordexistsindataset(Rpt_Ds) Then
                    MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
                Report_Heading = "|Heading| Doctor Details - " & Format(Dtp_1.Value, "dd/MM/yyyy") & " and " & Format(Dtp_2.Value, "dd/MM/yyyy")
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Show_Employee_Details_Rpt()
        Try
            Add_Query = ""
            If Pnl_Cmb_1.Visible And Cmb_1.SelectedIndex > 0 Then
                Add_Query = "Where [Emp_Category] = " & Cmb_1.SelectedValue & "  and Br_Code=" & Branch_Code & " "
            End If

            If Pnl_Cmb_2.Visible And Cmb_2.Text <> "     <       ALL     >   " Then
                If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and [Emp_Gender] = '" & Cmb_2.Text & " ' "
                If Len(Add_Query) = 0 Then Add_Query = "Where [Emp_Gender] = '" & Cmb_2.Text & "'"
            End If

            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Get_Employee_Details(Rpt_Ds, Add_Query) Then
                If Not Isrecordexistsindataset(Rpt_Ds) Then
                    MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
                Report_Heading = "|Heading| Employee Details - " & Format(Dtp_1.Value, "dd/MM/yyyy") & " and " & Format(Dtp_2.Value, "dd/MM/yyyy")
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Show_Doctor_Dutytimings_Rpt()
        Try

            Add_Query = ""

            If Pnl_Cmb_1.Visible And Cmb_1.SelectedIndex > 0 Then
                Add_Query = "Where [Doctor] = '" & Cmb_1.Text & "'  and Br_Code=" & Branch_Code & " "
            End If


            If Pnl_Dtp_1.Visible And DateValue(Dtp_1.Value) <> DateValue(Tran_Date) Then
                If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and Reg_Date >= '" & Format(Dtp_1.Value, "MM/dd/yyyy") & " 'and [Reg_Date] <=' " & Format(Dtp_2.Value, "MM/dd/yyyy") & "' "
                If Len(Add_Query) = 0 Then Add_Query = "Where Reg_Date >= '" & Format(Dtp_1.Value, "MM/dd/yyyy") & "'  and Reg_Date <= '" & Format(Dtp_2.Value, "MM/dd/yyyy") & "' "
            Else
                If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and Reg_Date =(Select max(Reg_Date) from   Doc_DutyTimings_Vw where  Reg_Date <= '" & Format(Dtp_1.Value, "MM/dd/yyyy") & "') "
                If Len(Add_Query) = 0 Then Add_Query = "Where Reg_Date =(Select max(Reg_Date) from   Doc_DutyTimings_Vw  where  Reg_Date <= '" & Format(Dtp_1.Value, "MM/dd/yyyy") & "') "
            End If

            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Get_Doctors_Dutytimings_Details(Rpt_Ds, Add_Query) Then
                If Not Isrecordexistsindataset(Rpt_Ds) Then
                    MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
                Report_Heading = "|Heading| Doctor Duty Timings - " & Format(Dtp_1.Value, "dd/MM/yyyy") & " and " & Format(Dtp_2.Value, "dd/MM/yyyy")
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Show_DoctorWise_OPCollection_Rpt()
        Try

            Add_Query = ""

            If Pnl_Cmb_1.Visible And Cmb_1.SelectedIndex > 0 Then
                Add_Query = "Where [Doc_ID] = '" & Cmb_1.SelectedValue & "'  "
            End If
            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Get_Docotor_Wise_OPCollection(Rpt_Ds, Dtp_1.Value, Dtp_2.Value, Branch_Code, Add_Query) Then
                If Not Isrecordexistsindataset(Rpt_Ds) Then
                    MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
                Report_Heading = "|Heading| Doctor Wise Outpatient Collection Between- " & Format(Dtp_1.Value, "dd/MM/yyyy") & " To " & Format(Dtp_2.Value, "dd/MM/yyyy")
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Show_DoctorWise_OPCollection_Detailed_Rpt()
        Try
            Add_Query = ""

            If Pnl_Cmb_1.Visible And Cmb_1.SelectedIndex > 0 Then
                Add_Query = "Where [Doc_ID] = '" & Cmb_1.SelectedValue & "'  "
            End If

            If Pnl_Cmb_2.Visible And Cmb_2.SelectedIndex > 0 Then
                If Len(Add_Query) > 0 Then Add_Query = Add_Query + "And [ExpenseSubTypeName] = '" & Cmb_2.Text & "'  "
                If Len(Add_Query) = 0 Then Add_Query = "Where [ExpenseSubTypeName] = '" & Cmb_2.Text & "'  "
            End If

            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Get_Docotor_Wise_OPCollection(Rpt_Ds, Dtp_1.Value, Dtp_2.Value, Branch_Code, Add_Query) Then
                If Not Isrecordexistsindataset(Rpt_Ds) Then
                    MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
                Report_Heading = "|Heading| Doctor Wise Collection Between- " & Format(Dtp_1.Value, "dd/MM/yyyy") & " To " & Format(Dtp_2.Value, "dd/MM/yyyy")
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Show_Doctor_LeaveRegister_Rpt()
        Try

            Add_Query = ""

            If Pnl_Cmb_1.Visible And Cmb_1.SelectedIndex > 0 Then
                Add_Query = "Where [Doctor] = '" & Cmb_1.Text & "'  "
            End If

            If Pnl_Cmb_2.Visible Then
                If Cmb_2.SelectedIndex > 0 Then
                    If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and  [Leave_Type] = '" & Cmb_2.SelectedValue & "'  "
                    If Len(Add_Query) = 0 Then Add_Query = "Where [Leave_Type] = '" & Cmb_2.SelectedValue & "'  "
                End If
            End If

            If Pnl_Dtp_1.Visible Then
                If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and Leave_Date >= '" & Format(Dtp_1.Value, "MM/dd/yyyy") & " 'and [Leave_Date] <=' " & Format(Dtp_2.Value, "MM/dd/yyyy") & "' "
                If Len(Add_Query) = 0 Then Add_Query = "Where Leave_Date >= '" & Format(Dtp_1.Value, "MM/dd/yyyy") & "'  and Leave_Date <= '" & Format(Dtp_2.Value, "MM/dd/yyyy") & "' "
            End If

            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Get_Docotor_LeaveRegister(Rpt_Ds, Add_Query) Then
                If Not Isrecordexistsindataset(Rpt_Ds) Then
                    MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
                Report_Heading = "|Heading| Doctor Leave Register - " & Format(Dtp_1.Value, "dd/MM/yyyy") & " and " & Format(Dtp_2.Value, "dd/MM/yyyy")
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Show_Specialisations_Details()
        Try

            Add_Query = ""
            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Get_Specialisations_Details(Rpt_Ds, Add_Query) Then
                If Not Isrecordexistsindataset(Rpt_Ds) Then
                    MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
                Report_Heading = "|Heading| S p e c i a l i s a t i o n s   D e t a i l s "
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Get_Servicemaster_Details()
        Try

            Add_Query = ""
            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Get_Servicemaster_Details(Rpt_Ds, Add_Query) Then
                If Not Isrecordexistsindataset(Rpt_Ds) Then
                    MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
                Report_Heading = "|Heading| S e r v i c e s   D e t a i l s "
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Get_Diagnosis_Details()
        Try

            Add_Query = ""
            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Get_Diagnosis_Details(Rpt_Ds, Add_Query) Then
                If Not Isrecordexistsindataset(Rpt_Ds) Then
                    MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
                Report_Heading = "|Heading| D i a g o n i s i s   D e t a i l s "
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Show_ExpMaster_Details()
        Try

            Add_Query = ""
            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Get_ExpMaste_Details(Rpt_Ds, Add_Query) Then
                If Not Isrecordexistsindataset(Rpt_Ds) Then
                    MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
                Report_Heading = "|Heading| E x p e n s e   M a s t e r  D e t a i l s "
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Show_Expense_Charge()
        Try

            Add_Query = ""
            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Get_Expense_Charge(Rpt_Ds, Tran_Date, Branch_Code, Add_Query) Then
                If Not Isrecordexistsindataset(Rpt_Ds) Then
                    MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
                Report_Heading = "|Heading| E x p e n s e   C h a r g e  D e t a i l s"
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Show_Patient_Bill()
        Try

            Add_Query = ""

            If Pnl_Text_1.Visible And Len(Txt_Box1.Text) > 0 Then
                Add_Query = "Where [Acc_ID] = " & Txt_Box1.Text & " "
            Else
                MessageBox.Show("Invalid Outpatient ID, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_Box1.Focus()
                Exit Sub
            End If

            If Pnl_Cmb_1.Visible And Cmb_1.Text <> "     <       ALL     >   " Then
                If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and [Bill_Status] = '" & Strings.Left(Cmb_1.Text, 1) & " ' "
                If Len(Add_Query) = 0 Then Add_Query = "Where [Bill_Status] = '" & Strings.Left(Cmb_1.Text, 1) & "'"
            End If

            If Pnl_Cmb_2.Visible And Cmb_2.Text <> "     <       ALL     >   " Then
                If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and [Exp_ID] = '" & Cmb_2.SelectedValue & " ' "
                If Len(Add_Query) = 0 Then Add_Query = "Where [Exp_ID] = '" & Cmb_2.SelectedValue & "'"
            End If

            If Pnl_Dtp_1.Visible Then
                If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and Tr_Date >= '" & Format(Dtp_1.Value, "MM/dd/yyyy") & " 'and [Tr_Date] <=' " & Format(Dtp_2.Value, "MM/dd/yyyy") & "' "
                If Len(Add_Query) = 0 Then Add_Query = "Where Tr_Date >= '" & Format(Dtp_1.Value, "MM/dd/yyyy") & "'  and Tr_Date <= '" & Format(Dtp_2.Value, "MM/dd/yyyy") & "' "
            End If


            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Ger_Patient_Bill(Rpt_Ds, Add_Query) Then
                If Not Isrecordexistsindataset(Rpt_Ds) Then
                    MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
                Report_Heading = "|Heading| P a t i e n t   B i l l  D e t a i l s"
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Get_Account_Master_Details()
        Try

            Add_Query = ""
            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Get_Account_Master_Details(Rpt_Ds, Add_Query) Then
                If Not Isrecordexistsindataset(Rpt_Ds) Then
                    MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
                Report_Heading = "|Heading| A c c o u n t   M a s t e r   D e t a i l s "
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Show_Patient_Daignosis()
        Try
            Add_Query = ""

            If Pnl_Cmb_1.Visible And Cmb_1.SelectedIndex > 0 Then
                Add_Query = "Where [Dig_Doc_ID] = " & Cmb_1.SelectedValue & " "
            End If


            If Pnl_Text_1.Visible And Len(Txt_Box1.Text) > 0 Then
                If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and Where [OPD_ID] = " & Txt_Box1.Text.Trim & " "
                If Len(Add_Query) = 0 Then Add_Query = "Where [OPD_ID] = " & Txt_Box1.Text.Trim & " "
            End If

            If Pnl_Text_2.Visible And Len(Txt_Box2.Text) > 0 Then
                If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and  [Patient ID] = " & Txt_Box2.Text.Trim & " "
                If Len(Add_Query) = 0 Then Add_Query = "Where [Patient ID] = " & Txt_Box2.Text.Trim & " "
            End If


            If Pnl_Dtp_1.Visible Then
                If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and Tr_Date >= '" & Format(Dtp_1.Value, "MM/dd/yyyy") & " 'and [Tr_Date] <=' " & Format(Dtp_2.Value, "MM/dd/yyyy") & "' "
                If Len(Add_Query) = 0 Then Add_Query = "Where Tr_Date >= '" & Format(Dtp_1.Value, "MM/dd/yyyy") & "'  and Tr_Date <= '" & Format(Dtp_2.Value, "MM/dd/yyyy") & "' "
            End If


            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Get_Patient_Diagnosis(Rpt_Ds, Add_Query) Then
                If Not Isrecordexistsindataset(Rpt_Ds) Then
                    MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
                Report_Heading = "|Heading| Patient Diagnosis between - " & Format(Dtp_1.Value, "dd/MM/yyyy") & " and " & Format(Dtp_2.Value, "dd/MM/yyyy")
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Show_PatientWise_Pendingbills_Rpt()
        Try
            Add_Query = ""

            If Pnl_Text_1.Visible And Len(Txt_Box1.Text) > 0 Then
                If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and Where [Acc_ID] = " & Txt_Box1.Text.Trim & " "
                If Len(Add_Query) = 0 Then Add_Query = "Where [Acc_ID] = " & Txt_Box1.Text.Trim & " "
            End If


            If Pnl_Dtp_1.Visible Then
                If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and Tr_Date >= '" & Format(Dtp_1.Value, "MM/dd/yyyy") & " 'and [Tr_Date] <=' " & Format(Dtp_2.Value, "MM/dd/yyyy") & "' "
                If Len(Add_Query) = 0 Then Add_Query = "Where Tr_Date >= '" & Format(Dtp_1.Value, "MM/dd/yyyy") & "'  and Tr_Date <= '" & Format(Dtp_2.Value, "MM/dd/yyyy") & "' "
            End If

            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Get_Patientwise_Pendingbills(Rpt_Ds, Add_Query) Then
                If Not Isrecordexistsindataset(Rpt_Ds) Then
                    MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
                Report_Heading = "|Heading| Patient wise pending  - " & Format(Dtp_1.Value, "dd/MM/yyyy") & " and " & Format(Dtp_2.Value, "dd/MM/yyyy")
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Show_OutPatient_Details_Rpt()
        Try

            Add_Query = ""

            If Pnl_Cmb_1.Visible And Cmb_1.SelectedIndex > 0 Then
                Add_Query = "Where [Doc_ID] = " & Cmb_1.SelectedValue & " "
            End If


            If Pnl_Text_1.Visible And Len(Txt_Box1.Text) > 0 Then
                If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and Where [Acc_ID] = " & Txt_Box1.Text.Trim & " "
                If Len(Add_Query) = 0 Then Add_Query = "Where [Acc_ID] = " & Txt_Box1.Text.Trim & " "
            End If

            If Pnl_Text_2.Visible And Len(Txt_Box2.Text) > 0 Then
                If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and  [Patient ID] = " & Txt_Box2.Text.Trim & " "
                If Len(Add_Query) = 0 Then Add_Query = "Where [Patient ID] = " & Txt_Box2.Text.Trim & " "
            End If


            If Pnl_Cmb_2.Visible And Cmb_2.SelectedIndex > 0 Then
                If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and  [Service ID] = " & Cmb_2.SelectedValue & " "
                If Len(Add_Query) = 0 Then Add_Query = "Where [Service ID] = " & Cmb_2.SelectedValue & " "
            End If


            If Pnl_Dtp_1.Visible Then
                If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and [Tran Date] >= '" & Format(Dtp_1.Value, "MM/dd/yyyy") & " 'and [Tran Date] <=' " & Format(Dtp_2.Value, "MM/dd/yyyy") & "' "
                If Len(Add_Query) = 0 Then Add_Query = "Where [Tran Date] >= '" & Format(Dtp_1.Value, "MM/dd/yyyy") & "'  and [Tran Date] <= '" & Format(Dtp_2.Value, "MM/dd/yyyy") & "' "
            End If

            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Get_OutPatient_Details(Rpt_Ds, Add_Query) Then
                If Not Isrecordexistsindataset(Rpt_Ds) Then
                    MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
                Report_Heading = "|Heading| Outpatient Details Between - " & Format(Dtp_1.Value, "dd/MM/yyyy") & " and " & Format(Dtp_2.Value, "dd/MM/yyyy")
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Show_IPReg_Details_Rpt()
        Try

            Add_Query = ""

            If Pnl_Cmb_1.Visible And Cmb_1.SelectedIndex > 0 Then
                Add_Query = "Where [Doctor_Incharge] = " & Cmb_1.SelectedValue & " "
            End If


            If Pnl_Text_1.Visible And Len(Txt_Box1.Text) > 0 Then
                If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and Where [OPD_ID] = " & Txt_Box1.Text.Trim & " "
                If Len(Add_Query) = 0 Then Add_Query = "Where [OPD_ID] = " & Txt_Box1.Text.Trim & " "
            End If

            If Pnl_Text_2.Visible And Len(Txt_Box2.Text) > 0 Then
                If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and  [Patient ID] = " & Txt_Box2.Text.Trim & " "
                If Len(Add_Query) = 0 Then Add_Query = "Where [Patient ID] = " & Txt_Box2.Text.Trim & " "
            End If


            If Pnl_Cmb_2.Visible And Cmb_2.SelectedIndex > 0 Then
                If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and  Service_ID = " & Cmb_2.SelectedValue & " "
                If Len(Add_Query) = 0 Then Add_Query = "Where Service_ID = " & Cmb_2.SelectedValue & " "
            End If

            If Pnl_Cmb_3.Visible And Cmb_3.SelectedIndex > 0 Then
                If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and  [Dep_ID] = " & Cmb_3.SelectedValue & " "
                If Len(Add_Query) = 0 Then Add_Query = "Where [Dep_ID] = " & Cmb_3.SelectedValue & " "
            End If

            If Pnl_Dtp_1.Visible Then
                If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and Tr_Date >= '" & Format(Dtp_1.Value, "MM/dd/yyyy") & " 'and Tr_Date <=' " & Format(Dtp_2.Value, "MM/dd/yyyy") & "' "
                If Len(Add_Query) = 0 Then Add_Query = "Where Tr_Date >= '" & Format(Dtp_1.Value, "MM/dd/yyyy") & "'  and Tr_Date <= '" & Format(Dtp_2.Value, "MM/dd/yyyy") & "' "
            End If
            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Get_IPReg_Details(Rpt_Ds, Add_Query) Then
                If Not Isrecordexistsindataset(Rpt_Ds) Then
                    MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
                Report_Heading = "|Heading| In-patient Details Between - " & Format(Dtp_1.Value, "dd/MM/yyyy") & " and " & Format(Dtp_2.Value, "dd/MM/yyyy")
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Show_Accountheaddetails_Rpt()
        Add_Query = ""
        If Pnl_Cmb_1.Visible And Cmb_1.SelectedIndex > 0 Then
            Add_Query = "Where Grp_ID = " & Cmb_1.SelectedValue & ""
        End If
        ''If Rpt_BL.Get_Accountheaddetails(Rpt_Ds, Add_Query) Then
        ''    If Not Isrecordexistsindataset(Rpt_Ds) Then
        ''        MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        ''        Exit Sub
        ''    End If
        ''    Report_Heading = "|Heading| Account Head Details as on - " & Format(Tran_Date, "dd/MM/yyyy")
        ''    Rpt_Formulafields = Rpt_Formulafields & Report_Heading
        ''    mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", , )
        ''End If

    End Sub

    Private Sub Show_Patient_Bill_Summary()
        Try
            Add_Query = ""
            If Txt_Box1.Text = "" Then MessageBox.Show("Invalid OutPatient ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Exit Sub
            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Show_Patient_Bill_Summary(Rpt_Ds, Add_Query) Then
                If Not Isrecordexistsindataset(Rpt_Ds) Then
                    MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
                Report_Heading = "|Heading| Patient Bill Summary between - " & Format(Dtp_1.Value, "dd/MM/yyyy") & " and " & Format(Dtp_2.Value, "dd/MM/yyyy ")
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Show_Patient_Deposit_Ledger_Rpt()
        Try
            Add_Query = ""
            If Txt_Box1.Text = "" Then MessageBox.Show("Invalid PMRID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Exit Sub

            If Pnl_Text_1.Visible And Len(Txt_Box1.Text) > 0 Then
                If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and Where [Account ID] = " & Txt_Box1.Text.Trim & " "
                If Len(Add_Query) = 0 Then Add_Query = "Where [Account ID] = " & Txt_Box1.Text.Trim & " "
            End If


            If Pnl_Dtp_1.Visible Then
                If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and [Tran Date] >= '" & Format(Dtp_1.Value, "MM/dd/yyyy") & " 'and [Tran Date] <=' " & Format(Dtp_2.Value, "MM/dd/yyyy") & "' "
                If Len(Add_Query) = 0 Then Add_Query = "Where [Tr Date] >= '" & Format(Dtp_1.Value, "MM/dd/yyyy") & "'  and [Tran Date] <= '" & Format(Dtp_2.Value, "MM/dd/yyyy") & "' "
            End If

            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Show_Patient_Deposit_Ledger(Rpt_Ds, Add_Query) Then
                If Not Isrecordexistsindataset(Rpt_Ds) Then
                    MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
                Report_Heading = "|Heading| Patient Deposit Ledger between - " & Format(Dtp_1.Value, "dd/MM/yyyy") & " and " & Format(Dtp_2.Value, "dd/MM/yyyy")
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Show_Bank_Tran_Ledger_Rpt()
        Try

            Add_Query = ""

            If Pnl_Cmb_1.Visible And Cmb_1.SelectedIndex > 0 Then
                Add_Query = "Where [Bank_ID] = " & Cmb_1.SelectedValue & " "
            End If



            If Pnl_Cmb_2.Visible And Cmb_2.SelectedIndex > 0 Then
                If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and  [Acc_Type] = " & Cmb_2.SelectedValue & " "
                If Len(Add_Query) = 0 Then Add_Query = "Where [Acc_Type] = " & Cmb_2.SelectedValue & " "
            End If

            If Pnl_Cmb_3.Visible And Cmb_3.SelectedIndex > 0 Then
                If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and  [Acc No] = " & Cmb_3.Text & " "
                If Len(Add_Query) = 0 Then Add_Query = "Where [Acc No] = " & Cmb_3.Text & " "
            End If

            If Pnl_Dtp_1.Visible Then
                If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and [Date] >= '" & Format(Dtp_1.Value, "MM/dd/yyyy") & " 'and [Date] <=' " & Format(Dtp_2.Value, "MM/dd/yyyy") & "' "
                If Len(Add_Query) = 0 Then Add_Query = "Where [Date] >= '" & Format(Dtp_1.Value, "MM/dd/yyyy") & "'  and [Date] <= '" & Format(Dtp_2.Value, "MM/dd/yyyy") & "' "
            End If

            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Get_Bank_Account_Transaction_All(Rpt_Ds, Add_Query) Then
                If Not Isrecordexistsindataset(Rpt_Ds) Then
                    MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
                Report_Heading = "|Heading| Bank Account Transaction Between - " & Format(Dtp_1.Value, "dd/MM/yyyy") & " and " & Format(Dtp_2.Value, "dd/MM/yyyy")
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Show_Bank_Outstanding_Rpt()
        Try

            Add_Query = ""

            If Pnl_Cmb_1.Visible And Cmb_1.SelectedIndex > 0 Then
                Add_Query = "Where [Bank_ID] = '" & Cmb_1.SelectedValue & "' "
            End If

            If Pnl_Cmb_2.Visible And Cmb_2.SelectedIndex > 0 Then
                If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and  [Acc_Type] = '" & Cmb_2.Text & "' "
                If Len(Add_Query) = 0 Then Add_Query = "Where [Acc_Type] = '" & Cmb_2.Text & "' "
            End If

            If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and  Outstand > 0 "
            If Len(Add_Query) = 0 Then Add_Query = "Where Outstand > 0 "

            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Show_Investment_Outstanding(Rpt_Ds, Add_Query) Then
                If Not Isrecordexistsindataset(Rpt_Ds) Then
                    MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
                Report_Heading = "|Heading| Bank Account Outstanding as on - " & Format(Dtp_1.Value, "dd/MM/yyyy") & ""
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading

                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Show_Employee_Acc_Ledger_Rpt()
        Try
            hms_helper = New Hms_Helperimpliments
            Add_Query = ""

            If Pnl_Cmb_1.Visible And Cmb_1.SelectedIndex > 0 Then
                Add_Query = "Where [Acc_No] = '" & Cmb_1.SelectedValue & "' and Br_Code='" & Branch_Code & "' "
            End If

            If Pnl_Dtp_1.Visible Then
                If Len(Add_Query) > 0 Then Add_Query = Add_Query + " and [Date] >= '" & Format(Dtp_1.Value, "MM/dd/yyyy") & " 'and [Date] <=' " & Format(Dtp_2.Value, "MM/dd/yyyy") & "' "
                If Len(Add_Query) = 0 Then Add_Query = "Where [Date] >= '" & Format(Dtp_1.Value, "MM/dd/yyyy") & "'  and [Date] <= '" & Format(Dtp_2.Value, "MM/dd/yyyy") & "' "
            End If
            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If hms_helper.Get_Emp_Account_Ledger(Rpt_Ds, Add_Query) Then
                If Not Isrecordexistsindataset(Rpt_Ds) Then
                    MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
                Report_Heading = "|Heading| Employee Account Transaction Between - " & Format(Dtp_1.Value, "dd/MM/yyyy") & " and " & Format(Dtp_2.Value, "dd/MM/yyyy")
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Show_Employee_Outstanding_Rpt()
        Try
            Add_Query = ""

            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Show_Emp_Account_Outstanding(Rpt_Ds, Add_Query) Then
                If Not Isrecordexistsindataset(Rpt_Ds) Then
                    MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
                Report_Heading = "|Heading| Employee Account Outstanding as On - " & Format(Dtp_1.Value, "dd/MM/yyyy") & ""
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Report_Process(ByVal Rpt_ID As String)
        Try

            Select Case Rpt_ID
                Case 28
                    Call Process_Investment_Outstanding()
                Case 29
                    Call Process_Emp_Accounts_Outstanding()
                Case 21
                    Call Process_Patient_Bill_Summery()
                Case Else
            End Select

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Process_Investment_Outstanding()
        Try
            Dim Dtbl As DataTable = Nothing
            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Process_Investment_Outstanding(Dtbl, Dtp_1.Value) Then
                If Not Isrecordexistsindatatable(Dtbl) Then
                    MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
                MessageBox.Show("Process Completed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Btn_Show.Focus()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Process_Emp_Accounts_Outstanding()
        Try
            Dim Dtbl As DataTable = Nothing
            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Process_Emp_Account_Outstanding(Dtbl, Dtp_1.Value) Then
                If Not Isrecordexistsindatatable(Dtbl) Then
                    MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
                MessageBox.Show("Process Completed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Btn_Show.Focus()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Searchfield(ByRef Searchctrl As TextBox, ByVal Search_Item As String)
        Try
            Dim dtbl As DataTable = Nothing
            Select Case Search_Item
                Case "OP_ID"
                    If Searchctrl.Text.Trim = "" Then
                        Dim Sql As String
                        Dim Colwidth As String = ""
                        'Colwidth = "100|200|5|5|50|10|"
                        ' Sql = "SELECT   *  FROM    OPD_Master_Vw where Active='Y' and Br_Code='" & Branch_Code & "'"                      
                        Colwidth = "200|50|200|150|"
                        Sql = "SELECT [Patient Name], [S.S.No], ([Family Name] + Address + City) as Address, ACC_ID AS [PMR-ID]"
                        Sql += "FROM Patient_Account_Vw WHERE ([Account Status] = 'Active')"
                        Call ShowSearchengine(Searchctrl, Sql, 3, "[Patient Name]", Colwidth, , 0)
                        hms_helper = New Hms_Helperimpliments
                        If hms_helper.Get_PatientID(dtbl, Searchctrl.Text.Trim, Branch_Code) Then
                            Txt_Box2.Text = dtbl.Rows(0).Item(0).ToString
                        End If
                    End If
                Case "P_ID"
                    If Searchctrl.Text.Trim = "" Then
                        Dim Sql As String
                        Dim Colwidth As String = ""
                        Colwidth = "100|200|5|5|50|10|"
                        Sql = "SELECT     [Patient ID], [Patient Name], Doctor, Service, Department,OPD_ID FROM   OPD_Master_Vw where Active='Y' and Br_Code='" & Branch_Code & "'"
                        Call ShowSearchengine(Searchctrl, Sql, 0, "[Patient Name]", Colwidth, , 0)
                    End If
                Case Else
            End Select
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Process_Patient_Bill_Summery()
        Try
            Dim Dtbl As DataTable = Nothing
            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Process_Patient_Bill_Summary(Dtbl, Txt_Box1.Text, Dtp_1.Value, Dtp_2.Value, Branch_Code) Then
                If Not Isrecordexistsindatatable(Dtbl) Then
                    MessageBox.Show("No Records Found,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
                MessageBox.Show("Process Completed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Btn_Show.Focus()
            End If
        Catch ex As Exception

        End Try
    End Sub

#End Region

End Class

