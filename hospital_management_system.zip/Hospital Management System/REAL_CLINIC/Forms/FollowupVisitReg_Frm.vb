﻿

Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls
Public Class FollowupVisitReg_Frm

#Region " D e c l a r a t i o n s "

    Private hms_helper As HMS_Helper = Nothing
    Private OP_BL As OutPatient_BL_Cls
    Private Apoint_Bl As Appointment_BL_Cls


    Dim frm_Heading As String = String.Empty



    Dim Service_Dtbl As DataTable = Nothing
    Dim doc_Dtbl As DataTable = Nothing


    Private Ctrl_Point As Point
    Private mReq_Ctrl As Object = Nothing

#End Region

#Region " E n u m s "

    Public Enum enm_Visitor_Type
        New_Visitor
        Pre_Visitor
        Employee
    End Enum

#End Region

#Region " P r o p e r t i e s "

    'Transaction Mode checking Property
    Private mTr_Mode As Tran_Mode = Tran_Mode.New_Mode
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    'Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_OPID.BackColor = Color.White
                    Me.Txt_OPID.ReadOnly = False
                Case Tran_Mode.Edit_Mode
                    'Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_OPID.BackColor = Color.Silver
                    Me.Txt_OPID.ReadOnly = True
            End Select
        End Set
    End Property

    'Appointment Service Property
    Private _OP_Service_ID As Integer = 0
    Private Property OP_Service_ID() As Integer
        Get
            Return _OP_Service_ID
        End Get
        Set(ByVal value As Integer)
            _OP_Service_ID = value

            If _OP_Service_ID = 0 Then Exit Property

            Call Populate_Doctorlist(_OP_Service_ID)

        End Set
    End Property

    Private _Seldoctor_ID As Integer = 0
    Public Property Seldoctor_ID() As Integer
        Get
            Return _Seldoctor_ID
        End Get
        Set(ByVal value As Integer)
            _Seldoctor_ID = value
            If value = 0 Then
                Pnl_1.Enabled = False
                Pnl_2.Enabled = False
                Pnl_3.Enabled = False
                Return
            Else
                Pnl_1.Enabled = True
                Pnl_2.Enabled = True
                Pnl_3.Enabled = True
            End If

            Call Get_Doctordetails(value)
        End Set
    End Property

    Private _App_Doctor_name As String
    Public Property App_Doctor_Name() As String
        Get
            Return _App_Doctor_name
        End Get
        Set(ByVal value As String)
            _App_Doctor_name = value
            Lbl_Heading.Text = frm_Heading
            If Not value = String.Empty Then Lbl_Heading.Text = frm_Heading + "  of  " + value
        End Set
    End Property

    
    Private _RegExpID As Integer = 1
    Private Property RegExpID() As Integer
        Get
            Return _RegExpID
        End Get
        Set(ByVal value As Integer)
            _RegExpID = value
        End Set
    End Property

    Private _Tran_BatchID As String = String.Empty
    Private Property Tran_BatchID() As String
        Get
            Return _Tran_BatchID
        End Get
        Set(ByVal value As String)
            _Tran_BatchID = value
        End Set
    End Property

    Private _Tran_RefNo As String = "OP"
    Private Property Tran_RefNo() As String
        Get
            Return _Tran_RefNo
        End Get
        Set(ByVal value As String)
            _Tran_RefNo = value
        End Set
    End Property

    Private _BK_TranID As String = "0"
    Private Property BK_TranID() As String
        Get
            Return _BK_TranID
        End Get
        Set(ByVal value As String)
            _BK_TranID = value
        End Set
    End Property

    Private _IsValid_OP As Boolean = False
    Private Property IsValid_OP() As Boolean
        Get
            Return _IsValid_OP
        End Get
        Set(ByVal value As Boolean)
            _IsValid_OP = value
        End Set
    End Property

#End Region

#Region " M e t h o d s "

    Public Sub Initialiseform()
        Try
            hms_helper = New Hms_Helperimpliments

            frm_Heading = Lbl_Heading.Text

            'Populating Combo box
            Call hms_helper.Fill_ApointmentServices(Cmb_Service)
            'Just Changed the index to Populate Doctor List
            If Cmb_Service.Items.Count > 0 Then
                Cmb_Service.SelectedIndex = -1
                Cmb_Service.SelectedIndex = 0
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Function Populate_Doctorlist(ByVal ServiceID As Integer) As Boolean
        Try

            Dim btnSomething As ToolStripButton
            Dim doc_Dtbl As DataTable = Nothing

            TlStrp_Doctors.Items.Clear()

            If hms_helper.Get_Doctorswithservices(doc_Dtbl, ServiceID, Tran_Date, Branch_Code) Then

                For i = 0 To doc_Dtbl.Rows.Count - 1
                    btnSomething = New ToolStripButton
                    With btnSomething
                        .Text = doc_Dtbl.Rows(i).Item("Name").ToString
                        .Tag = doc_Dtbl.Rows(i).Item("DoctorID").ToString
                        .Image = My.Resources.Health_care_shield_32
                        .ImageAlign = ContentAlignment.TopCenter
                        .ImageScaling = ToolStripItemImageScaling.None
                        .ForeColor = Color.Maroon
                        .DisplayStyle = ToolStripItemDisplayStyle.ImageAndText
                        .TextImageRelation = TextImageRelation.ImageAboveText
                    End With
                    TlStrp_Doctors.Items.Add(btnSomething)
                Next

            End If
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Clear_Patientinfo()
        Try
            With Me
                .Lbl_MesageTokenno.Text = String.Empty
                .Lbl_Mesageaproxtime.Text = String.Empty
                .Txt_PatientID.Text = String.Empty
                .Txt_Visitor_SSNO.Text = String.Empty
                .Txt_Visitor_Name.Text = String.Empty
                .Txt_Visitor_Addr.Text = String.Empty
                .Txt_Visitor_Familyname.Text = String.Empty
                .Txt_Visitor_Age.Text = String.Empty
                .Txt_Visitor_Phone.Text = String.Empty
                .Txt_Visitor_Mobile.Text = String.Empty
                .Txt_Gender.Text = String.Empty
                .Txt_Nationality.Text = String.Empty
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Function Locate_ApointDetails(ByVal ApointID As Long) As Boolean
        Try
            Dim Dtbl As DataTable = Nothing
            Apoint_Bl = New Appointment_BL_Cls

            Lbl_MesageTokenno.Text = String.Empty
            Lbl_Mesageaproxtime.Text = String.Empty

            If Not Apoint_Bl.Get_AppointMent_Details(Dtbl, ApointID) Then
                MessageBox.Show("Invalid Apointment ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If


            With Dtbl

                If CDate(.Rows(0).Item("Apoint_Date").ToString()) <> Tran_Date Then
                    MessageBox.Show("Apointment is not taken on this date,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Return False
                End If

                If Not Cmb_Service.SelectedValue = .Rows(0).Item("Service_ID").ToString Then
                    If MessageBox.Show("This Appointment is not Registered for the selected Service" + vbCrLf + "Wan't to Change ", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.No Then
                        Call Clear_Patientinfo()
                        Return False
                    End If
                End If

                Me.Txt_ApointID.Text = ApointID
                Me.Txt_ApointID.Tag = ApointID

                '=====================================================================================================

                Lbl_MesageTokenno.Text = .Rows(0).Item("Apoint_Tokenno").ToString
                Lbl_Mesageaproxtime.Text = CDate(.Rows(0).Item("Apoint_AproxStime").ToString).ToString("hh:mm tt")

                '=====================================================================================================

            End With

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Locate_PatientApointment(ByVal Patient_ID As String) As Boolean
        Try
            Dim Dtbl As DataTable = Nothing
            Apoint_Bl = New Appointment_BL_Cls

            Lbl_MesageTokenno.Text = String.Empty
            Lbl_Mesageaproxtime.Text = String.Empty

            If Not Apoint_Bl.Get_PatientAppointment(Dtbl, Patient_ID, Tran_Date) Then Return False

            With Dtbl

                '=====================================================================================================

                If Not Cmb_Service.SelectedValue = .Rows(0).Item("Service_ID").ToString Then
                    Return False
                End If

                '=====================================================================================================
                Me.Txt_ApointID.Text = .Rows(0).Item("Apoint_ID").ToString
                Me.Txt_ApointID.Tag = .Rows(0).Item("Apoint_ID").ToString

                Lbl_MesageTokenno.Text = .Rows(0).Item("Apoint_Tokenno").ToString
                Lbl_Mesageaproxtime.Text = CDate(.Rows(0).Item("Apoint_AproxStime").ToString).ToString("hh:mm tt")

                '=====================================================================================================

            End With

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Clear_Form()
        Try
            Call Clear_Patientinfo()
            With Me
                .Txt_OPID.Text = String.Empty
                .Txt_OPID.Tag = String.Empty
                .Txt_ApointID.Text = String.Empty
                .Txt_Nationality.Text = String.Empty
                .Txt_Gender.Text = String.Empty
                .Txt_PMRID.Text = String.Empty
                .Txt_PMRID.Tag = String.Empty
                .Lbl_Billingmethod.Text = String.Empty
                .Lbl_Patienttype.Text = String.Empty
                .Lbl_Currentstatus.Text = String.Empty

                .Tr_Mode = Tran_Mode.New_Mode
                .Tran_BatchID = String.Empty
                .Tran_RefNo = String.Empty
                .Txt_Remarks.Text = String.Empty

                .Lbl_OPValidDays.Text = String.Empty
                .Lbl_OPValidity.Text = String.Empty
                .Lbl_OPValidDays.Tag = String.Empty
                .Lbl_OPValidity.BackColor = Color.White
                .Btn_NewOP.Visible = False

                .Txt_OPID.BackColor = Color.White
                .Txt_OPID.ReadOnly = False
                .Pnl_2.Enabled = False
                .Btn_Save.Enabled = False
                .Timer1.Enabled = False

            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Function Get_Doctordetails(ByVal Doc_ID As String) As Boolean
        Try
            Lbl_Doctordetails.Text = String.Empty

            Dim Dtbl As New DataTable
            If hms_helper.Get_Doctordetails(Dtbl, Doc_ID) Then
                Me.App_Doctor_Name = Dtbl.Rows(0).Item("Name").ToString
                Lbl_Doctordetails.Text = Dtbl.Rows(0).Item("Name").ToString.ToUpper
                Lbl_Doctordetails.Text += vbCrLf + Dtbl.Rows(0).Item("Qualification").ToString
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Clear_Patientdetails()
        Try


            Lbl_MesageTokenno.Text = "*"
            Lbl_Mesageaproxtime.Text = "*"

            Txt_PatientID.Text = String.Empty
            Txt_Visitor_SSNO.Text = String.Empty
            Txt_Visitor_Name.Text = String.Empty
            Txt_Visitor_Addr.Text = String.Empty
            Txt_Visitor_Familyname.Text = String.Empty
            Txt_Visitor_Age.Text = String.Empty
            Txt_Visitor_Mobile.Text = String.Empty
            Txt_Visitor_Phone.Text = String.Empty
            Txt_Gender.Text = String.Empty
            Txt_Nationality.Text = String.Empty


        Catch ex As Exception

        End Try
    End Sub

    Private Function Validate_Fields() As Boolean
        Try
            If OP_Service_ID = 0 Then MessageBox.Show("Please Select a Service and Proceed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_Service.Focus() : Return False
            If Seldoctor_ID = 0 Then MessageBox.Show("Please Select a Doctor and Proceed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : TlStrp_Doctors.Focus() : Return False


            If Txt_OPID.Text.Trim = String.Empty Then MessageBox.Show("Invalid OP - ID, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_OPID.Focus() : Return False


            If Txt_ApointID.Text.Trim = String.Empty Then MessageBox.Show("Invalid Apoint - ID, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_ApointID.Focus() : Return False


            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Locate_OPRegister(ByVal OP_ID As String, ByVal Br_Code As Integer) As Boolean
        Try

            Call Clear_Form()

            OP_BL = New OutPatient_BL_Cls

            Dim Dtbl As DataTable = Nothing
            Dim Tramt_Dtbl As DataTable = Nothing
            Dim Op_Tran_Dtbl As DataTable = Nothing
            Dim BkTran_Dtbl As DataTable = Nothing



            Dim Tr_Refno As String = "OP"


            If Not OP_BL.Get_OutPatient_Details(Dtbl, OP_ID) Then
                MessageBox.Show("Invalid OP-ID or OP-ID does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return False
            End If

            With Dtbl
                '-------------------------------------------------------------

                Dim OP_Perioddays As Integer = CInt(Dtbl.Rows(0).Item("OP Period Days").ToString())
                Dim OP_Regdate As Date = CDate(Dtbl.Rows(0).Item("Tran Date").ToString())

                Lbl_OPValidDays.Tag = CStr(OP_Perioddays)
                Lbl_OPValidDays.Text = CStr(DateAdd(DateInterval.Day, OP_Perioddays, OP_Regdate))
                Lbl_OPValidity.Text = IIf(DateAdd(DateInterval.Day, OP_Perioddays, OP_Regdate) < Tran_Date, "OP EXPIRED", "OP VALID")

                If DateAdd(DateInterval.Day, OP_Perioddays, OP_Regdate) < Tran_Date Then
                    IsValid_OP = False
                Else
                    IsValid_OP = True
                End If


                Txt_OPID.Text = .Rows(0).Item("OPD_ID").ToString
                Txt_OPID.Tag = Txt_OPID.Text
                Cmb_Service.SelectedValue = .Rows(0).Item("Service ID").ToString
                OP_Service_ID = .Rows(0).Item("Service ID").ToString
                Seldoctor_ID = .Rows(0).Item("Doc_ID").ToString

                Call Select_ApointDoctor(Seldoctor_ID)
                '-------------------------------------------------------------

                Me.Txt_PMRID.Text = .Rows(0).Item("Acc_ID").ToString

                If Not Locate_PMR_Masterinfo(Me.Txt_PMRID.Text.Trim) Then
                    MessageBox.Show("Invalid PMR-ID or PMR-ID does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Return False
                End If


                'Locating Apointment Details
                If Me.Txt_PatientID.Text.Trim <> String.Empty And IsValid_OP Then
                    If Not Locate_PatientApointment(Txt_PatientID.Text.Trim) Then
                        Me.Txt_ApointID.Text = String.Empty
                        Me.Lbl_MesageTokenno.Text = String.Empty
                        Me.Lbl_Mesageaproxtime.Text = String.Empty
                        Pnl_Apoint.Enabled = True
                    Else
                        Pnl_Apoint.Enabled = False
                    End If
                End If
                '-------------------------------------------------------------

                Lbl_Patienttype.Text = .Rows(0).Item("Patient Type").ToString
                Lbl_Currentstatus.Text = .Rows(0).Item("Status").ToString
                Lbl_Billingmethod.Text = .Rows(0).Item("Billing Method").ToString

                Pnl_2.Enabled = True

                If Not IsValid_OP Then
                    Timer1.Enabled = True
                    Btn_Save.Enabled = False
                    Btn_NewOP.Visible = True
                    Pnl_Apoint.Enabled = False
                Else
                    Timer1.Enabled = False
                    Btn_Save.Enabled = True
                    Btn_NewOP.Visible = False
                End If

                Return True

            End With

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub GenerateAppointment(ByVal DrId As Integer, _
                                    Optional ByVal ApointID As String = "")

        With Appointment_Reg_Frm
            .Clear_Form()
            .MdiParent = Me.MdiParent
            .Req_Ctrl = Txt_ApointID
            .ShowDialog(Me)
        End With

    End Sub

    Private Function Update_ApointmentOPID(ByVal OPD_ID As String) As Boolean
        Try
            Apoint_Bl = New Appointment_BL_Cls
            Dim Dtbl As DataTable = Nothing
            If Apoint_Bl.Update_AppointmentOPID(Dtbl, Val(Txt_ApointID.Text.Trim), Branch_Code, OPD_ID) Then
                If Dtbl.Rows(0).Item(0).ToString = "0" Then
                    MessageBox.Show("Appointment OP-ID Updation failed,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                Else
                    Return True
                End If
            Else
                Return False
            End If

        Catch ex As Exception

        End Try
    End Function

    Private Function Locate_PMR_Masterinfo(ByVal PMR_ID As String) As Boolean
        Try

            '-----------------   Clear Patient info   -----------------------------------

            Call Clear_Patientinfo()

            '----------------------------------------------------------------------------


            '-----------------  Locate Pateint Medical Record Master info   -------------

            Dim Dtbl As DataTable = Nothing
            If Not hms_helper.Get_PMR_Masterinfo(Dtbl, PMR_ID, Branch_Code) Then Return False

            With Dtbl
                Txt_PatientID.Text = .Rows(0).Item("Patient ID").ToString
                Txt_Visitor_SSNO.Text = .Rows(0).Item("S.S.No").ToString
                Txt_Visitor_Name.Text = .Rows(0).Item("Patient Name").ToString
                Txt_Visitor_Addr.Text = .Rows(0).Item("Address").ToString
                Txt_Visitor_Familyname.Text = .Rows(0).Item("Family Name").ToString
                Txt_Visitor_Age.Text = .Rows(0).Item("Age").ToString
                Txt_Visitor_Mobile.Text = .Rows(0).Item("Mobile1").ToString
                Txt_Visitor_Phone.Text = .Rows(0).Item("Phone1").ToString
                Txt_Gender.Text = IIf(.Rows(0).Item("Gender").ToString = "M", "Male", "Female")
                Txt_Nationality.Text = .Rows(0).Item("Country").ToString
                Txt_Nationality.Text = hms_helper.Get_Gendatadescription(Val(Txt_Nationality.Text.Trim))

            End With



            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Get_PMRID_OPID(ByVal PMR_ID As String) As String
        Try
            Dim Dtbl As DataTable = Nothing
            '-----------------  Locate Pateint Medical Record Master info   -------------
            If Not hms_helper.Get_PMR_Masterinfo(Dtbl, PMR_ID, Branch_Code) Then Return ""

            Return Dtbl.Rows(0).Item("OP ID").ToString

        Catch ex As Exception
            Return ""
        End Try
    End Function

    Private Sub Clear_Apointdetails()
        Try

            Lbl_MesageTokenno.Text = "*"
            Lbl_Mesageaproxtime.Text = "*"
            Txt_ApointID.Tag = ""


        Catch ex As Exception

        End Try
    End Sub

    Public Sub Select_ApointDoctor(ByVal Doc_ID As String)
        Try
            Dim btn_Doctor As ToolStripButton
            btn_Doctor = New ToolStripButton

            For Each btn_Doctor In TlStrp_Doctors.Items
                If btn_Doctor.Tag = Doc_ID Then
                    btn_Doctor.BackColor = Color.FromArgb(60, 113, 193)
                    btn_Doctor.ForeColor = Color.White
                Else
                    btn_Doctor.BackColor = Color.White
                    btn_Doctor.ForeColor = Color.DarkBlue
                End If

            Next
        Catch ex As Exception

        End Try
    End Sub

    Private Function Save_FollowupvisitReg() As Boolean
        Try
            OP_BL = New OutPatient_BL_Cls
            Dim Dtbl As DataTable = Nothing
            If OP_BL.Save_FollowupvisitReg(Dtbl, Me.Tr_Mode, 0, Tran_Date, _
                                           Txt_PMRID.Text.Trim, Txt_OPID.Text.Trim, _
                                           Txt_ApointID.Text.Trim, Txt_PatientID.Text.Trim, _
                                           Me.OP_Service_ID, Me.Seldoctor_ID, "N", 0, Now) Then
                If Dtbl.Rows(0).Item("FVR_ID") <> 0 Then
                    Return True
                Else
                    Return False
                End If
            End If

        Catch ex As Exception

        End Try
    End Function

#End Region

    Private Sub FollowupVisitReg_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then Call SendKeyTab()

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Cmb_Service_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_Service.SelectedIndexChanged
        Try
            Me.OP_Service_ID = 0
            Me.OP_Service_ID = Cmb_Service.SelectedValue
        Catch ex As Exception

        End Try
    End Sub

    Private Sub FollowupVisitReg_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub FollowupVisitReg_Frm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try

            If Cmb_Service.Items.Count = 0 Then
                Call Initialiseform()
            End If


        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Try
            Me.Close()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_AppIDF2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_AppIDF2.Click
        Try
            If Txt_ApointID.Text.Trim = String.Empty Then
                Dim Sql As String
                Dim Colwidth As String = String.Empty
                Colwidth = "200|50|50|70|"
                Sql = " SELECT   a.Visitor_Name , a.Apoint_Tokenno as [Token No], a.Apoint_Date as [Apoint Date], a.Apoint_AproxStime as [Apoint Time],a.Doctor, a.Apoint_ID"
                Sql += "  FROM   Appointments_Vw a "
                Sql += " WHERE  (Apoint_Date = '" & Format(Tran_Date, "MM/dd/yyyy") & "') AND (Doc_ID = " & Seldoctor_ID & ") AND (Apoint_Status = 'B') and (Visitor_ID = '" & Txt_PatientID.Text.Trim & "') "

                'Sql += "   AND	(Exists(Select * "
                'Sql += "  From   dbo.[Get_Doctorswithservices_Fn](" & Cmb_Service.SelectedValue & ",'" & Format(Tran_Date, "MM/dd/yyyy") & "') d Where d.DoctorID = a.Doc_ID))"

                Call ShowSearchengine(Txt_ApointID, Sql, 5, "Visitor_Name", Colwidth, , 0)
            End If

            'Validating Mandatory fields for locating
            If Txt_ApointID.Text.Trim = String.Empty Then
                'MessageBox.Show("Invalid Appointment ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_ApointID.Focus() : Exit Sub
            End If

            'Locating Apointment Details
            If Not Locate_ApointDetails(Val(Txt_ApointID.Text.Trim)) Then
                Txt_ApointID.Focus()
                Return
            End If

        Catch ex As Exception
        End Try
    End Sub

    Private Sub TlStrp_Doctors_ItemClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles TlStrp_Doctors.ItemClicked
        Try

            Dim btn_Doctor As ToolStripButton
            btn_Doctor = New ToolStripButton

            For Each btn_Doctor In TlStrp_Doctors.Items
                btn_Doctor.BackColor = Color.White
                btn_Doctor.ForeColor = Color.DarkBlue
            Next

            btn_Doctor = e.ClickedItem

            e.ClickedItem.BackColor = Color.FromArgb(60, 113, 193)
            e.ClickedItem.ForeColor = Color.White

            Lbl_Heading.Text = frm_Heading + "  of  " + e.ClickedItem.Text.ToUpper

            Call Clear_Form()
            Seldoctor_ID = 0

            With btn_Doctor
                Seldoctor_ID = Val(.Tag)
                'SendKeyTab()
            End With

            Dim Offday As String = String.Empty
            Dim Timings_Dtbl As DataTable = Nothing

            If Not hms_helper.Get_DoctorsDutytimings(Timings_Dtbl, Seldoctor_ID, Tran_Date) Then
                MessageBox.Show("Selected Doctors Duty Timings not available,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return
            End If

            Dim StrDt As String
            StrDt = Format(Tran_Date, "ddd").ToString()
            Offday = Timings_Dtbl.Rows(0).Item("D_OffDay").ToString
            If InStr(Offday, StrDt) > 0 Then
                MessageBox.Show("Off day for the selected doctor", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Seldoctor_ID = 0
                Lbl_Doctordetails.Text = String.Empty
                Exit Sub
            End If

            Txt_OPID.Focus()

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try
            Call Clear_Form()
            Txt_OPID.Focus()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_ApointID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_ApointID.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then Call Btn_AppIDF2_Click(sender, e)
            If e.KeyCode = Keys.F3 Then Call Btn_Appointment_Click(Nothing, Nothing)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Appointment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Appointment.Click
        Try

            'GenerateAppointment(Seldoctor_ID)
            Try

                If Txt_ApointID.Text.Trim <> "" Then Exit Sub

                If Seldoctor_ID = 0 Then
                    MessageBox.Show("Select a doctor from list", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    TlStrp_Doctors.Focus()
                    Exit Sub
                End If
                With Appointment_Reg_Frm
                    '.MdiParent = Me.MdiParent
                    .Req_Ctrl = Txt_ApointID

                    If .Set_Environment(OP_Service_ID, _
                                        Seldoctor_ID, _
                                        Tran_Date, _
                                        1) Then
                        .Txt_PMRID.Text = Txt_PMRID.Text.Trim
                        .Btn_FindPMRID_Click(Nothing, Nothing)
                        .IsLoaded = True
                        .ShowDialog(Me)

                        '==================================================
                        '   Locating Apointment details
                        If Txt_ApointID.Text.Trim <> "" Then
                            Call Btn_AppIDF2_Click(Nothing, Nothing)
                            Return
                        End If
                        '==================================================

                    End If
                End With

            Catch ex As Exception
                MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_ApointID_Validating(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_ApointID.Validating
        Try
            If Txt_ApointID.Text.Trim <> String.Empty And Me.Txt_OPID.Text <> Me.Txt_OPID.Tag Then
                If Not Locate_ApointDetails(Val(Txt_ApointID.Text.Trim)) Then
                    e.Cancel = True
                    Return
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Public Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try
            If Txt_OPID.Text.Trim = String.Empty Then
                Dim Sql As String
                Dim Colwidth As String = String.Empty
                Colwidth = "145|145|75|50|50|50"
                'Sql = "SELECT   [Patient Name],Doctor,[Status],[Patient Type],Cure_Status, [Tran Date],OPD_ID  FROM OPD_Master_Vw where [Tran Date] = '" & Format(Tran_Date, "MM/dd/yyyy") & "' and Br_Code = " & Branch_Code & " and  Active='Y' and Cancelled='N' "
                Sql = "SELECT   [Patient Name],Address,OPD_ID,[Status],[Cure Status], [Tran Date],[Patient Type]  FROM OPD_Master_Vw where Br_Code = " & Branch_Code & " and  Active='Y' and Cancelled='N' "
                Call ShowSearchengine(Txt_OPID, Sql, 2, "Patient Name", Colwidth, , 0)
            End If

            If Txt_OPID.Text.Trim = String.Empty Then
                Txt_OPID.Focus() : Exit Sub
            End If

            If Txt_OPID.Text.Trim <> String.Empty Then
                If Locate_OPRegister(Txt_OPID.Text.Trim, Branch_Code) Then

                    Me.Txt_OPID.BackColor = Color.Silver
                    Me.Txt_OPID.ReadOnly = True
                End If
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_OPID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_OPID.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then Call Btn_Find_Click(Nothing, Nothing)
            If e.KeyCode = Keys.F3 And Btn_NewOP.Visible Then Call Btn_NewOP_Click(Nothing, Nothing)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_OPID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_OPID.Validating
        Try
            If Me.Txt_OPID.Text.Trim <> String.Empty And Me.Txt_OPID.Text <> Me.Txt_OPID.Tag Then
                If Locate_OPRegister(Txt_OPID.Text.Trim, Branch_Code) Then
                    Me.Txt_OPID.BackColor = Color.Silver
                    Me.Txt_OPID.ReadOnly = True
                Else
                    'MessageBox.Show("Invalid OP ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Txt_OPID.Focus()
                    e.Cancel = True
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_ApointID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_ApointID.TextChanged
        Try
            If Txt_ApointID.Text.Trim = String.Empty Then
                Call Clear_Apointdetails()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try

            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If

            'Validating Fields
            If Not Validate_Fields() Then Exit Sub

            'Go For Registration
            If Save_FollowupvisitReg() Then

                '===========================================================================
                'Updating Apointment OP ID
                If Not Update_ApointmentOPID(Txt_OPID.Text.Trim) Then
                    Return
                End If

                '===========================================================================

                MessageBox.Show("Followup Visit Registration Completed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Call Clear_Form()
                Txt_OPID.Focus()

            Else
                MessageBox.Show("Error Occured While Saving Followup Visit Registration,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Timer1_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Try
            If Timer1.Tag = 1 Then
                Lbl_OPValidity.BackColor = Color.Red
                Timer1.Tag = 0
            Else
                Lbl_OPValidity.BackColor = Color.White
                Timer1.Tag = 1
            End If
        Catch ex As Exception

        End Try
    End Sub

  
    Private Sub Btn_NewOP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_NewOP.Click
        Try
            With OP_Register_Frm
                '--------------------------------------------------------
                .Initialising_form()
                '--------------------------------------------------------
                .Cmb_Service.SelectedValue = Me.Cmb_Service.SelectedValue
                .OP_Service_ID = Me.OP_Service_ID
                .Seldoctor_ID = Me.Seldoctor_ID
                .Cmb_Visittype.SelectedIndex = 1
                .Txt_PMRID.Text = Me.Txt_PMRID.Text.Trim
                '--------------------------------------------------------
                .Btn_PMRIDF2_Click(Nothing, Nothing)
                .Pnl_Doc.Enabled = False
                '--------------------------------------------------------
                Me.Clear_Form()
                '--------------------------------------------------------
                .MdiParent = Me.MdiParent
                .Show()
                '--------------------------------------------------------
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_PMRIDF2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_PMRIDF2.Click
        Try
            If Txt_PMRID.Text.Trim = String.Empty Then
                Dim Sql As String
                Dim Colwidth As String = String.Empty
                Colwidth = "200|50|300|70|"

                Sql = " SELECT [Patient Name], [SS No], ([Family Name] + Address + City) AS Address, PMR_ID, OPD_ID, Patient_ID"
                Sql += " FROM Pateint_Accountsearch_Vw WHERE (Cancelled = 'N') AND (Authorised = 'Y')"

                Call ShowSearchengine(Txt_PMRID, Sql, 3, "[Patient Name]", Colwidth, , 0)
            End If

            'Validating Mandatory fields for locating
            If Txt_PMRID.Text.Trim = String.Empty Then
                'MessageBox.Show("Invalid Appointment ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_PMRID.Focus() : Exit Sub
            End If

            Txt_OPID.Text = Get_PMRID_OPID(Txt_PMRID.Text.Trim)

            If Txt_OPID.Text.Trim <> String.Empty Then
                Call Btn_Find_Click(Nothing, Nothing)
            Else
                MessageBox.Show("Invalid PMR ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_PMRID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_PMRID.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then Call Btn_PMRIDF2_Click(Nothing, Nothing)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_PMRID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_PMRID.Validating
        Try
            If Me.Txt_PMRID.Text.Trim <> String.Empty And Me.Txt_PMRID.Text <> Me.Txt_PMRID.Tag Then
                Txt_OPID.Text = Get_PMRID_OPID(Txt_PMRID.Text.Trim)

                If Txt_OPID.Text.Trim <> String.Empty Then
                    Call Btn_Find_Click(Nothing, Nothing)
                Else
                    MessageBox.Show("Invalid PMR ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            End If

        Catch ex As Exception

        End Try
    End Sub

End Class