﻿Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls
Public Class Patient_Prescription_Frm

#Region "Declarations"
    'Object of Patient Details Bussiness Layer
    ' Private Doctor_BL As OutPatient_BL_Cls

    Private hms_helper As HMS_Helper = Nothing
    Private Pat_Presc_BL As Patient_Prescription_BL_Cls
    Private prec_Template As Prescription_Template_BL_Cls
    Private Pat_Diagno_BL As Patient_Diagnosis_BL_Cls
    Private mReq_Ctrl As Object = Nothing
    Private mTr_Mode As Long
    Private Form_Closing As Boolean

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing
    Dim PhySician_ID As Integer
    Dim IntRow As Integer
    Dim IntSelectRow As Integer

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"

                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"

            End Select
        End Set
    End Property

#End Region

#Region "Methods"

    Public Function Fill_Acc_Details(ByVal Acc_ID As String) As Boolean
        Try
            Dim dtbl As DataTable = Nothing
            Dim dr As DataTableReader = Nothing

            hms_helper = New Hms_Helperimpliments
            Txt_Patient_Id.Tag = ""
            If hms_helper.Get_Patient_Account_Details(dtbl, Acc_ID) Then
                dr = dtbl.CreateDataReader
                dr.Read()
                With dr
                    Cmb_Doctor.SelectedValue = dr.Item("Doc_ID").ToString
                    Txt_Patient_Id.Text = dr.Item("Patient ID").ToString
                    Txt_op_Id.Text = dr.Item("OP ID").ToString
                    Txt_Acc_Id.Tag = Acc_ID

                    'Locate_Latest_Diagnosis(Txt_Acc_Id.Text.Trim)
                    'hms_helper.Fill_Pat_Latest_Diagnosis(Cmb_Pres_Templates, Txt_Acc_Id.Text.Trim, Branch_Code)
                    Pat_Presc_BL = New Patient_Prescription_BL_Cls
                    If Cmb_Pres_Templates.Tag = "False" Then
                        If Pat_Presc_BL.Fill_Patient_Distinct_Diagnosis(Cmb_Pres_Templates, Txt_Acc_Id.Text.Trim, Branch_Code) Then
                            Cmb_Pres_Templates.Tag = "True" ' Combo Filled
                            'Locate Patients Prescription details
                            If Locate_Values(Txt_Acc_Id.Text.Trim) Then
                            End If
                        Else
                            MessageBox.Show("Please Enter Diagnosis Details Of Patient", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                            Cmb_Pres_Templates.Tag = "False"
                        End If
                    End If
                End With
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            Return False
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Function

    Private Sub Clear_Form()
        Try
            Cmb_Pres_Templates.DataSource = Nothing
            Txt_Patient_Id.Text = ""
            Txt_Acc_Id.Text = ""
            Txt_Physician.Text = ""
            Call Clear_Prescription_Details()
            Dgv_Prescription.RowCount = 0
            Cmb_Pres_Templates.Tag = "False"
            Txt_Acc_Id.Tag = ""
            Txt_Physician.Tag = ""

            Txt_op_Id.Text = ""
            'Cmb_Pres_Templates.Items.Clear()
            Tr_Mode = Tran_Mode.New_Mode

            Btn_Delete.Enabled = False
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try
    End Sub

    Private Function GET_PhysicianName(ByVal PhySician_ID As Integer) As Boolean
        Try
            Dim Dtbl As DataTable = Nothing
            Dim Dr As DataTableReader = Nothing
            hms_helper = New Hms_Helperimpliments
            Txt_Physician.Tag = ""
            If hms_helper.GetEmp_Details(Dtbl, PhySician_ID) Then
                Dr = Dtbl.CreateDataReader()
                Dr.Read()
                With Dr
                    Lbl_Drname.Text = Dr.Item("Name").ToString + vbCrLf
                    Lbl_Drname.Text += Dr.Item("Emp_Qualification").ToString
                    Txt_Physician.Tag = PhySician_ID
                End With
                Return True
            Else
                Lbl_Drname.Text = ""
                Txt_Physician.Text = ""
                'Txt_Physician.
                Return False
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function

    Public Function FillOp_Detail(ByVal OpId As String) As Boolean
        Try
            Dim dtbl As DataTable = Nothing
            Dim dr As DataTableReader = Nothing

            hms_helper = New Hms_Helperimpliments
            Txt_Patient_Id.Tag = ""
            If hms_helper.Get_OP_Details(dtbl, OpId) Then
                dr = dtbl.CreateDataReader
                dr.Read()

                With dr
                    Txt_Patient_Id.Text = dr.Item("Patient ID").ToString
                    Txt_Acc_Id.Text = dr.Item("ACC_ID")
                    Cmb_Doctor.SelectedValue = dr.Item("DOC_ID").ToString
                End With
                'Locating Images if available
                'Call ShowImageviewer(Me, Patient_ID, Customer_Type.Employee)

                'Locate_Latest_Diagnosis(Txt_Acc_Id.Text.Trim)
                'hms_helper.Fill_Pat_Latest_Diagnosis(Cmb_Pres_Templates, Txt_Acc_Id.Text.Trim, Branch_Code)
                Pat_Presc_BL = New Patient_Prescription_BL_Cls
                If Cmb_Pres_Templates.Tag = "False" Then
                    Pat_Presc_BL.Fill_Patient_Distinct_Diagnosis(Cmb_Pres_Templates, Txt_Acc_Id.Text.Trim, Branch_Code)
                End If
                Cmb_Pres_Templates.Tag = "True" ' Combo Filled

                If Txt_Acc_Id.Text.Trim <> "" And Me.Txt_Acc_Id.Text.Trim <> Me.Txt_Acc_Id.Tag Then
                    If Locate_Values(Txt_Acc_Id.Text.Trim) Then
                    End If
                End If

                Return True
            Else
                Return False
                Cmb_Pres_Templates.Tag = "False" '  Combo not Filled
            End If

        Catch ex As Exception
            Return False
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Function

    Private Function Validate_GridValues() As Boolean
        Try
            With Dgv_Prescription
                If Cmb_Pres_Templates.Text = "" Then MessageBox.Show("Invalid Diagnosis", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Cmb_Pres_Templates.Focus() : Return False : Exit Function
                For i = 0 To .Rows.Count - 1 'Presc_ID
                    If .Rows(i).Cells("Medicine").Value.ToString = "x" Then
                        If Txt_Medicine.Text.Trim = .Rows(i).Cells("Medicine").Value.ToString.Trim Then
                            MessageBox.Show("Medicine Already Enterd, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_Medicine.Focus() : Return False : Exit Function
                        End If
                    End If
                Next
            End With
            If Txt_Medicine.Text.Trim = "" Then MessageBox.Show("Invalid Medicine name, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_Medicine.Focus() : Return False : Exit Function
            If Txt_Dose.Text.Trim = "" Then MessageBox.Show("invalid Medicine Dose, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_Dose.Focus() : Return False : Exit Function
            If cmb_Frequency.Text = "" Then MessageBox.Show("Invalid Freequency, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : cmb_Frequency.Focus() : Return False : Exit Function
            If Cmb_Route.Text = "" Then MessageBox.Show("Invalid Medicine Route, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Cmb_Route.Focus() : Return False : Exit Function
            If Val(Txt_Qty.Text) = 0 Then MessageBox.Show("Invalid Quantity , Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_Qty.Focus() : Return False : Exit Function
            If Val(Txt_Refils.Text) = 0 Then MessageBox.Show("Invalid Refils, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_Refils.Focus() : Return False : Exit Function
            If Val(Txt_Days.Text) = 0 Then MessageBox.Show("Invalid Days, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_Days.Focus() : Return False : Exit Function
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Clear_Prescription_Details()
        Try
            Txt_Medicine.Text = ""
            Txt_Dose.Text = ""
            cmb_Frequency.SelectedIndex = 0
            Cmb_Route.SelectedIndex = 0
            Txt_Qty.Text = ""
            Txt_Refils.Text = ""
            Txt_Days.Text = ""
            Cmb_Continue.SelectedIndex = 0
            Cmb_Stat.SelectedIndex = 0
            Txt_Medicine.Focus()
            Btn_Add.Text = "Add"
            Btn_Add.Tag = "A" 'Add
            IntSelectRow = -1
            Tr_Mode = Tran_Mode.New_Mode
            Dgv_Prescription.ClearSelection()
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Function Validate_Fields() As Boolean
        Try
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If

            If Txt_Acc_Id.Text.Trim = "" Then MessageBox.Show("Invalid PMR ID ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Acc_Id.Focus() : Exit Function
            If Txt_Physician.Text.Trim = "" Then MessageBox.Show("Invalid Physician Id ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Physician.Focus() : Exit Function
            Return True
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function

    Private Function Load_Prescription_Values(ByVal Diagnos_Id As Integer) As Boolean

        Try
            'Dgv_Prescription.RowCount = 0

            If Not Validate_Fields() Then Exit Function

            Dim i As Integer
            Dim TotalRow As Integer
            i = Dgv_Prescription.Rows.Count
            Dim TR As Integer

            Dim Dtbl As DataTable = Nothing
            If hms_helper.Get_Prescription_Details(Dtbl, Cmb_Pres_Templates.SelectedValue, Dtp_TranDate.Value, Branch_Code) Then

                'Dim Dtbl As DataTable = Nothing
                'Pat_Presc_BL = New Patient_Prescription_BL_Cls
                'If Pat_Presc_BL.Get_Prescription_Templates_Values(Dtbl, Diagnos_Id) Then
                With Dtbl
                    TotalRow = Dgv_Prescription.RowCount + .Rows.Count
                    Dgv_Prescription.RowCount = TotalRow
                    For i = i To TotalRow - 1
                        Dgv_Prescription.Rows(i).Cells("Medicine").Value = .Rows(TR).Item("Pres_Medicine_Name").ToString
                        Dgv_Prescription.Rows(i).Cells("Dose").Value = .Rows(TR).Item("Pres_Dose").ToString
                        Dgv_Prescription.Rows(i).Cells("Freequency").Value = .Rows(TR).Item("Pres_Frequency").ToString
                        Dgv_Prescription.Rows(i).Cells("Route").Value = .Rows(TR).Item("Pres_Route").ToString
                        Dgv_Prescription.Rows(i).Cells("Qty").Value = .Rows(TR).Item("Pres_Quantity").ToString
                        Dgv_Prescription.Rows(i).Cells("Refils").Value = .Rows(TR).Item("Pres_Refills").ToString
                        Dgv_Prescription.Rows(i).Cells("Days").Value = .Rows(TR).Item("Pres_NoofDays").ToString
                        Dgv_Prescription.Rows(i).Cells("Pres_Continue").Value = 1
                        Dgv_Prescription.Rows(i).Cells("Status").Value = "Yes"
                        Dgv_Prescription.Rows(i).Cells("Presc_ID").Value = "x"

                        Dgv_Prescription.Rows(i).Cells("Tr_Dt").Value = Dtp_TranDate.Value
                        Dgv_Prescription.Rows(i).Cells("Doctor").Value = Cmb_Doctor.SelectedValue
                        Dgv_Prescription.Rows(i).Cells("PhyID").Value = Txt_Physician.Text.Trim
                        Dgv_Prescription.Rows(i).Cells("Diagnos_Id").Value = Cmb_Pres_Templates.SelectedValue

                        TR = TR + 1
                    Next
                End With
                Form_Closing = False
            Else
                MessageBox.Show("Prescription details not entered for this Diagnosis", Product_Name, MessageBoxButtons.OK)
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try
    End Function

    Private Function Locate_Values(ByVal ACC_ID As String) As Boolean
        Try
            Dim dtbl As DataTable = Nothing
            'Initialising BL Object
            Pat_Presc_BL = New Patient_Prescription_BL_Cls

            dtbl = Nothing
            Txt_Acc_Id.Text = ACC_ID
            'Retreiving Patient Prescription Details
            If Pat_Presc_BL.Get_Patient_Prescription(dtbl, ACC_ID, Branch_Code) Then
                'Return Assigntocontrols(dtbl)
                Cmb_Pres_Templates.DataSource = Nothing
                Cmb_Pres_Templates.Tag = "False"
                Call Clear_Prescription_Details()

                Txt_Patient_Id.Text = dtbl.Rows(0).Item("Patient_ID")
                Txt_Acc_Id.Text = dtbl.Rows(0).Item("ACC_ID")
                Txt_Acc_Id.Tag = dtbl.Rows(0).Item("ACC_ID")
                Dtp_TranDate.Text = dtbl.Rows(0).Item("Pres_Date")
                Cmb_Doctor.SelectedValue = dtbl.Rows(0).Item("Doc_ID").ToString
                Txt_Physician.Text = dtbl.Rows(0).Item("Physician_ID")

                'If Cmb_Continue.SelectedIndex = 0 Then
                '    .Rows(.Rows.Count - 1).Cells("Pres_Continue").Value = 1
                'Else
                '    .Rows(.Rows.Count - 1).Cells("Pres_Continue").Value = 0
                'End If

                With dtbl
                    Dgv_Prescription.RowCount = .Rows.Count
                    For i = 0 To .Rows.Count - 1
                        Dgv_Prescription.Rows(i).Cells("Medicine").Value = .Rows(i).Item("Pres_Medicine_Name").ToString
                        Dgv_Prescription.Rows(i).Cells("Dose").Value = .Rows(i).Item("Pres_Dose").ToString
                        Dgv_Prescription.Rows(i).Cells("Freequency").Value = .Rows(i).Item("Pres_Frequency").ToString
                        Dgv_Prescription.Rows(i).Cells("Route").Value = .Rows(i).Item("Pres_Route").ToString
                        Dgv_Prescription.Rows(i).Cells("Qty").Value = .Rows(i).Item("Pres_Quantity").ToString
                        Dgv_Prescription.Rows(i).Cells("Refils").Value = .Rows(i).Item("Pres_Refills").ToString
                        Dgv_Prescription.Rows(i).Cells("Days").Value = .Rows(i).Item("Pres_NoofDays").ToString
                        If .Rows(i).Item("Pres_Continue").ToString = "Y" Then
                            Dgv_Prescription.Rows(i).Cells("Pres_Continue").Value = 1
                        Else
                            Dgv_Prescription.Rows(i).Cells("Pres_Continue").Value = 0
                        End If
                        Dgv_Prescription.Rows(i).Cells("Dis_Dt").Value = .Rows(i).Item("Pres_Discontinuedate").ToString
                        If .Rows(i).Item("Pres_Status").ToString = "Y" Then
                            Dgv_Prescription.Rows(i).Cells("Status").Value = "Yes" '
                        Else
                            Dgv_Prescription.Rows(i).Cells("Status").Value = "No" '
                        End If
                        Dgv_Prescription.Rows(i).Cells("Presc_ID").Value = .Rows(i).Item("Presc_ID").ToString
                        Dgv_Prescription.Rows(i).Cells("Tr_Dt").Value = Format(.Rows(i).Item("Pres_Date"), "dd/MM/yyyy")
                        Dgv_Prescription.Rows(i).Cells("Doctor").Value = .Rows(i).Item("Doc_ID").ToString
                        Dgv_Prescription.Rows(i).Cells("PhyID").Value = .Rows(i).Item("Physician_ID").ToString

                        Dgv_Prescription.Rows(i).Cells("Diagnos_Id").Value = .Rows(i).Item("Diagno_Id").ToString
                    Next
                End With
                Pat_Presc_BL = New Patient_Prescription_BL_Cls
                If Cmb_Pres_Templates.Tag = "False" Then
                    Pat_Presc_BL.Fill_Patient_Distinct_Diagnosis(Cmb_Pres_Templates, Txt_Acc_Id.Text.Trim, Branch_Code)
                    Cmb_Pres_Templates.Tag = "True" ' Combo Filled
                End If
                'Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Delete.Enabled = True
                Return True
            Else
                Tr_Mode = Tran_Mode.New_Mode
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        Finally
            Dr = Nothing
            Dtbl = Nothing
            Pat_Presc_BL = Nothing
        End Try
    End Function

    Private Function Assigntocontrols(ByVal D_Table As DataTable) As Boolean
        Try

            'Dr = D_Table.CreateDataReader()
            'Dr.Read()
            'With Dr
            '    Dgv_Prescription.rows.Count =
            '    Txt_Presc_ID.Text = .Item("Presc_ID")
            '    Txt_op_Id.Text = .Item("OP_ID")
            '    Txt_Patient_Id.Text = .Item("Patient_ID")
            '    Txt_Acc_Id.Text = .Item("ACC_ID")
            '    Dtp_TranDate.Text = .Item("Pres_Date")
            '    Cmb_Doctor.SelectedValue = .Item("Doc_ID").ToString
            '    Txt_Physician.Text = .Item("Physician_ID")
            '    For i = 0 To Dr.r
            '        Cmb_Country.SelectedValue = .Item("Pres_Medicine_Name").ToString
            '        Txt_Ref_DrMobile1.Text = .Item("Mobile1")
            '        Txt_Ref_DrMobile2.Text = .Item("Mobile2")
            '        Txt_Ref_DrPhone1.Text = .Item("Phone1")
            '        Txt_Ref_DrPhone2.Text = .Item("Phone2")
            '        Txt_Ref_DrQF.Text = .Item("Qualification")

            '    Next

            'End With

            Return True
        Catch ex As Exception
            Return False
        Finally
            D_Table = Nothing
        End Try
    End Function

    Sub ComboChange(ByVal Item As String)
        Try
            Dim ID As Integer
            If cmb_Frequency.FindString(Item) > 0 Then
                ID = cmb_Frequency.FindString(Item)
            Else
                ID = cmb_Frequency.Items.Add(Item)
            End If
            cmb_Frequency.SelectedIndex = ID
        Catch ex As Exception

        End Try
    End Sub

#End Region

    Public WriteOnly Property Req_Ctrl() As Object
        Set(ByVal Value As Object)
            mReq_Ctrl = Value
        End Set
    End Property

    Private Sub Patient_Prescription_Frm_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Try
            If Dgv_Prescription.Rows.Count <> 0 Then
                If Form_Closing = False Then
                    MessageBox.Show("Please, Save the records before closing", Product_Name, MessageBoxButtons.OK)
                    e.Cancel = True
                End If
            End If

            If TypeOf mReq_Ctrl Is TextBox And Txt_Acc_Id.Text.Trim <> "" Then
                mReq_Ctrl.text = Txt_Acc_Id.Text
                If mReq_Ctrl.Visible Then mReq_Ctrl.focus()
                Me.Close()
            End If
        Catch ex As Exception
        End Try

    End Sub

    Private Sub Patient_Prescription_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then Call SendKeyTab()
    End Sub

    Private Sub Patient_Prescription_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub Patient_Prescription_Frm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try

            hms_helper = New Hms_Helperimpliments
            hms_helper.Fill_Doctors(Cmb_Doctor)
            'hms_helper.Fill_Prescription_Templates(Cmb_Pres_Templates)

            cmb_Frequency.SelectedIndex = 0
            Cmb_Route.SelectedIndex = 0
            Cmb_Continue.SelectedIndex = 0
            Cmb_Stat.SelectedIndex = 0
            SendKeyTab()
            SendKeyTab()
            SendKeyTab()
            Cmb_Pres_Templates.Tag = "False"
            Btn_Add.Tag = "A"

            'IntSelectRow = -1

            Dtp_TranDate.Value = Tran_Date
            DTP_Dis.Value = Tran_Date
            Btn_Delete.Enabled = False

            Form_Closing = True
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Add_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Add.Click
        Try
            If Not Validate_Fields() Then Exit Sub
            If Not Validate_GridValues() Then Exit Sub
            If Btn_Add.Tag = "A" Then
                Form_Closing = False
                With Dgv_Prescription
                    .Rows.Add()
                    .Rows(.Rows.Count - 1).Cells("Medicine").Value = Txt_Medicine.Text.Trim
                    .Rows(.Rows.Count - 1).Cells("Dose").Value = Txt_Dose.Text.Trim
                    .Rows(.Rows.Count - 1).Cells("Freequency").Value = cmb_Frequency.Text
                    .Rows(.Rows.Count - 1).Cells("Route").Value = Cmb_Route.Text
                    .Rows(.Rows.Count - 1).Cells("Qty").Value = Txt_Qty.Text.Trim
                    .Rows(.Rows.Count - 1).Cells("Refils").Value = Txt_Refils.Text.Trim
                    .Rows(.Rows.Count - 1).Cells("Days").Value = Txt_Days.Text.Trim

                    If Cmb_Continue.SelectedIndex = 0 Then
                        .Rows(.Rows.Count - 1).Cells("Pres_Continue").Value = 1
                    Else
                        .Rows(.Rows.Count - 1).Cells("Pres_Continue").Value = 0
                    End If
                    '.Rows(.Rows.Count - 1).Cells("Pres_Continue").Value = Cmb_Continue.Text
                    If Cmb_Continue.SelectedIndex = 0 Then
                        '.Rows(.Rows.Count - 1).Cells("Dis_Dt").Value = "NULL"
                    Else
                        .Rows(.Rows.Count - 1).Cells("Dis_Dt").Value = DTP_Dis.Value
                    End If
                    .Rows(.Rows.Count - 1).Cells("Status").Value = Cmb_Stat.Text
                    .Rows(.Rows.Count - 1).Cells("Presc_ID").Value = "x"

                    .Rows(.Rows.Count - 1).Cells("Tr_Dt").Value = Dtp_TranDate.Value
                    .Rows(.Rows.Count - 1).Cells("Doctor").Value = Cmb_Doctor.SelectedValue
                    .Rows(.Rows.Count - 1).Cells("PhyID").Value = Txt_Physician.Text.Trim
                    .Rows(.Rows.Count - 1).Cells("Diagnos_Id").Value = Cmb_Pres_Templates.SelectedValue

                    Call Clear_Prescription_Details()
                End With
            ElseIf Btn_Add.Tag = "M" Then
                With Dgv_Prescription
                    If IntSelectRow >= 0 Then
                        .Rows(IntSelectRow).Cells("Medicine").Value = Txt_Medicine.Text.Trim
                        .Rows(IntSelectRow).Cells("Dose").Value = Txt_Dose.Text.Trim
                        .Rows(IntSelectRow).Cells("Freequency").Value = cmb_Frequency.Text
                        .Rows(IntSelectRow).Cells("Route").Value = Cmb_Route.Text
                        .Rows(IntSelectRow).Cells("Qty").Value = Txt_Qty.Text.Trim
                        .Rows(IntSelectRow).Cells("Refils").Value = Txt_Refils.Text.Trim
                        .Rows(IntSelectRow).Cells("Days").Value = Txt_Days.Text.Trim
                        If Cmb_Continue.SelectedIndex = 0 Then
                            .Rows(IntSelectRow).Cells("Pres_Continue").Value = 1
                        Else
                            .Rows(IntSelectRow).Cells("Pres_Continue").Value = 0
                        End If
                        '.Rows(intSelectrow).Cells("Pres_Continue").Value = Cmb_Continue.Text
                        If Cmb_Continue.SelectedIndex = 0 Then
                            .Rows(IntSelectRow).Cells("Dis_Dt").Value = ""
                        Else
                            .Rows(IntSelectRow).Cells("Dis_Dt").Value = DTP_Dis.Value
                        End If
                        .Rows(IntSelectRow).Cells("Status").Value = Cmb_Stat.Text

                        .Rows(IntSelectRow).Cells("Tr_Dt").Value = Dtp_TranDate.Value
                        .Rows(IntSelectRow).Cells("Doctor").Value = Cmb_Doctor.SelectedValue
                        .Rows(IntSelectRow).Cells("PhyID").Value = Txt_Physician.Text.Trim
                    Else
                        .Rows.Add()
                        .Rows(.Rows.Count - 1).Cells("Medicine").Value = Txt_Medicine.Text.Trim
                        .Rows(.Rows.Count - 1).Cells("Dose").Value = Txt_Dose.Text.Trim
                        .Rows(.Rows.Count - 1).Cells("Freequency").Value = cmb_Frequency.Text
                        .Rows(.Rows.Count - 1).Cells("Route").Value = Cmb_Route.Text
                        .Rows(.Rows.Count - 1).Cells("Qty").Value = Txt_Qty.Text.Trim
                        .Rows(.Rows.Count - 1).Cells("Refils").Value = Txt_Refils.Text.Trim
                        .Rows(.Rows.Count - 1).Cells("Days").Value = Txt_Days.Text.Trim
                        If Cmb_Continue.SelectedIndex = 0 Then
                            .Rows(.Rows.Count - 1).Cells("Pres_Continue").Value = 1
                        Else
                            .Rows(.Rows.Count - 1).Cells("Pres_Continue").Value = 0
                        End If
                        '.Rows(.Rows.Count - 1).Cells("Pres_Continue").Value = Cmb_Continue.Text
                        If Cmb_Continue.SelectedIndex = 0 Then
                            '.Rows(.Rows.Count - 1).Cells("Dis_Dt").Value = "NULL"
                        Else
                            .Rows(.Rows.Count - 1).Cells("Dis_Dt").Value = DTP_Dis.Value
                        End If
                        .Rows(.Rows.Count - 1).Cells("Status").Value = Cmb_Stat.Text
                        .Rows(.Rows.Count - 1).Cells("Presc_ID").Value = "x"

                        .Rows(.Rows.Count - 1).Cells("Tr_Dt").Value = Dtp_TranDate.Value
                        .Rows(.Rows.Count - 1).Cells("Doctor").Value = Cmb_Doctor.SelectedValue
                        .Rows(.Rows.Count - 1).Cells("PhyID").Value = Txt_Physician.Text.Trim
                    End If
                End With
                Call Clear_Prescription_Details()
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try

    End Sub

    Private Sub Btn_Physician_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Physician.Click
        Try

            If Txt_Physician.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "150|200|75|100|150|"
                Sql = "SELECT  Name,Address,Phone,Mobile,Email,Country,Emp_ID FROM EMP_Details_Vw where Emp_Category = 37 and Status = 'A'and Br_Code = '" & Branch_Code & "'"
                Call ShowSearchengine(Txt_Physician, Sql, 6, "Name", Colwidth, , 0)
            End If

            If Txt_Physician.Text.Trim = "" Then
                Txt_Physician.Focus() : Exit Sub
            Else
                Cmb_Pres_Templates.Focus()
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try
    End Sub

    Private Sub Txt_Patient_Id_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Patient_Id.TextChanged
        Try
            With Patient_Info1
                .Viewmoreform_Name = "Patient_InfoSheet_Frm"
                .MDIform_Name = Me.MdiParent
                If Txt_Patient_Id.Text.Trim <> "" Then .Patient_ID = Txt_Patient_Id.Text.Trim
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_Physician_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Physician.KeyDown
        If e.KeyCode = Keys.F2 Then
            Call Btn_Physician_Click(sender, e)
        End If
    End Sub

    Private Sub Txt_Physician_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Physician.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Physician.Text, Data_Type.Integer_Type, 12))
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Txt_Physician_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Physician.TextChanged
        Try
            Txt_Physician.Tag = ""
            If Txt_Physician.Text.Trim <> "" Then
                If GET_PhysicianName(Txt_Physician.Text.Trim) Then
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_Qty_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Qty.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Qty.Text, Data_Type.Integer_Type, 12))
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Txt_Refils_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Refils.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Refils.Text, Data_Type.Integer_Type, 12))
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Txt_Days_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Days.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Days.Text, Data_Type.Integer_Type, 12))
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try

            Pat_Presc_BL = New Patient_Prescription_BL_Cls

            'Validating Data controls
            If Not Validate_Fields() Then Exit Sub
            If Dgv_Prescription.Rows.Count <= 0 Then
                MessageBox.Show("Please Enter Prescription Details ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Medicine.Focus() : Exit Sub
            End If

            'Call Pat_Presc_BL.Delete_Patient_Prescription(Txt_Acc_Id.Text.Trim)

            Dim i As Integer
            Dim Int_Presc_ID As Long
            With Pat_Presc_BL
                Pat_Presc_BL.OP_ID = Txt_op_Id.Text.Trim
                Pat_Presc_BL.Patient_ID = Txt_Patient_Id.Text.Trim
                Pat_Presc_BL.ACC_ID = Txt_Acc_Id.Text.Trim
                'Pat_Presc_BL.Pres_Date = Dtp_TranDate.Value
                'Pat_Presc_BL.Doc_ID = Cmb_Doctor.SelectedValue
                'Pat_Presc_BL.Physician_ID = Txt_Physician.Text.Trim


                With Dgv_Prescription
                    For i = 0 To .Rows.Count - 1
                        Pat_Presc_BL.Pres_Date = .Rows(i).Cells("Tr_Dt").Value.ToString.Trim
                        Pat_Presc_BL.Doc_ID = .Rows(i).Cells("Doctor").Value.ToString.Trim
                        Pat_Presc_BL.Physician_ID = .Rows(i).Cells("PhyID").Value.ToString.Trim

                        Pat_Presc_BL.Pres_Medicine_Name = .Rows(i).Cells("Medicine").Value.ToString.Trim
                        Pat_Presc_BL.Pres_Dose = .Rows(i).Cells("Dose").Value.ToString.Trim
                        Pat_Presc_BL.Pres_Frequency = .Rows(i).Cells("Freequency").Value.ToString.Trim
                        Pat_Presc_BL.Pres_Route = .Rows(i).Cells("Route").Value.ToString.Trim
                        Pat_Presc_BL.Pres_Quantity = .Rows(i).Cells("Qty").Value.ToString.Trim
                        Pat_Presc_BL.Pres_Refills = .Rows(i).Cells("Refils").Value.ToString.Trim
                        Pat_Presc_BL.Pres_NoofDays = .Rows(i).Cells("Days").Value.ToString.Trim
                        If .Rows(i).Cells("Pres_Continue").Value = 1 Then
                            Pat_Presc_BL.Pres_Continue = "Y"
                        Else
                            Pat_Presc_BL.Pres_Continue = "N"
                        End If
                        If .Rows(i).Cells("Pres_Continue").Value = 0 Then
                            Pat_Presc_BL.Pres_Discontinuedate = Format(Tran_Date, "dd/MM/yyyy")
                        End If
                        Pat_Presc_BL.Pres_Status = .Rows(i).Cells("Status").Value.ToString.Trim
                        Pat_Presc_BL.Diagno_ID = .Rows(i).Cells("Diagnos_Id").Value
                        'If .Rows(i).Cells("Presc_ID").Value.ToString.Trim() = "x" Then
                        '    Int_Presc_ID = 0
                        '    Tr_Mode = Tran_Mode.New_Mode
                        'Else
                        '    Int_Presc_ID = (.Rows(i).Cells("Presc_ID").Value.ToString.Trim())
                        '    Tr_Mode = Tran_Mode.Edit_Mode
                        'End If


                        'End If
                        Tr_Mode = Tran_Mode.New_Mode
                        Pat_Presc_BL.Save_Patient_Prescription(Dtbl, Int_Presc_ID, Tr_Mode)

                    Next
                End With
                Dtbl = Nothing
                MessageBox.Show("Patient Prescription Details Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Form_Closing = True
                Call Btn_Clear_Click(sender, e)
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try

    End Sub

    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try

            If Tr_Mode = Tran_Mode.New_Mode Then
                If Txt_Acc_Id.Text.Trim = "" Then
                    Dim Sql As String
                    Dim Colwidth As String = ""
                    Colwidth = "175|125|100|50|125"
                    'Sql = "SELECT [Patient Name],ACC_ID,[Reg Date],[Family Name],Address,City,[Patient_ID]  FROM Patient_Account_Vw where ACC_ID IN(Select Acc_ID from Patient_Presc_Vw) Order by [Reg Date] Desc"
                    Sql = "SELECT * FROM Patient_Pres_Distinct_Vw"
                    Call ShowSearchengine(Txt_Acc_Id, Sql, 0, "Acc_ID", Colwidth, , 0)
                End If

                If Txt_Acc_Id.Text.Trim = "" Then
                    Txt_Acc_Id.Focus() : Exit Sub
                End If

                'Locate Out Patient details
                If Locate_Values(Txt_Acc_Id.Text.Trim) Then
                    'Tr_Mode = Tran_Mode.Edit_Mode
                    'Btn_Delete.Enabled = True
                    Txt_Acc_Id.Focus()

                Else
                    MessageBox.Show("Prescription details not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Txt_Acc_Id.Text = ""
                    Txt_Acc_Id.Focus()
                    Exit Sub
                End If
            Else
                Txt_Acc_Id.Focus()
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Call Clear_Form()
        Txt_Acc_Id.Focus()
    End Sub

    Private Sub Txt_Presc_ID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs)
        If e.KeyCode = Keys.F2 Then
            Btn_Find_Click(sender, e)
        End If
    End Sub

    Private Sub Btn_Remove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Remove.Click
        Try
            If Dgv_Prescription.RowCount > 0 Then
                If MessageBox.Show("Are you sure wan't to remove the selected record ", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                    Dgv_Prescription.Rows.RemoveAt(Dgv_Prescription.CurrentRow.Index)
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Load_Prescription_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Load_Prescription.Click
        Try

            If Load_Prescription_Values(Cmb_Pres_Templates.SelectedValue) Then
                Cmb_Pres_Templates.Focus()
            End If

        Catch ex As Exception
        End Try
    End Sub

    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click
        Try
            'If Tr_Mode = Tran_Mode.New_Mode Then

            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If

            If Dgv_Prescription.Rows.Count = 0 Then
                MessageBox.Show("You have to locate details before deleting the record", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            If Txt_Acc_Id.Text.Trim = "" Then
                MessageBox.Show("Invalid Account ID ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_Acc_Id.Focus() : Exit Sub
            End If

            'Confirm before delete the record
            If MessageBox.Show("Are you sure wan't to delete the Prescription Details", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = Windows.Forms.DialogResult.No Then
                Exit Sub
            End If

            'Initialising BL Object
            Pat_Presc_BL = New Patient_Prescription_BL_Cls

            If Pat_Presc_BL.Delete_Patient_Prescription(Txt_Acc_Id.Text.Trim, Branch_Code) Then
                Call Btn_Clear_Click(sender, e)
            Else
                MessageBox.Show("You cannot delete Prescription Details" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Dgv_Prescription_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles Dgv_Prescription.CellMouseClick
        Try
            If e.RowIndex = -1 Then Exit Sub
            If e.ColumnIndex <> 7 Then Exit Sub

            Call Mark_RightHorizontal(e.RowIndex, Not Dgv_Prescription.Rows(e.RowIndex).Cells("Pres_Continue").Value)

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgv_Prescription_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Dgv_Prescription.DoubleClick
        Try
            'If Tr_Mode = Tran_Mode.Edit_Mode Then
            With Dgv_Prescription
                If .Rows.Count > 0 Then
                    IntSelectRow = .CurrentRow.Index
                    Txt_Medicine.Text = .Rows(.CurrentRow.Index).Cells("Medicine").Value.ToString.Trim
                    Txt_Dose.Text = .Rows(.CurrentRow.Index).Cells("Dose").Value.ToString.Trim
                    cmb_Frequency.Text = .Rows(.CurrentRow.Index).Cells("Freequency").Value.ToString.Trim
                    Cmb_Route.Text = .Rows(.CurrentRow.Index).Cells("Route").Value.ToString.Trim
                    Txt_Qty.Text = .Rows(.CurrentRow.Index).Cells("Qty").Value.ToString.Trim
                    Txt_Refils.Text = .Rows(.CurrentRow.Index).Cells("Refils").Value.ToString.Trim
                    Txt_Days.Text = .Rows(.CurrentRow.Index).Cells("Days").Value.ToString.Trim
                    If .Rows(.CurrentRow.Index).Cells("Pres_Continue").Value = 1 Then
                        Cmb_Continue.SelectedIndex = 0
                    Else
                        Cmb_Continue.SelectedIndex = 1
                    End If
                    If .Rows(.CurrentRow.Index).Cells("Pres_Continue").Value = 0 Then
                        DTP_Dis.Text = .Rows(.CurrentRow.Index).Cells("Dis_Dt").Value.ToString.Trim
                        'Else
                        '    Pat_Presc_BL.Pres_Discontinuedate = ""
                    End If
                    If .Rows(.CurrentRow.Index).Cells("Status").Value.ToString.Trim = "Yes" Then
                        Cmb_Stat.SelectedIndex = 0
                    Else
                        Cmb_Stat.SelectedIndex = 1
                    End If
                    Cmb_Pres_Templates.SelectedValue = .Rows(.CurrentRow.Index).Cells("Diagnos_Id").Value
                    Btn_Add.Text = "Save"
                    Btn_Add.Tag = "M"
                    Txt_Medicine.Focus()
                    Dgv_Prescription.ClearSelection()
                    Tr_Mode = Tran_Mode.Edit_Mode
                End If
            End With
            'End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_Physician_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_Physician.Validating
        Try
            If Txt_Physician.Text.Trim <> "" And Me.Txt_Physician.Text.Trim <> Me.Txt_Physician.Tag Then
                If GET_PhysicianName(Txt_Physician.Text.Trim) Then
                    e.Cancel = False
                    'Txt_Ref_DrID.Focus()
                Else
                    MessageBox.Show("Invalid Physcian", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Txt_Physician.Focus()
                    e.Cancel = True
                End If
            Else
                Cmb_Pres_Templates.Focus()
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Mark_RightHorizontal(ByVal Markrowindex As Integer, ByVal Mark As Boolean)
        Try
            With Dgv_Prescription

                .Rows(Markrowindex).Cells("Pres_Continue").Value = Mark
            End With
        Catch ex As Exception

        End Try
    End Sub

    Public Sub Btn_FindAccID_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_FindAccID.Click
        Try
            If Txt_Acc_Id.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "150|125|300|50"

                Sql = "SELECT [Patient Name], [S.S.No], ([Family Name] + Address + City) as Address, ACC_ID AS [PMR-ID]"
                Sql += "FROM Patient_Account_Vw WHERE ([Account Status] = 'Active')And Br_Code='" & Branch_Code & "'"
                'Sql = Sql + "Where Active = 'Y' or Active = 'N' and Cancelled = 'N' and (Deactivate_Date >= '" & Format(Tran_Date, "MM/dd/yyyy") & "') and Br_Code = '" & Branch_Code & "'"
                Call ShowSearchengine(Txt_Acc_Id, Sql, 3, "Patient Name", Colwidth, , 0)
            End If

            If Txt_Acc_Id.Text.Trim = "" Then
                Txt_Acc_Id.Focus() : Exit Sub
            End If

            'Locate patient details 
            If Fill_Acc_Details(Txt_Acc_Id.Text.Trim) Then
                Txt_Acc_Id.Tag = Txt_Acc_Id.Text.Trim
                If Tr_Mode = Tran_Mode.New_Mode Then
                    Cmb_Doctor.Focus()
                    Exit Sub
                Else
                    Txt_Acc_Id.Focus()
                    Exit Sub
                End If
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_Acc_Id_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Acc_Id.KeyDown
        If e.KeyCode = Keys.F2 Then
            Call Btn_FindAccID_Click(sender, e)
        End If
    End Sub

    Private Sub Txt_Acc_Id_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_Acc_Id.Validating
        Try
            If Txt_Acc_Id.Text.Trim <> "" And Me.Txt_Acc_Id.Text.Trim <> Me.Txt_Acc_Id.Tag Then
                If Locate_Values(Txt_Acc_Id.Text.Trim) Then
                    Btn_Delete.Enabled = True
                    'Tr_Mode = Tran_Mode.Edit_Mode
                    'Txt_Ref_DrID.Focus()
                Else
                    MessageBox.Show("Invalid PMR-ID", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Btn_Delete.Enabled = False
                    Tr_Mode = Tran_Mode.New_Mode
                    e.Cancel = True
                End If
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_SaveTemplate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_SaveTemplate.Click
        Try

            Dim dtbl As DataTable = Nothing
            Dim dr As DataTableReader = Nothing
            If Cmb_Pres_Templates.Text = "" Then
                MessageBox.Show("Invalid Diagnosis Name", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Cmb_Pres_Templates.Focus()
                Exit Sub
            End If
            If Dgv_Prescription.RowCount = 0 Then
                MessageBox.Show("Enter prescription details to save Template", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Txt_Medicine.Focus()
                Exit Sub
            End If
            hms_helper = New Hms_Helperimpliments
            ''To change the Status as Active = 'N' for the existing diagnosis template
            'If Not Validate_GridValues() Then Exit Sub
            Dim i As Integer = 0
            For i = 0 To Cmb_Pres_Templates.Items.Count - 1
                Dim x As Integer = 0
                With Dgv_Prescription
                    'Cmb_Pres_Templates.SelectedIndex = 0
                    For x = 0 To .Rows.Count - 1
                        Cmb_Pres_Templates.SelectedIndex = i
                        If Cmb_Pres_Templates.SelectedValue = .Rows(x).Cells("Diagnos_Id").Value Then
                            hms_helper.Delete_Prescription_Template(Cmb_Pres_Templates.SelectedValue, Branch_Code)
                            Exit For
                        End If
                    Next
                End With
            Next

            Pat_Presc_BL = New Patient_Prescription_BL_Cls
            prec_Template = New Prescription_Template_BL_Cls
            Dim PresDtbl As DataTable = Nothing

            With Dgv_Prescription
                For i = 0 To .Rows.Count - 1
                    prec_Template.Pres_Date = Dtp_TranDate.Value
                    prec_Template.Pres_Medicine_Name = .Rows(i).Cells("Medicine").Value.ToString.Trim
                    prec_Template.Pres_Dose = .Rows(i).Cells("Dose").Value.ToString.Trim
                    prec_Template.Pres_Frequency = .Rows(i).Cells("Freequency").Value.ToString.Trim
                    prec_Template.Pres_Route = .Rows(i).Cells("Route").Value.ToString.Trim
                    prec_Template.Pres_Quantity = .Rows(i).Cells("Qty").Value.ToString.Trim
                    prec_Template.Pres_Refills = .Rows(i).Cells("Refils").Value.ToString.Trim
                    prec_Template.Pres_NoofDays = .Rows(i).Cells("Days").Value.ToString.Trim
                    prec_Template.Active = "Y"

                    prec_Template.Save_Prescription_Template(dtbl, 0, .Rows(i).Cells("Diagnos_Id").Value, Tran_Mode.New_Mode)

                Next
            End With
            dtbl = Nothing
            PresDtbl = Nothing
            MessageBox.Show("Prescription Templates Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Call Btn_Save_Click(sender, e)
            Form_Closing = True
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Cmb_Continue_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_Continue.SelectedIndexChanged
        Try
            If Cmb_Continue.Text = "No" Then
                DTP_Dis.Enabled = True
            Else
                DTP_Dis.Enabled = False
            End If
        Catch ex As Exception

        End Try

    End Sub

   
    Private Sub Txt_Acc_Id_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Acc_Id.TextChanged

    End Sub

    Private Sub Txt_Qty_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Qty.TextChanged

    End Sub
End Class