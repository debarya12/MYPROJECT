﻿
Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls

Public Class DoctorMaster_Frm

#Region "Declarations"
    'Object of Employee Details Bussiness Layer

    Private hms_helper As HMS_Helper = Nothing
    Private Doctor_BL As DoctorMaster_BL_Cls
    Private mTr_Mode As Tran_Mode

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing
    Private IsHandleAdded As Boolean

    Private CellRowindex As Integer
    Private CellColindex As Integer


    Private GrDtbl As DataTable

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_DoctorID.BackColor = Color.White
                    Me.Txt_DoctorID.ReadOnly = False
                    Me.Txt_EmpID.BackColor = Color.White
                    Me.Txt_EmpID.ReadOnly = False
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_DoctorID.BackColor = Color.Silver
                    Me.Txt_DoctorID.ReadOnly = True
                    Me.Txt_EmpID.BackColor = Color.Silver
                    Me.Txt_EmpID.ReadOnly = True
            End Select
        End Set
    End Property

#End Region

#Region "Methods"

    Private Sub AssignToControl(ByVal dtbl As DataTable)
        Try

            Dim dr As DataTableReader = Nothing
            dr = dtbl.CreateDataReader()
            dr.Read()

            With dr
                Txt_DoctorID.Text = .Item("Doc_ID").ToString
                Txt_DoctorID.Tag = .Item("Doc_ID").ToString
                Txt_EmpID.Text = .Item("Emp_ID").ToString
                Txt_EmpID.Tag = .Item("Emp_ID").ToString
                Cmb_DocCategory.SelectedValue = .Item("Doc_Categroy").ToString
            End With
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Clear_Form()
        Try

            Txt_DoctorID.Tag = ""
            Txt_DoctorID.Text = ""
            Txt_EmpID.Text = ""
            Txt_EmpID.Tag = ""
            Lbl_DocID.Tag = ""

            Txt_DoctorFee.Text = ""

            If Cmb_DocCategory.Items.Count > 0 Then Cmb_DocCategory.SelectedIndex = 0
            If Cmb_FeeCalcMethod.Items.Count > 0 Then Cmb_FeeCalcMethod.SelectedIndex = 0
            If Cmb_status.Items.Count > 0 Then Cmb_status.SelectedIndex = 0
            REM List box Clear functions

            Clear_ListBox(chk_Doctor_Splization)

            Call Clear_GridView()

            Tr_Mode = Tran_Mode.New_Mode
            Btn_Save.Enabled = True
            Btn_Delete.Enabled = False

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Clear_GridView()
        Try

            With Dgvw_Services
                For i = 0 To .Rows.Count - 1
                    .CurrentCell = Dgvw_Services(0, i)
                    Dim CheckCell As DataGridViewCheckBoxCell = _
                    CType(.Rows(i).Cells("Mark"), DataGridViewCheckBoxCell)
                    CheckCell.Value = False

                    .Rows(i).Cells("Commission").Value = ""
                    .Rows(i).Cells("Type").Value = "< NA >"
                Next

            End With


            With Dgv_Doc_Achivements
                Dgv_Doc_Achivements.RowCount = 0
                For i = 0 To .Rows.Count - 1
                    .Rows(i).Cells("slno").Value = ""
                    .Rows(i).Cells("Achievements").Value = ""
                Next
            End With

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Clear_ListBox(ByVal ListCntrol As CheckedListBox)
        Try
            Dim CNT As Integer
            For CNT = 0 To ListCntrol.Items.Count - 1
                ListCntrol.SetItemChecked(CNT, False)
            Next
            ListCntrol.SetSelected(0, True)
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try

    End Sub

    Private Function Validate_Fields() As Boolean
        Try
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If

            If Tr_Mode <> Tran_Mode.New_Mode Then
                If Txt_DoctorID.Text.Trim = "" Then MessageBox.Show("Invalid Doctor ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_DoctorID.Focus() : Exit Function
            End If
            'Assigning Default values
            If Txt_EmpID.Text.Trim = "" Then MessageBox.Show("Invalid Employee ID, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_EmpID.Focus() : Exit Function
            If Cmb_DocCategory.SelectedIndex = 0 Then MessageBox.Show("Invalid Category, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_DocCategory.Focus() : Exit Function
            If Cmb_FeeCalcMethod.SelectedIndex = 0 Then MessageBox.Show("Invalid Fee Calculation Method, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_FeeCalcMethod.Focus() : Exit Function
            If Val(Txt_DoctorFee.Text) <= 0 Then
                If MessageBox.Show("Invalid Doctor Fee amount, Continue Save ?", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.No Then
                    Txt_DoctorFee.Focus()
                    Exit Function
                End If
            End If

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Validate_GridView() As Boolean
        Try

            With Dgvw_Services
                For i_Ctr = 0 To .Rows.Count - 1


                    Dim CheckCell As DataGridViewCheckBoxCell = _
                    CType(Dgvw_Services.Rows(i_Ctr).Cells("Mark"), DataGridViewCheckBoxCell)

                    If CheckCell.Value = True Then


                        If Val(Dgvw_Services.Rows(i_Ctr).Cells("Commission").Value) < 0 Then _
                       MessageBox.Show("Invalid Commission amount, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Return False


                        If Val(Dgvw_Services.Rows(i_Ctr).Cells("Commission").Value) > 0 Then
                            If Dgvw_Services.Rows(i_Ctr).Cells("Type").Value.ToString.ToUpper.Trim = "< NA >" Then _
                           MessageBox.Show("Invalid Commission Type Selection, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Return False
                        End If

                        If Strings.Left(Dgvw_Services.Rows(i_Ctr).Cells("Type").Value.ToString.ToUpper.Trim, 1) = "P" Then

                            If Val(Dgvw_Services.Rows(i_Ctr).Cells("Commission").Value) > 100 Then _
                      MessageBox.Show("Invalid Percentage amount, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Return False

                        End If


                    End If

                Next
            End With
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    'Public Function Locate_Employee(ByVal Employee_ID As Integer) As Boolean
    '    Try
    '        Dim dtbl As DataTable = Nothing
    '        Dim dr As DataTableReader = Nothing

    '        hms_helper = New Hms_Helperimpliments
    '        If hms_helper.GetEmp_Details(dtbl, Employee_ID) Then
    '            dr = dtbl.CreateDataReader
    '            dr.Read()
    '            With dr
    '                Txt_DoctorName.Text = dr.Item("Name").ToString

    '                Dim strAddress As String = ""

    '                strAddress = dr.Item("address").ToString + vbCrLf
    '                strAddress = strAddress + "Security Number      :   " + dr.Item("SS_Number").ToString + vbCrLf
    '                strAddress = strAddress + "Designation               :   " + dr.Item("Designation").ToString + vbCrLf

    '                Txt_DoctorAdd.Text = strAddress


    '            End With

    '            Return True
    '        Else
    '            Return False
    '        End If

    '    Catch ex As Exception
    '        Return False
    '    End Try
    'End Function

    Public Function Locate_Values(ByVal Doc_ID As Integer) As Boolean
        Try
            Dim dtbl As DataTable = Nothing
            Dim dr As DataTableReader = Nothing

            Doctor_BL = New DoctorMaster_BL_Cls
            If Doctor_BL.Get_EmpDetailsFromDoctorID(dtbl, Doc_ID) Then

                Txt_EmpID.Text = dtbl.Rows(0).Item("EmpID").ToString
                Cmb_status.Text = IIf(dtbl.Rows(0).Item("Active").ToString = "Y", "Yes", "No")
                Cmb_DocCategory.SelectedValue = dtbl.Rows(0).Item("Doc_Category").ToString
                Lbl_DocID.Tag = dtbl.Rows(0).Item("Reg_Date").ToString

                Call Select_Doctor_Services(Txt_DoctorID.Text.Trim)
                Call Select_Doctor_Splization(Txt_DoctorID.Text.Trim)
                Call Locate_DoctorFeeDetails(Txt_DoctorID.Text.Trim)
                Call Locate_Doctor_Achivements(Txt_DoctorID.Text.Trim)
                Txt_Achivements.Focus()

                Return True

            Else
                Return False
            End If

        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function Locate_DoctorFeeDetails(ByVal Doc_ID As Integer) As Boolean
        Try
            Dim dtbl As DataTable = Nothing
            Dim dr As DataTableReader = Nothing

            Doctor_BL = New DoctorMaster_BL_Cls
            If Doctor_BL.Get_Doctor_FeeDetails(dtbl, Doc_ID) Then
                dr = dtbl.CreateDataReader
                dr.Read()
                With dr

                    Cmb_FeeCalcMethod.SelectedValue = .Item("Fee_Calcmethod").ToString
                    Txt_DoctorFee.Text = .Item("Fee_Amount").ToString

                    Return True
                End With
            Else
                Return False
            End If

        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function Is_Doctor_Registered(ByVal Emp_ID As Integer, ByRef Doc_ID As String) As Integer
        Try
            Doctor_BL = New DoctorMaster_BL_Cls
            Dim dtbl As DataTable = Nothing
            Dim dr As DataTableReader = Nothing

            dr = Nothing
            dtbl = Nothing
            If Doctor_BL.Is_Doctor_Registered(dtbl, Emp_ID) > 0 Then
                Doc_ID = dtbl.Rows(0).Item(0).ToString
                Return dtbl.Rows(0).Item(0).ToString
            Else
                Return 0
            End If

        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Sub Select_Doctor_Services(ByVal Doc_ID As Integer)
        Try
            Dim cntInt As Integer
            Dim dtbl As DataTable = Nothing
            Dim dr As DataTableReader = Nothing
            dr = Nothing
            dtbl = Nothing
            Dim Sel_Text As String = ""
            Dim Sel_Value As String = ""

            If Doctor_BL.Get_Doctorservices(dtbl, Doc_ID, Tran_Date) Then
                dr = dtbl.CreateDataReader

                While dr.Read
                    With dr
                        For cntInt = 0 To Dgvw_Services.Rows.Count - 1


                            If Dgvw_Services.Rows(cntInt).Cells("Services").Value.ToUpper.Trim = .Item("Service_Name").ToString.ToUpper.Trim Then

                                Dgvw_Services.CurrentCell = Dgvw_Services(0, cntInt)
                                Dim CheckCell As DataGridViewCheckBoxCell = _
                                CType(Dgvw_Services.Rows(cntInt).Cells("Mark"), DataGridViewCheckBoxCell)
                                CheckCell.Value = True

                                Dgvw_Services.CurrentCell = Dgvw_Services(2, cntInt)
                                If .Item("CommisionType").ToString.ToUpper.Trim = "F" Then
                                    Dgvw_Services.Rows(cntInt).Cells("Type").Value = "Fixed"
                                ElseIf .Item("CommisionType").ToString.ToUpper.Trim = "P" Then
                                    Dgvw_Services.Rows(cntInt).Cells("Type").Value = "Percentage"
                                Else
                                    Dgvw_Services.Rows(cntInt).Cells("Type").Value = "< NA >"
                                End If

                                Dgvw_Services.CurrentCell = Dgvw_Services(3, cntInt)
                                Dgvw_Services.Rows(cntInt).Cells("Commission").Value = dr.Item("commision").ToString


                            End If


                        Next
                    End With
                End While
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Public Sub Locate_Doctor_Achivements(ByVal Doc_ID As Integer)
        Try

            Dim dtbl As DataTable = Nothing
            dtbl = Nothing

            If Doctor_BL.Get_Doctor_Achivements(dtbl, Doc_ID, Tran_Date) Then
                With Dgv_Doc_Achivements
                    .RowCount = 0

                    For i = 0 To dtbl.Rows.Count - 1
                        .Rows.Add()
                        .Rows(.Rows.Count - 1).Cells("Sl_No").Value = .Rows.Count
                        .Rows(.Rows.Count - 1).Cells("Achivements").Value = dtbl.Rows(i).Item("Achivements").ToString

                    Next
                End With
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Public Function IsInsert_Doctor_Achivements(ByVal Doc_ID As Integer) As Boolean
        Try

            Dim dtbl As DataTable = Nothing
            dtbl = Nothing

            If Doctor_BL.Get_Doctor_Achivements(dtbl, Doc_ID, Tran_Date) Then

                If dtbl.Rows.Count <> Dgv_Doc_Achivements.Rows.Count Then Return True

                With Dgv_Doc_Achivements
                    For i = 0 To dtbl.Rows.Count - 1

                        If .Rows(i).Cells("Achivements").Value.ToString.Trim <> _
                        dtbl.Rows(i).Item("Achivements").ToString.Trim Then Return True

                    Next
                    Return False
                End With
            Else
                Return True
            End If


        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function Validate_Doctor_Splisations() As Boolean
        Try
            If chk_Doctor_Splization.CheckedItems.Count > 0 Then
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function IsInsert_Doctor_Feesettings(ByVal Doc_ID As Integer) As Boolean
        Try

            Dim dtbl As DataTable = Nothing
            dtbl = Nothing

            If Doctor_BL.Get_Doctor_FeeDetails(dtbl, Doc_ID) Then

                If Cmb_FeeCalcMethod.SelectedValue <> dtbl.Rows(0).Item("Fee_Calcmethod").ToString.Trim Then Return True
                If Cmb_DocCategory.SelectedValue <> dtbl.Rows(0).Item("Fee_Calcmethod").ToString.Trim Then Return True
                If Txt_DoctorFee.Text.Trim <> dtbl.Rows(0).Item("Fee_Amount").ToString.Trim Then Return True

                Return False

            Else
                Return True
            End If


        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function Validate_Doctor_Services() As Boolean
        Try


            Dim cntInt As Integer = 0

            For i = 0 To Dgvw_Services.Rows.Count - 1

                Dgvw_Services.CurrentCell = Dgvw_Services(0, i)
                Dim CheckCell As DataGridViewCheckBoxCell = _
                CType(Dgvw_Services.Rows(i).Cells("Mark"), DataGridViewCheckBoxCell)

                If CheckCell.Value = True Then cntInt = cntInt + 1
            Next


            If cntInt = 0 Then Return False
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function


    Public Function Isinsert_DoctorServices(ByVal Doc_ID As Integer) As Boolean
        Try

            Dim dtbl As DataTable = Nothing
            dtbl = Nothing
            Dim cntInt As Integer = 0
            cntInt = 0
            For i = 0 To Dgvw_Services.Rows.Count - 1

                Dgvw_Services.CurrentCell = Dgvw_Services(0, i)
                Dim CheckCell As DataGridViewCheckBoxCell = _
                CType(Dgvw_Services.Rows(i).Cells("Mark"), DataGridViewCheckBoxCell)

                If CheckCell.Value = True Then cntInt = cntInt + 1
            Next

            If cntInt = 0 Then Return False

            If Doctor_BL.Get_Doctorservices(dtbl, Doc_ID, Tran_Date) Then

                If dtbl.Rows.Count <> cntInt Then Return True


                With Dgvw_Services

                    For i = 0 To .Rows.Count - 1

                        Dgvw_Services.CurrentCell = Dgvw_Services(0, i)
                        Dim CheckCell As DataGridViewCheckBoxCell = _
                        CType(Dgvw_Services.Rows(i).Cells("Mark"), DataGridViewCheckBoxCell)


                        If CheckCell.Value = True Then
                            If .Rows(i).Cells("Commission").Value.ToString.Trim <> _
                                        dtbl.Rows(i).Item("Commision").ToString.Trim Then Return True
                        End If

                    Next
                    Return False
                End With

            Else
                Return True
            End If


        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Sub Select_Doctor_Splization(ByVal Doc_ID As Integer)
        Try
            Dim cntInt As Integer
            Dim dtbl As DataTable = Nothing
            Dim dr As DataTableReader = Nothing
            dr = Nothing
            dtbl = Nothing
            Dim Sel_Text As String = ""
            Dim Sel_Value As String = ""

            If Doctor_BL.Get_DoctorSplization(dtbl, Doc_ID) Then
                dr = dtbl.CreateDataReader

                While dr.Read
                    With dr
                        For cntInt = 0 To chk_Doctor_Splization.Items.Count - 1
                            chk_Doctor_Splization.SelectedIndex = cntInt
                            If Selectlist_Item_Value(chk_Doctor_Splization, Sel_Text, Sel_Value) Then

                                If Sel_Text.ToUpper.Trim = .Item("Specialization").ToString.ToUpper.Trim Then
                                    chk_Doctor_Splization.SetItemChecked(cntInt, True)
                                    chk_Doctor_Splization.SetSelected(cntInt, True)
                                End If

                            End If

                        Next
                    End With
                End While
            End If
        Catch ex As Exception

        End Try
    End Sub

    Public Function Save_Doctor_Service() As Boolean
        Dim Sel_Text As String = ""
        Dim Sel_Value As String = ""
        Dim Dtbl As DataTable = Nothing

        Try



            Doctor_BL = New DoctorMaster_BL_Cls


            REM DELETING MARKED DOCTOR ACTIVITIES. 
            Doctor_BL.Doc_ID = Txt_DoctorID.Text.Trim
            If Doctor_BL.Del_Doctor_Services(Txt_DoctorID.Text.Trim) Then


                With Dgvw_Services
                    For i_Ctr = 0 To .Rows.Count - 1


                        Dim CheckCell As DataGridViewCheckBoxCell = _
                        CType(Dgvw_Services.Rows(i_Ctr).Cells("Mark"), DataGridViewCheckBoxCell)

                        If CheckCell.Value = True Then
                            REM SAVE DOCTOR ACTIVITIES
                            Doctor_BL.Service_ID = Dgvw_Services.Rows(i_Ctr).Cells("ServiceID").Value.ToString.Trim
                            Doctor_BL.Doc_ID = Txt_DoctorID.Text.Trim
                            Doctor_BL.Reg_Date = Tran_Date
                            Doctor_BL.CommissionType = IIf(Strings.Left(Dgvw_Services.Rows(i_Ctr).Cells("Type").Value.ToString.ToUpper.Trim, 1) _
                                                     = "<", "", Strings.Left(Dgvw_Services.Rows(i_Ctr).Cells("Type").Value.ToString.ToUpper.Trim, 1))
                            Doctor_BL.Commission = Val(Dgvw_Services.Rows(i_Ctr).Cells("Commission").Value.ToString.Trim)
                            If Doctor_BL.Save_DoctorServices(Dtbl, Tr_Mode, Val(Txt_DoctorID.Text.Trim)) Then
                                If Dtbl.Rows(0).Item(0).ToString = "0" Then Return False
                            End If

                        End If
                    Next
                End With
                Return True


            Else
                Return False
            End If
        Catch ex As Exception
            Return False
        Finally
            Sel_Text = Nothing
            Sel_Value = Nothing
            Dtbl = Nothing

        End Try
    End Function

    Private Function Save_Doctor_Splzations() As Boolean

        Dim Sel_Text As String = ""
        Dim Sel_Value As String = ""
        Dim Dtbl As DataTable = Nothing

        Try

            Doctor_BL = New DoctorMaster_BL_Cls


            REM DELETING MARKED DOCTOR SPLZATIONS. 
            Doctor_BL.Doc_ID = Txt_DoctorID.Text.Trim
            If Doctor_BL.Del_DoctorSplzation(Txt_DoctorID.Text.Trim) Then


                With chk_Doctor_Splization
                    For i_Ctr = 0 To .Items.Count - 1
                        If .GetItemCheckState(i_Ctr) = CheckState.Checked Then
                            .SelectedIndex = i_Ctr
                            If Selectlist_Item_Value(chk_Doctor_Splization, Sel_Text, Sel_Value) Then
                                REM SAVE DOCTOR SPLZATIONS
                                Doctor_BL.Spec_ID = Sel_Value
                                Doctor_BL.Doc_ID = Txt_DoctorID.Text.Trim
                                Doctor_BL.Reg_Date = Tran_Date
                                If Doctor_BL.Save_DoctorSplzations(Dtbl, Tr_Mode, Txt_DoctorID.Text.Trim) Then
                                    If Dtbl.Rows(0).Item(0).ToString = "0" Then Return False
                                End If

                            End If
                        End If
                    Next
                End With
                Return True


            Else
                Return False
            End If
        Catch ex As Exception
            Return False
        Finally
            Sel_Text = Nothing
            Sel_Value = Nothing
            Dtbl = Nothing

        End Try
    End Function

    Public Function Save_Doctor_Achivements() As Boolean
        Dim Sel_Text As String = ""
        Dim Sel_Value As String = ""
        Dim Dtbl As DataTable = Nothing

        Try

            Doctor_BL = New DoctorMaster_BL_Cls


            REM DELETING DOCTOR ACHIVEMENTS ON CURRENT DATE. 
            Doctor_BL.Doc_ID = Txt_DoctorID.Text.Trim
            If Doctor_BL.Del_Doctor_Achivements(Txt_DoctorID.Text.Trim) Then


                With Dgv_Doc_Achivements
                    For i_Ctr = 0 To .Rows.Count - 1


                        REM SAVE DOCTOR ACHIVEMENTS
                        Doctor_BL.Achivements = .Rows(i_Ctr).Cells("Achivements").Value.ToString.Trim
                        Doctor_BL.Doc_ID = Txt_DoctorID.Text.Trim
                        Doctor_BL.Reg_Date = Tran_Date
                        If Doctor_BL.Save_Doctor_Achivements(Dtbl, Tr_Mode, Val(Txt_DoctorID.Text.Trim)) Then
                            If Dtbl.Rows(0).Item(0).ToString = "0" Then Return False
                        End If

                    Next
                End With
                Return True


            Else
                Return False
            End If
        Catch ex As Exception
            Return False
        Finally
            Sel_Text = Nothing
            Sel_Value = Nothing
            Dtbl = Nothing

        End Try
    End Function

    Private Function Save_DoctorFee_Details() As Boolean
        Dim Dtbl As DataTable = Nothing

        Try

            Doctor_BL = New DoctorMaster_BL_Cls


            REM DELETING MARKED DOCTOR FEE. 
            Doctor_BL.Doc_ID = Txt_DoctorID.Text.Trim
            Doctor_BL.DocFee_ID = 0
            Doctor_BL.Fee_Calcmethod = Cmb_FeeCalcMethod.SelectedValue
            Doctor_BL.Fee_Amount = Val(Txt_DoctorFee.Text)
            Doctor_BL.Reg_Date = Tran_Date
            Call Doctor_BL.Del_Doctor_Fee(Txt_DoctorID.Text.Trim)

            If Doctor_BL.Save_DoctorFee_Details(Dtbl, Tr_Mode, Txt_DoctorID.Text.Trim) Then
                If Dtbl.Rows(0).Item(0).ToString = "0" Then Return False
                Return True
            Else
                Return False
            End If



        Catch ex As Exception
            Return False
        Finally

            Dtbl = Nothing

        End Try
    End Function

    Public Sub Set_PositionCombo()
        Try

            With Dgvw_Services


                If .Columns(.CurrentCell.ColumnIndex).Name = "Type" Then


                    Dim TextType As DataGridViewTextBoxCell = _
                    CType(.Rows(.CurrentCell.RowIndex).Cells("Type"), DataGridViewTextBoxCell)
                    If TextType.Tag = False Then Exit Sub


                    Dim X As Integer = .GetCellDisplayRectangle(.CurrentCell.ColumnIndex, .CurrentCell.RowIndex, False).Left + .Left
                    Dim Y As Integer = .GetCellDisplayRectangle(.CurrentCell.ColumnIndex, .CurrentCell.RowIndex, False).Bottom + .Top
                    Cmb_CommType.Location = New Point(X, Y - 20)
                    Cmb_CommType.Text = .Item(.CurrentCell.ColumnIndex, .CurrentCell.RowIndex).Value
                    Cmb_CommType.Visible = True
                    Cmb_CommType.BringToFront()
                    'Cmb_CommType.Focus()
                Else
                    Cmb_CommType.Visible = False
                End If
            End With

        Catch ex As Exception

        End Try
    End Sub

    Private Function Set_GridViewColumn() As Boolean
        Try
            Dim Col_1 As New DataGridViewCheckBoxColumn
            Dim Col_2 As New DataGridViewTextBoxColumn
            Dim Col_3 As New DataGridViewTextBoxColumn
            Dim Col_4 As New DataGridViewTextBoxColumn
            Dim Col_5 As New DataGridViewTextBoxColumn

            Cmb_CommType.Items.Add("< NA >")
            Cmb_CommType.Items.Add("Fixed")
            Cmb_CommType.Items.Add("Percentage")
            Cmb_CommType.SelectedIndex = 0


            Col_1.Name = "Mark"
            Col_1.HeaderText = ""
            Col_1.Width = 30
            Col_1.SortMode = DataGridViewColumnSortMode.NotSortable

            Col_2.Name = "Services"
            Col_2.HeaderText = "Services"
            Col_2.Width = 150
            Col_2.ReadOnly = True
            Col_2.SortMode = DataGridViewColumnSortMode.NotSortable



            Col_3.Name = "Type"
            Col_3.HeaderText = "Type"
            Col_3.Width = 90
            Col_3.ReadOnly = True
            Col_3.SortMode = DataGridViewColumnSortMode.NotSortable


            Col_4.Name = "Commission"
            Col_4.HeaderText = "Commission"
            Col_4.Width = 100
            Col_4.ReadOnly = True
            Col_4.SortMode = DataGridViewColumnSortMode.NotSortable


            Col_5.Name = "ServiceID"
            Col_5.HeaderText = ""
            Col_5.Visible = False
            Col_5.SortMode = DataGridViewColumnSortMode.NotSortable


            With Dgvw_Services
                .Columns.Add(Col_1)
                .Columns.Add(Col_2)
                .Columns.Add(Col_3)
                .Columns.Add(Col_4)
                .Columns.Add(Col_5)

            End With

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Sub Populate_GridView()
        Try
            Dim dtbl As DataTable
            dtbl = Nothing

            If hms_helper.Get_ServiceDetails(dtbl, Branch_Code) > 0 Then
                Dr = dtbl.CreateDataReader
                Dgvw_Services.RowCount = dtbl.Rows.Count

                With Dgvw_Services
                    For i = 0 To dtbl.Rows.Count - 1

                        .Rows(i).Cells("Services").Value = dtbl.Rows(i).Item("Service Name").ToString
                        .Rows(i).Cells("ServiceID").Value = dtbl.Rows(i).Item("Service_ID").ToString
                        .Rows(i).Cells("Type").Value = "< NA >"

                    Next
                End With
            End If
        Catch ex As Exception

        End Try
    End Sub

#End Region

    Private Sub DoctorMaster_Frm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            hms_helper = New Hms_Helperimpliments


            Call Set_GridViewColumn()
            Call Populate_GridView()

            Cmb_FeeCalcMethod.Items.Add("< Select >")
            Cmb_FeeCalcMethod.Items.Add("Fixed")
            Cmb_FeeCalcMethod.Items.Add("Percentage")
            Cmb_FeeCalcMethod.SelectedIndex = 0

            Cmb_status.Items.Add("Yes")
            Cmb_status.Items.Add("No")
            Cmb_status.SelectedIndex = 0

            hms_helper.Fill_DoctorSplzations(chk_Doctor_Splization)
            hms_helper.Fill_GenData(Cmb_DocCategory, Gendatatype.Doctor_Category, "< Select >")
            hms_helper.Fill_GenData(Cmb_FeeCalcMethod, Gendatatype.Fee_Calculation_Methods, "< Select >")

        Catch ex As Exception


        End Try
    End Sub

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try
            Dim Dr As DataTableReader = Nothing
            Dim Dtbl As DataTable = Nothing


            Doctor_BL = New DoctorMaster_BL_Cls


            'Validating Data controls
            If Not Validate_Fields() Then Exit Sub

            'Validating DataGridView controls
            If Not Validate_GridView() Then Exit Sub


            If Not Validate_Doctor_Services() Then
                MessageBox.Show("Invalid Service Selection, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Sub
            End If


            With Doctor_BL

                .Doc_ID = IIf(Tr_Mode <> Tran_Mode.New_Mode, Txt_DoctorID.Text.Trim, 0)
                .Emp_ID = Txt_EmpID.Text.Trim
                .Doc_Catagory = Cmb_DocCategory.SelectedValue
                .Reg_Date = Tran_Date
                .Active = Strings.Left(Cmb_status.Text, 1).ToUpper
                .Deactivate_Date = Tran_Date
                .Last_Updated = Tran_Date


                Dtbl = Nothing
                If Doctor_BL.Save_DoctorMaster(Dtbl, Tr_Mode, IIf(Tr_Mode <> Tran_Mode.New_Mode, Txt_DoctorID.Text.Trim, 0)) Then
                    If Dtbl.Rows(0).Item("Transtatus").ToString = "0" Then
                        MessageBox.Show("Doctor Details Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                        Exit Sub
                    End If

                    Call AssignToControl(Dtbl)

                    If Validate_Doctor_Splisations() Then
                        If Not Save_Doctor_Splzations() Then
                            MessageBox.Show("Error Occured While Saving Doctor Specialisation" + vbCrLf + "Doctor Registration Revert Back", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                            GoTo Error_Point
                        End If
                    End If

                    If Isinsert_DoctorServices(Txt_DoctorID.Text.Trim) Then
                        If Not Save_Doctor_Service() Then
                            MessageBox.Show("Error Occured While Saving Doctor Services" + vbCrLf + "Doctor Registration Revert Back", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                            GoTo Error_Point
                        End If
                    End If

                    If IsInsert_Doctor_Feesettings(Txt_DoctorID.Text.Trim) Then
                        If Not Save_DoctorFee_Details() Then
                            MessageBox.Show("Error Occured While Saving Doctor Fee Settings" + vbCrLf + "Doctor Registration Revert Back", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                            GoTo Error_Point
                        End If
                    End If

                    If IsInsert_Doctor_Achivements(Txt_DoctorID.Text.Trim) Then
                        If Not Save_Doctor_Achivements() Then
                            MessageBox.Show("Error Occured While Saving Doctor Achivements" + vbCrLf + "Doctor Registration Revert Back", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                            GoTo Error_Point
                        End If
                    End If

                    Tr_Mode = Tran_Mode.Edit_Mode
                    MessageBox.Show("Doctor Details Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Btn_Clear.Focus()
                Else
                    MessageBox.Show("Doctor Registration Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If

            End With
Exit_point:
            Return
Error_Point:
            Dtbl = Nothing
            If Doctor_BL.Revert_Doctor_Details(Dtbl, Tr_Mode, Tran_Date, Txt_DoctorID.Text.Trim, Branch_Code) Then
                If Dtbl.Rows(0).Item(0).ToString = "0" Then
                    MessageBox.Show("Error Occured While Reverting Doctor Registration,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Call Clear_Form()
        Txt_DoctorID.Focus()
    End Sub

    Private Sub DoctorMaster_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then Call SendKeyTab()
    End Sub

    Private Sub DoctorMaster_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub Btn_Find1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find1.Click
        Try

            If Txt_EmpID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "10|200|50|"
                Sql = "SELECT * FROM GetEmployeeDetailsAll_Vw where Br_Code='" & Branch_Code & "'"
                Call ShowSearchengine(Txt_EmpID, Sql, 0, "Name", Colwidth, , 0)
            End If

            If Txt_EmpID.Text.Trim = "" Then
                Txt_EmpID.Focus() : Exit Sub
            End If

            If Is_Doctor_Registered(Txt_EmpID.Text.Trim, Txt_DoctorID.Text) Then
                MessageBox.Show("This employee already registered as Doctor", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Btn_Find_Click(sender, e)
                Exit Sub
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try

            If Txt_DoctorID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "10|200|50|"
                Sql = "SELECT     DoctorID, Name, Address, Designation, EmpID,SS_Number as [SS Number]  FROM    Doctormaster_Vw where Br_Code='" & Branch_Code & "'"
                Call ShowSearchengine(Txt_DoctorID, Sql, 0, "Name", Colwidth, , 0)
            End If

            If Txt_DoctorID.Text.Trim = "" Then
                Txt_DoctorID.Focus() : Exit Sub
            End If

            Call Clear_GridView()
            'Locate Employee details 
            If Locate_Values(Txt_DoctorID.Text.Trim) Then
                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Delete.Enabled = True
                'Get Docotor Details exist
                If Is_Doctor_Registered(Txt_EmpID.Text.Trim, "") Then
                    'Txt_DoctorID.Text = IsDoctor(Txt_EmpID.Text.Trim)
                    Tr_Mode = Tran_Mode.Edit_Mode
                    Txt_Achivements.Focus()
                    'Mark Doctor Activities 
                    'Call Select_Doctor_Services(Txt_DoctorID.Text.Trim)
                    'Mark Doctor Spliztions 
                    'Call Select_Doctor_Splization(Txt_DoctorID.Text.Trim)
                End If

            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_DoctorID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_DoctorID.KeyDown
        If e.KeyCode = Keys.F2 Then Btn_Find_Click(sender, e)
    End Sub

    Private Sub Txt_EmpID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_EmpID.KeyDown
        If e.KeyCode = Keys.F2 Then Btn_Find1_Click(sender, e)
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click
        Try

            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If

            'Validating Mandatory fields for Deleting
            If Tr_Mode = Tran_Mode.New_Mode Then
                MessageBox.Show("You have to locate details before deleting the record", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

            If Txt_DoctorID.Text.Trim = "" Then
                MessageBox.Show("Invalid Docotor ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_DoctorID.Focus() : Exit Sub
            End If

            If DateDiff(DateInterval.Day, Tran_Date, Lbl_DocID.Tag) <> 0 Then
                MessageBox.Show("Deletion is possible on Registered Date, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
            Doctor_BL = New DoctorMaster_BL_Cls

            If MessageBox.Show("Are you sure wan't to delete the selected Doctor", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                Dtbl = Nothing

                'to delete doctor master also change the tran mode to new mode
                If Doctor_BL.Revert_Doctor_Details(Dtbl, Tran_Mode.New_Mode, Tran_Date, Txt_DoctorID.Text.Trim, Branch_Code) Then
                    If Dtbl.Rows(0).Item(0).ToString = "0" Then
                        MessageBox.Show("Error Occured While Reverting Doctor Registration,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                    MessageBox.Show("Doctor Details Deleted Successfuly", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Call Clear_Form()
                End If
            End If


        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_DoctorID_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_DoctorID.KeyPress
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_DoctorID.Text, Data_Type.Double_Type, 5))
    End Sub

    Private Sub Txt_DoctorID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_DoctorID.TextChanged
        If Txt_DoctorID.Text.Trim = "" Then
            Call Clear_Form()
        End If
    End Sub

    Private Sub Txt_DoctorID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_DoctorID.Validating
        Try
            If Me.Txt_DoctorID.Text.Trim <> "" And Me.Txt_DoctorID.Text <> Me.Txt_DoctorID.Tag Then
                If Locate_Values(Txt_DoctorID.Text.Trim) Then

                    Tr_Mode = Tran_Mode.Edit_Mode
                    Btn_Delete.Enabled = True
                Else
                    MessageBox.Show("Doctor ID does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Txt_DoctorID.Focus()
                    e.Cancel = True
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_EmpID_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_EmpID.KeyPress
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_EmpID.Text, Data_Type.Double_Type, 5))
    End Sub

    Private Sub Txt_EmpID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_EmpID.TextChanged
        Try
            With Employee_Info1
                .Viewmoreform_Name = "Employee_InfoSheet_Frm"
                .MDIform_Name = Me.MdiParent
                .Employee_ID = Txt_EmpID.Text.Trim
            End With
            With Imageviewer1
                .CUST_TYPE = Customer_Type.Employee
                .CUST_ID = Txt_EmpID.Text.Trim
            End With


            If Txt_EmpID.Text.Trim = "" Then
                Call Clear_Form()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_EmpID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_EmpID.Validating
        Try
            If Me.Txt_EmpID.Text.Trim <> "" And Me.Txt_EmpID.Text <> Me.Txt_EmpID.Tag Then
                If Employee_Info1.Is_Valid Then
                    'Get Docotor Details exist
                    If Is_Doctor_Registered(Txt_EmpID.Text.Trim, Txt_DoctorID.Text) Then
                        'Txt_DoctorID.Text = Is_Doctor_Registered(Txt_EmpID.Text.Trim)
                        Tr_Mode = Tran_Mode.Edit_Mode
                        'Mark Doctor Activities 
                        Call Select_Doctor_Services(Txt_DoctorID.Text.Trim)
                        'Mark Doctor Spliztions 
                        Call Select_Doctor_Splization(Txt_DoctorID.Text.Trim)
                    End If
                Else
                    MessageBox.Show("Employee ID does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Txt_EmpID.Focus()
                    e.Cancel = True
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub DoctorMaster_Frm_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        Call KeepRightofme(Me, ImageViewer_Frm)
    End Sub

    Private Sub Dgvw_Services_CellValueChanged(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgvw_Services.CellValueChanged
        With Dgvw_Services
            If .Columns(.CurrentCell.ColumnIndex).Name = "Mark" Then

                Dim CheckCell As DataGridViewCheckBoxCell = _
                CType(.Rows(.CurrentCell.RowIndex).Cells("Mark"), DataGridViewCheckBoxCell)
                Dim TextCommission As DataGridViewTextBoxCell = _
                CType(.Rows(.CurrentCell.RowIndex).Cells("Commission"), DataGridViewTextBoxCell)
                TextCommission.Value = ""
                TextCommission.ReadOnly = Not CType(CheckCell.Value, [Boolean])
                Dim TextType As DataGridViewTextBoxCell = _
                CType(.Rows(.CurrentCell.RowIndex).Cells("Type"), DataGridViewTextBoxCell)
                TextType.Tag = CType(CheckCell.Value, [Boolean])
                If CType(CheckCell.Value, [Boolean]) = False Then
                    TextType.Value = "< NA >"
                End If
                .Invalidate()
            End If
        End With
    End Sub

    Private Sub Dgvw_Services_EditingControlShowing(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewEditingControlShowingEventArgs) Handles Dgvw_Services.EditingControlShowing
        Try

        
            If Dgvw_Services.Columns(Dgvw_Services.CurrentCell.ColumnIndex).Name = "Commission" Then

                If (Not IsHandleAdded) Then
                    Dim tx As TextBox = CType(e.Control, TextBox)

                    If (Not (tx) Is Nothing) Then
                        AddHandler tx.KeyPress, AddressOf Me.tx_KeyPress
                        Me.IsHandleAdded = True
                        RemoveHandler Me.Dgvw_Services.EditingControlShowing, AddressOf Me.Dgvw_Services_EditingControlShowing
                    End If

                End If

            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try
    End Sub

    Private Sub tx_KeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs)
        Dim txt As TextBox = CType(sender, TextBox)
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), txt.Text, Data_Type.Double_Type, 12))
    End Sub

    Private Sub Cmb_CommType_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Cmb_CommType.Validating
        Try
            With Dgvw_Services
                .Item(.CurrentCell.ColumnIndex, .CurrentCell.RowIndex).Value = Cmb_CommType.Text

            End With
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Dgvw_Services_CellEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgvw_Services.CellEnter
        Call Set_PositionCombo()
    End Sub

    Private Sub Dgvw_Services_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgvw_Services.CellClick
        Call Set_PositionCombo()
    End Sub

    Private Sub Btn_Add_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Add.Click
        Try

            If Txt_Achivements.Text.Trim <> "" Then
                With Dgv_Doc_Achivements
                    .Rows.Add()
                    .Rows(.Rows.Count - 1).Cells("Sl_No").Value = .Rows.Count
                    .Rows(.Rows.Count - 1).Cells("Achivements").Value = Txt_Achivements.Text.Trim
                End With
                Txt_Achivements.Text = ""
                Txt_Achivements.Focus()
            Else
                Cmb_DocCategory.Focus()
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Function Get_Datatable() As DataTable
        Try
            Dim dt As New DataTable

            dt.Columns.Add("Slno")
            dt.Columns.Add("Achievements")
            Return dt
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Private Function Fill_AchivementGrid(ByRef Dgrivw As DataGridView, ByVal dtbl As DataTable) As Boolean
        Try

            Dgrivw.DataSource = dtbl
            Dgrivw.Refresh()
            Dgrivw.Columns(0).Width = 30
            Dgrivw.Columns(1).Width = 230


            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Dgv_Doc_Achivements_CellEndEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgv_Doc_Achivements.CellEndEdit
        Try
            GrDtbl.AcceptChanges()
            Fill_AchivementGrid(Dgv_Doc_Achivements, GrDtbl)
        Catch ex As Exception

        End Try
    End Sub

    'Private Sub Btn_New_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_New.Click
    '    Try
    '        Dim cname As String = ""
    '        Dim Fill_ID As String = ""
    '        Dim i_Start As Int16 = InStr(Me.Btn_New.Tag, "|", CompareMethod.Text)
    '        cname = Mid(Me.Btn_New.Tag, 1, i_Start - 1)
    '        Fill_ID = Mid(Me.Btn_New.Tag, i_Start + 1, Len(Me.Btn_New.Tag))
    '        Dim ctr As Object
    '        ctr = DirectCast(Me.Controls(cname), ComboBox)
    '        With Generaldatasave_Frm
    '            .Point_Frm = Get_GendatasaveformPosition(Me, ctr)
    '            .Data_CatID = Fill_ID
    '            .Req_Ctrl = ctr
    '            .ShowDialog()
    '        End With
    '    Catch ex As Exception

    '    End Try
    'End Sub

    'Private Sub Cmb_DocCategory_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cmb_DocCategory.GotFocus
    '    Btn_New.Visible = True
    '    Me.Btn_New.Location = Get_Newgendatabuttonposition(Cmb_DocCategory)
    '    Me.Btn_New.Tag = "Cmb_DocCategory|" & Gendatatype.Doctor_Category.ToString
    'End Sub

    Private Sub Txt_DoctorFee_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_DoctorFee.KeyPress
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_DoctorFee.Text, Data_Type.Double_Type, 12))
    End Sub

#Region "A D D  New GenData"

    Private Sub Set_NewGendatabutton(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cmb_DocCategory.GotFocus
        Try
            Dim AddReqCtrl As Control = CType(sender, Control)

            Btn_New.Visible = True
            Me.Btn_New.Location = Get_Newgendatabuttonposition(AddReqCtrl)
            Me.Btn_New.Tag = AddReqCtrl.Name & "|" & Val(AddReqCtrl.Tag)

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_New_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_New.Click
        Try

            Call AddNewGendata(Btn_New)

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Call_Btnnew(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Cmb_DocCategory.KeyDown
        Try
            If e.KeyCode = Keys.Add Then Call Btn_New_Click(Nothing, Nothing)
        Catch ex As Exception

        End Try
    End Sub

#End Region

    
End Class
