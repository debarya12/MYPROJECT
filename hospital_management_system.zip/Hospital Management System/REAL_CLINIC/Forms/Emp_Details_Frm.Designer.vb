﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Emp_Details_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Emp_Details_Frm))
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Btn_Find = New System.Windows.Forms.Button
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Cmb_Emp_status = New System.Windows.Forms.ComboBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.Dtp_Admitdate = New System.Windows.Forms.DateTimePicker
        Me.Label9 = New System.Windows.Forms.Label
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Delete = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.Txt_Emp_ID = New System.Windows.Forms.TextBox
        Me.Txt_Emp_Name = New System.Windows.Forms.TextBox
        Me.Txt_Emp_Add = New System.Windows.Forms.TextBox
        Me.Txt_Emp_Phone1 = New System.Windows.Forms.TextBox
        Me.Txt_Emp_Mob1 = New System.Windows.Forms.TextBox
        Me.Txt_Emp_Email = New System.Windows.Forms.TextBox
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label
        Me.Btn_Userpwd = New System.Windows.Forms.Button
        Me.Pnl_Deactivate = New System.Windows.Forms.Panel
        Me.Dtp_Deactivate = New System.Windows.Forms.DateTimePicker
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Cmb_Designation = New System.Windows.Forms.ComboBox
        Me.Txt_SSNo = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Cmb_Gender = New System.Windows.Forms.ComboBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.Cmb_Country = New System.Windows.Forms.ComboBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.Dtp_DOB = New System.Windows.Forms.DateTimePicker
        Me.Txt_Age = New System.Windows.Forms.TextBox
        Me.Label16 = New System.Windows.Forms.Label
        Me.Txt_Emp_Phone2 = New System.Windows.Forms.TextBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.Txt_Emp_Mob2 = New System.Windows.Forms.TextBox
        Me.Cmb_EmpCategory = New System.Windows.Forms.ComboBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.Txt_Qualification = New System.Windows.Forms.TextBox
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.Label27 = New System.Windows.Forms.Label
        Me.Label28 = New System.Windows.Forms.Label
        Me.Label29 = New System.Windows.Forms.Label
        Me.Btn_New = New System.Windows.Forms.Button
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.Imageviewer1 = New TECHNO_CLINIC.Imageviewer
        Me.Txt_Short_Name = New System.Windows.Forms.TextBox
        Me.Label30 = New System.Windows.Forms.Label
        Me.Pnl_Header.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.Pnl_Tran_mode.SuspendLayout()
        Me.Pnl_Deactivate.SuspendLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = Global.TECHNO_CLINIC.My.Resources.Resources.Menu_Bkg
        Me.Pnl_Header.Controls.Add(Me.Label1)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(646, 24)
        Me.Pnl_Header.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(6, 1)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(137, 18)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Employee Details"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(105, 35)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(47, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Emp ID"
        '
        'Btn_Find
        '
        Me.Btn_Find.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find.BackgroundImage = CType(resources.GetObject("Btn_Find.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find.ForeColor = System.Drawing.Color.White
        Me.Btn_Find.Location = New System.Drawing.Point(369, 31)
        Me.Btn_Find.Name = "Btn_Find"
        Me.Btn_Find.Size = New System.Drawing.Size(29, 21)
        Me.Btn_Find.TabIndex = 1
        Me.Btn_Find.TabStop = False
        Me.Btn_Find.Text = "F2"
        Me.Btn_Find.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(105, 88)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(39, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Name"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(105, 145)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(53, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Address"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(105, 312)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(52, 13)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Phone 1"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(105, 340)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(54, 13)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Mobile 1"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(105, 365)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(37, 13)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Email"
        '
        'Cmb_Emp_status
        '
        Me.Cmb_Emp_status.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Emp_status.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Emp_status.FormattingEnabled = True
        Me.Cmb_Emp_status.ItemHeight = 13
        Me.Cmb_Emp_status.Location = New System.Drawing.Point(185, 471)
        Me.Cmb_Emp_status.Name = "Cmb_Emp_status"
        Me.Cmb_Emp_status.Size = New System.Drawing.Size(98, 21)
        Me.Cmb_Emp_status.TabIndex = 16
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(105, 474)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(44, 13)
        Me.Label8.TabIndex = 16
        Me.Label8.Text = "Status"
        '
        'Dtp_Admitdate
        '
        Me.Dtp_Admitdate.CustomFormat = "dd/MM/yyyy"
        Me.Dtp_Admitdate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_Admitdate.Location = New System.Drawing.Point(185, 498)
        Me.Dtp_Admitdate.Name = "Dtp_Admitdate"
        Me.Dtp_Admitdate.Size = New System.Drawing.Size(98, 21)
        Me.Dtp_Admitdate.TabIndex = 17
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(105, 498)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(65, 13)
        Me.Label9.TabIndex = 18
        Me.Label9.Text = "Joint Date"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Left
        Me.PictureBox1.Location = New System.Drawing.Point(0, 24)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(105, 530)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox1.TabIndex = 19
        Me.PictureBox1.TabStop = False
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Delete)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(560, 377)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(62, 126)
        Me.Pnl_Common_Btn.TabIndex = 60
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(2, 63)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear.TabIndex = 22
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(2, 94)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 23
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Delete
        '
        Me.Btn_Delete.BackgroundImage = CType(resources.GetObject("Btn_Delete.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Delete.Location = New System.Drawing.Point(2, 33)
        Me.Btn_Delete.Name = "Btn_Delete"
        Me.Btn_Delete.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Delete.TabIndex = 21
        Me.Btn_Delete.Text = "Delete"
        Me.Btn_Delete.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = Global.TECHNO_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(2, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save.TabIndex = 20
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Txt_Emp_ID
        '
        Me.Txt_Emp_ID.BackColor = System.Drawing.Color.White
        Me.Txt_Emp_ID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Emp_ID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Emp_ID.Location = New System.Drawing.Point(185, 31)
        Me.Txt_Emp_ID.Name = "Txt_Emp_ID"
        Me.Txt_Emp_ID.Size = New System.Drawing.Size(161, 21)
        Me.Txt_Emp_ID.TabIndex = 0
        '
        'Txt_Emp_Name
        '
        Me.Txt_Emp_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Emp_Name.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Emp_Name.Location = New System.Drawing.Point(185, 87)
        Me.Txt_Emp_Name.MaxLength = 250
        Me.Txt_Emp_Name.Name = "Txt_Emp_Name"
        Me.Txt_Emp_Name.Size = New System.Drawing.Size(304, 21)
        Me.Txt_Emp_Name.TabIndex = 2
        '
        'Txt_Emp_Add
        '
        Me.Txt_Emp_Add.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Emp_Add.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Emp_Add.HideSelection = False
        Me.Txt_Emp_Add.Location = New System.Drawing.Point(185, 142)
        Me.Txt_Emp_Add.MaxLength = 500
        Me.Txt_Emp_Add.Multiline = True
        Me.Txt_Emp_Add.Name = "Txt_Emp_Add"
        Me.Txt_Emp_Add.Size = New System.Drawing.Size(304, 80)
        Me.Txt_Emp_Add.TabIndex = 3
        '
        'Txt_Emp_Phone1
        '
        Me.Txt_Emp_Phone1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Emp_Phone1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Emp_Phone1.Location = New System.Drawing.Point(185, 309)
        Me.Txt_Emp_Phone1.Name = "Txt_Emp_Phone1"
        Me.Txt_Emp_Phone1.Size = New System.Drawing.Size(98, 21)
        Me.Txt_Emp_Phone1.TabIndex = 8
        '
        'Txt_Emp_Mob1
        '
        Me.Txt_Emp_Mob1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Emp_Mob1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Emp_Mob1.Location = New System.Drawing.Point(185, 336)
        Me.Txt_Emp_Mob1.Name = "Txt_Emp_Mob1"
        Me.Txt_Emp_Mob1.Size = New System.Drawing.Size(98, 21)
        Me.Txt_Emp_Mob1.TabIndex = 10
        '
        'Txt_Emp_Email
        '
        Me.Txt_Emp_Email.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Emp_Email.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Emp_Email.Location = New System.Drawing.Point(185, 363)
        Me.Txt_Emp_Email.MaxLength = 100
        Me.Txt_Emp_Email.Name = "Txt_Emp_Email"
        Me.Txt_Emp_Email.Size = New System.Drawing.Size(304, 21)
        Me.Txt_Emp_Email.TabIndex = 12
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(427, 31)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(74, 22)
        Me.Pnl_Tran_mode.TabIndex = 23
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(2, 1)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(68, 16)
        Me.Lbl_Tran_Mode.TabIndex = 0
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Btn_Userpwd
        '
        Me.Btn_Userpwd.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Userpwd.BackgroundImage = Global.TECHNO_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Userpwd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Userpwd.Enabled = False
        Me.Btn_Userpwd.ForeColor = System.Drawing.Color.White
        Me.Btn_Userpwd.Location = New System.Drawing.Point(185, 525)
        Me.Btn_Userpwd.Name = "Btn_Userpwd"
        Me.Btn_Userpwd.Size = New System.Drawing.Size(304, 25)
        Me.Btn_Userpwd.TabIndex = 11
        Me.Btn_Userpwd.Text = "Manage User name and &Password"
        Me.Btn_Userpwd.UseVisualStyleBackColor = False
        '
        'Pnl_Deactivate
        '
        Me.Pnl_Deactivate.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Deactivate.Controls.Add(Me.Dtp_Deactivate)
        Me.Pnl_Deactivate.Controls.Add(Me.Label10)
        Me.Pnl_Deactivate.Location = New System.Drawing.Point(286, 493)
        Me.Pnl_Deactivate.Name = "Pnl_Deactivate"
        Me.Pnl_Deactivate.Size = New System.Drawing.Size(204, 28)
        Me.Pnl_Deactivate.TabIndex = 24
        '
        'Dtp_Deactivate
        '
        Me.Dtp_Deactivate.CustomFormat = "dd/MM/yyyy"
        Me.Dtp_Deactivate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_Deactivate.Location = New System.Drawing.Point(104, 4)
        Me.Dtp_Deactivate.Name = "Dtp_Deactivate"
        Me.Dtp_Deactivate.Size = New System.Drawing.Size(98, 21)
        Me.Dtp_Deactivate.TabIndex = 18
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Location = New System.Drawing.Point(2, 9)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(99, 13)
        Me.Label10.TabIndex = 23
        Me.Label10.Text = "Deactivate Date"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(105, 420)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(74, 13)
        Me.Label11.TabIndex = 26
        Me.Label11.Text = "Designation"
        '
        'Cmb_Designation
        '
        Me.Cmb_Designation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Designation.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Designation.FormattingEnabled = True
        Me.Cmb_Designation.ItemHeight = 13
        Me.Cmb_Designation.Location = New System.Drawing.Point(185, 417)
        Me.Cmb_Designation.Name = "Cmb_Designation"
        Me.Cmb_Designation.Size = New System.Drawing.Size(261, 21)
        Me.Cmb_Designation.TabIndex = 14
        '
        'Txt_SSNo
        '
        Me.Txt_SSNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_SSNo.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_SSNo.Location = New System.Drawing.Point(185, 60)
        Me.Txt_SSNo.MaxLength = 20
        Me.Txt_SSNo.Name = "Txt_SSNo"
        Me.Txt_SSNo.Size = New System.Drawing.Size(161, 21)
        Me.Txt_SSNo.TabIndex = 1
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.ForeColor = System.Drawing.Color.Black
        Me.Label12.Location = New System.Drawing.Point(105, 62)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(38, 13)
        Me.Label12.TabIndex = 28
        Me.Label12.Text = "SS No"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.ForeColor = System.Drawing.Color.Black
        Me.Label13.Location = New System.Drawing.Point(105, 234)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(48, 13)
        Me.Label13.TabIndex = 30
        Me.Label13.Text = "Gender"
        '
        'Cmb_Gender
        '
        Me.Cmb_Gender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Gender.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Gender.FormattingEnabled = True
        Me.Cmb_Gender.Location = New System.Drawing.Point(185, 228)
        Me.Cmb_Gender.Name = "Cmb_Gender"
        Me.Cmb_Gender.Size = New System.Drawing.Size(98, 21)
        Me.Cmb_Gender.TabIndex = 4
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.ForeColor = System.Drawing.Color.Black
        Me.Label14.Location = New System.Drawing.Point(105, 260)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(52, 13)
        Me.Label14.TabIndex = 32
        Me.Label14.Text = "Country"
        '
        'Cmb_Country
        '
        Me.Cmb_Country.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Country.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Country.FormattingEnabled = True
        Me.Cmb_Country.Location = New System.Drawing.Point(185, 255)
        Me.Cmb_Country.Name = "Cmb_Country"
        Me.Cmb_Country.Size = New System.Drawing.Size(273, 21)
        Me.Cmb_Country.TabIndex = 5
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.ForeColor = System.Drawing.Color.Black
        Me.Label15.Location = New System.Drawing.Point(105, 286)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(30, 13)
        Me.Label15.TabIndex = 34
        Me.Label15.Text = "DOB"
        '
        'Dtp_DOB
        '
        Me.Dtp_DOB.CustomFormat = "dd/MM/yyyy"
        Me.Dtp_DOB.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_DOB.Location = New System.Drawing.Point(185, 282)
        Me.Dtp_DOB.Name = "Dtp_DOB"
        Me.Dtp_DOB.Size = New System.Drawing.Size(98, 21)
        Me.Dtp_DOB.TabIndex = 6
        '
        'Txt_Age
        '
        Me.Txt_Age.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Age.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Age.Location = New System.Drawing.Point(383, 282)
        Me.Txt_Age.Name = "Txt_Age"
        Me.Txt_Age.Size = New System.Drawing.Size(75, 21)
        Me.Txt_Age.TabIndex = 7
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.ForeColor = System.Drawing.Color.Black
        Me.Label16.Location = New System.Drawing.Point(323, 289)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(29, 13)
        Me.Label16.TabIndex = 36
        Me.Label16.Text = "Age"
        '
        'Txt_Emp_Phone2
        '
        Me.Txt_Emp_Phone2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Emp_Phone2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Emp_Phone2.Location = New System.Drawing.Point(383, 309)
        Me.Txt_Emp_Phone2.Name = "Txt_Emp_Phone2"
        Me.Txt_Emp_Phone2.Size = New System.Drawing.Size(105, 21)
        Me.Txt_Emp_Phone2.TabIndex = 9
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.ForeColor = System.Drawing.Color.Black
        Me.Label17.Location = New System.Drawing.Point(323, 315)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(52, 13)
        Me.Label17.TabIndex = 38
        Me.Label17.Text = "Phone 2"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.Transparent
        Me.Label18.ForeColor = System.Drawing.Color.Black
        Me.Label18.Location = New System.Drawing.Point(323, 340)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(54, 13)
        Me.Label18.TabIndex = 40
        Me.Label18.Text = "Mobile 2"
        '
        'Txt_Emp_Mob2
        '
        Me.Txt_Emp_Mob2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Emp_Mob2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Emp_Mob2.Location = New System.Drawing.Point(383, 336)
        Me.Txt_Emp_Mob2.Name = "Txt_Emp_Mob2"
        Me.Txt_Emp_Mob2.Size = New System.Drawing.Size(105, 21)
        Me.Txt_Emp_Mob2.TabIndex = 11
        '
        'Cmb_EmpCategory
        '
        Me.Cmb_EmpCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_EmpCategory.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_EmpCategory.FormattingEnabled = True
        Me.Cmb_EmpCategory.ItemHeight = 13
        Me.Cmb_EmpCategory.Location = New System.Drawing.Point(185, 444)
        Me.Cmb_EmpCategory.Name = "Cmb_EmpCategory"
        Me.Cmb_EmpCategory.Size = New System.Drawing.Size(261, 21)
        Me.Cmb_EmpCategory.TabIndex = 15
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.ForeColor = System.Drawing.Color.Black
        Me.Label19.Location = New System.Drawing.Point(105, 447)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(59, 13)
        Me.Label19.TabIndex = 42
        Me.Label19.Text = "Category"
        '
        'Txt_Qualification
        '
        Me.Txt_Qualification.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Qualification.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Qualification.Location = New System.Drawing.Point(185, 390)
        Me.Txt_Qualification.MaxLength = 100
        Me.Txt_Qualification.Name = "Txt_Qualification"
        Me.Txt_Qualification.Size = New System.Drawing.Size(304, 21)
        Me.Txt_Qualification.TabIndex = 13
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.Color.Transparent
        Me.Label20.ForeColor = System.Drawing.Color.Black
        Me.Label20.Location = New System.Drawing.Point(105, 392)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(77, 13)
        Me.Label20.TabIndex = 44
        Me.Label20.Text = "Qualification"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.Color.Transparent
        Me.Label21.ForeColor = System.Drawing.Color.Red
        Me.Label21.Location = New System.Drawing.Point(352, 62)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(147, 13)
        Me.Label21.TabIndex = 61
        Me.Label21.Text = "(Social Security Number)"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.BackColor = System.Drawing.Color.Transparent
        Me.Label22.ForeColor = System.Drawing.Color.Red
        Me.Label22.Location = New System.Drawing.Point(144, 60)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(14, 13)
        Me.Label22.TabIndex = 62
        Me.Label22.Text = "*"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.BackColor = System.Drawing.Color.Transparent
        Me.Label23.ForeColor = System.Drawing.Color.Red
        Me.Label23.Location = New System.Drawing.Point(144, 87)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(14, 13)
        Me.Label23.TabIndex = 63
        Me.Label23.Text = "*"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.BackColor = System.Drawing.Color.Transparent
        Me.Label24.ForeColor = System.Drawing.Color.Red
        Me.Label24.Location = New System.Drawing.Point(150, 228)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(14, 13)
        Me.Label24.TabIndex = 64
        Me.Label24.Text = "*"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.BackColor = System.Drawing.Color.Transparent
        Me.Label25.ForeColor = System.Drawing.Color.Red
        Me.Label25.Location = New System.Drawing.Point(156, 258)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(14, 13)
        Me.Label25.TabIndex = 65
        Me.Label25.Text = "*"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.BackColor = System.Drawing.Color.Transparent
        Me.Label26.ForeColor = System.Drawing.Color.Red
        Me.Label26.Location = New System.Drawing.Point(152, 309)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(14, 13)
        Me.Label26.TabIndex = 66
        Me.Label26.Text = "*"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.BackColor = System.Drawing.Color.Transparent
        Me.Label27.ForeColor = System.Drawing.Color.Red
        Me.Label27.Location = New System.Drawing.Point(165, 282)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(14, 13)
        Me.Label27.TabIndex = 67
        Me.Label27.Text = "*"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.BackColor = System.Drawing.Color.Transparent
        Me.Label28.ForeColor = System.Drawing.Color.Red
        Me.Label28.Location = New System.Drawing.Point(165, 441)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(14, 13)
        Me.Label28.TabIndex = 68
        Me.Label28.Text = "*"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.BackColor = System.Drawing.Color.Transparent
        Me.Label29.ForeColor = System.Drawing.Color.Red
        Me.Label29.Location = New System.Drawing.Point(165, 493)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(14, 13)
        Me.Label29.TabIndex = 69
        Me.Label29.Text = "*"
        '
        'Btn_New
        '
        Me.Btn_New.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_New.BackgroundImage = Global.TECHNO_CLINIC.My.Resources.Resources.F2_Button
        Me.Btn_New.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_New.ForeColor = System.Drawing.Color.White
        Me.Btn_New.Location = New System.Drawing.Point(446, 444)
        Me.Btn_New.Name = "Btn_New"
        Me.Btn_New.Size = New System.Drawing.Size(41, 20)
        Me.Btn_New.TabIndex = 97
        Me.Btn_New.TabStop = False
        Me.Btn_New.Text = "NEW"
        Me.Btn_New.UseVisualStyleBackColor = False
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'Imageviewer1
        '
        Me.Imageviewer1.CUST_ID = ""
        Me.Imageviewer1.CUST_TYPE = HMS_Common.Common_Cls.Customer_Type.Employee
        Me.Imageviewer1.Location = New System.Drawing.Point(496, 115)
        Me.Imageviewer1.Name = "Imageviewer1"
        Me.Imageviewer1.Scan_Enabled = True
        Me.Imageviewer1.Size = New System.Drawing.Size(145, 187)
        Me.Imageviewer1.TabIndex = 98
        '
        'Txt_Short_Name
        '
        Me.Txt_Short_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Short_Name.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Short_Name.Location = New System.Drawing.Point(185, 114)
        Me.Txt_Short_Name.MaxLength = 15
        Me.Txt_Short_Name.Name = "Txt_Short_Name"
        Me.Txt_Short_Name.Size = New System.Drawing.Size(161, 21)
        Me.Txt_Short_Name.TabIndex = 99
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.BackColor = System.Drawing.Color.Transparent
        Me.Label30.ForeColor = System.Drawing.Color.Black
        Me.Label30.Location = New System.Drawing.Point(105, 118)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(73, 13)
        Me.Label30.TabIndex = 100
        Me.Label30.Text = "Short Name"
        '
        'Emp_Details_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(646, 554)
        Me.Controls.Add(Me.Txt_Short_Name)
        Me.Controls.Add(Me.Label30)
        Me.Controls.Add(Me.Imageviewer1)
        Me.Controls.Add(Me.Btn_New)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Txt_Qualification)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Cmb_EmpCategory)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Txt_Emp_Mob2)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Txt_Emp_Phone2)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Txt_Age)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Dtp_DOB)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Cmb_Country)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Cmb_Gender)
        Me.Controls.Add(Me.Txt_SSNo)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Cmb_Designation)
        Me.Controls.Add(Me.Pnl_Deactivate)
        Me.Controls.Add(Me.Btn_Userpwd)
        Me.Controls.Add(Me.Pnl_Tran_mode)
        Me.Controls.Add(Me.Txt_Emp_Email)
        Me.Controls.Add(Me.Txt_Emp_Mob1)
        Me.Controls.Add(Me.Txt_Emp_Phone1)
        Me.Controls.Add(Me.Txt_Emp_Add)
        Me.Controls.Add(Me.Txt_Emp_Name)
        Me.Controls.Add(Me.Txt_Emp_ID)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Dtp_Admitdate)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Cmb_Emp_status)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Btn_Find)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Controls.Add(Me.Label11)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Emp_Details_Frm"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.Pnl_Tran_mode.ResumeLayout(False)
        Me.Pnl_Deactivate.ResumeLayout(False)
        Me.Pnl_Deactivate.PerformLayout()
        CType(Me.ErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Btn_Find As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Emp_status As System.Windows.Forms.ComboBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Dtp_Admitdate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Delete As System.Windows.Forms.Button
    Friend WithEvents Txt_Emp_ID As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Emp_Name As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Emp_Add As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Emp_Phone1 As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Emp_Mob1 As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Emp_Email As System.Windows.Forms.TextBox
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Btn_Userpwd As System.Windows.Forms.Button
    Friend WithEvents Pnl_Deactivate As System.Windows.Forms.Panel
    Friend WithEvents Dtp_Deactivate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Designation As System.Windows.Forms.ComboBox
    Friend WithEvents Txt_SSNo As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Gender As System.Windows.Forms.ComboBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Country As System.Windows.Forms.ComboBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Dtp_DOB As System.Windows.Forms.DateTimePicker
    Friend WithEvents Txt_Age As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Txt_Emp_Phone2 As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Txt_Emp_Mob2 As System.Windows.Forms.TextBox
    Friend WithEvents Cmb_EmpCategory As System.Windows.Forms.ComboBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Txt_Qualification As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Btn_New As System.Windows.Forms.Button
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents Imageviewer1 As TECHNO_CLINIC.Imageviewer
    Friend WithEvents Txt_Short_Name As System.Windows.Forms.TextBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
End Class
