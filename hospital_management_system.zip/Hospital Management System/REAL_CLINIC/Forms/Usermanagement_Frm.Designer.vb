﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Usermanagement_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Usermanagement_Frm))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.Txt_NewPWD = New System.Windows.Forms.TextBox
        Me.Txt_CurrPWD = New System.Windows.Forms.TextBox
        Me.Txt_Emp_Add = New System.Windows.Forms.TextBox
        Me.Txt_Emp_Name = New System.Windows.Forms.TextBox
        Me.Txt_Emp_ID = New System.Windows.Forms.TextBox
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Delete = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.Label8 = New System.Windows.Forms.Label
        Me.Cmb_Userstatus = New System.Windows.Forms.ComboBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Btn_Find = New System.Windows.Forms.Button
        Me.Label2 = New System.Windows.Forms.Label
        Me.Txt_ConfPWD = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label
        Me.Lbl_ActDeactivate = New System.Windows.Forms.Label
        Me.Dtp_Activatedate = New System.Windows.Forms.DateTimePicker
        Me.Txt_Username = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Dtp_Validupto = New System.Windows.Forms.DateTimePicker
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Pnl_Header.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.Pnl_Tran_mode.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Left
        Me.PictureBox1.Location = New System.Drawing.Point(0, 24)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(100, 331)
        Me.PictureBox1.TabIndex = 21
        Me.PictureBox1.TabStop = False
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Header.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Menu_Bkg
        Me.Pnl_Header.Controls.Add(Me.Label1)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(541, 24)
        Me.Pnl_Header.TabIndex = 20
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(7, 5)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(204, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "User / Password Management"
        '
        'Txt_NewPWD
        '
        Me.Txt_NewPWD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_NewPWD.Font = New System.Drawing.Font("Wingdings", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Txt_NewPWD.Location = New System.Drawing.Point(205, 223)
        Me.Txt_NewPWD.Name = "Txt_NewPWD"
        Me.Txt_NewPWD.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.Txt_NewPWD.Size = New System.Drawing.Size(233, 20)
        Me.Txt_NewPWD.TabIndex = 6
        Me.Txt_NewPWD.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Txt_CurrPWD
        '
        Me.Txt_CurrPWD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_CurrPWD.Font = New System.Drawing.Font("Wingdings", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Txt_CurrPWD.Location = New System.Drawing.Point(205, 197)
        Me.Txt_CurrPWD.Name = "Txt_CurrPWD"
        Me.Txt_CurrPWD.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.Txt_CurrPWD.Size = New System.Drawing.Size(234, 20)
        Me.Txt_CurrPWD.TabIndex = 5
        Me.Txt_CurrPWD.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Txt_Emp_Add
        '
        Me.Txt_Emp_Add.BackColor = System.Drawing.Color.White
        Me.Txt_Emp_Add.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Emp_Add.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Emp_Add.Location = New System.Drawing.Point(205, 89)
        Me.Txt_Emp_Add.Multiline = True
        Me.Txt_Emp_Add.Name = "Txt_Emp_Add"
        Me.Txt_Emp_Add.ReadOnly = True
        Me.Txt_Emp_Add.Size = New System.Drawing.Size(331, 77)
        Me.Txt_Emp_Add.TabIndex = 3
        Me.Txt_Emp_Add.TabStop = False
        '
        'Txt_Emp_Name
        '
        Me.Txt_Emp_Name.BackColor = System.Drawing.Color.White
        Me.Txt_Emp_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Emp_Name.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Emp_Name.Location = New System.Drawing.Point(205, 63)
        Me.Txt_Emp_Name.Name = "Txt_Emp_Name"
        Me.Txt_Emp_Name.ReadOnly = True
        Me.Txt_Emp_Name.Size = New System.Drawing.Size(331, 21)
        Me.Txt_Emp_Name.TabIndex = 2
        Me.Txt_Emp_Name.TabStop = False
        '
        'Txt_Emp_ID
        '
        Me.Txt_Emp_ID.BackColor = System.Drawing.Color.White
        Me.Txt_Emp_ID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Emp_ID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Emp_ID.Location = New System.Drawing.Point(205, 37)
        Me.Txt_Emp_ID.Name = "Txt_Emp_ID"
        Me.Txt_Emp_ID.Size = New System.Drawing.Size(187, 21)
        Me.Txt_Emp_ID.TabIndex = 0
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Delete)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(462, 222)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(72, 126)
        Me.Pnl_Common_Btn.TabIndex = 33
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(2, 63)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(65, 28)
        Me.Btn_Clear.TabIndex = 13
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(2, 94)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(65, 28)
        Me.Btn_Close.TabIndex = 14
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Delete
        '
        Me.Btn_Delete.BackgroundImage = CType(resources.GetObject("Btn_Delete.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Delete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Delete.Location = New System.Drawing.Point(2, 33)
        Me.Btn_Delete.Name = "Btn_Delete"
        Me.Btn_Delete.Size = New System.Drawing.Size(65, 28)
        Me.Btn_Delete.TabIndex = 12
        Me.Btn_Delete.Text = "Delete"
        Me.Btn_Delete.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = CType(resources.GetObject("Btn_Save.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Save.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(2, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(65, 28)
        Me.Btn_Save.TabIndex = 11
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Location = New System.Drawing.Point(100, 281)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(44, 13)
        Me.Label8.TabIndex = 35
        Me.Label8.Text = "Status"
        '
        'Cmb_Userstatus
        '
        Me.Cmb_Userstatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Userstatus.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Userstatus.FormattingEnabled = True
        Me.Cmb_Userstatus.Location = New System.Drawing.Point(205, 275)
        Me.Cmb_Userstatus.Name = "Cmb_Userstatus"
        Me.Cmb_Userstatus.Size = New System.Drawing.Size(114, 21)
        Me.Cmb_Userstatus.TabIndex = 8
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Location = New System.Drawing.Point(100, 226)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(87, 13)
        Me.Label6.TabIndex = 34
        Me.Label6.Text = "New Password"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Location = New System.Drawing.Point(100, 199)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(107, 13)
        Me.Label5.TabIndex = 32
        Me.Label5.Text = "Current Password"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Location = New System.Drawing.Point(100, 93)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(80, 13)
        Me.Label4.TabIndex = 30
        Me.Label4.Text = "Emp Address"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Location = New System.Drawing.Point(100, 65)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(66, 13)
        Me.Label3.TabIndex = 28
        Me.Label3.Text = "Emp Name"
        '
        'Btn_Find
        '
        Me.Btn_Find.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find.BackgroundImage = CType(resources.GetObject("Btn_Find.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find.ForeColor = System.Drawing.Color.White
        Me.Btn_Find.Location = New System.Drawing.Point(394, 37)
        Me.Btn_Find.Name = "Btn_Find"
        Me.Btn_Find.Size = New System.Drawing.Size(34, 21)
        Me.Btn_Find.TabIndex = 1
        Me.Btn_Find.TabStop = False
        Me.Btn_Find.Text = "F2"
        Me.Btn_Find.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Location = New System.Drawing.Point(100, 39)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(47, 13)
        Me.Label2.TabIndex = 23
        Me.Label2.Text = "Emp ID"
        '
        'Txt_ConfPWD
        '
        Me.Txt_ConfPWD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_ConfPWD.Font = New System.Drawing.Font("Wingdings", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Txt_ConfPWD.Location = New System.Drawing.Point(206, 249)
        Me.Txt_ConfPWD.Name = "Txt_ConfPWD"
        Me.Txt_ConfPWD.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.Txt_ConfPWD.Size = New System.Drawing.Size(233, 20)
        Me.Txt_ConfPWD.TabIndex = 7
        Me.Txt_ConfPWD.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Location = New System.Drawing.Point(100, 253)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(108, 13)
        Me.Label7.TabIndex = 37
        Me.Label7.Text = "Confirm Password"
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(449, 37)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(86, 22)
        Me.Pnl_Tran_mode.TabIndex = 38
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(2, 1)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(79, 16)
        Me.Lbl_Tran_Mode.TabIndex = 0
        Me.Lbl_Tran_Mode.Text = "New Mode"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Lbl_ActDeactivate
        '
        Me.Lbl_ActDeactivate.AutoSize = True
        Me.Lbl_ActDeactivate.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_ActDeactivate.Location = New System.Drawing.Point(100, 305)
        Me.Lbl_ActDeactivate.Name = "Lbl_ActDeactivate"
        Me.Lbl_ActDeactivate.Size = New System.Drawing.Size(95, 13)
        Me.Lbl_ActDeactivate.TabIndex = 40
        Me.Lbl_ActDeactivate.Text = "Activation Date"
        '
        'Dtp_Activatedate
        '
        Me.Dtp_Activatedate.CustomFormat = "dd/MM/yyyy"
        Me.Dtp_Activatedate.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dtp_Activatedate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_Activatedate.Location = New System.Drawing.Point(206, 301)
        Me.Dtp_Activatedate.Name = "Dtp_Activatedate"
        Me.Dtp_Activatedate.Size = New System.Drawing.Size(114, 21)
        Me.Dtp_Activatedate.TabIndex = 9
        '
        'Txt_Username
        '
        Me.Txt_Username.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Username.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Username.Location = New System.Drawing.Point(205, 171)
        Me.Txt_Username.Name = "Txt_Username"
        Me.Txt_Username.Size = New System.Drawing.Size(234, 21)
        Me.Txt_Username.TabIndex = 4
        Me.Txt_Username.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Location = New System.Drawing.Point(100, 174)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(68, 13)
        Me.Label9.TabIndex = 42
        Me.Label9.Text = "User Name"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Location = New System.Drawing.Point(100, 331)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(64, 13)
        Me.Label10.TabIndex = 44
        Me.Label10.Text = "Valid Upto"
        '
        'Dtp_Validupto
        '
        Me.Dtp_Validupto.CustomFormat = "dd/MM/yyyy"
        Me.Dtp_Validupto.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dtp_Validupto.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_Validupto.Location = New System.Drawing.Point(206, 327)
        Me.Dtp_Validupto.Name = "Dtp_Validupto"
        Me.Dtp_Validupto.Size = New System.Drawing.Size(114, 21)
        Me.Dtp_Validupto.TabIndex = 10
        '
        'Usermanagement_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.LeftGradiant
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(541, 355)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Dtp_Validupto)
        Me.Controls.Add(Me.Txt_Username)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Lbl_ActDeactivate)
        Me.Controls.Add(Me.Dtp_Activatedate)
        Me.Controls.Add(Me.Pnl_Tran_mode)
        Me.Controls.Add(Me.Txt_ConfPWD)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Txt_NewPWD)
        Me.Controls.Add(Me.Txt_CurrPWD)
        Me.Controls.Add(Me.Txt_Emp_Add)
        Me.Controls.Add(Me.Txt_Emp_Name)
        Me.Controls.Add(Me.Txt_Emp_ID)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Cmb_Userstatus)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Btn_Find)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Usermanagement_Frm"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.TopMost = True
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.Pnl_Tran_mode.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Txt_NewPWD As System.Windows.Forms.TextBox
    Friend WithEvents Txt_CurrPWD As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Emp_Add As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Emp_Name As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Emp_ID As System.Windows.Forms.TextBox
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Delete As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Userstatus As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Btn_Find As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Txt_ConfPWD As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Lbl_ActDeactivate As System.Windows.Forms.Label
    Friend WithEvents Dtp_Activatedate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Txt_Username As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Dtp_Validupto As System.Windows.Forms.DateTimePicker
End Class
