﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Patient_InfoSheet_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Patient_InfoSheet_Frm))
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Btn_Edit = New System.Windows.Forms.Button
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Panel4 = New System.Windows.Forms.Panel
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.Label4 = New System.Windows.Forms.Label
        Me.Lbl_Occupation = New System.Windows.Forms.Label
        Me.Label43 = New System.Windows.Forms.Label
        Me.Label42 = New System.Windows.Forms.Label
        Me.Label31 = New System.Windows.Forms.Label
        Me.Label32 = New System.Windows.Forms.Label
        Me.Label33 = New System.Windows.Forms.Label
        Me.Label37 = New System.Windows.Forms.Label
        Me.Label41 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.Lbl_remarks = New System.Windows.Forms.Label
        Me.Lbl_Nominee = New System.Windows.Forms.Label
        Me.Lbl_NomineeRel = New System.Windows.Forms.Label
        Me.Lbl_IdentificationMark = New System.Windows.Forms.Label
        Me.Lbl_AnnualIncome = New System.Windows.Forms.Label
        Me.Lbl_Patient_Socialstatus = New System.Windows.Forms.Label
        Me.Lbl_Status = New System.Windows.Forms.Label
        Me.Lbl_FamiliyDoctor = New System.Windows.Forms.Label
        Me.Lbl_Employer = New System.Windows.Forms.Label
        Me.Label47 = New System.Windows.Forms.Label
        Me.Lbl_Insured = New System.Windows.Forms.Label
        Me.Lbl_LastVistdate = New System.Windows.Forms.Label
        Me.Lbl_RegDate = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Lbl_FamilyName = New System.Windows.Forms.Label
        Me.Label27 = New System.Windows.Forms.Label
        Me.Lbl_SOCNo = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.Lbl_MartialStatus = New System.Windows.Forms.Label
        Me.Lbl_DOB = New System.Windows.Forms.Label
        Me.Lbl_Gender = New System.Windows.Forms.Label
        Me.Lbl_Age = New System.Windows.Forms.Label
        Me.Lbl_Email = New System.Windows.Forms.Label
        Me.Lbl_Mob2 = New System.Windows.Forms.Label
        Me.Lbl_Mob1 = New System.Windows.Forms.Label
        Me.Lbl_Phone2 = New System.Windows.Forms.Label
        Me.Lbl_Phone1 = New System.Windows.Forms.Label
        Me.Lbl_Pin = New System.Windows.Forms.Label
        Me.Lbl_Country = New System.Windows.Forms.Label
        Me.Lbl_State = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Lbl_City = New System.Windows.Forms.Label
        Me.lbl_Address = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Lbl_PatientID = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Lbl_Name = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Panel1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.BackgroundImage = CType(resources.GetObject("Panel1.BackgroundImage"), System.Drawing.Image)
        Me.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel1.Controls.Add(Me.Btn_Edit)
        Me.Panel1.Controls.Add(Me.Btn_Close)
        Me.Panel1.Controls.Add(Me.Panel4)
        Me.Panel1.Controls.Add(Me.Panel3)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Location = New System.Drawing.Point(-1, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(811, 555)
        Me.Panel1.TabIndex = 0
        '
        'Btn_Edit
        '
        Me.Btn_Edit.BackgroundImage = CType(resources.GetObject("Btn_Edit.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Edit.CausesValidation = False
        Me.Btn_Edit.Location = New System.Drawing.Point(635, 509)
        Me.Btn_Edit.Name = "Btn_Edit"
        Me.Btn_Edit.Size = New System.Drawing.Size(79, 28)
        Me.Btn_Edit.TabIndex = 42
        Me.Btn_Edit.Text = "Edit"
        Me.Btn_Edit.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(715, 509)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(79, 28)
        Me.Btn_Close.TabIndex = 43
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Panel4
        '
        Me.Panel4.BackgroundImage = CType(resources.GetObject("Panel4.BackgroundImage"), System.Drawing.Image)
        Me.Panel4.Location = New System.Drawing.Point(411, 44)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(11, 495)
        Me.Panel4.TabIndex = 39
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.Transparent
        Me.Panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel3.Controls.Add(Me.Label4)
        Me.Panel3.Controls.Add(Me.Lbl_Occupation)
        Me.Panel3.Controls.Add(Me.Label43)
        Me.Panel3.Controls.Add(Me.Label42)
        Me.Panel3.Controls.Add(Me.Label31)
        Me.Panel3.Controls.Add(Me.Label32)
        Me.Panel3.Controls.Add(Me.Label33)
        Me.Panel3.Controls.Add(Me.Label37)
        Me.Panel3.Controls.Add(Me.Label41)
        Me.Panel3.Controls.Add(Me.Label20)
        Me.Panel3.Controls.Add(Me.Label21)
        Me.Panel3.Controls.Add(Me.Label22)
        Me.Panel3.Controls.Add(Me.Label23)
        Me.Panel3.Controls.Add(Me.Label24)
        Me.Panel3.Controls.Add(Me.Lbl_remarks)
        Me.Panel3.Controls.Add(Me.Lbl_Nominee)
        Me.Panel3.Controls.Add(Me.Lbl_NomineeRel)
        Me.Panel3.Controls.Add(Me.Lbl_IdentificationMark)
        Me.Panel3.Controls.Add(Me.Lbl_AnnualIncome)
        Me.Panel3.Controls.Add(Me.Lbl_Patient_Socialstatus)
        Me.Panel3.Controls.Add(Me.Lbl_Status)
        Me.Panel3.Controls.Add(Me.Lbl_FamiliyDoctor)
        Me.Panel3.Controls.Add(Me.Lbl_Employer)
        Me.Panel3.Controls.Add(Me.Label47)
        Me.Panel3.Controls.Add(Me.Lbl_Insured)
        Me.Panel3.Controls.Add(Me.Lbl_LastVistdate)
        Me.Panel3.Controls.Add(Me.Lbl_RegDate)
        Me.Panel3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel3.ForeColor = System.Drawing.Color.Black
        Me.Panel3.Location = New System.Drawing.Point(422, 44)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(372, 467)
        Me.Panel3.TabIndex = 38
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(6, 35)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(70, 13)
        Me.Label4.TabIndex = 59
        Me.Label4.Text = "Occupation"
        '
        'Lbl_Occupation
        '
        Me.Lbl_Occupation.AutoSize = True
        Me.Lbl_Occupation.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Occupation.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Occupation.ForeColor = System.Drawing.Color.Black
        Me.Lbl_Occupation.Location = New System.Drawing.Point(133, 35)
        Me.Lbl_Occupation.Name = "Lbl_Occupation"
        Me.Lbl_Occupation.Size = New System.Drawing.Size(0, 14)
        Me.Lbl_Occupation.TabIndex = 58
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.BackColor = System.Drawing.Color.Transparent
        Me.Label43.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.ForeColor = System.Drawing.Color.Black
        Me.Label43.Location = New System.Drawing.Point(6, 396)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(58, 13)
        Me.Label43.TabIndex = 57
        Me.Label43.Text = "Remarks"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.BackColor = System.Drawing.Color.Transparent
        Me.Label42.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.ForeColor = System.Drawing.Color.Black
        Me.Label42.Location = New System.Drawing.Point(5, 162)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(102, 13)
        Me.Label42.TabIndex = 56
        Me.Label42.Text = "Employer Details"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.BackColor = System.Drawing.Color.Transparent
        Me.Label31.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.ForeColor = System.Drawing.Color.Black
        Me.Label31.Location = New System.Drawing.Point(3, 316)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(121, 13)
        Me.Label31.TabIndex = 49
        Me.Label31.Text = "Identification Marks"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.BackColor = System.Drawing.Color.Transparent
        Me.Label32.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.ForeColor = System.Drawing.Color.Black
        Me.Label32.Location = New System.Drawing.Point(5, 298)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(92, 13)
        Me.Label32.TabIndex = 48
        Me.Label32.Text = "Annual Income"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.BackColor = System.Drawing.Color.Transparent
        Me.Label33.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.Black
        Me.Label33.Location = New System.Drawing.Point(5, 278)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(80, 13)
        Me.Label33.TabIndex = 47
        Me.Label33.Text = "Social Status"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.BackColor = System.Drawing.Color.Transparent
        Me.Label37.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.ForeColor = System.Drawing.Color.Black
        Me.Label37.Location = New System.Drawing.Point(5, 258)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(88, 13)
        Me.Label37.TabIndex = 46
        Me.Label37.Text = "Patient Status"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.BackColor = System.Drawing.Color.Transparent
        Me.Label41.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.ForeColor = System.Drawing.Color.Black
        Me.Label41.Location = New System.Drawing.Point(5, 236)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(85, 13)
        Me.Label41.TabIndex = 45
        Me.Label41.Text = "Family Doctor"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.Color.Transparent
        Me.Label20.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.Black
        Me.Label20.Location = New System.Drawing.Point(5, 102)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(59, 13)
        Me.Label20.TabIndex = 44
        Me.Label20.Text = "Nominee "
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.Color.Transparent
        Me.Label21.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.Black
        Me.Label21.Location = New System.Drawing.Point(5, 122)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(106, 13)
        Me.Label21.TabIndex = 43
        Me.Label21.Text = "Nominee Relation"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.BackColor = System.Drawing.Color.Transparent
        Me.Label22.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.Black
        Me.Label22.Location = New System.Drawing.Point(5, 142)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(51, 13)
        Me.Label22.TabIndex = 42
        Me.Label22.Text = "Insured"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.BackColor = System.Drawing.Color.Transparent
        Me.Label23.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.Black
        Me.Label23.Location = New System.Drawing.Point(5, 82)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(88, 13)
        Me.Label23.TabIndex = 41
        Me.Label23.Text = "Last Visit Date"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.BackColor = System.Drawing.Color.Transparent
        Me.Label24.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.Black
        Me.Label24.Location = New System.Drawing.Point(5, 62)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(59, 13)
        Me.Label24.TabIndex = 40
        Me.Label24.Text = "Reg Date"
        '
        'Lbl_remarks
        '
        Me.Lbl_remarks.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_remarks.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_remarks.ForeColor = System.Drawing.Color.Black
        Me.Lbl_remarks.Location = New System.Drawing.Point(135, 396)
        Me.Lbl_remarks.Name = "Lbl_remarks"
        Me.Lbl_remarks.Size = New System.Drawing.Size(231, 57)
        Me.Lbl_remarks.TabIndex = 39
        '
        'Lbl_Nominee
        '
        Me.Lbl_Nominee.AutoSize = True
        Me.Lbl_Nominee.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Nominee.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Nominee.ForeColor = System.Drawing.Color.Black
        Me.Lbl_Nominee.Location = New System.Drawing.Point(135, 102)
        Me.Lbl_Nominee.Name = "Lbl_Nominee"
        Me.Lbl_Nominee.Size = New System.Drawing.Size(0, 14)
        Me.Lbl_Nominee.TabIndex = 38
        '
        'Lbl_NomineeRel
        '
        Me.Lbl_NomineeRel.AutoSize = True
        Me.Lbl_NomineeRel.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_NomineeRel.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_NomineeRel.ForeColor = System.Drawing.Color.Black
        Me.Lbl_NomineeRel.Location = New System.Drawing.Point(135, 122)
        Me.Lbl_NomineeRel.Name = "Lbl_NomineeRel"
        Me.Lbl_NomineeRel.Size = New System.Drawing.Size(0, 14)
        Me.Lbl_NomineeRel.TabIndex = 20
        '
        'Lbl_IdentificationMark
        '
        Me.Lbl_IdentificationMark.AutoSize = True
        Me.Lbl_IdentificationMark.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_IdentificationMark.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_IdentificationMark.ForeColor = System.Drawing.Color.Black
        Me.Lbl_IdentificationMark.Location = New System.Drawing.Point(135, 316)
        Me.Lbl_IdentificationMark.Name = "Lbl_IdentificationMark"
        Me.Lbl_IdentificationMark.Size = New System.Drawing.Size(0, 14)
        Me.Lbl_IdentificationMark.TabIndex = 16
        '
        'Lbl_AnnualIncome
        '
        Me.Lbl_AnnualIncome.AutoSize = True
        Me.Lbl_AnnualIncome.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_AnnualIncome.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_AnnualIncome.ForeColor = System.Drawing.Color.Black
        Me.Lbl_AnnualIncome.Location = New System.Drawing.Point(135, 298)
        Me.Lbl_AnnualIncome.Name = "Lbl_AnnualIncome"
        Me.Lbl_AnnualIncome.Size = New System.Drawing.Size(0, 14)
        Me.Lbl_AnnualIncome.TabIndex = 15
        '
        'Lbl_Patient_Socialstatus
        '
        Me.Lbl_Patient_Socialstatus.AutoSize = True
        Me.Lbl_Patient_Socialstatus.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Patient_Socialstatus.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Patient_Socialstatus.ForeColor = System.Drawing.Color.Black
        Me.Lbl_Patient_Socialstatus.Location = New System.Drawing.Point(135, 278)
        Me.Lbl_Patient_Socialstatus.Name = "Lbl_Patient_Socialstatus"
        Me.Lbl_Patient_Socialstatus.Size = New System.Drawing.Size(0, 14)
        Me.Lbl_Patient_Socialstatus.TabIndex = 14
        '
        'Lbl_Status
        '
        Me.Lbl_Status.AutoSize = True
        Me.Lbl_Status.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Status.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Status.ForeColor = System.Drawing.Color.Black
        Me.Lbl_Status.Location = New System.Drawing.Point(135, 258)
        Me.Lbl_Status.Name = "Lbl_Status"
        Me.Lbl_Status.Size = New System.Drawing.Size(0, 14)
        Me.Lbl_Status.TabIndex = 13
        '
        'Lbl_FamiliyDoctor
        '
        Me.Lbl_FamiliyDoctor.AutoSize = True
        Me.Lbl_FamiliyDoctor.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_FamiliyDoctor.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_FamiliyDoctor.ForeColor = System.Drawing.Color.Black
        Me.Lbl_FamiliyDoctor.Location = New System.Drawing.Point(135, 236)
        Me.Lbl_FamiliyDoctor.Name = "Lbl_FamiliyDoctor"
        Me.Lbl_FamiliyDoctor.Size = New System.Drawing.Size(0, 14)
        Me.Lbl_FamiliyDoctor.TabIndex = 12
        '
        'Lbl_Employer
        '
        Me.Lbl_Employer.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Employer.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Employer.ForeColor = System.Drawing.Color.Black
        Me.Lbl_Employer.Location = New System.Drawing.Point(135, 162)
        Me.Lbl_Employer.Name = "Lbl_Employer"
        Me.Lbl_Employer.Size = New System.Drawing.Size(231, 67)
        Me.Lbl_Employer.TabIndex = 11
        '
        'Label47
        '
        Me.Label47.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.Label47.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label47.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.ForeColor = System.Drawing.Color.White
        Me.Label47.Image = CType(resources.GetObject("Label47.Image"), System.Drawing.Image)
        Me.Label47.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.Label47.Location = New System.Drawing.Point(2, 1)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(358, 24)
        Me.Label47.TabIndex = 10
        Me.Label47.Text = "O t h e r   I n f o r m a t i o n s"
        '
        'Lbl_Insured
        '
        Me.Lbl_Insured.AutoSize = True
        Me.Lbl_Insured.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Insured.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Insured.ForeColor = System.Drawing.Color.Black
        Me.Lbl_Insured.Location = New System.Drawing.Point(135, 142)
        Me.Lbl_Insured.Name = "Lbl_Insured"
        Me.Lbl_Insured.Size = New System.Drawing.Size(0, 14)
        Me.Lbl_Insured.TabIndex = 8
        '
        'Lbl_LastVistdate
        '
        Me.Lbl_LastVistdate.AutoSize = True
        Me.Lbl_LastVistdate.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_LastVistdate.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_LastVistdate.ForeColor = System.Drawing.Color.Black
        Me.Lbl_LastVistdate.Location = New System.Drawing.Point(135, 82)
        Me.Lbl_LastVistdate.Name = "Lbl_LastVistdate"
        Me.Lbl_LastVistdate.Size = New System.Drawing.Size(0, 14)
        Me.Lbl_LastVistdate.TabIndex = 5
        '
        'Lbl_RegDate
        '
        Me.Lbl_RegDate.AutoSize = True
        Me.Lbl_RegDate.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_RegDate.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_RegDate.ForeColor = System.Drawing.Color.Black
        Me.Lbl_RegDate.Location = New System.Drawing.Point(135, 62)
        Me.Lbl_RegDate.Name = "Lbl_RegDate"
        Me.Lbl_RegDate.Size = New System.Drawing.Size(0, 14)
        Me.Lbl_RegDate.TabIndex = 3
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Tahoma", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(250, 9)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(330, 24)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "P a t i e n t     I n f o r m a t i o n"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Transparent
        Me.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel2.Controls.Add(Me.Lbl_FamilyName)
        Me.Panel2.Controls.Add(Me.Label27)
        Me.Panel2.Controls.Add(Me.Lbl_SOCNo)
        Me.Panel2.Controls.Add(Me.Label25)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Controls.Add(Me.Label8)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.Label11)
        Me.Panel2.Controls.Add(Me.Label13)
        Me.Panel2.Controls.Add(Me.Label14)
        Me.Panel2.Controls.Add(Me.Label15)
        Me.Panel2.Controls.Add(Me.Label16)
        Me.Panel2.Controls.Add(Me.Label17)
        Me.Panel2.Controls.Add(Me.Label18)
        Me.Panel2.Controls.Add(Me.Label19)
        Me.Panel2.Controls.Add(Me.Lbl_MartialStatus)
        Me.Panel2.Controls.Add(Me.Lbl_DOB)
        Me.Panel2.Controls.Add(Me.Lbl_Gender)
        Me.Panel2.Controls.Add(Me.Lbl_Age)
        Me.Panel2.Controls.Add(Me.Lbl_Email)
        Me.Panel2.Controls.Add(Me.Lbl_Mob2)
        Me.Panel2.Controls.Add(Me.Lbl_Mob1)
        Me.Panel2.Controls.Add(Me.Lbl_Phone2)
        Me.Panel2.Controls.Add(Me.Lbl_Phone1)
        Me.Panel2.Controls.Add(Me.Lbl_Pin)
        Me.Panel2.Controls.Add(Me.Lbl_Country)
        Me.Panel2.Controls.Add(Me.Lbl_State)
        Me.Panel2.Controls.Add(Me.Label12)
        Me.Panel2.Controls.Add(Me.Lbl_City)
        Me.Panel2.Controls.Add(Me.lbl_Address)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.Lbl_PatientID)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.Lbl_Name)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel2.Location = New System.Drawing.Point(47, 44)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(369, 467)
        Me.Panel2.TabIndex = 2
        '
        'Lbl_FamilyName
        '
        Me.Lbl_FamilyName.AutoSize = True
        Me.Lbl_FamilyName.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_FamilyName.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_FamilyName.ForeColor = System.Drawing.Color.Black
        Me.Lbl_FamilyName.Location = New System.Drawing.Point(119, 94)
        Me.Lbl_FamilyName.Name = "Lbl_FamilyName"
        Me.Lbl_FamilyName.Size = New System.Drawing.Size(0, 14)
        Me.Lbl_FamilyName.TabIndex = 41
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.BackColor = System.Drawing.Color.Transparent
        Me.Label27.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.ForeColor = System.Drawing.Color.Black
        Me.Label27.Location = New System.Drawing.Point(8, 95)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(79, 13)
        Me.Label27.TabIndex = 40
        Me.Label27.Text = "Family Name"
        '
        'Lbl_SOCNo
        '
        Me.Lbl_SOCNo.AutoSize = True
        Me.Lbl_SOCNo.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_SOCNo.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_SOCNo.ForeColor = System.Drawing.Color.Black
        Me.Lbl_SOCNo.Location = New System.Drawing.Point(117, 75)
        Me.Lbl_SOCNo.Name = "Lbl_SOCNo"
        Me.Lbl_SOCNo.Size = New System.Drawing.Size(67, 13)
        Me.Lbl_SOCNo.TabIndex = 39
        Me.Lbl_SOCNo.Text = "Soc Sec No"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.BackColor = System.Drawing.Color.Transparent
        Me.Label25.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.ForeColor = System.Drawing.Color.Black
        Me.Label25.Location = New System.Drawing.Point(8, 74)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(67, 13)
        Me.Label25.TabIndex = 38
        Me.Label25.Text = "Soc Sec No"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(8, 447)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(84, 13)
        Me.Label5.TabIndex = 36
        Me.Label5.Text = "MartialStatus"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(8, 407)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(30, 13)
        Me.Label6.TabIndex = 35
        Me.Label6.Text = "DOB"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(8, 207)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(48, 13)
        Me.Label7.TabIndex = 34
        Me.Label7.Text = "Gender"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(8, 427)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(29, 13)
        Me.Label8.TabIndex = 33
        Me.Label8.Text = "Age"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(8, 387)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(37, 13)
        Me.Label9.TabIndex = 32
        Me.Label9.Text = "Email"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(8, 367)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(51, 13)
        Me.Label11.TabIndex = 31
        Me.Label11.Text = "Mobile2"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.Black
        Me.Label13.Location = New System.Drawing.Point(8, 347)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(51, 13)
        Me.Label13.TabIndex = 30
        Me.Label13.Text = "Mobile1"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.Black
        Me.Label14.Location = New System.Drawing.Point(8, 327)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(49, 13)
        Me.Label14.TabIndex = 29
        Me.Label14.Text = "Phone2"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.Black
        Me.Label15.Location = New System.Drawing.Point(8, 307)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(49, 13)
        Me.Label15.TabIndex = 28
        Me.Label15.Text = "Phone1"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.Black
        Me.Label16.Location = New System.Drawing.Point(8, 287)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(52, 13)
        Me.Label16.TabIndex = 27
        Me.Label16.Text = "ZipCode"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.Black
        Me.Label17.Location = New System.Drawing.Point(8, 267)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(52, 13)
        Me.Label17.TabIndex = 26
        Me.Label17.Text = "Country"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.Transparent
        Me.Label18.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.Black
        Me.Label18.Location = New System.Drawing.Point(8, 247)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(38, 13)
        Me.Label18.TabIndex = 25
        Me.Label18.Text = "State"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.Black
        Me.Label19.Location = New System.Drawing.Point(8, 227)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(29, 13)
        Me.Label19.TabIndex = 24
        Me.Label19.Text = "City"
        '
        'Lbl_MartialStatus
        '
        Me.Lbl_MartialStatus.AutoSize = True
        Me.Lbl_MartialStatus.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_MartialStatus.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_MartialStatus.ForeColor = System.Drawing.Color.Black
        Me.Lbl_MartialStatus.Location = New System.Drawing.Point(120, 447)
        Me.Lbl_MartialStatus.Name = "Lbl_MartialStatus"
        Me.Lbl_MartialStatus.Size = New System.Drawing.Size(0, 14)
        Me.Lbl_MartialStatus.TabIndex = 22
        '
        'Lbl_DOB
        '
        Me.Lbl_DOB.AutoSize = True
        Me.Lbl_DOB.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_DOB.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_DOB.ForeColor = System.Drawing.Color.Black
        Me.Lbl_DOB.Location = New System.Drawing.Point(120, 407)
        Me.Lbl_DOB.Name = "Lbl_DOB"
        Me.Lbl_DOB.Size = New System.Drawing.Size(0, 14)
        Me.Lbl_DOB.TabIndex = 21
        '
        'Lbl_Gender
        '
        Me.Lbl_Gender.AutoSize = True
        Me.Lbl_Gender.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Gender.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Gender.ForeColor = System.Drawing.Color.Black
        Me.Lbl_Gender.Location = New System.Drawing.Point(120, 207)
        Me.Lbl_Gender.Name = "Lbl_Gender"
        Me.Lbl_Gender.Size = New System.Drawing.Size(0, 14)
        Me.Lbl_Gender.TabIndex = 20
        '
        'Lbl_Age
        '
        Me.Lbl_Age.AutoSize = True
        Me.Lbl_Age.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Age.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Age.ForeColor = System.Drawing.Color.Black
        Me.Lbl_Age.Location = New System.Drawing.Point(120, 427)
        Me.Lbl_Age.Name = "Lbl_Age"
        Me.Lbl_Age.Size = New System.Drawing.Size(0, 14)
        Me.Lbl_Age.TabIndex = 19
        '
        'Lbl_Email
        '
        Me.Lbl_Email.AutoSize = True
        Me.Lbl_Email.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Email.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Email.ForeColor = System.Drawing.Color.Black
        Me.Lbl_Email.Location = New System.Drawing.Point(120, 387)
        Me.Lbl_Email.Name = "Lbl_Email"
        Me.Lbl_Email.Size = New System.Drawing.Size(0, 14)
        Me.Lbl_Email.TabIndex = 18
        '
        'Lbl_Mob2
        '
        Me.Lbl_Mob2.AutoSize = True
        Me.Lbl_Mob2.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Mob2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Mob2.ForeColor = System.Drawing.Color.Black
        Me.Lbl_Mob2.Location = New System.Drawing.Point(120, 367)
        Me.Lbl_Mob2.Name = "Lbl_Mob2"
        Me.Lbl_Mob2.Size = New System.Drawing.Size(0, 14)
        Me.Lbl_Mob2.TabIndex = 17
        '
        'Lbl_Mob1
        '
        Me.Lbl_Mob1.AutoSize = True
        Me.Lbl_Mob1.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Mob1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Mob1.ForeColor = System.Drawing.Color.Black
        Me.Lbl_Mob1.Location = New System.Drawing.Point(120, 347)
        Me.Lbl_Mob1.Name = "Lbl_Mob1"
        Me.Lbl_Mob1.Size = New System.Drawing.Size(0, 14)
        Me.Lbl_Mob1.TabIndex = 16
        '
        'Lbl_Phone2
        '
        Me.Lbl_Phone2.AutoSize = True
        Me.Lbl_Phone2.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Phone2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Phone2.ForeColor = System.Drawing.Color.Black
        Me.Lbl_Phone2.Location = New System.Drawing.Point(120, 327)
        Me.Lbl_Phone2.Name = "Lbl_Phone2"
        Me.Lbl_Phone2.Size = New System.Drawing.Size(0, 14)
        Me.Lbl_Phone2.TabIndex = 15
        '
        'Lbl_Phone1
        '
        Me.Lbl_Phone1.AutoSize = True
        Me.Lbl_Phone1.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Phone1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Phone1.ForeColor = System.Drawing.Color.Black
        Me.Lbl_Phone1.Location = New System.Drawing.Point(120, 307)
        Me.Lbl_Phone1.Name = "Lbl_Phone1"
        Me.Lbl_Phone1.Size = New System.Drawing.Size(0, 14)
        Me.Lbl_Phone1.TabIndex = 14
        '
        'Lbl_Pin
        '
        Me.Lbl_Pin.AutoSize = True
        Me.Lbl_Pin.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Pin.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Pin.ForeColor = System.Drawing.Color.Black
        Me.Lbl_Pin.Location = New System.Drawing.Point(120, 287)
        Me.Lbl_Pin.Name = "Lbl_Pin"
        Me.Lbl_Pin.Size = New System.Drawing.Size(0, 14)
        Me.Lbl_Pin.TabIndex = 13
        '
        'Lbl_Country
        '
        Me.Lbl_Country.AutoSize = True
        Me.Lbl_Country.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Country.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Country.ForeColor = System.Drawing.Color.Black
        Me.Lbl_Country.Location = New System.Drawing.Point(120, 267)
        Me.Lbl_Country.Name = "Lbl_Country"
        Me.Lbl_Country.Size = New System.Drawing.Size(0, 14)
        Me.Lbl_Country.TabIndex = 12
        '
        'Lbl_State
        '
        Me.Lbl_State.AutoSize = True
        Me.Lbl_State.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_State.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_State.ForeColor = System.Drawing.Color.Black
        Me.Lbl_State.Location = New System.Drawing.Point(120, 247)
        Me.Lbl_State.Name = "Lbl_State"
        Me.Lbl_State.Size = New System.Drawing.Size(0, 14)
        Me.Lbl_State.TabIndex = 11
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.Label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label12.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.White
        Me.Label12.Image = CType(resources.GetObject("Label12.Image"), System.Drawing.Image)
        Me.Label12.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.Label12.Location = New System.Drawing.Point(5, 1)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(358, 24)
        Me.Label12.TabIndex = 10
        Me.Label12.Text = "P e r s o n a l   D e t a i l s"
        '
        'Lbl_City
        '
        Me.Lbl_City.AutoSize = True
        Me.Lbl_City.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_City.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_City.ForeColor = System.Drawing.Color.Black
        Me.Lbl_City.Location = New System.Drawing.Point(120, 227)
        Me.Lbl_City.Name = "Lbl_City"
        Me.Lbl_City.Size = New System.Drawing.Size(0, 14)
        Me.Lbl_City.TabIndex = 8
        '
        'lbl_Address
        '
        Me.lbl_Address.BackColor = System.Drawing.Color.Transparent
        Me.lbl_Address.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lbl_Address.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_Address.ForeColor = System.Drawing.Color.Black
        Me.lbl_Address.Location = New System.Drawing.Point(120, 119)
        Me.lbl_Address.Name = "lbl_Address"
        Me.lbl_Address.Size = New System.Drawing.Size(241, 84)
        Me.lbl_Address.TabIndex = 7
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(8, 114)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Address"
        '
        'Lbl_PatientID
        '
        Me.Lbl_PatientID.AutoSize = True
        Me.Lbl_PatientID.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_PatientID.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_PatientID.ForeColor = System.Drawing.Color.Black
        Me.Lbl_PatientID.Location = New System.Drawing.Point(120, 56)
        Me.Lbl_PatientID.Name = "Lbl_PatientID"
        Me.Lbl_PatientID.Size = New System.Drawing.Size(0, 14)
        Me.Lbl_PatientID.TabIndex = 5
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(8, 53)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Patient ID"
        '
        'Lbl_Name
        '
        Me.Lbl_Name.AutoSize = True
        Me.Lbl_Name.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Name.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Name.ForeColor = System.Drawing.Color.Black
        Me.Lbl_Name.Location = New System.Drawing.Point(120, 34)
        Me.Lbl_Name.Name = "Lbl_Name"
        Me.Lbl_Name.Size = New System.Drawing.Size(0, 14)
        Me.Lbl_Name.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(8, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(83, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Patient Name"
        '
        'Patient_InfoSheet_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.LeftGradiant
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(784, 530)
        Me.ControlBox = False
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Patient_InfoSheet_Frm"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Name As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Lbl_PatientID As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lbl_Address As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Lbl_City As System.Windows.Forms.Label
    Friend WithEvents Lbl_Pin As System.Windows.Forms.Label
    Friend WithEvents Lbl_Country As System.Windows.Forms.Label
    Friend WithEvents Lbl_State As System.Windows.Forms.Label
    Friend WithEvents Lbl_Mob1 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Phone2 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Age As System.Windows.Forms.Label
    Friend WithEvents Lbl_Email As System.Windows.Forms.Label
    Friend WithEvents Lbl_Mob2 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Gender As System.Windows.Forms.Label
    Friend WithEvents Lbl_MartialStatus As System.Windows.Forms.Label
    Friend WithEvents Lbl_DOB As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_NomineeRel As System.Windows.Forms.Label
    Friend WithEvents Lbl_IdentificationMark As System.Windows.Forms.Label
    Friend WithEvents Lbl_AnnualIncome As System.Windows.Forms.Label
    Friend WithEvents Lbl_Patient_Socialstatus As System.Windows.Forms.Label
    Friend WithEvents Lbl_Status As System.Windows.Forms.Label
    Friend WithEvents Lbl_FamiliyDoctor As System.Windows.Forms.Label
    Friend WithEvents Lbl_Employer As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Insured As System.Windows.Forms.Label
    Friend WithEvents Lbl_LastVistdate As System.Windows.Forms.Label
    Friend WithEvents Lbl_RegDate As System.Windows.Forms.Label
    Friend WithEvents Lbl_Nominee As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Lbl_remarks As System.Windows.Forms.Label
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Btn_Edit As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Lbl_Phone1 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Lbl_SOCNo As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Occupation As System.Windows.Forms.Label
    Friend WithEvents Lbl_FamilyName As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
End Class
