﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Bank_Accounts_Reg_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Bank_Accounts_Reg_Frm))
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle16 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Pnl_Header = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel()
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label()
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel()
        Me.Btn_Clear = New System.Windows.Forms.Button()
        Me.Btn_Close = New System.Windows.Forms.Button()
        Me.Btn_Delete = New System.Windows.Forms.Button()
        Me.Btn_Save = New System.Windows.Forms.Button()
        Me.Btn_Find = New System.Windows.Forms.Button()
        Me.Txt_BankAcc_ID = New System.Windows.Forms.TextBox()
        Me.Lbl_DocID = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Dgvw_Bank_Account_Master = New System.Windows.Forms.DataGridView()
        Me.Txt_BankAddress = New System.Windows.Forms.TextBox()
        Me.Txt_Remarks = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Cmb_Bank_Name = New System.Windows.Forms.ComboBox()
        Me.Cmb_Active = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Pnl_BankAccountdet = New System.Windows.Forms.Panel()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Cmb_Payment_Mode = New System.Windows.Forms.ComboBox()
        Me.Dtp_OpDate = New System.Windows.Forms.DateTimePicker()
        Me.Cmb_Acc_Type = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Txt_Balance = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Txt_AccNo = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Pnl_Header.SuspendLayout()
        Me.Pnl_Tran_mode.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        CType(Me.Dgvw_Bank_Account_Master, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Pnl_BankAccountdet.SuspendLayout()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.SystemColors.HotTrack
        Me.Pnl_Header.Controls.Add(Me.Label1)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(659, 24)
        Me.Pnl_Header.TabIndex = 100
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(3, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(266, 18)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "B a n k   A c c o u n t s   R e g i s t e r"
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(301, 30)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(74, 22)
        Me.Pnl_Tran_mode.TabIndex = 48
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(4, 1)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(68, 16)
        Me.Lbl_Tran_Mode.TabIndex = 0
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Delete)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(6, 305)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(231, 35)
        Me.Pnl_Common_Btn.TabIndex = 6
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(115, 3)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear.TabIndex = 3
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(171, 3)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 4
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Delete
        '
        Me.Btn_Delete.BackgroundImage = CType(resources.GetObject("Btn_Delete.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Delete.Location = New System.Drawing.Point(59, 3)
        Me.Btn_Delete.Name = "Btn_Delete"
        Me.Btn_Delete.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Delete.TabIndex = 2
        Me.Btn_Delete.Text = "Delete"
        Me.Btn_Delete.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(3, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save.TabIndex = 1
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Btn_Find
        '
        Me.Btn_Find.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find.BackgroundImage = CType(resources.GetObject("Btn_Find.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find.ForeColor = System.Drawing.Color.White
        Me.Btn_Find.Location = New System.Drawing.Point(248, 30)
        Me.Btn_Find.Name = "Btn_Find"
        Me.Btn_Find.Size = New System.Drawing.Size(29, 21)
        Me.Btn_Find.TabIndex = 1
        Me.Btn_Find.TabStop = False
        Me.Btn_Find.Text = "F2"
        Me.Btn_Find.UseVisualStyleBackColor = False
        Me.Btn_Find.Visible = False
        '
        'Txt_BankAcc_ID
        '
        Me.Txt_BankAcc_ID.BackColor = System.Drawing.Color.White
        Me.Txt_BankAcc_ID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_BankAcc_ID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_BankAcc_ID.Location = New System.Drawing.Point(119, 30)
        Me.Txt_BankAcc_ID.Name = "Txt_BankAcc_ID"
        Me.Txt_BankAcc_ID.Size = New System.Drawing.Size(128, 21)
        Me.Txt_BankAcc_ID.TabIndex = 0
        '
        'Lbl_DocID
        '
        Me.Lbl_DocID.AutoSize = True
        Me.Lbl_DocID.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_DocID.ForeColor = System.Drawing.Color.White
        Me.Lbl_DocID.Location = New System.Drawing.Point(8, 34)
        Me.Lbl_DocID.Name = "Lbl_DocID"
        Me.Lbl_DocID.Size = New System.Drawing.Size(74, 13)
        Me.Lbl_DocID.TabIndex = 50
        Me.Lbl_DocID.Text = "Bank A/c ID"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(8, 57)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(70, 13)
        Me.Label5.TabIndex = 91
        Me.Label5.Text = "Bank Name"
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.FromArgb(CType(CType(19, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(153, Byte), Integer))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(3, 343)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(650, 18)
        Me.Label7.TabIndex = 142
        Me.Label7.Text = "B a n k   A c c o u n t   M a s t e r"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Dgvw_Bank_Account_Master
        '
        Me.Dgvw_Bank_Account_Master.AllowUserToAddRows = False
        Me.Dgvw_Bank_Account_Master.AllowUserToDeleteRows = False
        Me.Dgvw_Bank_Account_Master.AllowUserToResizeColumns = False
        Me.Dgvw_Bank_Account_Master.AllowUserToResizeRows = False
        DataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(248, Byte), Integer))
        DataGridViewCellStyle13.ForeColor = System.Drawing.Color.DarkBlue
        Me.Dgvw_Bank_Account_Master.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle13
        Me.Dgvw_Bank_Account_Master.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(236, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Dgvw_Bank_Account_Master.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(CType(CType(75, Byte), Integer), CType(CType(116, Byte), Integer), CType(CType(165, Byte), Integer))
        DataGridViewCellStyle14.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle14.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgvw_Bank_Account_Master.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle14
        Me.Dgvw_Bank_Account_Master.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Dgvw_Bank_Account_Master.Location = New System.Drawing.Point(3, 364)
        Me.Dgvw_Bank_Account_Master.Name = "Dgvw_Bank_Account_Master"
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(179, Byte), Integer))
        DataGridViewCellStyle15.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle15.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgvw_Bank_Account_Master.RowHeadersDefaultCellStyle = DataGridViewCellStyle15
        Me.Dgvw_Bank_Account_Master.RowHeadersVisible = False
        DataGridViewCellStyle16.BackColor = System.Drawing.Color.FromArgb(CType(CType(219, Byte), Integer), CType(CType(227, Byte), Integer), CType(CType(249, Byte), Integer))
        DataGridViewCellStyle16.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle16.ForeColor = System.Drawing.Color.DarkBlue
        DataGridViewCellStyle16.SelectionBackColor = System.Drawing.Color.DeepSkyBlue
        DataGridViewCellStyle16.SelectionForeColor = System.Drawing.Color.Black
        Me.Dgvw_Bank_Account_Master.RowsDefaultCellStyle = DataGridViewCellStyle16
        Me.Dgvw_Bank_Account_Master.Size = New System.Drawing.Size(650, 136)
        Me.Dgvw_Bank_Account_Master.TabIndex = 141
        '
        'Txt_BankAddress
        '
        Me.Txt_BankAddress.BackColor = System.Drawing.Color.White
        Me.Txt_BankAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_BankAddress.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_BankAddress.Location = New System.Drawing.Point(391, 72)
        Me.Txt_BankAddress.Multiline = True
        Me.Txt_BankAddress.Name = "Txt_BankAddress"
        Me.Txt_BankAddress.ReadOnly = True
        Me.Txt_BankAddress.Size = New System.Drawing.Size(262, 73)
        Me.Txt_BankAddress.TabIndex = 9
        Me.Txt_BankAddress.TabStop = False
        '
        'Txt_Remarks
        '
        Me.Txt_Remarks.BackColor = System.Drawing.Color.White
        Me.Txt_Remarks.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Remarks.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Remarks.Location = New System.Drawing.Point(119, 251)
        Me.Txt_Remarks.Name = "Txt_Remarks"
        Me.Txt_Remarks.Size = New System.Drawing.Size(177, 21)
        Me.Txt_Remarks.TabIndex = 4
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(11, 253)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(60, 13)
        Me.Label8.TabIndex = 4
        Me.Label8.Text = "Narration"
        '
        'Cmb_Bank_Name
        '
        Me.Cmb_Bank_Name.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Bank_Name.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Bank_Name.FormattingEnabled = True
        Me.Cmb_Bank_Name.Location = New System.Drawing.Point(119, 54)
        Me.Cmb_Bank_Name.Name = "Cmb_Bank_Name"
        Me.Cmb_Bank_Name.Size = New System.Drawing.Size(257, 21)
        Me.Cmb_Bank_Name.TabIndex = 2
        '
        'Cmb_Active
        '
        Me.Cmb_Active.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Active.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Active.FormattingEnabled = True
        Me.Cmb_Active.Location = New System.Drawing.Point(118, 275)
        Me.Cmb_Active.Name = "Cmb_Active"
        Me.Cmb_Active.Size = New System.Drawing.Size(67, 21)
        Me.Cmb_Active.TabIndex = 5
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(11, 275)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(43, 13)
        Me.Label9.TabIndex = 158
        Me.Label9.Text = "Active"
        '
        'Pnl_BankAccountdet
        '
        Me.Pnl_BankAccountdet.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_BankAccountdet.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_BankAccountdet.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_BankAccountdet.Controls.Add(Me.Label11)
        Me.Pnl_BankAccountdet.Controls.Add(Me.Label4)
        Me.Pnl_BankAccountdet.Controls.Add(Me.Cmb_Payment_Mode)
        Me.Pnl_BankAccountdet.Controls.Add(Me.Dtp_OpDate)
        Me.Pnl_BankAccountdet.Controls.Add(Me.Cmb_Acc_Type)
        Me.Pnl_BankAccountdet.Controls.Add(Me.Label2)
        Me.Pnl_BankAccountdet.Controls.Add(Me.Txt_Balance)
        Me.Pnl_BankAccountdet.Controls.Add(Me.Label6)
        Me.Pnl_BankAccountdet.Controls.Add(Me.Txt_AccNo)
        Me.Pnl_BankAccountdet.Controls.Add(Me.Label3)
        Me.Pnl_BankAccountdet.Enabled = False
        Me.Pnl_BankAccountdet.ForeColor = System.Drawing.Color.Black
        Me.Pnl_BankAccountdet.Location = New System.Drawing.Point(6, 88)
        Me.Pnl_BankAccountdet.Name = "Pnl_BankAccountdet"
        Me.Pnl_BankAccountdet.Size = New System.Drawing.Size(372, 157)
        Me.Pnl_BankAccountdet.TabIndex = 3
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(5, 108)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(92, 13)
        Me.Label11.TabIndex = 10026
        Me.Label11.Text = "Payment Mode"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(5, 83)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(83, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Opening Date"
        '
        'Cmb_Payment_Mode
        '
        Me.Cmb_Payment_Mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.Cmb_Payment_Mode.CausesValidation = False
        Me.Cmb_Payment_Mode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Payment_Mode.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Payment_Mode.FormattingEnabled = True
        Me.Cmb_Payment_Mode.ItemHeight = 13
        Me.Cmb_Payment_Mode.Location = New System.Drawing.Point(113, 101)
        Me.Cmb_Payment_Mode.Name = "Cmb_Payment_Mode"
        Me.Cmb_Payment_Mode.Size = New System.Drawing.Size(177, 21)
        Me.Cmb_Payment_Mode.TabIndex = 4
        '
        'Dtp_OpDate
        '
        Me.Dtp_OpDate.CustomFormat = "dd/MM/yyyy"
        Me.Dtp_OpDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_OpDate.Location = New System.Drawing.Point(113, 75)
        Me.Dtp_OpDate.Name = "Dtp_OpDate"
        Me.Dtp_OpDate.Size = New System.Drawing.Size(109, 21)
        Me.Dtp_OpDate.TabIndex = 3
        '
        'Cmb_Acc_Type
        '
        Me.Cmb_Acc_Type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Acc_Type.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Acc_Type.FormattingEnabled = True
        Me.Cmb_Acc_Type.Location = New System.Drawing.Point(113, 23)
        Me.Cmb_Acc_Type.Name = "Cmb_Acc_Type"
        Me.Cmb_Acc_Type.Size = New System.Drawing.Size(255, 21)
        Me.Cmb_Acc_Type.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(4, 28)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(58, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "A/c Type"
        '
        'Txt_Balance
        '
        Me.Txt_Balance.BackColor = System.Drawing.Color.White
        Me.Txt_Balance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Balance.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Balance.Location = New System.Drawing.Point(113, 127)
        Me.Txt_Balance.Name = "Txt_Balance"
        Me.Txt_Balance.Size = New System.Drawing.Size(177, 21)
        Me.Txt_Balance.TabIndex = 5
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(4, 132)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(99, 13)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Balance Amount"
        '
        'Txt_AccNo
        '
        Me.Txt_AccNo.BackColor = System.Drawing.Color.White
        Me.Txt_AccNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_AccNo.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_AccNo.Location = New System.Drawing.Point(113, 49)
        Me.Txt_AccNo.Name = "Txt_AccNo"
        Me.Txt_AccNo.Size = New System.Drawing.Size(178, 21)
        Me.Txt_AccNo.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(4, 54)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "A/c No"
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.FromArgb(CType(CType(19, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(153, Byte), Integer))
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(391, 52)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(262, 18)
        Me.Label10.TabIndex = 159
        Me.Label10.Text = "B a n k   A d d r e s s"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.FromArgb(CType(CType(19, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(153, Byte), Integer))
        Me.Label12.ForeColor = System.Drawing.Color.White
        Me.Label12.Location = New System.Drawing.Point(7, 89)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(370, 18)
        Me.Label12.TabIndex = 160
        Me.Label12.Text = "B a n k A c c o u n t   D e t a i l s"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Bank_Accounts_Reg_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Highlight
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(659, 505)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Pnl_BankAccountdet)
        Me.Controls.Add(Me.Cmb_Active)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Cmb_Bank_Name)
        Me.Controls.Add(Me.Txt_Remarks)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Txt_BankAddress)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Dgvw_Bank_Account_Master)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Txt_BankAcc_ID)
        Me.Controls.Add(Me.Lbl_DocID)
        Me.Controls.Add(Me.Pnl_Tran_mode)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.Btn_Find)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Bank_Accounts_Reg_Frm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Pnl_Tran_mode.ResumeLayout(False)
        Me.Pnl_Common_Btn.ResumeLayout(False)
        CType(Me.Dgvw_Bank_Account_Master, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Pnl_BankAccountdet.ResumeLayout(False)
        Me.Pnl_BankAccountdet.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Delete As System.Windows.Forms.Button
    Friend WithEvents Btn_Find As System.Windows.Forms.Button
    Friend WithEvents Txt_BankAcc_ID As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_DocID As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Dgvw_Bank_Account_Master As System.Windows.Forms.DataGridView
    Friend WithEvents Txt_BankAddress As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Remarks As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Bank_Name As System.Windows.Forms.ComboBox
    Friend WithEvents Cmb_Active As System.Windows.Forms.ComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Pnl_BankAccountdet As System.Windows.Forms.Panel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Dtp_OpDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Cmb_Acc_Type As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Txt_Balance As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Txt_AccNo As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Payment_Mode As System.Windows.Forms.ComboBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
End Class
