﻿
Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls

Public Class Doctor_DutyTimings_Frm

#Region "Declarations"
    'Object of Employee Details Bussiness Layer
    Private dt As New Data.DataTable

    Private hms_helper As HMS_Helper = Nothing
    Private Doc_DutyTimings_BL As Doctors_DutyTimings_BL_Cls
    Private mTr_Mode As Tran_Mode
    Private TimeReqCtr As Object

    Dim StartTime As Date = "06:00:00 AM"
    Dim EndTime As Date = "06:00:00 PM"
    Dim TimeIntervel As Double = 30

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing
    Dim BlOffDay As Boolean       'If Off day available marked as true


    Dim GrDtbl As DataTable





    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"

                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"

            End Select
        End Set
    End Property

#End Region

#Region "Methods"

    Private Sub AssignToControl(ByVal dtbl As DataTable)
        Try

            Dim dr As DataTableReader = Nothing
            dr = dtbl.CreateDataReader()
            dr.Read()

            With dr


            End With
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Clear_Form()

        Try


            Txt_FromTime.Text = StartTime
            Txt_Totime.Text = EndTime

            Employee_Info1.Employee_ID = 0
            Txt_DoctorID.Text = ""

            Cmb_Weekdays.SelectedIndex = 0

            GrDtbl = Nothing
            GrDtbl = Get_Datatable()
            Dgvw_DutyTimings.DataSource = GrDtbl
            Dgvw_DutyTimings.Refresh()

            With Cmb_WeekdayOFF
                For i_Ctr = 0 To .Items.Count - 1
                    .SelectedIndex = i_Ctr
                    .SetItemChecked(i_Ctr, False)
                Next
                .SelectedIndex = 0
            End With


            Tr_Mode = Tran_Mode.New_Mode
            Btn_AddtoGrid.Text = "Add"
            Btn_AddtoGrid.Tag = ""
            Cmb_Weekdays.Enabled = True
            Cmb_Services.Enabled = True
            Btn_Save.Enabled = True
            Btn_Delete.Enabled = False


        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub Clear_Time()
        Try
            Btn_AddtoGrid.Text = "Add"
            Btn_AddtoGrid.Tag = ""
            Cmb_Weekdays.Enabled = True
            Cmb_Services.Enabled = True

            If Cmb_Services.Items.Count > 0 Then Cmb_Services.SelectedIndex = 0
            If Cmb_Weekdays.Items.Count > 0 Then Cmb_Weekdays.SelectedIndex = 0

            Txt_FromTime.Text = StartTime
            Txt_Totime.Text = EndTime

            Tr_Mode = Tran_Mode.New_Mode
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Clear_ListBox(ByVal ListCntrol As CheckedListBox)
        Try
            Dim CNT As Integer
            For CNT = 0 To ListCntrol.Items.Count - 1
                ListCntrol.SetItemChecked(CNT, False)
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try

    End Sub

    Private Function Validate_Fields() As Boolean 
        Try


            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If

            If Txt_DoctorID.Text.Trim = "" Then MessageBox.Show("Enter Doctor ID", Product_Name, _
                                       MessageBoxButtons.OK, MessageBoxIcon.Error) : Txt_DoctorID.Focus() : Return False

            'If Cmb_WeekdayOFF.SelectedIndex = 0 Then MessageBox.Show("Select Week day OFF before Add", Product_Name, _
            '                     MessageBoxButtons.OK, MessageBoxIcon.Error) : Cmb_WeekdayOFF.Focus() : Return False

            If Nmr_TimeIntervel.Value = 0 Then MessageBox.Show("Select Valid Appointment intervel", Product_Name, _
                                 MessageBoxButtons.OK, MessageBoxIcon.Error) : Nmr_TimeIntervel.Focus() : Return False


            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function Locate_Employee(ByVal Employee_ID As Integer) As Boolean
        Try

            Employee_Info1.Employee_ID = Employee_ID

            If Not Employee_Info1.Is_Valid Then Exit Function

        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function Locate_Values(ByVal Doc_ID As Integer) As Boolean
        Try
            Dim Dtbl As DataTable = Nothing
            Dim dr As DataTableReader = Nothing

            hms_helper.Fill_Doctorservices(Cmb_Services, Txt_DoctorID.Text.Trim, Tran_Date, "< select >")

            Doc_DutyTimings_BL = New Doctors_DutyTimings_BL_Cls

            If Doc_DutyTimings_BL.Get_Doctor_DutyTime(Dtbl, Doc_ID, Tran_Date) Then

                dr = Dtbl.CreateDataReader
                dr.Read()
                With dr
                    Cmb_StartDay.SelectedValue = .Item("D_StartDay").ToString

                    Call Select_OffDay(.Item("D_OffDay").ToString)
                    'Cmb_WeekdayOFF.SelectedValue = .Item("D_OffDay").ToString
                    Nmr_TimeIntervel.Value = .Item("D_Appointmentinterval").ToString

                    Dtp_StartTime.Text = .Item("D_DutyStarttime").ToString
                    Dtp_EndTime.Text = .Item("D_DutyEndtime").ToString
                End With
                Dtbl = Nothing


                If Doc_DutyTimings_BL.Get_Doc_ServiceWithTime(Dtbl, Doc_ID, Tran_Date) Then
                    GrDtbl = Dtbl
                    Dgvw_DutyTimings.DataSource = GrDtbl
                    Dgvw_DutyTimings.Refresh()
                End If


            End If

        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function Is_CorrectTimeRange(ByVal FrmTime As Date, ByVal Totime As Date) As Boolean
        Try
            If DateDiff(DateInterval.Minute, FrmTime, Totime) >= 0 Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception

        End Try
    End Function

    Private Function Fill_TimePicker(ByVal LstBoxCtrl As ListBox, ByVal TimerangeFrm As Date, ByVal TimerangeTo As Date, ByVal Minitintervel As Integer) As Boolean
        Try
            Dim timesstring As String
            Dim cnt As Integer = 0
            Dim intervel As Long
            cnt = 0
            LstBoxCtrl.Items.Clear()
            intervel = DateDiff(DateInterval.Minute, TimerangeFrm, TimerangeTo) / Minitintervel
            For i = 0 To Int(intervel)
                timesstring = DateAdd(DateInterval.Minute, cnt, TimerangeFrm)
                timesstring = Strings.Right("00000000000" + timesstring, 11)
                LstBoxCtrl.Items.Add(timesstring)
                cnt = cnt + Minitintervel
            Next
        Catch ex As Exception

        End Try
    End Function

    Public Function Validate_Doctor_DutyTimings(ByVal Doc_ID As Integer) As Boolean
        Try

            Dim dtbl As DataTable = Nothing
            dtbl = Nothing
            Doc_DutyTimings_BL = New Doctors_DutyTimings_BL_Cls
            If Doc_DutyTimings_BL.Get_Doctor_DutyTime(dtbl, Doc_ID, Tran_Date) Then

                If dtbl.Rows.Count <> Dgvw_DutyTimings.Rows.Count Then Return False

                If Cmb_StartDay.SelectedValue <> dtbl.Rows(0).Item("D_StartDay").ToString Then Return False
                If Cmb_WeekdayOFF.SelectedValue <> dtbl.Rows(0).Item("D_OffDay").ToString Then Return False
                If Nmr_TimeIntervel.Value <> dtbl.Rows(0).Item("D_Appointmentinterval").ToString Then Return False

                With Dgvw_DutyTimings

                    For i = 0 To .Rows.Count - 1
                        If .Rows(i).Cells("Monday").Value.ToString.Trim <> dtbl.Rows(i).Item("D_Mon").ToString.Trim Then Return False
                        If .Rows(i).Cells("Tuesday").Value.ToString.Trim <> dtbl.Rows(i).Item("D_Tue").ToString.Trim Then Return False
                        If .Rows(i).Cells("Wednesday").Value.ToString.Trim <> dtbl.Rows(i).Item("D_Wed").ToString.Trim Then Return False
                        If .Rows(i).Cells("Thursday").Value.ToString.Trim <> dtbl.Rows(i).Item("D_Thu").ToString.Trim Then Return False
                        If .Rows(i).Cells("Friday").Value.ToString.Trim <> dtbl.Rows(i).Item("D_Fri").ToString.Trim Then Return False
                        If .Rows(i).Cells("Saturday").Value.ToString.Trim <> dtbl.Rows(i).Item("D_Sat").ToString.Trim Then Return False
                        If .Rows(i).Cells("Sunday").Value.ToString.Trim <> dtbl.Rows(i).Item("D_Sun").ToString.Trim Then Return False
                    Next

                End With

            Else
                Return False
            End If
            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Get_Datatable() As DataTable
        Try
            Dim dt As New DataTable

            dt.Columns.Add("Services")
            dt.Columns.Add("Monday")
            dt.Columns.Add("Tuesday")
            dt.Columns.Add("Wednesday")
            dt.Columns.Add("Thursday")
            dt.Columns.Add("Friday")
            dt.Columns.Add("Saturday")
            dt.Columns.Add("Sunday")
            dt.Columns.Add("ServiceID")

            Return dt
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Private Function Add_ValueTo_Datarow(ByRef Dtbl As DataTable, _
                                         ByVal SeviceID As String, _
                                         ByVal Services As String, _
                                         ByVal Monday As String, _
                                         ByVal Tuesday As String, _
                                         ByVal Wednesday As String, _
                                         ByVal Thursday As String, _
                                         ByVal Friday As String, _
                                         ByVal Saturday As String, _
                                         ByVal Sunday As String _
                                         ) As DataRow
        Try
            Dim Dr As DataRow
            Dr = Dtbl.NewRow
            Dr("ServiceID") = SeviceID
            Dr("Services") = Services
            Dr("Monday") = Monday
            Dr("Tuesday") = Tuesday
            Dr("Wednesday") = Wednesday
            Dr("Thursday") = Thursday
            Dr("Friday") = Friday
            Dr("Saturday") = Saturday
            Dr("Sunday") = Sunday


            Return Dr
        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Private Function Edit_DataTable(ByRef dtbl As DataTable, _
                                          ByVal Service As String, _
                                          ByVal WeekDay As String, _
                                          ByVal FromTime As String, _
                                          ByVal ToTime As String) As Boolean

        Try
            Dim ValueStr As String
            ValueStr = FromTime + " - " + ToTime
            For i = 0 To dtbl.Rows.Count - 1
                'comparing selected service with grid value
                If Service = dtbl.Rows(i).Item("Services") Then


                    If dtbl.Rows(i).Item(WeekDay) = "" Then

                        'editing existing row 
                        dtbl.Rows(i).Item(WeekDay) = ValueStr
                        dtbl.AcceptChanges()
                        Exit Function
                    Else
                        If dtbl.Rows.Count = i Then
                            'adding new time row  for existing service
                            Call Populate_GridVw(True)
                            Exit Function
                        End If


                    End If


                End If

            Next
            'adding new time row  for existing service
            Call Populate_GridVw(True)

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Add_RowTo_DataTable(ByRef dtbl As DataTable, ByRef Dr As DataRow) As Boolean
        Try
            dtbl.Rows.Add(Dr)
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Fill_TimeGrid(ByRef Dgrivw As DataGridView, ByVal dtbl As DataTable) As Boolean
        Try

            Dgrivw.DataSource = dtbl
            Dgrivw.Refresh()
            Dgrivw.Columns(0).Width = 160
            Dgrivw.Columns(1).Width = 130
            Dgrivw.Columns(2).Width = 130
            Dgrivw.Columns(3).Width = 130
            Dgrivw.Columns(4).Width = 130
            Dgrivw.Columns(5).Width = 130
            Dgrivw.Columns(6).Width = 130
            Dgrivw.Columns(7).Width = 130
            Dgrivw.Columns(8).Width = 0

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Populate_GridVw(ByVal IsAdd As Boolean) As Boolean
        Try

            If IsAdd Then
                Dim Dr As DataRow = Nothing
                Dim Cellvalue As String
                Cellvalue = Txt_FromTime.Text.Trim + " - " + Txt_Totime.Text.Trim


                Select Case Cmb_Weekdays.Text.ToUpper

                    Case "MONDAY"
                        Dr = Add_ValueTo_Datarow(GrDtbl, Cmb_Services.SelectedValue, Cmb_Services.Text, _
                                                Cellvalue, "", "", "", "", "", "")
                    Case "TUESDAY"
                        Dr = Add_ValueTo_Datarow(GrDtbl, Cmb_Services.SelectedValue, Cmb_Services.Text, _
                                                "", Cellvalue, "", "", "", "", "")
                    Case "WEDNESDAY"
                        Dr = Add_ValueTo_Datarow(GrDtbl, Cmb_Services.SelectedValue, Cmb_Services.Text, _
                                                 "", "", Cellvalue, "", "", "", "")
                    Case "THURSDAY"
                        Dr = Add_ValueTo_Datarow(GrDtbl, Cmb_Services.SelectedValue, Cmb_Services.Text, _
                                                 "", "", "", Cellvalue, "", "", "")
                    Case "FRIDAY"
                        Dr = Add_ValueTo_Datarow(GrDtbl, Cmb_Services.SelectedValue, Cmb_Services.Text, _
                                                 "", "", "", "", Cellvalue, "", "")
                    Case "SATURDAY"
                        Dr = Add_ValueTo_Datarow(GrDtbl, Cmb_Services.SelectedValue, Cmb_Services.Text, _
                                                 "", "", "", "", "", Cellvalue, "")
                    Case "SUNDAY"
                        Dr = Add_ValueTo_Datarow(GrDtbl, Cmb_Services.SelectedValue, Cmb_Services.Text, _
                                                 "", "", "", "", "", "", Cellvalue)
                End Select

                Call Add_RowTo_DataTable(GrDtbl, Dr)
                Call Fill_TimeGrid(Dgvw_DutyTimings, GrDtbl)


            Else
                'modify

            End If
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Is_ValidTime(ByVal dtbl As DataTable, _
                                 ByVal service As String, _
                                 ByVal weekday As String, _
                                 ByVal FromTime As Date, _
                                 ByVal ToTime As Date, _
                                 Optional ByVal Rowindex As Integer = 0, _
                                 Optional ByVal ColIndex As Integer = 0) As Boolean
        Try


            Dim ValueStr As String = ""
            Dim valFromTime, ValTotime As Date
            Dim ValueStr_2 As String = ""


            Dim newspanFrom, newspanTo, Startspan1, Endspan1 As TimeSpan


            If Tr_Mode = Tran_Mode.New_Mode Then
                For i = 0 To dtbl.Rows.Count - 1

                    If dtbl.Rows(i).Item(weekday) <> "" Then
                        ValueStr = dtbl.Rows(i).Item(weekday).ToString
                        valFromTime = Strings.Left(ValueStr, 10)
                        ValTotime = Strings.Right(ValueStr, 10)

                        newspanFrom = New TimeSpan(Format(FromTime, "HH"), FromTime.Minute, FromTime.Second)
                        Startspan1 = New TimeSpan(Format(valFromTime, "HH"), valFromTime.Minute, valFromTime.Second)
                        Endspan1 = New TimeSpan(Format(ValTotime, "HH"), ValTotime.Minute, ValTotime.Second)
                        newspanTo = New TimeSpan(Format(ToTime, "HH"), ToTime.Minute, ToTime.Second)



                        If newspanFrom.Ticks < Endspan1.Ticks Then

                            If newspanTo.Ticks > Startspan1.Ticks Then
                                Return False
                            End If

                        End If

                    End If

                Next

                Return True

            Else

                For i = 0 To dtbl.Rows.Count - 1
                    If (Not (i = Rowindex) And (dtbl.Columns(weekday).Ordinal = ColIndex)) Then
                        If dtbl.Rows(i).Item(weekday) <> "" Then
                            ValueStr = dtbl.Rows(i).Item(weekday).ToString
                            valFromTime = Strings.Left(ValueStr, 10)
                            ValTotime = Strings.Right(ValueStr, 10)

                            newspanFrom = New TimeSpan(Format(FromTime, "HH"), FromTime.Minute, FromTime.Second)
                            Startspan1 = New TimeSpan(Format(valFromTime, "HH"), valFromTime.Minute, valFromTime.Second)
                            Endspan1 = New TimeSpan(Format(ValTotime, "HH"), ValTotime.Minute, ValTotime.Second)
                            newspanTo = New TimeSpan(Format(ToTime, "HH"), ToTime.Minute, ToTime.Second)



                            If newspanFrom.Ticks < Endspan1.Ticks Then

                                If newspanTo.Ticks > Startspan1.Ticks Then
                                    Return False
                                End If

                            End If

                        End If
                    End If

                Next

                Return True

            End If





        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Edit_ValueInDatatable(ByRef dtbl As DataTable, _
                                          ByVal rowindex As Integer, _
                                          ByVal colindex As Integer, _
                                          ByVal colValue As String) As Boolean
        Try

            dtbl.Rows(rowindex).Item(colindex) = colValue
            dtbl.AcceptChanges()
            'Dgvw_DutyTimings.Refresh()

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function
    
#End Region

    Private Sub DoctorMaster_Frm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            hms_helper = New Hms_Helperimpliments


            Call Fill_Weekdays(Cmb_WeekdayOFF)
            Call Fill_Weekdays(Cmb_Weekdays, "< Select >")
            Call Fill_Weekdays(Cmb_StartDay, "< Select >")



            GrDtbl = Get_Datatable()

            Call Fill_TimeGrid(Dgvw_DutyTimings, GrDtbl)

            'chk_Week_Days.Items.Add("Sunday")


            Txt_FromTime.Text = StartTime
            'Txt_Totime.Text = EndTime



           
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)

        End Try
    End Sub

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try
            Dim Dr As DataTableReader = Nothing
            Dim Dtbl As DataTable = Nothing
            Dim SaveFlg As Integer = 0
            Dim Sel_Value As String = ""
            Dim WeekDayoffStr As String = ""

            Dim Sel_Text As String = ""
            
            Doc_DutyTimings_BL = New Doctors_DutyTimings_BL_Cls
            'Validating Data controls
            If Not Validate_Fields() Then Exit Sub

            'Deleting existing date timings of a select doctor 
            Call Doc_DutyTimings_BL.Del_Doctor_Dutytiming(Dtbl, Txt_DoctorID.Text.Trim, Tran_Date)
            'Validation for change in any values or not 
            If Validate_Doctor_DutyTimings(Txt_DoctorID.Text.Trim) Then
                MessageBox.Show("Doctor Duty Timings  Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Exit Sub
            End If


            With Cmb_WeekdayOFF
                For i_Ctr = 0 To .Items.Count - 1
                    If .GetItemCheckState(i_Ctr) = CheckState.Checked Then
                        .SelectedIndex = i_Ctr
                        WeekDayoffStr = WeekDayoffStr + .SelectedValue + "|"
                    End If

                Next
            End With
            If Len(WeekDayoffStr) > 0 Then WeekDayoffStr = Strings.Left(WeekDayoffStr, Len(WeekDayoffStr) - 1)

            With Doc_DutyTimings_BL
                For i = 0 To GrDtbl.Rows.Count - 1

                    .Doc_TimingID = 0
                    .Doc_ID = Txt_DoctorID.Text.Trim
                    .Reg_Date = Tran_Date
                    .D_Appointmentinterval = Nmr_TimeIntervel.Value


                    .D_StartDay = Cmb_StartDay.SelectedValue
                    

                    


                    .D_OffDay = WeekDayoffStr

                    .D_DutyStarttime = Format(Dtp_StartTime.Value, "hh:mm tt").ToString
                    .D_DutyEndtime = Format(Dtp_EndTime.Value, "hh:mm tt").ToString


                    .Service_ID = GrDtbl.Rows(i).Item("ServiceID").ToString
                    .D_Mon = GrDtbl.Rows(i).Item("Monday").ToString
                    .D_Tue = GrDtbl.Rows(i).Item("Tuesday").ToString
                    .D_Wed = GrDtbl.Rows(i).Item("Wednesday").ToString
                    .D_Thu = GrDtbl.Rows(i).Item("Thursday").ToString
                    .D_Fri = GrDtbl.Rows(i).Item("Friday").ToString
                    .D_Sat = GrDtbl.Rows(i).Item("Saturday").ToString
                    .D_Sun = GrDtbl.Rows(i).Item("Sunday").ToString

                    Dtbl = Nothing
                    If Doc_DutyTimings_BL.Save_DoctorsDutytimings(Dtbl, Tr_Mode, Txt_DoctorID.Text.Trim) Then
                        SaveFlg = 1
                    Else
                        SaveFlg = 0
                    End If
                Next
                    End With
            If SaveFlg = 1 Then
                MessageBox.Show("Doctor Duty Timings  Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                BlOffDay = False
                Call Locate_Values(Txt_DoctorID.Text.Trim)

            Else
                MessageBox.Show("Doctor Duty Timings Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Call Clear_Form()
        Txt_DoctorID.Focus()
    End Sub

    Private Sub DoctorMaster_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then Call SendKeyTab()
    End Sub

    Private Sub DoctorMaster_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

    Private Sub DoctorMaster_Frm_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        Call KeepRightofme(Me, ImageViewer_Frm)
    End Sub

    Private Sub Cmb_Weekdays_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_Weekdays.SelectedIndexChanged
        Try

            If Cmb_Weekdays.SelectedIndex = 0 Then Exit Sub

            If Not Is_Week_OFFDay(Cmb_Weekdays.SelectedValue) Then
                MessageBox.Show("Selected day is already marked as OFF Day, Please check", Product_Name, _
                                MessageBoxButtons.OK, MessageBoxIcon.Error)

                Cmb_Weekdays.SelectedIndex = 0
                Cmb_Weekdays.Focus()
                Exit Sub
            End If

            ' ''If Cmb_WeekdayOFF.SelectedValue = Cmb_Weekdays.SelectedValue Then
            ' ''    MessageBox.Show("Selected day is already marked as OFF Day, Please check", Product_Name, _
            ' ''                    MessageBoxButtons.OK, MessageBoxIcon.Error)

            ' ''    Cmb_Weekdays.SelectedIndex = 0
            ' ''    Cmb_Weekdays.Focus()
            ' ''    Exit Sub
            ' ''End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Cmb_WeekdayOFF_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Cmb_Weekdays.Items.Count > 0 Then Cmb_Weekdays.SelectedIndex = 0
    End Sub

    Private Sub DateTimePicker1_DropDown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Txt_FromTime.DropDown
        Txt_FromTime.ShowUpDown = False
    End Sub

    Private Sub Btn_AddtoGrid_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_AddtoGrid.Click
        Try


            If Txt_DoctorID.Text.Trim = "" Then MessageBox.Show("Enter Doctor ID", Product_Name, _
                                         MessageBoxButtons.OK, MessageBoxIcon.Error) : Txt_DoctorID.Focus() : Exit Sub
            If Cmb_StartDay.SelectedIndex = 0 Then MessageBox.Show("Select Start day before Add", Product_Name, _
                                    MessageBoxButtons.OK, MessageBoxIcon.Error) : Cmb_StartDay.Focus() : Exit Sub

            If Cmb_Weekdays.SelectedIndex = 0 Then MessageBox.Show("Select Week day before Add", Product_Name, _
                                  MessageBoxButtons.OK, MessageBoxIcon.Error) : Cmb_Weekdays.Focus() : Exit Sub

            'If Cmb_WeekdayOFF.SelectedIndex = 0 Then MessageBox.Show("Select Week day OFF before Add", Product_Name, _
            '                     MessageBoxButtons.OK, MessageBoxIcon.Error) : Cmb_WeekdayOFF.Focus() : Exit Sub

            If Nmr_TimeIntervel.Value = 0 Then MessageBox.Show("Select Valid Appointment intervel", Product_Name, _
                                 MessageBoxButtons.OK, MessageBoxIcon.Error) : Nmr_TimeIntervel.Focus() : Exit Sub

            If Cmb_Services.SelectedIndex = 0 Then MessageBox.Show("Select Service before Add", Product_Name, _
                                   MessageBoxButtons.OK, MessageBoxIcon.Error) : Cmb_Services.Focus() : Exit Sub

            If Cmb_Weekdays.SelectedIndex = 0 Then MessageBox.Show("Select day before Add", Product_Name, _
                                  MessageBoxButtons.OK, MessageBoxIcon.Error) : Cmb_Weekdays.Focus() : Exit Sub

            If DateDiff(DateInterval.Minute, Txt_FromTime.Value, Txt_Totime.Value) <= 0 Then
                MessageBox.Show("To time should be greater than From time, Please check", Product_Name, _
                              MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            If DateDiff(DateInterval.Minute, Dtp_StartTime.Value, Txt_FromTime.Value) < 0 Then
                MessageBox.Show(" From time should be greater than or equal to Start time, Please check", Product_Name, _
                              MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_FromTime.Focus()
                Exit Sub
            End If

            If DateDiff(DateInterval.Minute, Dtp_EndTime.Value, Txt_Totime.Value) > 0 Then
                MessageBox.Show(" To Time should be less than End Time, Please check", Product_Name, _
                              MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_Totime.Focus()
                Exit Sub
            End If

            '============================================================================================
            'Doctors off day checking ===================================================================

            If BlOffDay = False Then
                For Cnt = 0 To Cmb_WeekdayOFF.Items.Count - 1
                    If Cmb_WeekdayOFF.GetItemCheckState(Cnt) = CheckState.Checked Then
                        BlOffDay = True
                        Exit For
                    Else
                        BlOffDay = False
                    End If
                Next
            End If
            If BlOffDay = False Then
                If MessageBox.Show("Doctor's Off Day not marked , Do you wish to continue", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.No Then
                    Cmb_WeekdayOFF.Focus()
                    Exit Sub
                Else
                    BlOffDay = True
                End If
            End If

            '============================================================================================
            'Doctors off day checking ===================================================================


            If Tr_Mode = Tran_Mode.New_Mode Then
                If Not Is_ValidTime(GrDtbl, Cmb_Services.Text.Trim, _
                                    Cmb_Weekdays.Text.Trim, _
                                    Txt_FromTime.Text.Trim, _
                                    Txt_Totime.Text.Trim) Then
                    MessageBox.Show("Selected time range is already in the List, Please check", Product_Name, _
                                   MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
                Call Edit_DataTable(GrDtbl, _
                                    Cmb_Services.Text.Trim, _
                                    Cmb_Weekdays.Text.Trim, _
                                    Txt_FromTime.Text.Trim, _
                                    Txt_Totime.Text.Trim)
            Else
                If Not Is_ValidTime(GrDtbl, Cmb_Services.Text.Trim, _
                                    Cmb_Weekdays.Text.Trim, _
                                    Txt_FromTime.Text.Trim, _
                                    Txt_Totime.Text.Trim, Strings.Left(Btn_AddtoGrid.Tag, 3), Strings.Right(Btn_AddtoGrid.Tag, 3)) Then
                    MessageBox.Show("Selected time is already in the List, Please check", Product_Name, _
                                   MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
                Call Edit_ValueInDatatable(GrDtbl, Strings.Left(Btn_AddtoGrid.Tag, 3), Strings.Right(Btn_AddtoGrid.Tag, 3), (Txt_FromTime.Text.Trim + " - " + Txt_Totime.Text.Trim))
                Call Clear_Time()
                Cmb_Weekdays.Focus()
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Dgvw_DutyTimings_CellContentDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgvw_DutyTimings.CellContentDoubleClick
        Try
            With Dgvw_DutyTimings

                Cmb_Services.SelectedValue = .Item(8, e.RowIndex).Value.ToString.Trim
                Cmb_Services.Enabled = False
                Cmb_Weekdays.Text = .Columns(e.ColumnIndex).HeaderText.ToString.Trim
                Cmb_Weekdays.Enabled = False
                Txt_FromTime.Text = Strings.Left(.Item(e.ColumnIndex, e.RowIndex).Value.ToString.Trim, 10)
                Txt_Totime.Text = Strings.Right(.Item(e.ColumnIndex, e.RowIndex).Value.ToString.Trim, 10)


                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_AddtoGrid.Text = "Save"
                Btn_AddtoGrid.Tag = Strings.Right("000" + e.RowIndex.ToString, 3) + "|" + Strings.Right("000" + e.ColumnIndex.ToString, 3)
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click

        Try

            If Txt_DoctorID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "10|200|50|"
                Sql = "SELECT     DoctorID, Name, Address, Designation, EmpID,SS_Number as [SS Number]  FROM    Doctormaster_Vw where Br_Code='" & Branch_Code & "'"
                Call ShowSearchengine(Txt_DoctorID, Sql, 0, "Name", Colwidth, , 0)
            End If

            If Txt_DoctorID.Text.Trim = "" Then
                Txt_DoctorID.Focus()
                Exit Sub
            End If


            hms_helper = New Hms_Helperimpliments
            hms_helper.GetEmpDetailsFromDoctorID(Dtbl, Txt_DoctorID.Text.Trim)
            If Dtbl.Rows.Count = 0 Then Exit Sub

            Call Locate_Employee(Dtbl.Rows(0).Item("EmpID").ToString)

            Call Locate_Values(Txt_DoctorID.Text.Trim)

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Cancel.Click
        Try
            
            Call Clear_Time()

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_DoctorID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_DoctorID.KeyDown
        If e.KeyCode = Keys.F2 Then
            Call Btn_Find_Click(sender, e)
        End If
    End Sub


    Private Sub Txt_DoctorID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_DoctorID.Validating
        Try
            If Txt_DoctorID.Text.Trim <> "" Then
                Dim dtbl As DataTable = Nothing
                Dim dr As DataTableReader = Nothing

                hms_helper = New Hms_Helperimpliments
                hms_helper.GetEmpDetailsFromDoctorID(dtbl, Txt_DoctorID.Text.Trim)
                If dtbl.Rows.Count = 0 Then Exit Sub

                Call Locate_Employee(dtbl.Rows(0).Item("EmpID").ToString)



                REM Locating Last updated Leave for selected Doctor(Max Reg Date)
                Call Locate_Values(Txt_DoctorID.Text.Trim)
            Else
                Exit Sub
                e.Cancel = True
            End If

        Catch ex As Exception
            e.Cancel = True
        End Try
    End Sub

    Private Sub Select_OffDay(ByVal days As String)
        Try
            If Len(days) < 3 Then Exit Sub
            Dim cnt As Integer = 1
            Dim dayStr As String = ""
            days = Replace(days, "|", "")
            For i = 1 To Len(days.Trim) / 3
                'splitting days
                dayStr = Strings.Left(Strings.Mid(days, cnt), 3)

                With Cmb_WeekdayOFF
                    For i_Ctr = 0 To .Items.Count - 1
                        .SelectedIndex = i_Ctr
                        If .SelectedValue = dayStr Then
                            .SetItemChecked(i_Ctr, True)
                        End If
                    Next
                End With

                cnt = cnt + 3

            Next

        Catch ex As Exception

        End Try
    End Sub

    Private Function Is_Week_OFFDay(ByVal weekdaystr As String) As Boolean
        Try

            With Cmb_WeekdayOFF
                For i_Ctr = 0 To .Items.Count - 1
                    If .GetItemCheckState(i_Ctr) = CheckState.Checked Then
                        .SelectedIndex = i_Ctr
                        If .SelectedValue = weekdaystr Then Return False
                    End If
                Next
            End With

            Return True
        Catch ex As Exception

        End Try
    End Function

   
End Class