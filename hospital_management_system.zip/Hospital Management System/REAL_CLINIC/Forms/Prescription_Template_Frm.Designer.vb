﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Prescription_Template_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Prescription_Template_Frm))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Label3 = New System.Windows.Forms.Label
        Me.Btn_Find = New System.Windows.Forms.Button
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Dtp_Tran_Date = New System.Windows.Forms.DateTimePicker
        Me.Cmb_Pres_Templates = New System.Windows.Forms.ComboBox
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Btn_Remove = New System.Windows.Forms.Button
        Me.Btn_Add = New System.Windows.Forms.Button
        Me.Cmb_Route = New System.Windows.Forms.ComboBox
        Me.cmb_Frequency = New System.Windows.Forms.ComboBox
        Me.Txt_Days = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.Txt_Refils = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.Txt_Qty = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Txt_Dose = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Txt_Medicine = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Dgv_Prescription = New REAL_CLINIC.Hms_DGridview(Me.components)
        Me.Medicine = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Dose = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Freequency = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Route = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Qty = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Refils = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Days = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Pres_Continue = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.Dis_Dt = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Status = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.TempID = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.TR_DT = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Cancel = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.Pnl_Header.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Pnl_Tran_mode.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.Dgv_Prescription, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.LightSkyBlue
        Me.Pnl_Header.BackgroundImage = CType(resources.GetObject("Pnl_Header.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Header.Controls.Add(Me.Label1)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(721, 24)
        Me.Pnl_Header.TabIndex = 101
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(8, 1)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(328, 18)
        Me.Label1.TabIndex = 121
        Me.Label1.Text = "P r e s c r i p t i o n  T e m p l a t e   M a s t e r"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Btn_Find)
        Me.Panel1.Controls.Add(Me.Pnl_Tran_mode)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Dtp_Tran_Date)
        Me.Panel1.Controls.Add(Me.Cmb_Pres_Templates)
        Me.Panel1.Location = New System.Drawing.Point(157, 26)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(563, 55)
        Me.Panel1.TabIndex = 100010
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.GhostWhite
        Me.Label3.Location = New System.Drawing.Point(310, 5)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(34, 13)
        Me.Label3.TabIndex = 100014
        Me.Label3.Text = "Date"
        '
        'Btn_Find
        '
        Me.Btn_Find.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find.BackgroundImage = CType(resources.GetObject("Btn_Find.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find.ForeColor = System.Drawing.Color.White
        Me.Btn_Find.Location = New System.Drawing.Point(444, 23)
        Me.Btn_Find.Name = "Btn_Find"
        Me.Btn_Find.Size = New System.Drawing.Size(28, 21)
        Me.Btn_Find.TabIndex = 100013
        Me.Btn_Find.TabStop = False
        Me.Btn_Find.Text = "F2"
        Me.Btn_Find.UseVisualStyleBackColor = False
        Me.Btn_Find.Visible = False
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(474, 22)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(74, 22)
        Me.Pnl_Tran_mode.TabIndex = 100012
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(3, 2)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(68, 16)
        Me.Lbl_Tran_Mode.TabIndex = 126
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.GhostWhite
        Me.Label2.Location = New System.Drawing.Point(17, 5)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(134, 13)
        Me.Label2.TabIndex = 100011
        Me.Label2.Text = "Select Diagnosis Name"
        '
        'Dtp_Tran_Date
        '
        Me.Dtp_Tran_Date.CustomFormat = "dd/MM/yyyy"
        Me.Dtp_Tran_Date.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_Tran_Date.Location = New System.Drawing.Point(310, 24)
        Me.Dtp_Tran_Date.Name = "Dtp_Tran_Date"
        Me.Dtp_Tran_Date.Size = New System.Drawing.Size(101, 21)
        Me.Dtp_Tran_Date.TabIndex = 1
        '
        'Cmb_Pres_Templates
        '
        Me.Cmb_Pres_Templates.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Pres_Templates.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Pres_Templates.FormattingEnabled = True
        Me.Cmb_Pres_Templates.ItemHeight = 13
        Me.Cmb_Pres_Templates.Location = New System.Drawing.Point(16, 24)
        Me.Cmb_Pres_Templates.Name = "Cmb_Pres_Templates"
        Me.Cmb_Pres_Templates.Size = New System.Drawing.Size(289, 21)
        Me.Cmb_Pres_Templates.TabIndex = 0
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Transparent
        Me.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.Btn_Remove)
        Me.Panel2.Controls.Add(Me.Btn_Add)
        Me.Panel2.Controls.Add(Me.Cmb_Route)
        Me.Panel2.Controls.Add(Me.cmb_Frequency)
        Me.Panel2.Controls.Add(Me.Txt_Days)
        Me.Panel2.Controls.Add(Me.Label12)
        Me.Panel2.Controls.Add(Me.Txt_Refils)
        Me.Panel2.Controls.Add(Me.Label11)
        Me.Panel2.Controls.Add(Me.Txt_Qty)
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Controls.Add(Me.Txt_Dose)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.Txt_Medicine)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.Dgv_Prescription)
        Me.Panel2.Location = New System.Drawing.Point(157, 81)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(563, 359)
        Me.Panel2.TabIndex = 100011
        '
        'Btn_Remove
        '
        Me.Btn_Remove.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Remove.BackgroundImage = CType(resources.GetObject("Btn_Remove.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Remove.CausesValidation = False
        Me.Btn_Remove.ForeColor = System.Drawing.Color.Lavender
        Me.Btn_Remove.Location = New System.Drawing.Point(493, 58)
        Me.Btn_Remove.Name = "Btn_Remove"
        Me.Btn_Remove.Size = New System.Drawing.Size(62, 22)
        Me.Btn_Remove.TabIndex = 10
        Me.Btn_Remove.Text = "&Remove"
        Me.Btn_Remove.UseVisualStyleBackColor = False
        '
        'Btn_Add
        '
        Me.Btn_Add.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Add.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Add.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Add.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Add.ForeColor = System.Drawing.Color.White
        Me.Btn_Add.Location = New System.Drawing.Point(443, 58)
        Me.Btn_Add.Name = "Btn_Add"
        Me.Btn_Add.Size = New System.Drawing.Size(46, 22)
        Me.Btn_Add.TabIndex = 9
        Me.Btn_Add.Text = "&Add"
        Me.Btn_Add.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btn_Add.UseVisualStyleBackColor = False
        '
        'Cmb_Route
        '
        Me.Cmb_Route.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Route.FormattingEnabled = True
        Me.Cmb_Route.Items.AddRange(New Object() {"Before Food", "After Food", "Early Morning"})
        Me.Cmb_Route.Location = New System.Drawing.Point(16, 60)
        Me.Cmb_Route.Name = "Cmb_Route"
        Me.Cmb_Route.Size = New System.Drawing.Size(205, 21)
        Me.Cmb_Route.TabIndex = 5
        '
        'cmb_Frequency
        '
        Me.cmb_Frequency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_Frequency.FormattingEnabled = True
        Me.cmb_Frequency.Items.AddRange(New Object() {"Morning", "Morning,After Noon", "Morning,After Noon,Night", "Morning,Night", "Night"})
        Me.cmb_Frequency.Location = New System.Drawing.Point(310, 18)
        Me.cmb_Frequency.Name = "cmb_Frequency"
        Me.cmb_Frequency.Size = New System.Drawing.Size(245, 21)
        Me.cmb_Frequency.TabIndex = 4
        '
        'Txt_Days
        '
        Me.Txt_Days.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Days.Location = New System.Drawing.Point(379, 59)
        Me.Txt_Days.MaxLength = 5
        Me.Txt_Days.Name = "Txt_Days"
        Me.Txt_Days.Size = New System.Drawing.Size(58, 21)
        Me.Txt_Days.TabIndex = 8
        Me.Txt_Days.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.ForeColor = System.Drawing.Color.Transparent
        Me.Label12.Location = New System.Drawing.Point(376, 43)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(35, 13)
        Me.Label12.TabIndex = 1146
        Me.Label12.Text = "Days"
        '
        'Txt_Refils
        '
        Me.Txt_Refils.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Refils.Location = New System.Drawing.Point(310, 59)
        Me.Txt_Refils.MaxLength = 5
        Me.Txt_Refils.Name = "Txt_Refils"
        Me.Txt_Refils.Size = New System.Drawing.Size(63, 21)
        Me.Txt_Refils.TabIndex = 7
        Me.Txt_Refils.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.ForeColor = System.Drawing.Color.Transparent
        Me.Label11.Location = New System.Drawing.Point(307, 43)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(38, 13)
        Me.Label11.TabIndex = 1145
        Me.Label11.Text = "Refils"
        '
        'Txt_Qty
        '
        Me.Txt_Qty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Qty.Location = New System.Drawing.Point(227, 59)
        Me.Txt_Qty.MaxLength = 5
        Me.Txt_Qty.Name = "Txt_Qty"
        Me.Txt_Qty.Size = New System.Drawing.Size(77, 21)
        Me.Txt_Qty.TabIndex = 6
        Me.Txt_Qty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.ForeColor = System.Drawing.Color.Transparent
        Me.Label10.Location = New System.Drawing.Point(224, 43)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(56, 13)
        Me.Label10.TabIndex = 1144
        Me.Label10.Text = "Quantity"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.ForeColor = System.Drawing.Color.Transparent
        Me.Label9.Location = New System.Drawing.Point(14, 44)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(41, 13)
        Me.Label9.TabIndex = 1143
        Me.Label9.Text = "Route"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.ForeColor = System.Drawing.Color.Transparent
        Me.Label7.Location = New System.Drawing.Point(307, 2)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(66, 13)
        Me.Label7.TabIndex = 1142
        Me.Label7.Text = "Frequency"
        '
        'Txt_Dose
        '
        Me.Txt_Dose.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Dose.Location = New System.Drawing.Point(227, 19)
        Me.Txt_Dose.MaxLength = 15
        Me.Txt_Dose.Name = "Txt_Dose"
        Me.Txt_Dose.Size = New System.Drawing.Size(77, 21)
        Me.Txt_Dose.TabIndex = 3
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.Color.Transparent
        Me.Label6.Location = New System.Drawing.Point(224, 3)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(35, 13)
        Me.Label6.TabIndex = 1141
        Me.Label6.Text = "Dose"
        '
        'Txt_Medicine
        '
        Me.Txt_Medicine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Medicine.Location = New System.Drawing.Point(16, 19)
        Me.Txt_Medicine.MaxLength = 100
        Me.Txt_Medicine.Name = "Txt_Medicine"
        Me.Txt_Medicine.Size = New System.Drawing.Size(206, 21)
        Me.Txt_Medicine.TabIndex = 2
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.Color.Transparent
        Me.Label5.Location = New System.Drawing.Point(12, 1)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(57, 13)
        Me.Label5.TabIndex = 1140
        Me.Label5.Text = "Medicine"
        '
        'Dgv_Prescription
        '
        Me.Dgv_Prescription.AllowUserToAddRows = False
        Me.Dgv_Prescription.AllowUserToDeleteRows = False
        Me.Dgv_Prescription.AllowUserToResizeColumns = False
        Me.Dgv_Prescription.AllowUserToResizeRows = False
        Me.Dgv_Prescription.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(118, Byte), Integer), CType(CType(155, Byte), Integer), CType(CType(197, Byte), Integer))
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(87, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(162, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.AliceBlue
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgv_Prescription.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.Dgv_Prescription.ColumnHeadersHeight = 20
        Me.Dgv_Prescription.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.Dgv_Prescription.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Medicine, Me.Dose, Me.Freequency, Me.Route, Me.Qty, Me.Refils, Me.Days, Me.Pres_Continue, Me.Dis_Dt, Me.Status, Me.TempID, Me.TR_DT})
        Me.Dgv_Prescription.Location = New System.Drawing.Point(15, 95)
        Me.Dgv_Prescription.Name = "Dgv_Prescription"
        Me.Dgv_Prescription.ReadOnly = True
        Me.Dgv_Prescription.RowHeadersVisible = False
        Me.Dgv_Prescription.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.Dgv_Prescription.Size = New System.Drawing.Size(540, 259)
        Me.Dgv_Prescription.TabIndex = 1139
        Me.Dgv_Prescription.TabStop = False
        '
        'Medicine
        '
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(194, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Medicine.DefaultCellStyle = DataGridViewCellStyle2
        Me.Medicine.HeaderText = "Medicine"
        Me.Medicine.Name = "Medicine"
        Me.Medicine.ReadOnly = True
        Me.Medicine.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Medicine.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Medicine.Width = 200
        '
        'Dose
        '
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(248, Byte), Integer))
        Me.Dose.DefaultCellStyle = DataGridViewCellStyle3
        Me.Dose.HeaderText = "Dose"
        Me.Dose.Name = "Dose"
        Me.Dose.ReadOnly = True
        Me.Dose.Width = 125
        '
        'Freequency
        '
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(213, Byte), Integer))
        Me.Freequency.DefaultCellStyle = DataGridViewCellStyle4
        Me.Freequency.HeaderText = "Freequency"
        Me.Freequency.Name = "Freequency"
        Me.Freequency.ReadOnly = True
        Me.Freequency.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Freequency.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Freequency.Width = 125
        '
        'Route
        '
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(CType(CType(194, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Route.DefaultCellStyle = DataGridViewCellStyle5
        Me.Route.HeaderText = "Route"
        Me.Route.Name = "Route"
        Me.Route.ReadOnly = True
        Me.Route.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Route.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Route.Width = 125
        '
        'Qty
        '
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(213, Byte), Integer))
        Me.Qty.DefaultCellStyle = DataGridViewCellStyle6
        Me.Qty.HeaderText = "Quantity"
        Me.Qty.Name = "Qty"
        Me.Qty.ReadOnly = True
        Me.Qty.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Qty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Qty.Width = 50
        '
        'Refils
        '
        Me.Refils.HeaderText = "Refils"
        Me.Refils.Name = "Refils"
        Me.Refils.ReadOnly = True
        Me.Refils.Visible = False
        Me.Refils.Width = 50
        '
        'Days
        '
        Me.Days.HeaderText = "Days"
        Me.Days.Name = "Days"
        Me.Days.ReadOnly = True
        Me.Days.Width = 50
        '
        'Pres_Continue
        '
        Me.Pres_Continue.HeaderText = "Continue"
        Me.Pres_Continue.Name = "Pres_Continue"
        Me.Pres_Continue.ReadOnly = True
        Me.Pres_Continue.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Pres_Continue.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Pres_Continue.Width = 50
        '
        'Dis_Dt
        '
        Me.Dis_Dt.HeaderText = "Discontinue Dt"
        Me.Dis_Dt.Name = "Dis_Dt"
        Me.Dis_Dt.ReadOnly = True
        Me.Dis_Dt.Visible = False
        '
        'Status
        '
        Me.Status.HeaderText = "Status"
        Me.Status.Name = "Status"
        Me.Status.ReadOnly = True
        Me.Status.Visible = False
        '
        'TempID
        '
        Me.TempID.HeaderText = "TempID"
        Me.TempID.Name = "TempID"
        Me.TempID.ReadOnly = True
        Me.TempID.Visible = False
        '
        'TR_DT
        '
        Me.TR_DT.HeaderText = "TR_DT"
        Me.TR_DT.Name = "TR_DT"
        Me.TR_DT.ReadOnly = True
        Me.TR_DT.Visible = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.Btn_Close)
        Me.Panel3.Controls.Add(Me.Btn_Clear)
        Me.Panel3.Controls.Add(Me.Btn_Cancel)
        Me.Panel3.Controls.Add(Me.Btn_Save)
        Me.Panel3.Location = New System.Drawing.Point(464, 442)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(249, 36)
        Me.Panel3.TabIndex = 100012
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Btn_Close.Location = New System.Drawing.Point(184, 3)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(60, 28)
        Me.Btn_Close.TabIndex = 14
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Btn_Clear.Location = New System.Drawing.Point(63, 3)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(60, 28)
        Me.Btn_Clear.TabIndex = 12
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Cancel
        '
        Me.Btn_Cancel.BackgroundImage = CType(resources.GetObject("Btn_Cancel.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Cancel.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Btn_Cancel.Location = New System.Drawing.Point(124, 3)
        Me.Btn_Cancel.Name = "Btn_Cancel"
        Me.Btn_Cancel.Size = New System.Drawing.Size(60, 28)
        Me.Btn_Cancel.TabIndex = 13
        Me.Btn_Cancel.Text = "&Delete"
        Me.Btn_Cancel.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = CType(resources.GetObject("Btn_Save.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Save.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Btn_Save.Location = New System.Drawing.Point(3, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(60, 28)
        Me.Btn_Save.TabIndex = 11
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Left
        Me.PictureBox1.Location = New System.Drawing.Point(0, 24)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(155, 459)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox1.TabIndex = 100013
        Me.PictureBox1.TabStop = False
        '
        'Prescription_Template_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(721, 483)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Prescription_Template_Frm"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Pnl_Tran_mode.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.Dgv_Prescription, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Btn_Find As System.Windows.Forms.Button
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Dtp_Tran_Date As System.Windows.Forms.DateTimePicker
    Friend WithEvents Cmb_Pres_Templates As System.Windows.Forms.ComboBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Btn_Remove As System.Windows.Forms.Button
    Friend WithEvents Btn_Add As System.Windows.Forms.Button
    Friend WithEvents Cmb_Route As System.Windows.Forms.ComboBox
    Friend WithEvents cmb_Frequency As System.Windows.Forms.ComboBox
    Friend WithEvents Txt_Days As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Txt_Refils As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Txt_Qty As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Txt_Dose As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Txt_Medicine As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Dgv_Prescription As REAL_CLINIC.Hms_DGridview
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Cancel As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Medicine As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Dose As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Freequency As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Route As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Qty As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Refils As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Days As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Pres_Continue As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents Dis_Dt As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Status As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TempID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TR_DT As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
End Class
