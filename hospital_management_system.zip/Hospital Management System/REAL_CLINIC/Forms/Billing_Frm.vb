﻿'Developed by   : PRAMODBHASKER
'Date           : 30-06-2010
'Purpose        : Managing Report Options

Option Explicit On
Imports System.IO
Imports HMS_BL
Imports HMS_Common.Common_Cls
Public Class Billing_Frm

    Private mTr_Mode As Tran_Mode
    Private hms_helper As HMS_Helper = Nothing
    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_OutPatientID.BackColor = Color.White
                    Me.Txt_OutPatientID.ReadOnly = False
                    Me.Txt_PatientID.ReadOnly = False
                    Me.Txt_PatientID.BackColor = Color.White
                   

                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_OutPatientID.BackColor = Color.Silver
                    Me.Txt_OutPatientID.ReadOnly = True
                    Me.Txt_PatientID.ReadOnly = True
                    Me.Txt_PatientID.BackColor = Color.Silver
                   


            End Select
        End Set
    End Property



    Dim tvRoot As TreeNode
    Dim tvNode As TreeNode
    Dim tvNode1 As TreeNode


    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing

    Private Sub Billing_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then Call SendKeyTab()
    End Sub


    Private Sub Reports_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub Reports_Frm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call Fill_ExpenseGroup()
        Call Fill_ExpenseMaster()
        Me.Tvw_ExpenseList.ExpandAll()
        Txt_PatientID.Focus()



    End Sub



#Region "Methods"


    Private Sub Clear_Form()
    End Sub

    Private Sub Fill_ExpenseGroup()
        Try
            Dtbl = Nothing
            Dr = Nothing
            hms_helper = New Hms_Helperimpliments

            If hms_helper.Get_ExpenseGrouplist(Dtbl) Then
                tvRoot = Me.Tvw_ExpenseList.Nodes.Add("Expense Heads")

                Dr = Dtbl.CreateDataReader
                With Dr
                    While Dr.Read
                        tvNode = tvRoot.Nodes.Add(Dr.Item("Exp_GrpID"), Dr.Item("Exp_Groupname"))
                        tvNode.ForeColor = Color.Maroon
                        tvNode.Name = Dr.Item("Exp_GrpID").ToString
                    End While
                End With

            End If


        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Fill_ExpenseMaster()
        Try
            Dtbl = Nothing
            Dr = Nothing

            hms_helper = New Hms_Helperimpliments

            With Tvw_ExpenseList


                For i = 0 To .Nodes(0).Nodes.Count - 1
                    Dtbl = Nothing
                    Dr = Nothing

                    If hms_helper.Get_ExpenseMasterdatalist(Dtbl, .Nodes(0).Nodes(i).Name) Then
                        Dr = Dtbl.CreateDataReader

                        While Dr.Read

                            Lst_Search.Items.Add(Dr.Item("Exp_Name"))
                            tvRoot = .Nodes(0).Nodes(i)
                            tvNode = tvRoot.Nodes.Add(Dr.Item("Exp_ID"), Dr.Item("Exp_Name"))
                            tvNode.ForeColor = Color.DarkBlue
                            tvNode.Name = Dr.Item("Exp_Name").ToString
                            tvNode.Tag = Dr.Item("Exp_ID").ToString
                            .Nodes(0).Nodes(i).Expand()

                        End While

                    End If
                Next
            End With

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


#End Region

   

    Private Sub Txt_ExpenseMaster_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_ExpenseMaster.KeyDown
        If e.KeyCode = Keys.Enter Then
            Txt_ExpenseMaster.Text = Lst_Search.SelectedItem
            Lst_Search.Visible = False
            'look for a node with a text property value of 'Node3'
            Tvw_ExpenseList.SelectedNode = GetNode(Txt_ExpenseMaster.Text, Tvw_ExpenseList.Nodes)
            'Tvw_ExpenseList the focus set on the node
            Tvw_ExpenseList.Select()


        End If
    End Sub

   

    Private Sub Txt_ExpenseMaster_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_ExpenseMaster.TextChanged
        Try
            If Txt_ExpenseMaster.Text.Trim <> "" Then

                'Retrieve the item's listindex
                Lst_Search.Visible = True
                Dim i As Integer = Lst_Search.FindString(Txt_ExpenseMaster.Text)

                'highligting the matched ones
                Lst_Search.SelectedIndex = i
            End If
        Catch ex As Exception

        End Try

    End Sub

    Private Function GetNode(ByVal text As String, ByVal parentCollection As TreeNodeCollection) As TreeNode
        Try

        
            Dim ret As TreeNode = Nothing
            Dim child As TreeNode

            For Each child In parentCollection 'step through the parentcollection
                If child.Text = text Then
                    ret = child
                ElseIf child.GetNodeCount(False) > 0 Then ' if there is child items then call this function recursively
                    ret = GetNode(text, child.Nodes)
                End If

                If Not ret Is Nothing Then Exit For 'if something was found, exit out of the for loop

            Next

            Return ret
        Catch ex As Exception
            Return Nothing
        End Try

    End Function

    Private Sub Tvw_ExpenseList_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles Tvw_ExpenseList.AfterSelect
        Try
            Trancontrol1.Clear_Values()
            Call Fill_Trancontrol()
        Catch ex As Exception

        End Try

    End Sub


    Private Function Fill_Trancontrol() As Boolean
        Try

            Dim dtbl As DataTable = Nothing
            Dim Gridsorce_Dtbl As New DataTable
            Dim Assignvalue_Dtbl As New DataTable

            Dim Drow, Amt_Drow As DataRow
            Dim Paymentmodesource_Dtbl As DataTable = Nothing

            With Gridsorce_Dtbl
                .Columns.Add("Particulars")
                .Columns.Add("Acc_Code")
                .Columns.Add("Particulars_ID")
                .Columns.Add("Def_Trantype")
                .Columns.Add("Editable")

            End With

            With Assignvalue_Dtbl
                .Columns.Add("Particulars_ID")
                .Columns.Add("Amount")
            End With


            If Not hms_helper.Get_ExpenseCharges(dtbl, Tvw_ExpenseList.SelectedNode.Tag, Tran_Date) Then Return False

            For i = 0 To dtbl.Rows.Count - 1
                Drow = Gridsorce_Dtbl.NewRow()
                Drow("Particulars") = dtbl.Rows(i).Item("Particulars").ToString
                ' MessageBox.Show(dtbl.Rows(i).Item("Particulars").ToString)

                Drow("Acc_Code") = dtbl.Rows(i).Item("Exp_Acc_Code").ToString
                'MessageBox.Show(dtbl.Rows(i).Item("Exp_Acc_Code").ToString)

                Drow("Particulars_ID") = dtbl.Rows(i).Item("Exp_Subtype").ToString
                'MessageBox.Show(dtbl.Rows(i).Item("Exp_Subtype").ToString)

                Drow("Def_Trantype") = "C"
                Drow("Editable") = "Y"
                Gridsorce_Dtbl.Rows.Add(Drow)

                Amt_Drow = Assignvalue_Dtbl.NewRow
                Amt_Drow("Particulars_ID") = dtbl.Rows(i).Item("Exp_Subtype").ToString
                Amt_Drow("Amount") = dtbl.Rows(i).Item("Exp_Amount").ToString
                Assignvalue_Dtbl.Rows.Add(Amt_Drow)
            Next

            If hms_helper.Get_Gendata(Paymentmodesource_Dtbl, Gendatatype.Payment_Mode) Then
                Trancontrol1.Clear_Values()
                If Trancontrol1.Set_Tranenvironment(Gridsorce_Dtbl, Paymentmodesource_Dtbl) Then
                    Trancontrol1.Assign_Values(Assignvalue_Dtbl, 48)
                    Trancontrol1.Amount_Editable = True
                End If
            End If




        Catch ex As Exception

        End Try
    End Function

    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try

        
            If Tr_Mode = Tran_Mode.New_Mode Then
                If Txt_OutPatientID.Text.Trim = "" Then
                    Dim Sql As String
                    Dim Colwidth As String = ""
                    Colwidth = "10|50|50|50|50|200"
                    Sql = "SELECT   *  FROM    OPD_Master_Vw"
                    Call ShowSearchengine(Txt_OutPatientID, Sql, 0, "Patient Name", Colwidth, , 0)
                End If

                If Txt_OutPatientID.Text.Trim = "" Then
                    Txt_OutPatientID.Focus() : Exit Sub
                End If

                hms_helper = New Hms_Helperimpliments
                If hms_helper.Get_OP_Details(Dtbl, Txt_OutPatientID.Text.Trim) Then
                    Txt_PatientID.Text = Dtbl.Rows(0).Item("Patient ID").ToString
                    Patient_Info2.Patient_ID = Txt_PatientID.Text.Trim

                    Imageviewer1.CUST_ID = Txt_PatientID.Text.Trim
                    Imageviewer1.CUST_TYPE = Customer_Type.Patient
                End If

            Else
                Txt_ExpenseMaster.Focus()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Add_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Add.Click
        Try


            With Dgv_ChargesGrid

                For i = 0 To Trancontrol1.Tran_Grid.RowCount - 1
                    .Rows.Add()
                    .Rows(.Rows.Count - 1).Cells("Expense").Value = Txt_ExpenseMaster.Text.Trim
                    .Rows(.Rows.Count - 1).Cells("Particulars").Value = Trancontrol1.Tran_Grid.Rows(i).Cells("Particulars").Value.ToString
                    .Rows(.Rows.Count - 1).Cells("Amount").Value = Trancontrol1.Tran_Grid.Rows(i).Cells("Amount").Value.ToString
                    Dgv_ChargesGrid.Rows(.Rows.Count - 1).Cells("Amount").Style.Alignment = DataGridViewContentAlignment.MiddleRight

                Next
            End With
            Dgv_ChargesGrid.Columns("Expense").SortMode = DataGridViewColumnSortMode.NotSortable
            Dgv_ChargesGrid.Columns("Particulars").SortMode = DataGridViewColumnSortMode.NotSortable
            Dgv_ChargesGrid.Columns("Amount").SortMode = DataGridViewColumnSortMode.NotSortable
            Dgv_ChargesGrid.Columns("Amount").HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight
            'clear Tran grid values
            Trancontrol1.Clear_Values()
        Catch ex As Exception

        End Try
    End Sub
End Class