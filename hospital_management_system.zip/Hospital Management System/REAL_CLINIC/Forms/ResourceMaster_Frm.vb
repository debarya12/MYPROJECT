﻿
Imports HMS_BL
Imports HMS_Common.Common_Cls
Public Class ResourceMaster_Frm

#Region "Declarations"
    'Variable declaration/ object for Business Layer objects

    Private mTr_Mode As Tran_Mode
    Private Resource_BL As ResourceMaster_BL_Cls
    Private Com_BL As HMS_Common_BL_Cls
    Private hms_helper As HMS_Helper = Nothing

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Tran_Mode_Lbl1.Text = "NEW MODE"
                    Me.Txt_ResID.BackColor = Color.White
                Case Tran_Mode.Edit_Mode
                    Me.Tran_Mode_Lbl1.Text = "EDIT MODE"
                    Me.Txt_ResID.BackColor = Color.Silver

            End Select
        End Set
    End Property


#End Region

#Region "Form Load"

    Private Sub ResourceMaster_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub ResourceMaster_Frm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Call Fill_ResourceDetails()
        Catch ex As Exception

        End Try
    End Sub

#End Region

#Region "Key events"

    Private Sub Txt_ResID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_ResID.KeyDown
        If e.KeyCode = Keys.F2 Then Btn_Find_Click(sender, e)
    End Sub
    Private Sub Txt_ResID_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_ResID.KeyPress
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_ResID.Text, Data_Type.Integer_Type, 12))
    End Sub
    Private Sub ResourceMaster_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then Call SendKeyTab()
    End Sub
#End Region

#Region "Functions"

    Public Sub clearForm()
        Try
            Txt_ResID.Text = ""
            Txt_ResName.Text = ""
            Txt_ResPath.Text = ""
            Txt_ResID.Tag = ""

            Call Fill_ResourceDetails()

            Tr_Mode = Tran_Mode.New_Mode
            Btn_Save.Enabled = True
            Btn_Delete.Enabled = False
        Catch ex As Exception

        End Try
    End Sub

    'function for validate fields 
    'return boolean
    Private Function Validate_Fields() As Boolean
        Try


            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If

            If Tr_Mode <> Tran_Mode.New_Mode Then
                If Txt_ResID.Text.Trim = "" Then MessageBox.Show("Invalid Resource ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_ResID.Focus() : Exit Function
            End If


            'Assigning Default values

            If Txt_ResName.Text.Trim = "" Then MessageBox.Show("Invalid Resource Name - Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_ResName.Focus() : Exit Function
            If Txt_ResPath.Text.Trim = "" Then MessageBox.Show("Invalid Resource Path - Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_ResPath.Focus() : Exit Function


            Return True
         
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try

    End Function

    'Saving Resource details
    Private Sub Btn_Save_Click(ByVal sendr As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try

            'Validating Data controls
            If Not Validate_Fields() Then Exit Sub
            ' declaration of variables for data reading 
            Dim dr As DataTableReader = Nothing
            Dim dtbl As DataTable = Nothing

            'Initialising  object for BL
            Resource_BL = New ResourceMaster_BL_Cls

            'assigning values to propeties for saving
            Resource_BL.Res_ID = IIf(Tr_Mode <> Tran_Mode.New_Mode, Txt_ResID.Text, 0)
            Resource_BL.Res_Name = Txt_ResName.Text
            Resource_BL.Res_Path = Txt_ResPath.Text

            'Save function from BL
            If Resource_BL.Save_ResourceMaster(dtbl, Tr_Mode, Val(Txt_ResID.Text)) Then
                MessageBox.Show("Resource Details  Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                dr = dtbl.CreateDataReader()
                dr.Read()
                Txt_ResID.Text = dr.GetValue(0).ToString
                Call Btn_Find_Click(sendr, e)
                Btn_Clear.Focus()
            Else
                MessageBox.Show("Resource Details Not Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)

        End Try

    End Sub

    'Locating Resource details
    'return Boolean
    Public Function Locate_Values_Resource(ByVal Res_ID As Integer) As Boolean
        Try


            'dim variable declaration for data retrive
            Dim dr As DataTableReader = Nothing
            Dim dtbl As DataTable = Nothing

            'initialising BL Object
            Resource_BL = New ResourceMaster_BL_Cls

            If Resource_BL.Get_ResourceMaster(dtbl, Res_ID) Then
                dr = dtbl.CreateDataReader
                dr.Read()
                    With dr
                    Txt_ResID.Text = .GetValue(0).ToString
                    Txt_ResID.Tag = .GetValue(0).ToString
                    Txt_ResName.Text = .GetValue(1).ToString
                    Txt_ResPath.Text = .GetValue(2).ToString
                End With
                Return True
            Else
                'MessageBox.Show("Invalid Resource Id, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_ResID.Focus()
                Return False
            End If

        Catch ex As Exception
            Return False
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Function

    'resource find
    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try

            ' search engine
            If Txt_ResID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "50|200|5|5|"
                Sql = "Select * From Get_ResourceMasterDetails_Vw"
                Call ShowSearchengine(Txt_ResID, Sql, 0, "Res_Name", Colwidth, , 0)
            End If


            'Validating Mandatory fields for locating
            If Txt_ResID.Text.Trim = "" Then
                Txt_ResID.Focus() : Exit Sub
            End If

            If Locate_Values_Resource(Txt_ResID.Text) Then
                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Delete.Enabled = True
            Else
                MessageBox.Show("Resource ID does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    'delete resournce
    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click
        Try
            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If

            If MessageBox.Show("Are You Sure Delete this Resource  ", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.No Then Exit Sub
            Resource_BL = New ResourceMaster_BL_Cls
            If Resource_BL.Delete_ResourceMaster(Txt_ResID.Text) Then
                MessageBox.Show("Resource master Deleted Successfully", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Call clearForm()
            Else
                MessageBox.Show("You cannot delete this Resource" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Btn_Clear.Focus()
            End If
        Catch ex As Exception

        End Try
       
    End Sub
    ''function for fill Resource master details into grid
    'return boolean
    Public Function Fill_ResourceDetails() As Boolean
        Try

            'declaring variable for data reading
            Dim dtbl As DataTable = Nothing
            Dim dr As DataTableReader = Nothing

            'initialising BL Object
            Resource_BL = New ResourceMaster_BL_Cls

            If Resource_BL.Get_ResourceMasterAll(dtbl) Then
                Dgrd_History.DataSource = Nothing
                Dgrd_History.DataSource = dtbl
                'Com_BL = New DCMGTS.BL.DCMGTS_Common_BL
                Com_BL = New HMS_BL.HMS_Common_BL_Cls
                Com_Bl.SetGrid_Colwidth("10|100|250|", Dgrd_History)
                Dgrd_History.Refresh()
                Return True
            Else
                Return False
            End If

            dr = Nothing
            dtbl = Nothing
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False

        End Try
    End Function
    Private Sub Txt_ResName_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_ResName.Validating
        Try
            Com_BL = New HMS_BL.HMS_Common_BL_Cls
            If Tr_Mode = Tran_Mode.New_Mode Then
                If Com_BL.Check_Duplicatedataexists("Resource_Master_Tbl", "Res_Name", Data_Type.General_Type, Txt_ResName.Text.Trim, Branch_Code) Then
                    MessageBox.Show("Resource Name Already Exist,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_ResName.Focus()
                    Txt_ResName.Text = ""
                    e.Cancel = True
                End If
            Else

                If Com_BL.Check_Duplicatedataexists("Resource_Master_Tbl", "Res_Name", Data_Type.General_Type, Txt_ResName.Text.Trim, Branch_Code, , "Res_ID", Data_Type.Integer_Type, Txt_ResID.Text.Trim) Then
                    MessageBox.Show("Resource Name Already Exist,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_ResName.Focus()
                    Txt_ResName.Text = ""
                    e.Cancel = True
                End If
            End If
        Catch ex As Exception

        End Try

    End Sub
#End Region

#Region "Button Events"
    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Call clearForm()
        Txt_ResID.Focus()
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

    Private Sub Dgrd_History_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Dgrd_History.DoubleClick
        With Dgrd_History
            If .CurrentRow Is Nothing Then Exit Sub
            Txt_ResID.Text = .Item(0, .CurrentCell.RowIndex).Value.ToString.Trim
            Call Btn_Find_Click(sender, e)
        End With
    End Sub
    Private Sub Btn_Search_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Search.Click
        FolderBrowserDialog1.ShowDialog()
        Txt_ResPath.Text = (FolderBrowserDialog1.SelectedPath)
        Btn_Save.Focus()
    End Sub
#End Region

    Private Sub Txt_ResID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_ResID.TextChanged

    End Sub

    Private Sub Txt_ResID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_ResID.Validating
        Try
            If Txt_ResID.Text.Trim <> "" And Txt_ResID.Text.Trim <> Txt_ResID.Tag Then
                    If Locate_Values_Resource(Txt_ResID.Text.Trim) Then
                    Tr_Mode = Tran_Mode.Edit_Mode
                    Btn_Delete.Enabled = True
                    SendKeyTab()
                Else
                    MessageBox.Show("Invalid Resource Id, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Tr_Mode = Tran_Mode.New_Mode
                    e.Cancel = True
                End If

            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_ResName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_ResName.TextChanged

    End Sub
End Class