﻿

Option Explicit On

Public Class Trancontrol


#Region " D e c l a r a t i o n s "

    Private Adjwidht As Int64 = 0
    Private IsHandleAdded As Boolean
    Private _Amount_Editable As Boolean = True

#End Region

#Region " P r o p e r t i e s "

    Public ReadOnly Property Total_Amount() As Double
        Get
            Return Val(Lbl_TotalAmount.Text)
        End Get
    End Property

    Public WriteOnly Property Amount_Editable() As Boolean
        Set(ByVal value As Boolean)
            _Amount_Editable = value
            Btn_Clear.Enabled = value
        End Set
    End Property

#End Region

#Region " M e t h o d s "

    Private Sub Trancontrol_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        Try

            Adjwidht = Me.Tran_Grid.Width - (Me.Slno.Width + Me.Amount.Width)

            If Adjwidht > 0 Then
                Me.Particulars.Width = Adjwidht
            End If
            Me.Amount.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight

        Catch ex As Exception

        End Try

    End Sub

    Public Function Set_Tranenvironment(ByVal Gridsource_Dtbl As DataTable, _
                                        ByVal Paymentmodesource_Dtbl As DataTable) As Boolean
        Try

            With Tran_Grid
                .RowCount = 0
                For i = 0 To Gridsource_Dtbl.Rows.Count - 1
                    .Rows.Add()
                    .Rows(i).Cells("Slno").Value = i + 1
                    .Rows(i).Cells("Particulars").Value = Gridsource_Dtbl.Rows(i).Item("Particulars").ToString
                    .Rows(i).Cells("Acc_Code").Value = Gridsource_Dtbl.Rows(i).Item("Acc_Code").ToString
                    .Rows(i).Cells("Exp_Subtype").Value = Gridsource_Dtbl.Rows(i).Item("Exp_Subtype").ToString
                    .Rows(i).Cells("Def_Trantype").Value = Gridsource_Dtbl.Rows(i).Item("Def_Trantype").ToString
                    .Rows(i).Cells("Editable").Value = Gridsource_Dtbl.Rows(i).Item("Editable").ToString
                    .Rows(i).Cells("Charge_Calctype").Value = Gridsource_Dtbl.Rows(i).Item("Charge_Calctype").ToString
                    .Rows(i).Cells("Percentage_Of").Value = Gridsource_Dtbl.Rows(i).Item("Percentage_Of").ToString
                    .Rows(i).Cells("Percentage").Value = Gridsource_Dtbl.Rows(i).Item("Percentage").ToString

                Next
                Me.Amount.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight
            End With


            If Not Paymentmodesource_Dtbl Is Nothing Then
                With Cmb_Paymode
                    .DataSource = Nothing
                    .DataSource = Paymentmodesource_Dtbl
                    .DisplayMember = Paymentmodesource_Dtbl.Columns(2).ColumnName
                    .ValueMember = Paymentmodesource_Dtbl.Columns(0).ColumnName
                End With
            End If

            Return True
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            Return False
        End Try
    End Function

    Public Function Assign_Values(ByVal Gridsource_Dtbl As DataTable, _
                                  ByVal Paymentmode As Integer) As Boolean
        Try
            Dim CellAmt As Double = 0

            With Tran_Grid
                For i = 0 To Gridsource_Dtbl.Rows.Count - 1
                    For k = 0 To .Rows.Count - 1
                        If .Rows(k).Cells("Exp_Subtype").Value.ToString = Gridsource_Dtbl.Rows(i).Item("Exp_Subtype").ToString Then
                            CellAmt = Gridsource_Dtbl.Rows(i).Item("Amount").ToString
                            .Rows(k).Cells("Amount").Value = CellAmt
                        End If
                    Next
                Next
            End With
            If Cmb_Paymode.Visible Then
                Cmb_Paymode.SelectedValue = Paymentmode
            End If


            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Sub Clear_Values()
        Try
            With Tran_Grid
                For k = 0 To .Rows.Count - 1
                    .Rows(k).Cells("Amount").Value = ""
                Next
                .CurrentCell = .Rows(0).Cells("Amount")
            End With
        Catch ex As Exception

        End Try
    End Sub

    Public Sub Clear_AllValues()
        Try
            With Tran_Grid
                .RowCount = 0
            End With
            Lbl_TotalAmount.Text = ""
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Calc_PercentageAmount()
        Try
            With Tran_Grid
                For i = 0 To .Rows.Count - 1
                    If (Not .Rows(i).Cells("Charge_Calctype").Value Is Nothing) Then
                        If .Rows(i).Cells("Charge_Calctype").Value.ToString = "P" Then
                            If (Not .Rows(i).Cells("Percentage_Of").Value Is Nothing) Then
                                If (Not .Rows(i).Cells("Percentage").Value Is Nothing) Then
                                    'Finding The Respective Grid Row
                                    Dim SelRow As DataGridViewRow = Nothing
                                    Dim Servalue, Calc_Value, Percentage As Double

                                    Dim SearchID As String = .Rows(i).Cells("Percentage_Of").Value.ToString
                                    SelRow = (From Rows In .Rows.Cast(Of DataGridViewRow)() _
                                              Where Rows.Cells("Exp_Subtype").Value.ToString() = SearchID).FirstOrDefault
                                    If Not IsNothing(SelRow) Then
                                        If (Not SelRow.Cells("Amount").Value Is Nothing) Then
                                            Servalue = Val(SelRow.Cells("Amount").Value.ToString)
                                            Percentage = .Rows(i).Cells("Percentage").Value.ToString
                                            Calc_Value = Servalue * Percentage / 100
                                            .Rows(i).Cells("Amount").Value = Calc_Value
                                        End If
                                    End If
                                End If
                            End If
                        End If
                    End If
                Next
            End With

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Totaling_Amount()
        Try
            Lbl_TotalAmount.Text = ""
            Dim Totalamt As Double = 0

            With Tran_Grid
                For i = 0 To .Rows.Count - 1
                    Totalamt += .Rows(i).Cells("Amount").Value
                Next
            End With
            Lbl_TotalAmount.Text = Totalamt.ToString("0.00")
        Catch ex As Exception

        End Try

    End Sub



#End Region



    Private Sub Tran_Grid_CellBeginEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellCancelEventArgs) Handles Tran_Grid.CellBeginEdit
        Try
            If (Tran_Grid.Rows(e.RowIndex).Cells("Editable").Value = "N") Or (_Amount_Editable = False) Then
                Tran_Grid.EndEdit(True)
                e.Cancel = True
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Tran_Grid_CellEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Tran_Grid.CellEnter
        Try
            If Not Tran_Grid.Columns(e.ColumnIndex).ReadOnly Then
                Tran_Grid.BeginEdit(True)
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Tran_Grid_CellValueChanged(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Tran_Grid.CellValueChanged
        Try
            If e.ColumnIndex = Tran_Grid.Columns("Amount").Index Then
                Call Calc_PercentageAmount()
                Call Totaling_Amount()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Tran_Grid_EditingControlShowing(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewEditingControlShowingEventArgs) Handles Tran_Grid.EditingControlShowing
        Try
            If Tran_Grid.Columns(Tran_Grid.CurrentCell.ColumnIndex).Name = "Amount" Then

                If (Not IsHandleAdded) Then
                    Dim tx As TextBox = CType(e.Control, TextBox)

                    If (Not (tx) Is Nothing) Then
                        AddHandler tx.KeyPress, AddressOf Me.tx_KeyPress
                        Me.IsHandleAdded = True
                        RemoveHandler Me.Tran_Grid.EditingControlShowing, AddressOf Me.Tran_Grid_EditingControlShowing
                    End If

                End If

            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub tx_KeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs)
        Try

            Dim Txt As TextBox = CType(sender, TextBox)
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt.Text, Data_Type.Double_Type, 13))

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Tran_Grid_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles Tran_Grid.Enter
        Try
            With Tran_Grid
                .CurrentCell = .Rows(0).Cells("Amount")
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Tran_Grid_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Tran_Grid.Validated
        Try
            With Tran_Grid
                .ClearSelection()
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try

            Call Clear_Values()

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Cmb_Paymode_VisibleChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cmb_Paymode.VisibleChanged
        Try
            Lbl_Pay.Visible = Cmb_Paymode.Visible
        Catch ex As Exception

        End Try
    End Sub


End Class
