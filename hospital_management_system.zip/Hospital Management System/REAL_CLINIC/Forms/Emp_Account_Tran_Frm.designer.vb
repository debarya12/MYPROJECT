﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Emp_Account_Tran_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Emp_Account_Tran_Frm))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Ledger = New System.Windows.Forms.Button
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Cancel = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.Btn_Find = New System.Windows.Forms.Button
        Me.Txt_AccountNo = New System.Windows.Forms.TextBox
        Me.Lbl_AccNo = New System.Windows.Forms.Label
        Me.Txt_EmpID = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Cmb_Tran_Type = New System.Windows.Forms.ComboBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Dgvw_Emp_AccountTran = New System.Windows.Forms.DataGridView
        Me.Cmb_Payment_Mode = New System.Windows.Forms.ComboBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Txt_Amount = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Txt_Narration = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Txt_TransactionBal = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.Txt_LedgerBal = New System.Windows.Forms.TextBox
        Me.Lbl_Words = New System.Windows.Forms.Label
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.Imageviewer1 = New REAL_CLINIC.Imageviewer
        Me.Employee_Info1 = New REAL_CLINIC.Employee_Info
        Me.Pnl_Header.SuspendLayout()
        Me.Pnl_Tran_mode.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        CType(Me.Dgvw_Emp_AccountTran, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Menu_Bkg
        Me.Pnl_Header.Controls.Add(Me.Label1)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(791, 24)
        Me.Pnl_Header.TabIndex = 100
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(0, 4)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(349, 18)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "E m p l o y e e   A c c o u n t   T r a n s a c t i o n "
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(620, 32)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(74, 22)
        Me.Pnl_Tran_mode.TabIndex = 48
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(-7, 4)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(68, 16)
        Me.Lbl_Tran_Mode.TabIndex = 0
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Ledger)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Cancel)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(310, 329)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(288, 35)
        Me.Pnl_Common_Btn.TabIndex = 8
        '
        'Btn_Ledger
        '
        Me.Btn_Ledger.BackgroundImage = CType(resources.GetObject("Btn_Ledger.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Ledger.CausesValidation = False
        Me.Btn_Ledger.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Ledger.Location = New System.Drawing.Point(170, 2)
        Me.Btn_Ledger.Name = "Btn_Ledger"
        Me.Btn_Ledger.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Ledger.TabIndex = 5
        Me.Btn_Ledger.Text = "&Ledger"
        Me.Btn_Ledger.UseVisualStyleBackColor = True
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(114, 2)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear.TabIndex = 3
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(226, 2)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 4
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Cancel
        '
        Me.Btn_Cancel.BackgroundImage = CType(resources.GetObject("Btn_Cancel.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Cancel.Location = New System.Drawing.Point(58, 2)
        Me.Btn_Cancel.Name = "Btn_Cancel"
        Me.Btn_Cancel.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Cancel.TabIndex = 2
        Me.Btn_Cancel.Text = "Cancel"
        Me.Btn_Cancel.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(2, 2)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save.TabIndex = 1
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Btn_Find
        '
        Me.Btn_Find.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find.BackgroundImage = CType(resources.GetObject("Btn_Find.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find.ForeColor = System.Drawing.Color.White
        Me.Btn_Find.Location = New System.Drawing.Point(382, 32)
        Me.Btn_Find.Name = "Btn_Find"
        Me.Btn_Find.Size = New System.Drawing.Size(29, 21)
        Me.Btn_Find.TabIndex = 1
        Me.Btn_Find.TabStop = False
        Me.Btn_Find.Text = "F2"
        Me.Btn_Find.UseVisualStyleBackColor = False
        '
        'Txt_AccountNo
        '
        Me.Txt_AccountNo.BackColor = System.Drawing.Color.White
        Me.Txt_AccountNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_AccountNo.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_AccountNo.Location = New System.Drawing.Point(216, 32)
        Me.Txt_AccountNo.Name = "Txt_AccountNo"
        Me.Txt_AccountNo.Size = New System.Drawing.Size(165, 21)
        Me.Txt_AccountNo.TabIndex = 0
        '
        'Lbl_AccNo
        '
        Me.Lbl_AccNo.AutoSize = True
        Me.Lbl_AccNo.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_AccNo.ForeColor = System.Drawing.Color.White
        Me.Lbl_AccNo.Location = New System.Drawing.Point(101, 37)
        Me.Lbl_AccNo.Name = "Lbl_AccNo"
        Me.Lbl_AccNo.Size = New System.Drawing.Size(70, 13)
        Me.Lbl_AccNo.TabIndex = 50
        Me.Lbl_AccNo.Text = "Account No"
        '
        'Txt_EmpID
        '
        Me.Txt_EmpID.BackColor = System.Drawing.Color.White
        Me.Txt_EmpID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_EmpID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_EmpID.Location = New System.Drawing.Point(216, 56)
        Me.Txt_EmpID.Name = "Txt_EmpID"
        Me.Txt_EmpID.ReadOnly = True
        Me.Txt_EmpID.Size = New System.Drawing.Size(165, 21)
        Me.Txt_EmpID.TabIndex = 2
        Me.Txt_EmpID.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(102, 58)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(47, 13)
        Me.Label5.TabIndex = 91
        Me.Label5.Text = "Emp ID"
        '
        'Cmb_Tran_Type
        '
        Me.Cmb_Tran_Type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Tran_Type.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Tran_Type.FormattingEnabled = True
        Me.Cmb_Tran_Type.Location = New System.Drawing.Point(216, 198)
        Me.Cmb_Tran_Type.Name = "Cmb_Tran_Type"
        Me.Cmb_Tran_Type.Size = New System.Drawing.Size(143, 22)
        Me.Cmb_Tran_Type.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(101, 201)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(105, 13)
        Me.Label3.TabIndex = 140
        Me.Label3.Text = "Transaction Type"
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.FromArgb(CType(CType(19, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(153, Byte), Integer))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(109, 367)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(668, 18)
        Me.Label7.TabIndex = 142
        Me.Label7.Text = "T r a n s a c t i o n   D e t a i l s"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Dgvw_Emp_AccountTran
        '
        Me.Dgvw_Emp_AccountTran.AllowUserToAddRows = False
        Me.Dgvw_Emp_AccountTran.AllowUserToDeleteRows = False
        Me.Dgvw_Emp_AccountTran.AllowUserToResizeColumns = False
        Me.Dgvw_Emp_AccountTran.AllowUserToResizeRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(248, Byte), Integer))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.DarkBlue
        Me.Dgvw_Emp_AccountTran.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.Dgvw_Emp_AccountTran.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(236, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Dgvw_Emp_AccountTran.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(75, Byte), Integer), CType(CType(116, Byte), Integer), CType(CType(165, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgvw_Emp_AccountTran.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.Dgvw_Emp_AccountTran.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Dgvw_Emp_AccountTran.Location = New System.Drawing.Point(109, 388)
        Me.Dgvw_Emp_AccountTran.Name = "Dgvw_Emp_AccountTran"
        Me.Dgvw_Emp_AccountTran.ReadOnly = True
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(179, Byte), Integer))
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgvw_Emp_AccountTran.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.Dgvw_Emp_AccountTran.RowHeadersVisible = False
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(CType(CType(219, Byte), Integer), CType(CType(227, Byte), Integer), CType(CType(249, Byte), Integer))
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.Color.DarkBlue
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.DeepSkyBlue
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black
        Me.Dgvw_Emp_AccountTran.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.Dgvw_Emp_AccountTran.Size = New System.Drawing.Size(670, 105)
        Me.Dgvw_Emp_AccountTran.TabIndex = 141
        '
        'Cmb_Payment_Mode
        '
        Me.Cmb_Payment_Mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.Cmb_Payment_Mode.CausesValidation = False
        Me.Cmb_Payment_Mode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Payment_Mode.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Payment_Mode.FormattingEnabled = True
        Me.Cmb_Payment_Mode.ItemHeight = 14
        Me.Cmb_Payment_Mode.Location = New System.Drawing.Point(216, 224)
        Me.Cmb_Payment_Mode.Name = "Cmb_Payment_Mode"
        Me.Cmb_Payment_Mode.Size = New System.Drawing.Size(143, 22)
        Me.Cmb_Payment_Mode.TabIndex = 5
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(101, 227)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(92, 13)
        Me.Label2.TabIndex = 10014
        Me.Label2.Text = "Payment Mode"
        '
        'Txt_Amount
        '
        Me.Txt_Amount.BackColor = System.Drawing.Color.White
        Me.Txt_Amount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Amount.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Amount.Location = New System.Drawing.Point(494, 224)
        Me.Txt_Amount.Name = "Txt_Amount"
        Me.Txt_Amount.Size = New System.Drawing.Size(120, 22)
        Me.Txt_Amount.TabIndex = 6
        Me.Txt_Amount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(434, 227)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(52, 13)
        Me.Label4.TabIndex = 10016
        Me.Label4.Text = "Amount"
        '
        'Txt_Narration
        '
        Me.Txt_Narration.BackColor = System.Drawing.Color.White
        Me.Txt_Narration.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Narration.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Narration.Location = New System.Drawing.Point(216, 274)
        Me.Txt_Narration.Name = "Txt_Narration"
        Me.Txt_Narration.Size = New System.Drawing.Size(398, 21)
        Me.Txt_Narration.TabIndex = 7
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(101, 276)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(60, 13)
        Me.Label6.TabIndex = 10018
        Me.Label6.Text = "Narration"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(365, 254)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(121, 13)
        Me.Label8.TabIndex = 10020
        Me.Label8.Text = "Transaction Balance"
        '
        'Txt_TransactionBal
        '
        Me.Txt_TransactionBal.BackColor = System.Drawing.Color.White
        Me.Txt_TransactionBal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_TransactionBal.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_TransactionBal.Location = New System.Drawing.Point(494, 249)
        Me.Txt_TransactionBal.Name = "Txt_TransactionBal"
        Me.Txt_TransactionBal.Size = New System.Drawing.Size(120, 22)
        Me.Txt_TransactionBal.TabIndex = 10019
        Me.Txt_TransactionBal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(393, 201)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(93, 13)
        Me.Label9.TabIndex = 10022
        Me.Label9.Text = "Ledger Balance"
        '
        'Txt_LedgerBal
        '
        Me.Txt_LedgerBal.BackColor = System.Drawing.Color.White
        Me.Txt_LedgerBal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_LedgerBal.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_LedgerBal.Location = New System.Drawing.Point(494, 199)
        Me.Txt_LedgerBal.Name = "Txt_LedgerBal"
        Me.Txt_LedgerBal.Size = New System.Drawing.Size(120, 22)
        Me.Txt_LedgerBal.TabIndex = 10021
        Me.Txt_LedgerBal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Lbl_Words
        '
        Me.Lbl_Words.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Words.ForeColor = System.Drawing.Color.Maroon
        Me.Lbl_Words.Location = New System.Drawing.Point(109, 309)
        Me.Lbl_Words.Name = "Lbl_Words"
        Me.Lbl_Words.Size = New System.Drawing.Size(668, 17)
        Me.Lbl_Words.TabIndex = 10023
        Me.Lbl_Words.Text = "Words"
        Me.Lbl_Words.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Left
        Me.PictureBox1.Location = New System.Drawing.Point(0, 24)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(99, 481)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox1.TabIndex = 10024
        Me.PictureBox1.TabStop = False
        '
        'Imageviewer1
        '
        Me.Imageviewer1.CUST_ID = ""
        Me.Imageviewer1.CUST_TYPE = HMS_Common.Common_Cls.Customer_Type.Employee
        Me.Imageviewer1.Location = New System.Drawing.Point(620, 80)
        Me.Imageviewer1.Name = "Imageviewer1"
        Me.Imageviewer1.Scan_Enabled = True
        Me.Imageviewer1.Size = New System.Drawing.Size(159, 215)
        Me.Imageviewer1.TabIndex = 138
        '
        'Employee_Info1
        '
        Me.Employee_Info1.BackColor = System.Drawing.Color.AliceBlue
        Me.Employee_Info1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Employee_Info1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Employee_Info1.ForeColor = System.Drawing.Color.DarkBlue
        Me.Employee_Info1.Location = New System.Drawing.Point(216, 80)
        Me.Employee_Info1.Name = "Employee_Info1"
        Me.Employee_Info1.Padding = New System.Windows.Forms.Padding(2)
        Me.Employee_Info1.Size = New System.Drawing.Size(398, 113)
        Me.Employee_Info1.TabIndex = 3
        Me.Employee_Info1.TabStop = False
        '
        'Emp_Account_Tran_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(791, 505)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Lbl_Words)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Txt_LedgerBal)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Txt_TransactionBal)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Txt_Narration)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Txt_Amount)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Cmb_Payment_Mode)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Dgvw_Emp_AccountTran)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Cmb_Tran_Type)
        Me.Controls.Add(Me.Imageviewer1)
        Me.Controls.Add(Me.Employee_Info1)
        Me.Controls.Add(Me.Txt_EmpID)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Txt_AccountNo)
        Me.Controls.Add(Me.Lbl_AccNo)
        Me.Controls.Add(Me.Pnl_Tran_mode)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.Btn_Find)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Emp_Account_Tran_Frm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Pnl_Tran_mode.ResumeLayout(False)
        Me.Pnl_Common_Btn.ResumeLayout(False)
        CType(Me.Dgvw_Emp_AccountTran, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Cancel As System.Windows.Forms.Button
    Friend WithEvents Btn_Find As System.Windows.Forms.Button
    Friend WithEvents Txt_AccountNo As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_AccNo As System.Windows.Forms.Label
    Friend WithEvents Txt_EmpID As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Employee_Info1 As REAL_CLINIC.Employee_Info
    Friend WithEvents Imageviewer1 As REAL_CLINIC.Imageviewer
    Friend WithEvents Cmb_Tran_Type As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Dgvw_Emp_AccountTran As System.Windows.Forms.DataGridView
    Friend WithEvents Cmb_Payment_Mode As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Txt_Amount As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Txt_Narration As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Btn_Ledger As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Txt_TransactionBal As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Txt_LedgerBal As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_Words As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
End Class
