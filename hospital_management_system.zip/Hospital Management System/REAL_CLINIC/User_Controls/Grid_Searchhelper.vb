﻿

Option Explicit On
Imports HMS_BL
Public Class Grid_Searchhelper


#Region " D e c l a r a t i o n s "
    Private hms_helper As HMS_Helper = Nothing

    Private Dtbl As DataTable = Nothing


    Private Search_Control As TextBox = Nothing
    Private Search_ID_Control As TextBox = Nothing

    Private _Final_Query As String = String.Empty
#End Region

#Region " P r o p e r t i e s "

    Private _Search_Query As String = String.Empty
    Public Property Search_Query() As String
        Get
            Return _Search_Query
        End Get
        Set(ByVal value As String)
            _Search_Query = value
        End Set
    End Property

#End Region

#Region " M e t h o d s "

    Public Function Show_Result(ByRef Search_Ctrl As TextBox, Optional ByRef ID_Ctrl As TextBox = Nothing) As Boolean
        Try
            If Not Search_Control Is Nothing Then
                If Me.Search_Control.Tag = "Loading" Then Return False
            End If


            '==================================================================
            'Add Search Textbox Keydown Event handler
            AddHandler Search_Ctrl.KeyDown, AddressOf Me.Search_Ctrl_KeyDown
            'AddHandler Search_Ctrl.Validating, AddressOf Me.Search_Ctrl_Validating

            Me.Search_Control = Search_Ctrl
            Me.Search_ID_Control = ID_Ctrl
            '==================================================================

            If Search_Ctrl.Text.Trim = String.Empty Then Me.Visible = False
            If Search_Query.Trim = String.Empty Then Me.Visible = False

            '==================================================================

            _Final_Query = Me.Search_Query + "'" & Search_Ctrl.Text.Trim & "%'"
            Dtbl = Nothing
            Grid_List.DataSource = Nothing
            Grid_List.Refresh()
            '==================================================================

            'Executing Query
            hms_helper = New Hms_Helperimpliments
            If hms_helper.Get_Data(_Final_Query, Dtbl) Then
                With Grid_List
                    .DataSource = Dtbl
                    .Refresh()
                    .ClearSelection()
                End With
            End If

            If Me.Grid_List.RowCount > 0 Then
                If Me.Grid_List.ColumnCount >= 1 Then
                    Me.Grid_List.Columns(1).Visible = False
                End If
                Me.Grid_List.Columns(0).Width = 5000
                Call Set_myPosition(Search_Control)
                Me.Visible = True
            Else
                Me.Visible = False
            End If

            Search_Ctrl.Focus()
            Return True

            '==================================================================
        Catch ex As Exception
            MessageBox.Show(ex.Message, ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function

    Private Sub Select_Item(ByVal row As Integer)
        Try
            Search_Control.Tag = "Loading"
            With Grid_List
                If Not Search_Control Is Nothing Then
                    Search_Control.Text = .Item(0, row).Value.ToString.Trim
                    Search_Control.Tag = .Item(1, row).Value.ToString.Trim
                End If
                If Not Search_ID_Control Is Nothing Then
                    Search_ID_Control.Text = .Item(1, row).Value.ToString.Trim
                    Search_ID_Control.Tag = Search_ID_Control.Text
                End If
                Search_Control.Focus()
                Me.Visible = False
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Set_myPosition(ByRef Search_Ctrl As TextBox)
        Try
            Dim newpoint As Point = Nothing
            Dim Ctrl_point As Point = Nothing
            'Dim Search_Ctrl_ParentCtrl As Object

            Me.Width = Search_Ctrl.Width
            Me.Height = 130
            'Search_Ctrl_ParentCtrl = Search_Ctrl.Parent
            'Ctrl_point = Search_Ctrl_ParentCtrl.PointToScreen(Search_Ctrl.Location)
            'newpoint = New Point(Ctrl_point.X - Search_Ctrl.Parent.Parent.Location.X, Ctrl_point.Y - Search_Ctrl.Parent.Parent.Height + 1)

            newpoint = New Point(Search_Ctrl.Location.X, Search_Ctrl.Location.Y + Search_Ctrl.Height + 1)
            Me.Location = newpoint
            Me.BringToFront()
        Catch ex As Exception

        End Try
    End Sub

#End Region

    

    Private Sub Grid_Searchhelper_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            hms_helper = New Hms_Helperimpliments

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Search_Ctrl_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs)
        Try
            If Not Me.Visible Then Return

            If e.KeyCode = Keys.Down Then
                Grid_List.Focus()
            ElseIf e.KeyCode = Keys.Enter Then
                Me.Visible = False
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Search_Ctrl_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs)
        Try
            Me.Visible = False
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Grid_List_CellDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Grid_List.CellDoubleClick
        Try
            Call Select_Item(e.RowIndex)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Grid_List_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Grid_List.KeyDown
        Try
            If e.KeyCode <> Keys.Enter Then Return
            If Grid_List.RowCount > 0 Then
                If Grid_List.CurrentCell Is Nothing Then Return
                Call Select_Item(Grid_List.CurrentCell.RowIndex)
            End If

        Catch ex As Exception

        End Try
    End Sub

End Class
