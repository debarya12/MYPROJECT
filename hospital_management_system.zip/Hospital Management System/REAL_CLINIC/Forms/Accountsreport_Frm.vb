﻿

Option Explicit On
Imports System.IO
Imports HMS_BL
Imports HMS_Common.Common_Cls
Public Class Accountsreport_Frm

    Private helper As HMS_Helper = New Hms_Helperimpliments
    Private AccRpt_Bl As AccountsReports_BL_Cls
    Private mRpt_Vwr As ReportViewer_Cls

    Dim Rpt_Formulafields As String = "Company| " & Company_Name & "|Branch|" & Branch_Name
    Dim Rpt_Filename As String = ""

    Dim Report_Heading As String = ""
    Dim Add_Query As String = ""
    Dim mReport_ID As String = ""

#Region "Properties"

    Private Property Report_ID() As String
        Get
            Return mReport_ID
        End Get
        Set(ByVal value As String)
            mReport_ID = value
        End Set
    End Property

#End Region

#Region "Methods"


    Private Function Load_Reportoptions() As Boolean
        Try
            Dim Dtbl As DataTable = Nothing
            If helper.Get_ReportOptionsGroupwise(Dtbl, 3) Then
                With Dgvw_Reportoptions
                    .RowCount = 0
                    For i = 0 To Dtbl.Rows.Count - 1
                        .Rows.Add()
                        .Rows(i).Cells("Reportname").Value = Dtbl.Rows(i).Item("Rpt_Name").ToString
                        .Rows(i).Cells("ReportID").Value = Dtbl.Rows(i).Item("Rpt_ID").ToString
                        .Rows(i).Cells("Reportfile").Value = Dtbl.Rows(i).Item("Rpt_Filename").ToString
                    Next

                End With
            End If
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Select_Report()

        Report_ID = ""
        Rpt_Filename = ""
        Lbl_Heading.Text = ""
        Set_Default_Env()

        With Dgvw_Reportoptions
            Try
                Lbl_Heading.Text = .Rows(.CurrentRow.Index).Cells("Reportname").Value.ToString.ToUpper

                Report_ID = .Rows(.CurrentCell.RowIndex).Cells("ReportID").Value

                Rpt_Filename = .Rows(.CurrentCell.RowIndex).Cells("Reportfile").Value

                If Rpt_Filename.Trim = "" Then Exit Sub

                Rpt_Filename = IIf(Strings.Left(Rpt_Filename, 1) = "\", Strings.Right(Rpt_Filename, Len(Rpt_Filename) - 1), Rpt_Filename)
                Rpt_Filename = File_Path & "\" & Rpt_Filename

            Catch ex As Exception

            End Try

            If Report_ID <> "" Then
                If Strings.Left(Report_ID, 1) = "G" Then
                    Report_ID = "G"
                ElseIf Strings.Left(Report_ID, 1) = "R" Then
                    Report_ID = Strings.Right(Report_ID, Len(Report_ID) - 1)
                End If
            Else
                Report_ID = "G"
            End If

            Call Set_Environment(Report_ID)


        End With

    End Sub

    Private Sub Set_Daybookenv()
        Try
            Btn_Show.Enabled = True
            Btn_Clear.Enabled = True
            Pnl_Dtp_2.Visible = False
            Pnl_Emplist.Visible = False
            Lbl_Date1.Text = "Date"

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Show_Report(ByVal Rpt_ID As String)

        Select Case Rpt_ID

            Case 5
                Call Show_Daybook(User_ID, Dtp_1.Value, Branch_Code)
            Case 2

            Case Else

        End Select
    End Sub

    Private Sub Set_Environment(ByVal Rpt_ID As String)
        Try
            Call Set_Default_Env()

            Select Case Rpt_ID
                Case 5
                    Call Set_Daybookenv()
                Case 2

                Case Else
            End Select

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Set_Default_Env()
        Try
            Pnl_Dtp_1.Visible = True
            Pnl_Dtp_2.Visible = True
            Btn_Show.Enabled = True
            Btn_Clear.Enabled = True
            Btn_Find.Visible = False

            Dtp_1.Value = Today
            Dtp_2.Value = Today


        Catch ex As Exception

        End Try
    End Sub

    Private Function Date_Validation() As Boolean
        Try
            If Pnl_Dtp_1.Visible = True And Pnl_Dtp_2.Visible = True Then
                If Dtp_1.Value > Dtp_2.Value Then Return False
            End If
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Clear_Form()
        Try


            Rpt_Formulafields = "Company| " & Company_Name & "|Branch|" & Branch_Name
            Report_ID = ""
            Rpt_Filename = ""
            Report_Heading = ""
            Add_Query = ""
            Lbl_Heading.Text = ""
            Pnl_Emplist.Visible = False

            If Pnl_Dtp_1.Visible Then
                Dtp_1.Value = Today
            End If
            If Pnl_Dtp_2.Visible Then
                Dtp_2.Value = Today
            End If
            Call Set_Default_Env()

        Catch ex As Exception

        End Try
    End Sub


    Private Function Show_Daybook(ByVal Session_UID As String, _
                                  ByVal Demand_Date As Date, _
                                  ByVal Br_Code As Int32) As Boolean
        Try
            Dim Daybook_Dtbl As DataTable = Nothing
            Dim Rec_Dtbl As New DataTable
            Dim Pay_Dtbl As New DataTable
            Dim RptDsource As New Collection
            Dim Com_Bl As New HMS_Common_BL_Cls
            Dim Cashbal_Dtbl As DataTable = Nothing
            Dim OP_Bal As Double = 0
            Dim CL_Bal As Double = 0

            AccRpt_Bl = New AccountsReports_BL_Cls

            'Processing Transaction For Daybook
            If Not AccRpt_Bl.Process_Daybook(Daybook_Dtbl, Session_UID, Demand_Date, Br_Code, "N") Then
                MessageBox.Show("Error Occured While Processing Daybook,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If


            'Getting Daybook Data from Processed Data
            If Not AccRpt_Bl.Get_Daybookdata(Daybook_Dtbl, Session_UID, Demand_Date, Br_Code) Then
                MessageBox.Show("No Records Found on this Date", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If

            'Getting Cash Balance for the given Transaction Date
            If Not Com_Bl.Get_Cashbalance(Cashbal_Dtbl, Demand_Date, 1, Br_Code) Then Return False

            OP_Bal = CDbl(Cashbal_Dtbl.Rows(0).Item("Op_Bal").ToString)
            CL_Bal = CDbl(Cashbal_Dtbl.Rows(0).Item("Cl_Bal").ToString)

            Rec_Dtbl = Daybook_Dtbl
            Pay_Dtbl = Daybook_Dtbl

            RptDsource.Add(Rec_Dtbl, 1)
            RptDsource.Add(Pay_Dtbl, 2)

            Report_Heading = "|Heading| Daybook as on - " & Format(Demand_Date, "dd/MM/yyyy") & ""
            Rpt_Formulafields &= "|Op_CashBal|" & Format(OP_Bal, "##.00")
            Rpt_Formulafields &= "|Closing_CashBal|" & Format(CL_Bal, "##.00")
            Rpt_Formulafields &= "|Cashbalancewords|" & Towords(CL_Bal)

            Rpt_Formulafields &= Report_Heading
            mRpt_Vwr.ShowReport(Daybook_Dtbl, Rpt_Formulafields, Rpt_Filename, "", "Dbk_Rec|Dbk_Pay", RptDsource)

        Catch ex As Exception

        End Try
    End Function

#End Region

    Private Sub Accountsreport_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        Try
            If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
        Catch ex As Exception

        End Try
    End Sub


    Private Sub Accountsreport_Frm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try



            Call Load_Reportoptions()




        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgv_AccReports_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Dgvw_Reportoptions.SelectionChanged
        Try
            With Dgvw_Reportoptions
                If .CurrentRow Is Nothing Then Exit Sub
                If .CurrentRow.Index = -1 Then Exit Sub
                Call Select_Report()


            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Show_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Btn_Show.Click
        Try
            If Report_ID.Trim = "" Then
                MessageBox.Show("Invalid Report Selection,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Sub
            End If

            If Not Date_Validation() Then MessageBox.Show("Date Mismatch ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Dtp_1.Focus() : Exit Sub

            'Initialising Report Objects
            mRpt_Vwr = New ReportViewer_Cls
            'Rpt_Ds = Nothing

            If Not File.Exists(Rpt_Filename) Then
                MessageBox.Show("Report File : (" & Rpt_Filename & ") does not exists" & vbCrLf & "Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            Call Show_Report(Report_ID)


        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Try
            Me.Close()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try
            Call Clear_Form()
        Catch ex As Exception

        End Try
    End Sub
End Class