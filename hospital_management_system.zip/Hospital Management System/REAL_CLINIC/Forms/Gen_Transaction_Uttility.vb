﻿
Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls

Public Class Gen_Transaction_Uttility

#Region " D e c l a r a t i o n s "


    Private Gen_Tran_BL As Gen_Transaction_BL_Cls
    Private mRpt_Vwr As ReportViewer_Cls
    Private Rpt_BL As HMS_BL.Reports_BL_Cls
    Private hms_helper As HMS_Helper = Nothing

#End Region

#Region " M e t h o d s "

    Private Sub Clear_Form()
        Try

            Txt_Narration.Text = ""
            Txt_Remarks.Text = ""

            Cmb_AccountHead.SelectedIndex = 0
            Cmb_PaymentMode.SelectedIndex = 0
            Cmb_TranType.SelectedIndex = 0

            Dtp_FromDate.Value = Tran_Date
            Dtp_ToDate.Value = Tran_Date
            Btn_Print.Visible = False
            Dim Add_Quary As String = ""
            Call Populate_GridView(Add_Quary)

        Catch ex As Exception

        End Try
    End Sub

    Public Function Show_Reciept(ByVal Batch_ID As String) As Boolean
        Try
            If Batch_ID = "" Then MessageBox.Show("Invalid  Batch ID .. Please enter valid Tran Id", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Exit Function
            Dim Rpt_Ds As DataSet = Nothing
            Dim Rpt_Formulafields As String = "Company| " & Company_Name & "|Branch|" & Branch_Name
            Dim Rpt_Filename As String = ""
            Dim mReport_ID As String = ""
            Dim Report_Heading As String = ""
            Dim Add_Query As String = ""

            mRpt_Vwr = New ReportViewer_Cls

            Add_Query = ""
            Add_Query = "Where [Batch No] = " & Batch_ID & " "
            Rpt_Filename = File_Path & "\Gen_Tran_Reciept.rpt"
            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Get_GenTran_Reciept(Rpt_Ds, Add_Query) Then

                REM for Geting total amount 
                Dim dtbl As DataTable = Rpt_Ds.Tables(0)
                Dim dr As DataTableReader
                Dim Amt As Double
                Amt = 0
                dr = dtbl.CreateDataReader

                While dr.Read
                    Amt = Amt + Val(dr.Item("Tr_Amount").ToString)
                End While
                REM .....

                Report_Heading = "|Heading| Receipt|Footer3|Authorised Signatory"
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading & "|words|" & Towords(Amt)
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            Else
                MessageBox.Show("Invalid Batch ID .. Please enter valid Batch ID", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function

#End Region


    Private Sub Gen_Transaction_Uttility_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then Call SendKeyTab()
    End Sub

    Private Sub Gen_Transaction_Uttility_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub Gen_Transaction_Uttilty_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            hms_helper = New Hms_Helperimpliments
            'populate Transaction type
            Call Fill_Transaction_Type(Cmb_TranType, "< Select >")
            Cmb_TranType.SelectedIndex = 0


            hms_helper.Fill_AccountMaster(Cmb_AccountHead, "< Select >")
            Cmb_AccountHead.SelectedIndex = 0


            'populate Mode of Payment
            hms_helper.Fill_GenData(Cmb_PaymentMode, Gendatatype.Payment_Mode, "< Select >")
            Cmb_PaymentMode.SelectedIndex = 0
            Dim Add_Quary As String = ""
            Call Populate_GridView(Add_Quary)
            Dgvw_SearchGrid.Rows(0).Selected = True

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Populate_GridView(ByVal Add_Quary As String)
        Try


            Dim dtbl As DataTable = Nothing
            Dim dr As DataTableReader = Nothing
            Dim dtst As DataSet = Nothing
            Gen_Tran_BL = New Gen_Transaction_BL_Cls


            If Gen_Tran_BL.Get_General_Tran_All(dtst, Add_Quary) Then
                dtbl = dtst.Tables(0)

                With Dgvw_SearchGrid

                    .DataSource = Nothing
                    .DataSource = dtbl
                    .Refresh()
                    .Columns(0).MinimumWidth = 25
                    .Columns(1).MinimumWidth = 50
                    .Columns(2).Visible = False
                    .Columns(4).MinimumWidth = 10

                    .ReadOnly = True
                    .Columns(9).Visible = False
                    .Columns(10).Visible = False

                End With

                Dgvw_SearchGrid.Refresh()
                Dgvw_SearchGrid.Rows(0).Selected = True
            End If

        Catch ex As Exception

        End Try

    End Sub

    Private Sub Btn_Uttility_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Uttility.Click
        Try

            Dim Add_Quary As String = ""

            If Cmb_AccountHead.SelectedIndex <> 0 Then
                Add_Quary = "Where [Account Head] = '" & Cmb_AccountHead.Text.Trim & "'"
            End If
            If Add_Quary <> "" Then
                Add_Quary = Add_Quary & " And Date >= '" & Format(Dtp_FromDate.Value, "MM/dd/yyyy") _
                & "' And    Date <= '" & Format(Dtp_ToDate.Value, "MM/dd/yyyy") & "'"
            Else
                Add_Quary = " Where Date >= '" & Format(Dtp_FromDate.Value, "MM/dd/yyyy") _
               & "' And    Date <= '" & Format(Dtp_ToDate.Value, "MM/dd/yyyy") & "'"
            End If
            If Cmb_TranType.SelectedIndex <> 0 Then
                If Add_Quary <> "" Then
                    Add_Quary = Add_Quary & " And [Transaction Type] ='" & Cmb_TranType.Text.Trim & "'"
                Else
                    Add_Quary = "Where [Transaction Type] =' " & Cmb_TranType.Text.Trim & "'"
                End If
            End If

            If Cmb_PaymentMode.SelectedIndex <> 0 Then
                If Add_Quary <> "" Then
                    Add_Quary = Add_Quary & " And [Payment  Mode] = '" & Cmb_PaymentMode.Text.Trim & "'"
                Else
                    Add_Quary = "Where [Payment  Mode] = '" & Cmb_PaymentMode.Text.Trim & "'"
                End If
            End If

            If Txt_Narration.Text <> "" Then
                If Add_Quary <> "" Then
                    Add_Quary = Add_Quary & " And [Narration] like   '" & "%" & Txt_Narration.Text.Trim & "%" & "'"
                Else
                    Add_Quary = "Where [Narration] = '" & "%" & Txt_Narration.Text.Trim & "%" & " &'"
                End If
            End If

            If Txt_Remarks.Text <> "" Then
                If Add_Quary <> "" Then
                    Add_Quary = Add_Quary & " And [Remarks] like   '" & "%" & Txt_Remarks.Text.Trim & "%" & "'"
                Else
                    Add_Quary = "Where [Remarks] = '" & "%" & Txt_Remarks.Text.Trim & "%" & " &'"
                End If
            End If
            Call Populate_GridView(Add_Quary)

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgvw_SearchGrid_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgvw_SearchGrid.CellClick
        Try
            If Dgvw_SearchGrid.CurrentRow Is Nothing Then Exit Sub
            Dgvw_SearchGrid.CurrentRow.Selected = True
            Btn_Print.Visible = True
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgvw_SearchGrid_CellPainting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellPaintingEventArgs) Handles Dgvw_SearchGrid.CellPainting
        Try
            If e.ColumnIndex = 0 AndAlso e.RowIndex <> -1 Then

                Using gridBrush As Brush = New SolidBrush(Me.Dgvw_SearchGrid.GridColor), backColorBrush As Brush = New SolidBrush(e.CellStyle.BackColor)

                    Using gridLinePen As Pen = New Pen(gridBrush)
                        ' Clear cell  
                        e.Graphics.FillRectangle(backColorBrush, e.CellBounds)

                        ' Draw line (bottom border and right border of current cell)  
                        'If next row cell has different content, only draw bottom border line of current cell  
                        If e.RowIndex < Dgvw_SearchGrid.Rows.Count - 2 AndAlso Dgvw_SearchGrid.Rows(e.RowIndex + 1).Cells(e.ColumnIndex).Value.ToString() <> e.Value.ToString() Then
                            e.Graphics.DrawLine(gridLinePen, e.CellBounds.Left, e.CellBounds.Bottom - 1, e.CellBounds.Right - 1, e.CellBounds.Bottom - 1)
                        End If

                        ' Draw right border line of current cell  
                        e.Graphics.DrawLine(gridLinePen, e.CellBounds.Right - 1, e.CellBounds.Top, e.CellBounds.Right - 1, e.CellBounds.Bottom)

                        ' draw/fill content in current cell, and fill only one cell of multiple same cells  
                        If Not e.Value Is Nothing Then
                            If e.RowIndex > 0 AndAlso Dgvw_SearchGrid.Rows(e.RowIndex - 1).Cells(e.ColumnIndex).Value.ToString() = e.Value.ToString() Then
                            Else
                                e.Graphics.DrawString(CType(e.Value, String), e.CellStyle.Font, Brushes.Black, e.CellBounds.X + 2, e.CellBounds.Y + 5, StringFormat.GenericDefault)
                            End If
                        End If

                        e.Handled = True
                    End Using
                End Using
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Print_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Btn_Print.Click
        Try
            If Dgvw_SearchGrid.CurrentRow Is Nothing Then
                MessageBox.Show("Please select a record to Print", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Exit Sub
            End If
            Call Show_Reciept(Dgvw_SearchGrid.CurrentRow.Cells("Batch No").Value.ToString)

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try
            Call Clear_Form()
            Cmb_AccountHead.Focus()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click

        Try
            Me.Close()
        Catch ex As Exception

        End Try
    End Sub


End Class