﻿Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls
Public Class ServiceMaster_Frm
#Region "Declarations"

    'Object of Employee Details Bussiness Layer
    Private Service_Master_BL As ServiceMaster_BL_Cls
    Private mTr_Mode As Tran_Mode
    Private StrQry As String

    Private Com_BL As HMS_Common_BL_Cls

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_Service_ID.BackColor = Color.White
                    Me.Txt_Service_ID.ReadOnly = False
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_Service_ID.BackColor = Color.Silver
                    Me.Txt_Service_ID.ReadOnly = True
            End Select
        End Set
    End Property

#End Region

#Region "Methods"

    
    Private Sub Clear_Form()
        Try

            Txt_Service_ID.Text = ""
            Txt_Service_ID.Tag = ""
            Txt_Service_ID.ReadOnly = False
            Txt_Service_ID.BackColor = Color.White

            Txt_Service_Name.Text = ""
            Txt_Service_Name.Tag = ""

            Txt_Service_Name.ReadOnly = False
            Txt_Service_Name.BackColor = Color.White

            Com_BL = New HMS_BL.HMS_Common_BL_Cls
            Com_BL.Fill_ServiceMaster(Cmb_Service_Lid, "    <   NOT APPLICABLE  >   ")

            Btn_Delete.Enabled = False
            Tr_Mode = Tran_Mode.New_Mode


        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Function Locate_Values(ByVal Service_ID As String) As Boolean
        Try

            'Initialising BL Object
            Service_Master_BL = New ServiceMaster_BL_Cls

            Dtbl = Nothing
            Call Clear_Form()

            Txt_Service_ID.Text = Service_ID


            'Retreiving Service Details and Assign the values to respective controls
            If Service_Master_BL.Get_Service_Master_Details(Dtbl, Service_ID) Then
                Return Assigntocontrols(Dtbl)
            Else
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        Finally
            Dr = Nothing
            Dtbl = Nothing
            Service_Master_BL = Nothing
        End Try
    End Function

    Private Function Locate_Valueshelper(ByVal Service_ID As String) As Boolean
        Try

            'Initialising BL Object
            Service_Master_BL = New ServiceMaster_BL_Cls

            Dtbl = Nothing
            Call Clear_Form()

            Txt_Service_ID.Text = Service_ID


            'Retreiving Service Details and Assign the values to respective controls
            If Service_Master_BL.Get_Service_Master_Details(Dtbl, Service_ID) Then
                If Assigntocontrols(Dtbl) Then
                    Txt_Service_ID.ReadOnly = True
                    Txt_Service_ID.BackColor = Color.Silver
                    Txt_Service_Name.ReadOnly = True
                    Txt_Service_Name.BackColor = Color.Silver
                End If

            Else
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        Finally
            Dr = Nothing
            Dtbl = Nothing
            Service_Master_BL = Nothing
        End Try
    End Function

    Private Function Assigntocontrols(ByVal D_Table As DataTable) As Boolean
        Try

            Dr = D_Table.CreateDataReader()
            Dr.Read()
            With Dr
                Txt_Service_ID.Text = .Item("Service_ID")
                Txt_Service_ID.Tag = .Item("Service_ID")
                Txt_Service_Name.Text = .Item("Service Name")
                Cmb_Service_Lid.SelectedValue = .Item("Service_ParentID")

                If .Item("Active").ToString.Trim = "Y" Then
                    Cmb_Active.SelectedIndex = 0
                Else
                    Cmb_Active.SelectedIndex = 1
                End If

                If .Item("Appointment_Needed").ToString.Trim = "Y" Then
                    cmb_App_Need.SelectedIndex = 0
                Else
                    cmb_App_Need.SelectedIndex = 1
                End If
            End With

            Return True
        Catch ex As Exception
            Return False
        Finally
            D_Table = Nothing
        End Try
    End Function

    Private Sub ShowInGrid()
        Try
            Com_BL = New HMS_Common_BL_Cls
            Dim Sr_Dtbl As DataTable = Nothing

            StrQry = "Select Service_ID,[Service Name],[Parent Service], Active from Servicemaster_Vw where Br_Code=" & Branch_Code & ""
            If Com_BL.Get_Data(StrQry, Sr_Dtbl) Then
                With Dgrd_ServiceMas
                    .DataSource = Nothing
                    .DataSource = Sr_Dtbl
                    .Refresh()
                    .Columns(0).MinimumWidth = 50
                    .Columns(1).MinimumWidth = 205
                    .Columns(2).MinimumWidth = 170
                    .Columns(3).AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells
                    '.Columns(4).AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells
                    '.Columns(5).AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells


                End With
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try
    End Sub

    Private Function Validate_Fields() As Boolean
        Try
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If

            If Tr_Mode <> Tran_Mode.New_Mode Then
                If Txt_Service_ID.Text.Trim = "" Then MessageBox.Show("Invalid  Service Id ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Service_ID.Focus() : Exit Function
            End If
            If Txt_Service_Name.Text.Trim = "" Then MessageBox.Show("Invalid Service Name,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Service_Name.Focus() : Exit Function


            'If Cmb_Dep_Lid.Text.Trim 
            Return True
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function

#End Region

    Private Sub ServiceMaster_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then SendKeyTab()
        If e.KeyCode = Keys.F2 Then Btn_Find_Click(sender, e)
    End Sub

    Private Sub ServiceMaster_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub ServiceMaster_Frm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try


            Call Clear_Form()
            Com_BL.Fill_ServiceMaster(Cmb_Service_Lid, "    <   NOT APPLICABLE  >   ")
            cmb_App_Need.SelectedIndex = 0
            Cmb_Active.SelectedIndex = 0
            Call ShowInGrid()

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try

            Service_Master_BL = New ServiceMaster_BL_Cls
            If Not Validate_Fields() Then Exit Sub

            With Service_Master_BL
                .Service_ID = Val(Txt_Service_ID.Text)
                .Service_Name = Txt_Service_Name.Text.Trim
                .Service_ParentID = Cmb_Service_Lid.SelectedValue
                .Appointment_Needed = Strings.Left(cmb_App_Need.Text, 1).Trim
                If Strings.Left(Cmb_Active.Text, 1).Trim = "A" Then
                    .Active = "Y"
                Else
                    .Active = "N"
                End If

            End With

            If Service_Master_BL.Save_Service_Master(Dtbl, Val(Txt_Service_ID.Text), Tr_Mode) Then
                MessageBox.Show("Service master saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Call Clear_Form()
                If Assigntocontrols(Dtbl) Then
                    Tr_Mode = Tran_Mode.Edit_Mode
                    Btn_Delete.Enabled = True
                End If
                Call ShowInGrid()
                Com_BL.Fill_ServiceMaster(Cmb_Service_Lid, "    <   NOT APPLICABLE  >   ")
                Btn_Clear.Focus()
                Exit Sub
            Else
                MessageBox.Show("Service master not saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click
        Try
            'Validating Mandatory fields for Deleting
            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If

            If MessageBox.Show("Are you sure want to delete the Service Details", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.No Then Exit Sub
            If Tr_Mode = Tran_Mode.New_Mode Then
                MessageBox.Show("You have to locate details before deleting the record", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

            If Txt_Service_ID.Text.Trim = "" Then
                MessageBox.Show("Invalid Service ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                If Txt_Service_ID.Enabled = True Then Txt_Service_ID.Focus() : Exit Sub
            End If

            'Initialising BL Object
            Service_Master_BL = New HMS_BL.ServiceMaster_BL_Cls

            If Service_Master_BL.Del_ServiceMaster_Details(Txt_Service_ID.Text.Trim) Then
                MessageBox.Show("Service Details Deleted", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Call Btn_Clear_Click(sender, e)
                Call ShowInGrid()
            Else
                MessageBox.Show("You cannot delete this service details" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
            Call Clear_Form()
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Service_Master_BL = Nothing
        End Try

    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try

            Call Clear_Form()
            Txt_Service_ID.Focus()

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Close()
    End Sub

    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try

            If Txt_Service_ID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "225|225|50"
                Sql = "Select [Service Name],[Parent Service],Service_ID, Active from Servicemaster_Vw where Br_Code = " & Branch_Code & ""
                Call ShowSearchengine(Txt_Service_ID, Sql, 2, "Service Name", Colwidth, , 0)
            End If

            'Validating Mandatory fields for locating
            If Txt_Service_ID.Text.Trim = "" Then
                Txt_Service_ID.Focus() : Exit Sub
            End If

            If Locate_Values(Txt_Service_ID.Text.Trim) Then
                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Delete.Enabled = True
            Else
                MessageBox.Show("Investigation Master does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_Service_Name_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_Service_Name.Validating
        Try
            If Txt_Service_Name.Text.Trim = String.Empty Then Return

            If Tr_Mode = Tran_Mode.New_Mode Then
                If Com_BL.Check_Duplicatedataexists("Servicemaster_Tbl", "Service_Name", Data_Type.General_Type, Txt_Service_Name.Text.Trim, Branch_Code) Then
                    MessageBox.Show("Service Name already exists", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    e.Cancel = True
                    Txt_Service_Name.Text = ""
                End If
                If Txt_Service_Name.Tag <> "" Then
                    Locate_Valueshelper(Txt_Service_Name.Tag)
                    Cmb_Service_Lid.Focus()
                    Exit Sub
                End If
            Else
                If Com_BL.Check_Duplicatedataexists("Servicemaster_Tbl", "Service_Name", Data_Type.General_Type, Txt_Service_Name.Text.Trim, Branch_Code, , "Service_ID", Data_Type.Integer_Type, Txt_Service_ID.Text.Trim) Then
                    MessageBox.Show("Service Name already exists", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    e.Cancel = True
                    Txt_Service_Name.Text = ""
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_Service_ID_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Service_ID.KeyPress
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Service_ID.Text, Data_Type.Integer_Type, 12))
    End Sub

    Private Sub Txt_Service_ID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_Service_ID.Validating
        Try
            If Txt_Service_ID.Text.Trim <> "" And Txt_Service_ID.Text.Trim <> Txt_Service_ID.Tag Then
                If Locate_Values(Txt_Service_ID.Text.Trim) Then
                    Tr_Mode = Tran_Mode.Edit_Mode
                    Btn_Delete.Enabled = True
                    SendKeyTab()
                Else
                    MessageBox.Show("Invalid service Id, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Tr_Mode = Tran_Mode.New_Mode
                    e.Cancel = True
                End If

            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    
    Private Sub Dgrd_ServiceMas_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            With Dgrd_ServiceMas
                If .CurrentRow Is Nothing Then Exit Sub
                Txt_Service_ID.Text = .Item("Service_ID", .CurrentCell.RowIndex).Value.ToString
                Call Btn_Find_Click(sender, e)
                Txt_Service_ID.Focus()
            End With

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Dgrd_ServiceMas_DoubleClick1(ByVal sender As Object, ByVal e As System.EventArgs) Handles Dgrd_ServiceMas.DoubleClick
        Try
            With Dgrd_ServiceMas
                Txt_Service_ID.Text = .Item("Service_ID", .CurrentCell.RowIndex).Value.ToString
                Call Btn_Find_Click(sender, e)
                Txt_Service_ID.Focus()
            End With

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Service_Name_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Service_Name.KeyUp
        Try
            If Txt_Service_Name.Text.Trim = String.Empty Then Return
            If Me.Tr_Mode <> Tran_Mode.New_Mode Then Return
            With Grid_Searchhelper1
                .Search_Query = "SELECT Distinct Service_Name, Service_ID"
                .Search_Query += " FROM Servicemaster_Tbl "
                .Search_Query += " WHERE     (Br_Code <> " & Branch_Code & ") AND Service_Name LIKE "
                .Show_Result(Txt_Service_Name, Txt_Service_ID)
            End With

        Catch ex As Exception

        End Try
    End Sub

End Class