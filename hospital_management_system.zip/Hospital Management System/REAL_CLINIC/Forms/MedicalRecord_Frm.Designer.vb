﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MedicalRecord_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MedicalRecord_Frm))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Lbl_Heading = New System.Windows.Forms.Label
        Me.Pnl_1 = New System.Windows.Forms.Panel
        Me.Label2 = New System.Windows.Forms.Label
        Me.Txt_DocDetails = New System.Windows.Forms.TextBox
        Me.Txt_DocID = New System.Windows.Forms.TextBox
        Me.Btn_DocFind = New System.Windows.Forms.Button
        Me.Btn_PMRFind = New System.Windows.Forms.Button
        Me.Txt_PMRID = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Patient_Info1 = New REAL_CLINIC.Patient_Info
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label
        Me.Pnl_Vitals = New System.Windows.Forms.Panel
        Me.Txt_Bloodclass = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.Txt_Pulse = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.Txt_Respiration = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.Txt_BPSystolic = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Txt_BPDiastolic = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.Rbtn_H_Pt = New System.Windows.Forms.RadioButton
        Me.Rbtn_H_Cm = New System.Windows.Forms.RadioButton
        Me.Txt_Height = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Rbtn_T_C = New System.Windows.Forms.RadioButton
        Me.Rbtn_T_F = New System.Windows.Forms.RadioButton
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Rbtn_W_P = New System.Windows.Forms.RadioButton
        Me.Rbtn_W_K = New System.Windows.Forms.RadioButton
        Me.Txt_Temprature = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Txt_Weight = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Panel4 = New System.Windows.Forms.Panel
        Me.Btn_Billdetails = New System.Windows.Forms.Button
        Me.Btn_Recomendations = New System.Windows.Forms.Button
        Me.Btn_PTransaction = New System.Windows.Forms.Button
        Me.Btn_Diagnosis = New System.Windows.Forms.Button
        Me.Btn_Prescription = New System.Windows.Forms.Button
        Me.Txt_Results = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.Txt_Testconducted = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.Txt_Complaints = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Cancel = New System.Windows.Forms.Button
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.Dgrd_Medicalrecord = New System.Windows.Forms.DataGridView
        Me.Label14 = New System.Windows.Forms.Label
        Me.Pnl_Header.SuspendLayout()
        Me.Pnl_1.SuspendLayout()
        Me.Pnl_Tran_mode.SuspendLayout()
        Me.Pnl_Vitals.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        CType(Me.Dgrd_Medicalrecord, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Menu_Bkg
        Me.Pnl_Header.Controls.Add(Me.Lbl_Heading)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(807, 18)
        Me.Pnl_Header.TabIndex = 0
        '
        'Lbl_Heading
        '
        Me.Lbl_Heading.AutoSize = True
        Me.Lbl_Heading.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Heading.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Heading.ForeColor = System.Drawing.Color.White
        Me.Lbl_Heading.Location = New System.Drawing.Point(7, 1)
        Me.Lbl_Heading.Name = "Lbl_Heading"
        Me.Lbl_Heading.Size = New System.Drawing.Size(391, 16)
        Me.Lbl_Heading.TabIndex = 0
        Me.Lbl_Heading.Text = "P A T I E N T    M E D I C A L    R E C O R D    M A N A G E M E N T"
        '
        'Pnl_1
        '
        Me.Pnl_1.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_1.Controls.Add(Me.Label2)
        Me.Pnl_1.Controls.Add(Me.Txt_DocDetails)
        Me.Pnl_1.Controls.Add(Me.Txt_DocID)
        Me.Pnl_1.Controls.Add(Me.Btn_DocFind)
        Me.Pnl_1.Controls.Add(Me.Btn_PMRFind)
        Me.Pnl_1.Controls.Add(Me.Txt_PMRID)
        Me.Pnl_1.Controls.Add(Me.Label1)
        Me.Pnl_1.Controls.Add(Me.Patient_Info1)
        Me.Pnl_1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_1.Location = New System.Drawing.Point(0, 18)
        Me.Pnl_1.Name = "Pnl_1"
        Me.Pnl_1.Size = New System.Drawing.Size(807, 125)
        Me.Pnl_1.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(3, 37)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(45, 13)
        Me.Label2.TabIndex = 1093
        Me.Label2.Text = "Doctor"
        '
        'Txt_DocDetails
        '
        Me.Txt_DocDetails.BackColor = System.Drawing.Color.White
        Me.Txt_DocDetails.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_DocDetails.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_DocDetails.Location = New System.Drawing.Point(93, 60)
        Me.Txt_DocDetails.MaxLength = 500
        Me.Txt_DocDetails.Multiline = True
        Me.Txt_DocDetails.Name = "Txt_DocDetails"
        Me.Txt_DocDetails.ReadOnly = True
        Me.Txt_DocDetails.Size = New System.Drawing.Size(265, 60)
        Me.Txt_DocDetails.TabIndex = 5
        Me.Txt_DocDetails.TabStop = False
        '
        'Txt_DocID
        '
        Me.Txt_DocID.BackColor = System.Drawing.Color.White
        Me.Txt_DocID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_DocID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_DocID.Location = New System.Drawing.Point(93, 33)
        Me.Txt_DocID.MaxLength = 10
        Me.Txt_DocID.Name = "Txt_DocID"
        Me.Txt_DocID.Size = New System.Drawing.Size(152, 21)
        Me.Txt_DocID.TabIndex = 3
        Me.Txt_DocID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Btn_DocFind
        '
        Me.Btn_DocFind.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_DocFind.BackgroundImage = CType(resources.GetObject("Btn_DocFind.BackgroundImage"), System.Drawing.Image)
        Me.Btn_DocFind.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_DocFind.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_DocFind.ForeColor = System.Drawing.Color.White
        Me.Btn_DocFind.Location = New System.Drawing.Point(246, 33)
        Me.Btn_DocFind.Name = "Btn_DocFind"
        Me.Btn_DocFind.Size = New System.Drawing.Size(29, 21)
        Me.Btn_DocFind.TabIndex = 4
        Me.Btn_DocFind.TabStop = False
        Me.Btn_DocFind.Text = "F2"
        Me.Btn_DocFind.UseVisualStyleBackColor = False
        '
        'Btn_PMRFind
        '
        Me.Btn_PMRFind.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_PMRFind.BackgroundImage = CType(resources.GetObject("Btn_PMRFind.BackgroundImage"), System.Drawing.Image)
        Me.Btn_PMRFind.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_PMRFind.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_PMRFind.ForeColor = System.Drawing.Color.White
        Me.Btn_PMRFind.Location = New System.Drawing.Point(246, 6)
        Me.Btn_PMRFind.Name = "Btn_PMRFind"
        Me.Btn_PMRFind.Size = New System.Drawing.Size(28, 21)
        Me.Btn_PMRFind.TabIndex = 2
        Me.Btn_PMRFind.TabStop = False
        Me.Btn_PMRFind.Text = "F2"
        Me.Btn_PMRFind.UseVisualStyleBackColor = False
        '
        'Txt_PMRID
        '
        Me.Txt_PMRID.BackColor = System.Drawing.Color.White
        Me.Txt_PMRID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_PMRID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PMRID.Location = New System.Drawing.Point(93, 6)
        Me.Txt_PMRID.MaxLength = 15
        Me.Txt_PMRID.Name = "Txt_PMRID"
        Me.Txt_PMRID.Size = New System.Drawing.Size(152, 21)
        Me.Txt_PMRID.TabIndex = 1
        Me.Txt_PMRID.Tag = ""
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(3, 10)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(50, 13)
        Me.Label1.TabIndex = 1088
        Me.Label1.Text = "PMR-ID"
        '
        'Patient_Info1
        '
        Me.Patient_Info1.BackColor = System.Drawing.Color.AliceBlue
        Me.Patient_Info1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Patient_Info1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Patient_Info1.Location = New System.Drawing.Point(364, 3)
        Me.Patient_Info1.Name = "Patient_Info1"
        Me.Patient_Info1.Padding = New System.Windows.Forms.Padding(2)
        Me.Patient_Info1.Size = New System.Drawing.Size(440, 117)
        Me.Patient_Info1.TabIndex = 6
        Me.Patient_Info1.TabStop = False
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(728, 5)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(74, 22)
        Me.Pnl_Tran_mode.TabIndex = 100035
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(2, 1)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(68, 16)
        Me.Lbl_Tran_Mode.TabIndex = 0
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Pnl_Vitals
        '
        Me.Pnl_Vitals.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Vitals.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Vitals.Controls.Add(Me.Pnl_Tran_mode)
        Me.Pnl_Vitals.Controls.Add(Me.Txt_Bloodclass)
        Me.Pnl_Vitals.Controls.Add(Me.Label10)
        Me.Pnl_Vitals.Controls.Add(Me.Txt_Pulse)
        Me.Pnl_Vitals.Controls.Add(Me.Label9)
        Me.Pnl_Vitals.Controls.Add(Me.Txt_Respiration)
        Me.Pnl_Vitals.Controls.Add(Me.Label8)
        Me.Pnl_Vitals.Controls.Add(Me.Txt_BPSystolic)
        Me.Pnl_Vitals.Controls.Add(Me.Label7)
        Me.Pnl_Vitals.Controls.Add(Me.Txt_BPDiastolic)
        Me.Pnl_Vitals.Controls.Add(Me.Label6)
        Me.Pnl_Vitals.Controls.Add(Me.Panel3)
        Me.Pnl_Vitals.Controls.Add(Me.Txt_Height)
        Me.Pnl_Vitals.Controls.Add(Me.Label5)
        Me.Pnl_Vitals.Controls.Add(Me.Panel2)
        Me.Pnl_Vitals.Controls.Add(Me.Panel1)
        Me.Pnl_Vitals.Controls.Add(Me.Txt_Temprature)
        Me.Pnl_Vitals.Controls.Add(Me.Label4)
        Me.Pnl_Vitals.Controls.Add(Me.Txt_Weight)
        Me.Pnl_Vitals.Controls.Add(Me.Label3)
        Me.Pnl_Vitals.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Vitals.Location = New System.Drawing.Point(0, 143)
        Me.Pnl_Vitals.Name = "Pnl_Vitals"
        Me.Pnl_Vitals.Size = New System.Drawing.Size(807, 88)
        Me.Pnl_Vitals.TabIndex = 2
        '
        'Txt_Bloodclass
        '
        Me.Txt_Bloodclass.BackColor = System.Drawing.Color.White
        Me.Txt_Bloodclass.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Bloodclass.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Bloodclass.Location = New System.Drawing.Point(528, 33)
        Me.Txt_Bloodclass.MaxLength = 15
        Me.Txt_Bloodclass.Name = "Txt_Bloodclass"
        Me.Txt_Bloodclass.Size = New System.Drawing.Size(69, 21)
        Me.Txt_Bloodclass.TabIndex = 11
        Me.Txt_Bloodclass.Tag = ""
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(439, 38)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(70, 13)
        Me.Label10.TabIndex = 1108
        Me.Label10.Text = "Blood Class"
        '
        'Txt_Pulse
        '
        Me.Txt_Pulse.BackColor = System.Drawing.Color.White
        Me.Txt_Pulse.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Pulse.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Pulse.Location = New System.Drawing.Point(528, 5)
        Me.Txt_Pulse.MaxLength = 15
        Me.Txt_Pulse.Name = "Txt_Pulse"
        Me.Txt_Pulse.Size = New System.Drawing.Size(69, 21)
        Me.Txt_Pulse.TabIndex = 10
        Me.Txt_Pulse.Tag = ""
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(439, 9)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(37, 13)
        Me.Label9.TabIndex = 1106
        Me.Label9.Text = "Pulse"
        '
        'Txt_Respiration
        '
        Me.Txt_Respiration.BackColor = System.Drawing.Color.White
        Me.Txt_Respiration.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Respiration.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Respiration.Location = New System.Drawing.Point(363, 60)
        Me.Txt_Respiration.MaxLength = 15
        Me.Txt_Respiration.Name = "Txt_Respiration"
        Me.Txt_Respiration.Size = New System.Drawing.Size(69, 21)
        Me.Txt_Respiration.TabIndex = 9
        Me.Txt_Respiration.Tag = ""
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(273, 64)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(72, 13)
        Me.Label8.TabIndex = 1104
        Me.Label8.Text = "Respiration"
        '
        'Txt_BPSystolic
        '
        Me.Txt_BPSystolic.BackColor = System.Drawing.Color.White
        Me.Txt_BPSystolic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_BPSystolic.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_BPSystolic.Location = New System.Drawing.Point(363, 33)
        Me.Txt_BPSystolic.MaxLength = 15
        Me.Txt_BPSystolic.Name = "Txt_BPSystolic"
        Me.Txt_BPSystolic.Size = New System.Drawing.Size(69, 21)
        Me.Txt_BPSystolic.TabIndex = 8
        Me.Txt_BPSystolic.Tag = ""
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(273, 37)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(68, 13)
        Me.Label7.TabIndex = 1102
        Me.Label7.Text = "BP Systolic"
        '
        'Txt_BPDiastolic
        '
        Me.Txt_BPDiastolic.BackColor = System.Drawing.Color.White
        Me.Txt_BPDiastolic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_BPDiastolic.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_BPDiastolic.Location = New System.Drawing.Point(363, 5)
        Me.Txt_BPDiastolic.MaxLength = 15
        Me.Txt_BPDiastolic.Name = "Txt_BPDiastolic"
        Me.Txt_BPDiastolic.Size = New System.Drawing.Size(69, 21)
        Me.Txt_BPDiastolic.TabIndex = 7
        Me.Txt_BPDiastolic.Tag = ""
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(273, 9)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(72, 13)
        Me.Label6.TabIndex = 1100
        Me.Label6.Text = "BP Diastolic"
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.Rbtn_H_Pt)
        Me.Panel3.Controls.Add(Me.Rbtn_H_Cm)
        Me.Panel3.Location = New System.Drawing.Point(167, 58)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(102, 25)
        Me.Panel3.TabIndex = 6
        '
        'Rbtn_H_Pt
        '
        Me.Rbtn_H_Pt.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Rbtn_H_Pt.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Rbtn_H_Pt.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rbtn_H_Pt.ForeColor = System.Drawing.Color.White
        Me.Rbtn_H_Pt.Location = New System.Drawing.Point(57, 4)
        Me.Rbtn_H_Pt.Name = "Rbtn_H_Pt"
        Me.Rbtn_H_Pt.Size = New System.Drawing.Size(42, 17)
        Me.Rbtn_H_Pt.TabIndex = 2
        Me.Rbtn_H_Pt.Text = "Pt"
        Me.Rbtn_H_Pt.UseVisualStyleBackColor = False
        '
        'Rbtn_H_Cm
        '
        Me.Rbtn_H_Cm.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Rbtn_H_Cm.Checked = True
        Me.Rbtn_H_Cm.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Rbtn_H_Cm.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rbtn_H_Cm.ForeColor = System.Drawing.Color.White
        Me.Rbtn_H_Cm.Location = New System.Drawing.Point(5, 4)
        Me.Rbtn_H_Cm.Name = "Rbtn_H_Cm"
        Me.Rbtn_H_Cm.Size = New System.Drawing.Size(42, 17)
        Me.Rbtn_H_Cm.TabIndex = 1
        Me.Rbtn_H_Cm.TabStop = True
        Me.Rbtn_H_Cm.Text = "Cm"
        Me.Rbtn_H_Cm.UseVisualStyleBackColor = False
        '
        'Txt_Height
        '
        Me.Txt_Height.BackColor = System.Drawing.Color.White
        Me.Txt_Height.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Height.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Height.Location = New System.Drawing.Point(92, 59)
        Me.Txt_Height.MaxLength = 15
        Me.Txt_Height.Name = "Txt_Height"
        Me.Txt_Height.Size = New System.Drawing.Size(69, 21)
        Me.Txt_Height.TabIndex = 5
        Me.Txt_Height.Tag = ""
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(2, 63)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(44, 13)
        Me.Label5.TabIndex = 1097
        Me.Label5.Text = "Height"
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.Rbtn_T_C)
        Me.Panel2.Controls.Add(Me.Rbtn_T_F)
        Me.Panel2.Location = New System.Drawing.Point(167, 31)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(102, 25)
        Me.Panel2.TabIndex = 4
        '
        'Rbtn_T_C
        '
        Me.Rbtn_T_C.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Rbtn_T_C.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Rbtn_T_C.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rbtn_T_C.ForeColor = System.Drawing.Color.White
        Me.Rbtn_T_C.Location = New System.Drawing.Point(57, 4)
        Me.Rbtn_T_C.Name = "Rbtn_T_C"
        Me.Rbtn_T_C.Size = New System.Drawing.Size(42, 17)
        Me.Rbtn_T_C.TabIndex = 2
        Me.Rbtn_T_C.Text = "C"
        Me.Rbtn_T_C.UseVisualStyleBackColor = False
        '
        'Rbtn_T_F
        '
        Me.Rbtn_T_F.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Rbtn_T_F.Checked = True
        Me.Rbtn_T_F.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Rbtn_T_F.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rbtn_T_F.ForeColor = System.Drawing.Color.White
        Me.Rbtn_T_F.Location = New System.Drawing.Point(5, 4)
        Me.Rbtn_T_F.Name = "Rbtn_T_F"
        Me.Rbtn_T_F.Size = New System.Drawing.Size(42, 17)
        Me.Rbtn_T_F.TabIndex = 1
        Me.Rbtn_T_F.TabStop = True
        Me.Rbtn_T_F.Text = "F"
        Me.Rbtn_T_F.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Rbtn_W_P)
        Me.Panel1.Controls.Add(Me.Rbtn_W_K)
        Me.Panel1.Location = New System.Drawing.Point(167, 4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(102, 25)
        Me.Panel1.TabIndex = 2
        '
        'Rbtn_W_P
        '
        Me.Rbtn_W_P.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Rbtn_W_P.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Rbtn_W_P.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rbtn_W_P.ForeColor = System.Drawing.Color.White
        Me.Rbtn_W_P.Location = New System.Drawing.Point(57, 4)
        Me.Rbtn_W_P.Name = "Rbtn_W_P"
        Me.Rbtn_W_P.Size = New System.Drawing.Size(42, 17)
        Me.Rbtn_W_P.TabIndex = 2
        Me.Rbtn_W_P.Text = "P"
        Me.Rbtn_W_P.UseVisualStyleBackColor = False
        '
        'Rbtn_W_K
        '
        Me.Rbtn_W_K.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Rbtn_W_K.Checked = True
        Me.Rbtn_W_K.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.Rbtn_W_K.FlatAppearance.CheckedBackColor = System.Drawing.Color.White
        Me.Rbtn_W_K.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Rbtn_W_K.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Rbtn_W_K.ForeColor = System.Drawing.Color.White
        Me.Rbtn_W_K.Location = New System.Drawing.Point(5, 4)
        Me.Rbtn_W_K.Name = "Rbtn_W_K"
        Me.Rbtn_W_K.Size = New System.Drawing.Size(42, 17)
        Me.Rbtn_W_K.TabIndex = 1
        Me.Rbtn_W_K.TabStop = True
        Me.Rbtn_W_K.Text = "K"
        Me.Rbtn_W_K.UseVisualStyleBackColor = False
        '
        'Txt_Temprature
        '
        Me.Txt_Temprature.BackColor = System.Drawing.Color.White
        Me.Txt_Temprature.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Temprature.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Temprature.Location = New System.Drawing.Point(92, 32)
        Me.Txt_Temprature.MaxLength = 15
        Me.Txt_Temprature.Name = "Txt_Temprature"
        Me.Txt_Temprature.Size = New System.Drawing.Size(69, 21)
        Me.Txt_Temprature.TabIndex = 3
        Me.Txt_Temprature.Tag = ""
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(2, 36)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(82, 13)
        Me.Label4.TabIndex = 1092
        Me.Label4.Text = "Temperature"
        '
        'Txt_Weight
        '
        Me.Txt_Weight.BackColor = System.Drawing.Color.White
        Me.Txt_Weight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Weight.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Weight.Location = New System.Drawing.Point(92, 5)
        Me.Txt_Weight.MaxLength = 15
        Me.Txt_Weight.Name = "Txt_Weight"
        Me.Txt_Weight.Size = New System.Drawing.Size(69, 21)
        Me.Txt_Weight.TabIndex = 1
        Me.Txt_Weight.Tag = ""
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(2, 9)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(47, 13)
        Me.Label3.TabIndex = 1090
        Me.Label3.Text = "Weight"
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.Transparent
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Controls.Add(Me.Btn_Billdetails)
        Me.Panel4.Controls.Add(Me.Btn_Recomendations)
        Me.Panel4.Controls.Add(Me.Btn_PTransaction)
        Me.Panel4.Controls.Add(Me.Btn_Diagnosis)
        Me.Panel4.Controls.Add(Me.Btn_Prescription)
        Me.Panel4.Controls.Add(Me.Txt_Results)
        Me.Panel4.Controls.Add(Me.Label13)
        Me.Panel4.Controls.Add(Me.Txt_Testconducted)
        Me.Panel4.Controls.Add(Me.Label12)
        Me.Panel4.Controls.Add(Me.Txt_Complaints)
        Me.Panel4.Controls.Add(Me.Label11)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel4.Location = New System.Drawing.Point(0, 231)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(807, 146)
        Me.Panel4.TabIndex = 3
        '
        'Btn_Billdetails
        '
        Me.Btn_Billdetails.BackColor = System.Drawing.Color.Indigo
        Me.Btn_Billdetails.BackgroundImage = CType(resources.GetObject("Btn_Billdetails.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Billdetails.Enabled = False
        Me.Btn_Billdetails.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Billdetails.ForeColor = System.Drawing.Color.White
        Me.Btn_Billdetails.Location = New System.Drawing.Point(505, 114)
        Me.Btn_Billdetails.Name = "Btn_Billdetails"
        Me.Btn_Billdetails.Size = New System.Drawing.Size(299, 26)
        Me.Btn_Billdetails.TabIndex = 1100
        Me.Btn_Billdetails.Text = "&B i l l   D e t a i l s      (F8) "
        Me.Btn_Billdetails.UseVisualStyleBackColor = False
        '
        'Btn_Recomendations
        '
        Me.Btn_Recomendations.BackColor = System.Drawing.Color.Indigo
        Me.Btn_Recomendations.BackgroundImage = CType(resources.GetObject("Btn_Recomendations.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Recomendations.Enabled = False
        Me.Btn_Recomendations.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Recomendations.ForeColor = System.Drawing.Color.White
        Me.Btn_Recomendations.Location = New System.Drawing.Point(505, 59)
        Me.Btn_Recomendations.Name = "Btn_Recomendations"
        Me.Btn_Recomendations.Size = New System.Drawing.Size(299, 26)
        Me.Btn_Recomendations.TabIndex = 1098
        Me.Btn_Recomendations.Text = "C o m m e n t s   &&  &R e c o m e n d a t i o n s      (F6)"
        Me.Btn_Recomendations.UseVisualStyleBackColor = False
        '
        'Btn_PTransaction
        '
        Me.Btn_PTransaction.BackColor = System.Drawing.Color.Indigo
        Me.Btn_PTransaction.BackgroundImage = CType(resources.GetObject("Btn_PTransaction.BackgroundImage"), System.Drawing.Image)
        Me.Btn_PTransaction.Enabled = False
        Me.Btn_PTransaction.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_PTransaction.ForeColor = System.Drawing.Color.White
        Me.Btn_PTransaction.Location = New System.Drawing.Point(505, 87)
        Me.Btn_PTransaction.Name = "Btn_PTransaction"
        Me.Btn_PTransaction.Size = New System.Drawing.Size(299, 26)
        Me.Btn_PTransaction.TabIndex = 1099
        Me.Btn_PTransaction.Text = "&T r a n s a c t i o n      (F7) "
        Me.Btn_PTransaction.UseVisualStyleBackColor = False
        '
        'Btn_Diagnosis
        '
        Me.Btn_Diagnosis.BackColor = System.Drawing.Color.Indigo
        Me.Btn_Diagnosis.BackgroundImage = CType(resources.GetObject("Btn_Diagnosis.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Diagnosis.Enabled = False
        Me.Btn_Diagnosis.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Diagnosis.ForeColor = System.Drawing.Color.White
        Me.Btn_Diagnosis.Location = New System.Drawing.Point(505, 3)
        Me.Btn_Diagnosis.Name = "Btn_Diagnosis"
        Me.Btn_Diagnosis.Size = New System.Drawing.Size(299, 26)
        Me.Btn_Diagnosis.TabIndex = 4
        Me.Btn_Diagnosis.Text = "&D i a g n o s i s      (F4)"
        Me.Btn_Diagnosis.UseVisualStyleBackColor = False
        '
        'Btn_Prescription
        '
        Me.Btn_Prescription.BackColor = System.Drawing.Color.Indigo
        Me.Btn_Prescription.BackgroundImage = CType(resources.GetObject("Btn_Prescription.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Prescription.Enabled = False
        Me.Btn_Prescription.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Prescription.ForeColor = System.Drawing.Color.White
        Me.Btn_Prescription.Location = New System.Drawing.Point(505, 31)
        Me.Btn_Prescription.Name = "Btn_Prescription"
        Me.Btn_Prescription.Size = New System.Drawing.Size(299, 26)
        Me.Btn_Prescription.TabIndex = 5
        Me.Btn_Prescription.Text = "&P r e s c r i p t i o n      (F5)"
        Me.Btn_Prescription.UseVisualStyleBackColor = False
        '
        'Txt_Results
        '
        Me.Txt_Results.BackColor = System.Drawing.Color.White
        Me.Txt_Results.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Results.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Results.Location = New System.Drawing.Point(92, 97)
        Me.Txt_Results.MaxLength = 500
        Me.Txt_Results.Multiline = True
        Me.Txt_Results.Name = "Txt_Results"
        Me.Txt_Results.Size = New System.Drawing.Size(340, 44)
        Me.Txt_Results.TabIndex = 3
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.White
        Me.Label13.Location = New System.Drawing.Point(3, 103)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(49, 13)
        Me.Label13.TabIndex = 1097
        Me.Label13.Text = "Results"
        '
        'Txt_Testconducted
        '
        Me.Txt_Testconducted.BackColor = System.Drawing.Color.White
        Me.Txt_Testconducted.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Testconducted.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Testconducted.Location = New System.Drawing.Point(92, 50)
        Me.Txt_Testconducted.MaxLength = 500
        Me.Txt_Testconducted.Multiline = True
        Me.Txt_Testconducted.Name = "Txt_Testconducted"
        Me.Txt_Testconducted.Size = New System.Drawing.Size(340, 44)
        Me.Txt_Testconducted.TabIndex = 2
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.White
        Me.Label12.Location = New System.Drawing.Point(3, 56)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(84, 31)
        Me.Label12.TabIndex = 1095
        Me.Label12.Text = "Test Conducted"
        '
        'Txt_Complaints
        '
        Me.Txt_Complaints.BackColor = System.Drawing.Color.White
        Me.Txt_Complaints.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Complaints.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Complaints.Location = New System.Drawing.Point(92, 3)
        Me.Txt_Complaints.MaxLength = 500
        Me.Txt_Complaints.Multiline = True
        Me.Txt_Complaints.Name = "Txt_Complaints"
        Me.Txt_Complaints.Size = New System.Drawing.Size(340, 44)
        Me.Txt_Complaints.TabIndex = 1
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(3, 13)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(70, 13)
        Me.Label11.TabIndex = 1093
        Me.Label11.Text = "Complaints"
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Cancel)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(506, 381)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(301, 34)
        Me.Pnl_Common_Btn.TabIndex = 6
        '
        'Btn_Cancel
        '
        Me.Btn_Cancel.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Cancel.BackgroundImage = CType(resources.GetObject("Btn_Cancel.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Cancel.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Cancel.ForeColor = System.Drawing.Color.White
        Me.Btn_Cancel.Location = New System.Drawing.Point(77, 3)
        Me.Btn_Cancel.Name = "Btn_Cancel"
        Me.Btn_Cancel.Size = New System.Drawing.Size(73, 26)
        Me.Btn_Cancel.TabIndex = 2
        Me.Btn_Cancel.Text = "C&ancel MR"
        Me.Btn_Cancel.UseVisualStyleBackColor = False
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Clear.Location = New System.Drawing.Point(150, 3)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(73, 26)
        Me.Btn_Clear.TabIndex = 3
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Close.Location = New System.Drawing.Point(223, 3)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(73, 26)
        Me.Btn_Close.TabIndex = 4
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = CType(resources.GetObject("Btn_Save.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Save.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(4, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(73, 26)
        Me.Btn_Save.TabIndex = 1
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Dgrd_Medicalrecord
        '
        Me.Dgrd_Medicalrecord.AllowUserToAddRows = False
        Me.Dgrd_Medicalrecord.AllowUserToDeleteRows = False
        Me.Dgrd_Medicalrecord.AllowUserToResizeColumns = False
        Me.Dgrd_Medicalrecord.AllowUserToResizeRows = False
        Me.Dgrd_Medicalrecord.BackgroundColor = System.Drawing.Color.SteelBlue
        Me.Dgrd_Medicalrecord.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(75, Byte), Integer), CType(CType(103, Byte), Integer), CType(CType(131, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgrd_Medicalrecord.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.Dgrd_Medicalrecord.ColumnHeadersHeight = 20
        Me.Dgrd_Medicalrecord.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.Dgrd_Medicalrecord.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Dgrd_Medicalrecord.Location = New System.Drawing.Point(0, 419)
        Me.Dgrd_Medicalrecord.MultiSelect = False
        Me.Dgrd_Medicalrecord.Name = "Dgrd_Medicalrecord"
        Me.Dgrd_Medicalrecord.ReadOnly = True
        Me.Dgrd_Medicalrecord.RowHeadersVisible = False
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgrd_Medicalrecord.RowsDefaultCellStyle = DataGridViewCellStyle2
        Me.Dgrd_Medicalrecord.RowTemplate.Height = 30
        Me.Dgrd_Medicalrecord.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.Dgrd_Medicalrecord.Size = New System.Drawing.Size(807, 178)
        Me.Dgrd_Medicalrecord.TabIndex = 7
        Me.Dgrd_Medicalrecord.TabStop = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.White
        Me.Label14.Location = New System.Drawing.Point(3, 401)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(248, 13)
        Me.Label14.TabIndex = 1098
        Me.Label14.Text = "* Doubleclick the record to Modify / Cancel"
        '
        'MedicalRecord_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(807, 597)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Dgrd_Medicalrecord)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Pnl_Vitals)
        Me.Controls.Add(Me.Pnl_1)
        Me.Controls.Add(Me.Pnl_Header)
        Me.KeyPreview = True
        Me.Name = "MedicalRecord_Frm"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Pnl_1.ResumeLayout(False)
        Me.Pnl_1.PerformLayout()
        Me.Pnl_Tran_mode.ResumeLayout(False)
        Me.Pnl_Vitals.ResumeLayout(False)
        Me.Pnl_Vitals.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Pnl_Common_Btn.ResumeLayout(False)
        CType(Me.Dgrd_Medicalrecord, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Heading As System.Windows.Forms.Label
    Friend WithEvents Pnl_1 As System.Windows.Forms.Panel
    Friend WithEvents Patient_Info1 As REAL_CLINIC.Patient_Info
    Friend WithEvents Btn_PMRFind As System.Windows.Forms.Button
    Friend WithEvents Txt_PMRID As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Txt_DocID As System.Windows.Forms.TextBox
    Friend WithEvents Btn_DocFind As System.Windows.Forms.Button
    Friend WithEvents Txt_DocDetails As System.Windows.Forms.TextBox
    Friend WithEvents Pnl_Vitals As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Rbtn_W_K As System.Windows.Forms.RadioButton
    Friend WithEvents Txt_Temprature As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Txt_Weight As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Txt_BPDiastolic As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Rbtn_H_Pt As System.Windows.Forms.RadioButton
    Friend WithEvents Rbtn_H_Cm As System.Windows.Forms.RadioButton
    Friend WithEvents Txt_Height As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Rbtn_T_C As System.Windows.Forms.RadioButton
    Friend WithEvents Rbtn_T_F As System.Windows.Forms.RadioButton
    Friend WithEvents Rbtn_W_P As System.Windows.Forms.RadioButton
    Friend WithEvents Txt_Pulse As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Txt_Respiration As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Txt_BPSystolic As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Txt_Bloodclass As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Txt_Testconducted As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Txt_Complaints As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Txt_Results As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Btn_Diagnosis As System.Windows.Forms.Button
    Friend WithEvents Btn_Prescription As System.Windows.Forms.Button
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Dgrd_Medicalrecord As System.Windows.Forms.DataGridView
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Btn_Cancel As System.Windows.Forms.Button
    Friend WithEvents Btn_Recomendations As System.Windows.Forms.Button
    Friend WithEvents Btn_PTransaction As System.Windows.Forms.Button
    Friend WithEvents Btn_Billdetails As System.Windows.Forms.Button
End Class
