﻿

Public Class Navigator_Frm
    Public Point_Frm As Point
    Public MDI_Form As Form

    Public Sub Showmenuform()
        Try
            Call Select_Navigatormenuoption(DGvw_Menulist, MDI_Form)

        Catch ex As Exception

        End Try
    End Sub

    Public Sub DGvw_Menulist_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles DGvw_Menulist.DoubleClick
        Try

            Call Showmenuform()
        Catch ex As Exception

        End Try
    End Sub


    Private Sub DGvw_Menulist_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles DGvw_Menulist.KeyDown
        If e.KeyCode = Keys.Return Then
            Call Showmenuform()
        End If
    End Sub

    Private Sub Navigator_Frm_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Try
            HMS_MDIMain_Frm.Txt_Menucommand.Text = ""
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Navigator_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Try
            If e.KeyCode = Keys.Escape Then
                Me.Close()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Navigator_Frm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.DesktopLocation = Point_Frm
    End Sub

    Private Sub DGvw_Menulist_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DGvw_Menulist.CellContentClick

    End Sub

End Class