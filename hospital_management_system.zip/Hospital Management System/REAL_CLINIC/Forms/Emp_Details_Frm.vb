﻿'Developed by   : PRAMODBHASKER
'Date           : 11-06-2010
'Purpose        : Maintaining(Save / Modify / View) Employee Details

Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls

Public Class Emp_Details_Frm

#Region "Declarations"
    'Object of Employee Details Bussiness Layer
    Private Emp_BL As EmpDetails_BL_Cls
    Private hms_helper As HMS_Helper = Nothing

    Private mTr_Mode As Tran_Mode

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing
    Private Ctrl_Point As Point

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_Emp_ID.BackColor = Color.White
                    Me.Txt_Emp_ID.ReadOnly = False
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_Emp_ID.BackColor = Color.Silver
                    Me.Txt_Emp_ID.ReadOnly = True
            End Select
        End Set
    End Property


#End Region


    Private Sub Close_Btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

    Private Sub Save_Btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try
            'Initialising BL Object
            Emp_BL = New EmpDetails_BL_Cls

            'Validating Data controls
            If Not Validate_Fields() Then Exit Sub

            'Assigning Values to BL Properties
            Emp_BL.Emp_ID = Val(Txt_Emp_ID.Text)
            Emp_BL.SS_Number = Txt_SSNo.Text
            Emp_BL.Emp_Name = Txt_Emp_Name.Text
            Emp_BL.Emp_Addr = Txt_Emp_Add.Text
            Emp_BL.Emp_Country = Cmb_Country.SelectedValue
            Emp_BL.Emp_Gender = Cmb_Gender.Text
            Emp_BL.Emp_DOB = Dtp_DOB.Value
            Emp_BL.Emp_Age = Txt_Age.Text
            Emp_BL.Emp_Phone1 = Txt_Emp_Phone1.Text
            Emp_BL.Emp_Phone2 = Txt_Emp_Phone2.Text
            Emp_BL.Emp_Mobile1 = Txt_Emp_Mob1.Text
            Emp_BL.Emp_Mobile2 = Txt_Emp_Mob2.Text
            Emp_BL.Emp_Qualification = Txt_Qualification.Text
            Emp_BL.Emp_Category = Cmb_EmpCategory.SelectedValue
            Emp_BL.Emp_Email = Txt_Emp_Email.Text
            Emp_BL.Emp_Status = Strings.Left(Cmb_Emp_status.Text, 1)
            Emp_BL.Emp_Admitdate = Dtp_Admitdate.Value
            Emp_BL.Emp_Deactivatedate = Dtp_Deactivate.Value
            Emp_BL.Emp_Designation = Cmb_Designation.SelectedValue

            Dtbl = Nothing

            'Saving Employee Details using BL method
            If Emp_BL.Save_Emp_Details(Dtbl, Val(Txt_Emp_ID.Text), Tr_Mode) Then
                MessageBox.Show("Employee Details Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Call Clear_Form()

                If Assigntocontrols(Dtbl) Then
                    Tr_Mode = Tran_Mode.Edit_Mode
                    Btn_Delete.Enabled = True
                    Btn_Userpwd.Enabled = True
                    Btn_Userpwd.Focus()
                End If

            Else
                MessageBox.Show("Employee Details not Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Function Validate_Fields() As Boolean
        Try
            If Tr_Mode <> Tran_Mode.New_Mode Then
                If Txt_Emp_ID.Text.Trim = "" Then MessageBox.Show("Invalid Employee ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Emp_ID.Focus() : Exit Function
            End If

            If Is_SSnumberneeded And Txt_SSNo.Text.Trim = "" Then MessageBox.Show("Invalid Social Security number Name,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Emp_Name.Focus() : Exit Function
            If Txt_Emp_Name.Text.Trim = "" Then MessageBox.Show("Invalid Employee Name,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Emp_Name.Focus() : Exit Function
            If Txt_Emp_Add.Text.Trim = "" Then MessageBox.Show("Invalid Employee Address,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Emp_Add.Focus() : Exit Function
            If Cmb_Designation.SelectedIndex = 0 Then MessageBox.Show("Please Select Employee Designation", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_Designation.Focus() : Exit Function
            If Txt_Emp_Phone1.Text.Trim = "" Then MessageBox.Show("Invalid Phone Number, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Emp_Add.Focus() : Exit Function

            If Txt_Emp_Email.Text.Trim = "" Then
                Txt_Emp_Email.Text = "-"
            Else
                If Not Email_Validation(Txt_Emp_Email.Text.Trim, True) Then Txt_Emp_Email.Focus() : Exit Function
            End If

            'Assigning Default values
            If Txt_Emp_Phone1.Text.Trim = "" Then Txt_Emp_Phone1.Text = "-"
            If Txt_Emp_Mob1.Text.Trim = "" Then Txt_Emp_Mob1.Text = "-"


            Return True

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try

    End Function

    Private Sub Emp_Details_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then Btn_Find_Click(sender, e)
            If e.KeyCode = Keys.Enter Then Call SendKeyTab()
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Emp_Details_Frm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            'Populating Status Combo
            With Cmb_Emp_status
                .Items.Add("Active")
                .Items.Add("InActive")
                .SelectedIndex = 0
            End With

            'Populating Gender Combo
            With Cmb_Gender
                .Items.Add("Male")
                .Items.Add("Female")
                .SelectedIndex = 0
            End With

            'Populating Country Combo
            With Cmb_Country
                .Items.Add("Soudi Arabia")
                .Items.Add("India")
                .SelectedIndex = 0
            End With

            'Populating Staff Category

            hms_helper = New Hms_Helperimpliments


            Call hms_helper.Fill_GenData(Cmb_EmpCategory, Gendatatype.Employee_Category)


            Call hms_helper.Fill_Designations(Cmb_Designation, "     <       Select     >        ")

            'Call Clear_Form()
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub Clear_Form()
        Try

            Txt_Emp_ID.Text = ""
            Txt_Emp_ID.Tag = ""
            Txt_SSNo.Text = ""
            Txt_Emp_Name.Text = ""
            Txt_Emp_Add.Text = ""
            Txt_Age.Text = ""
            Txt_Emp_Phone1.Text = ""
            Txt_Emp_Phone2.Text = ""
            Txt_Emp_Mob1.Text = ""
            Txt_Emp_Mob2.Text = ""
            Txt_Emp_Email.Text = ""
            Txt_Qualification.Text = ""

            Cmb_EmpCategory.SelectedIndex = 0
            Cmb_Gender.SelectedIndex = 0
            Cmb_Country.SelectedIndex = 0
            Cmb_Emp_status.SelectedIndex = 0
            Cmb_Designation.SelectedIndex = 0


            Imageviewer1.CUST_ID = ""
            Tr_Mode = Tran_Mode.New_Mode

            Btn_Userpwd.Enabled = False
            Btn_Save.Enabled = True
            Btn_Delete.Enabled = False
            If ImageViewer_Frm.Visible Then ImageViewer_Frm.Visible = False

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Clear_Btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try
            Call Clear_Form()
            Txt_Emp_ID.Focus()
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Function Locate_Values(ByVal Emp_ID As Integer) As Boolean



        Try

            'Initialising BL Object
            Emp_BL = New EmpDetails_BL_Cls
            Dtbl = Nothing
            Call Clear_Form()

            Txt_Emp_ID.Text = Emp_ID

            With Imageviewer1
                .CUST_ID = Emp_ID
                .CUST_TYPE = Customer_Type.Employee
            End With

            'Retreiving Employee Details and Assign the values to respective controls
            If Emp_BL.GetEmp_Details(Dtbl, Emp_ID) Then
                Return Assigntocontrols(Dtbl)
            Else
                Return False
            End If



        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        Finally
            Dr = Nothing
            Dtbl = Nothing
            Emp_BL = Nothing
        End Try

    End Function
    Private Function Assigntocontrols(ByVal D_Table As DataTable) As Boolean
        Try

            Dr = D_Table.CreateDataReader()
            Dr.Read()
            With Dr

                Txt_Emp_ID.Text = .Item("Emp_ID").ToString
                Txt_Emp_ID.Tag = .Item("Emp_ID").ToString
                Txt_SSNo.Text = .Item("SS_Number").ToString
                Txt_Emp_Name.Text = .Item("Name").ToString
                Txt_Emp_Add.Text = .Item("address").ToString
                Cmb_Country.SelectedValue = .Item("Emp_Country").ToString
                Dtp_DOB.Value = .Item("Emp_DOB")
                Txt_Age.Text = .Item("Emp_Age")
                Cmb_Gender.Text = .Item("Emp_Gender")
                Cmb_EmpCategory.SelectedValue = .Item("Emp_Category").ToString
                Txt_Emp_Phone1.Text = .Item("Phone").ToString
                Txt_Emp_Phone2.Text = .Item("Emp_Phone2").ToString
                Txt_Emp_Mob1.Text = .Item("Mobile").ToString
                Txt_Emp_Mob2.Text = .Item("Emp_Mobile2").ToString
                Txt_Emp_Email.Text = .Item("Email").ToString
                Txt_Qualification.Text = .Item("Emp_Qualification").ToString
                If .Item("Status") = "A" Then
                    Cmb_Emp_status.SelectedIndex = 0
                Else
                    Cmb_Emp_status.SelectedIndex = 1
                End If
                Cmb_Designation.SelectedValue = .Item("Desig_ID")
                Dtp_Admitdate.Value = CDate(.Item("Admit Date"))
                If Pnl_Deactivate.Visible And Not .IsDBNull(.GetOrdinal("Deactivate Date")) Then
                    Dtp_Deactivate.Value = CDate(.Item("Deactivate Date"))
                End If
                If Len(Txt_Emp_Add.Text) > 150 Then Txt_Emp_Add.ScrollBars = ScrollBars.Both Else Txt_Emp_Add.ScrollBars = ScrollBars.None

            End With

            Return True
        Catch ex As Exception
            Return False
        Finally
            D_Table = Nothing
        End Try
    End Function

    Private Sub Emp_status_Cmb_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_Emp_status.SelectedIndexChanged
        If Cmb_Emp_status.SelectedIndex = 0 Then
            Pnl_Deactivate.Visible = False
        Else
            Pnl_Deactivate.Visible = True
        End If
    End Sub

    Private Sub Delete_Btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click
        Try
            'Validating Mandatory fields for Deleting
            If Tr_Mode = Tran_Mode.New_Mode Then
                MessageBox.Show("You have to locate details before deleting the record", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

            If Txt_Emp_ID.Text.Trim = "" Then
                MessageBox.Show("Invalid Employee ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_Emp_ID.Focus() : Exit Sub
            End If

            'Confirm before delete the record
            If MessageBox.Show("Are you sure wan't to delete the selected employee", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = Windows.Forms.DialogResult.No Then
                Exit Sub
            End If

            'Initialising BL Object
            Emp_BL = New EmpDetails_BL_Cls

            If Emp_BL.DelEmp_Details(Txt_Emp_ID.Text.Trim) Then
                Call Clear_Btn_Click(sender, e)
            Else
                MessageBox.Show("You cannot delete this employee details" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            Emp_BL = Nothing
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try
            If Txt_Emp_ID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "200|200|50|"
                Sql = "SELECT Name, Address, Phone, Mobile, Email, Status, [Admit Date], [Deactivate Date], Emp_ID From Emp_Details_Vw"
                Call ShowSearchengine(Txt_Emp_ID, Sql, 8, "Name", Colwidth, , 0)
            End If

            'Validating Mandatory fields for locating
            If Txt_Emp_ID.Text.Trim = "" Then
                'MessageBox.Show("Invalid Employee ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_Emp_ID.Focus() : Exit Sub
            End If

            If Locate_Values(Txt_Emp_ID.Text.Trim) Then
                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Delete.Enabled = True
                Btn_Userpwd.Enabled = True
                Btn_Userpwd.Focus()
            Else
                MessageBox.Show("Employee ID does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


    Private Sub Btn_Userpwd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Userpwd.Click
        Try
            With Usermanagement_Frm
                .Set_Environment()
                .Txt_Emp_ID.Text = Txt_Emp_ID.Text
                .RemoveOwnedForm(ImageViewer_Frm)
                .Btn_Find_Click(sender, e)
                .MdiParent = Me.MdiParent
                .Show() '
            End With

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_Emp_Phone_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Emp_Phone1.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Emp_Phone1.Text, Data_Type.Integer_Type, 11))
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_Emp_Mob_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Emp_Mob1.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Emp_Mob1.Text, Data_Type.Integer_Type, 9))
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_Emp_ID_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Emp_ID.KeyPress
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Emp_ID.Text, Data_Type.Double_Type, 5))
    End Sub

    Private Sub Txt_Emp_ID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_Emp_ID.Validating
        Try
            If Me.Txt_Emp_ID.Text.Trim <> "" And Me.Txt_Emp_ID.Text <> Me.Txt_Emp_ID.Tag Then
                If Locate_Values(Txt_Emp_ID.Text.Trim) Then
                    Tr_Mode = Tran_Mode.Edit_Mode
                    Btn_Delete.Enabled = True
                    Btn_Userpwd.Enabled = True
                    Btn_Userpwd.Focus()
                Else
                    MessageBox.Show("Employee ID does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Txt_Emp_ID.Focus()
                    e.Cancel = True
                End If

            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_Emp_ID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Emp_ID.TextChanged
        If Txt_Emp_ID.Text.Trim = "" Then
            Call Clear_Form()
        End If
    End Sub

    Private Sub Txt_Emp_Add_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Emp_Add.KeyDown
        If e.KeyCode = Keys.Enter Then Txt_Emp_Add.Select(Len(Txt_Emp_Add.Text), 0)
        If Len(Txt_Emp_Add.Text) > 150 Then Txt_Emp_Add.ScrollBars = ScrollBars.Both Else Txt_Emp_Add.ScrollBars = ScrollBars.None
    End Sub

    Private Sub Emp_Details_Frm_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        Call KeepRightofme(Me, ImageViewer_Frm)
    End Sub


    Private Sub Dtp_DOB_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Dtp_DOB.ValueChanged
        Txt_Age.Text = Int(DateDiff(DateInterval.Month, Dtp_DOB.Value, Tran_Date) / 12).ToString
    End Sub

    Private Sub Btn_New_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_New.Click
        Try
            Dim cname As String = ""
            Dim Fill_ID As String = ""
            Dim i_Start As Int16 = InStr(Me.Btn_New.Tag, "|", CompareMethod.Text)
            cname = Mid(Me.Btn_New.Tag, 1, i_Start - 1)
            Fill_ID = Mid(Me.Btn_New.Tag, i_Start + 1, Len(Me.Btn_New.Tag))
            Dim ctr As Object
            ctr = DirectCast(Me.Controls(cname), ComboBox)
            With Generaldatasave_Frm
                .Point_Frm = Get_GendatasaveformPosition(Me, ctr)
                .Data_CatID = Fill_ID
                .Req_Ctrl = ctr
                .ShowDialog()
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Cmb_Country_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cmb_Country.GotFocus
        Try
            Me.Btn_New.Location = Get_Newgendatabuttonposition(Cmb_Country)
            Me.Btn_New.Tag = "Cmb_Country|" & Gendatatype.Nationality.ToString
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Cmb_EmpCategory_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cmb_EmpCategory.GotFocus
        Try
            Me.Btn_New.Location = Get_Newgendatabuttonposition(Cmb_EmpCategory)
            Me.Btn_New.Tag = "Cmb_EmpCategory|" & Gendatatype.Employee_Category.ToString
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Age_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Age.KeyPress
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Age.Text, Data_Type.Double_Type, 3))
    End Sub
  
    Private Sub Txt_Emp_Phone1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Emp_Phone1.TextChanged

    End Sub

    Private Sub Txt_Emp_Phone2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Emp_Phone2.KeyPress
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Emp_Phone2.Text, Data_Type.Double_Type, 11))
    End Sub

    Private Sub Txt_Emp_Phone2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Emp_Phone2.TextChanged

    End Sub

    Private Sub Txt_Emp_Mob2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Emp_Mob2.KeyPress
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Emp_Mob2.Text, Data_Type.Double_Type, 9))
    End Sub

    Private Sub Txt_Age_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Age.TextChanged
        If Val(Txt_Age.Text) > 250 Then
            ErrorProvider1.SetError(Txt_Age, "Invalid Age")
            ErrorProvider1.BlinkStyle = ErrorBlinkStyle.AlwaysBlink
        Else
            ErrorProvider1.SetError(Txt_Age, "")

        End If
    End Sub
End Class