﻿'Developed by   : Murali
'Date           : 19-08-2010
'Purpose        : Maintaining(Save / Modify / View)  Doctor Details.
Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls

Public Class OutPatient_Master_Frm

#Region "Declarations"
    'Object of Patient Details Bussiness Layer
    ' Private Doctor_BL As OutPatient_BL_Cls
    Private Gen_Tran_BL As Gen_Transaction_BL_Cls
    Private hms_helper As HMS_Helper = Nothing
    Private OutPatient_BL As OutPatient_BL_Cls
    Private Appointment_BL As Appointment_BL_Cls
    Private Patient_Tran_BL As Patient_Transaction_BL_Cls

    Private mReq_Ctrl As Object = Nothing

    Dim StrBatch_Id As String = "" ' Stores batch id from Gen_Transaction table  to update in OPD master table
    Dim Pat_Tran_BID As String = "" ' Stores batch id from Patient_Transaction table 

    Dim Int_GenTran_ID(2)  'TO Store TranId from Gen_tran while find OP Details  
    Dim IntTr_RefNo(2)  'TO STORE refNo from Gen_tran 
    Dim IntPat_Tran_ID(2)  'TO TranId from Patient_Transaction_Tbl
    Dim Assignvalue_Dtbl As New DataTable
    Dim IntRefNo As Long


    Private mTr_Mode As Long

    ' Dim StrBid As String = "" ' Stores batch id from Gen_Transaction table  to update in OPD master table


    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_OutPatientID.BackColor = Color.White
                    Me.Txt_OutPatientID.ReadOnly = False
                    Me.Txt_PatientID.ReadOnly = False
                    Me.Txt_PatientID.BackColor = Color.White
                    Me.Txt_AccID.ReadOnly = False
                    Me.Txt_AccID.BackColor = Color.White
                    Me.Txt_AppID.ReadOnly = False
                    Me.Txt_AppID.BackColor = Color.White
                    Btn_NewPatient.Enabled = True
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_OutPatientID.BackColor = Color.Silver
                    Me.Txt_OutPatientID.ReadOnly = True
                    Me.Txt_PatientID.ReadOnly = True
                    Me.Txt_PatientID.BackColor = Color.Silver
                    Me.Txt_AccID.ReadOnly = True
                    Me.Txt_AccID.BackColor = Color.Silver
                    Me.Txt_AppID.ReadOnly = True
                    Me.Txt_AppID.BackColor = Color.Silver
                    Btn_NewPatient.Enabled = False

            End Select
        End Set
    End Property

#End Region

#Region "Methods"

    Private Function GET_DoctorName(ByVal Dr_Id As Integer) As Boolean
        Try
            Dim Dtbl As DataTable = Nothing
            Dim Dr As DataTableReader = Nothing
            hms_helper = New Hms_Helperimpliments
            Txt_DrID.Tag = ""
            If hms_helper.Get_DoctorName(Dtbl, Dr_Id, 1) Then
                Dr = Dtbl.CreateDataReader()
                Dr.Read()
                With Dr
                    Lbl_Drname.Text = Dr.Item("Name").ToString
                    Txt_DrID.Tag = Dr_Id
                End With
                Return True
            Else
                Lbl_Drname.Text = ""
                Txt_DrID.Tag = ""
                Return False
            End If


        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Function

    Private Sub Get_BatchID(ByVal Batch_Dtbl As DataTable)
        Try
            Dim Dr As DataTableReader = Nothing
            Dr = Batch_Dtbl.CreateDataReader()
            Dr.Read()
            With Dr
                StrBatch_Id = .Item("Tran_BatchID").ToString
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub AssignToControl(ByVal dtbl As DataTable)
        Try

            Dim dr As DataTableReader = Nothing
            dr = dtbl.CreateDataReader()
            dr.Read()

            With dr
                Txt_OutPatientID.Text = .Item("OPD_ID").ToString
                Txt_OutPatientID.Tag = .Item("OPD_ID").ToString
                Txt_AppID.Text = .Item("Appoint ID").ToString
                Txt_PatientID.Text = .Item("Patient ID").ToString
                Txt_PatientID.Tag = .Item("Patient ID").ToString
                Cmb_Service.SelectedValue = .Item("Service ID").ToString
                Cmb_ArrivalMode.SelectedValue = .Item("Arrival_Mode").ToString
                Cmb_BillingMethod.SelectedValue = .Item("Billing_Method").ToString
                Cmb_CureStatus.SelectedValue = .Item("Cure_Status").ToString
                Cmb_Dept.SelectedValue = .Item("Dep_ID").ToString
                Txt_DrID.Text = .Item("Doc_ID").ToString
                Cmb_PatientType.SelectedValue = .Item("Patient_Type").ToString
                Cmb_Service.SelectedValue = .Item("Service ID").ToString
                Cmb_Status.SelectedValue = .Item("Curr_Status").ToString
                Txt_AccID.Text = .Item("ACC_ID").ToString
                Txt_OpDays.Text = .Item("OP Period Days").ToString
                Txt_AmbulatoryStatus.Text = .Item("Ambulatory Status").ToString

            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub


    Private Sub AssignAppointId(ByVal dtbl As DataTable)
        Try

            Dim dr As DataTableReader = Nothing
            dr = dtbl.CreateDataReader()
            dr.Read()

            With dr
                Txt_AppID.Text = .Item("Apoint_ID").ToString
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub


    Private Sub Clear_Form()
        Try
            Txt_OutPatientID.Tag = ""
            Txt_OutPatientID.Text = ""
            Txt_PatientID.Text = ""
            Txt_PatientID.Tag = ""
            Txt_DrID.Tag = ""

            'Txt_PatientAdd.Text = ""
            Txt_AppID.Text = ""
            'Txt_PatientName.Text = ""
            Txt_OpDays.Text = ""
            Txt_AmbulatoryStatus.Text = ""
            Txt_AccID.Text = ""
            Lbl_Drname.Text = ""
            Txt_DrID.Text = ""
            If Cmb_Service.Items.Count > 0 Then Cmb_Service.SelectedIndex = 0
            'Trancontrol1.Clear_Values()

            REM List box Clear functions
            Tr_Mode = Tran_Mode.New_Mode
            Btn_Save.Enabled = True
            Btn_Delete.Enabled = False
            StrBatch_Id = ""
            For i = 0 To 2
                Int_GenTran_ID(i) = 0
                IntTr_RefNo(i) = 0
                IntPat_Tran_ID(i) = 0
            Next
            Dtp_TranDate.Value = Tran_Date
            Trancontrol1.Clear_Values()
            Trancontrol1.Assign_Values(Assignvalue_Dtbl, 48)
            Txt_OutPatientID.Focus()
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try


    End Sub

    Private Function Validate_Fields() As Boolean
        Try
            If Tr_Mode <> Tran_Mode.New_Mode Then
                If Txt_OutPatientID.Text.Trim = "" Then MessageBox.Show("Invalid OP ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_OutPatientID.Focus() : Exit Function
            End If
            'Assigning Default values
            If IsDate(Dtp_TranDate.Value) = False Then MessageBox.Show("invalid date,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Dtp_TranDate.Focus() : Exit Function
            If Txt_PatientID.Text.Trim = "" Then MessageBox.Show("Invalid Patient ID, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_PatientID.Focus() : Exit Function
            If Txt_DrID.Text.Trim = "" Then MessageBox.Show("Invalid Doctor ID, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_DrID.Focus() : Exit Function
            If Txt_AmbulatoryStatus.Text.Trim = "" Then MessageBox.Show("Invalid Ambulatory Status, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_AmbulatoryStatus.Focus() : Exit Function
            If Val(Txt_OpDays.Text) <= 0 Then MessageBox.Show("Invalid OP Periods, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_OpDays.Focus() : Exit Function
            If Val(Txt_OpDays.Text) > 255 Then MessageBox.Show("OP Days Can't be more than 255,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Txt_OpDays.Focus() : Exit Function
            If Tr_Mode <> Tran_Mode.New_Mode Then
                'If Txt_AppID.Text.Trim = "" Then MessageBox.Show("Invalid Appointment ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_AppID.Focus() : Exit Function
                If Txt_AccID.Text.Trim = "" Then MessageBox.Show("Invalid Account ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_AccID.Focus() : Exit Function
            End If

            Return True
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function

    Public Function Locate_Appointment(ByVal Apoint_ID As Long) As Boolean
        Try
            Dim dtbl As DataTable = Nothing
            Dim dr As DataTableReader = Nothing

            hms_helper = New Hms_Helperimpliments
            'Txt_PatientName.Text = ""
            'Txt_PatientAdd.Text = ""
            Txt_PatientID.Tag = ""
            If hms_helper.Get_AppointMent_Details(dtbl, Apoint_ID) Then
                dr = dtbl.CreateDataReader
                dr.Read()
                With dr
                    Txt_DrID.Text = dr.Item("Doc_ID").ToString
                End With
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)

        End Try
    End Function

    Public Function Locate_Patient(ByVal Patient_ID As String) As Boolean
        Try
            Dim dtbl As DataTable = Nothing
            Dim dr As DataTableReader = Nothing

            hms_helper = New Hms_Helperimpliments
            'Txt_PatientName.Text = ""
            'Txt_PatientAdd.Text = ""
            Txt_PatientID.Tag = ""
            If hms_helper.Get_Patient_Info(dtbl, Patient_ID) Then
                dr = dtbl.CreateDataReader
                dr.Read()
                With dr
                    'Txt_PatientName.Text = dr.Item("Patient_Name").ToString
                    'Txt_PatientAdd.Text = dr.Item("Patient_Addr").ToString
                    'Txt_PatientID.Tag = Patient_ID
                End With

                'Locating Images if available
                'Call ShowImageviewer(Me, Patient_ID, Customer_Type.Employee)
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function

    Public Function Locate_Values(ByVal OPD_ID As String) As Boolean
        Try
            Dim dtbl As DataTable = Nothing
            Dim dr As DataTableReader = Nothing

            OutPatient_BL = New OutPatient_BL_Cls
            dtbl = Nothing
            Call Clear_Form()

            Txt_OutPatientID.Text = OPD_ID

            'Retreiving Refer Doctor Details and Assign the values to respective controls
            If OutPatient_BL.Get_OutPatient_Details(dtbl, OPD_ID) Then
                Return Assigntocontrols(dtbl)
                Call ShowImageviewer(Me, Txt_PatientID.Text, Customer_Type.Patient)
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Assigntocontrols(ByVal D_Table As DataTable) As Boolean
        Try

            Dr = D_Table.CreateDataReader()
            Dr.Read()
            With Dr

                Txt_OutPatientID.Text = .Item("OPD_ID").ToString
                Txt_OutPatientID.Tag = .Item("OPD_ID").ToString
                Txt_PatientID.Text = .Item("Patient ID").ToString
                Txt_PatientID.Tag = .Item("Patient ID").ToString
                Txt_AppID.Text = .Item("Appoint ID").ToString
                Cmb_Service.SelectedValue = .Item("Service ID").ToString
                Cmb_ArrivalMode.SelectedValue = .Item("Arrival_Mode").ToString
                Cmb_BillingMethod.SelectedValue = .Item("Billing_Method").ToString
                Cmb_CureStatus.SelectedValue = .Item("Cure_Status").ToString
                Cmb_Dept.SelectedValue = .Item("Dep_ID").ToString
                Txt_DrID.Text = .Item("Doc_ID").ToString
                Cmb_PatientType.SelectedValue = .Item("Patient_Type").ToString
                Cmb_Status.SelectedValue = .Item("Curr_Status").ToString
                Txt_AccID.Text = .Item("ACC_ID").ToString
                Txt_OpDays.Text = .Item("OP Period Days").ToString
                Txt_AmbulatoryStatus.Text = .Item("Ambulatory Status").ToString
                StrBatch_Id = .Item("Tran_BatchID").ToString
                'Locate patient details 
                'If Locate_Patient(Txt_PatientID.Text.Trim) Then

                'End If
            End With

            Return True
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        Finally
            D_Table = Nothing
        End Try
    End Function

    Private Function Fill_Trancontrol() As Boolean
        Try
            Dim dtbl As DataTable = Nothing
            Dim Gridsorce_Dtbl As New DataTable


            Dim Drow, Amt_Drow As DataRow
            Dim Paymentmodesource_Dtbl As DataTable = Nothing

            With Gridsorce_Dtbl
                .Columns.Add("Particulars")
                .Columns.Add("Acc_Code")
                .Columns.Add("Exp_Subtype")
                .Columns.Add("Def_Trantype")
                .Columns.Add("Editable")
                .Columns.Add("Charge_Calctype")
                .Columns.Add("Percentage_Of")
                .Columns.Add("Percentage")

            End With

            With Assignvalue_Dtbl
                .Columns.Add("Exp_Subtype")
                .Columns.Add("Amount")
            End With


            If Not hms_helper.Get_ExpenseCharges(dtbl, 1, Tran_Date) Then Return False
            For i = 0 To dtbl.Rows.Count - 1
                Drow = Gridsorce_Dtbl.NewRow()
                Drow("Particulars") = dtbl.Rows(i).Item("Particulars").ToString
                Drow("Acc_Code") = dtbl.Rows(i).Item("Exp_Acc_Code").ToString
                Drow("Exp_Subtype") = dtbl.Rows(i).Item("Exp_Subtype").ToString

                Drow("Def_Trantype") = "C"
                Drow("Editable") = "Y"
                Drow("Charge_Calctype") = dtbl.Rows(i).Item("Charge_Calctype").ToString
                Drow("Percentage_Of") = dtbl.Rows(i).Item("Percentage_Of").ToString
                Drow("Percentage") = dtbl.Rows(i).Item("Exp_Amount").ToString



                Gridsorce_Dtbl.Rows.Add(Drow)

                Amt_Drow = Assignvalue_Dtbl.NewRow
                Amt_Drow("Exp_Subtype") = dtbl.Rows(i).Item("Exp_Subtype").ToString
                Amt_Drow("Amount") = dtbl.Rows(i).Item("Exp_Amount").ToString
                Assignvalue_Dtbl.Rows.Add(Amt_Drow)
            Next

            If hms_helper.Get_Gendata(Paymentmodesource_Dtbl, Gendatatype.Payment_Mode) Then
                If Trancontrol1.Set_Tranenvironment(Gridsorce_Dtbl, Paymentmodesource_Dtbl) Then
                    Trancontrol1.Assign_Values(Assignvalue_Dtbl, 48)
                    Trancontrol1.Amount_Editable = True
                End If
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function

    Private Function Get_AccountsTran() As Boolean
        Try
            Dim dtbl As DataTable = Nothing
            Dim ExpName_Dtbl As DataTable = Nothing
            Dim Gridsorce_Dtbl As New DataTable
            Dim Assignvalue_Dtbl As New DataTable
            Dim i As Integer
            Dim Drow, Amt_Drow As DataRow
            Dim Paymentmodesource_Dtbl As DataTable = Nothing
            Dim PayMode As Integer


            With Assignvalue_Dtbl
                .Columns.Add("Exp_Subtype")
                .Columns.Add("Amount")
            End With

            If Not hms_helper.Get_Gentranaction(dtbl, StrBatch_Id, Tran_Date, Branch_Code) Then Return False

            For i = 0 To dtbl.Rows.Count - 1
                Drow = Gridsorce_Dtbl.NewRow()
                Gridsorce_Dtbl.Rows.Add(Drow)
                Amt_Drow = Assignvalue_Dtbl.NewRow
                Amt_Drow("Exp_Subtype") = dtbl.Rows(i).Item("Exp_Subtype").ToString
                Amt_Drow("Amount") = dtbl.Rows(i).Item("Tr_Amount").ToString
                Assignvalue_Dtbl.Rows.Add(Amt_Drow)
                If i = 0 Then PayMode = dtbl.Rows(i).Item("Tr_Pay_Mode").ToString
                Int_GenTran_ID(i) = dtbl.Rows(i).Item("Tran_ID").ToString
                IntTr_RefNo(i) = dtbl.Rows(i).Item("Tr_RefNo").ToString
            Next

            Trancontrol1.Assign_Values(Assignvalue_Dtbl, 48)
            Trancontrol1.Amount_Editable = True

            Trancontrol1.Cmb_Paymode.SelectedValue = PayMode
            If hms_helper.Get_Patient_Transaction(dtbl, StrBatch_Id, Branch_Code) > 0 Then
                For i = 0 To dtbl.Rows.Count - 1
                    IntPat_Tran_ID(i) = dtbl.Rows(i).Item("Tran_ID").ToString
                Next
            End If


        Catch ex As Exception
            MessageBox.Show(ex.Message, ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function
    
    Private Sub RegFeeCollecting(ByVal Gen_BatId As String)
        Try
            Dim Dr As DataTableReader = Nothing
            Dim Dtbl As DataTable = Nothing
            Dim SaveFlg As Integer = 0

            Gen_Tran_BL = New Gen_Transaction_BL_Cls
            hms_helper = New Hms_Helperimpliments

            'Call Hide_GridContorls()

            'Validating DataGridView controls
            If Not Validate_GridView() Then Exit Sub

            With Gen_Tran_BL

                .Tran_BatchID = Gen_BatId
                .Tr_Date = Dtp_TranDate.Value
                .Tr_Narration = "Registration Fee"
                .Tr_Pay_Mode = Trancontrol1.Cmb_Paymode.SelectedValue
                .Tr_Type = "R"

                If Tr_Mode = Tran_Mode.New_Mode Then

                    If Gen_Tran_BL.Get_Maxmimum_BatchNo_GenTran(Dtbl) Then
                        Dr = Dtbl.CreateDataReader
                        Dr.Read()
                        Gen_Tran_BL.Tran_BatchID = Dr.GetValue(0).ToString.Trim
                        Gen_BatId = Dr.GetValue(0).ToString.Trim
                        If Gen_BatId = "" Then Gen_Tran_BL.Tran_BatchID = "0000000001" _
                          : Gen_BatId = "0000000001"
                        IntRefNo = Val(Gen_BatId)
                        StrBatch_Id = Gen_BatId
                    End If
                    Gen_Tran_BL.Tr_RefNo = "OP"
                End If

                Dtbl = Nothing

                'Getting Transaction one by one saving 
                With Trancontrol1.Tran_Grid

                    For i = 0 To .Rows.Count - 1

                        If Val(.Rows(i).Cells("Amount").Value) > 0 Then

                            If Tr_Mode = Tran_Mode.Edit_Mode Then
                                Gen_Tran_BL.Tran_ID = Int_GenTran_ID(i)
                                Gen_Tran_BL.Tr_RefNo = IntTr_RefNo(i)
                            End If


                        End If

                        'Cmb_AccountHead.Text = .Rows(i).Cells("AccountHead").Value.ToString
                        Gen_Tran_BL.Acc_Code = Trancontrol1.Tran_Grid.Rows(i).Cells("Acc_Code").Value.ToString 'Cmb_AccountHead.SelectedValue
                        Gen_Tran_BL.Tr_Remarks = "Registration Fee" '.Rows(i).Cells("Narration").Value.ToString
                        Gen_Tran_BL.Tr_Amount = .Rows(i).Cells("Amount").Value.ToString
                        Gen_Tran_BL.Exp_ID = 1

                        Gen_Tran_BL.Exp_Subtype = Trancontrol1.Tran_Grid.Rows(i).Cells("Exp_Subtype").Value.ToString
                        If Gen_Tran_BL.Save_Gen_Transaction(Dtbl, Tr_Mode, Gen_BatId) Then
                            SaveFlg = 1
                        Else
                            Gen_Tran_BL.Del_Gen_Transaction(StrBatch_Id, Dtp_TranDate.Value)
                            SaveFlg = 0
                            Exit For
                        End If



                    Next

                End With

                Dtbl = Nothing
                If SaveFlg = 1 Then
                    'MessageBox.Show("General Transaction Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    'Call Locate_Values(Txt_BatchID.Text.Trim)
                    ' Call Get_BatchID(Dtbl)
                Else
                    MessageBox.Show("General Transaction Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If

            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Function Validate_GridView() As Boolean
        Try
            Dim i As Integer
            With Trancontrol1.Tran_Grid
                For i = 0 To Trancontrol1.Tran_Grid.Rows.Count - 1
                    'MsgBox(i)

                    If Val(.Rows(i).Cells("Amount").Value) > 0 Then
                        If Trancontrol1.Tran_Grid.Rows(i).Cells("Particulars").Value.ToString = "" Then _
                        MessageBox.Show("Invalid Account Head, Please Check", Product_Name, _
                        MessageBoxButtons.OK, MessageBoxIcon.Error) : .Rows(i).Cells("AccountHead").Selected = True : Trancontrol1.Focus() : Return False

                    End If

                Next
            End With

            Return True
        Catch ex As Exception
            MessageBox.Show("Memmorry")
            MessageBox.Show(ex.Message)
            MessageBox.Show("Memmorry")

            Return False
        End Try
    End Function

#End Region

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try
            Dim Dr As DataTableReader = Nothing
            Dim Dtbl As DataTable = Nothing

            OutPatient_BL = New OutPatient_BL_Cls
            Appointment_BL = New Appointment_BL_Cls
            Patient_Tran_BL = New Patient_Transaction_BL_Cls

            'Validating Data controls
            If Not Validate_Fields() Then Exit Sub
            If Not Validate_GridView() Then Exit Sub


            With OutPatient_BL

                .OPD_ID = IIf(Tr_Mode <> Tran_Mode.New_Mode, Txt_OutPatientID.Text.Trim, 0)
                .Tr_Date = Dtp_TranDate.Value
                .Appoint_ID = Val(Txt_AppID.Text)
                .Patient_ID = Txt_PatientID.Text.Trim
                .Op_Perioddays = Val(Txt_OpDays.Text)
                .Service_ID = Cmb_Service.SelectedValue
                '.Dep_ID = Cmb_Dept.SelectedValue
                .Doc_ID = Txt_DrID.Text.Trim
                .Arrival_Mode = Cmb_ArrivalMode.SelectedValue
                .Ambulatory_Status = Txt_AmbulatoryStatus.Text.Trim
                .Billing_Method = Cmb_BillingMethod.SelectedValue
                .Patient_Type = Cmb_PatientType.SelectedValue
                .Curr_Status = Cmb_Status.SelectedValue
                .Cure_Status = Cmb_CureStatus.SelectedValue
                .ACC_ID = Txt_AccID.Text.Trim
                If StrBatch_Id = "" Then
                    .Tran_BatchID = "Nil"
                Else
                    .Tran_BatchID = StrBatch_Id
                End If

                '.Emp_ID = Txt_PatientID.Text.Trim
                '.Doc_Catagory = Cmb_Service.SelectedValue

                Dtbl = Nothing
                'If OutPatient_BL.Save_OutPatient_Details(Dtbl, Tr_Mode, IIf(Tr_Mode <> Tran_Mode.New_Mode, Txt_OutPatientID.Text.Trim, 0)) Then

                '    'Registration FEE Collecting , inserting in to Gen_Transaction table ==============================================================
                '    Call RegFeeCollecting(StrBatch_Id)
                '    'Registration FEE Collecting , inserting in to Gen_Transaction table ==============================================================

                '    'Updating OP Master by general Voucher batch ID'
                'Dr = Dtbl.CreateDataReader()
                '    Dr.Read()

                '    With Dr
                '        Txt_OutPatientID.Text = .Item("OPD_ID").ToString
                '        Txt_AccID.Text = .Item("ACC_ID").ToString
                '    End With

                '    OutPatient_BL = New OutPatient_BL_Cls
                '    If OutPatient_BL.Update_OP_Batch(Txt_OutPatientID.Text.Trim, StrBatch_Id) Then
                '    End If


                '    MessageBox.Show("Out patient Details Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)

                '    If TypeOf mReq_Ctrl Is TextBox And Txt_OutPatientID.Text.Trim <> "" Then
                '        mReq_Ctrl.text = Txt_OutPatientID.Text
                '        If mReq_Ctrl.Visible Then mReq_Ctrl.focus()
                '        Me.Close()
                '    End If

                '    'Call Locate_Patient(Txt_PatientID.Text)
                '    Call Clear_Form()
                '    Txt_OutPatientID.Focus()

                'Else
                '    MessageBox.Show("Out patient Details not Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                'End If

            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try

            Call Clear_Form()
            Txt_OutPatientID.Focus()
            Return
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub Btn_Find1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find1.Click
        Try

            If Txt_PatientID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "10|200|50|"
                'Sql = "SELECT * FROM Patient_Info_Vw"

                Sql = "Select  Name, [Family Name], Address, [SS_No],City,State,Country,Gender,PIN,Phone1,Phone2,Mobile1,Mobile2,[Date of Birth],Age,Religion,[Marital Status],Email,Occupation,Patient_ID from Patient_Info_Short_Vw "

                Call ShowSearchengine(Txt_PatientID, Sql, 19, "Name", Colwidth, , 0)
            End If

            If Txt_PatientID.Text.Trim = "" Then
                Txt_PatientID.Focus() : Exit Sub
            End If

            'Locate patient details 
            If Locate_Patient(Txt_PatientID.Text.Trim) Then
                Dtp_TranDate.Focus()
                Exit Sub
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try

            Trancontrol1.Clear_Values()

            If Tr_Mode = Tran_Mode.New_Mode Then
                If Txt_OutPatientID.Text.Trim = "" Then
                    Dim Sql As String
                    Dim Colwidth As String = ""
                    Colwidth = "145|145|75|50|50|50"
                    Sql = "SELECT   [Patient Name],Doctor,Service,Department,[Status],[Patient Type],Cure_Status, [Tran Date],OPD_ID  FROM OPD_Master_Vw where [Tran Date] = '" & Format(Tran_Date, "MM/dd/yyyy") & "' and Br_Code = " & Branch_Code & " "
                    Call ShowSearchengine(Txt_OutPatientID, Sql, 8, "Patient Name", Colwidth, , 0)
                End If

                If Txt_OutPatientID.Text.Trim = "" Then
                    Txt_OutPatientID.Focus() : Exit Sub
                End If

                'Locate Out Patient details
                If Locate_Values(Txt_OutPatientID.Text.Trim) Then
                    Tr_Mode = Tran_Mode.Edit_Mode
                    Btn_Delete.Enabled = True
                    Txt_OutPatientID.Focus()
                    Call Get_AccountsTran()
                Else
                    MessageBox.Show("OP ID Does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Txt_OutPatientID.Text = ""
                    Txt_OutPatientID.Focus()
                    Exit Sub
                End If
            Else
                Txt_OutPatientID.Focus()
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click
        Try
            'Validating Mandatory fields for Deleting
            If Tr_Mode = Tran_Mode.New_Mode Then
                MessageBox.Show("You have to locate details before deleting the record", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_OutPatientID.Focus()
                Exit Sub
            End If
            If Txt_OutPatientID.Text.Trim = "" Then
                MessageBox.Show("Invalid OP ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_OutPatientID.Focus() : Exit Sub
            End If
            OutPatient_BL = New OutPatient_BL_Cls
            If MessageBox.Show("Are you sure wan't to delete the selected OP Details", Product_Name, MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                If OutPatient_BL.Delete_OutPatient(Txt_OutPatientID.Text.Trim) Then
                    MessageBox.Show("Deleted OP Details successfully", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Call Clear_Form()
                Else
                    MessageBox.Show("You cannot delete this OP details" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_New_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_New.Click
        Try

            Dim cname As String = ""
            Dim Fill_ID As String = ""
            Dim i_Start As Int16 = InStr(Me.Btn_New.Tag, "|", CompareMethod.Text)
            cname = Mid(Me.Btn_New.Tag, 1, i_Start - 1)
            Fill_ID = Mid(Me.Btn_New.Tag, i_Start + 1, Len(Me.Btn_New.Tag))
            Dim ctr As Object
            ctr = DirectCast(Me.Controls(cname), ComboBox)
            With Generaldatasave_Frm
                .Point_Frm = Get_GendatasaveformPosition(Me, ctr)
                .Data_CatID = Fill_ID
                .Req_Ctrl = ctr
                .ShowDialog()
            End With

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_DoctorID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_OutPatientID.KeyDown
        If e.KeyCode = Keys.F2 Then Btn_Find_Click(sender, e)
    End Sub

    Private Sub Txt_DoctorID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_OutPatientID.TextChanged
        If Txt_OutPatientID.Text.Trim = "" Then
            Call Clear_Form()
        End If
    End Sub

    Private Sub Txt_OutPatientID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_OutPatientID.Validating
        Try
            If Me.Txt_OutPatientID.Text.Trim <> "" And Me.Txt_OutPatientID.Text <> Me.Txt_OutPatientID.Tag Then
                If Locate_Values(Txt_OutPatientID.Text.Trim) Then
                    Tr_Mode = Tran_Mode.Edit_Mode
                    Btn_Delete.Enabled = True
                    Call Get_AccountsTran()
                Else
                    MessageBox.Show("OP ID does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Txt_OutPatientID.Focus()
                    e.Cancel = True
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub OutPatient_Master_Frm_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If TypeOf mReq_Ctrl Is TextBox And Txt_OutPatientID.Text.Trim <> "" Then
            mReq_Ctrl.text = Txt_OutPatientID.Text
            If mReq_Ctrl.Visible Then mReq_Ctrl.focus()
        End If
    End Sub

    Private Sub OutPatient_Master_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then SendKeyTab()
    End Sub

    Private Sub OutPatient_Master_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub OutPatient_Master_Frm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            OutPatient_BL = New OutPatient_BL_Cls
            hms_helper = New Hms_Helperimpliments
            'SendKeyTab()
            'SendKeyTab()

            'Gen data filling
            Call hms_helper.Fill_GenData(Cmb_ArrivalMode, Gendatatype.Arrival_Mode)
            Call hms_helper.Fill_GenData(Cmb_BillingMethod, Gendatatype.Billing_Method)
            Call hms_helper.Fill_GenData(Cmb_Dept, Gendatatype.Department)
            Call hms_helper.Fill_GenData(Cmb_CureStatus, Gendatatype.Cure_Status)
            Call hms_helper.Fill_GenData(Cmb_Status, Gendatatype.Patient_Status)
            Call hms_helper.Fill_GenData(Cmb_PatientType, Gendatatype.Patient_Type)
            'Doctor 
            'hms_helper.Fill_Doctors(Cmb_Doctor)
            'servises
            hms_helper.Fill_Service(Cmb_Service)
            Call Fill_Trancontrol()
            Btn_Delete.Enabled = False
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub OutPatient_Master_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        Call KeepRightofme(Me, ImageViewer_Frm)
    End Sub

    Private Sub Txt_PatientID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_PatientID.KeyDown
        If e.KeyCode = Keys.F2 Then
            Btn_Find1_Click(sender, e)
        End If
    End Sub

    Private Sub Txt_PatientID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_PatientID.Validating
        Try
            If Txt_PatientID.Text.Trim <> "" Then
                If Locate_Patient(Txt_PatientID.Text.Trim) Then
                    Dtp_TranDate.Focus()
                    Exit Sub
                Else
                    MessageBox.Show("Patient Id not exists", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Txt_PatientID.Text = ""
                    e.Cancel = True
                    Exit Sub
                End If
            End If

            If Txt_PatientID.Text.Trim = "" Then
                Btn_Find1.Focus()
                Exit Sub
            Else
                Dtp_TranDate.Focus()
                Exit Sub
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_OpDays_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_OpDays.KeyPress
        'If Val(Txt_OpDays.Text) > 255 Then
        '    e.KeyChar = Chr(0)
        '    EP.SetError(Txt_OpDays, "Invalid Op Period Days")
        'End If
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_OpDays.Text, Data_Type.Integer_Type, 12))

    End Sub

    Private Sub Txt_AppID_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_AppID.KeyPress
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_AppID.Text, Data_Type.Integer_Type, 12))
    End Sub

    Private Sub Txt_AmbulatoryStatus_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Txt_AmbulatoryStatus.GotFocus
        Txt_AmbulatoryStatus.SelectionStart = Len(Txt_AmbulatoryStatus.Text)
    End Sub

    Private Sub Cmb_Dept_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cmb_Dept.GotFocus
        Btn_New.Visible = True
        Me.Btn_New.Location = Get_Newgendatabuttonposition(Cmb_Dept)
        Me.Btn_New.Tag = "Cmb_Dept|" & Gendatatype.Department
    End Sub

    Private Sub Cmb_ArrivalMode_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cmb_ArrivalMode.GotFocus
        Btn_New.Visible = True
        Me.Btn_New.Location = Get_Newgendatabuttonposition(Cmb_ArrivalMode)
        Me.Btn_New.Tag = "Cmb_ArrivalMode|" & Gendatatype.Arrival_Mode
    End Sub

    Private Sub Cmb_BillingMethod_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_BillingMethod.SelectedIndexChanged
        Btn_New.Visible = True
        Me.Btn_New.Location = Get_Newgendatabuttonposition(Cmb_BillingMethod)
        Me.Btn_New.Tag = "Cmb_BillingMethod|" & Gendatatype.Billing_Method
    End Sub

    Private Sub Cmb_CureStatus_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cmb_CureStatus.GotFocus
        Btn_New.Visible = True
        Me.Btn_New.Location = Get_Newgendatabuttonposition(Cmb_CureStatus)
        Me.Btn_New.Tag = "Cmb_CureStatus|" & Gendatatype.Cure_Status
    End Sub

    Private Sub Cmb_Status_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cmb_Status.GotFocus
        Btn_New.Visible = True
        Me.Btn_New.Location = Get_Newgendatabuttonposition(Cmb_Status)
        Me.Btn_New.Tag = "Cmb_Status|" & Gendatatype.Patient_Status
    End Sub

    Private Sub Cmb_PatientType_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cmb_PatientType.GotFocus
        Btn_New.Visible = True
        Me.Btn_New.Location = Get_Newgendatabuttonposition(Cmb_PatientType)
        Me.Btn_New.Tag = "Cmb_PatientType|" & Gendatatype.Patient_Type
    End Sub

    Private Sub Txt_AppID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_AppID.Validating
        Try
            If Tr_Mode = Tran_Mode.New_Mode Then
                If Val(Txt_AppID.Text) > 0 Then
                    If Locate_Appointment(Txt_AppID.Text) Then
                        e.Cancel = False
                    Else
                        MessageBox.Show("Invalid Appointment Id", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                        e.Cancel = True
                    End If
                End If
            End If
            'If Txt_AppID.Text.Trim = "" Then
            '    Btn_Find_AppID.Focus()
            '    Exit Sub
            'Else
            '    Txt_PatientID.Focus()
            '    Exit Sub
            'End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public WriteOnly Property Req_Ctrl() As Object
        Set(ByVal Value As Object)
            mReq_Ctrl = Value
        End Set
    End Property

    Private Sub Txt_PatientID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_PatientID.TextChanged
        Try
            With Patient_Info1
                .Viewmoreform_Name = "Patient_InfoSheet_Frm"
                .MDIform_Name = Me.MdiParent
                If Txt_PatientID.Text.Trim <> "" Then .Patient_ID = Txt_PatientID.Text.Trim
            End With

            With Imageviewer1
                .CUST_TYPE = Customer_Type.Patient
                .CUST_ID = Txt_PatientID.Text
            End With

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Cmb_Doctor_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs)
        Call Fill_Trancontrol()
    End Sub

    Private Sub Btn_FindDr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_FindDr.Click
        Try
            If Txt_DrID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "150|75|75|100|125|"
                Sql = "SELECT  Name,Qualification,Category,Designation,Address,[Email-ID],[Phone 1],[Phone 2],[Mobile 1],[Mobile 2],DoctorID FROM Doctormaster_Vw"
                Call ShowSearchengine(Txt_DrID, Sql, 10, "Name", Colwidth, , 0)
            End If

            If Txt_DrID.Text.Trim = "" Then
                Txt_DrID.Focus() : Exit Sub
            End If
            If GET_DoctorName(Txt_DrID.Text.Trim) Then
                Cmb_Service.Focus()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_DrID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_DrID.KeyDown
        If e.KeyCode = Keys.F2 Then
            Btn_FindDr_Click(sender, e)
        End If
    End Sub

    Private Sub Txt_DrID_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_DrID.KeyPress
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_DrID.Text, Data_Type.Integer_Type, 12))
    End Sub

    Private Sub Txt_DrID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_DrID.Validating
        Try
            If Me.Txt_DrID.Text.Trim <> "" And Me.Txt_DrID.Text.Trim <> Me.Txt_DrID.Tag Then
                If GET_DoctorName(Txt_DrID.Text.Trim) Then
                    e.Cancel = False
                Else
                    MessageBox.Show("Invalid Doctor", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Txt_DrID.Text = ""
                    e.Cancel = True
                End If
            Else
                If Txt_DrID.Text = "" Then
                    Btn_FindDr.Focus()
                Else
                    Cmb_Service.Focus()
                End If

            End If

        Catch ex As Exception   
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_DrID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_DrID.TextChanged
        Try
            Txt_DrID.Tag = ""
            If Txt_DrID.Text.Trim <> "" Then
                If GET_DoctorName(Txt_DrID.Text.Trim) Then

                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub Txt_OpDays_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_OpDays.TextChanged
        Lbl_OPValidDays.Text = DateAdd(DateInterval.Day, Val(Txt_OpDays.Text), Dtp_TranDate.Value)
    End Sub

    Private Sub Btn_NewPatient_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_NewPatient.Click
        Try
            With PatientInfo_Short_Frm
                .MdiParent = Me.MdiParent
                .Req_Ctrl = Txt_PatientID
                .Show()
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Find_AppID_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find_AppID.Click

        'Try
        '    If Txt_AppID.Text.Trim = "" Then
        '        Dim Sql As String
        '        Dim Colwidth As String = ""
        '        Colwidth = "200|50|100|"
        '        Sql = "SELECT Visitor_Name, Apoint_Tokenno, Doctor, Apoint_Date, Visitor_Type, Visit_Type, Booked_Mode, Apoint_Status, Apoint_ID "
        '        Sql = Sql + " FROM Appointments_Vw "
        '        Sql = Sql + " WHERE (Apoint_Status <> 'C') AND (Apoint_Date >= '" & Format(Tran_Date, "MM/dd/yyyy") & "')"

        '        Call ShowSearchengine(Txt_AppID, Sql, 8, "Branch Name", Colwidth, , 0)
        '    End If

        '    If Txt_AppID.Text.Trim = "" Then
        '        Txt_AppID.Focus() : Exit Sub
        '    End If

        '    'Locate Appointment details
        '    If Locate_Appointment(Txt_AppID.Text.Trim) Then
        '        Txt_PatientID.Focus()
        '        Exit Sub
        '    End If

        'Catch ex As Exception
        '    MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        'End Try


    End Sub
   
    Private Sub Txt_AppID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_AppID.TextChanged

    End Sub
End Class