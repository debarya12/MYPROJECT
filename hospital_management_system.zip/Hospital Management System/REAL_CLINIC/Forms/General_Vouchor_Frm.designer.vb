﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class General_Vouchor_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(General_Vouchor_Frm))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Uttility = New System.Windows.Forms.Button
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Print = New System.Windows.Forms.Button
        Me.Btn_Delete = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.Panel4 = New System.Windows.Forms.Panel
        Me.Lbl_total = New System.Windows.Forms.Label
        Me.Lbl_Words = New System.Windows.Forms.Label
        Me.Txt_Totalamount = New System.Windows.Forms.TextBox
        Me.Txt_Cash = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Txt_Narration = New System.Windows.Forms.TextBox
        Me.Cmb_PaymentMode = New System.Windows.Forms.ComboBox
        Me.Cmb_AccountHead = New System.Windows.Forms.ComboBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Cmb_TranType = New System.Windows.Forms.ComboBox
        Me.Dgvw_GeneralVouchor = New System.Windows.Forms.DataGridView
        Me.Dtp_Trandate = New System.Windows.Forms.DateTimePicker
        Me.Txt_BatchID = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.Txt_Narr = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Btn_Find = New System.Windows.Forms.Button
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label
        Me.Pnl_Header.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.Panel4.SuspendLayout()
        CType(Me.Dgvw_GeneralVouchor, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Pnl_Tran_mode.SuspendLayout()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = CType(resources.GetObject("Pnl_Header.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Header.Controls.Add(Me.Label1)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(861, 24)
        Me.Pnl_Header.TabIndex = 100
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(3, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(196, 19)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "G e n e r a l   V o u c h e r"
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Uttility)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Print)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Delete)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(515, 417)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(342, 35)
        Me.Pnl_Common_Btn.TabIndex = 47
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(279, 3)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 10
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Uttility
        '
        Me.Btn_Uttility.BackgroundImage = CType(resources.GetObject("Btn_Uttility.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Uttility.CausesValidation = False
        Me.Btn_Uttility.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Uttility.Location = New System.Drawing.Point(224, 3)
        Me.Btn_Uttility.Name = "Btn_Uttility"
        Me.Btn_Uttility.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Uttility.TabIndex = 9
        Me.Btn_Uttility.Text = "&Uttility"
        Me.Btn_Uttility.UseVisualStyleBackColor = True
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(169, 3)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear.TabIndex = 8
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Print
        '
        Me.Btn_Print.BackgroundImage = CType(resources.GetObject("Btn_Print.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Print.CausesValidation = False
        Me.Btn_Print.Location = New System.Drawing.Point(114, 3)
        Me.Btn_Print.Name = "Btn_Print"
        Me.Btn_Print.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Print.TabIndex = 7
        Me.Btn_Print.Text = "&Print"
        Me.Btn_Print.UseVisualStyleBackColor = True
        '
        'Btn_Delete
        '
        Me.Btn_Delete.BackgroundImage = CType(resources.GetObject("Btn_Delete.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Delete.Enabled = False
        Me.Btn_Delete.Location = New System.Drawing.Point(59, 3)
        Me.Btn_Delete.Name = "Btn_Delete"
        Me.Btn_Delete.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Delete.TabIndex = 6
        Me.Btn_Delete.Text = "&Cancel"
        Me.Btn_Delete.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = CType(resources.GetObject("Btn_Save.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(4, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save.TabIndex = 5
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Panel4.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel4.Controls.Add(Me.Lbl_total)
        Me.Panel4.Controls.Add(Me.Lbl_Words)
        Me.Panel4.Controls.Add(Me.Txt_Totalamount)
        Me.Panel4.Controls.Add(Me.Txt_Cash)
        Me.Panel4.Controls.Add(Me.Label6)
        Me.Panel4.Controls.Add(Me.Txt_Narration)
        Me.Panel4.Controls.Add(Me.Cmb_PaymentMode)
        Me.Panel4.Controls.Add(Me.Cmb_AccountHead)
        Me.Panel4.Controls.Add(Me.Label5)
        Me.Panel4.Controls.Add(Me.Cmb_TranType)
        Me.Panel4.Controls.Add(Me.Dgvw_GeneralVouchor)
        Me.Panel4.Location = New System.Drawing.Point(157, 85)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(700, 326)
        Me.Panel4.TabIndex = 4
        '
        'Lbl_total
        '
        Me.Lbl_total.AutoSize = True
        Me.Lbl_total.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_total.ForeColor = System.Drawing.Color.Black
        Me.Lbl_total.Location = New System.Drawing.Point(457, 301)
        Me.Lbl_total.Name = "Lbl_total"
        Me.Lbl_total.Size = New System.Drawing.Size(36, 13)
        Me.Lbl_total.TabIndex = 140
        Me.Lbl_total.Text = "Total"
        '
        'Lbl_Words
        '
        Me.Lbl_Words.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Words.ForeColor = System.Drawing.Color.Black
        Me.Lbl_Words.Location = New System.Drawing.Point(7, 300)
        Me.Lbl_Words.Name = "Lbl_Words"
        Me.Lbl_Words.Size = New System.Drawing.Size(444, 14)
        Me.Lbl_Words.TabIndex = 139
        Me.Lbl_Words.Text = """"""
        '
        'Txt_Totalamount
        '
        Me.Txt_Totalamount.BackColor = System.Drawing.Color.White
        Me.Txt_Totalamount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Totalamount.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Totalamount.Location = New System.Drawing.Point(521, 298)
        Me.Txt_Totalamount.MaxLength = 15
        Me.Txt_Totalamount.Name = "Txt_Totalamount"
        Me.Txt_Totalamount.Size = New System.Drawing.Size(173, 21)
        Me.Txt_Totalamount.TabIndex = 128
        Me.Txt_Totalamount.TabStop = False
        Me.Txt_Totalamount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Txt_Cash
        '
        Me.Txt_Cash.BackColor = System.Drawing.Color.White
        Me.Txt_Cash.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Cash.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Cash.Location = New System.Drawing.Point(429, 200)
        Me.Txt_Cash.MaxLength = 100
        Me.Txt_Cash.Name = "Txt_Cash"
        Me.Txt_Cash.Size = New System.Drawing.Size(137, 21)
        Me.Txt_Cash.TabIndex = 8
        Me.Txt_Cash.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.Txt_Cash.Visible = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(270, 16)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(92, 13)
        Me.Label6.TabIndex = 138
        Me.Label6.Text = "Payment Mode"
        '
        'Txt_Narration
        '
        Me.Txt_Narration.BackColor = System.Drawing.Color.White
        Me.Txt_Narration.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Narration.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Narration.Location = New System.Drawing.Point(455, 77)
        Me.Txt_Narration.MaxLength = 100
        Me.Txt_Narration.Name = "Txt_Narration"
        Me.Txt_Narration.Size = New System.Drawing.Size(137, 21)
        Me.Txt_Narration.TabIndex = 7
        Me.Txt_Narration.Visible = False
        '
        'Cmb_PaymentMode
        '
        Me.Cmb_PaymentMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_PaymentMode.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_PaymentMode.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_PaymentMode.FormattingEnabled = True
        Me.Cmb_PaymentMode.ItemHeight = 13
        Me.Cmb_PaymentMode.Location = New System.Drawing.Point(365, 11)
        Me.Cmb_PaymentMode.Name = "Cmb_PaymentMode"
        Me.Cmb_PaymentMode.Size = New System.Drawing.Size(149, 21)
        Me.Cmb_PaymentMode.TabIndex = 4
        '
        'Cmb_AccountHead
        '
        Me.Cmb_AccountHead.DropDownHeight = 150
        Me.Cmb_AccountHead.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_AccountHead.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_AccountHead.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_AccountHead.FormattingEnabled = True
        Me.Cmb_AccountHead.IntegralHeight = False
        Me.Cmb_AccountHead.ItemHeight = 13
        Me.Cmb_AccountHead.Location = New System.Drawing.Point(382, 146)
        Me.Cmb_AccountHead.Name = "Cmb_AccountHead"
        Me.Cmb_AccountHead.Size = New System.Drawing.Size(231, 21)
        Me.Cmb_AccountHead.TabIndex = 6
        Me.Cmb_AccountHead.Visible = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(7, 16)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(105, 13)
        Me.Label5.TabIndex = 136
        Me.Label5.Text = "Transaction Type"
        '
        'Cmb_TranType
        '
        Me.Cmb_TranType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_TranType.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_TranType.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_TranType.FormattingEnabled = True
        Me.Cmb_TranType.ItemHeight = 13
        Me.Cmb_TranType.Location = New System.Drawing.Point(119, 11)
        Me.Cmb_TranType.Name = "Cmb_TranType"
        Me.Cmb_TranType.Size = New System.Drawing.Size(149, 21)
        Me.Cmb_TranType.TabIndex = 3
        '
        'Dgvw_GeneralVouchor
        '
        Me.Dgvw_GeneralVouchor.AllowUserToAddRows = False
        Me.Dgvw_GeneralVouchor.AllowUserToDeleteRows = False
        Me.Dgvw_GeneralVouchor.AllowUserToResizeColumns = False
        Me.Dgvw_GeneralVouchor.AllowUserToResizeRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(248, Byte), Integer))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.DarkBlue
        Me.Dgvw_GeneralVouchor.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.Dgvw_GeneralVouchor.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(236, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Dgvw_GeneralVouchor.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(75, Byte), Integer), CType(CType(116, Byte), Integer), CType(CType(165, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgvw_GeneralVouchor.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.Dgvw_GeneralVouchor.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Dgvw_GeneralVouchor.Location = New System.Drawing.Point(10, 40)
        Me.Dgvw_GeneralVouchor.Name = "Dgvw_GeneralVouchor"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(179, Byte), Integer))
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgvw_GeneralVouchor.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.Dgvw_GeneralVouchor.RowHeadersVisible = False
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(CType(CType(219, Byte), Integer), CType(CType(227, Byte), Integer), CType(CType(249, Byte), Integer))
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.Color.DarkBlue
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.White
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black
        Me.Dgvw_GeneralVouchor.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.Dgvw_GeneralVouchor.Size = New System.Drawing.Size(683, 252)
        Me.Dgvw_GeneralVouchor.TabIndex = 5
        '
        'Dtp_Trandate
        '
        Me.Dtp_Trandate.CustomFormat = "dd/MM/yyyy"
        Me.Dtp_Trandate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_Trandate.Location = New System.Drawing.Point(562, 30)
        Me.Dtp_Trandate.Name = "Dtp_Trandate"
        Me.Dtp_Trandate.Size = New System.Drawing.Size(109, 21)
        Me.Dtp_Trandate.TabIndex = 128
        '
        'Txt_BatchID
        '
        Me.Txt_BatchID.BackColor = System.Drawing.Color.White
        Me.Txt_BatchID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_BatchID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_BatchID.Location = New System.Drawing.Point(232, 30)
        Me.Txt_BatchID.MaxLength = 10
        Me.Txt_BatchID.Name = "Txt_BatchID"
        Me.Txt_BatchID.Size = New System.Drawing.Size(137, 21)
        Me.Txt_BatchID.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(164, 32)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(55, 13)
        Me.Label2.TabIndex = 130
        Me.Label2.Text = "Batch ID"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(522, 32)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(34, 13)
        Me.Label3.TabIndex = 131
        Me.Label3.Text = "Date"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Left
        Me.PictureBox1.Location = New System.Drawing.Point(0, 24)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(131, 435)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox1.TabIndex = 134
        Me.PictureBox1.TabStop = False
        '
        'Txt_Narr
        '
        Me.Txt_Narr.BackColor = System.Drawing.Color.White
        Me.Txt_Narr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Narr.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Narr.Location = New System.Drawing.Point(232, 58)
        Me.Txt_Narr.MaxLength = 100
        Me.Txt_Narr.Name = "Txt_Narr"
        Me.Txt_Narr.Size = New System.Drawing.Size(439, 21)
        Me.Txt_Narr.TabIndex = 2
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(164, 60)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(60, 13)
        Me.Label7.TabIndex = 140
        Me.Label7.Text = "Narration"
        '
        'Btn_Find
        '
        Me.Btn_Find.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find.BackgroundImage = CType(resources.GetObject("Btn_Find.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find.ForeColor = System.Drawing.Color.White
        Me.Btn_Find.Location = New System.Drawing.Point(375, 30)
        Me.Btn_Find.Name = "Btn_Find"
        Me.Btn_Find.Size = New System.Drawing.Size(29, 21)
        Me.Btn_Find.TabIndex = 1
        Me.Btn_Find.TabStop = False
        Me.Btn_Find.Text = "F2"
        Me.Btn_Find.UseVisualStyleBackColor = False
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(721, 30)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(74, 22)
        Me.Pnl_Tran_mode.TabIndex = 147
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(3, 1)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(68, 16)
        Me.Lbl_Tran_Mode.TabIndex = 0
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'General_Vouchor_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(861, 459)
        Me.Controls.Add(Me.Btn_Find)
        Me.Controls.Add(Me.Pnl_Tran_mode)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Txt_Narr)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Txt_BatchID)
        Me.Controls.Add(Me.Dtp_Trandate)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "General_Vouchor_Frm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        CType(Me.Dgvw_GeneralVouchor, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Pnl_Tran_mode.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Delete As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Dgvw_GeneralVouchor As System.Windows.Forms.DataGridView
    Friend WithEvents Cmb_AccountHead As System.Windows.Forms.ComboBox
    Friend WithEvents Txt_Narration As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Cash As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Totalamount As System.Windows.Forms.TextBox
    Friend WithEvents Dtp_Trandate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Txt_BatchID As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Cmb_TranType As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Cmb_PaymentMode As System.Windows.Forms.ComboBox
    Friend WithEvents Txt_Narr As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Btn_Find As System.Windows.Forms.Button
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Lbl_Words As System.Windows.Forms.Label
    Friend WithEvents Lbl_total As System.Windows.Forms.Label
    Friend WithEvents Btn_Print As System.Windows.Forms.Button
    Friend WithEvents Btn_Uttility As System.Windows.Forms.Button
End Class
