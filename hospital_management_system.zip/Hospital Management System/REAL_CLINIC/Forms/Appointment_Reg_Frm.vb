﻿

Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls
Public Class Appointment_Reg_Frm

#Region " D e c l a r a t i o n s "

    Private hms_helper As HMS_Helper = Nothing
    Private Apoint_Bl As Appointment_BL_Cls
    Private OP_BL As OutPatient_BL_Cls

    Private Timing_Tbl As DataTable = Nothing
    Private T_Dr As DataRow = Nothing

    Dim frm_Heading As String = "A P P O I N T M E N T    R E G  I S T R A T I O N"

#End Region

#Region " E n u m s "

    Public Enum enm_Visitor_Type
        New_Visitor
        Pre_Visitor
        Employee
    End Enum

#End Region

#Region " P r o p e r t i e s "

    'Transaction Mode checking Property
    Private mTr_Mode As Tran_Mode
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_ApointID.BackColor = Cmb_Status.BackColor
                    Me.Txt_ApointID.ReadOnly = False
                    Timer1.Enabled = True
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_ApointID.BackColor = Color.Silver
                    Me.Txt_ApointID.ReadOnly = True
                    Timer1.Enabled = False
            End Select
        End Set
    End Property

    Private _Seldoctor_A_interval As Integer = 0
    Public Property Seldoctor_A_interval() As Integer
        Get
            Return _Seldoctor_A_interval
        End Get
        Set(ByVal value As Integer)
            _Seldoctor_A_interval = value
        End Set
    End Property

    Private _Seldoctor_Offday As String
    Public Property Seldoctor_Offday() As String
        Get
            Return _Seldoctor_Offday
        End Get
        Set(ByVal value As String)
            _Seldoctor_Offday = value
        End Set
    End Property

    Public _Visitortype As enm_Visitor_Type
    Public Property Visitortype() As enm_Visitor_Type
        Get
            Return _Visitortype
        End Get
        Set(ByVal value As enm_Visitor_Type)
            Pnl_Othersdetails.Enabled = False
            Pnl_Patientdetails.Enabled = False
            Pnl_Empdetails.Enabled = False

            _Visitortype = value
            If _Visitortype = enm_Visitor_Type.New_Visitor Then
                Pnl_Othersdetails.Enabled = True
                Pnl_Othersdetails.BringToFront()
                Call Clear_Othervisitordetails()
            ElseIf _Visitortype = enm_Visitor_Type.Pre_Visitor Then
                Pnl_Patientdetails.Enabled = True
                Pnl_Patientdetails.BringToFront()
                Call Clear_Patientdetails()
            ElseIf _Visitortype = enm_Visitor_Type.Employee Then
                Pnl_Empdetails.Enabled = True
                Pnl_Empdetails.BringToFront()
                Call Clear_Empdetails()
            End If
        End Set
    End Property

    Private ReadOnly Property Is_NewCustomer() As Boolean
        Get
            If Me.Visitortype = enm_Visitor_Type.New_Visitor Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property

    Private ReadOnly Property Visitor_ID() As String
        Get
            If Me.Visitortype = enm_Visitor_Type.New_Visitor Then
                Return Txt_Visitor_SSNO.Tag
            ElseIf Me.Visitortype = enm_Visitor_Type.Employee Then
                Return Txt_EmpID.Text.Trim
            ElseIf Me.Visitortype = enm_Visitor_Type.Pre_Visitor Then
                Return Txt_PatientID.Text.Trim
            Else
                Return ""
            End If
        End Get
    End Property

    Private ReadOnly Property Visitor_Name() As String
        Get
            If Me.Visitortype = enm_Visitor_Type.New_Visitor Then
                Return Txt_Visitor_Name.Text
            ElseIf Me.Visitortype = enm_Visitor_Type.Employee Then
                Return Employee_Info1.EmployeeName.Text
            ElseIf Me.Visitortype = enm_Visitor_Type.Pre_Visitor Then
                Return Patient_Info1.PatientName.Text
            Else
                Return ""
            End If
        End Get
    End Property

    Private _App_Service_ID As Integer
    Public Property App_Service_ID() As Integer
        Get
            Return _App_Service_ID
        End Get
        Set(ByVal value As Integer)
            _App_Service_ID = value
            If value = 0 Then Exit Property
            Call Populate_Doctor(value)
        End Set
    End Property

    Private _App_Doctor_ID As Integer
    Public Property App_Doctor_ID() As Integer
        Get
            Return _App_Doctor_ID
        End Get
        Set(ByVal value As Integer)
            _App_Doctor_ID = value
            Call Clear_Grid(False)
            Lbl_Doctordetails.Text = ""
            If value = 0 Then
                Cmb_Timefrom.Text = ""
                Cmb_Timefrom.Items.Clear()
                Cmb_Timeto.Text = ""
                Cmb_Timeto.Items.Clear()
                Lbl_Fromtime.Text = "" : Lbl_Totime.Text = "" : Cmb_Timeto.Text = "" : Lbl_Confirm.Text = "" : Lbl_ApStatus.Text = ""
                Exit Property
            End If

            Call Get_Doctordetails(value)
            Call Show_DocAppointmentchart(value)
        End Set
    End Property

    Private _App_Doctor_name As String
    Public Property App_Doctor_Name() As String
        Get
            Return _App_Doctor_name
        End Get
        Set(ByVal value As String)
            _App_Doctor_name = value
            Lbl_Heading.Text = frm_Heading
            If Not value = "" Then Lbl_Heading.Text = frm_Heading + "  of  " + value
        End Set
    End Property

    Private mReq_Ctrl As Object = Nothing
    Public WriteOnly Property Req_Ctrl() As Object
        Set(ByVal Value As Object)
            mReq_Ctrl = Value
        End Set
    End Property

    Private mIsLoaded As Boolean = False
    Public WriteOnly Property IsLoaded() As Boolean
        Set(ByVal value As Boolean)
            mIsLoaded = value
        End Set
    End Property

    Private _IsValid_OP As Boolean = False
    Private Property IsValid_OP() As Boolean
        Get
            Return _IsValid_OP
        End Get
        Set(ByVal value As Boolean)
            _IsValid_OP = value
        End Set
    End Property

#End Region

#Region " M e t h o d s "

#Region " P o p u l a t e  M e t h o d s "

    Public Sub Populate_Visitortype(ByVal Dtbl As DataTable)
        Try
            If Cmb_Visitortype.Items.Count > 0 Then Return
            If Dtbl Is Nothing Then
                hms_helper = New Hms_Helperimpliments
                Call hms_helper.Get_Gendata(Dtbl, Gendatatype.Visitor_Type)
            End If
            With Cmb_Visitortype
                .DataSource = Nothing
                .DataSource = Dtbl
                .DisplayMember = "Data_Description"
                .ValueMember = "Data_ID"
                .Refresh()
                If .Items.Count > 0 Then .SelectedIndex = 0
            End With

        Catch ex As Exception

        End Try
    End Sub

    Public Sub Populate_Visittype(ByVal Dtbl As DataTable)
        Try
            If Cmb_Visittype.Items.Count > 0 Then Return
            If Dtbl Is Nothing Then
                hms_helper = New Hms_Helperimpliments
                Call hms_helper.Get_Gendata(Dtbl, Gendatatype.Visit_Type)
            End If

            With Cmb_Visittype
                .DataSource = Nothing
                .DataSource = Dtbl
                .DisplayMember = "Data_Description"
                .ValueMember = "Data_ID"
                .Refresh()
                If .Items.Count > 0 Then .SelectedIndex = 0
            End With

        Catch ex As Exception

        End Try
    End Sub

    Public Sub Populate_Bookingtype()
        Try
            With Cmb_Bookingtype
                If .Items.Count > 0 Then Exit Sub
                .Items.Add("Queue")
                .Items.Add("Fixed")
                .SelectedIndex = 0
            End With

        Catch ex As Exception

        End Try
    End Sub

    Public Sub Populate_Bookingmode(ByVal Dtbl As DataTable)
        Try
            If Cmb_Bookmode.Items.Count > 0 Then Return
            If Dtbl Is Nothing Then
                hms_helper = New Hms_Helperimpliments
                Call hms_helper.Get_Gendata(Dtbl, Gendatatype.Booking_Mode)
            End If

            With Cmb_Bookmode
                .DataSource = Nothing
                .DataSource = Dtbl
                .DisplayMember = "Data_Description"
                .ValueMember = "Data_ID"
                .Refresh()
                If .Items.Count > 0 Then .SelectedIndex = 0
            End With

        Catch ex As Exception

        End Try
    End Sub

    Public Sub Populate_Doctor(ByVal ServiceID As Integer)
        Try
            Dim doc_Dtbl As DataTable = Nothing
            Dim btnSomething As ToolStripButton

            hms_helper = New Hms_Helperimpliments

            TlStrp_Doctors.Items.Clear()

            If hms_helper.Get_Doctorswithservices(doc_Dtbl, ServiceID, Tran_Date, Branch_Code) Then

                For i = 0 To doc_Dtbl.Rows.Count - 1
                    btnSomething = New ToolStripButton
                    With btnSomething
                        .Text = doc_Dtbl.Rows(i).Item("Name").ToString

                        .Tag = doc_Dtbl.Rows(i).Item("DoctorID").ToString
                        .Image = My.Resources.Health_care_shield_32
                        .ImageAlign = ContentAlignment.TopCenter
                        .ImageScaling = ToolStripItemImageScaling.None
                        .ForeColor = Color.Maroon
                        .DisplayStyle = ToolStripItemDisplayStyle.ImageAndText
                        .TextImageRelation = TextImageRelation.ImageAboveText
                    End With
                    TlStrp_Doctors.Items.Add(btnSomething)
                Next

            End If

        Catch ex As Exception

        End Try
    End Sub

    Public Sub Populate_Service(ByVal Dtbl As DataTable)
        Try
            If Cmb_Service.Items.Count > 0 Then Return
            If Dtbl Is Nothing Then
                Call hms_helper.Get_ApointmentServices(Dtbl, Branch_Code)
            End If

            With Cmb_Service
                .DataSource = Nothing
                .DataSource = Dtbl
                .DisplayMember = "Service Name"
                .ValueMember = "Service_ID"
                .Refresh()
                If .Items.Count > 0 Then .SelectedIndex = 0

            End With
        Catch ex As Exception

        End Try
    End Sub

    Public Sub Populate_Nationality(ByVal Dtbl As DataTable)
        Try
            If Cmb_Visitor_nationality.Items.Count > 0 Then Return
            If Dtbl Is Nothing Then
                Call hms_helper.Get_Gendata(Dtbl, Gendatatype.Country)
            End If

            With Cmb_Visitor_nationality
                .DataSource = Nothing
                .DataSource = Dtbl
                .DisplayMember = "Data_Description"
                .ValueMember = "Data_ID"
                .Refresh()
                If .Items.Count > 0 Then .SelectedIndex = 0

            End With
        Catch ex As Exception

        End Try

    End Sub

    Public Sub Populate_Gender()
        Try
            With Cmb_visitor_Gender
                If .Items.Count > 0 Then Return
                .Items.Add("Male")
                .Items.Add("Female")

                If .Items.Count > 0 Then .SelectedIndex = 0

            End With
        Catch ex As Exception

        End Try

    End Sub

    Public Sub Populate_Appoinmentstatus()
        Try
            With Cmb_Status
                If .Items.Count > 0 Then .SelectedIndex = 0 : Return
                .Items.Add("Booked")
                .Items.Add("Cancelled")
                .SelectedIndex = 0
            End With

        Catch ex As Exception

        End Try
    End Sub

#End Region

    Private Sub Clear_Empdetails()
        Try
            Txt_EmpID.Text = ""
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Clear_Patientdetails()
        Try
            Txt_PatientID.Text = ""
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Clear_Othervisitordetails()
        Try
            Me.Txt_Visitor_SSNO.Text = ""
            Me.Txt_Visitor_Name.Text = ""
            Me.Txt_Visitor_Addr.Text = ""
            Me.Txt_Visitor_Familyname.Text = ""
            Me.Txt_Visitor_Age.Text = ""
            Me.Txt_Visitor_Phone.Text = ""
            Me.Txt_Visitor_Mobile.Text = ""

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Initialise_Timingdatatable()
        Try
            Timing_Tbl = Nothing
            Timing_Tbl = New DataTable
            With Timing_Tbl
                .Columns.Add("A_BatchID")
                .Columns.Add("Has_Apointment")
                .Columns.Add("T_STime")
                .Columns.Add("T_ETime")
                .Columns.Add("T_Mode")
                .Columns.Add("SlNO", GetType(Int32))
                .Columns("SLNO").AutoIncrement = True
                .Columns("SLNO").AutoIncrementSeed = 1
                .Columns("SLNO").AutoIncrementStep = 1
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Function Locate_Tempcustinfo(ByVal CustID As String) As Boolean
        Try
            If CustID = "" Then Return False
            Apoint_Bl = New Appointment_BL_Cls
            Dim Dtbl As DataTable = Nothing

            Call Clear_Othervisitordetails()

            If Apoint_Bl.Get_AppointMent_TempcustDetails(Dtbl, CustID) Then
                With Dtbl
                    Txt_Visitor_SSNO.Text = .Rows(0).Item("Cust_SSNo").ToString
                    Txt_Visitor_SSNO.Tag = CustID

                    Txt_Visitor_Name.Text = .Rows(0).Item("Cust_Name").ToString
                    Txt_Visitor_Addr.Text = .Rows(0).Item("Cust_Addr").ToString
                    Txt_Visitor_Familyname.Text = .Rows(0).Item("Cust_FamilyName").ToString
                    Txt_Visitor_Phone.Text = .Rows(0).Item("Cust_Phone").ToString
                    Txt_Visitor_Mobile.Text = .Rows(0).Item("Cust_Mobile").ToString
                    Txt_Visitor_Age.Text = .Rows(0).Item("Cust_Age").ToString
                    Cmb_visitor_Gender.SelectedIndex = IIf(.Rows(0).Item("Cust_Gender").ToString = "M", 0, 1)
                    Cmb_Visitor_nationality.SelectedValue = .Rows(0).Item("Cust_Country").ToString

                End With
            End If

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Validate_Fields() As Boolean
        Try
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If

            If Me.Tr_Mode <> Tran_Mode.New_Mode Then
                If Txt_ApointID.Text.Trim = "" Then MessageBox.Show("Please Enter Appointment ID and Proceed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Txt_ApointID.Focus() : Return False
            End If


            If Pnl_PMRID.Visible Then
                If Txt_PMRID.Text.Trim = "" Then MessageBox.Show("Please Enter OP-ID and Proceed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Txt_PMRID.Focus() : Return False
            End If

            If Cmb_Service.Text.Trim = "" Then MessageBox.Show("Please Select Valid Service Name", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Cmb_Service.Focus() : Return False
            If App_Doctor_ID = 0 Then MessageBox.Show("Please Select Valid Doctor Name", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : TlStrp_Doctors.Focus() : Return False
            If Cmb_Timefrom.Text.Trim = "" Then MessageBox.Show("Please Select Valid Appointment Time from the list", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Cmb_Timefrom.Focus() : Return False
            If Cmb_Timeto.Text.Trim = "" Then MessageBox.Show("Please Select Valid Appointment Time from the list", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Cmb_Timeto.Focus() : Return False

            If Cmb_Bookingtype.SelectedIndex = 1 Then
                Apoint_Bl = New Appointment_BL_Cls
                Dim rowSet As DataRow()
                Dim t_dtbl As DataTable = Nothing
                Dim t_Date As Date = Nothing
                t_Date = CDate(Cmb_Timefrom.Text.Trim)
                If Apoint_Bl.Get_DocApointmentchart(t_dtbl, App_Doctor_ID, App_Service_ID, Dtp_Apointdate.Value) Then
                    rowSet = t_dtbl.Select("(Fromtime = '" + Format(t_Date, "01-01-1900 HH:mm:00.000") + "') ")
                    If rowSet.Length = 0 Then
                        MessageBox.Show("Selected Time had an appointment already,Please Select another Time from the list", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Cmb_Timefrom.Focus()
                        Return False
                    End If
                End If
            End If

            If Me.Visitortype = enm_Visitor_Type.New_Visitor Then
                If Txt_Visitor_Name.Text.Trim = "" Then MessageBox.Show("Please Enter Visitor Name and Proceed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Txt_Visitor_Name.Focus() : Return False
                If Txt_Visitor_Addr.Text.Trim = "" And Txt_Visitor_Familyname.Text.Trim = "" Then MessageBox.Show("Atleast one contact details should be supplied", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Txt_Visitor_Addr.Focus() : Return False
                If Txt_Visitor_Phone.Text.Trim = "" And Txt_Visitor_Mobile.Text.Trim = "" Then MessageBox.Show("Atleast one contact no should be supplied", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Txt_Visitor_Mobile.Focus() : Return False
            ElseIf Me.Visitortype = enm_Visitor_Type.Pre_Visitor Then
                If Txt_PatientID.Text = "" Then MessageBox.Show("Please Select Valid Patient ID and Proceed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Txt_PatientID.Focus() : Return False
                If Not Patient_Info1.Is_Valid Then MessageBox.Show("Please Select Valid Patient ID and Proceed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Txt_PatientID.Focus() : Return False
            ElseIf Me.Visitortype = enm_Visitor_Type.Employee Then
                If Txt_EmpID.Text = "" Then MessageBox.Show("Please Select Valid Employee ID and Proceed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Txt_EmpID.Focus() : Return False
                If Not Employee_Info1.Is_Valid Then MessageBox.Show("Please Select Valid Employee ID and Proceed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Txt_EmpID.Focus() : Return False
            End If

            If Val(Txt_Visitor_Age.Text) > 250 Then
                MessageBox.Show("Invalid Age , please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Txt_Visitor_Age.Focus() : Return False
            End If

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Get_TimingBatchID(ByVal Dtbl As DataTable, ByVal Apoint_Time As String) As String
        Try
            Dim rowSet As DataRow()
            Dim D_Row As DataRow

            If Dtbl Is Nothing Then Return True
            rowSet = Dtbl.Select("(T_STime = '" + Apoint_Time.ToString + "')")

            For Each D_Row In rowSet
                Return D_Row.Item("A_BatchID").ToString
            Next
            Return "0"
        Catch ex As Exception
            Return "0"
        End Try
    End Function

    Private Function Get_TimingMode(ByVal Dtbl As DataTable, ByVal Apoint_Time As String) As String
        Try
            Dim rowSet As DataRow()
            Dim D_Row As DataRow

            If Dtbl Is Nothing Then Return True
            rowSet = Dtbl.Select("(T_STime = '" + Apoint_Time.ToString + "')")

            For Each D_Row In rowSet
                Return D_Row.Item("T_Mode").ToString
            Next
            Return ""
        Catch ex As Exception
            Return ""
        End Try
    End Function

    Private Function Save_Tempcustomer(ByVal CustID As String) As Boolean
        Try
            Apoint_Bl = New Appointment_BL_Cls
            Dim r_Dtbl As DataTable = Nothing
            With Apoint_Bl
                .Cust_SSNo = Txt_Visitor_SSNO.Text.Trim
                .Cust_Name = Txt_Visitor_Name.Text.Trim
                .Cust_FamilyName = Txt_Visitor_Familyname.Text.Trim
                .Cust_Addr = Txt_Visitor_Addr.Text.Trim
                .Cust_Gender = Strings.Left(Cmb_visitor_Gender.Text.Trim, 1)
                .Cust_Age = Val(Txt_Visitor_Age.Text.Trim)
                .Cust_Phone = Txt_Visitor_Phone.Text.Trim
                .Cust_Mobile = Txt_Visitor_Mobile.Text.Trim
                .Cust_Country = Cmb_Visitor_nationality.SelectedValue
                .Apoint_CustID = CustID
                If .Save_Appointmenttempcustinfo(r_Dtbl, Me.Tr_Mode) Then
                    Txt_Visitor_SSNO.Tag = r_Dtbl.Rows(0).Item("Apoint_CustID").ToString
                End If
            End With

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Save_Appointment() As Boolean
        Try

            If Is_NewCustomer Then
                If Not Save_Tempcustomer(Txt_Visitor_SSNO.Tag) Then
                    MessageBox.Show("Error Occured While Saving Temp Customer ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
            End If

            Apoint_Bl = New Appointment_BL_Cls
            Dim r_Dtbl As DataTable = Nothing

            With Apoint_Bl
                .Apoint_ID = Val(Txt_ApointID.Text.Trim)
                .Apoint_Date = Dtp_Apointdate.Value
                .Doc_ID = App_Doctor_ID
                .Service_ID = App_Service_ID
                .Apoint_BatchID = Get_TimingBatchID(Timing_Tbl, Format(CDate(Cmb_Timefrom.Text.Trim), "hh:mm tt"))
                .Apoint_AproxStime = Format(CDate(Cmb_Timefrom.Text.Trim), "hh:mm tt")
                .Apoint_AproxEtime = Format(CDate(Cmb_Timeto.Text.Trim), "hh:mm tt")
                .Apoint_Tokenno = Val(Me.Txt_ApointID.Tag)
                .Visitor_Type = Cmb_Visitortype.SelectedValue
                .Visitor_ID = Me.Visitor_ID
                .Visit_Type = Cmb_Visittype.SelectedValue
                .Visitor_Name = Me.Visitor_Name
                .Booking_Type = Strings.Left(Cmb_Bookingtype.Text, 1)
                .Booked_Mode = Cmb_Bookmode.SelectedValue
                .Booked_Date = Tran_Date
                .Booked_Time = Now.ToString("hh:mm:ss tt")
                .Apoint_Status = Strings.Left(Cmb_Status.Text.Trim, 1)
                .Visit_Time = Now.ToString("hh:mm:ss tt")

                If IsValid_OP Then
                    .Apoint_OPID = IIf(Pnl_PMRID.Visible, Txt_PMRID.Text.Trim, "")
                Else
                    .Apoint_OPID = String.Empty
                End If

                If .Save_Appointment(r_Dtbl, Me.Tr_Mode, Val(Txt_ApointID.Text.Trim)) Then

                    If r_Dtbl.Rows(0).Item("Apoint_Status") <> "E" Then

                        '==============================================================================================================
                        'Going with Apointment ID to Respective Form

                        If TypeOf mReq_Ctrl Is TextBox And Txt_ApointID.Text.Trim = "" Then
                            Me.Txt_ApointID.Text = r_Dtbl.Rows(0).Item("Apoint_ID").ToString
                            mReq_Ctrl.text = Txt_ApointID.Text
                            If mReq_Ctrl.Visible Then mReq_Ctrl.focus()
                            Me.Close()

                            Return True
                        End If

                        '==============================================================================================================
                        'Showing Apointment Status

                        Me.Pnl_Message.Visible = True
                        Me.Lbl_MesageTokenno.Text = r_Dtbl.Rows(0).Item("Apoint_Tokenno").ToString
                        Me.Lbl_MesageDate.Text = CDate(r_Dtbl.Rows(0).Item("Apoint_Date").ToString).ToString("dd-MM-yyyy")
                        Me.Lbl_Mesageaproxtime.Text = CDate(r_Dtbl.Rows(0).Item("Apoint_AproxStime").ToString).ToString("hh : mm tt")
                        Me.Lbl_Status.Text = Cmb_Status.Text.ToUpper
                        Me.Lbl_Service.Text = Cmb_Service.Text
                        Me.Lbl_Visitype.Text = Cmb_Visittype.Text
                        Me.Lbl_Doctor.Text = App_Doctor_Name
                        Me.Lbl_Bookingtype.Text = Cmb_Bookingtype.Text

                        If r_Dtbl.Rows(0).Item("Apoint_Status") = "C" Then
                            Me.Lbl_Status.ForeColor = Color.SandyBrown
                        Else
                            Me.Lbl_Status.ForeColor = Color.DarkBlue
                        End If
                        Me.Pnl_Message.Visible = True
                        Me.Btn_Save.Enabled = False
                        Me.Btn_Clear.Focus()

                        '==============================================================================================================
                        Return True
                    Else
                        MessageBox.Show("Error Occured While Saving Appointment ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End If
                Else
                    MessageBox.Show("Error Occured While Saving Appointment ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
            End With

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Locate_Values(ByVal ApointID As Long) As Boolean
        Try
            Dim Dtbl As DataTable = Nothing
            Apoint_Bl = New Appointment_BL_Cls

            Call Clear_Form()

            If Not Apoint_Bl.Get_AppointMent_Details(Dtbl, ApointID) Then Return False
            Timer1.Enabled = False
            With Dtbl
                Me.Txt_ApointID.Text = ApointID
                Me.Txt_ApointID.Tag = .Rows(0).Item("Apoint_Tokenno").ToString

                Me.Cmb_Visittype.SelectedValue = .Rows(0).Item("Visit_TypeID").ToString
                If Pnl_PMRID.Visible Then
                    Me.Txt_PMRID.Text = .Rows(0).Item("OPD_ID").ToString
                End If

                Me.Cmb_Visitortype.SelectedValue = .Rows(0).Item("Visitor_TypeID").ToString
                Me.Cmb_Status.SelectedIndex = 0

                If Me.Visitortype = enm_Visitor_Type.Employee Then
                    Txt_EmpID.Text = .Rows(0).Item("Visitor_ID").ToString
                ElseIf Me.Visitortype = enm_Visitor_Type.Pre_Visitor Then
                    Txt_PatientID.Text = .Rows(0).Item("Visitor_ID").ToString
                Else
                    If Not Locate_Tempcustinfo(.Rows(0).Item("Visitor_ID").ToString) Then Return False
                End If

                Cmb_Service.SelectedValue = .Rows(0).Item("Service_ID").ToString

                App_Doctor_ID = .Rows(0).Item("Doc_ID").ToString
                Cmb_Bookingtype.SelectedIndex = IIf(.Rows(0).Item("Booking_Type").ToString = "Q", 0, 1)
                Cmb_Bookmode.SelectedValue = .Rows(0).Item("Booked_ModeID").ToString
                Dtp_Apointdate.Value = CDate(.Rows(0).Item("Apoint_Date").ToString)

                Cmb_Timefrom.Text = Format(CDate(.Rows(0).Item("Apoint_AproxStime").ToString.Trim), " hh : mm tt")
                Cmb_Timeto.Text = Format(CDate(.Rows(0).Item("Apoint_AproxEtime").ToString.Trim), " hh : mm tt")

                '=====================================================================================================
                Pnl_Message.Visible = True
                Lbl_MesageTokenno.Text = .Rows(0).Item("Apoint_Tokenno").ToString
                Lbl_MesageDate.Text = CDate(.Rows(0).Item("Apoint_Date").ToString).ToString("dd-MM-yyyy")
                Lbl_Mesageaproxtime.Text = CDate(.Rows(0).Item("Apoint_AproxStime").ToString).ToString("hh : mm tt")
                Me.Lbl_Service.Text = Cmb_Service.Text
                Me.Lbl_Visitype.Text = Cmb_Visittype.Text
                Me.Lbl_Doctor.Text = App_Doctor_Name
                Me.Lbl_Bookingtype.Text = Cmb_Bookingtype.Text

                Lbl_Status.Text = ""

                '=====================================================================================================

            End With
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Sub Clear_Form()
        Try
            Txt_ApointID.Text = ""
            Me.Txt_ApointID.Tag = ""
            Txt_PMRID.Text = ""
            Txt_PMRID.Tag = ""
            Cmb_Status.SelectedValue = 0
            Cmb_Visitortype.SelectedIndex = 0
            Cmb_Bookingtype.SelectedIndex = 0
            Pnl_Booking.Enabled = True
            Pnl_Message.Visible = False
            Lbl_MesageTokenno.Text = ""
            Lbl_MesageDate.Text = ""
            Lbl_Mesageaproxtime.Text = ""

            Me.Lbl_Service.Text = ""
            Me.Lbl_Visitype.Text = ""
            Me.Lbl_Doctor.Text = ""
            Me.Lbl_Bookingtype.Text = ""

            Call Clear_Empdetails()
            Call Clear_Othervisitordetails()
            Call Clear_Patientdetails()

            Cmb_Visitortype.Enabled = True

            'Call Refresh_Apointmentchart(App_Doctor_ID, App_Service_ID, Dtp_Apointdate.Value)
            Me.IsValid_OP = False
            Me.Tr_Mode = Tran_Mode.New_Mode
            Me.Btn_Save.Enabled = True

        Catch ex As Exception

        End Try
    End Sub

    Public Sub Show_DocAppointmentchart(ByVal selDocID As String)
        Try
            Dim Start_Time, End_Time As Date
            Dim A_Interval As Double = 0
            Dim Offday As String = ""
            Dim Timings_Dtbl As DataTable = Nothing

            If Not hms_helper.Get_DoctorsDutytimings(Timings_Dtbl, selDocID, Tran_Date) Then
                MessageBox.Show("Selected Doctors Duty Timings not available,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return
            End If

            'Assign Paramater Values
            Start_Time = Timings_Dtbl.Rows(0).Item("D_DutyStarttime").ToString
            End_Time = Timings_Dtbl.Rows(0).Item("D_DutyEndtime").ToString

            A_Interval = Timings_Dtbl.Rows(0).Item("D_Appointmentinterval").ToString
            Seldoctor_A_interval = A_Interval

            Offday = Timings_Dtbl.Rows(0).Item("D_OffDay").ToString
            Seldoctor_Offday = Offday

            If Not Set_BlankGrid(Start_Time, End_Time, A_Interval) Then
                Return
            End If

            Timer1.Enabled = True
            Call Timer1_Tick(Nothing, Nothing)

        Catch ex As Exception

        End Try
    End Sub

    Private Function Set_BlankGrid(ByVal Start_Time As Date, _
                               ByVal End_Time As Date, _
                               ByVal A_Interval As Double) As Boolean
        Try
            With Dgrd_Appointment
                .RowCount = 0
                'End_Time = End_Time.AddMinutes(A_Interval * -1)
                While Start_Time <= End_Time
                    .Rows.Add()
                    .Rows(.Rows.Count - 1).Cells("Time").Value = Format(Start_Time, " hh : mm tt")
                    '.Rows(i).Cells(k).Style.BackColor = Color.FromArgb(138, 162, 187)
                    Start_Time = Start_Time.AddMinutes(A_Interval)

                End While
                .Invalidate()
            End With
            Return True
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function

    Private Sub Clear_Grid(ByVal Isdata As Boolean)
        Try
            With Dgrd_Appointment
                If Not Isdata Then
                    .RowCount = 0
                Else
                    For i = 0 To .RowCount - 1
                        .Rows(i).Cells(1).Value = ""
                        .Rows(i).Cells(1).Tag = ""
                        .Rows(i).Cells(1).Style.BackColor = Color.FromArgb(138, 162, 187)
                    Next
                    .Invalidate()
                End If

            End With
        Catch ex As Exception

        End Try
    End Sub

    Public Sub Refresh_Apointmentchart(ByVal DocID As Integer, _
                                        ByVal ServiceID As Integer, _
                                        ByVal Demand_Date As Date)
        Try
            Apoint_Bl = New Appointment_BL_Cls
            Dim A_Dtbl As DataTable = Nothing
            Dim A_Time As Date
            Dim SelRow As DataGridViewRow = Nothing
            Dim Has_Apointment, A_ApointID, A_BatchID, A_Details As String
            Dim frmtime, Totime As Date

            Cmb_Timefrom.Text = ""
            Cmb_Timefrom.Items.Clear()
            Cmb_Timeto.Text = ""
            Cmb_Timeto.Items.Clear()



            Lbl_Fromtime.Text = "" : Lbl_Totime.Text = "" : Cmb_Timeto.Text = "" : Lbl_Confirm.Text = "" : Lbl_ApStatus.Text = ""
            If Seldoctor_Offday Is Nothing Then Return

            If Strings.Left(Dtp_Apointdate.Value.ToString("dddd").ToUpper, 3) = Seldoctor_Offday.ToUpper Then
                MessageBox.Show("This Date is Marked as OFF DAY for this Doctor", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return
            End If

            If Apoint_Bl.Get_DocApointmentchart(A_Dtbl, DocID, ServiceID, Demand_Date) Then


                With Dgrd_Appointment

                    Call Initialise_Timingdatatable()

                    For i = 0 To A_Dtbl.Rows.Count - 1
                        '==========================================================================================================================
                        'First Fill the Available Timings'
                        '==========================================================================================================================
                        'Populating Timing Table
                        T_Dr = Timing_Tbl.NewRow
                        T_Dr.Item("A_BatchID") = A_Dtbl.Rows(i).Item("A_BatchID").ToString
                        T_Dr.Item("Has_Apointment") = A_Dtbl.Rows(i).Item("Has_Apointment").ToString
                        T_Dr.Item("T_STime") = Format(CDate(A_Dtbl.Rows(i).Item("Fromtime").ToString), "hh:mm tt")
                        T_Dr.Item("T_ETime") = Format(CDate(A_Dtbl.Rows(i).Item("Totime").ToString), "hh:mm tt")
                        T_Dr.Item("T_Mode") = A_Dtbl.Rows(i).Item("A_Timemode").ToString
                        Timing_Tbl.Rows.Add(T_Dr)
                        '==========================================================================================================================
                        If (A_Dtbl.Rows(i).Item("Has_Apointment").ToString = "N" Or A_Dtbl.Rows(i).Item("A_Timemode").ToString = "W") And (A_Dtbl.Rows(i).Item("Reserved").ToString <> "Y") Then
                            frmtime = A_Dtbl.Rows(i).Item("Fromtime").ToString
                            Totime = A_Dtbl.Rows(i).Item("Totime").ToString
                            If Demand_Date = Tran_Date And frmtime.TimeOfDay <= Now.TimeOfDay Then
                                GoTo Skipnext
                            End If
                            Cmb_Timefrom.Items.Add(Format(frmtime, " hh : mm tt"))
                            Cmb_Timeto.Items.Add(Format(Totime, " hh : mm tt"))
                        End If
                        '==========================================================================================================================

Skipnext:
                        '==========================================================================================================================
                        'End of Filling the Available Timings'
                        '==========================================================================================================================

                        Has_Apointment = "" : A_ApointID = "" : A_BatchID = "" : A_Details = ""
                        A_Time = A_Dtbl.Rows(i).Item("Fromtime").ToString

                        SelRow = Nothing
                        SelRow = (From Rows In .Rows.Cast(Of DataGridViewRow)() _
                                    Where Rows.Cells("Time").Value.ToString() = Format(A_Time, " hh : mm tt")).FirstOrDefault
                        If Not IsNothing(SelRow) Then
                            '========================================================================================================
                            Has_Apointment = A_Dtbl.Rows(i).Item("Has_Apointment").ToString
                            A_BatchID = A_Dtbl.Rows(i).Item("A_BatchID").ToString
                            'Setting The Default Color to Active Time Cell
                            SelRow.Cells(1).Style.BackColor = Color.White

                            If A_Dtbl.Rows(i).Item("A_Timemode").ToString = "C" Then    'Confirmed

                                If Has_Apointment = "Y" Then
                                    A_Details = A_Dtbl.Rows(i).Item("Apoint_Tokenno").ToString
                                    A_ApointID = A_Dtbl.Rows(i).Item("Apoint_ID").ToString

                                    'Change the Cell Color as Has Appointment
                                    SelRow.Cells(1).Style.BackColor = Color.PaleVioletRed
                                    SelRow.Cells(1).Style.ForeColor = Color.White
                                Else
                                    Has_Apointment = "N"
                                    A_ApointID = "F"
                                End If

                                If Has_Apointment = "Y" Then A_Details += vbCrLf + A_Dtbl.Rows(i).Item("Visitor_Name").ToString
                                SelRow.Cells(1).Value = A_Details
                                SelRow.Cells(1).Tag = A_ApointID + "|" + A_BatchID

                            ElseIf A_Dtbl.Rows(i).Item("A_Timemode").ToString = "W" Then 'Waiting
                                A_ApointID = "W"
                                SelRow.Cells(1).Style.BackColor = Color.Khaki
                                If Has_Apointment = "Y" Then
                                    A_Details = A_Dtbl.Rows(i).Item("Apoint_Tokenno").ToString
                                End If
                                A_Details += vbCrLf + "Not Confirm"
                                SelRow.Cells(1).Value = A_Details
                                SelRow.Cells(1).Tag = A_ApointID + "|" + A_BatchID
                            End If


                        End If

                    Next
                End With

                If Cmb_Timefrom.Items.Count > 0 Then Cmb_Timefrom.Text = "" : Cmb_Timefrom.Text = Cmb_Timefrom.Items(0).ToString ': Call Display_Timeinfo()
                If Cmb_Timeto.Items.Count > 0 Then Cmb_Timeto.Text = "" : Cmb_Timeto.Text = Cmb_Timeto.Items(0).ToString

            End If


        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try
    End Sub

    Public Sub Select_ApointDoctor(ByVal Doc_ID As String)
        Try
            Dim btn_Doctor As ToolStripButton
            btn_Doctor = New ToolStripButton

            For Each btn_Doctor In TlStrp_Doctors.Items
                If btn_Doctor.Tag = Doc_ID Then
                    btn_Doctor.BackColor = Color.FromArgb(60, 113, 193)
                    btn_Doctor.ForeColor = Color.White
                Else
                    btn_Doctor.BackColor = Color.White
                    btn_Doctor.ForeColor = Color.DarkBlue
                End If

            Next
        Catch ex As Exception

        End Try
    End Sub

    Private Function Get_Doctordetails(ByVal Doc_ID As String) As Boolean
        Try
            Lbl_Doctordetails.Text = ""

            Dim Dtbl As New DataTable
            If hms_helper.Get_Doctordetails(Dtbl, Doc_ID) Then
                Me.App_Doctor_Name = Dtbl.Rows(0).Item("Name").ToString
                Lbl_Doctordetails.Text = Dtbl.Rows(0).Item("Name").ToString.ToUpper
                Lbl_Doctordetails.Text += vbCrLf + Dtbl.Rows(0).Item("Qualification").ToString
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function Set_Environment(ByVal ServiceID As String, _
                                    ByVal Doc_ID As String, _
                                    ByVal Bookingdate As Date, _
                                    Optional ByVal visittype As Int32 = 0, _
                                    Optional ByVal Visitortype As Int32 = 0) As Boolean
        Try
            '=====================================================================
            Call Populate_Appoinmentstatus()
            Call Populate_Visitortype(Nothing)
            Call Populate_Visittype(Nothing)
            Call Populate_Bookingtype()
            Call Populate_Bookingmode(Nothing)
            Call Populate_Nationality(Nothing)
            Call Populate_Service(Nothing)
            Call Populate_Gender()
            '=====================================================================

            Me.Cmb_Service.SelectedValue = ServiceID
            Me.App_Doctor_ID = Doc_ID
            Call Select_ApointDoctor(Doc_ID)
            Me.Cmb_Visittype.SelectedIndex = visittype
            Me.Cmb_Bookingtype.SelectedIndex = 0
            Me.Cmb_Bookmode.SelectedIndex = 0
            Me.Dtp_Apointdate.Value = Bookingdate
            Me.Timer1.Enabled = True
            Call Me.Dtp_Apointdate_ValueChanged(Nothing, Nothing)
            Me.Cmb_Visitortype.SelectedIndex = Visitortype

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Locate_PMR_Masterinfo(ByVal PMR_ID As String, ByVal Br_Code As Integer) As Boolean
        Try
            OP_BL = New OutPatient_BL_Cls

            Dim Dtbl As DataTable = Nothing
            Dim OP_Dtbl As DataTable = Nothing

            Call Clear_Form()

            Txt_PMRID.Text = PMR_ID

            '-----------------  Locate Pateint Medical Record Master info   -------------
            If Not hms_helper.Get_PMR_Masterinfo(Dtbl, PMR_ID, Branch_Code) Then Return False

            With Dtbl

                '-------------------------------------------------------------
                'OP Validation
                If hms_helper.Get_OP_Details(OP_Dtbl, .Rows(0).Item("OP ID").ToString) Then

                    Dim OP_Perioddays As Integer = CInt(OP_Dtbl.Rows(0).Item("OP Period Days").ToString())
                    Dim OP_Regdate As Date = CDate(OP_Dtbl.Rows(0).Item("Tran Date").ToString())

                    If DateAdd(DateInterval.Day, OP_Perioddays, OP_Regdate) < Dtp_Apointdate.Value Then
                        IsValid_OP = False
                    Else
                        IsValid_OP = True
                    End If

                End If
                '-------------------------------------------------------------

                Cmb_Service.SelectedValue = OP_Dtbl.Rows(0).Item("Service ID").ToString
                Me.App_Service_ID = OP_Dtbl.Rows(0).Item("Service ID").ToString
                App_Doctor_ID = .Rows(0).Item("Doc_ID").ToString
                Call Select_ApointDoctor(App_Doctor_ID)

                '-------------------------------------------------------------

                Cmb_Visitortype.SelectedIndex = 1
                Cmb_Visitortype.Enabled = False
                Txt_PatientID.Text = .Rows(0).Item("Patient ID").ToString

                '-------------------------------------------------------------
            End With

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function


#End Region


    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Try

            Call Clear_Form()

            Timer1.Enabled = False

            Me.Close()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Appointment_Reg_Frm_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Try
            If TypeOf mReq_Ctrl Is TextBox And Txt_ApointID.Text.Trim <> "" Then
                mReq_Ctrl.text = Txt_ApointID.Text
                If mReq_Ctrl.Visible Then mReq_Ctrl.focus()
            End If

        Catch ex As Exception

        End Try


    End Sub

    Private Sub Appointment_Reg_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then SendKeyTab()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Appointment_Reg_Frm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            hms_helper = New Hms_Helperimpliments


            If Not mIsLoaded Then
                '=====================================================================
                Call Populate_Appoinmentstatus()
                Call Populate_Visitortype(Nothing)
                Call Populate_Visittype(Nothing)
                Call Populate_Bookingtype()
                Call Populate_Bookingmode(Nothing)
                Call Populate_Nationality(Nothing)
                Call Populate_Service(Nothing)
                Call Populate_Gender()
                '=====================================================================
                Cmb_Visitor_nationality.SelectedValue = Branch_CountryID

                If Cmb_Bookingtype.SelectedIndex = 0 And Me.Tr_Mode = Tran_Mode.New_Mode Then
                    Timer1.Enabled = True
                Else
                    Timer1.Enabled = False
                End If
            End If

            Call SendKeyTab()

            Cmb_Visitortype.Focus()


        Catch ex As Exception

        End Try
    End Sub

    Private Sub Cmb_Visitortype_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cmb_Visitortype.EnabledChanged
        Try
            Txt_PatientID.Enabled = Cmb_Visitortype.Enabled
            Btn_PatientF2.Enabled = Cmb_Visitortype.Enabled
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Cmb_Custtype_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_Visitortype.SelectedIndexChanged
        Try

            Select Case Cmb_Visitortype.SelectedIndex
                Case 1

                    Me.Visitortype = enm_Visitor_Type.Pre_Visitor
                Case 2

                    Me.Visitortype = enm_Visitor_Type.Employee
                Case Else

                    Me.Visitortype = enm_Visitor_Type.New_Visitor
            End Select



        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_EmpID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_EmpID.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then
                Call Btn_EmpF2_Click(Nothing, Nothing)
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_EmpID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_EmpID.TextChanged
        Try
            With Employee_Info1
                .Employee_ID = Txt_EmpID.Text.Trim
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_PatientID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_PatientID.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then
                Call Btn_PatientF2_Click(Nothing, Nothing)
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_PatientID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_PatientID.TextChanged
        Try
            With Patient_Info1
                .Viewmoreform_Name = "Patient_InfoSheet_Frm"
                .MDIform_Name = Me.MdiParent
                .Patient_ID = Txt_PatientID.Text.Trim
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_EmpID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_EmpID.Validating
        Try
            If Not Employee_Info1.Enabled Then Return
            If Not Employee_Info1.Is_Valid Then
                MessageBox.Show("Invalid Employee ID ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_EmpID.Focus()
                e.Cancel = True
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_PatientID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_PatientID.Validating
        Try
            If Not Patient_Info1.Enabled Then Return
            If Not Patient_Info1.Is_Valid Then
                MessageBox.Show("Invalid Patient ID ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_PatientID.Focus()
                e.Cancel = True
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_PatientF2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Btn_PatientF2.Click
        Try
            If Txt_PatientID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "150|50|50|150|150"
                Sql = "SELECT   Name,Patient_ID,SS_No,[Family Name],Address,City,Phone1,Mobile1  FROM    Patient_Info_Short_Vw where Br_Code= " & Branch_Code & ""
                Call ShowSearchengine(Txt_PatientID, Sql, 1, "Name", Colwidth, , 0)
            End If

            If Txt_PatientID.Text.Trim = "" Then
                Txt_PatientID.Focus() : Exit Sub
            End If

            Patient_Info1.Patient_ID = Txt_PatientID.Text.Trim
            If Not Patient_Info1.Is_Valid Then
                MessageBox.Show("Invalid Patient ID ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_PatientID.Focus()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_EmpF2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_EmpF2.Click
        Try
            If Txt_EmpID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "200|200|50|"
                Sql = "SELECT Name, Address, SS_Number,Phone, Mobile, Email, Status, [Admit Date], [Deactivate Date], Emp_ID From Emp_Details_Vw where Br_Code=" & Branch_Code & ""
                Call ShowSearchengine(Txt_EmpID, Sql, 9, "Name", Colwidth, , 0)
            End If

            'Validating Mandatory fields for locating
            If Txt_EmpID.Text.Trim = "" Then
                'MessageBox.Show("Invalid Employee ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_EmpID.Focus() : Exit Sub
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dtp_Apointdate_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Dtp_Apointdate.ValueChanged
        Try
            Lbl_Seldayname.Text = ""
            Lbl_Seldayname.Text = "( " + Dtp_Apointdate.Value.ToString("dddd").ToUpper + " )"
            Call Clear_Grid(True)
            Call Timer1_Tick(Nothing, Nothing)

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Cmb_Timefrom_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cmb_Timefrom.EnabledChanged
        Try
            Cmb_Timeto.Enabled = Cmb_Timefrom.Enabled
            Lbl_Fromtime.Visible = Not Cmb_Timefrom.Enabled
            Lbl_Totime.Visible = Not Cmb_Timeto.Enabled
            Lbl_Fromtime.Text = Cmb_Timefrom.Text
            Lbl_Totime.Text = Cmb_Timeto.Text
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Display_Timeinfo() Handles Cmb_Timefrom.TextChanged
        Try
            Dim frmtime As Date = Cmb_Timefrom.Items(0).ToString
            Lbl_Fromtime.Text = "" : Lbl_Totime.Text = "" : Cmb_Timeto.Text = "" : Lbl_Confirm.Text = "" : Lbl_ApStatus.Text = ""
            Cmb_Timeto.Text = Format(frmtime.AddMinutes(Seldoctor_A_interval), " hh : mm tt")
            Lbl_Fromtime.Text = Cmb_Timefrom.Text
            Lbl_Totime.Text = Cmb_Timeto.Text
            Lbl_Confirm.Text = Get_TimingMode(Timing_Tbl, Format(CDate(Cmb_Timefrom.Text.Trim), "hh:mm tt"))
            Lbl_Confirm.Text = IIf(Lbl_Confirm.Text = "W", "Not Confirm", IIf(Lbl_Confirm.Text = "C", "Confirm", ""))
            Lbl_ApStatus.Text = Lbl_Confirm.Text
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Cmb_Timefrom_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Cmb_Timefrom.Validating
        Try
            If Cmb_Timefrom.Text = "" Then Return

            Cmb_Timefrom.Text = Format(CDate(Cmb_Timefrom.Text), " hh : mm tt")

            If Lbl_Confirm.Text.ToUpper <> "CONFIRM" And Cmb_Bookingtype.SelectedIndex = 1 Then
                MessageBox.Show("Fixed Reservation is not Possible for Not Confirm Time ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Cmb_Bookingtype.SelectedIndex = 0
                Cmb_Bookingtype.Focus()
                e.Cancel = True
            End If

            If Cmb_Timefrom.FindStringExact(Cmb_Timefrom.Text, 0) < 0 Then
                MessageBox.Show("Selected Time not in the list ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Cmb_Timefrom.Focus()
                e.Cancel = True
            End If

            Dim frmtime As Date = Cmb_Timefrom.Text.Trim
            Cmb_Timeto.Text = Format(frmtime.AddMinutes(Seldoctor_A_interval), " hh : mm tt")


        Catch ex As Exception
            MessageBox.Show("Selected Time not in the list ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Cmb_Timefrom.Focus()
            e.Cancel = True
        End Try
    End Sub

    Private Sub Cmb_Timeto_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Cmb_Timeto.Validating
        Try
            If Cmb_Timeto.Text = "" Then Return
            Cmb_Timeto.Text = Format(CDate(Cmb_Timeto.Text), " hh : mm tt")

            If Cmb_Timeto.FindStringExact(Cmb_Timeto.Text, 0) < 0 Then
                MessageBox.Show("Selected Time not in the list ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Cmb_Timeto.Focus()
                e.Cancel = True
            End If

            Dim frmtime As Date = Cmb_Timefrom.Text.Trim
            Dim totime As Date = Cmb_Timeto.Text.Trim
            If frmtime > totime Then
                MessageBox.Show("To Time should be greater than from time", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Cmb_Timeto.Focus()
                e.Cancel = True
            ElseIf frmtime = totime Then
                Cmb_Timeto.Text = Format(frmtime.AddMinutes(Seldoctor_A_interval), " hh : mm tt")
            End If





        Catch ex As Exception
            MessageBox.Show("Selected Time not in the list ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Cmb_Timeto.Focus()
            e.Cancel = True
        End Try
    End Sub

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try
            If Not Validate_Fields() Then Exit Sub

            If Not Save_Appointment() Then
                MessageBox.Show("Error Occured While Saving Temp Customer ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Else
                Call Refresh_Apointmentchart(App_Doctor_ID, App_Service_ID, Dtp_Apointdate.Value)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Pnl_Message_VisibleChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Pnl_Message.VisibleChanged
        Try

            If Pnl_Message.Visible Then
                Pnl_Message.BringToFront()
            Else
                Me.Lbl_MesageTokenno.Text = ""
                Me.Lbl_MesageDate.Text = ""
                Me.Lbl_Mesageaproxtime.Text = ""
                Me.Lbl_Status.Text = ""
                Pnl_Message.SendToBack()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Public Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try
            If Txt_ApointID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "200|50|50|70|"
                Sql = " SELECT   a.Visitor_Name , a.Apoint_Tokenno as [Token No], a.Apoint_Date as [Apoint Date], a.Apoint_AproxStime as [Apoint Time],a.Doctor, a.Apoint_ID"
                Sql += "  FROM   Appointments_Vw a "
                Sql += " WHERE  (Apoint_Date >= '" & Format(Tran_Date, "MM/dd/yyyy") & "') AND (Service_ID = " & Cmb_Service.SelectedValue & ") AND (Apoint_Status = 'B')"
                Sql += "   AND	(Exists(Select * "
                Sql += "  From   dbo.[Get_Doctorswithservices_Fn](" & Cmb_Service.SelectedValue & ",'" & Format(Tran_Date, "MM/dd/yyyy") & "', " & Branch_Code & ") d Where d.DoctorID = a.Doc_ID))"

                Call ShowSearchengine(Txt_ApointID, Sql, 5, "Visitor_Name", Colwidth, , 0)
            End If

            'Validating Mandatory fields for locating
            If Txt_ApointID.Text.Trim = "" Then
                'MessageBox.Show("Invalid Appointment ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_ApointID.Focus() : Exit Sub
            End If

            If Locate_Values(Txt_ApointID.Text.Trim) Then
                Tr_Mode = Tran_Mode.Edit_Mode
                Pnl_Booking.Enabled = False
            Else

                MessageBox.Show("Appointment ID does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Cmb_Apointtype_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_Bookingtype.SelectedIndexChanged
        Try
            If Cmb_Timefrom.Items.Count > 0 Then Cmb_Timefrom.Text = Cmb_Timefrom.Items(0).ToString
            If Cmb_Bookingtype.SelectedIndex = 0 Then
                Timer1.Enabled = True
                Call Timer1_Tick(Nothing, Nothing)
                Cmb_Timefrom.Enabled = False
            Else
                Cmb_Timefrom.Enabled = True
                Timer1.Enabled = False
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Visitor_Age_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Visitor_Age.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Visitor_Age.Text, Data_Type.Integer_Type, 12))
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Visitor_Phone_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Visitor_Phone.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Visitor_Phone.Text, Data_Type.Integer_Type, 12))
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Visitor_Mobile_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Visitor_Mobile.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Visitor_Mobile.Text, Data_Type.Integer_Type, 12))
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try
            Call Clear_Form()

            Cmb_Visitortype.Focus()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Cmb_Service_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_Service.SelectedIndexChanged, Cmb_Service.SelectedValueChanged
        Try
            Me.App_Doctor_ID = 0
            Me.App_Service_ID = Cmb_Service.SelectedValue
            Dtp_Apointdate.Value = Tran_Date

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Try
            If App_Service_ID = 0 Then Exit Sub
            If App_Doctor_ID = 0 Then Exit Sub

            Call Refresh_Apointmentchart(App_Doctor_ID, App_Service_ID, Dtp_Apointdate.Value)

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_ApointID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_ApointID.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then Call Btn_Find_Click(Nothing, Nothing)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TlStrp_Doctors_ItemClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles TlStrp_Doctors.ItemClicked
        Try

            Dim btn_Doctor As ToolStripButton
            btn_Doctor = New ToolStripButton

            For Each btn_Doctor In TlStrp_Doctors.Items
                btn_Doctor.BackColor = Color.White
                btn_Doctor.ForeColor = Color.DarkBlue
            Next

            btn_Doctor = e.ClickedItem

            e.ClickedItem.BackColor = Color.FromArgb(60, 113, 193)
            e.ClickedItem.ForeColor = Color.White

            App_Doctor_ID = 0
            App_Doctor_ID = btn_Doctor.Tag
            App_Service_ID = Cmb_Service.SelectedValue

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgrd_Appointment_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgrd_Appointment.CellClick
        Try

            With Dgrd_Appointment
                If e.RowIndex = -1 Then Exit Sub
                If e.ColumnIndex = 0 Then Exit Sub
                If .Rows(e.RowIndex).Cells(e.ColumnIndex).Tag = "" Then
                    Return
                End If

                Dim ApointID As String = ""

                ApointID = .Rows(e.RowIndex).Cells(e.ColumnIndex).Tag
                ApointID = Mid(ApointID, 1, InStr(ApointID, "|") - 1)
                If Not (ApointID = "F" Or ApointID = "W") Then
                    Txt_ApointID.Text = ApointID
                    Call Btn_Find_Click(Nothing, Nothing)
                End If
            End With

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgrd_Appointment_CellEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgrd_Appointment.CellEnter
        Try
            With Dgrd_Appointment
                If e.RowIndex = -1 Then Exit Sub
                If e.ColumnIndex = 0 Then Exit Sub
                If .Rows(e.RowIndex).Cells(e.ColumnIndex).Tag = "" Then
                    If Strings.Left(Format((.Columns(e.ColumnIndex).Name), "dddd").ToString, 3).ToUpper = Seldoctor_Offday.ToUpper Then
                        .Rows(e.RowIndex).Cells(e.ColumnIndex).Value = "OFF DAY"
                    Else
                        .Rows(e.RowIndex).Cells(e.ColumnIndex).Value = "OFF TIME"
                    End If
                    Return
                End If
            End With

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgrd_Appointment_CellLeave(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgrd_Appointment.CellLeave
        Try
            With Dgrd_Appointment
                If e.RowIndex = -1 Then Exit Sub
                If e.ColumnIndex = 0 Then Exit Sub
                If .Rows(e.RowIndex).Cells(e.ColumnIndex).Tag = "" Then
                    .Rows(e.RowIndex).Cells(e.ColumnIndex).Value = ""

                End If
            End With

        Catch ex As Exception

        End Try
    End Sub

    Public Sub Btn_FindPMRID_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_FindPMRID.Click
        Try
            Try

                If Txt_PMRID.Text.Trim = String.Empty Then
                    Dim Sql As String
                    Dim Colwidth As String = String.Empty
                    Colwidth = "200|50|300|70|"

                    Sql = " SELECT [Patient Name], [SS No], ([Family Name] + Address + City) AS Address, PMR_ID, OPD_ID, Patient_ID"
                    Sql += " FROM Pateint_Accountsearch_Vw WHERE (Cancelled = 'N') AND (Authorised = 'Y')"

                    Call ShowSearchengine(Txt_PMRID, Sql, 3, "[Patient Name]", Colwidth, , 0)
                End If

                'Validating Mandatory fields for locating
                If Txt_PMRID.Text.Trim = String.Empty Then
                    'MessageBox.Show("Invalid Appointment ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Txt_PMRID.Focus() : Exit Sub
                End If

                If Locate_PMR_Masterinfo(Txt_PMRID.Text.Trim, Branch_Code) Then
                    Cmb_Bookingtype.Focus()
                Else
                    MessageBox.Show("Invalid PMR ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If

            Catch ex As Exception
                MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Cmb_Visittype_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_Visittype.SelectedIndexChanged
        Try
            If Cmb_Visittype.Items.Count > 0 Then
                If Cmb_Visittype.SelectedIndex = 0 Then
                    Pnl_PMRID.Visible = False
                    Cmb_Visitortype.SelectedIndex = 0
                    Cmb_Visitortype.Enabled = True
                Else
                    Pnl_PMRID.Visible = True
                    Txt_PMRID.Text = ""
                    Cmb_Visitortype.SelectedIndex = 1
                    Cmb_Visitortype.Enabled = False
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_OPID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_PMRID.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then Call Btn_FindPMRID_Click(Nothing, Nothing)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_OPID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_PMRID.TextChanged
        Try
            If Txt_PMRID.Text.Trim = "" Then Call Clear_Form()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_PMRID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_PMRID.Validating
        Try
            If Me.Txt_PMRID.Text.Trim <> "" And Me.Txt_PMRID.Text <> Me.Txt_PMRID.Tag Then
                If Not Locate_PMR_Masterinfo(Txt_PMRID.Text.Trim, Branch_Code) Then
                    MessageBox.Show("Invalid PMR-ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Txt_PMRID.Focus()
                    e.Cancel = True
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub



    Private Sub Assign_PatientDet(ByVal dtbl As DataTable)
        Try
            Txt_Visitor_Name.Text = dtbl.Rows(0).Item("Name").ToString
            Txt_Visitor_Addr.Text = dtbl.Rows(0).Item("address").ToString
            Txt_Visitor_Familyname.Text = dtbl.Rows(0).Item("Family").ToString
            Cmb_visitor_Gender.SelectedIndex = IIf(dtbl.Rows(0).Item("gender").ToString = "M", 0, 1)
            Txt_Visitor_Age.Text = dtbl.Rows(0).Item("Age").ToString
            Txt_Visitor_Phone.Text = dtbl.Rows(0).Item("Phone").ToString
            Txt_Visitor_Mobile.Text = dtbl.Rows(0).Item("Mobile").ToString
            Cmb_Visitor_nationality.SelectedValue = dtbl.Rows(0).Item("Patient_Country").ToString

        Catch ex As Exception

        End Try

    End Sub

    Private Sub Txt_Visitor_SSNO_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_Visitor_SSNO.Validating
        Try

            If Txt_Visitor_SSNO.Text.Trim = "" Then Exit Sub

            Dim dtbl As DataTable = Nothing
            hms_helper = New Hms_Helperimpliments

            If hms_helper.Get_Patient_Info_SSNo(dtbl, Txt_Visitor_SSNO.Text.Trim) Then
                If dtbl.Rows.Count > 0 Then
                    If MessageBox.Show("Social securtiy number already exist, Continue with existing SSN..?", _
                                    Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                        ' Assign values to particular controls
                        Cmb_Visitortype.SelectedIndex = 1
                        Patient_Info1.Patient_ID = dtbl.Rows(0).Item("Patient_ID").ToString
                        Txt_PatientID.Text = dtbl.Rows(0).Item("Patient_ID").ToString

                    End If
                End If
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Visitor_SSNO_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Visitor_SSNO.TextChanged

    End Sub
End Class