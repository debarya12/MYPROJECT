﻿Module My_Utilities

#Region "APIs"
    Declare Sub keybd_event Lib "user32" (ByVal bVk As Byte, ByVal bScan As Byte, ByVal dwFlags As Long, ByVal dwExtraInfo As Long)
#End Region


#Region "Constants"

    Const GoodChar As String = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
    Const GoodNum As String = "1234567890"

#End Region

#Region "Enums"

    'Data Type
    Public Enum Data_Type
        Date_Type
        Alpha_Type
        Alphanumeric_Type
        Integer_Type
        Double_Type
        General_Type
    End Enum

#End Region

    'Validating Keyascii
    Public Function Validate_KeyAscii(ByVal keycode As Short, ByVal Expression As String, ByVal DataType As Data_Type, Optional ByVal MaxLength As Short = 0) As Short

        Dim keyreturn As Short = 0

        Try
            keyreturn = keycode

            If keycode = Keys.Back Then Return keyreturn
            If keycode = Keys.Tab Then Return keyreturn

            Dim ChrKeycode As String

            ChrKeycode = Chr(keycode)

            If MaxLength > 0 Then
                If Len(Expression.Trim) >= MaxLength Then keyreturn = 0 : Return keyreturn
            End If


            Select Case DataType

                Case Data_Type.Alpha_Type
                    If InStr(1, CStr(GoodChar & "."), ChrKeycode) = 0 Then
                        keyreturn = 0 : Return keyreturn
                    End If

                Case Data_Type.Alphanumeric_Type
                    If InStr(1, CStr(GoodChar & GoodNum & "."), ChrKeycode) = 0 Then
                        keyreturn = 0 : Return keyreturn
                    End If
                Case Data_Type.Date_Type
                    Return keyreturn
                Case Data_Type.Integer_Type
                    If InStr(1, GoodNum, ChrKeycode) = 0 Then
                        keyreturn = 0 : Return keyreturn
                    End If

                Case Data_Type.Double_Type

                    If InStr(1, CStr(GoodNum & "."), ChrKeycode) = 0 Then
                        keyreturn = 0 : Return keyreturn
                    Else
                        If ChrKeycode = "." Then
                            If InStr(1, Expression, ".") > 0 Then keyreturn = 0 : Return keyreturn
                        Else
                            If InStr(1, Expression, ".") > 0 Then
                                Dim Decimal_number As String = ""

                                Decimal_number = Mid(Expression, InStr(1, Expression, "."))
                                If Decimal_number.Length > 2 Then
                                    keyreturn = 0 : Return keyreturn
                                End If
                            End If
                        End If
                    End If

                Case "GENERAL"
                    Return keyreturn
                Case Else
                    Return keyreturn
            End Select

            Return keyreturn

        Catch ex As Exception
            Return 0
        End Try


    End Function


    'Key board Handler
    Public Sub SendKeyTab(Optional ByRef KeyAscii As Integer = 0)
        Try

            If KeyAscii = Keys.Enter Then
                KeyAscii = 0 ' suppress the "beep"
                keybd_event(Keys.Tab, 0, 0, 0) ' press Tab key
                keybd_event(Keys.Tab, 0, 2, 0) ' release Tab key
                If KeyAscii = 39 Then KeyAscii = 96
            ElseIf KeyAscii = 0 Then
                keybd_event(Keys.Tab, 0, 0, 0) ' press Tab key
                keybd_event(Keys.Tab, 0, 2, 0) ' release Tab key
            End If

        Catch ex As Exception

        End Try

    End Sub
End Module
