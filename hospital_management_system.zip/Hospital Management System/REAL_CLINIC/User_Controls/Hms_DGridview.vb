﻿

Option Explicit On
Public Class Hms_DGridview
    Inherits DataGridView

    Protected Overloads Overrides Function ProcessDialogKey(ByVal keyData As Keys) As Boolean
        Try
            If keyData = Keys.Enter Then
                Dim row As Integer = Me.CurrentCell.RowIndex
                If row < Me.RowCount Then
                    If row = Me.RowCount - 1 Then
                        Return False
                    Else
                        MyBase.OnKeyDown(New KeyEventArgs(keyData))
                        Return True
                    End If
                End If
            End If
            Return MyBase.ProcessDialogKey(keyData)
        Catch ex As Exception
            Return MyBase.ProcessDialogKey(keyData)
        End Try
    End Function

    Protected Overloads Overrides Sub OnKeyDown(ByVal e As KeyEventArgs)
        Try
            If e.KeyData = Keys.Enter Then
                '// Do Nothing              
            Else
                MyBase.OnKeyDown(e)
            End If
        Catch ex As Exception

        End Try
    End Sub

    

End Class
