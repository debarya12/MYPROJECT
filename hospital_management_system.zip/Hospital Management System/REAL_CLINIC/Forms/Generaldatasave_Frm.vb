﻿

Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls
Public Class Generaldatasave_Frm

#Region "Declarations"
    'Object of Gendata Bussiness Layer
    Private Gendata_BL As HMS_Common_BL_Cls

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing

    Public Point_Frm As Point

#End Region

#Region "Properties"

    Private mReq_Ctrl As Object = Nothing
    Public WriteOnly Property Req_Ctrl() As Object
        Set(ByVal Value As Object)
            mReq_Ctrl = Value
        End Set
    End Property

    Private mData_ID As Integer = 0
    Public Property Data_ID() As Integer
        Get
            Return mData_ID
        End Get
        Set(ByVal value As Integer)
            mData_ID = value
        End Set
    End Property

    Private mData_CatID As Integer
    Public Property Data_CatID() As Integer
        Get
            Return mData_CatID
        End Get
        Set(ByVal value As Integer)
            mData_CatID = value
        End Set
    End Property

    Private mData_ParentID As Integer
    Public Property Data_ParentID() As Integer
        Get
            Return mData_ParentID
        End Get
        Set(ByVal value As Integer)
            mData_ParentID = value
        End Set
    End Property

    Private mData_Description As String
    Public Property Data_Description() As String
        Get
            Return mData_Description
        End Get
        Set(ByVal value As String)
            mData_Description = value
        End Set
    End Property

#End Region

#Region "Methods"

    Private Function Validate_Fields() As Boolean
        Try

            Dim Accesstype As Access_Type = Access_Type.Add
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If

            If Txt_Datadescription.Text.Trim = "" Then MessageBox.Show("Invalid Data Description,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Datadescription.Focus() : Exit Function

            If Cmb_Parentdata.SelectedIndex < 0 Then MessageBox.Show("Please Select Parent Data", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_Parentdata.Focus() : Exit Function

            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Clear_Datadetails()
        Try
            Data_CatID = ""
            Txt_Datadescription.Text = ""
            Cmb_Parentdata.SelectedIndex = 0
            Data_ParentID = 0
            Data_Description = ""

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Return_Withvalue()
        Try
            If TypeOf mReq_Ctrl Is ComboBox Or TypeOf mReq_Ctrl Is ListBox Then
                mReq_Ctrl.tag = mData_ID
                If TypeOf mReq_Ctrl Is ComboBox Then
                    'Initialising BL Object
                    Gendata_BL = New HMS_Common_BL_Cls

                    If Data_CatID <> 0 Then
                        Gendata_BL.Fill_Gendata(mReq_Ctrl, Data_CatID, "Not Applicable")
                    End If

                    Call Set_Defaultvalue(mReq_Ctrl, Data_ID)
                End If
                If mReq_Ctrl.Visible Then mReq_Ctrl.focus()
                Me.Close()
                Exit Sub
            End If

        Catch ex As Exception
            'MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Set_Defaultvalue(ByRef Cmbbx As ComboBox, ByVal Defaultvalue As String)
        Try

            Cmbbx.SelectedValue = Defaultvalue

        Catch ex As Exception

        End Try
    End Sub

#End Region

    Private Sub Close_Btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

    Private Sub Generaldatasave_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then Call SendKeyTab()
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try

            'Validating Data
            If Not Validate_Fields() Then Exit Sub

            'Initialising BL Object
            Gendata_BL = New HMS_Common_BL_Cls

            'Saving Records
            With Gendata_BL
                .Data_ID = 0
                .Data_CatID = Data_CatID
                .Data_Description = Txt_Datadescription.Text.Trim
                .Data_ParentID = Getlist_Item_Value(Cmb_Parentdata, Cmb_Parentdata.SelectedIndex)
                .Data_Locked = "N"
                .Data_Active = "Y"
                .Data_Order = 0
                If .Save_Gendata(Dtbl, Tran_Mode.New_Mode, 0) Then
                    Dr = Dtbl.CreateDataReader()
                    Dr.Read()
                    With Dr
                        Data_ID = .Item("Data_ID")
                    End With

                    Call Return_Withvalue()
                    Return
                End If
                Me.Close()
            End With

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Generaldatasave_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub Generaldatasave_Frm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            'Positioning Form to respective controls
            Me.DesktopLocation = Point_Frm

            'Initialising BL Object
            Gendata_BL = New HMS_Common_BL_Cls

            If Data_CatID <> 0 Then
                Gendata_BL.Fill_Gendata(Cmb_Parentdata, Data_CatID, "Not Applicable")
            End If

            Txt_Datadescription.Text = ""
            If Cmb_Parentdata.Items.Count > 0 Then Cmb_Parentdata.SelectedIndex = 0

        Catch ex As Exception

        End Try

    End Sub

    Private Sub Txt_Datadescription_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_Datadescription.Validating
        Try
            If Isexistsinlist(Cmb_Parentdata, Txt_Datadescription.Text.Trim) Then
                MessageBox.Show("Data Description Already Exists ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_Datadescription.Focus()
                e.Cancel = True
            End If


        Catch ex As Exception

        End Try
    End Sub

    Private Sub Generaldatasave_Frm_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Try
            Txt_Datadescription.Focus()
        Catch ex As Exception

        End Try
    End Sub
End Class