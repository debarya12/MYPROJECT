﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Imageviewer
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Imageviewer))
        Me.Pnl_Exphotos = New System.Windows.Forms.Panel
        Me.Pic_Photo = New System.Windows.Forms.PictureBox
        Me.Panel4 = New System.Windows.Forms.Panel
        Me.Lbl_Navimagetype = New System.Windows.Forms.Label
        Me.Btn_ScanImage = New System.Windows.Forms.Button
        Me.Nav_Imageview = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.BindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Pnl_Exphotos.SuspendLayout()
        CType(Me.Pic_Photo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        CType(Me.Nav_Imageview, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Nav_Imageview.SuspendLayout()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Pnl_Exphotos
        '
        Me.Pnl_Exphotos.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Exphotos.Controls.Add(Me.Pic_Photo)
        Me.Pnl_Exphotos.Controls.Add(Me.Panel4)
        Me.Pnl_Exphotos.Controls.Add(Me.Btn_ScanImage)
        Me.Pnl_Exphotos.Controls.Add(Me.Nav_Imageview)
        Me.Pnl_Exphotos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Pnl_Exphotos.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Exphotos.Name = "Pnl_Exphotos"
        Me.Pnl_Exphotos.Size = New System.Drawing.Size(177, 270)
        Me.Pnl_Exphotos.TabIndex = 90
        '
        'Pic_Photo
        '
        Me.Pic_Photo.BackColor = System.Drawing.Color.White
        Me.Pic_Photo.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Pic_Photo.Image = CType(resources.GetObject("Pic_Photo.Image"), System.Drawing.Image)
        Me.Pic_Photo.Location = New System.Drawing.Point(0, 47)
        Me.Pic_Photo.Name = "Pic_Photo"
        Me.Pic_Photo.Size = New System.Drawing.Size(177, 201)
        Me.Pic_Photo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pic_Photo.TabIndex = 94
        Me.Pic_Photo.TabStop = False
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Controls.Add(Me.Lbl_Navimagetype)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel4.ForeColor = System.Drawing.Color.White
        Me.Panel4.Location = New System.Drawing.Point(0, 25)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(177, 22)
        Me.Panel4.TabIndex = 93
        '
        'Lbl_Navimagetype
        '
        Me.Lbl_Navimagetype.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Navimagetype.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Lbl_Navimagetype.Location = New System.Drawing.Point(0, 0)
        Me.Lbl_Navimagetype.Name = "Lbl_Navimagetype"
        Me.Lbl_Navimagetype.Size = New System.Drawing.Size(175, 20)
        Me.Lbl_Navimagetype.TabIndex = 0
        Me.Lbl_Navimagetype.Text = "PHOTO"
        Me.Lbl_Navimagetype.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Btn_ScanImage
        '
        Me.Btn_ScanImage.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_ScanImage.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.F2_Button
        Me.Btn_ScanImage.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Btn_ScanImage.ForeColor = System.Drawing.Color.White
        Me.Btn_ScanImage.Location = New System.Drawing.Point(0, 248)
        Me.Btn_ScanImage.Name = "Btn_ScanImage"
        Me.Btn_ScanImage.Size = New System.Drawing.Size(177, 22)
        Me.Btn_ScanImage.TabIndex = 92
        Me.Btn_ScanImage.TabStop = False
        Me.Btn_ScanImage.Text = "S C A N"
        Me.Btn_ScanImage.UseVisualStyleBackColor = False
        '
        'Nav_Imageview
        '
        Me.Nav_Imageview.AddNewItem = Nothing
        Me.Nav_Imageview.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Nav_Imageview.CountItem = Me.BindingNavigatorCountItem
        Me.Nav_Imageview.DeleteItem = Nothing
        Me.Nav_Imageview.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Nav_Imageview.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2})
        Me.Nav_Imageview.Location = New System.Drawing.Point(0, 0)
        Me.Nav_Imageview.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.Nav_Imageview.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.Nav_Imageview.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.Nav_Imageview.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.Nav_Imageview.Name = "Nav_Imageview"
        Me.Nav_Imageview.PositionItem = Me.BindingNavigatorPositionItem
        Me.Nav_Imageview.Size = New System.Drawing.Size(177, 25)
        Me.Nav_Imageview.TabIndex = 0
        Me.Nav_Imageview.Text = "BindingNavigator1"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(42, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(20, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'BindingSource1
        '
        '
        'Imageviewer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.Pnl_Exphotos)
        Me.Name = "Imageviewer"
        Me.Size = New System.Drawing.Size(177, 270)
        Me.Pnl_Exphotos.ResumeLayout(False)
        Me.Pnl_Exphotos.PerformLayout()
        CType(Me.Pic_Photo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        CType(Me.Nav_Imageview, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Nav_Imageview.ResumeLayout(False)
        Me.Nav_Imageview.PerformLayout()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Pnl_Exphotos As System.Windows.Forms.Panel
    Friend WithEvents Btn_ScanImage As System.Windows.Forms.Button
    Friend WithEvents Nav_Imageview As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Pic_Photo As System.Windows.Forms.PictureBox
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Navimagetype As System.Windows.Forms.Label
    Friend WithEvents BindingSource1 As System.Windows.Forms.BindingSource

End Class
