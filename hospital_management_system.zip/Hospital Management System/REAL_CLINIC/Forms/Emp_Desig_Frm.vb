﻿

Option Explicit On
Imports HMS_Common.Common_Cls
Imports HMS_BL
Public Class Emp_Desig_Frm

#Region "Declarations"
    'Object of Employee Details Bussiness Layer
    Private Emp_Desig_BL As Emp_Desig_Master_BL_Cls
    Private mTr_Mode As Tran_Mode

    Private hms_Helper As HMS_Helper

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_DesigID.BackColor = Color.White
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_DesigID.BackColor = Color.Silver
            End Select
        End Set
    End Property


#End Region

    Private Sub Close_Btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

#Region "Functions"

    Private Sub Clear_Form()
        Try

            Txt_DesigID.Text = ""
            Txt_Designation.Text = ""
            Txt_Designation.Tag = ""
            Cmb_Admin.SelectedIndex = 0

            Tr_Mode = Tran_Mode.New_Mode
            Btn_Save.Enabled = True
            Btn_Delete.Enabled = False

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Sub Fill_Emp_Desig_Grid()
        Try

            Emp_Desig_BL = New Emp_Desig_Master_BL_Cls
            Dtbl = Nothing
            With Dgvw_Emp_DesigMaster

                If Emp_Desig_BL.Get_Emp_Designation_Details_All(Dtbl) Then
                    .DataSource = Dtbl
                    .Columns(0).Width = 100
                    .Columns(1).Width = 200
                    .Columns(2).Width = 100
                    .Refresh()
                End If
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region



    Private Function Validate_Fields() As Boolean
        Try
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If

            If Not Validate_Transactionright(Tr_Mode, Me.Name) Then
                If Tr_Mode = Tran_Mode.New_Mode Then
                    MessageBox.Show("Save Permission Denied for this User" & vbCrLf & "Please Contact System Administrator ", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                ElseIf Tr_Mode = Tran_Mode.Edit_Mode Then
                    MessageBox.Show("Edit Permission Denied for this User" & vbCrLf & "Please Contact System Administrator ", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
            End If

            If Txt_Designation.Text.Trim = "" Then MessageBox.Show("Invalid Designation,Please Check", _
            Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Designation.Focus() : Return False

            If Cmb_Admin.SelectedIndex = 0 Then MessageBox.Show("Select Valid Admin,Please Check", _
            Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_Admin.Focus() : Return False

            'Assigning Default values
            Return True

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try

    End Function

    Private Function Locate_Values(ByVal Desig_ID As Integer) As Boolean

        Try

            'Initialising BL Object
            Emp_Desig_BL = New Emp_Desig_Master_BL_Cls
            Dtbl = Nothing
            Call Clear_Form()
            Tr_Mode = Tran_Mode.Edit_Mode
            Btn_Delete.Enabled = True
            'Retreiving Company Details and Assign the values to respective controls
            If Emp_Desig_BL.GetEmp_Desig_Details(Dtbl, Desig_ID) Then
               
                With Dtbl

                    Txt_DesigID.Text = .Rows(0).Item("Desig_ID")
                    Txt_Designation.Text = .Rows(0).Item("Designation")
                    Cmb_Admin.SelectedIndex = IIf(.Rows(0).Item("Admin").ToString = "Y", 1, 2)

                End With
                Return True
            Else
                Return False
            End If



        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        Finally
            Dr = Nothing
            Dtbl = Nothing
            Emp_Desig_BL = Nothing
        End Try

    End Function

    Private Sub Emp_Desig_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then Call SendKeyTab()
        Catch ex As Exception

        End Try

    End Sub

 

    Private Sub Companyprofile_Frm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try

            Cmb_Admin.Items.Add("<Select>")
            Cmb_Admin.Items.Add("Yes")
            Cmb_Admin.Items.Add("No")
            Cmb_Admin.SelectedIndex = 0

            Call Fill_Emp_Desig_Grid()

        Catch ex As Exception

        End Try
    End Sub

   
    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try


            If Not Validate_Fields() Then Exit Sub
            Dim Dtbl As DataTable

            'Initialising BL Object
            Emp_Desig_BL = New Emp_Desig_Master_BL_Cls
            Dtbl = Nothing
            Emp_Desig_BL.Desig_ID = Val(Txt_DesigID.Text.Trim)
            Emp_Desig_BL.Designation = Txt_Designation.Text.Trim
            Emp_Desig_BL.Admin = Strings.Left(Cmb_Admin.Text, 1).Trim.ToUpper

            If Emp_Desig_BL.Save_Emp_Desig_Master(Dtbl, Tr_Mode, Val(Txt_DesigID.Text.Trim)) Then
                Txt_DesigID.Text = Dtbl.Rows(0).Item("Desig_ID").ToString
                Tr_Mode = Tran_Mode.Edit_Mode
                MessageBox.Show("Employee Designation Details Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Btn_Clear.Focus()
                Call Fill_Emp_Desig_Grid()
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Designation_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_Designation.Validating
        Try

            hms_Helper = New Hms_Helperimpliments
            If Tr_Mode = Tran_Mode.New_Mode Then
                If hms_Helper.Check_Duplicatedataexists("Emp_Designation_Tbl", "Designation", Data_Type.General_Type, Txt_Designation.Text.Trim) Then
                    MessageBox.Show("Account Group Already Exist,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_Designation.Focus()
                    Txt_Designation.Text = ""
                    e.Cancel = True
                    Exit Sub
                End If

            Else
                If hms_Helper.Check_Duplicatedataexists("Emp_Designation_Tbl", "Designation", Data_Type.General_Type, Txt_Designation.Text.Trim, , , "Desig_ID", Data_Type.Integer_Type, Txt_DesigID.Text.Trim) Then
                    MessageBox.Show("Account Group Already Exist,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_Designation.Focus()
                    Txt_Designation.Text = ""
                    e.Cancel = True
                End If
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try

            Call Clear_Form()
            Txt_DesigID.Focus()

        Catch ex As Exception

        End Try
        
    End Sub

    Private Sub Dgvw_Emp_DesigMaster_CellDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgvw_Emp_DesigMaster.CellDoubleClick
        Try
            With Dgvw_Emp_DesigMaster
                If .CurrentRow Is Nothing Then Exit Sub
                Txt_DesigID.Text = .CurrentRow.Cells("Desig_ID").Value
                Call Locate_Values(Txt_DesigID.Text)
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try

            'search engine
            If Txt_DesigID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "100|300|5|"
                Sql = "Select * From Employee_Designation_Details_Vw "
                Call ShowSearchengine(Txt_DesigID, Sql, 0, "[Designation]", Colwidth, , 0)
            End If


            'Validating Mandatory fields for locating
            If Txt_DesigID.Text.Trim = "" Then
                'MessageBox.Show("Invalid Group ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_DesigID.Focus() : Exit Sub
            End If

            If Locate_Values(Txt_DesigID.Text) Then
                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Delete.Enabled = True
                Txt_DesigID.Focus()
            Else
                MessageBox.Show("Group ID does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_DesigID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_DesigID.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then Btn_Find_Click(sender, e)
        Catch ex As Exception

        End Try
    End Sub

    
    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click
        Try
            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If

            Emp_Desig_BL = New Emp_Desig_Master_BL_Cls
            Dtbl = Nothing
            If MessageBox.Show("Are You Sure Delete the Selected Designation ", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.No Then Exit Sub

            If Emp_Desig_BL.Del_Emp_Designation(Dtbl, Txt_DesigID.Text.Trim) Then
                If Dtbl.Rows(0).Item(0).ToString = "0" Then MessageBox.Show("Cancellation failed" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Exit Sub
                MessageBox.Show("Employee Designation Cancelled", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("You cannot delete this Account Group" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

            Btn_Clear.Focus()
            Fill_Emp_Desig_Grid()

        Catch ex As Exception

        End Try
    End Sub

    
End Class