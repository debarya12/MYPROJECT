﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Patient_Transaction_Bill_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Patient_Transaction_Bill_Frm))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.Lst_Search = New System.Windows.Forms.ListBox
        Me.Txt_PatientID = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Txt_OutPatientID = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Txt_ExpID = New System.Windows.Forms.TextBox
        Me.Txt_ExpenseMaster = New System.Windows.Forms.TextBox
        Me.Tvw_ExpenseList = New System.Windows.Forms.TreeView
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Lbl_TotalAmount = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Lbl_Words = New System.Windows.Forms.Label
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Discharge = New System.Windows.Forms.Button
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Report = New System.Windows.Forms.Button
        Me.Btn_Uttility = New System.Windows.Forms.Button
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Cancel = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.Btn_Add = New System.Windows.Forms.Button
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label
        Me.Txt_Remarks = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Txt_BatchID = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Btn_Cleargrid = New System.Windows.Forms.Button
        Me.Pnl_History = New System.Windows.Forms.Panel
        Me.Label27 = New System.Windows.Forms.Label
        Me.Txt_PMR_ID = New System.Windows.Forms.TextBox
        Me.Btn_FindOP = New System.Windows.Forms.Button
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Btn_CloseHistory = New System.Windows.Forms.Button
        Me.Btn_ShowHistory = New System.Windows.Forms.Button
        Me.Cmb_PayStatus = New System.Windows.Forms.ComboBox
        Me.Dtp_ToDate = New System.Windows.Forms.DateTimePicker
        Me.Dtp_FrmDate = New System.Windows.Forms.DateTimePicker
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.Dgv_PatientTran_Grid = New REAL_CLINIC.Hms_DGridview(Me.components)
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Label24 = New System.Windows.Forms.Label
        Me.Cmb_DebitDep = New System.Windows.Forms.ComboBox
        Me.Txt_Tran_BatchID = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Cmb_Payment_Mode = New System.Windows.Forms.ComboBox
        Me.Txt_BillBatchNO = New System.Windows.Forms.TextBox
        Me.Trancontrol1 = New Tran_Controls.Trancontrol
        Me.Dgv_PatientBill_Grid = New REAL_CLINIC.Hms_DGridview(Me.components)
        Me.Expense = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Particulars = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Amount = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Acc_Code = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Exp_Subtype = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Def_TranType = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Editable = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Exp_ID = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.ChkAll = New System.Windows.Forms.CheckBox
        Me.Label25 = New System.Windows.Forms.Label
        Me.Cmb_debitfromDeposit = New System.Windows.Forms.ComboBox
        Me.Btn_ProcessAllPending = New System.Windows.Forms.Button
        Me.Btn_GenerateBill = New System.Windows.Forms.Button
        Me.Dgv_PendingBills = New REAL_CLINIC.Hms_DGridview(Me.components)
        Me.Mark = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.SerialNo = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.BillDate = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.ExpenseParticulars = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.ExpenseAmount = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Bill_BatchNo = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.PatientTranBatchID = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Bill_ID = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Panel4 = New System.Windows.Forms.Panel
        Me.Lbl_TotUnpaid = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Lbl_Wrds = New System.Windows.Forms.Label
        Me.Txt_Remark = New System.Windows.Forms.TextBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.Cmb_PamentMode = New System.Windows.Forms.ComboBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.Btn_Close1 = New System.Windows.Forms.Button
        Me.Btn_Show1 = New System.Windows.Forms.Button
        Me.Btn_Uttility1 = New System.Windows.Forms.Button
        Me.Btn_Clear1 = New System.Windows.Forms.Button
        Me.Btn_Cancel1 = New System.Windows.Forms.Button
        Me.Btn_Save1 = New System.Windows.Forms.Button
        Me.Btn_Showtran = New System.Windows.Forms.Button
        Me.Txt_Trandate = New System.Windows.Forms.TextBox
        Me.Txt_DepositBalance = New System.Windows.Forms.TextBox
        Me.Pnl_Details = New System.Windows.Forms.Panel
        Me.Pnl_CreditPosition = New System.Windows.Forms.Panel
        Me.Lbl_UnPaid_BillAmt = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.Lbl_BalanceAmt = New System.Windows.Forms.Label
        Me.Lbl_Paid_BillAmt = New System.Windows.Forms.Label
        Me.Lbl_DepositAmt = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.Pct_UPDown = New System.Windows.Forms.PictureBox
        Me.Label22 = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.Btn_PMRFind = New System.Windows.Forms.Button
        Me.Txt_PMRID = New System.Windows.Forms.TextBox
        Me.Label26 = New System.Windows.Forms.Label
        Me.Btn_ExpGroup = New System.Windows.Forms.Button
        Me.Button1 = New System.Windows.Forms.Button
        Me.Panel5 = New System.Windows.Forms.Panel
        Me.Patient_Info1 = New REAL_CLINIC.Patient_Info
        Me.Pnl_Header.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.Pnl_Tran_mode.SuspendLayout()
        Me.Pnl_History.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.Dgv_PatientTran_Grid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Dgv_PatientBill_Grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.Dgv_PendingBills, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Pnl_Details.SuspendLayout()
        Me.Pnl_CreditPosition.SuspendLayout()
        CType(Me.Pct_UPDown, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel5.SuspendLayout()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Menu_Bkg
        Me.Pnl_Header.Controls.Add(Me.Label1)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(815, 19)
        Me.Pnl_Header.TabIndex = 10000
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(7, 1)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(153, 18)
        Me.Label1.TabIndex = 100000
        Me.Label1.Text = "B i l l   P a y m e n t s"
        '
        'Lst_Search
        '
        Me.Lst_Search.BackColor = System.Drawing.Color.White
        Me.Lst_Search.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Lst_Search.FormattingEnabled = True
        Me.Lst_Search.Location = New System.Drawing.Point(50, 25)
        Me.Lst_Search.Name = "Lst_Search"
        Me.Lst_Search.Size = New System.Drawing.Size(196, 106)
        Me.Lst_Search.TabIndex = 126
        Me.Lst_Search.Visible = False
        '
        'Txt_PatientID
        '
        Me.Txt_PatientID.BackColor = System.Drawing.Color.White
        Me.Txt_PatientID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_PatientID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PatientID.Location = New System.Drawing.Point(76, 96)
        Me.Txt_PatientID.MaxLength = 10
        Me.Txt_PatientID.Name = "Txt_PatientID"
        Me.Txt_PatientID.Size = New System.Drawing.Size(109, 21)
        Me.Txt_PatientID.TabIndex = 206
        Me.Txt_PatientID.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(8, 99)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(64, 13)
        Me.Label5.TabIndex = 211
        Me.Label5.Text = "Patient ID"
        '
        'Txt_OutPatientID
        '
        Me.Txt_OutPatientID.BackColor = System.Drawing.Color.White
        Me.Txt_OutPatientID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_OutPatientID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_OutPatientID.Location = New System.Drawing.Point(52, 83)
        Me.Txt_OutPatientID.MaxLength = 10
        Me.Txt_OutPatientID.Name = "Txt_OutPatientID"
        Me.Txt_OutPatientID.Size = New System.Drawing.Size(164, 21)
        Me.Txt_OutPatientID.TabIndex = 235252
        Me.Txt_OutPatientID.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(8, 75)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 13)
        Me.Label2.TabIndex = 210
        Me.Label2.Text = "OP ID"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.Controls.Add(Me.Txt_ExpID)
        Me.Panel1.Controls.Add(Me.Txt_ExpenseMaster)
        Me.Panel1.Controls.Add(Me.Lst_Search)
        Me.Panel1.Controls.Add(Me.Tvw_ExpenseList)
        Me.Panel1.Location = New System.Drawing.Point(17, 5)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(249, 354)
        Me.Panel1.TabIndex = 213
        '
        'Txt_ExpID
        '
        Me.Txt_ExpID.BackColor = System.Drawing.Color.White
        Me.Txt_ExpID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_ExpID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_ExpID.Location = New System.Drawing.Point(1, 3)
        Me.Txt_ExpID.Name = "Txt_ExpID"
        Me.Txt_ExpID.Size = New System.Drawing.Size(47, 21)
        Me.Txt_ExpID.TabIndex = 128
        '
        'Txt_ExpenseMaster
        '
        Me.Txt_ExpenseMaster.BackColor = System.Drawing.Color.White
        Me.Txt_ExpenseMaster.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_ExpenseMaster.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_ExpenseMaster.Location = New System.Drawing.Point(50, 3)
        Me.Txt_ExpenseMaster.Name = "Txt_ExpenseMaster"
        Me.Txt_ExpenseMaster.Size = New System.Drawing.Size(196, 21)
        Me.Txt_ExpenseMaster.TabIndex = 4
        '
        'Tvw_ExpenseList
        '
        Me.Tvw_ExpenseList.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Tvw_ExpenseList.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Tvw_ExpenseList.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tvw_ExpenseList.ItemHeight = 22
        Me.Tvw_ExpenseList.Location = New System.Drawing.Point(1, 25)
        Me.Tvw_ExpenseList.Name = "Tvw_ExpenseList"
        Me.Tvw_ExpenseList.Size = New System.Drawing.Size(245, 329)
        Me.Tvw_ExpenseList.TabIndex = 127
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Transparent
        Me.Panel2.Controls.Add(Me.Lbl_TotalAmount)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Location = New System.Drawing.Point(555, 254)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(223, 20)
        Me.Panel2.TabIndex = 216
        '
        'Lbl_TotalAmount
        '
        Me.Lbl_TotalAmount.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_TotalAmount.ForeColor = System.Drawing.Color.DarkBlue
        Me.Lbl_TotalAmount.Location = New System.Drawing.Point(76, 4)
        Me.Lbl_TotalAmount.Name = "Lbl_TotalAmount"
        Me.Lbl_TotalAmount.Size = New System.Drawing.Size(147, 13)
        Me.Lbl_TotalAmount.TabIndex = 212
        Me.Lbl_TotalAmount.Text = "00.00"
        Me.Lbl_TotalAmount.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label3.Location = New System.Drawing.Point(3, 3)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(42, 13)
        Me.Label3.TabIndex = 211
        Me.Label3.Text = "Total :"
        '
        'Lbl_Words
        '
        Me.Lbl_Words.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Words.ForeColor = System.Drawing.Color.Maroon
        Me.Lbl_Words.Location = New System.Drawing.Point(269, 277)
        Me.Lbl_Words.Name = "Lbl_Words"
        Me.Lbl_Words.Size = New System.Drawing.Size(518, 18)
        Me.Lbl_Words.TabIndex = 217
        Me.Lbl_Words.Text = "Words"
        Me.Lbl_Words.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Discharge)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Report)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Uttility)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Cancel)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(308, 324)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(416, 35)
        Me.Pnl_Common_Btn.TabIndex = 218
        '
        'Btn_Discharge
        '
        Me.Btn_Discharge.BackgroundImage = CType(resources.GetObject("Btn_Discharge.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Discharge.CausesValidation = False
        Me.Btn_Discharge.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Discharge.Location = New System.Drawing.Point(279, 3)
        Me.Btn_Discharge.Name = "Btn_Discharge"
        Me.Btn_Discharge.Size = New System.Drawing.Size(76, 28)
        Me.Btn_Discharge.TabIndex = 19
        Me.Btn_Discharge.Text = "&Final Bill"
        Me.Btn_Discharge.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(355, 3)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 16
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Report
        '
        Me.Btn_Report.BackgroundImage = CType(resources.GetObject("Btn_Report.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Report.CausesValidation = False
        Me.Btn_Report.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Report.Location = New System.Drawing.Point(224, 3)
        Me.Btn_Report.Name = "Btn_Report"
        Me.Btn_Report.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Report.TabIndex = 18
        Me.Btn_Report.Text = "S&how"
        Me.Btn_Report.UseVisualStyleBackColor = True
        '
        'Btn_Uttility
        '
        Me.Btn_Uttility.BackgroundImage = CType(resources.GetObject("Btn_Uttility.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Uttility.CausesValidation = False
        Me.Btn_Uttility.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Uttility.Location = New System.Drawing.Point(169, 3)
        Me.Btn_Uttility.Name = "Btn_Uttility"
        Me.Btn_Uttility.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Uttility.TabIndex = 17
        Me.Btn_Uttility.Text = "&Uttility"
        Me.Btn_Uttility.UseVisualStyleBackColor = True
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(114, 3)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear.TabIndex = 15
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Cancel
        '
        Me.Btn_Cancel.BackgroundImage = CType(resources.GetObject("Btn_Cancel.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Cancel.Location = New System.Drawing.Point(59, 3)
        Me.Btn_Cancel.Name = "Btn_Cancel"
        Me.Btn_Cancel.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Cancel.TabIndex = 14
        Me.Btn_Cancel.Text = "C&ancel"
        Me.Btn_Cancel.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = CType(resources.GetObject("Btn_Save.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(4, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save.TabIndex = 13
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Btn_Add
        '
        Me.Btn_Add.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Add.BackgroundImage = CType(resources.GetObject("Btn_Add.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Add.ForeColor = System.Drawing.Color.White
        Me.Btn_Add.Location = New System.Drawing.Point(648, 66)
        Me.Btn_Add.Name = "Btn_Add"
        Me.Btn_Add.Size = New System.Drawing.Size(56, 29)
        Me.Btn_Add.TabIndex = 219
        Me.Btn_Add.Text = "&Add"
        Me.Btn_Add.UseVisualStyleBackColor = False
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(634, 23)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(74, 22)
        Me.Pnl_Tran_mode.TabIndex = 10001
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(3, 1)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(67, 16)
        Me.Lbl_Tran_Mode.TabIndex = 122
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Txt_Remarks
        '
        Me.Txt_Remarks.BackColor = System.Drawing.Color.White
        Me.Txt_Remarks.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Remarks.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Remarks.Location = New System.Drawing.Point(367, 297)
        Me.Txt_Remarks.MaxLength = 10
        Me.Txt_Remarks.Name = "Txt_Remarks"
        Me.Txt_Remarks.Size = New System.Drawing.Size(411, 21)
        Me.Txt_Remarks.TabIndex = 10002
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(269, 299)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(58, 13)
        Me.Label4.TabIndex = 10003
        Me.Label4.Text = "Remarks"
        '
        'Txt_BatchID
        '
        Me.Txt_BatchID.BackColor = System.Drawing.Color.White
        Me.Txt_BatchID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_BatchID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_BatchID.Location = New System.Drawing.Point(76, 70)
        Me.Txt_BatchID.MaxLength = 10
        Me.Txt_BatchID.Name = "Txt_BatchID"
        Me.Txt_BatchID.Size = New System.Drawing.Size(109, 21)
        Me.Txt_BatchID.TabIndex = 0
        Me.Txt_BatchID.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(8, 75)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(55, 13)
        Me.Label6.TabIndex = 10006
        Me.Label6.Text = "Batch ID"
        '
        'Btn_Cleargrid
        '
        Me.Btn_Cleargrid.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Cleargrid.BackgroundImage = CType(resources.GetObject("Btn_Cleargrid.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Cleargrid.ForeColor = System.Drawing.Color.White
        Me.Btn_Cleargrid.Location = New System.Drawing.Point(710, 66)
        Me.Btn_Cleargrid.Name = "Btn_Cleargrid"
        Me.Btn_Cleargrid.Size = New System.Drawing.Size(56, 29)
        Me.Btn_Cleargrid.TabIndex = 10007
        Me.Btn_Cleargrid.Text = "&Clear"
        Me.Btn_Cleargrid.UseVisualStyleBackColor = False
        '
        'Pnl_History
        '
        Me.Pnl_History.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.MainMenu_Bkg
        Me.Pnl_History.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_History.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Pnl_History.Controls.Add(Me.Label27)
        Me.Pnl_History.Controls.Add(Me.Txt_PMR_ID)
        Me.Pnl_History.Controls.Add(Me.Btn_FindOP)
        Me.Pnl_History.Controls.Add(Me.Label11)
        Me.Pnl_History.Controls.Add(Me.Label10)
        Me.Pnl_History.Controls.Add(Me.Label9)
        Me.Pnl_History.Controls.Add(Me.Label8)
        Me.Pnl_History.Controls.Add(Me.Btn_CloseHistory)
        Me.Pnl_History.Controls.Add(Me.Btn_ShowHistory)
        Me.Pnl_History.Controls.Add(Me.Cmb_PayStatus)
        Me.Pnl_History.Controls.Add(Me.Dtp_ToDate)
        Me.Pnl_History.Controls.Add(Me.Dtp_FrmDate)
        Me.Pnl_History.Location = New System.Drawing.Point(269, 5)
        Me.Pnl_History.Name = "Pnl_History"
        Me.Pnl_History.Size = New System.Drawing.Size(355, 165)
        Me.Pnl_History.TabIndex = 10011
        Me.Pnl_History.Visible = False
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.BackColor = System.Drawing.Color.Transparent
        Me.Label27.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.ForeColor = System.Drawing.Color.Black
        Me.Label27.Location = New System.Drawing.Point(41, 37)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(45, 14)
        Me.Label27.TabIndex = 100015
        Me.Label27.Text = "PMR-ID"
        '
        'Txt_PMR_ID
        '
        Me.Txt_PMR_ID.BackColor = System.Drawing.Color.White
        Me.Txt_PMR_ID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_PMR_ID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PMR_ID.Location = New System.Drawing.Point(88, 35)
        Me.Txt_PMR_ID.MaxLength = 10
        Me.Txt_PMR_ID.Name = "Txt_PMR_ID"
        Me.Txt_PMR_ID.Size = New System.Drawing.Size(138, 21)
        Me.Txt_PMR_ID.TabIndex = 100002
        '
        'Btn_FindOP
        '
        Me.Btn_FindOP.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_FindOP.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_FindOP.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_FindOP.ForeColor = System.Drawing.Color.White
        Me.Btn_FindOP.Location = New System.Drawing.Point(230, 35)
        Me.Btn_FindOP.Name = "Btn_FindOP"
        Me.Btn_FindOP.Size = New System.Drawing.Size(29, 21)
        Me.Btn_FindOP.TabIndex = 100003
        Me.Btn_FindOP.TabStop = False
        Me.Btn_FindOP.Text = "F2"
        Me.Btn_FindOP.UseVisualStyleBackColor = False
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.Color.Blue
        Me.Label11.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(-2, 1)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(352, 21)
        Me.Label11.TabIndex = 100001
        Me.Label11.Text = "T r a n s a c t i o n   H i s t o r y"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(41, 107)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(98, 13)
        Me.Label10.TabIndex = 10012
        Me.Label10.Text = "Payment Status"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(161, 59)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(21, 13)
        Me.Label9.TabIndex = 10011
        Me.Label9.Text = "To"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(41, 59)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(39, 13)
        Me.Label8.TabIndex = 10010
        Me.Label8.Text = "From "
        '
        'Btn_CloseHistory
        '
        Me.Btn_CloseHistory.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_CloseHistory.BackgroundImage = CType(resources.GetObject("Btn_CloseHistory.BackgroundImage"), System.Drawing.Image)
        Me.Btn_CloseHistory.ForeColor = System.Drawing.Color.White
        Me.Btn_CloseHistory.Location = New System.Drawing.Point(259, 120)
        Me.Btn_CloseHistory.Name = "Btn_CloseHistory"
        Me.Btn_CloseHistory.Size = New System.Drawing.Size(56, 23)
        Me.Btn_CloseHistory.TabIndex = 10009
        Me.Btn_CloseHistory.Text = "&Close"
        Me.Btn_CloseHistory.UseVisualStyleBackColor = False
        '
        'Btn_ShowHistory
        '
        Me.Btn_ShowHistory.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_ShowHistory.BackgroundImage = CType(resources.GetObject("Btn_ShowHistory.BackgroundImage"), System.Drawing.Image)
        Me.Btn_ShowHistory.ForeColor = System.Drawing.Color.White
        Me.Btn_ShowHistory.Location = New System.Drawing.Point(203, 120)
        Me.Btn_ShowHistory.Name = "Btn_ShowHistory"
        Me.Btn_ShowHistory.Size = New System.Drawing.Size(56, 23)
        Me.Btn_ShowHistory.TabIndex = 10008
        Me.Btn_ShowHistory.Text = "&Show"
        Me.Btn_ShowHistory.UseVisualStyleBackColor = False
        '
        'Cmb_PayStatus
        '
        Me.Cmb_PayStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_PayStatus.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_PayStatus.FormattingEnabled = True
        Me.Cmb_PayStatus.ItemHeight = 13
        Me.Cmb_PayStatus.Location = New System.Drawing.Point(44, 122)
        Me.Cmb_PayStatus.Name = "Cmb_PayStatus"
        Me.Cmb_PayStatus.Size = New System.Drawing.Size(155, 21)
        Me.Cmb_PayStatus.TabIndex = 15
        '
        'Dtp_ToDate
        '
        Me.Dtp_ToDate.Cursor = System.Windows.Forms.Cursors.Default
        Me.Dtp_ToDate.CustomFormat = "dd/MM/yyyy"
        Me.Dtp_ToDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_ToDate.Location = New System.Drawing.Point(164, 75)
        Me.Dtp_ToDate.Name = "Dtp_ToDate"
        Me.Dtp_ToDate.Size = New System.Drawing.Size(98, 21)
        Me.Dtp_ToDate.TabIndex = 14
        Me.Dtp_ToDate.TabStop = False
        '
        'Dtp_FrmDate
        '
        Me.Dtp_FrmDate.Cursor = System.Windows.Forms.Cursors.Default
        Me.Dtp_FrmDate.CustomFormat = "dd/MM/yyyy"
        Me.Dtp_FrmDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_FrmDate.Location = New System.Drawing.Point(44, 75)
        Me.Dtp_FrmDate.Name = "Dtp_FrmDate"
        Me.Dtp_FrmDate.Size = New System.Drawing.Size(98, 21)
        Me.Dtp_FrmDate.TabIndex = 13
        Me.Dtp_FrmDate.TabStop = False
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(4, 171)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(788, 390)
        Me.TabControl1.TabIndex = 10012
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.Transparent
        Me.TabPage1.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.LeftGradiant
        Me.TabPage1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TabPage1.Controls.Add(Me.Dgv_PatientTran_Grid)
        Me.TabPage1.Controls.Add(Me.Label24)
        Me.TabPage1.Controls.Add(Me.Cmb_DebitDep)
        Me.TabPage1.Controls.Add(Me.Pnl_History)
        Me.TabPage1.Controls.Add(Me.Txt_Tran_BatchID)
        Me.TabPage1.Controls.Add(Me.Label7)
        Me.TabPage1.Controls.Add(Me.Cmb_Payment_Mode)
        Me.TabPage1.Controls.Add(Me.Txt_BillBatchNO)
        Me.TabPage1.Controls.Add(Me.Panel1)
        Me.TabPage1.Controls.Add(Me.Trancontrol1)
        Me.TabPage1.Controls.Add(Me.Btn_Cleargrid)
        Me.TabPage1.Controls.Add(Me.Dgv_PatientBill_Grid)
        Me.TabPage1.Controls.Add(Me.Panel2)
        Me.TabPage1.Controls.Add(Me.Lbl_Words)
        Me.TabPage1.Controls.Add(Me.Txt_Remarks)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.Btn_Add)
        Me.TabPage1.Controls.Add(Me.Pnl_Common_Btn)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(780, 364)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = " B i l l i n g   S e c t i o n                                         "
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Dgv_PatientTran_Grid
        '
        Me.Dgv_PatientTran_Grid.AllowUserToAddRows = False
        Me.Dgv_PatientTran_Grid.AllowUserToDeleteRows = False
        Me.Dgv_PatientTran_Grid.AllowUserToResizeColumns = False
        Me.Dgv_PatientTran_Grid.AllowUserToResizeRows = False
        Me.Dgv_PatientTran_Grid.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(118, Byte), Integer), CType(CType(155, Byte), Integer), CType(CType(197, Byte), Integer))
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(87, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(162, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.AliceBlue
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgv_PatientTran_Grid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.Dgv_PatientTran_Grid.ColumnHeadersHeight = 25
        Me.Dgv_PatientTran_Grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.Dgv_PatientTran_Grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3})
        Me.Dgv_PatientTran_Grid.Location = New System.Drawing.Point(654, 6)
        Me.Dgv_PatientTran_Grid.Name = "Dgv_PatientTran_Grid"
        Me.Dgv_PatientTran_Grid.ReadOnly = True
        Me.Dgv_PatientTran_Grid.RowHeadersVisible = False
        Me.Dgv_PatientTran_Grid.Size = New System.Drawing.Size(120, 51)
        Me.Dgv_PatientTran_Grid.TabIndex = 10008
        Me.Dgv_PatientTran_Grid.TabStop = False
        Me.Dgv_PatientTran_Grid.Visible = False
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.HeaderText = "Expense"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Width = 300
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.HeaderText = "Amount"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.Width = 220
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.HeaderText = "Exp_ID"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        Me.DataGridViewTextBoxColumn3.Visible = False
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.BackColor = System.Drawing.Color.Transparent
        Me.Label24.ForeColor = System.Drawing.Color.Black
        Me.Label24.Location = New System.Drawing.Point(651, 100)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(115, 13)
        Me.Label24.TabIndex = 10015
        Me.Label24.Text = "Debit From Deposit"
        '
        'Cmb_DebitDep
        '
        Me.Cmb_DebitDep.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.Cmb_DebitDep.CausesValidation = False
        Me.Cmb_DebitDep.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_DebitDep.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_DebitDep.FormattingEnabled = True
        Me.Cmb_DebitDep.ItemHeight = 13
        Me.Cmb_DebitDep.Location = New System.Drawing.Point(647, 116)
        Me.Cmb_DebitDep.Name = "Cmb_DebitDep"
        Me.Cmb_DebitDep.Size = New System.Drawing.Size(131, 21)
        Me.Cmb_DebitDep.TabIndex = 10014
        '
        'Txt_Tran_BatchID
        '
        Me.Txt_Tran_BatchID.BackColor = System.Drawing.Color.White
        Me.Txt_Tran_BatchID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Tran_BatchID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Tran_BatchID.Location = New System.Drawing.Point(652, 32)
        Me.Txt_Tran_BatchID.MaxLength = 10
        Me.Txt_Tran_BatchID.Name = "Txt_Tran_BatchID"
        Me.Txt_Tran_BatchID.Size = New System.Drawing.Size(126, 21)
        Me.Txt_Tran_BatchID.TabIndex = 10013
        Me.Txt_Tran_BatchID.Visible = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(269, 256)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(92, 13)
        Me.Label7.TabIndex = 10012
        Me.Label7.Text = "Payment Mode"
        '
        'Cmb_Payment_Mode
        '
        Me.Cmb_Payment_Mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.Cmb_Payment_Mode.CausesValidation = False
        Me.Cmb_Payment_Mode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Payment_Mode.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Payment_Mode.FormattingEnabled = True
        Me.Cmb_Payment_Mode.ItemHeight = 13
        Me.Cmb_Payment_Mode.Location = New System.Drawing.Point(367, 253)
        Me.Cmb_Payment_Mode.Name = "Cmb_Payment_Mode"
        Me.Cmb_Payment_Mode.Size = New System.Drawing.Size(143, 21)
        Me.Cmb_Payment_Mode.TabIndex = 10011
        '
        'Txt_BillBatchNO
        '
        Me.Txt_BillBatchNO.BackColor = System.Drawing.Color.White
        Me.Txt_BillBatchNO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_BillBatchNO.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_BillBatchNO.Location = New System.Drawing.Point(652, 12)
        Me.Txt_BillBatchNO.MaxLength = 10
        Me.Txt_BillBatchNO.Name = "Txt_BillBatchNO"
        Me.Txt_BillBatchNO.Size = New System.Drawing.Size(126, 21)
        Me.Txt_BillBatchNO.TabIndex = 10009
        Me.Txt_BillBatchNO.Visible = False
        '
        'Trancontrol1
        '
        Me.Trancontrol1.BackColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(123, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Trancontrol1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Trancontrol1.Location = New System.Drawing.Point(269, 5)
        Me.Trancontrol1.Name = "Trancontrol1"
        Me.Trancontrol1.Padding = New System.Windows.Forms.Padding(3)
        Me.Trancontrol1.Size = New System.Drawing.Size(369, 135)
        Me.Trancontrol1.TabIndex = 123
        '
        'Dgv_PatientBill_Grid
        '
        Me.Dgv_PatientBill_Grid.AllowUserToAddRows = False
        Me.Dgv_PatientBill_Grid.AllowUserToDeleteRows = False
        Me.Dgv_PatientBill_Grid.AllowUserToResizeColumns = False
        Me.Dgv_PatientBill_Grid.AllowUserToResizeRows = False
        Me.Dgv_PatientBill_Grid.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(118, Byte), Integer), CType(CType(155, Byte), Integer), CType(CType(197, Byte), Integer))
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(87, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(162, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.AliceBlue
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgv_PatientBill_Grid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.Dgv_PatientBill_Grid.ColumnHeadersHeight = 25
        Me.Dgv_PatientBill_Grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.Dgv_PatientBill_Grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Expense, Me.Particulars, Me.Amount, Me.Acc_Code, Me.Exp_Subtype, Me.Def_TranType, Me.Editable, Me.Exp_ID})
        Me.Dgv_PatientBill_Grid.Location = New System.Drawing.Point(269, 146)
        Me.Dgv_PatientBill_Grid.Name = "Dgv_PatientBill_Grid"
        Me.Dgv_PatientBill_Grid.ReadOnly = True
        Me.Dgv_PatientBill_Grid.RowHeadersVisible = False
        Me.Dgv_PatientBill_Grid.Size = New System.Drawing.Size(521, 104)
        Me.Dgv_PatientBill_Grid.TabIndex = 127
        Me.Dgv_PatientBill_Grid.TabStop = False
        '
        'Expense
        '
        Me.Expense.HeaderText = "Expense"
        Me.Expense.Name = "Expense"
        Me.Expense.ReadOnly = True
        Me.Expense.Width = 215
        '
        'Particulars
        '
        Me.Particulars.HeaderText = "Particulars"
        Me.Particulars.Name = "Particulars"
        Me.Particulars.ReadOnly = True
        Me.Particulars.Width = 160
        '
        'Amount
        '
        Me.Amount.HeaderText = "Amount"
        Me.Amount.Name = "Amount"
        Me.Amount.ReadOnly = True
        Me.Amount.Width = 140
        '
        'Acc_Code
        '
        Me.Acc_Code.HeaderText = "Acc_Code"
        Me.Acc_Code.Name = "Acc_Code"
        Me.Acc_Code.ReadOnly = True
        Me.Acc_Code.Visible = False
        '
        'Exp_Subtype
        '
        Me.Exp_Subtype.HeaderText = "Exp_Subtype"
        Me.Exp_Subtype.Name = "Exp_Subtype"
        Me.Exp_Subtype.ReadOnly = True
        Me.Exp_Subtype.Visible = False
        '
        'Def_TranType
        '
        Me.Def_TranType.HeaderText = "Def_TranType"
        Me.Def_TranType.Name = "Def_TranType"
        Me.Def_TranType.ReadOnly = True
        Me.Def_TranType.Visible = False
        '
        'Editable
        '
        Me.Editable.HeaderText = "Editable"
        Me.Editable.Name = "Editable"
        Me.Editable.ReadOnly = True
        Me.Editable.Visible = False
        '
        'Exp_ID
        '
        Me.Exp_ID.HeaderText = "Exp_ID"
        Me.Exp_ID.Name = "Exp_ID"
        Me.Exp_ID.ReadOnly = True
        Me.Exp_ID.Visible = False
        '
        'TabPage2
        '
        Me.TabPage2.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.LeftGradiant
        Me.TabPage2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TabPage2.Controls.Add(Me.ChkAll)
        Me.TabPage2.Controls.Add(Me.Label25)
        Me.TabPage2.Controls.Add(Me.Cmb_debitfromDeposit)
        Me.TabPage2.Controls.Add(Me.Btn_ProcessAllPending)
        Me.TabPage2.Controls.Add(Me.Btn_GenerateBill)
        Me.TabPage2.Controls.Add(Me.Dgv_PendingBills)
        Me.TabPage2.Controls.Add(Me.Panel4)
        Me.TabPage2.Controls.Add(Me.Label12)
        Me.TabPage2.Controls.Add(Me.Lbl_Wrds)
        Me.TabPage2.Controls.Add(Me.Txt_Remark)
        Me.TabPage2.Controls.Add(Me.Label14)
        Me.TabPage2.Controls.Add(Me.Cmb_PamentMode)
        Me.TabPage2.Controls.Add(Me.Label15)
        Me.TabPage2.Controls.Add(Me.Panel3)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(780, 364)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "P e n d i n g   B i l l i n g   S e c t i o n"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'ChkAll
        '
        Me.ChkAll.AutoSize = True
        Me.ChkAll.BackColor = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(131, Byte), Integer), CType(CType(157, Byte), Integer))
        Me.ChkAll.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.ChkAll.Location = New System.Drawing.Point(675, 19)
        Me.ChkAll.Name = "ChkAll"
        Me.ChkAll.Size = New System.Drawing.Size(78, 17)
        Me.ChkAll.TabIndex = 10025
        Me.ChkAll.Text = "Select All"
        Me.ChkAll.UseVisualStyleBackColor = False
        Me.ChkAll.Visible = False
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.BackColor = System.Drawing.Color.Transparent
        Me.Label25.ForeColor = System.Drawing.Color.Black
        Me.Label25.Location = New System.Drawing.Point(12, 250)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(115, 13)
        Me.Label25.TabIndex = 10024
        Me.Label25.Text = "Debit From Deposit"
        '
        'Cmb_debitfromDeposit
        '
        Me.Cmb_debitfromDeposit.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.Cmb_debitfromDeposit.CausesValidation = False
        Me.Cmb_debitfromDeposit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_debitfromDeposit.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_debitfromDeposit.FormattingEnabled = True
        Me.Cmb_debitfromDeposit.ItemHeight = 13
        Me.Cmb_debitfromDeposit.Location = New System.Drawing.Point(130, 246)
        Me.Cmb_debitfromDeposit.Name = "Cmb_debitfromDeposit"
        Me.Cmb_debitfromDeposit.Size = New System.Drawing.Size(72, 21)
        Me.Cmb_debitfromDeposit.TabIndex = 10023
        '
        'Btn_ProcessAllPending
        '
        Me.Btn_ProcessAllPending.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_ProcessAllPending.ForeColor = System.Drawing.Color.White
        Me.Btn_ProcessAllPending.Location = New System.Drawing.Point(208, 19)
        Me.Btn_ProcessAllPending.Name = "Btn_ProcessAllPending"
        Me.Btn_ProcessAllPending.Size = New System.Drawing.Size(187, 28)
        Me.Btn_ProcessAllPending.TabIndex = 10022
        Me.Btn_ProcessAllPending.Text = "&Generate Pending Bills All"
        Me.Btn_ProcessAllPending.UseVisualStyleBackColor = False
        '
        'Btn_GenerateBill
        '
        Me.Btn_GenerateBill.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_GenerateBill.ForeColor = System.Drawing.Color.White
        Me.Btn_GenerateBill.Location = New System.Drawing.Point(15, 19)
        Me.Btn_GenerateBill.Name = "Btn_GenerateBill"
        Me.Btn_GenerateBill.Size = New System.Drawing.Size(187, 28)
        Me.Btn_GenerateBill.TabIndex = 10021
        Me.Btn_GenerateBill.Text = "&Generate Pending Bills"
        Me.Btn_GenerateBill.UseVisualStyleBackColor = False
        '
        'Dgv_PendingBills
        '
        Me.Dgv_PendingBills.AllowUserToAddRows = False
        Me.Dgv_PendingBills.AllowUserToDeleteRows = False
        Me.Dgv_PendingBills.AllowUserToResizeColumns = False
        Me.Dgv_PendingBills.AllowUserToResizeRows = False
        Me.Dgv_PendingBills.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(118, Byte), Integer), CType(CType(155, Byte), Integer), CType(CType(197, Byte), Integer))
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(87, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(162, Byte), Integer))
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.AliceBlue
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgv_PendingBills.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.Dgv_PendingBills.ColumnHeadersHeight = 25
        Me.Dgv_PendingBills.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.Dgv_PendingBills.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Mark, Me.SerialNo, Me.BillDate, Me.ExpenseParticulars, Me.ExpenseAmount, Me.Bill_BatchNo, Me.PatientTranBatchID, Me.Bill_ID})
        Me.Dgv_PendingBills.Location = New System.Drawing.Point(15, 53)
        Me.Dgv_PendingBills.Name = "Dgv_PendingBills"
        Me.Dgv_PendingBills.RowHeadersVisible = False
        Me.Dgv_PendingBills.Size = New System.Drawing.Size(685, 188)
        Me.Dgv_PendingBills.TabIndex = 10020
        Me.Dgv_PendingBills.TabStop = False
        '
        'Mark
        '
        Me.Mark.HeaderText = ""
        Me.Mark.Name = "Mark"
        Me.Mark.Width = 50
        '
        'SerialNo
        '
        Me.SerialNo.HeaderText = "SlNO"
        Me.SerialNo.Name = "SerialNo"
        Me.SerialNo.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.SerialNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.SerialNo.Width = 30
        '
        'BillDate
        '
        Me.BillDate.HeaderText = "Bill Date"
        Me.BillDate.Name = "BillDate"
        Me.BillDate.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.BillDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'ExpenseParticulars
        '
        Me.ExpenseParticulars.HeaderText = "Expense Details"
        Me.ExpenseParticulars.Name = "ExpenseParticulars"
        Me.ExpenseParticulars.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.ExpenseParticulars.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.ExpenseParticulars.Width = 250
        '
        'ExpenseAmount
        '
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.ExpenseAmount.DefaultCellStyle = DataGridViewCellStyle4
        Me.ExpenseAmount.HeaderText = "Amount"
        Me.ExpenseAmount.Name = "ExpenseAmount"
        Me.ExpenseAmount.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.ExpenseAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.ExpenseAmount.Width = 150
        '
        'Bill_BatchNo
        '
        Me.Bill_BatchNo.HeaderText = "Bill_BatchNo"
        Me.Bill_BatchNo.Name = "Bill_BatchNo"
        '
        'PatientTranBatchID
        '
        Me.PatientTranBatchID.HeaderText = "PatientTran_BatchID"
        Me.PatientTranBatchID.Name = "PatientTranBatchID"
        Me.PatientTranBatchID.Visible = False
        '
        'Bill_ID
        '
        Me.Bill_ID.HeaderText = ""
        Me.Bill_ID.Name = "Bill_ID"
        Me.Bill_ID.Visible = False
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.Transparent
        Me.Panel4.Controls.Add(Me.Lbl_TotUnpaid)
        Me.Panel4.Controls.Add(Me.Label17)
        Me.Panel4.Location = New System.Drawing.Point(465, 247)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(235, 20)
        Me.Panel4.TabIndex = 10019
        '
        'Lbl_TotUnpaid
        '
        Me.Lbl_TotUnpaid.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_TotUnpaid.ForeColor = System.Drawing.Color.DarkBlue
        Me.Lbl_TotUnpaid.Location = New System.Drawing.Point(86, 3)
        Me.Lbl_TotUnpaid.Name = "Lbl_TotUnpaid"
        Me.Lbl_TotUnpaid.Size = New System.Drawing.Size(147, 13)
        Me.Lbl_TotUnpaid.TabIndex = 212
        Me.Lbl_TotUnpaid.Text = "00.00"
        Me.Lbl_TotUnpaid.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label17.Location = New System.Drawing.Point(3, 3)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(42, 13)
        Me.Label17.TabIndex = 211
        Me.Label17.Text = "Total :"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.ForeColor = System.Drawing.Color.Black
        Me.Label12.Location = New System.Drawing.Point(201, 249)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(92, 13)
        Me.Label12.TabIndex = 10018
        Me.Label12.Text = "Payment Mode"
        '
        'Lbl_Wrds
        '
        Me.Lbl_Wrds.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Wrds.ForeColor = System.Drawing.Color.Maroon
        Me.Lbl_Wrds.Location = New System.Drawing.Point(15, 271)
        Me.Lbl_Wrds.Name = "Lbl_Wrds"
        Me.Lbl_Wrds.Size = New System.Drawing.Size(661, 24)
        Me.Lbl_Wrds.TabIndex = 10014
        Me.Lbl_Wrds.Text = "Words"
        Me.Lbl_Wrds.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Txt_Remark
        '
        Me.Txt_Remark.BackColor = System.Drawing.Color.White
        Me.Txt_Remark.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Remark.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Remark.Location = New System.Drawing.Point(105, 295)
        Me.Txt_Remark.MaxLength = 10
        Me.Txt_Remark.Name = "Txt_Remark"
        Me.Txt_Remark.Size = New System.Drawing.Size(453, 21)
        Me.Txt_Remark.TabIndex = 10015
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label14.Location = New System.Drawing.Point(-43, -42)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(42, 13)
        Me.Label14.TabIndex = 10013
        Me.Label14.Text = "Total :"
        '
        'Cmb_PamentMode
        '
        Me.Cmb_PamentMode.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.Cmb_PamentMode.CausesValidation = False
        Me.Cmb_PamentMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_PamentMode.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_PamentMode.FormattingEnabled = True
        Me.Cmb_PamentMode.ItemHeight = 13
        Me.Cmb_PamentMode.Location = New System.Drawing.Point(294, 246)
        Me.Cmb_PamentMode.Name = "Cmb_PamentMode"
        Me.Cmb_PamentMode.Size = New System.Drawing.Size(143, 21)
        Me.Cmb_PamentMode.TabIndex = 10017
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.Black
        Me.Label15.Location = New System.Drawing.Point(12, 297)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(58, 13)
        Me.Label15.TabIndex = 10016
        Me.Label15.Text = "Remarks"
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.Btn_Close1)
        Me.Panel3.Controls.Add(Me.Btn_Show1)
        Me.Panel3.Controls.Add(Me.Btn_Uttility1)
        Me.Panel3.Controls.Add(Me.Btn_Clear1)
        Me.Panel3.Controls.Add(Me.Btn_Cancel1)
        Me.Panel3.Controls.Add(Me.Btn_Save1)
        Me.Panel3.ForeColor = System.Drawing.Color.White
        Me.Panel3.Location = New System.Drawing.Point(125, 322)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(341, 35)
        Me.Panel3.TabIndex = 219
        '
        'Btn_Close1
        '
        Me.Btn_Close1.BackgroundImage = CType(resources.GetObject("Btn_Close1.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close1.CausesValidation = False
        Me.Btn_Close1.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close1.Location = New System.Drawing.Point(279, 3)
        Me.Btn_Close1.Name = "Btn_Close1"
        Me.Btn_Close1.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close1.TabIndex = 16
        Me.Btn_Close1.Text = "&Close"
        Me.Btn_Close1.UseVisualStyleBackColor = True
        '
        'Btn_Show1
        '
        Me.Btn_Show1.BackgroundImage = CType(resources.GetObject("Btn_Show1.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Show1.CausesValidation = False
        Me.Btn_Show1.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Show1.Location = New System.Drawing.Point(224, 3)
        Me.Btn_Show1.Name = "Btn_Show1"
        Me.Btn_Show1.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Show1.TabIndex = 18
        Me.Btn_Show1.Text = "S&how"
        Me.Btn_Show1.UseVisualStyleBackColor = True
        '
        'Btn_Uttility1
        '
        Me.Btn_Uttility1.BackgroundImage = CType(resources.GetObject("Btn_Uttility1.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Uttility1.CausesValidation = False
        Me.Btn_Uttility1.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Uttility1.Location = New System.Drawing.Point(169, 3)
        Me.Btn_Uttility1.Name = "Btn_Uttility1"
        Me.Btn_Uttility1.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Uttility1.TabIndex = 17
        Me.Btn_Uttility1.Text = "&Uttility"
        Me.Btn_Uttility1.UseVisualStyleBackColor = True
        '
        'Btn_Clear1
        '
        Me.Btn_Clear1.BackgroundImage = CType(resources.GetObject("Btn_Clear1.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear1.CausesValidation = False
        Me.Btn_Clear1.Location = New System.Drawing.Point(114, 3)
        Me.Btn_Clear1.Name = "Btn_Clear1"
        Me.Btn_Clear1.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear1.TabIndex = 15
        Me.Btn_Clear1.Text = "C&lear"
        Me.Btn_Clear1.UseVisualStyleBackColor = True
        '
        'Btn_Cancel1
        '
        Me.Btn_Cancel1.BackgroundImage = CType(resources.GetObject("Btn_Cancel1.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Cancel1.Enabled = False
        Me.Btn_Cancel1.Location = New System.Drawing.Point(59, 3)
        Me.Btn_Cancel1.Name = "Btn_Cancel1"
        Me.Btn_Cancel1.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Cancel1.TabIndex = 14
        Me.Btn_Cancel1.Text = "C&ancel"
        Me.Btn_Cancel1.UseVisualStyleBackColor = True
        '
        'Btn_Save1
        '
        Me.Btn_Save1.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save1.BackgroundImage = CType(resources.GetObject("Btn_Save1.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Save1.ForeColor = System.Drawing.Color.White
        Me.Btn_Save1.Location = New System.Drawing.Point(4, 3)
        Me.Btn_Save1.Name = "Btn_Save1"
        Me.Btn_Save1.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save1.TabIndex = 13
        Me.Btn_Save1.Text = "&Save"
        Me.Btn_Save1.UseVisualStyleBackColor = False
        '
        'Btn_Showtran
        '
        Me.Btn_Showtran.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Showtran.BackgroundImage = CType(resources.GetObject("Btn_Showtran.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Showtran.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Showtran.ForeColor = System.Drawing.Color.White
        Me.Btn_Showtran.Location = New System.Drawing.Point(391, 45)
        Me.Btn_Showtran.Name = "Btn_Showtran"
        Me.Btn_Showtran.Size = New System.Drawing.Size(209, 28)
        Me.Btn_Showtran.TabIndex = 10016
        Me.Btn_Showtran.Text = "Show Transaction History"
        Me.Btn_Showtran.UseVisualStyleBackColor = False
        '
        'Txt_Trandate
        '
        Me.Txt_Trandate.BackColor = System.Drawing.Color.White
        Me.Txt_Trandate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Trandate.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Trandate.Location = New System.Drawing.Point(714, 23)
        Me.Txt_Trandate.MaxLength = 10
        Me.Txt_Trandate.Name = "Txt_Trandate"
        Me.Txt_Trandate.Size = New System.Drawing.Size(95, 21)
        Me.Txt_Trandate.TabIndex = 100006
        Me.Txt_Trandate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Txt_DepositBalance
        '
        Me.Txt_DepositBalance.BackColor = System.Drawing.Color.White
        Me.Txt_DepositBalance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_DepositBalance.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_DepositBalance.Location = New System.Drawing.Point(393, 128)
        Me.Txt_DepositBalance.MaxLength = 10
        Me.Txt_DepositBalance.Name = "Txt_DepositBalance"
        Me.Txt_DepositBalance.ReadOnly = True
        Me.Txt_DepositBalance.Size = New System.Drawing.Size(207, 24)
        Me.Txt_DepositBalance.TabIndex = 100007
        Me.Txt_DepositBalance.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Pnl_Details
        '
        Me.Pnl_Details.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Details.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Pnl_Details.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Details.Controls.Add(Me.Pnl_CreditPosition)
        Me.Pnl_Details.Controls.Add(Me.Pct_UPDown)
        Me.Pnl_Details.Controls.Add(Me.Label22)
        Me.Pnl_Details.Location = New System.Drawing.Point(393, 79)
        Me.Pnl_Details.Name = "Pnl_Details"
        Me.Pnl_Details.Size = New System.Drawing.Size(207, 22)
        Me.Pnl_Details.TabIndex = 100008
        '
        'Pnl_CreditPosition
        '
        Me.Pnl_CreditPosition.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_CreditPosition.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Pnl_CreditPosition.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_CreditPosition.Controls.Add(Me.Lbl_UnPaid_BillAmt)
        Me.Pnl_CreditPosition.Controls.Add(Me.Label16)
        Me.Pnl_CreditPosition.Controls.Add(Me.Label18)
        Me.Pnl_CreditPosition.Controls.Add(Me.Lbl_BalanceAmt)
        Me.Pnl_CreditPosition.Controls.Add(Me.Lbl_Paid_BillAmt)
        Me.Pnl_CreditPosition.Controls.Add(Me.Lbl_DepositAmt)
        Me.Pnl_CreditPosition.Controls.Add(Me.Label19)
        Me.Pnl_CreditPosition.Controls.Add(Me.Label20)
        Me.Pnl_CreditPosition.Controls.Add(Me.Label21)
        Me.Pnl_CreditPosition.Location = New System.Drawing.Point(5, 23)
        Me.Pnl_CreditPosition.Name = "Pnl_CreditPosition"
        Me.Pnl_CreditPosition.Size = New System.Drawing.Size(198, 102)
        Me.Pnl_CreditPosition.TabIndex = 10017
        '
        'Lbl_UnPaid_BillAmt
        '
        Me.Lbl_UnPaid_BillAmt.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_UnPaid_BillAmt.ForeColor = System.Drawing.Color.White
        Me.Lbl_UnPaid_BillAmt.Location = New System.Drawing.Point(110, 44)
        Me.Lbl_UnPaid_BillAmt.Name = "Lbl_UnPaid_BillAmt"
        Me.Lbl_UnPaid_BillAmt.Size = New System.Drawing.Size(81, 19)
        Me.Lbl_UnPaid_BillAmt.TabIndex = 10015
        Me.Lbl_UnPaid_BillAmt.Text = "Bill"
        Me.Lbl_UnPaid_BillAmt.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label16
        '
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(1, 47)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(108, 16)
        Me.Label16.TabIndex = 10014
        Me.Label16.Text = "Unpaid Bills"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.Transparent
        Me.Label18.ForeColor = System.Drawing.Color.White
        Me.Label18.Location = New System.Drawing.Point(3, 54)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(245, 13)
        Me.Label18.TabIndex = 10013
        Me.Label18.Text = "__________________________________"
        '
        'Lbl_BalanceAmt
        '
        Me.Lbl_BalanceAmt.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_BalanceAmt.ForeColor = System.Drawing.Color.White
        Me.Lbl_BalanceAmt.Location = New System.Drawing.Point(91, 68)
        Me.Lbl_BalanceAmt.Name = "Lbl_BalanceAmt"
        Me.Lbl_BalanceAmt.Size = New System.Drawing.Size(100, 19)
        Me.Lbl_BalanceAmt.TabIndex = 10012
        Me.Lbl_BalanceAmt.Text = "Balance Amount"
        Me.Lbl_BalanceAmt.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Lbl_Paid_BillAmt
        '
        Me.Lbl_Paid_BillAmt.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Paid_BillAmt.ForeColor = System.Drawing.Color.White
        Me.Lbl_Paid_BillAmt.Location = New System.Drawing.Point(94, 23)
        Me.Lbl_Paid_BillAmt.Name = "Lbl_Paid_BillAmt"
        Me.Lbl_Paid_BillAmt.Size = New System.Drawing.Size(97, 19)
        Me.Lbl_Paid_BillAmt.TabIndex = 10011
        Me.Lbl_Paid_BillAmt.Text = "Bill"
        Me.Lbl_Paid_BillAmt.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Lbl_DepositAmt
        '
        Me.Lbl_DepositAmt.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_DepositAmt.ForeColor = System.Drawing.Color.White
        Me.Lbl_DepositAmt.Location = New System.Drawing.Point(96, 0)
        Me.Lbl_DepositAmt.Name = "Lbl_DepositAmt"
        Me.Lbl_DepositAmt.Size = New System.Drawing.Size(95, 19)
        Me.Lbl_DepositAmt.TabIndex = 10010
        Me.Lbl_DepositAmt.Text = "Deposits"
        Me.Lbl_DepositAmt.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.ForeColor = System.Drawing.Color.White
        Me.Label19.Location = New System.Drawing.Point(1, 71)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(51, 13)
        Me.Label19.TabIndex = 10009
        Me.Label19.Text = "Balance"
        '
        'Label20
        '
        Me.Label20.BackColor = System.Drawing.Color.Transparent
        Me.Label20.ForeColor = System.Drawing.Color.White
        Me.Label20.Location = New System.Drawing.Point(1, 26)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(108, 16)
        Me.Label20.TabIndex = 10008
        Me.Label20.Text = "Paid Bills"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.Color.Transparent
        Me.Label21.ForeColor = System.Drawing.Color.White
        Me.Label21.Location = New System.Drawing.Point(1, 4)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(56, 13)
        Me.Label21.TabIndex = 10007
        Me.Label21.Text = "Deposits"
        '
        'Pct_UPDown
        '
        Me.Pct_UPDown.Image = Global.REAL_CLINIC.My.Resources.Resources.downArrow
        Me.Pct_UPDown.Location = New System.Drawing.Point(183, 0)
        Me.Pct_UPDown.Name = "Pct_UPDown"
        Me.Pct_UPDown.Size = New System.Drawing.Size(24, 21)
        Me.Pct_UPDown.TabIndex = 10016
        Me.Pct_UPDown.TabStop = False
        '
        'Label22
        '
        Me.Label22.ForeColor = System.Drawing.Color.White
        Me.Label22.Location = New System.Drawing.Point(0, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(207, 21)
        Me.Label22.TabIndex = 10015
        Me.Label22.Text = "Credit Position"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.BackColor = System.Drawing.Color.Transparent
        Me.Label23.ForeColor = System.Drawing.Color.White
        Me.Label23.Location = New System.Drawing.Point(443, 110)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(97, 13)
        Me.Label23.TabIndex = 100009
        Me.Label23.Text = "Deposit Balance"
        '
        'Btn_PMRFind
        '
        Me.Btn_PMRFind.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_PMRFind.BackgroundImage = CType(resources.GetObject("Btn_PMRFind.BackgroundImage"), System.Drawing.Image)
        Me.Btn_PMRFind.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_PMRFind.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_PMRFind.ForeColor = System.Drawing.Color.White
        Me.Btn_PMRFind.Location = New System.Drawing.Point(217, 24)
        Me.Btn_PMRFind.Name = "Btn_PMRFind"
        Me.Btn_PMRFind.Size = New System.Drawing.Size(28, 21)
        Me.Btn_PMRFind.TabIndex = 100013
        Me.Btn_PMRFind.TabStop = False
        Me.Btn_PMRFind.Text = "F2"
        Me.Btn_PMRFind.UseVisualStyleBackColor = False
        '
        'Txt_PMRID
        '
        Me.Txt_PMRID.BackColor = System.Drawing.Color.White
        Me.Txt_PMRID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_PMRID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PMRID.Location = New System.Drawing.Point(64, 24)
        Me.Txt_PMRID.MaxLength = 15
        Me.Txt_PMRID.Name = "Txt_PMRID"
        Me.Txt_PMRID.Size = New System.Drawing.Size(152, 21)
        Me.Txt_PMRID.TabIndex = 0
        Me.Txt_PMRID.Tag = ""
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.BackColor = System.Drawing.Color.Transparent
        Me.Label26.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label26.Location = New System.Drawing.Point(2, 28)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(45, 14)
        Me.Label26.TabIndex = 100014
        Me.Label26.Text = "PMR-ID"
        '
        'Btn_ExpGroup
        '
        Me.Btn_ExpGroup.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_ExpGroup.BackgroundImage = CType(resources.GetObject("Btn_ExpGroup.BackgroundImage"), System.Drawing.Image)
        Me.Btn_ExpGroup.ForeColor = System.Drawing.Color.White
        Me.Btn_ExpGroup.Location = New System.Drawing.Point(0, 0)
        Me.Btn_ExpGroup.Name = "Btn_ExpGroup"
        Me.Btn_ExpGroup.Size = New System.Drawing.Size(390, 28)
        Me.Btn_ExpGroup.TabIndex = 101
        Me.Btn_ExpGroup.TabStop = False
        Me.Btn_ExpGroup.Text = "D i r e c t  B i l l i n g   S e c t i o n "
        Me.Btn_ExpGroup.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Button1.BackgroundImage = CType(resources.GetObject("Button1.BackgroundImage"), System.Drawing.Image)
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(390, 0)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(397, 32)
        Me.Button1.TabIndex = 102
        Me.Button1.TabStop = False
        Me.Button1.Text = "P e n d i n g   B i l l   S e c t i o n"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.Transparent
        Me.Panel5.Controls.Add(Me.Button1)
        Me.Panel5.Controls.Add(Me.Btn_ExpGroup)
        Me.Panel5.Location = New System.Drawing.Point(4, 168)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(788, 24)
        Me.Panel5.TabIndex = 10014
        '
        'Patient_Info1
        '
        Me.Patient_Info1.BackColor = System.Drawing.Color.AliceBlue
        Me.Patient_Info1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Patient_Info1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Patient_Info1.ForeColor = System.Drawing.Color.DarkBlue
        Me.Patient_Info1.Location = New System.Drawing.Point(5, 47)
        Me.Patient_Info1.Name = "Patient_Info1"
        Me.Patient_Info1.Padding = New System.Windows.Forms.Padding(2)
        Me.Patient_Info1.Size = New System.Drawing.Size(380, 118)
        Me.Patient_Info1.TabIndex = 10013
        '
        'Patient_Transaction_Bill_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(815, 558)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.Btn_PMRFind)
        Me.Controls.Add(Me.Txt_PMRID)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Pnl_Details)
        Me.Controls.Add(Me.Txt_DepositBalance)
        Me.Controls.Add(Me.Txt_Trandate)
        Me.Controls.Add(Me.Btn_Showtran)
        Me.Controls.Add(Me.Patient_Info1)
        Me.Controls.Add(Me.Txt_BatchID)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Pnl_Tran_mode)
        Me.Controls.Add(Me.Txt_PatientID)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Txt_OutPatientID)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Controls.Add(Me.Label23)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Patient_Transaction_Bill_Frm"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.Pnl_Tran_mode.ResumeLayout(False)
        Me.Pnl_History.ResumeLayout(False)
        Me.Pnl_History.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.Dgv_PatientTran_Grid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Dgv_PatientBill_Grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.Dgv_PendingBills, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Pnl_Details.ResumeLayout(False)
        Me.Pnl_CreditPosition.ResumeLayout(False)
        Me.Pnl_CreditPosition.PerformLayout()
        CType(Me.Pct_UPDown, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel5.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Lst_Search As System.Windows.Forms.ListBox
    Friend WithEvents Dgv_PatientBill_Grid As REAL_CLINIC.Hms_DGridview
    Friend WithEvents Trancontrol1 As Tran_Controls.Trancontrol
    Friend WithEvents Txt_PatientID As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Txt_OutPatientID As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Txt_ExpenseMaster As System.Windows.Forms.TextBox
    Friend WithEvents Tvw_ExpenseList As System.Windows.Forms.TreeView
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_TotalAmount As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Words As System.Windows.Forms.Label
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Cancel As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Btn_Add As System.Windows.Forms.Button
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Txt_Remarks As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Txt_BatchID As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Btn_Cleargrid As System.Windows.Forms.Button
    Friend WithEvents Txt_ExpID As System.Windows.Forms.TextBox
    Friend WithEvents Btn_Uttility As System.Windows.Forms.Button
    Friend WithEvents Btn_Report As System.Windows.Forms.Button
    Friend WithEvents Pnl_History As System.Windows.Forms.Panel
    Friend WithEvents Dtp_ToDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Dtp_FrmDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Btn_CloseHistory As System.Windows.Forms.Button
    Friend WithEvents Btn_ShowHistory As System.Windows.Forms.Button
    Friend WithEvents Cmb_PayStatus As System.Windows.Forms.ComboBox
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Patient_Info1 As REAL_CLINIC.Patient_Info
    Friend WithEvents Dgv_PatientTran_Grid As REAL_CLINIC.Hms_DGridview
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Expense As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Particulars As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Amount As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Acc_Code As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Exp_Subtype As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Def_TranType As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Editable As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Exp_ID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Txt_BillBatchNO As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Payment_Mode As System.Windows.Forms.ComboBox
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Btn_Close1 As System.Windows.Forms.Button
    Friend WithEvents Btn_Show1 As System.Windows.Forms.Button
    Friend WithEvents Btn_Uttility1 As System.Windows.Forms.Button
    Friend WithEvents Btn_Clear1 As System.Windows.Forms.Button
    Friend WithEvents Btn_Cancel1 As System.Windows.Forms.Button
    Friend WithEvents Btn_Save1 As System.Windows.Forms.Button
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_TotUnpaid As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Wrds As System.Windows.Forms.Label
    Friend WithEvents Txt_Remark As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Cmb_PamentMode As System.Windows.Forms.ComboBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Dgv_PendingBills As REAL_CLINIC.Hms_DGridview
    Friend WithEvents Btn_GenerateBill As System.Windows.Forms.Button
    Friend WithEvents Txt_Tran_BatchID As System.Windows.Forms.TextBox
    Friend WithEvents Btn_Showtran As System.Windows.Forms.Button
    Friend WithEvents Txt_PMR_ID As System.Windows.Forms.TextBox
    Friend WithEvents Btn_FindOP As System.Windows.Forms.Button
    Friend WithEvents Txt_Trandate As System.Windows.Forms.TextBox
    Friend WithEvents Btn_ProcessAllPending As System.Windows.Forms.Button
    Friend WithEvents Txt_DepositBalance As System.Windows.Forms.TextBox
    Friend WithEvents Pnl_Details As System.Windows.Forms.Panel
    Friend WithEvents Pnl_CreditPosition As System.Windows.Forms.Panel
    Friend WithEvents Lbl_UnPaid_BillAmt As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Lbl_BalanceAmt As System.Windows.Forms.Label
    Friend WithEvents Lbl_Paid_BillAmt As System.Windows.Forms.Label
    Friend WithEvents Lbl_DepositAmt As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Pct_UPDown As System.Windows.Forms.PictureBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Cmb_DebitDep As System.Windows.Forms.ComboBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Cmb_debitfromDeposit As System.Windows.Forms.ComboBox
    Friend WithEvents Btn_Discharge As System.Windows.Forms.Button
    Friend WithEvents ChkAll As System.Windows.Forms.CheckBox
    Friend WithEvents Btn_PMRFind As System.Windows.Forms.Button
    Friend WithEvents Txt_PMRID As System.Windows.Forms.TextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Btn_ExpGroup As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Mark As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents SerialNo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BillDate As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ExpenseParticulars As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ExpenseAmount As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Bill_BatchNo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PatientTranBatchID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Bill_ID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label27 As System.Windows.Forms.Label
End Class
