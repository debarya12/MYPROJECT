﻿Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls

Public Class Insuarance_Master_Frm

#Region "Declarations"
    'Object of Employee Details Bussiness Layer


    Private Patient_BL As PatientInformation_BL_Cls
    Private Insurance_Master_BL As Insurance_Master_BL_Cls
    Private hms_helper As HMS_Helper = Nothing

    Private mTr_Mode As Tran_Mode

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing
    Private Ctrl_Point As Point

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_InsComp_ID.BackColor = Color.White
                    Me.Txt_InsComp_ID.ReadOnly = False

                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_InsComp_ID.BackColor = Color.Silver
                    Me.Txt_InsComp_ID.ReadOnly = True

            End Select
        End Set
    End Property


#End Region

#Region "Methods"
    'Clear Controls
    Public Sub Clear_Form()
        Try

            Txt_InsComp_ID.Text = ""
            Txt_Company_Name.Text = ""
            Txt_Company_Address.Text = ""
            Txt_City.Text = ""
            Txt_Zip.Text = ""
            Txt_Company_Email.Text = ""
            Txt_Company_Fax.Text = ""
            Txt_Company_Mob.Text = ""
            Txt_Company_Phone.Text = ""
            Txt_Company_Web.Text = ""
            Cmb_Country.SelectedIndex = 0
            cmb_State.SelectedIndex = 0
            Cmb_Active.SelectedIndex = 0

            Txt_Contact_Person_Name.Text = ""
            Txt_Contact_Person_Address.Text = ""
            Txt_Contact_Person_Email.Text = ""
            Txt_Contact_Person_Fax.Text = ""
            Txt_Contact_Person_Phone.Text = ""
            Txt_Contact_Person_Mobile.Text = ""

            Txt_Remarks.Text = ""
            Dtp_Company_RegDt.Value = Today

            Tr_Mode = Tran_Mode.New_Mode
            Btn_Save.Enabled = True
            Btn_Delete.Enabled = False

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    'assigning values to controls
    Private Sub AssignToControl(ByVal dtbl As DataTable)
        Try

            Dim dr As DataTableReader = Nothing
            dr = dtbl.CreateDataReader()
            dr.Read()

            With dr
                Txt_InsComp_ID.Text = .Item("IComp_ID").ToString
                Txt_Company_Name.Text = .Item("Name").ToString
                Txt_Company_Address.Text = .Item("Address").ToString
                Txt_City.Text = .Item("City").ToString
                Txt_Zip.Text = .Item("Zip").ToString
                Txt_Company_Email.Text = .Item("Email").ToString
                Txt_Company_Fax.Text = .Item("Fax").ToString
                Txt_Company_Mob.Text = .Item("Mobile").ToString
                Txt_Company_Phone.Text = .Item("Phone").ToString
                Txt_Company_Web.Text = .Item("Web").ToString
                Cmb_Country.SelectedValue = .Item("Contry").ToString
                cmb_State.SelectedValue = .Item("State").ToString
                Cmb_Active.SelectedIndex = IIf(.Item("Active").ToString = "Y", 0, 1)

                Txt_Contact_Person_Name.Text = .Item("Contact Person").ToString
                Txt_Contact_Person_Address.Text = .Item("Contact Person Address").ToString
                Txt_Contact_Person_Email.Text = .Item("Contact Person Email").ToString
                Txt_Contact_Person_Fax.Text = .Item("Contact Person Fax").ToString
                Txt_Contact_Person_Phone.Text = .Item("Contact Person Phone").ToString
                Txt_Contact_Person_Mobile.Text = .Item("Contact Person Mobile").ToString

                Txt_Remarks.Text = .Item("Remarks").ToString
                Dtp_Company_RegDt.Value = .Item("Reg Date").ToString


                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Save.Enabled = True
                Btn_Delete.Enabled = True

               
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    'validating fields 
    Private Function Validate_Fields() As Boolean
        Try

            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If

            If Tr_Mode <> Tran_Mode.New_Mode Then
                If Txt_InsComp_ID.Text.Trim = "" Then MessageBox.Show("Invalid Inusarance Company ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_InsComp_ID.Focus() : Return False
            End If
            'validating all mandatory fields
            If Txt_Company_Name.Text.Trim = "" Then MessageBox.Show("Invalid Insurance Company Name, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Company_Name.Focus() : Return False
            If Txt_Company_Address.Text.Trim = "" Then MessageBox.Show("Invalid Insurance Company Address, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Company_Address.Focus() : Return False
            If Txt_City.Text.Trim = "" Then MessageBox.Show("Invalid Insurance Company City, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_City.Focus() : Return False
            If Cmb_Country.SelectedIndex = 0 Then MessageBox.Show("Invalid Country, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_Country.Focus() : Return False
            If cmb_State.SelectedIndex = 0 Then MessageBox.Show("Invalid State, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : cmb_State.Focus() : Return False
            If Txt_Zip.Text.Trim = "" Then MessageBox.Show("Invalid Zip Code, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Zip.Focus() : Return False
            If Txt_Company_Phone.Text.Trim = "" Then MessageBox.Show("Invalid Phone Number, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Company_Phone.Focus() : Return False
            If Txt_Company_Mob.Text.Trim = "" Then MessageBox.Show("Invalid Mobile Number, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Company_Mob.Focus() : Return False
            If Txt_Company_Email.Text.Trim = "" Then MessageBox.Show("Invalid EMail ID, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Company_Email.Focus() : Return False
            If Txt_Contact_Person_Name.Text.Trim = "" Then MessageBox.Show("Invalid Contact Person Name, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Contact_Person_Name.Focus() : Return False
            If Txt_Contact_Person_Mobile.Text.Trim = "" Then MessageBox.Show("Invalid Contact Person Mobile Number, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Contact_Person_Mobile.Focus() : Return False
            If Txt_Contact_Person_Email.Text.Trim = "" Then MessageBox.Show("Invalid Contact Person Email ID, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Contact_Person_Email.Focus() : Return False

            REM Seting default values
            If Txt_Remarks.Text = "" Then Txt_Remarks.Text = ""
            If Txt_Contact_Person_Phone.Text = "" Then Txt_Contact_Person_Phone.Text = ""
            If Txt_Contact_Person_Fax.Text = "" Then Txt_Contact_Person_Fax.Text = ""
            If Txt_Company_Fax.Text = "" Then Txt_Company_Fax.Text = ""
            If Txt_Company_Web.Text = "" Then Txt_Company_Web.Text = ""

            REM Validatimg formats
            If Txt_Company_Email.Text.Trim <> "" Then If Not Email_Validation(Txt_Company_Email.Text.Trim, True) Then Txt_Company_Email.Focus() : Return False
            If Txt_Contact_Person_Email.Text.Trim <> "" Then If Not Email_Validation(Txt_Contact_Person_Email.Text.Trim, True) Then Txt_Contact_Person_Email.Focus() : Return False
            If Txt_Company_Mob.Text.Trim <> "" Then If Not Mobile_Validation(Txt_Company_Mob.Text.Trim, True) Then Txt_Company_Mob.Focus() : Return False
            If Txt_Contact_Person_Mobile.Text.Trim <> "" Then If Not Mobile_Validation(Txt_Contact_Person_Mobile.Text.Trim, True) Then Txt_Contact_Person_Mobile.Focus() : Return False
            If Txt_Company_Phone.Text.Trim <> "" Then If Not Phone_Validation(Txt_Company_Phone.Text.Trim, True) Then Txt_Company_Phone.Focus() : Return False
            If Txt_Contact_Person_Phone.Text.Trim <> "" Then If Not Phone_Validation(Txt_Contact_Person_Phone.Text.Trim, True) Then Txt_Contact_Person_Phone.Focus() : Return False




            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    'Locate values from BL
    Public Function Locate_Values(ByVal IComp_ID As Integer) As Boolean
        Insurance_Master_BL = New Insurance_Master_BL_Cls
        Dim dtbl As DataTable = Nothing
        Try
            If Insurance_Master_BL.Get_Insurance_Master_Details(dtbl, IComp_ID) Then
                Call AssignToControl(dtbl)
                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Delete.Enabled = True
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Function

  
#End Region

    Private Sub Insuarance_Master_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        Try

            If e.KeyCode = Keys.Enter Then SendKeyTab()
            If e.KeyCode = Keys.F2 Then Btn_FindID_Click(sender, e)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Insuarance_Master_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles MyBase.KeyPress
        Try
            If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Insuarance_Master_Frm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try


            hms_helper = New Hms_Helperimpliments
            Call hms_helper.Fill_GenData(Cmb_Country, Gendatatype.Country)
            Call hms_helper.Fill_GenData(cmb_State, Gendatatype.State)

            With Cmb_Active
                .Items.Add("Yes")
                .Items.Add("No")
            End With

            Txt_InsComp_ID.Focus()
            Cmb_Active.SelectedIndex = 0
            Dtp_Company_RegDt.Value = Tran_Date


        Catch ex As Exception

        End Try
    End Sub



    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try

            If Not Validate_Fields() Then Exit Sub

            'Variable declaration of BL 
            Insurance_Master_BL = New Insurance_Master_BL_Cls

            Insurance_Master_BL.IComp_ID = Val(Txt_InsComp_ID.Text.Trim)
            Insurance_Master_BL.IComp_Name = Txt_Company_Name.Text.Trim
            Insurance_Master_BL.IComp_Addr = Txt_Company_Address.Text.Trim
            Insurance_Master_BL.IComp_City = Txt_City.Text.Trim
            Insurance_Master_BL.IComp_State = cmb_State.SelectedValue
            Insurance_Master_BL.IComp_Country = Cmb_Country.SelectedValue
            Insurance_Master_BL.IComp_Phone = Txt_Company_Phone.Text
            Insurance_Master_BL.IComp_Mobile = Txt_Company_Mob.Text
            Insurance_Master_BL.IComp_Email = Txt_Company_Email.Text
            Insurance_Master_BL.IComp_Fax = Txt_Company_Fax.Text
            Insurance_Master_BL.IComp_Web = Txt_Company_Web.Text
            Insurance_Master_BL.IComp_Zip = Txt_Zip.Text
            Insurance_Master_BL.IComp_Remarks = Txt_Remarks.Text
            Insurance_Master_BL.IComp_CtPerson = Txt_Contact_Person_Name.Text
            Insurance_Master_BL.IComp_CtPersonaddr = Txt_Contact_Person_Address.Text
            Insurance_Master_BL.IComp_CtPersonEmail = Txt_Contact_Person_Email.Text
            Insurance_Master_BL.IComp_CtPersonFax = Txt_Contact_Person_Fax.Text
            Insurance_Master_BL.IComp_CtPersonMobile = Txt_Contact_Person_Mobile.Text
            Insurance_Master_BL.IComp_CtPersonPhone = Txt_Contact_Person_Phone.Text
            Insurance_Master_BL.IComp_Regdate = Dtp_Company_RegDt.Value
            Insurance_Master_BL.IComp_Active = Strings.Left(Cmb_Active.Text, 1)



            If Insurance_Master_BL.Save_Insurance_Master(Dtbl, Tr_Mode, Val(Txt_InsComp_ID.Text.Trim)) Then
                If Dtbl.Rows(0).Item(0).ToString = "0" Then
                    MessageBox.Show("Insurance Company Details Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Else
                    MessageBox.Show("Insurance Company Details Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Txt_InsComp_ID.Text = Dtbl.Rows(0).Item(1).ToString
                    Btn_Clear.Focus()
                End If

            Else
                MessageBox.Show("Insurance Company Details Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try
            Call Clear_Form()
            Txt_InsComp_ID.Focus()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Pat_ID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_InsComp_ID.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then Btn_FindID_Click(sender, e)
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Txt_Pat_ID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_InsComp_ID.Validating
        Try

            If Txt_InsComp_ID.Text.Trim <> "" Then
                If Not Locate_Values(Txt_InsComp_ID.Text.Trim) Then
                    MessageBox.Show("Invalid Insurance ID, Please Check ", _
                                    Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Txt_InsComp_ID.Focus()
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Public Sub Btn_FindID_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_FindID.Click
        Try
            If Txt_InsComp_ID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "150|75|200|200|200"
                'Sql = "Select  Name,Patient_ID,[Family Name], Address, [SS_No],City,State,Country from Get_Patient_Info_Vw " '"SELECT *  FROM    Patient_Info_Short_Vw"
                Sql = "select * from Insurance_Master_Vw where Br_code='" & Branch_Code & "' "
                Call ShowSearchengine(Txt_InsComp_ID, Sql, 0, "IComp_Name", Colwidth, , 0)
            End If

            If Txt_InsComp_ID.Text.Trim = "" Then
                Txt_InsComp_ID.Focus() : Exit Sub
            End If

            'Locate Employee details 
            If Not Locate_Values(Txt_InsComp_ID.Text.Trim) Then
                MessageBox.Show("Invalid Insurance Company ID, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Txt_InsComp_ID.Focus() : Exit Sub
            Else

            End If
        Catch ex As Exception

        End Try
    End Sub


    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Try
            Me.Close()
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click
        Try


            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If
            Insurance_Master_BL = New Insurance_Master_BL_Cls
            Dim dtbl As DataTable = Nothing
            If MessageBox.Show("Are you sure want to delete the  record ", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                If Insurance_Master_BL.Del_Insurance_Master(dtbl, Txt_InsComp_ID.Text.Trim) Then
                    If dtbl.Rows(0).Item(0).ToString = True Then
                        MessageBox.Show("Insurance Company Details Deleted", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                        Call Clear_Form()
                        Txt_InsComp_ID.Focus()
                    Else
                        MessageBox.Show("You cannot delete this Insurance Company Details" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                Else
                    MessageBox.Show("You cannot delete this Insurance Company Details" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub


#Region "A D D  New GenData"
    Private Sub Btn_New_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_New.Click
        Try

            Dim AddBtnCtrl As Control = CType(sender, Control)
            Call AddNewGendata(AddBtnCtrl)
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Cmb_Country_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cmb_Country.GotFocus
        Try

            Dim AddReqCtrl As Control = CType(sender, Control)
            Btn_New.Visible = True
            Me.Btn_New.Location = Get_Newgendatabuttonposition(AddReqCtrl)
            Me.Btn_New.Tag = AddReqCtrl.Name & "|" & Val(AddReqCtrl.Tag)


        Catch ex As Exception

        End Try
    End Sub

    Private Sub cmb_State_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmb_State.GotFocus
        Try
            Dim AddReqCtrl As Control = CType(sender, Control)
            Btn_New.Visible = True
            Me.Btn_New.Location = Get_Newgendatabuttonposition(AddReqCtrl)
            Me.Btn_New.Tag = AddReqCtrl.Name & "|" & Val(AddReqCtrl.Tag)
        Catch ex As Exception

        End Try
    End Sub

#End Region

    Private Sub Txt_Company_Address_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Company_Address.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then Txt_Company_Address.Select(Len(Txt_Company_Address.Text), 0)
            If Len(Txt_Company_Address.Text) > 150 Then Txt_Company_Address.ScrollBars = ScrollBars.Both Else Txt_Company_Address.ScrollBars = ScrollBars.None
        Catch ex As Exception

        End Try
    End Sub


    Private Sub Txt_Contact_Person_Address_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Contact_Person_Address.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then Txt_Contact_Person_Address.Select(Len(Txt_Contact_Person_Address.Text), 0)
            If Len(Txt_Contact_Person_Address.Text) > 150 Then Txt_Contact_Person_Address.ScrollBars = ScrollBars.Both Else Txt_Contact_Person_Address.ScrollBars = ScrollBars.None
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Zip_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Zip.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Zip.Text, Data_Type.Integer_Type, 6))
        Catch ex As Exception

        End Try
    End Sub
   
End Class