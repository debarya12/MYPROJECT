﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Employee_Info
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Pnl_Employeename = New System.Windows.Forms.Panel
        Me.EmployeeName = New System.Windows.Forms.Label
        Me.Lbl_name = New System.Windows.Forms.Label
        Me.Pnl_EmployeeSSN = New System.Windows.Forms.Panel
        Me.Btn_viewmore = New System.Windows.Forms.Button
        Me.EmployeeSSN = New System.Windows.Forms.Label
        Me.Lbl_SSN = New System.Windows.Forms.Label
        Me.Pnl_Phone = New System.Windows.Forms.Panel
        Me.Employeemobile = New System.Windows.Forms.Label
        Me.Lbl_Mobile = New System.Windows.Forms.Label
        Me.Employeephone = New System.Windows.Forms.Label
        Me.Lbl_Phone = New System.Windows.Forms.Label
        Me.Pnl_Employeeaddress = New System.Windows.Forms.Panel
        Me.Employeeaddress = New System.Windows.Forms.Label
        Me.Lbl_Address = New System.Windows.Forms.Label
        Me.Pnl_Familyname = New System.Windows.Forms.Panel
        Me.Employeefamilyname = New System.Windows.Forms.Label
        Me.Lbl_Familyname = New System.Windows.Forms.Label
        Me.Pnl_Employeename.SuspendLayout()
        Me.Pnl_EmployeeSSN.SuspendLayout()
        Me.Pnl_Phone.SuspendLayout()
        Me.Pnl_Employeeaddress.SuspendLayout()
        Me.Pnl_Familyname.SuspendLayout()
        Me.SuspendLayout()
        '
        'Pnl_Employeename
        '
        Me.Pnl_Employeename.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Employeename.Controls.Add(Me.EmployeeName)
        Me.Pnl_Employeename.Controls.Add(Me.Lbl_name)
        Me.Pnl_Employeename.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Employeename.Location = New System.Drawing.Point(2, 2)
        Me.Pnl_Employeename.Name = "Pnl_Employeename"
        Me.Pnl_Employeename.Size = New System.Drawing.Size(386, 22)
        Me.Pnl_Employeename.TabIndex = 2
        '
        'EmployeeName
        '
        Me.EmployeeName.BackColor = System.Drawing.Color.Transparent
        Me.EmployeeName.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EmployeeName.ForeColor = System.Drawing.Color.DarkBlue
        Me.EmployeeName.Location = New System.Drawing.Point(85, 0)
        Me.EmployeeName.Name = "EmployeeName"
        Me.EmployeeName.Size = New System.Drawing.Size(301, 22)
        Me.EmployeeName.TabIndex = 3
        Me.EmployeeName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Lbl_name
        '
        Me.Lbl_name.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_name.Dock = System.Windows.Forms.DockStyle.Left
        Me.Lbl_name.ForeColor = System.Drawing.Color.RoyalBlue
        Me.Lbl_name.Location = New System.Drawing.Point(0, 0)
        Me.Lbl_name.Name = "Lbl_name"
        Me.Lbl_name.Size = New System.Drawing.Size(85, 22)
        Me.Lbl_name.TabIndex = 2
        Me.Lbl_name.Text = "Name              :"
        Me.Lbl_name.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Pnl_EmployeeSSN
        '
        Me.Pnl_EmployeeSSN.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_EmployeeSSN.Controls.Add(Me.Btn_viewmore)
        Me.Pnl_EmployeeSSN.Controls.Add(Me.EmployeeSSN)
        Me.Pnl_EmployeeSSN.Controls.Add(Me.Lbl_SSN)
        Me.Pnl_EmployeeSSN.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Pnl_EmployeeSSN.Location = New System.Drawing.Point(2, 126)
        Me.Pnl_EmployeeSSN.Name = "Pnl_EmployeeSSN"
        Me.Pnl_EmployeeSSN.Size = New System.Drawing.Size(386, 22)
        Me.Pnl_EmployeeSSN.TabIndex = 7
        '
        'Btn_viewmore
        '
        Me.Btn_viewmore.BackColor = System.Drawing.Color.Transparent
        Me.Btn_viewmore.Dock = System.Windows.Forms.DockStyle.Right
        Me.Btn_viewmore.Enabled = False
        Me.Btn_viewmore.FlatAppearance.BorderSize = 0
        Me.Btn_viewmore.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_viewmore.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_viewmore.ForeColor = System.Drawing.Color.RoyalBlue
        Me.Btn_viewmore.Location = New System.Drawing.Point(297, 0)
        Me.Btn_viewmore.Name = "Btn_viewmore"
        Me.Btn_viewmore.Size = New System.Drawing.Size(89, 22)
        Me.Btn_viewmore.TabIndex = 6
        Me.Btn_viewmore.TabStop = False
        Me.Btn_viewmore.Text = "&View More"
        Me.Btn_viewmore.UseVisualStyleBackColor = False
        '
        'EmployeeSSN
        '
        Me.EmployeeSSN.BackColor = System.Drawing.Color.Transparent
        Me.EmployeeSSN.Dock = System.Windows.Forms.DockStyle.Fill
        Me.EmployeeSSN.ForeColor = System.Drawing.Color.DarkBlue
        Me.EmployeeSSN.Location = New System.Drawing.Point(85, 0)
        Me.EmployeeSSN.Name = "EmployeeSSN"
        Me.EmployeeSSN.Size = New System.Drawing.Size(301, 22)
        Me.EmployeeSSN.TabIndex = 3
        Me.EmployeeSSN.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Lbl_SSN
        '
        Me.Lbl_SSN.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_SSN.Dock = System.Windows.Forms.DockStyle.Left
        Me.Lbl_SSN.ForeColor = System.Drawing.Color.RoyalBlue
        Me.Lbl_SSN.Location = New System.Drawing.Point(0, 0)
        Me.Lbl_SSN.Name = "Lbl_SSN"
        Me.Lbl_SSN.Size = New System.Drawing.Size(85, 22)
        Me.Lbl_SSN.TabIndex = 2
        Me.Lbl_SSN.Text = "SSN                  :"
        Me.Lbl_SSN.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Pnl_Phone
        '
        Me.Pnl_Phone.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Phone.Controls.Add(Me.Employeemobile)
        Me.Pnl_Phone.Controls.Add(Me.Lbl_Mobile)
        Me.Pnl_Phone.Controls.Add(Me.Employeephone)
        Me.Pnl_Phone.Controls.Add(Me.Lbl_Phone)
        Me.Pnl_Phone.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Pnl_Phone.Location = New System.Drawing.Point(2, 104)
        Me.Pnl_Phone.Name = "Pnl_Phone"
        Me.Pnl_Phone.Size = New System.Drawing.Size(386, 22)
        Me.Pnl_Phone.TabIndex = 8
        '
        'Employeemobile
        '
        Me.Employeemobile.BackColor = System.Drawing.Color.Transparent
        Me.Employeemobile.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Employeemobile.ForeColor = System.Drawing.Color.DarkBlue
        Me.Employeemobile.Location = New System.Drawing.Point(268, 0)
        Me.Employeemobile.Name = "Employeemobile"
        Me.Employeemobile.Size = New System.Drawing.Size(118, 22)
        Me.Employeemobile.TabIndex = 5
        Me.Employeemobile.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Lbl_Mobile
        '
        Me.Lbl_Mobile.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Mobile.Dock = System.Windows.Forms.DockStyle.Left
        Me.Lbl_Mobile.ForeColor = System.Drawing.Color.RoyalBlue
        Me.Lbl_Mobile.Location = New System.Drawing.Point(214, 0)
        Me.Lbl_Mobile.Name = "Lbl_Mobile"
        Me.Lbl_Mobile.Size = New System.Drawing.Size(54, 22)
        Me.Lbl_Mobile.TabIndex = 4
        Me.Lbl_Mobile.Text = "Mobile  :"
        Me.Lbl_Mobile.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Employeephone
        '
        Me.Employeephone.BackColor = System.Drawing.Color.Transparent
        Me.Employeephone.Dock = System.Windows.Forms.DockStyle.Left
        Me.Employeephone.ForeColor = System.Drawing.Color.DarkBlue
        Me.Employeephone.Location = New System.Drawing.Point(85, 0)
        Me.Employeephone.Name = "Employeephone"
        Me.Employeephone.Size = New System.Drawing.Size(129, 22)
        Me.Employeephone.TabIndex = 3
        Me.Employeephone.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Lbl_Phone
        '
        Me.Lbl_Phone.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Phone.Dock = System.Windows.Forms.DockStyle.Left
        Me.Lbl_Phone.ForeColor = System.Drawing.Color.RoyalBlue
        Me.Lbl_Phone.Location = New System.Drawing.Point(0, 0)
        Me.Lbl_Phone.Name = "Lbl_Phone"
        Me.Lbl_Phone.Size = New System.Drawing.Size(85, 22)
        Me.Lbl_Phone.TabIndex = 2
        Me.Lbl_Phone.Text = "Phone             :"
        Me.Lbl_Phone.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Pnl_Employeeaddress
        '
        Me.Pnl_Employeeaddress.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Employeeaddress.Controls.Add(Me.Employeeaddress)
        Me.Pnl_Employeeaddress.Controls.Add(Me.Lbl_Address)
        Me.Pnl_Employeeaddress.Controls.Add(Me.Pnl_Familyname)
        Me.Pnl_Employeeaddress.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Pnl_Employeeaddress.Location = New System.Drawing.Point(2, 24)
        Me.Pnl_Employeeaddress.Name = "Pnl_Employeeaddress"
        Me.Pnl_Employeeaddress.Size = New System.Drawing.Size(386, 80)
        Me.Pnl_Employeeaddress.TabIndex = 9
        '
        'Employeeaddress
        '
        Me.Employeeaddress.BackColor = System.Drawing.Color.Transparent
        Me.Employeeaddress.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Employeeaddress.ForeColor = System.Drawing.Color.DarkBlue
        Me.Employeeaddress.Location = New System.Drawing.Point(85, 0)
        Me.Employeeaddress.Name = "Employeeaddress"
        Me.Employeeaddress.Size = New System.Drawing.Size(301, 58)
        Me.Employeeaddress.TabIndex = 11
        '
        'Lbl_Address
        '
        Me.Lbl_Address.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Address.Dock = System.Windows.Forms.DockStyle.Left
        Me.Lbl_Address.ForeColor = System.Drawing.Color.RoyalBlue
        Me.Lbl_Address.Location = New System.Drawing.Point(0, 0)
        Me.Lbl_Address.Name = "Lbl_Address"
        Me.Lbl_Address.Size = New System.Drawing.Size(85, 58)
        Me.Lbl_Address.TabIndex = 10
        Me.Lbl_Address.Text = "Address         :"
        '
        'Pnl_Familyname
        '
        Me.Pnl_Familyname.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Familyname.Controls.Add(Me.Employeefamilyname)
        Me.Pnl_Familyname.Controls.Add(Me.Lbl_Familyname)
        Me.Pnl_Familyname.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Pnl_Familyname.Location = New System.Drawing.Point(0, 58)
        Me.Pnl_Familyname.Name = "Pnl_Familyname"
        Me.Pnl_Familyname.Size = New System.Drawing.Size(386, 22)
        Me.Pnl_Familyname.TabIndex = 9
        '
        'Employeefamilyname
        '
        Me.Employeefamilyname.BackColor = System.Drawing.Color.Transparent
        Me.Employeefamilyname.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Employeefamilyname.ForeColor = System.Drawing.Color.DarkBlue
        Me.Employeefamilyname.Location = New System.Drawing.Point(85, 0)
        Me.Employeefamilyname.Name = "Employeefamilyname"
        Me.Employeefamilyname.Size = New System.Drawing.Size(301, 22)
        Me.Employeefamilyname.TabIndex = 3
        Me.Employeefamilyname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Lbl_Familyname
        '
        Me.Lbl_Familyname.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Familyname.Dock = System.Windows.Forms.DockStyle.Left
        Me.Lbl_Familyname.ForeColor = System.Drawing.Color.RoyalBlue
        Me.Lbl_Familyname.Location = New System.Drawing.Point(0, 0)
        Me.Lbl_Familyname.Name = "Lbl_Familyname"
        Me.Lbl_Familyname.Size = New System.Drawing.Size(85, 22)
        Me.Lbl_Familyname.TabIndex = 2
        Me.Lbl_Familyname.Text = "Family Name :"
        Me.Lbl_Familyname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Employee_Info
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Transparent
        Me.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Controls.Add(Me.Pnl_Employeeaddress)
        Me.Controls.Add(Me.Pnl_Phone)
        Me.Controls.Add(Me.Pnl_EmployeeSSN)
        Me.Controls.Add(Me.Pnl_Employeename)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "Employee_Info"
        Me.Padding = New System.Windows.Forms.Padding(2)
        Me.Size = New System.Drawing.Size(390, 150)
        Me.Pnl_Employeename.ResumeLayout(False)
        Me.Pnl_EmployeeSSN.ResumeLayout(False)
        Me.Pnl_Phone.ResumeLayout(False)
        Me.Pnl_Employeeaddress.ResumeLayout(False)
        Me.Pnl_Familyname.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Pnl_Employeename As System.Windows.Forms.Panel
    Friend WithEvents EmployeeName As System.Windows.Forms.Label
    Friend WithEvents Lbl_name As System.Windows.Forms.Label
    Friend WithEvents Pnl_EmployeeSSN As System.Windows.Forms.Panel
    Friend WithEvents Btn_viewmore As System.Windows.Forms.Button
    Friend WithEvents EmployeeSSN As System.Windows.Forms.Label
    Friend WithEvents Lbl_SSN As System.Windows.Forms.Label
    Friend WithEvents Pnl_Phone As System.Windows.Forms.Panel
    Friend WithEvents Employeemobile As System.Windows.Forms.Label
    Friend WithEvents Lbl_Mobile As System.Windows.Forms.Label
    Friend WithEvents Employeephone As System.Windows.Forms.Label
    Friend WithEvents Lbl_Phone As System.Windows.Forms.Label
    Friend WithEvents Pnl_Employeeaddress As System.Windows.Forms.Panel
    Friend WithEvents Pnl_Familyname As System.Windows.Forms.Panel
    Friend WithEvents Employeefamilyname As System.Windows.Forms.Label
    Friend WithEvents Lbl_Familyname As System.Windows.Forms.Label
    Friend WithEvents Employeeaddress As System.Windows.Forms.Label
    Friend WithEvents Lbl_Address As System.Windows.Forms.Label

End Class
