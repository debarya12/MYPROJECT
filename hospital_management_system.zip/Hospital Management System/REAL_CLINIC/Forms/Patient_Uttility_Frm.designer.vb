﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Patient_Uttility_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Patient_Uttility_Frm))
        Me.Pnl_PatientInfo = New System.Windows.Forms.Panel
        Me.Lbl_OPID = New System.Windows.Forms.Label
        Me.Txt_OPD_ID = New System.Windows.Forms.TextBox
        Me.Btn_viewmore = New System.Windows.Forms.Button
        Me.Btn_Find = New System.Windows.Forms.Button
        Me.Txt_Nationality = New System.Windows.Forms.TextBox
        Me.Txt_Gender = New System.Windows.Forms.TextBox
        Me.Txt_PMRID = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.Txt_Visitor_Familyname = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Txt_Visitor_SSNO = New System.Windows.Forms.TextBox
        Me.Label35 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Txt_Visitor_Age = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Txt_Visitor_Mobile = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.Txt_Visitor_Phone = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Txt_Visitor_Addr = New System.Windows.Forms.TextBox
        Me.Txt_Visitor_Name = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Pnl_Insurance = New System.Windows.Forms.Panel
        Me.Btn_InsureVw = New System.Windows.Forms.Button
        Me.Label3 = New System.Windows.Forms.Label
        Me.Pnl_Accounts = New System.Windows.Forms.Panel
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Label23 = New System.Windows.Forms.Label
        Me.Txt_Total = New System.Windows.Forms.TextBox
        Me.Label22 = New System.Windows.Forms.Label
        Me.Txt_Transfer = New System.Windows.Forms.TextBox
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Txt_Cash_Transaction = New System.Windows.Forms.TextBox
        Me.Label21 = New System.Windows.Forms.Label
        Me.Txt_Bill_Due = New System.Windows.Forms.TextBox
        Me.Txt_Balance_Deposit = New System.Windows.Forms.TextBox
        Me.Txt_Dedeucted_Amount = New System.Windows.Forms.TextBox
        Me.Txt_AdvanceDeposit = New System.Windows.Forms.TextBox
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.Button7 = New System.Windows.Forms.Button
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Btn_HistoryVw = New System.Windows.Forms.Button
        Me.Pnl_History = New System.Windows.Forms.Panel
        Me.Label14 = New System.Windows.Forms.Label
        Me.Btn_DiagnoVw = New System.Windows.Forms.Button
        Me.Pnl_Diagnosis = New System.Windows.Forms.Panel
        Me.Label26 = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.Txt_Diag_Status = New System.Windows.Forms.TextBox
        Me.Txt_Diag_Comment = New System.Windows.Forms.TextBox
        Me.Txt_Diagnosis = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.Button4 = New System.Windows.Forms.Button
        Me.Pnl_Patient_CaseRecord = New System.Windows.Forms.Panel
        Me.Txt_FooterText = New System.Windows.Forms.TextBox
        Me.Txt_Bodytext = New System.Windows.Forms.TextBox
        Me.Txt_Heading = New System.Windows.Forms.TextBox
        Me.Txt_DcotorName = New System.Windows.Forms.TextBox
        Me.Btn_CRvw = New System.Windows.Forms.Button
        Me.Label12 = New System.Windows.Forms.Label
        Me.Panel4 = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label29 = New System.Windows.Forms.Label
        Me.Txt_Weight = New System.Windows.Forms.TextBox
        Me.Label28 = New System.Windows.Forms.Label
        Me.Txt_Temprature = New System.Windows.Forms.TextBox
        Me.Label27 = New System.Windows.Forms.Label
        Me.Txt_Height = New System.Windows.Forms.TextBox
        Me.Label30 = New System.Windows.Forms.Label
        Me.Txt_BPDiastolic = New System.Windows.Forms.TextBox
        Me.Label32 = New System.Windows.Forms.Label
        Me.Txt_BPSystolic = New System.Windows.Forms.TextBox
        Me.Label31 = New System.Windows.Forms.Label
        Me.Txt_Respiration = New System.Windows.Forms.TextBox
        Me.Label34 = New System.Windows.Forms.Label
        Me.Txt_Pulse = New System.Windows.Forms.TextBox
        Me.Label33 = New System.Windows.Forms.Label
        Me.Txt_Bloodclass = New System.Windows.Forms.TextBox
        Me.Pnl_CurrentStatus = New System.Windows.Forms.Panel
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Label38 = New System.Windows.Forms.Label
        Me.Label37 = New System.Windows.Forms.Label
        Me.Txt_Results = New System.Windows.Forms.TextBox
        Me.Txt_Testconducted = New System.Windows.Forms.TextBox
        Me.Txt_Complaints = New System.Windows.Forms.TextBox
        Me.Label36 = New System.Windows.Forms.Label
        Me.Btn_MRvw = New System.Windows.Forms.Button
        Me.Pnl_PatientInfo.SuspendLayout()
        Me.Pnl_Insurance.SuspendLayout()
        Me.Pnl_Accounts.SuspendLayout()
        Me.Pnl_History.SuspendLayout()
        Me.Pnl_Diagnosis.SuspendLayout()
        Me.Pnl_Patient_CaseRecord.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Pnl_CurrentStatus.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Pnl_PatientInfo
        '
        Me.Pnl_PatientInfo.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_PatientInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_PatientInfo.Controls.Add(Me.Lbl_OPID)
        Me.Pnl_PatientInfo.Controls.Add(Me.Txt_OPD_ID)
        Me.Pnl_PatientInfo.Controls.Add(Me.Btn_viewmore)
        Me.Pnl_PatientInfo.Controls.Add(Me.Btn_Find)
        Me.Pnl_PatientInfo.Controls.Add(Me.Txt_Nationality)
        Me.Pnl_PatientInfo.Controls.Add(Me.Txt_Gender)
        Me.Pnl_PatientInfo.Controls.Add(Me.Txt_PMRID)
        Me.Pnl_PatientInfo.Controls.Add(Me.Label9)
        Me.Pnl_PatientInfo.Controls.Add(Me.Txt_Visitor_Familyname)
        Me.Pnl_PatientInfo.Controls.Add(Me.Label6)
        Me.Pnl_PatientInfo.Controls.Add(Me.Txt_Visitor_SSNO)
        Me.Pnl_PatientInfo.Controls.Add(Me.Label35)
        Me.Pnl_PatientInfo.Controls.Add(Me.Label5)
        Me.Pnl_PatientInfo.Controls.Add(Me.Txt_Visitor_Age)
        Me.Pnl_PatientInfo.Controls.Add(Me.Label15)
        Me.Pnl_PatientInfo.Controls.Add(Me.Label13)
        Me.Pnl_PatientInfo.Controls.Add(Me.Txt_Visitor_Mobile)
        Me.Pnl_PatientInfo.Controls.Add(Me.Label11)
        Me.Pnl_PatientInfo.Controls.Add(Me.Txt_Visitor_Phone)
        Me.Pnl_PatientInfo.Controls.Add(Me.Label8)
        Me.Pnl_PatientInfo.Controls.Add(Me.Label4)
        Me.Pnl_PatientInfo.Controls.Add(Me.Txt_Visitor_Addr)
        Me.Pnl_PatientInfo.Controls.Add(Me.Txt_Visitor_Name)
        Me.Pnl_PatientInfo.Controls.Add(Me.Label7)
        Me.Pnl_PatientInfo.Location = New System.Drawing.Point(1, 0)
        Me.Pnl_PatientInfo.Name = "Pnl_PatientInfo"
        Me.Pnl_PatientInfo.Size = New System.Drawing.Size(440, 205)
        Me.Pnl_PatientInfo.TabIndex = 16
        '
        'Lbl_OPID
        '
        Me.Lbl_OPID.AutoSize = True
        Me.Lbl_OPID.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_OPID.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_OPID.ForeColor = System.Drawing.Color.Navy
        Me.Lbl_OPID.Location = New System.Drawing.Point(317, 7)
        Me.Lbl_OPID.Name = "Lbl_OPID"
        Me.Lbl_OPID.Size = New System.Drawing.Size(77, 14)
        Me.Lbl_OPID.TabIndex = 100053
        Me.Lbl_OPID.Text = "OutPatient ID"
        '
        'Txt_OPD_ID
        '
        Me.Txt_OPD_ID.BackColor = System.Drawing.Color.White
        Me.Txt_OPD_ID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_OPD_ID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_OPD_ID.ForeColor = System.Drawing.Color.Navy
        Me.Txt_OPD_ID.Location = New System.Drawing.Point(267, 27)
        Me.Txt_OPD_ID.MaxLength = 50
        Me.Txt_OPD_ID.Name = "Txt_OPD_ID"
        Me.Txt_OPD_ID.Size = New System.Drawing.Size(169, 21)
        Me.Txt_OPD_ID.TabIndex = 100052
        Me.Txt_OPD_ID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Btn_viewmore
        '
        Me.Btn_viewmore.BackColor = System.Drawing.Color.Transparent
        Me.Btn_viewmore.Enabled = False
        Me.Btn_viewmore.FlatAppearance.BorderSize = 0
        Me.Btn_viewmore.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_viewmore.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_viewmore.ForeColor = System.Drawing.Color.DarkBlue
        Me.Btn_viewmore.Location = New System.Drawing.Point(362, 182)
        Me.Btn_viewmore.Name = "Btn_viewmore"
        Me.Btn_viewmore.Size = New System.Drawing.Size(74, 21)
        Me.Btn_viewmore.TabIndex = 100051
        Me.Btn_viewmore.TabStop = False
        Me.Btn_viewmore.Text = "&View More"
        Me.Btn_viewmore.UseVisualStyleBackColor = False
        '
        'Btn_Find
        '
        Me.Btn_Find.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find.BackgroundImage = CType(resources.GetObject("Btn_Find.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find.ForeColor = System.Drawing.Color.White
        Me.Btn_Find.Location = New System.Drawing.Point(232, 3)
        Me.Btn_Find.Name = "Btn_Find"
        Me.Btn_Find.Size = New System.Drawing.Size(29, 21)
        Me.Btn_Find.TabIndex = 100050
        Me.Btn_Find.TabStop = False
        Me.Btn_Find.Text = "F2"
        Me.Btn_Find.UseVisualStyleBackColor = False
        '
        'Txt_Nationality
        '
        Me.Txt_Nationality.BackColor = System.Drawing.Color.White
        Me.Txt_Nationality.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Nationality.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Nationality.ForeColor = System.Drawing.Color.Navy
        Me.Txt_Nationality.Location = New System.Drawing.Point(78, 180)
        Me.Txt_Nationality.MaxLength = 250
        Me.Txt_Nationality.Name = "Txt_Nationality"
        Me.Txt_Nationality.ReadOnly = True
        Me.Txt_Nationality.Size = New System.Drawing.Size(264, 21)
        Me.Txt_Nationality.TabIndex = 100049
        '
        'Txt_Gender
        '
        Me.Txt_Gender.BackColor = System.Drawing.Color.White
        Me.Txt_Gender.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Gender.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Gender.ForeColor = System.Drawing.Color.Navy
        Me.Txt_Gender.Location = New System.Drawing.Point(78, 132)
        Me.Txt_Gender.MaxLength = 250
        Me.Txt_Gender.Name = "Txt_Gender"
        Me.Txt_Gender.ReadOnly = True
        Me.Txt_Gender.Size = New System.Drawing.Size(153, 21)
        Me.Txt_Gender.TabIndex = 100048
        '
        'Txt_PMRID
        '
        Me.Txt_PMRID.BackColor = System.Drawing.Color.White
        Me.Txt_PMRID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_PMRID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PMRID.ForeColor = System.Drawing.Color.Navy
        Me.Txt_PMRID.Location = New System.Drawing.Point(78, 3)
        Me.Txt_PMRID.MaxLength = 50
        Me.Txt_PMRID.Name = "Txt_PMRID"
        Me.Txt_PMRID.Size = New System.Drawing.Size(153, 21)
        Me.Txt_PMRID.TabIndex = 1
        Me.Txt_PMRID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Navy
        Me.Label9.Location = New System.Drawing.Point(3, 7)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(44, 14)
        Me.Label9.TabIndex = 100047
        Me.Label9.Text = "PMR ID"
        '
        'Txt_Visitor_Familyname
        '
        Me.Txt_Visitor_Familyname.BackColor = System.Drawing.Color.White
        Me.Txt_Visitor_Familyname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Familyname.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Familyname.ForeColor = System.Drawing.Color.Navy
        Me.Txt_Visitor_Familyname.Location = New System.Drawing.Point(78, 108)
        Me.Txt_Visitor_Familyname.MaxLength = 250
        Me.Txt_Visitor_Familyname.Name = "Txt_Visitor_Familyname"
        Me.Txt_Visitor_Familyname.ReadOnly = True
        Me.Txt_Visitor_Familyname.Size = New System.Drawing.Size(358, 21)
        Me.Txt_Visitor_Familyname.TabIndex = 6
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Navy
        Me.Label6.Location = New System.Drawing.Point(3, 111)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(76, 14)
        Me.Label6.TabIndex = 100044
        Me.Label6.Text = "Family Name"
        '
        'Txt_Visitor_SSNO
        '
        Me.Txt_Visitor_SSNO.BackColor = System.Drawing.Color.White
        Me.Txt_Visitor_SSNO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_SSNO.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_SSNO.ForeColor = System.Drawing.Color.Navy
        Me.Txt_Visitor_SSNO.Location = New System.Drawing.Point(78, 27)
        Me.Txt_Visitor_SSNO.MaxLength = 50
        Me.Txt_Visitor_SSNO.Name = "Txt_Visitor_SSNO"
        Me.Txt_Visitor_SSNO.ReadOnly = True
        Me.Txt_Visitor_SSNO.Size = New System.Drawing.Size(183, 21)
        Me.Txt_Visitor_SSNO.TabIndex = 3
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.BackColor = System.Drawing.Color.Transparent
        Me.Label35.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.ForeColor = System.Drawing.Color.Navy
        Me.Label35.Location = New System.Drawing.Point(3, 32)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(67, 14)
        Me.Label35.TabIndex = 100042
        Me.Label35.Text = "Soc Sec No"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Navy
        Me.Label5.Location = New System.Drawing.Point(3, 182)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(63, 14)
        Me.Label5.TabIndex = 100041
        Me.Label5.Text = "Nationality"
        '
        'Txt_Visitor_Age
        '
        Me.Txt_Visitor_Age.BackColor = System.Drawing.Color.White
        Me.Txt_Visitor_Age.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Age.Cursor = System.Windows.Forms.Cursors.Default
        Me.Txt_Visitor_Age.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Age.ForeColor = System.Drawing.Color.Navy
        Me.Txt_Visitor_Age.Location = New System.Drawing.Point(278, 132)
        Me.Txt_Visitor_Age.MaxLength = 3
        Me.Txt_Visitor_Age.Name = "Txt_Visitor_Age"
        Me.Txt_Visitor_Age.ReadOnly = True
        Me.Txt_Visitor_Age.Size = New System.Drawing.Size(64, 21)
        Me.Txt_Visitor_Age.TabIndex = 8
        Me.Txt_Visitor_Age.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.Navy
        Me.Label15.Location = New System.Drawing.Point(240, 136)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(29, 14)
        Me.Label15.TabIndex = 100040
        Me.Label15.Text = "Age"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.Navy
        Me.Label13.Location = New System.Drawing.Point(3, 136)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(48, 14)
        Me.Label13.TabIndex = 100039
        Me.Label13.Text = "Gender"
        '
        'Txt_Visitor_Mobile
        '
        Me.Txt_Visitor_Mobile.BackColor = System.Drawing.Color.White
        Me.Txt_Visitor_Mobile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Mobile.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Mobile.ForeColor = System.Drawing.Color.Navy
        Me.Txt_Visitor_Mobile.Location = New System.Drawing.Point(278, 156)
        Me.Txt_Visitor_Mobile.MaxLength = 10
        Me.Txt_Visitor_Mobile.Name = "Txt_Visitor_Mobile"
        Me.Txt_Visitor_Mobile.ReadOnly = True
        Me.Txt_Visitor_Mobile.Size = New System.Drawing.Size(158, 21)
        Me.Txt_Visitor_Mobile.TabIndex = 10
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Navy
        Me.Label11.Location = New System.Drawing.Point(234, 160)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(44, 14)
        Me.Label11.TabIndex = 100038
        Me.Label11.Text = "Mobile"
        '
        'Txt_Visitor_Phone
        '
        Me.Txt_Visitor_Phone.BackColor = System.Drawing.Color.White
        Me.Txt_Visitor_Phone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Phone.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Phone.ForeColor = System.Drawing.Color.Navy
        Me.Txt_Visitor_Phone.Location = New System.Drawing.Point(78, 156)
        Me.Txt_Visitor_Phone.MaxLength = 11
        Me.Txt_Visitor_Phone.Name = "Txt_Visitor_Phone"
        Me.Txt_Visitor_Phone.ReadOnly = True
        Me.Txt_Visitor_Phone.Size = New System.Drawing.Size(153, 21)
        Me.Txt_Visitor_Phone.TabIndex = 9
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Navy
        Me.Label8.Location = New System.Drawing.Point(3, 157)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(42, 14)
        Me.Label8.TabIndex = 100037
        Me.Label8.Text = "Phone"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Navy
        Me.Label4.Location = New System.Drawing.Point(3, 82)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(55, 14)
        Me.Label4.TabIndex = 100036
        Me.Label4.Text = "Address"
        '
        'Txt_Visitor_Addr
        '
        Me.Txt_Visitor_Addr.BackColor = System.Drawing.Color.White
        Me.Txt_Visitor_Addr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Addr.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Addr.ForeColor = System.Drawing.Color.Navy
        Me.Txt_Visitor_Addr.Location = New System.Drawing.Point(78, 75)
        Me.Txt_Visitor_Addr.MaxLength = 500
        Me.Txt_Visitor_Addr.Multiline = True
        Me.Txt_Visitor_Addr.Name = "Txt_Visitor_Addr"
        Me.Txt_Visitor_Addr.ReadOnly = True
        Me.Txt_Visitor_Addr.Size = New System.Drawing.Size(358, 30)
        Me.Txt_Visitor_Addr.TabIndex = 5
        '
        'Txt_Visitor_Name
        '
        Me.Txt_Visitor_Name.BackColor = System.Drawing.Color.White
        Me.Txt_Visitor_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Name.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Name.ForeColor = System.Drawing.Color.Navy
        Me.Txt_Visitor_Name.Location = New System.Drawing.Point(78, 51)
        Me.Txt_Visitor_Name.MaxLength = 250
        Me.Txt_Visitor_Name.Name = "Txt_Visitor_Name"
        Me.Txt_Visitor_Name.ReadOnly = True
        Me.Txt_Visitor_Name.Size = New System.Drawing.Size(358, 21)
        Me.Txt_Visitor_Name.TabIndex = 4
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Navy
        Me.Label7.Location = New System.Drawing.Point(3, 57)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(38, 14)
        Me.Label7.TabIndex = 100035
        Me.Label7.Text = "Name"
        '
        'Pnl_Insurance
        '
        Me.Pnl_Insurance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Insurance.Controls.Add(Me.Btn_InsureVw)
        Me.Pnl_Insurance.Controls.Add(Me.Label3)
        Me.Pnl_Insurance.Location = New System.Drawing.Point(442, 206)
        Me.Pnl_Insurance.Name = "Pnl_Insurance"
        Me.Pnl_Insurance.Size = New System.Drawing.Size(385, 117)
        Me.Pnl_Insurance.TabIndex = 19
        '
        'Btn_InsureVw
        '
        Me.Btn_InsureVw.BackColor = System.Drawing.Color.Transparent
        Me.Btn_InsureVw.Enabled = False
        Me.Btn_InsureVw.FlatAppearance.BorderSize = 0
        Me.Btn_InsureVw.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_InsureVw.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_InsureVw.ForeColor = System.Drawing.Color.DarkBlue
        Me.Btn_InsureVw.Location = New System.Drawing.Point(307, 94)
        Me.Btn_InsureVw.Name = "Btn_InsureVw"
        Me.Btn_InsureVw.Size = New System.Drawing.Size(74, 21)
        Me.Btn_InsureVw.TabIndex = 100053
        Me.Btn_InsureVw.TabStop = False
        Me.Btn_InsureVw.Text = "&View More"
        Me.Btn_InsureVw.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Blue
        Me.Label3.Location = New System.Drawing.Point(-2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(150, 14)
        Me.Label3.TabIndex = 100052
        Me.Label3.Text = "I n s u r a n c e   D e t a i l s"
        '
        'Pnl_Accounts
        '
        Me.Pnl_Accounts.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Accounts.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Accounts.Controls.Add(Me.Btn_Close)
        Me.Pnl_Accounts.Controls.Add(Me.Label23)
        Me.Pnl_Accounts.Controls.Add(Me.Txt_Total)
        Me.Pnl_Accounts.Controls.Add(Me.Label22)
        Me.Pnl_Accounts.Controls.Add(Me.Txt_Transfer)
        Me.Pnl_Accounts.Controls.Add(Me.Panel1)
        Me.Pnl_Accounts.Controls.Add(Me.Txt_Cash_Transaction)
        Me.Pnl_Accounts.Controls.Add(Me.Label21)
        Me.Pnl_Accounts.Controls.Add(Me.Txt_Bill_Due)
        Me.Pnl_Accounts.Controls.Add(Me.Txt_Balance_Deposit)
        Me.Pnl_Accounts.Controls.Add(Me.Txt_Dedeucted_Amount)
        Me.Pnl_Accounts.Controls.Add(Me.Txt_AdvanceDeposit)
        Me.Pnl_Accounts.Controls.Add(Me.Label20)
        Me.Pnl_Accounts.Controls.Add(Me.Label19)
        Me.Pnl_Accounts.Controls.Add(Me.Label18)
        Me.Pnl_Accounts.Controls.Add(Me.Label17)
        Me.Pnl_Accounts.Controls.Add(Me.Button7)
        Me.Pnl_Accounts.Controls.Add(Me.Label16)
        Me.Pnl_Accounts.Location = New System.Drawing.Point(1, 446)
        Me.Pnl_Accounts.Name = "Pnl_Accounts"
        Me.Pnl_Accounts.Size = New System.Drawing.Size(826, 86)
        Me.Pnl_Accounts.TabIndex = 100054
        '
        'Btn_Clear
        '
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.ForeColor = System.Drawing.Color.Navy
        Me.Btn_Clear.Location = New System.Drawing.Point(704, 56)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear.TabIndex = 100068
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.ForeColor = System.Drawing.Color.Navy
        Me.Btn_Close.Location = New System.Drawing.Point(766, 56)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 100069
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.BackColor = System.Drawing.Color.Transparent
        Me.Label23.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.Navy
        Me.Label23.Location = New System.Drawing.Point(705, 10)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(105, 14)
        Me.Label23.TabIndex = 100067
        Me.Label23.Text = "Total Transaction "
        '
        'Txt_Total
        '
        Me.Txt_Total.BackColor = System.Drawing.Color.White
        Me.Txt_Total.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Total.Cursor = System.Windows.Forms.Cursors.Default
        Me.Txt_Total.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Total.ForeColor = System.Drawing.Color.Navy
        Me.Txt_Total.Location = New System.Drawing.Point(696, 29)
        Me.Txt_Total.MaxLength = 3
        Me.Txt_Total.Name = "Txt_Total"
        Me.Txt_Total.ReadOnly = True
        Me.Txt_Total.Size = New System.Drawing.Size(126, 21)
        Me.Txt_Total.TabIndex = 100066
        Me.Txt_Total.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.BackColor = System.Drawing.Color.Transparent
        Me.Label22.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.Navy
        Me.Label22.Location = New System.Drawing.Point(598, 12)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(58, 14)
        Me.Label22.TabIndex = 100065
        Me.Label22.Text = "Transfer "
        '
        'Txt_Transfer
        '
        Me.Txt_Transfer.BackColor = System.Drawing.Color.White
        Me.Txt_Transfer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Transfer.Cursor = System.Windows.Forms.Cursors.Default
        Me.Txt_Transfer.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Transfer.ForeColor = System.Drawing.Color.Navy
        Me.Txt_Transfer.Location = New System.Drawing.Point(561, 29)
        Me.Txt_Transfer.MaxLength = 3
        Me.Txt_Transfer.Name = "Txt_Transfer"
        Me.Txt_Transfer.ReadOnly = True
        Me.Txt_Transfer.Size = New System.Drawing.Size(133, 21)
        Me.Txt_Transfer.TabIndex = 100064
        Me.Txt_Transfer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Gray
        Me.Panel1.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.Panel1.Location = New System.Drawing.Point(437, 10)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(4, 66)
        Me.Panel1.TabIndex = 100063
        '
        'Txt_Cash_Transaction
        '
        Me.Txt_Cash_Transaction.BackColor = System.Drawing.Color.White
        Me.Txt_Cash_Transaction.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Cash_Transaction.Cursor = System.Windows.Forms.Cursors.Default
        Me.Txt_Cash_Transaction.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Cash_Transaction.ForeColor = System.Drawing.Color.Navy
        Me.Txt_Cash_Transaction.Location = New System.Drawing.Point(444, 29)
        Me.Txt_Cash_Transaction.MaxLength = 3
        Me.Txt_Cash_Transaction.Name = "Txt_Cash_Transaction"
        Me.Txt_Cash_Transaction.ReadOnly = True
        Me.Txt_Cash_Transaction.Size = New System.Drawing.Size(115, 21)
        Me.Txt_Cash_Transaction.TabIndex = 100062
        Me.Txt_Cash_Transaction.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.Color.Transparent
        Me.Label21.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.Navy
        Me.Label21.Location = New System.Drawing.Point(450, 12)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(103, 14)
        Me.Label21.TabIndex = 100061
        Me.Label21.Text = "Cash Transaction"
        '
        'Txt_Bill_Due
        '
        Me.Txt_Bill_Due.BackColor = System.Drawing.Color.White
        Me.Txt_Bill_Due.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Bill_Due.Cursor = System.Windows.Forms.Cursors.Default
        Me.Txt_Bill_Due.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Bill_Due.ForeColor = System.Drawing.Color.Navy
        Me.Txt_Bill_Due.Location = New System.Drawing.Point(322, 29)
        Me.Txt_Bill_Due.MaxLength = 3
        Me.Txt_Bill_Due.Name = "Txt_Bill_Due"
        Me.Txt_Bill_Due.ReadOnly = True
        Me.Txt_Bill_Due.Size = New System.Drawing.Size(114, 21)
        Me.Txt_Bill_Due.TabIndex = 100060
        Me.Txt_Bill_Due.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Txt_Balance_Deposit
        '
        Me.Txt_Balance_Deposit.BackColor = System.Drawing.Color.White
        Me.Txt_Balance_Deposit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Balance_Deposit.Cursor = System.Windows.Forms.Cursors.Default
        Me.Txt_Balance_Deposit.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Balance_Deposit.ForeColor = System.Drawing.Color.Navy
        Me.Txt_Balance_Deposit.Location = New System.Drawing.Point(215, 29)
        Me.Txt_Balance_Deposit.MaxLength = 3
        Me.Txt_Balance_Deposit.Name = "Txt_Balance_Deposit"
        Me.Txt_Balance_Deposit.ReadOnly = True
        Me.Txt_Balance_Deposit.Size = New System.Drawing.Size(105, 21)
        Me.Txt_Balance_Deposit.TabIndex = 100059
        Me.Txt_Balance_Deposit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Txt_Dedeucted_Amount
        '
        Me.Txt_Dedeucted_Amount.BackColor = System.Drawing.Color.White
        Me.Txt_Dedeucted_Amount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Dedeucted_Amount.Cursor = System.Windows.Forms.Cursors.Default
        Me.Txt_Dedeucted_Amount.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Dedeucted_Amount.ForeColor = System.Drawing.Color.Navy
        Me.Txt_Dedeucted_Amount.Location = New System.Drawing.Point(109, 29)
        Me.Txt_Dedeucted_Amount.MaxLength = 3
        Me.Txt_Dedeucted_Amount.Name = "Txt_Dedeucted_Amount"
        Me.Txt_Dedeucted_Amount.ReadOnly = True
        Me.Txt_Dedeucted_Amount.Size = New System.Drawing.Size(104, 21)
        Me.Txt_Dedeucted_Amount.TabIndex = 100058
        Me.Txt_Dedeucted_Amount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Txt_AdvanceDeposit
        '
        Me.Txt_AdvanceDeposit.BackColor = System.Drawing.Color.White
        Me.Txt_AdvanceDeposit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_AdvanceDeposit.Cursor = System.Windows.Forms.Cursors.Default
        Me.Txt_AdvanceDeposit.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_AdvanceDeposit.ForeColor = System.Drawing.Color.Navy
        Me.Txt_AdvanceDeposit.Location = New System.Drawing.Point(3, 29)
        Me.Txt_AdvanceDeposit.MaxLength = 3
        Me.Txt_AdvanceDeposit.Name = "Txt_AdvanceDeposit"
        Me.Txt_AdvanceDeposit.ReadOnly = True
        Me.Txt_AdvanceDeposit.Size = New System.Drawing.Size(104, 21)
        Me.Txt_AdvanceDeposit.TabIndex = 100057
        Me.Txt_AdvanceDeposit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.Color.Transparent
        Me.Label20.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.Navy
        Me.Label20.Location = New System.Drawing.Point(348, 12)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(47, 14)
        Me.Label20.TabIndex = 100056
        Me.Label20.Text = "Bill Due"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.Navy
        Me.Label19.Location = New System.Drawing.Point(220, 12)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(94, 14)
        Me.Label19.TabIndex = 100055
        Me.Label19.Text = "Balance Deposit"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.Transparent
        Me.Label18.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.Navy
        Me.Label18.Location = New System.Drawing.Point(108, 12)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(106, 14)
        Me.Label18.TabIndex = 100054
        Me.Label18.Text = "Deducted Amount"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.Navy
        Me.Label17.Location = New System.Drawing.Point(3, 12)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(99, 14)
        Me.Label17.TabIndex = 100053
        Me.Label17.Text = "Advance Deposit"
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.Color.Transparent
        Me.Button7.Enabled = False
        Me.Button7.FlatAppearance.BorderSize = 0
        Me.Button7.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button7.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.ForeColor = System.Drawing.Color.DarkBlue
        Me.Button7.Location = New System.Drawing.Point(733, 63)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(89, 21)
        Me.Button7.TabIndex = 100052
        Me.Button7.TabStop = False
        Me.Button7.Text = "&View More"
        Me.Button7.UseVisualStyleBackColor = False
        Me.Button7.Visible = False
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.Blue
        Me.Label16.Location = New System.Drawing.Point(404, -2)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(83, 14)
        Me.Label16.TabIndex = 100052
        Me.Label16.Text = "A c c o u n t s "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Blue
        Me.Label2.Location = New System.Drawing.Point(-2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(129, 14)
        Me.Label2.TabIndex = 100052
        Me.Label2.Text = "P a t i e n t   H i s t o r y"
        '
        'Btn_HistoryVw
        '
        Me.Btn_HistoryVw.BackColor = System.Drawing.Color.Transparent
        Me.Btn_HistoryVw.Enabled = False
        Me.Btn_HistoryVw.FlatAppearance.BorderSize = 0
        Me.Btn_HistoryVw.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_HistoryVw.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_HistoryVw.ForeColor = System.Drawing.Color.DarkBlue
        Me.Btn_HistoryVw.Location = New System.Drawing.Point(362, 94)
        Me.Btn_HistoryVw.Name = "Btn_HistoryVw"
        Me.Btn_HistoryVw.Size = New System.Drawing.Size(74, 21)
        Me.Btn_HistoryVw.TabIndex = 100052
        Me.Btn_HistoryVw.TabStop = False
        Me.Btn_HistoryVw.Text = "&View More"
        Me.Btn_HistoryVw.UseVisualStyleBackColor = False
        '
        'Pnl_History
        '
        Me.Pnl_History.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_History.Controls.Add(Me.Btn_HistoryVw)
        Me.Pnl_History.Controls.Add(Me.Label2)
        Me.Pnl_History.Location = New System.Drawing.Point(1, 206)
        Me.Pnl_History.Name = "Pnl_History"
        Me.Pnl_History.Size = New System.Drawing.Size(440, 117)
        Me.Pnl_History.TabIndex = 18
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.Blue
        Me.Label14.Location = New System.Drawing.Point(-2, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(149, 14)
        Me.Label14.TabIndex = 100052
        Me.Label14.Text = "D i a g n o s i s   D e t a i l s"
        '
        'Btn_DiagnoVw
        '
        Me.Btn_DiagnoVw.BackColor = System.Drawing.Color.Transparent
        Me.Btn_DiagnoVw.Enabled = False
        Me.Btn_DiagnoVw.FlatAppearance.BorderSize = 0
        Me.Btn_DiagnoVw.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_DiagnoVw.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_DiagnoVw.ForeColor = System.Drawing.Color.DarkBlue
        Me.Btn_DiagnoVw.Location = New System.Drawing.Point(307, 94)
        Me.Btn_DiagnoVw.Name = "Btn_DiagnoVw"
        Me.Btn_DiagnoVw.Size = New System.Drawing.Size(74, 21)
        Me.Btn_DiagnoVw.TabIndex = 100053
        Me.Btn_DiagnoVw.TabStop = False
        Me.Btn_DiagnoVw.Text = "&View More"
        Me.Btn_DiagnoVw.UseVisualStyleBackColor = False
        '
        'Pnl_Diagnosis
        '
        Me.Pnl_Diagnosis.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Diagnosis.Controls.Add(Me.Label26)
        Me.Pnl_Diagnosis.Controls.Add(Me.Label25)
        Me.Pnl_Diagnosis.Controls.Add(Me.Label24)
        Me.Pnl_Diagnosis.Controls.Add(Me.Txt_Diag_Status)
        Me.Pnl_Diagnosis.Controls.Add(Me.Txt_Diag_Comment)
        Me.Pnl_Diagnosis.Controls.Add(Me.Txt_Diagnosis)
        Me.Pnl_Diagnosis.Controls.Add(Me.Btn_DiagnoVw)
        Me.Pnl_Diagnosis.Controls.Add(Me.Label14)
        Me.Pnl_Diagnosis.Location = New System.Drawing.Point(442, 325)
        Me.Pnl_Diagnosis.Name = "Pnl_Diagnosis"
        Me.Pnl_Diagnosis.Size = New System.Drawing.Size(385, 117)
        Me.Pnl_Diagnosis.TabIndex = 21
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.ForeColor = System.Drawing.Color.Navy
        Me.Label26.Location = New System.Drawing.Point(0, 75)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(50, 13)
        Me.Label26.TabIndex = 100059
        Me.Label26.Text = "Status :"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.ForeColor = System.Drawing.Color.Navy
        Me.Label25.Location = New System.Drawing.Point(0, 48)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(74, 13)
        Me.Label25.TabIndex = 100058
        Me.Label25.Text = "Comments :"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.ForeColor = System.Drawing.Color.Navy
        Me.Label24.Location = New System.Drawing.Point(-1, 21)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(67, 13)
        Me.Label24.TabIndex = 100057
        Me.Label24.Text = "Diagnosis :"
        '
        'Txt_Diag_Status
        '
        Me.Txt_Diag_Status.BackColor = System.Drawing.Color.White
        Me.Txt_Diag_Status.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Diag_Status.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Diag_Status.ForeColor = System.Drawing.Color.Blue
        Me.Txt_Diag_Status.Location = New System.Drawing.Point(83, 70)
        Me.Txt_Diag_Status.MaxLength = 500
        Me.Txt_Diag_Status.Multiline = True
        Me.Txt_Diag_Status.Name = "Txt_Diag_Status"
        Me.Txt_Diag_Status.ReadOnly = True
        Me.Txt_Diag_Status.Size = New System.Drawing.Size(298, 23)
        Me.Txt_Diag_Status.TabIndex = 100056
        '
        'Txt_Diag_Comment
        '
        Me.Txt_Diag_Comment.BackColor = System.Drawing.Color.White
        Me.Txt_Diag_Comment.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Diag_Comment.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Diag_Comment.ForeColor = System.Drawing.Color.Blue
        Me.Txt_Diag_Comment.Location = New System.Drawing.Point(83, 43)
        Me.Txt_Diag_Comment.MaxLength = 500
        Me.Txt_Diag_Comment.Multiline = True
        Me.Txt_Diag_Comment.Name = "Txt_Diag_Comment"
        Me.Txt_Diag_Comment.ReadOnly = True
        Me.Txt_Diag_Comment.Size = New System.Drawing.Size(298, 23)
        Me.Txt_Diag_Comment.TabIndex = 100055
        '
        'Txt_Diagnosis
        '
        Me.Txt_Diagnosis.BackColor = System.Drawing.Color.White
        Me.Txt_Diagnosis.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Diagnosis.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Diagnosis.ForeColor = System.Drawing.Color.Blue
        Me.Txt_Diagnosis.Location = New System.Drawing.Point(83, 16)
        Me.Txt_Diagnosis.MaxLength = 500
        Me.Txt_Diagnosis.Multiline = True
        Me.Txt_Diagnosis.Name = "Txt_Diagnosis"
        Me.Txt_Diagnosis.ReadOnly = True
        Me.Txt_Diagnosis.Size = New System.Drawing.Size(298, 23)
        Me.Txt_Diagnosis.TabIndex = 100054
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Navy
        Me.Label10.Location = New System.Drawing.Point(-2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(117, 14)
        Me.Label10.TabIndex = 100052
        Me.Label10.Text = "C a s e   R e c o r d s"
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.Transparent
        Me.Button4.Enabled = False
        Me.Button4.FlatAppearance.BorderSize = 0
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button4.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ForeColor = System.Drawing.Color.DarkBlue
        Me.Button4.Location = New System.Drawing.Point(349, 94)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(89, 21)
        Me.Button4.TabIndex = 100052
        Me.Button4.TabStop = False
        Me.Button4.Text = "&View More"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Pnl_Patient_CaseRecord
        '
        Me.Pnl_Patient_CaseRecord.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Patient_CaseRecord.Controls.Add(Me.Txt_FooterText)
        Me.Pnl_Patient_CaseRecord.Controls.Add(Me.Txt_Bodytext)
        Me.Pnl_Patient_CaseRecord.Controls.Add(Me.Txt_Heading)
        Me.Pnl_Patient_CaseRecord.Controls.Add(Me.Txt_DcotorName)
        Me.Pnl_Patient_CaseRecord.Controls.Add(Me.Btn_CRvw)
        Me.Pnl_Patient_CaseRecord.Controls.Add(Me.Label12)
        Me.Pnl_Patient_CaseRecord.Location = New System.Drawing.Point(-1, -1)
        Me.Pnl_Patient_CaseRecord.Name = "Pnl_Patient_CaseRecord"
        Me.Pnl_Patient_CaseRecord.Size = New System.Drawing.Size(440, 117)
        Me.Pnl_Patient_CaseRecord.TabIndex = 100053
        '
        'Txt_FooterText
        '
        Me.Txt_FooterText.BackColor = System.Drawing.Color.White
        Me.Txt_FooterText.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Txt_FooterText.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_FooterText.ForeColor = System.Drawing.Color.Navy
        Me.Txt_FooterText.Location = New System.Drawing.Point(3, 91)
        Me.Txt_FooterText.MaxLength = 500
        Me.Txt_FooterText.Multiline = True
        Me.Txt_FooterText.Name = "Txt_FooterText"
        Me.Txt_FooterText.ReadOnly = True
        Me.Txt_FooterText.Size = New System.Drawing.Size(342, 24)
        Me.Txt_FooterText.TabIndex = 100056
        '
        'Txt_Bodytext
        '
        Me.Txt_Bodytext.BackColor = System.Drawing.Color.White
        Me.Txt_Bodytext.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Txt_Bodytext.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Bodytext.ForeColor = System.Drawing.Color.Navy
        Me.Txt_Bodytext.Location = New System.Drawing.Point(3, 66)
        Me.Txt_Bodytext.MaxLength = 500
        Me.Txt_Bodytext.Multiline = True
        Me.Txt_Bodytext.Name = "Txt_Bodytext"
        Me.Txt_Bodytext.ReadOnly = True
        Me.Txt_Bodytext.Size = New System.Drawing.Size(434, 24)
        Me.Txt_Bodytext.TabIndex = 100055
        '
        'Txt_Heading
        '
        Me.Txt_Heading.BackColor = System.Drawing.Color.White
        Me.Txt_Heading.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Txt_Heading.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Heading.ForeColor = System.Drawing.Color.Navy
        Me.Txt_Heading.Location = New System.Drawing.Point(3, 41)
        Me.Txt_Heading.MaxLength = 500
        Me.Txt_Heading.Multiline = True
        Me.Txt_Heading.Name = "Txt_Heading"
        Me.Txt_Heading.ReadOnly = True
        Me.Txt_Heading.Size = New System.Drawing.Size(434, 24)
        Me.Txt_Heading.TabIndex = 100054
        '
        'Txt_DcotorName
        '
        Me.Txt_DcotorName.BackColor = System.Drawing.Color.White
        Me.Txt_DcotorName.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Txt_DcotorName.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_DcotorName.ForeColor = System.Drawing.Color.Navy
        Me.Txt_DcotorName.Location = New System.Drawing.Point(3, 16)
        Me.Txt_DcotorName.MaxLength = 500
        Me.Txt_DcotorName.Multiline = True
        Me.Txt_DcotorName.Name = "Txt_DcotorName"
        Me.Txt_DcotorName.ReadOnly = True
        Me.Txt_DcotorName.Size = New System.Drawing.Size(434, 24)
        Me.Txt_DcotorName.TabIndex = 100053
        '
        'Btn_CRvw
        '
        Me.Btn_CRvw.BackColor = System.Drawing.Color.Transparent
        Me.Btn_CRvw.Enabled = False
        Me.Btn_CRvw.FlatAppearance.BorderSize = 0
        Me.Btn_CRvw.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_CRvw.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_CRvw.ForeColor = System.Drawing.Color.DarkBlue
        Me.Btn_CRvw.Location = New System.Drawing.Point(362, 94)
        Me.Btn_CRvw.Name = "Btn_CRvw"
        Me.Btn_CRvw.Size = New System.Drawing.Size(74, 21)
        Me.Btn_CRvw.TabIndex = 100052
        Me.Btn_CRvw.TabStop = False
        Me.Btn_CRvw.Text = "&View More"
        Me.Btn_CRvw.UseVisualStyleBackColor = False
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Blue
        Me.Label12.Location = New System.Drawing.Point(-2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(117, 14)
        Me.Label12.TabIndex = 100052
        Me.Label12.Text = "C a s e   R e c o r d s"
        '
        'Panel4
        '
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Controls.Add(Me.Pnl_Patient_CaseRecord)
        Me.Panel4.Controls.Add(Me.Button4)
        Me.Panel4.Controls.Add(Me.Label10)
        Me.Panel4.Location = New System.Drawing.Point(1, 325)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(440, 117)
        Me.Panel4.TabIndex = 20
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Blue
        Me.Label1.Location = New System.Drawing.Point(-2, 1)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(130, 14)
        Me.Label1.TabIndex = 100052
        Me.Label1.Text = "M e d i c a l   R e c o r d"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.BackColor = System.Drawing.Color.Transparent
        Me.Label29.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.ForeColor = System.Drawing.Color.Navy
        Me.Label29.Location = New System.Drawing.Point(2, 20)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(47, 13)
        Me.Label29.TabIndex = 100061
        Me.Label29.Text = "Weight"
        '
        'Txt_Weight
        '
        Me.Txt_Weight.BackColor = System.Drawing.Color.White
        Me.Txt_Weight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Weight.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Weight.ForeColor = System.Drawing.Color.Blue
        Me.Txt_Weight.Location = New System.Drawing.Point(84, 16)
        Me.Txt_Weight.MaxLength = 15
        Me.Txt_Weight.Name = "Txt_Weight"
        Me.Txt_Weight.Size = New System.Drawing.Size(54, 21)
        Me.Txt_Weight.TabIndex = 100055
        Me.Txt_Weight.Tag = ""
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.BackColor = System.Drawing.Color.Transparent
        Me.Label28.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.ForeColor = System.Drawing.Color.Navy
        Me.Label28.Location = New System.Drawing.Point(2, 42)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(82, 13)
        Me.Label28.TabIndex = 100062
        Me.Label28.Text = "Temperature"
        '
        'Txt_Temprature
        '
        Me.Txt_Temprature.BackColor = System.Drawing.Color.White
        Me.Txt_Temprature.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Temprature.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Temprature.ForeColor = System.Drawing.Color.Blue
        Me.Txt_Temprature.Location = New System.Drawing.Point(84, 38)
        Me.Txt_Temprature.MaxLength = 15
        Me.Txt_Temprature.Name = "Txt_Temprature"
        Me.Txt_Temprature.Size = New System.Drawing.Size(54, 21)
        Me.Txt_Temprature.TabIndex = 100057
        Me.Txt_Temprature.Tag = ""
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.BackColor = System.Drawing.Color.Transparent
        Me.Label27.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.ForeColor = System.Drawing.Color.Navy
        Me.Label27.Location = New System.Drawing.Point(2, 64)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(44, 13)
        Me.Label27.TabIndex = 100063
        Me.Label27.Text = "Height"
        '
        'Txt_Height
        '
        Me.Txt_Height.BackColor = System.Drawing.Color.White
        Me.Txt_Height.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Height.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Height.ForeColor = System.Drawing.Color.Blue
        Me.Txt_Height.Location = New System.Drawing.Point(84, 60)
        Me.Txt_Height.MaxLength = 15
        Me.Txt_Height.Name = "Txt_Height"
        Me.Txt_Height.Size = New System.Drawing.Size(54, 21)
        Me.Txt_Height.TabIndex = 100059
        Me.Txt_Height.Tag = ""
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.BackColor = System.Drawing.Color.Transparent
        Me.Label30.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.ForeColor = System.Drawing.Color.Navy
        Me.Label30.Location = New System.Drawing.Point(141, 20)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(72, 13)
        Me.Label30.TabIndex = 100064
        Me.Label30.Text = "BP Diastolic"
        '
        'Txt_BPDiastolic
        '
        Me.Txt_BPDiastolic.BackColor = System.Drawing.Color.White
        Me.Txt_BPDiastolic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_BPDiastolic.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_BPDiastolic.ForeColor = System.Drawing.Color.Blue
        Me.Txt_BPDiastolic.Location = New System.Drawing.Point(213, 16)
        Me.Txt_BPDiastolic.MaxLength = 15
        Me.Txt_BPDiastolic.Name = "Txt_BPDiastolic"
        Me.Txt_BPDiastolic.Size = New System.Drawing.Size(48, 21)
        Me.Txt_BPDiastolic.TabIndex = 100065
        Me.Txt_BPDiastolic.Tag = ""
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.BackColor = System.Drawing.Color.Transparent
        Me.Label32.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.ForeColor = System.Drawing.Color.Navy
        Me.Label32.Location = New System.Drawing.Point(261, 20)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(68, 13)
        Me.Label32.TabIndex = 100068
        Me.Label32.Text = "BP Systolic"
        '
        'Txt_BPSystolic
        '
        Me.Txt_BPSystolic.BackColor = System.Drawing.Color.White
        Me.Txt_BPSystolic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_BPSystolic.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_BPSystolic.ForeColor = System.Drawing.Color.Blue
        Me.Txt_BPSystolic.Location = New System.Drawing.Point(329, 16)
        Me.Txt_BPSystolic.MaxLength = 15
        Me.Txt_BPSystolic.Name = "Txt_BPSystolic"
        Me.Txt_BPSystolic.Size = New System.Drawing.Size(52, 21)
        Me.Txt_BPSystolic.TabIndex = 100066
        Me.Txt_BPSystolic.Tag = ""
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.BackColor = System.Drawing.Color.Transparent
        Me.Label31.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.ForeColor = System.Drawing.Color.Navy
        Me.Label31.Location = New System.Drawing.Point(141, 42)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(72, 13)
        Me.Label31.TabIndex = 100069
        Me.Label31.Text = "Respiration"
        '
        'Txt_Respiration
        '
        Me.Txt_Respiration.BackColor = System.Drawing.Color.White
        Me.Txt_Respiration.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Respiration.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Respiration.ForeColor = System.Drawing.Color.Blue
        Me.Txt_Respiration.Location = New System.Drawing.Point(213, 38)
        Me.Txt_Respiration.MaxLength = 15
        Me.Txt_Respiration.Name = "Txt_Respiration"
        Me.Txt_Respiration.Size = New System.Drawing.Size(48, 21)
        Me.Txt_Respiration.TabIndex = 100067
        Me.Txt_Respiration.Tag = ""
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.BackColor = System.Drawing.Color.Transparent
        Me.Label34.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.ForeColor = System.Drawing.Color.Navy
        Me.Label34.Location = New System.Drawing.Point(141, 64)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(37, 13)
        Me.Label34.TabIndex = 100072
        Me.Label34.Text = "Pulse"
        '
        'Txt_Pulse
        '
        Me.Txt_Pulse.BackColor = System.Drawing.Color.White
        Me.Txt_Pulse.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Pulse.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Pulse.ForeColor = System.Drawing.Color.Blue
        Me.Txt_Pulse.Location = New System.Drawing.Point(213, 60)
        Me.Txt_Pulse.MaxLength = 15
        Me.Txt_Pulse.Name = "Txt_Pulse"
        Me.Txt_Pulse.Size = New System.Drawing.Size(48, 21)
        Me.Txt_Pulse.TabIndex = 100070
        Me.Txt_Pulse.Tag = ""
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.BackColor = System.Drawing.Color.Transparent
        Me.Label33.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.Navy
        Me.Label33.Location = New System.Drawing.Point(261, 42)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(70, 13)
        Me.Label33.TabIndex = 100073
        Me.Label33.Text = "Blood Class"
        '
        'Txt_Bloodclass
        '
        Me.Txt_Bloodclass.BackColor = System.Drawing.Color.White
        Me.Txt_Bloodclass.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Bloodclass.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Bloodclass.ForeColor = System.Drawing.Color.Blue
        Me.Txt_Bloodclass.Location = New System.Drawing.Point(329, 38)
        Me.Txt_Bloodclass.MaxLength = 15
        Me.Txt_Bloodclass.Name = "Txt_Bloodclass"
        Me.Txt_Bloodclass.Size = New System.Drawing.Size(52, 21)
        Me.Txt_Bloodclass.TabIndex = 100071
        Me.Txt_Bloodclass.Tag = ""
        '
        'Pnl_CurrentStatus
        '
        Me.Pnl_CurrentStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_CurrentStatus.Controls.Add(Me.Panel2)
        Me.Pnl_CurrentStatus.Controls.Add(Me.Txt_Bloodclass)
        Me.Pnl_CurrentStatus.Controls.Add(Me.Label33)
        Me.Pnl_CurrentStatus.Controls.Add(Me.Txt_Pulse)
        Me.Pnl_CurrentStatus.Controls.Add(Me.Label34)
        Me.Pnl_CurrentStatus.Controls.Add(Me.Txt_Respiration)
        Me.Pnl_CurrentStatus.Controls.Add(Me.Label31)
        Me.Pnl_CurrentStatus.Controls.Add(Me.Txt_BPSystolic)
        Me.Pnl_CurrentStatus.Controls.Add(Me.Label32)
        Me.Pnl_CurrentStatus.Controls.Add(Me.Txt_BPDiastolic)
        Me.Pnl_CurrentStatus.Controls.Add(Me.Label30)
        Me.Pnl_CurrentStatus.Controls.Add(Me.Txt_Height)
        Me.Pnl_CurrentStatus.Controls.Add(Me.Label27)
        Me.Pnl_CurrentStatus.Controls.Add(Me.Txt_Temprature)
        Me.Pnl_CurrentStatus.Controls.Add(Me.Label28)
        Me.Pnl_CurrentStatus.Controls.Add(Me.Txt_Weight)
        Me.Pnl_CurrentStatus.Controls.Add(Me.Label29)
        Me.Pnl_CurrentStatus.Controls.Add(Me.Label1)
        Me.Pnl_CurrentStatus.Location = New System.Drawing.Point(442, 0)
        Me.Pnl_CurrentStatus.Name = "Pnl_CurrentStatus"
        Me.Pnl_CurrentStatus.Size = New System.Drawing.Size(386, 205)
        Me.Pnl_CurrentStatus.TabIndex = 17
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.White
        Me.Panel2.Controls.Add(Me.Label38)
        Me.Panel2.Controls.Add(Me.Label37)
        Me.Panel2.Controls.Add(Me.Txt_Results)
        Me.Panel2.Controls.Add(Me.Txt_Testconducted)
        Me.Panel2.Controls.Add(Me.Txt_Complaints)
        Me.Panel2.Controls.Add(Me.Label36)
        Me.Panel2.Controls.Add(Me.Btn_MRvw)
        Me.Panel2.Location = New System.Drawing.Point(0, 82)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(384, 122)
        Me.Panel2.TabIndex = 100080
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.BackColor = System.Drawing.Color.Transparent
        Me.Label38.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.ForeColor = System.Drawing.Color.Navy
        Me.Label38.Location = New System.Drawing.Point(1, 97)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(43, 13)
        Me.Label38.TabIndex = 100086
        Me.Label38.Text = "Result"
        '
        'Label37
        '
        Me.Label37.BackColor = System.Drawing.Color.Transparent
        Me.Label37.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.ForeColor = System.Drawing.Color.Navy
        Me.Label37.Location = New System.Drawing.Point(1, 47)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(70, 37)
        Me.Label37.TabIndex = 100085
        Me.Label37.Text = "Test Conducted"
        '
        'Txt_Results
        '
        Me.Txt_Results.BackColor = System.Drawing.Color.White
        Me.Txt_Results.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Results.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Results.ForeColor = System.Drawing.Color.Blue
        Me.Txt_Results.Location = New System.Drawing.Point(83, 87)
        Me.Txt_Results.MaxLength = 500
        Me.Txt_Results.Multiline = True
        Me.Txt_Results.Name = "Txt_Results"
        Me.Txt_Results.Size = New System.Drawing.Size(221, 32)
        Me.Txt_Results.TabIndex = 100084
        '
        'Txt_Testconducted
        '
        Me.Txt_Testconducted.BackColor = System.Drawing.Color.White
        Me.Txt_Testconducted.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Testconducted.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Testconducted.ForeColor = System.Drawing.Color.Blue
        Me.Txt_Testconducted.Location = New System.Drawing.Point(83, 46)
        Me.Txt_Testconducted.MaxLength = 500
        Me.Txt_Testconducted.Multiline = True
        Me.Txt_Testconducted.Name = "Txt_Testconducted"
        Me.Txt_Testconducted.Size = New System.Drawing.Size(298, 39)
        Me.Txt_Testconducted.TabIndex = 100083
        '
        'Txt_Complaints
        '
        Me.Txt_Complaints.BackColor = System.Drawing.Color.White
        Me.Txt_Complaints.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Complaints.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Complaints.ForeColor = System.Drawing.Color.Blue
        Me.Txt_Complaints.Location = New System.Drawing.Point(83, 5)
        Me.Txt_Complaints.MaxLength = 500
        Me.Txt_Complaints.Multiline = True
        Me.Txt_Complaints.Name = "Txt_Complaints"
        Me.Txt_Complaints.Size = New System.Drawing.Size(298, 39)
        Me.Txt_Complaints.TabIndex = 100081
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.BackColor = System.Drawing.Color.Transparent
        Me.Label36.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.ForeColor = System.Drawing.Color.Navy
        Me.Label36.Location = New System.Drawing.Point(1, 18)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(70, 13)
        Me.Label36.TabIndex = 100082
        Me.Label36.Text = "Complaints"
        '
        'Btn_MRvw
        '
        Me.Btn_MRvw.BackColor = System.Drawing.Color.Transparent
        Me.Btn_MRvw.Enabled = False
        Me.Btn_MRvw.FlatAppearance.BorderSize = 0
        Me.Btn_MRvw.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_MRvw.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_MRvw.ForeColor = System.Drawing.Color.DarkBlue
        Me.Btn_MRvw.Location = New System.Drawing.Point(307, 98)
        Me.Btn_MRvw.Name = "Btn_MRvw"
        Me.Btn_MRvw.Size = New System.Drawing.Size(74, 21)
        Me.Btn_MRvw.TabIndex = 100080
        Me.Btn_MRvw.TabStop = False
        Me.Btn_MRvw.Text = "&View More"
        Me.Btn_MRvw.UseVisualStyleBackColor = False
        '
        'Patient_Uttility_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(829, 535)
        Me.Controls.Add(Me.Pnl_Accounts)
        Me.Controls.Add(Me.Pnl_Diagnosis)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Pnl_Insurance)
        Me.Controls.Add(Me.Pnl_History)
        Me.Controls.Add(Me.Pnl_CurrentStatus)
        Me.Controls.Add(Me.Pnl_PatientInfo)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Patient_Uttility_Frm"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_PatientInfo.ResumeLayout(False)
        Me.Pnl_PatientInfo.PerformLayout()
        Me.Pnl_Insurance.ResumeLayout(False)
        Me.Pnl_Insurance.PerformLayout()
        Me.Pnl_Accounts.ResumeLayout(False)
        Me.Pnl_Accounts.PerformLayout()
        Me.Pnl_History.ResumeLayout(False)
        Me.Pnl_History.PerformLayout()
        Me.Pnl_Diagnosis.ResumeLayout(False)
        Me.Pnl_Diagnosis.PerformLayout()
        Me.Pnl_Patient_CaseRecord.ResumeLayout(False)
        Me.Pnl_Patient_CaseRecord.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Pnl_CurrentStatus.ResumeLayout(False)
        Me.Pnl_CurrentStatus.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Pnl_PatientInfo As System.Windows.Forms.Panel
    Friend WithEvents Btn_viewmore As System.Windows.Forms.Button
    Friend WithEvents Btn_Find As System.Windows.Forms.Button
    Friend WithEvents Txt_Nationality As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Gender As System.Windows.Forms.TextBox
    Friend WithEvents Txt_PMRID As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_Familyname As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_SSNO As System.Windows.Forms.TextBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_Age As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_Mobile As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_Phone As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_Addr As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Visitor_Name As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Insurance As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Btn_InsureVw As System.Windows.Forms.Button
    Friend WithEvents Pnl_Accounts As System.Windows.Forms.Panel
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Lbl_OPID As System.Windows.Forms.Label
    Friend WithEvents Txt_OPD_ID As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Bill_Due As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Balance_Deposit As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Dedeucted_Amount As System.Windows.Forms.TextBox
    Friend WithEvents Txt_AdvanceDeposit As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Txt_Cash_Transaction As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Txt_Transfer As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Txt_Total As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Btn_HistoryVw As System.Windows.Forms.Button
    Friend WithEvents Pnl_History As System.Windows.Forms.Panel
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Btn_DiagnoVw As System.Windows.Forms.Button
    Friend WithEvents Pnl_Diagnosis As System.Windows.Forms.Panel
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Pnl_Patient_CaseRecord As System.Windows.Forms.Panel
    Friend WithEvents Txt_FooterText As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Bodytext As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Heading As System.Windows.Forms.TextBox
    Friend WithEvents Txt_DcotorName As System.Windows.Forms.TextBox
    Friend WithEvents Btn_CRvw As System.Windows.Forms.Button
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Txt_Diagnosis As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Diag_Status As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Diag_Comment As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Txt_Weight As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Txt_Temprature As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Txt_Height As System.Windows.Forms.TextBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Txt_BPDiastolic As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Txt_BPSystolic As System.Windows.Forms.TextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Txt_Respiration As System.Windows.Forms.TextBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Txt_Pulse As System.Windows.Forms.TextBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Txt_Bloodclass As System.Windows.Forms.TextBox
    Friend WithEvents Pnl_CurrentStatus As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Txt_Results As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Testconducted As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Complaints As System.Windows.Forms.TextBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Btn_MRvw As System.Windows.Forms.Button
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
End Class
