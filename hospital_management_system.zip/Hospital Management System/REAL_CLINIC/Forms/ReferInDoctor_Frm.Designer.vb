﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ReferInDoctor_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ReferInDoctor_Frm))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.Txt_Ref_DrAdd = New System.Windows.Forms.TextBox
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.Txt_Ref_Comm_Address = New System.Windows.Forms.TextBox
        Me.TabPage3 = New System.Windows.Forms.TabPage
        Me.Txt_Ref_OffAddress = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Txt_RefInHopital = New System.Windows.Forms.TextBox
        Me.Dgrd_ReferInDr = New System.Windows.Forms.DataGridView
        Me.Label9 = New System.Windows.Forms.Label
        Me.Txt_Ref_DrQF = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Txt_Ref_DrMobile2 = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.Txt_Ref_DrMobile1 = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Txt_Ref_DrPhone2 = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Txt_Ref_DrPhone1 = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Txt_Ref_DrName = New System.Windows.Forms.TextBox
        Me.Txt_Ref_DrID = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Delete = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.Btn_Find = New System.Windows.Forms.Button
        Me.Label4 = New System.Windows.Forms.Label
        Me.Cmb_Country = New System.Windows.Forms.ComboBox
        Me.Pnl_Header.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        CType(Me.Dgrd_ReferInDr, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Pnl_Tran_mode.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = CType(resources.GetObject("Pnl_Header.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Header.Controls.Add(Me.Label1)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(675, 24)
        Me.Pnl_Header.TabIndex = 45
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(3, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(180, 18)
        Me.Label1.TabIndex = 125
        Me.Label1.Text = "Refer In Doctor Master"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Location = New System.Drawing.Point(112, 102)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(489, 143)
        Me.TabControl1.TabIndex = 4
        '
        'TabPage1
        '
        Me.TabPage1.BackgroundImage = CType(resources.GetObject("TabPage1.BackgroundImage"), System.Drawing.Image)
        Me.TabPage1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TabPage1.Controls.Add(Me.Txt_Ref_DrAdd)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(481, 117)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Permanent "
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Txt_Ref_DrAdd
        '
        Me.Txt_Ref_DrAdd.BackColor = System.Drawing.Color.White
        Me.Txt_Ref_DrAdd.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Ref_DrAdd.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Ref_DrAdd.Location = New System.Drawing.Point(6, 6)
        Me.Txt_Ref_DrAdd.MaxLength = 500
        Me.Txt_Ref_DrAdd.Multiline = True
        Me.Txt_Ref_DrAdd.Name = "Txt_Ref_DrAdd"
        Me.Txt_Ref_DrAdd.Size = New System.Drawing.Size(469, 105)
        Me.Txt_Ref_DrAdd.TabIndex = 5
        '
        'TabPage2
        '
        Me.TabPage2.BackgroundImage = CType(resources.GetObject("TabPage2.BackgroundImage"), System.Drawing.Image)
        Me.TabPage2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TabPage2.Controls.Add(Me.Txt_Ref_Comm_Address)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(481, 117)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Communcation"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Txt_Ref_Comm_Address
        '
        Me.Txt_Ref_Comm_Address.BackColor = System.Drawing.Color.White
        Me.Txt_Ref_Comm_Address.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Ref_Comm_Address.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Ref_Comm_Address.Location = New System.Drawing.Point(6, 6)
        Me.Txt_Ref_Comm_Address.MaxLength = 500
        Me.Txt_Ref_Comm_Address.Multiline = True
        Me.Txt_Ref_Comm_Address.Name = "Txt_Ref_Comm_Address"
        Me.Txt_Ref_Comm_Address.Size = New System.Drawing.Size(469, 105)
        Me.Txt_Ref_Comm_Address.TabIndex = 15
        '
        'TabPage3
        '
        Me.TabPage3.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.LeftGradiant
        Me.TabPage3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TabPage3.Controls.Add(Me.Txt_Ref_OffAddress)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(481, 117)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Official"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'Txt_Ref_OffAddress
        '
        Me.Txt_Ref_OffAddress.BackColor = System.Drawing.Color.White
        Me.Txt_Ref_OffAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Ref_OffAddress.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Ref_OffAddress.Location = New System.Drawing.Point(6, 6)
        Me.Txt_Ref_OffAddress.MaxLength = 500
        Me.Txt_Ref_OffAddress.Multiline = True
        Me.Txt_Ref_OffAddress.Name = "Txt_Ref_OffAddress"
        Me.Txt_Ref_OffAddress.Size = New System.Drawing.Size(468, 105)
        Me.Txt_Ref_OffAddress.TabIndex = 16
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.ForeColor = System.Drawing.Color.Black
        Me.Label13.Location = New System.Drawing.Point(6, 252)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(52, 13)
        Me.Label13.TabIndex = 115
        Me.Label13.Text = "Country"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(7, 82)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(88, 13)
        Me.Label10.TabIndex = 114
        Me.Label10.Text = "Hospital Name"
        '
        'Txt_RefInHopital
        '
        Me.Txt_RefInHopital.BackColor = System.Drawing.Color.White
        Me.Txt_RefInHopital.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_RefInHopital.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_RefInHopital.Location = New System.Drawing.Point(113, 78)
        Me.Txt_RefInHopital.MaxLength = 15
        Me.Txt_RefInHopital.Name = "Txt_RefInHopital"
        Me.Txt_RefInHopital.Size = New System.Drawing.Size(488, 21)
        Me.Txt_RefInHopital.TabIndex = 3
        '
        'Dgrd_ReferInDr
        '
        Me.Dgrd_ReferInDr.AllowUserToAddRows = False
        Me.Dgrd_ReferInDr.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(252, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.Navy
        Me.Dgrd_ReferInDr.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.Dgrd_ReferInDr.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Dgrd_ReferInDr.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(87, Byte), Integer), CType(CType(157, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgrd_ReferInDr.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.Dgrd_ReferInDr.ColumnHeadersHeight = 20
        Me.Dgrd_ReferInDr.Location = New System.Drawing.Point(9, 347)
        Me.Dgrd_ReferInDr.MultiSelect = False
        Me.Dgrd_ReferInDr.Name = "Dgrd_ReferInDr"
        Me.Dgrd_ReferInDr.ReadOnly = True
        Me.Dgrd_ReferInDr.RowHeadersVisible = False
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(254, Byte), Integer))
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.Navy
        Me.Dgrd_ReferInDr.RowsDefaultCellStyle = DataGridViewCellStyle3
        Me.Dgrd_ReferInDr.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.Dgrd_ReferInDr.Size = New System.Drawing.Size(663, 154)
        Me.Dgrd_ReferInDr.TabIndex = 113
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(7, 324)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(77, 13)
        Me.Label9.TabIndex = 112
        Me.Label9.Text = "Qualification"
        '
        'Txt_Ref_DrQF
        '
        Me.Txt_Ref_DrQF.BackColor = System.Drawing.Color.White
        Me.Txt_Ref_DrQF.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Ref_DrQF.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Ref_DrQF.Location = New System.Drawing.Point(113, 320)
        Me.Txt_Ref_DrQF.MaxLength = 150
        Me.Txt_Ref_DrQF.Name = "Txt_Ref_DrQF"
        Me.Txt_Ref_DrQF.Size = New System.Drawing.Size(488, 21)
        Me.Txt_Ref_DrQF.TabIndex = 11
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(320, 300)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(92, 13)
        Me.Label7.TabIndex = 111
        Me.Label7.Text = "Mobile phone 2"
        '
        'Txt_Ref_DrMobile2
        '
        Me.Txt_Ref_DrMobile2.BackColor = System.Drawing.Color.White
        Me.Txt_Ref_DrMobile2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Ref_DrMobile2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Ref_DrMobile2.Location = New System.Drawing.Point(418, 296)
        Me.Txt_Ref_DrMobile2.MaxLength = 15
        Me.Txt_Ref_DrMobile2.Name = "Txt_Ref_DrMobile2"
        Me.Txt_Ref_DrMobile2.Size = New System.Drawing.Size(183, 21)
        Me.Txt_Ref_DrMobile2.TabIndex = 10
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(7, 300)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(92, 13)
        Me.Label8.TabIndex = 110
        Me.Label8.Text = "Mobile Phone 1"
        '
        'Txt_Ref_DrMobile1
        '
        Me.Txt_Ref_DrMobile1.BackColor = System.Drawing.Color.White
        Me.Txt_Ref_DrMobile1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Ref_DrMobile1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Ref_DrMobile1.Location = New System.Drawing.Point(113, 296)
        Me.Txt_Ref_DrMobile1.MaxLength = 15
        Me.Txt_Ref_DrMobile1.Name = "Txt_Ref_DrMobile1"
        Me.Txt_Ref_DrMobile1.Size = New System.Drawing.Size(182, 21)
        Me.Txt_Ref_DrMobile1.TabIndex = 9
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(360, 276)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(52, 13)
        Me.Label6.TabIndex = 109
        Me.Label6.Text = "Phone 2"
        '
        'Txt_Ref_DrPhone2
        '
        Me.Txt_Ref_DrPhone2.BackColor = System.Drawing.Color.White
        Me.Txt_Ref_DrPhone2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Ref_DrPhone2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Ref_DrPhone2.Location = New System.Drawing.Point(418, 272)
        Me.Txt_Ref_DrPhone2.MaxLength = 15
        Me.Txt_Ref_DrPhone2.Name = "Txt_Ref_DrPhone2"
        Me.Txt_Ref_DrPhone2.Size = New System.Drawing.Size(183, 21)
        Me.Txt_Ref_DrPhone2.TabIndex = 8
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(7, 276)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(52, 13)
        Me.Label5.TabIndex = 108
        Me.Label5.Text = "Phone 1"
        '
        'Txt_Ref_DrPhone1
        '
        Me.Txt_Ref_DrPhone1.BackColor = System.Drawing.Color.White
        Me.Txt_Ref_DrPhone1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Ref_DrPhone1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Ref_DrPhone1.Location = New System.Drawing.Point(113, 272)
        Me.Txt_Ref_DrPhone1.MaxLength = 15
        Me.Txt_Ref_DrPhone1.Name = "Txt_Ref_DrPhone1"
        Me.Txt_Ref_DrPhone1.Size = New System.Drawing.Size(182, 21)
        Me.Txt_Ref_DrPhone1.TabIndex = 7
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(7, 58)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(39, 13)
        Me.Label3.TabIndex = 106
        Me.Label3.Text = "Name"
        '
        'Txt_Ref_DrName
        '
        Me.Txt_Ref_DrName.BackColor = System.Drawing.Color.White
        Me.Txt_Ref_DrName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Ref_DrName.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Ref_DrName.Location = New System.Drawing.Point(113, 54)
        Me.Txt_Ref_DrName.MaxLength = 150
        Me.Txt_Ref_DrName.Name = "Txt_Ref_DrName"
        Me.Txt_Ref_DrName.Size = New System.Drawing.Size(488, 21)
        Me.Txt_Ref_DrName.TabIndex = 2
        '
        'Txt_Ref_DrID
        '
        Me.Txt_Ref_DrID.BackColor = System.Drawing.Color.White
        Me.Txt_Ref_DrID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Ref_DrID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Ref_DrID.Location = New System.Drawing.Point(113, 30)
        Me.Txt_Ref_DrID.MaxLength = 8
        Me.Txt_Ref_DrID.Name = "Txt_Ref_DrID"
        Me.Txt_Ref_DrID.Size = New System.Drawing.Size(291, 21)
        Me.Txt_Ref_DrID.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(7, 34)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(61, 13)
        Me.Label2.TabIndex = 105
        Me.Label2.Text = "Doctor ID"
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(527, 30)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(74, 22)
        Me.Pnl_Tran_mode.TabIndex = 104
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(1, 1)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(68, 16)
        Me.Lbl_Tran_Mode.TabIndex = 126
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Delete)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(609, 215)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(62, 126)
        Me.Pnl_Common_Btn.TabIndex = 103
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(2, 63)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear.TabIndex = 14
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(2, 94)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 15
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Delete
        '
        Me.Btn_Delete.BackgroundImage = CType(resources.GetObject("Btn_Delete.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Delete.Location = New System.Drawing.Point(2, 33)
        Me.Btn_Delete.Name = "Btn_Delete"
        Me.Btn_Delete.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Delete.TabIndex = 13
        Me.Btn_Delete.Text = "&Delete"
        Me.Btn_Delete.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = CType(resources.GetObject("Btn_Save.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(2, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save.TabIndex = 12
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Btn_Find
        '
        Me.Btn_Find.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find.BackgroundImage = CType(resources.GetObject("Btn_Find.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find.ForeColor = System.Drawing.Color.White
        Me.Btn_Find.Location = New System.Drawing.Point(406, 30)
        Me.Btn_Find.Name = "Btn_Find"
        Me.Btn_Find.Size = New System.Drawing.Size(29, 21)
        Me.Btn_Find.TabIndex = 1
        Me.Btn_Find.TabStop = False
        Me.Btn_Find.Text = "F2"
        Me.Btn_Find.UseVisualStyleBackColor = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(6, 105)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(89, 13)
        Me.Label4.TabIndex = 116
        Me.Label4.Text = "Address Detail"
        '
        'Cmb_Country
        '
        Me.Cmb_Country.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Country.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Country.FormattingEnabled = True
        Me.Cmb_Country.Location = New System.Drawing.Point(113, 248)
        Me.Cmb_Country.Name = "Cmb_Country"
        Me.Cmb_Country.Size = New System.Drawing.Size(490, 21)
        Me.Cmb_Country.TabIndex = 6
        '
        'ReferInDoctor_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(675, 504)
        Me.Controls.Add(Me.Cmb_Country)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Txt_RefInHopital)
        Me.Controls.Add(Me.Dgrd_ReferInDr)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Txt_Ref_DrQF)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Txt_Ref_DrMobile2)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Txt_Ref_DrMobile1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Txt_Ref_DrPhone2)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Txt_Ref_DrPhone1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Txt_Ref_DrName)
        Me.Controls.Add(Me.Txt_Ref_DrID)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Pnl_Tran_mode)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.Btn_Find)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "ReferInDoctor_Frm"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Refer In Doctor"
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        CType(Me.Dgrd_ReferInDr, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Pnl_Tran_mode.ResumeLayout(False)
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Txt_Ref_Comm_Address As System.Windows.Forms.TextBox
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents Txt_Ref_DrAdd As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Txt_RefInHopital As System.Windows.Forms.TextBox
    Friend WithEvents Dgrd_ReferInDr As System.Windows.Forms.DataGridView
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Txt_Ref_DrQF As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Txt_Ref_DrMobile2 As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Txt_Ref_DrMobile1 As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Txt_Ref_DrPhone2 As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Txt_Ref_DrPhone1 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Txt_Ref_DrName As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Ref_DrID As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Delete As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Btn_Find As System.Windows.Forms.Button
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents Txt_Ref_OffAddress As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Country As System.Windows.Forms.ComboBox
End Class
