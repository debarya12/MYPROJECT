﻿

Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls

Public Class Usermanagement_Frm

#Region " D e c l a r a t i o n s "

    'Object of Employee Details Bussiness Layer
    Private Emp_BL As EmpDetails_BL_Cls
    Private mTr_Mode As Tran_Mode

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing


    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_Emp_ID.BackColor = Color.White
                    Me.Btn_Delete.Enabled = False
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_Emp_ID.BackColor = Color.Silver
                    Me.Btn_Delete.Enabled = True
            End Select
        End Set
    End Property


#End Region

#Region " M e t h o d s "

    Private Function Validate_Fields() As Boolean
        Try
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If


            If Tr_Mode <> Tran_Mode.New_Mode Then
                If Txt_Emp_ID.Text.Trim = "" Then MessageBox.Show("Invalid Employee ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Emp_ID.Focus() : Exit Function
            End If

            If Txt_Emp_Name.Text.Trim = "" Then MessageBox.Show("Invalid Employee Name,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Emp_Name.Focus() : Exit Function
            If Txt_Emp_Add.Text.Trim = "" Then MessageBox.Show("Invalid Employee Address,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Emp_Add.Focus() : Exit Function

            If Tr_Mode <> Tran_Mode.New_Mode Then
                If Txt_CurrPWD.Text.Trim = "" Then MessageBox.Show("Invalid Current Password,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_CurrPWD.Focus() : Exit Function
                If Txt_CurrPWD.Text.Trim <> "" Then
                    If Txt_CurrPWD.Tag.ToString.Trim <> Txt_CurrPWD.Text.Trim Then
                        MessageBox.Show("Incorrect Current password,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Txt_CurrPWD.Focus() : Exit Function
                    End If
                End If
            End If

            If Txt_NewPWD.Text.Trim = "" Then MessageBox.Show("Invalid New Password,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_NewPWD.Focus() : Exit Function
            If Txt_ConfPWD.Text.Trim = "" Then MessageBox.Show("Invalid Confirm Password,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_ConfPWD.Focus() : Exit Function
            If Txt_NewPWD.Text.Trim <> Txt_ConfPWD.Text.Trim Then
                MessageBox.Show("New Password and Confirm Password should match,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_ConfPWD.Focus() : Exit Function
            End If

            If Dtp_Activatedate.Value = Dtp_Validupto.Value Then
                MessageBox.Show("Activate date and Validupto are same,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Dtp_Validupto.Focus() : Exit Function
            End If


            Return True

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try

    End Function

    Private Sub Clear_Form()
        Try

            Txt_Emp_ID.Text = ""
            Txt_Emp_ID.Tag = ""
            Txt_Emp_Name.Text = ""
            Txt_Emp_Add.Text = ""
            Txt_Username.Text = ""
            Txt_CurrPWD.Text = ""
            Txt_CurrPWD.Tag = ""
            Txt_NewPWD.Text = ""
            Txt_ConfPWD.Text = ""
            Txt_CurrPWD.Enabled = False
            Txt_Username.ReadOnly = False

            If Cmb_Userstatus.Items.Count > 0 Then Cmb_Userstatus.SelectedIndex = 0

            Dtp_Activatedate.Value = Tran_Date
            Dtp_Activatedate.MinDate = Tran_Date

            Tr_Mode = Tran_Mode.New_Mode


            Btn_Save.Enabled = True
            Btn_Delete.Enabled = False
            If ImageViewer_Frm.Visible Then ImageViewer_Frm.Visible = False

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Function Locate_EmpDetails(ByVal Emp_ID As Integer) As Boolean


        Try


            'Initialising BL Object
            Emp_BL = New EmpDetails_BL_Cls
            Dtbl = Nothing
            Call Clear_Form()
            Txt_Emp_ID.Text = Emp_ID

            'Locating Images if available
            Call ShowImageviewer(Me, Txt_Emp_ID.Text.Trim, Customer_Type.Employee)

            'Retreiving Employee Details and Assign the values to respective controls
            If Emp_BL.GetEmp_Details(Dtbl, Emp_ID) Then
                Dr = Dtbl.CreateDataReader()
                Dr.Read()
                With Dr
                    Txt_Emp_ID.Text = Emp_ID
                    Txt_Emp_ID.Tag = Emp_ID
                    Txt_Emp_Name.Text = .GetValue(1).ToString.Trim
                    Txt_Emp_Add.Text = .GetValue(2).ToString.Trim
                    If Len(Txt_Emp_Add.Text) > 150 Then Txt_Emp_Add.ScrollBars = ScrollBars.Both Else Txt_Emp_Add.ScrollBars = ScrollBars.None
                End With
                Return True
            Else
                Return False
            End If



        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        Finally
            Dr = Nothing
            Dtbl = Nothing
            Emp_BL = Nothing
        End Try

    End Function

    Private Function Locate_Userdetails(ByVal Emp_ID As Integer) As Boolean

        Dim Dr As DataTableReader
        Dim Dtbl As DataTable = Nothing

        Try

            'Initialising BL Object
            Emp_BL = New EmpDetails_BL_Cls

            'Retreiving User Details and Assign the values to respective controls
            If Emp_BL.GetUser_Details(Dtbl, Emp_ID) Then
                Dr = Dtbl.CreateDataReader()

                While Dr.Read()
                    If Dr.GetString(5).ToString.Trim = "A" Then
                        With Dr
                            Txt_Username.Text = .GetString(0).ToString.Trim
                            Txt_CurrPWD.Tag = DecodeText(.GetValue(1).ToString.Trim)
                            If .GetString(5).ToString.Trim = "A" Then
                                Cmb_Userstatus.SelectedIndex = 0
                            Else
                                Cmb_Userstatus.SelectedIndex = 1
                            End If
                            Dtp_Activatedate.MinDate = Trim(.GetDateTime(3))
                            Dtp_Activatedate.Value = Trim(.GetDateTime(3))
                            Dtp_Validupto.Value = Trim(.GetDateTime(4))
                        End With
                        Return True
                    End If
                End While
                Return False
            Else
                Return False
            End If



        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        Finally
            Dr = Nothing
            Dtbl = Nothing
            Emp_BL = Nothing
        End Try

    End Function

#End Region

    Private Sub Close_Btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click

        Me.Close()

    End Sub

    Private Sub Usermanagement_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.F2 Then Btn_Find_Click(sender, e)
        If e.KeyCode = Keys.Enter Then Call SendKeyTab()
    End Sub

    Private Sub Usermanagement_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub Emp_Details_Frm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try

            Call Set_Environment()

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub Clear_Btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try
            Call Clear_Form()
            Txt_Emp_ID.Focus()
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Delete_Btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click
        Try
            'Validating Mandatory fields for Deleting
            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If

            If Tr_Mode = Tran_Mode.New_Mode Then
                MessageBox.Show("You have to locate details before deleting the record", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

            If Txt_Username.Text.Trim = "" Then
                MessageBox.Show("Invalid User Name,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_Emp_ID.Focus() : Exit Sub
            End If

            'Initialising BL Object
            Emp_BL = New EmpDetails_BL_Cls

            If Emp_BL.DelUser_Details(Txt_Username.Text.Trim) Then
                Call Clear_Form()
                MessageBox.Show("User Details Deleted", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("You cannot delete this User details" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            Emp_BL = Nothing
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try
            If Txt_Emp_ID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "25|200|200|"
                Sql = "SELECT Name, Address, Phone, Mobile, Email, Status, [Admit Date], [Deactivate Date], Emp_ID From Emp_Details_Vw"
                Call ShowSearchengine(Txt_Emp_ID, Sql, 8, "Name", Colwidth, , 0)
            End If


            'Validating Mandatory fields for locating
            If Txt_Emp_ID.Text.Trim = "" Then
                'MessageBox.Show("Invalid Employee ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_Emp_ID.Focus() : Exit Sub
            End If


            If Locate_EmpDetails(Txt_Emp_ID.Text.Trim) Then
                If Locate_Userdetails(Txt_Emp_ID.Text.Trim) Then
                    Tr_Mode = Tran_Mode.Edit_Mode
                    Txt_Username.ReadOnly = True
                    Txt_CurrPWD.Enabled = True
                    Txt_CurrPWD.Focus()
                Else
                    Txt_CurrPWD.Enabled = False
                    Txt_Username.ReadOnly = False
                    Txt_Username.Focus()
                End If

            Else
                MessageBox.Show("Employee ID does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Sub Set_Environment()
        Try

            'Populating Status Combo
            If Cmb_Userstatus.Items.Count = 0 Then
                With Cmb_Userstatus
                    .Items.Add("Active")
                    .Items.Add("InActive")
                    .SelectedIndex = 0
                End With
                'Call Clear_Form()
            Else

                If Txt_Emp_ID.Text.Trim <> "" Then
                    'Locating Images if available
                    Call ShowImageviewer(Me, Txt_Emp_ID.Text.Trim, Customer_Type.Employee)
                End If

            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try
            'Initialising BL Object
            Emp_BL = New EmpDetails_BL_Cls

            'Validating Data controls
            If Not Validate_Fields() Then Exit Sub

            'Validating Duplicate User name exists or not
            If Tr_Mode = Tran_Mode.New_Mode Then
                Dim Com_BL As New HMS_Common_BL_Cls
                If Com_BL.Check_Duplicatedataexists("User_Details_Tbl", "User_Name", Data_Type.Alphanumeric_Type, Txt_Username.Text.Trim, Branch_Code) Then
                    MessageBox.Show("User Details already exists,Please Try another one", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Txt_Username.Focus() : Exit Sub
                End If
            End If


            'Assigning Values to BL Properties
            Emp_BL.Emp_ID = Val(Txt_Emp_ID.Text.Trim)
            Emp_BL.User_Name = Txt_Username.Text.Trim
            Emp_BL.User_Pwd = EncodeText(Txt_NewPWD.Text.Trim)
            Emp_BL.User_Activatedate = Dtp_Activatedate.Value.ToString
            Emp_BL.User_Validupto = Dtp_Validupto.Value.ToString
            Emp_BL.User_Active = Strings.Left(Cmb_Userstatus.Text, 1).ToUpper
            Emp_BL.User_Lastupdated = Tran_Date.ToString

            Dtbl = Nothing

            'Saving User Details using BL method
            If Emp_BL.Save_User_Details(Dtbl, Txt_Username.Text.Trim, Tr_Mode) Then
                MessageBox.Show("User Details Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Call Clear_Form()
                Dr = Dtbl.CreateDataReader()
                Dr.Read()
                With Dr
                    Txt_Emp_ID.Text = .GetValue(2).ToString.Trim
                    Call Btn_Find_Click(sender, e)
                End With
                Exit Sub
            Else
                MessageBox.Show("User Details not Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, Product_Name)
        End Try
    End Sub

    Private Sub Cmb_Userstatus_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_Userstatus.SelectedIndexChanged
        Try
            If Cmb_Userstatus.SelectedIndex = 0 Then
                Lbl_ActDeactivate.Text = "Activation Date"
            Else
                Lbl_ActDeactivate.Text = "Deactivate Date"
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_CurrPWD_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_CurrPWD.Validating
        Try
            If Txt_CurrPWD.Text.Trim <> "" Then
                If Txt_CurrPWD.Tag.ToString.Trim <> Txt_CurrPWD.Text.Trim Then
                    MessageBox.Show("Incorrect Current password,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    e.Cancel = True
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Dtp_Activatedate_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Dtp_Activatedate.ValueChanged
        Try
            If Tr_Mode = Tran_Mode.New_Mode Then
                Dtp_Validupto.Value = DateAdd(DateInterval.Year, 1, Dtp_Activatedate.Value)
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_Emp_ID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_Emp_ID.Validating
        Try
            If Me.Txt_Emp_ID.Text.Trim <> "" And Me.Txt_Emp_ID.Text <> Me.Txt_Emp_ID.Tag Then
                If Locate_EmpDetails(Txt_Emp_ID.Text.Trim) Then
                    If Locate_Userdetails(Txt_Emp_ID.Text.Trim) Then
                        Tr_Mode = Tran_Mode.Edit_Mode
                        Txt_Username.ReadOnly = True
                        Txt_CurrPWD.Enabled = True
                        Txt_CurrPWD.Focus()
                    Else
                        Txt_CurrPWD.Enabled = False
                        Txt_Username.ReadOnly = False
                        Txt_Username.Focus()
                    End If
                Else
                    MessageBox.Show("Employee ID does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Txt_Emp_ID.Focus()
                    e.Cancel = True
                End If
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub Txt_Emp_ID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Emp_ID.TextChanged
        If Txt_Emp_ID.Text.Trim = "" Then
            Call Clear_Form()
        End If
    End Sub

    Private Sub Usermanagement_Frm_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        Call KeepRightofme(Me, ImageViewer_Frm)
    End Sub

    Private Sub Usermanagement_Frm_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        Call KeepRightofme(Me, ImageViewer_Frm)
    End Sub

End Class