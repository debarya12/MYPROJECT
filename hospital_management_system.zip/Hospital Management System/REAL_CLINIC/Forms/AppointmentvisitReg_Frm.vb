﻿

Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls

Public Class AppointmentvisitReg_Frm

#Region " D e c l a r a  t i o n s "

    Private hms_helper As HMS_Helper = Nothing
    Private Apoint_Bl As Appointment_BL_Cls


    Dim Service_Dtbl As DataTable = Nothing
    Dim doc_Dtbl As DataTable = Nothing
    Dim Apoint_Dtbl As DataTable = Nothing

    Dim frm_Heading As String = ""
    Dim tick_Ctr As Int16 = 0

#End Region

#Region " P r o p e r t i e s "
    'Appointment Service Property
    Private _App_Service_ID As Integer = 0
    Private Property App_Service_ID() As Integer
        Get
            Return _App_Service_ID
        End Get
        Set(ByVal value As Integer)
            _App_Service_ID = value

            If _App_Service_ID = 0 Then Exit Property

            Call Populate_Doctorlist(_App_Service_ID)

        End Set
    End Property

    Private _Seldoctor_ID As Integer = 0
    Private Property Seldoctor_ID() As Integer
        Get
            Return _Seldoctor_ID
        End Get
        Set(ByVal value As Integer)
            _Seldoctor_ID = value
        End Set
    End Property

#End Region

#Region " M e t h o d s "

    Private Function Populate_Doctorlist(ByVal ServiceID As Integer) As Boolean
        Try

            Dim btnSomething As ToolStripButton

            TlStrp_Doctors.Items.Clear()

            If hms_helper.Get_Doctorswithservices(doc_Dtbl, ServiceID, Tran_Date, Branch_Code) Then

                For i = 0 To doc_Dtbl.Rows.Count - 1
                    btnSomething = New ToolStripButton
                    With btnSomething
                        .Text = doc_Dtbl.Rows(i).Item("Name").ToString

                        .Tag = doc_Dtbl.Rows(i).Item("DoctorID").ToString
                        .Image = My.Resources.Health_care_shield_32
                        .ImageAlign = ContentAlignment.TopCenter
                        .ImageScaling = ToolStripItemImageScaling.None
                        .ForeColor = Color.Maroon
                        .DisplayStyle = ToolStripItemDisplayStyle.ImageAndText
                        .TextImageRelation = TextImageRelation.ImageAboveText
                    End With
                    TlStrp_Doctors.Items.Add(btnSomething)
                Next

            End If
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Clear_Form()
        Try
            With Me
                Call Clear_Grid()
                .Txt_Tokenno.Text = ""
                .Txt_Tokenno.Tag = ""
                .Txt_Visitor_SSNO.Text = ""
                .Txt_Visitor_Name.Text = ""
                .Txt_Visitor_Addr.Text = ""
                .Txt_Visitor_Familyname.Text = ""
                .Txt_Visitor_Age.Text = ""
                .Txt_Visitor_Mobile.Text = ""
                .Txt_Visitor_Phone.Text = ""
                .Txt_Gender.Text = ""
                .Cmb_Status.SelectedIndex = 0
                Lbl_Wnos.Text = 0
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Clear_Values()
        Try
            With Me
                .Txt_Tokenno.Text = ""
                .Txt_Tokenno.Tag = ""
                .Txt_Visitor_SSNO.Text = ""
                .Txt_Visitor_Name.Text = ""
                .Txt_Visitor_Addr.Text = ""
                .Txt_Visitor_Familyname.Text = ""
                .Txt_Visitor_Age.Text = ""
                .Txt_Visitor_Mobile.Text = ""
                .Txt_Visitor_Phone.Text = ""
                .Txt_Gender.Text = ""
                .Cmb_Status.SelectedIndex = 0
                .Timer2.Enabled = False
                .Lbl_OPValidator.ForeColor = Color.DarkBlue
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Function Locate_Values(ByVal Apoint_ID As String, ByVal Br_Code As Integer) As Boolean
        Try
            Dim Dtbl As DataTable = Nothing
            If Not Apoint_Bl.Get_ApointmentVisitordetails(Dtbl, Apoint_ID, Br_Code) Then Return False

            Call Clear_Values()

            With Dtbl
                If Txt_Tokenno.Text = "" Then
                    Txt_Tokenno.Text = .Rows(0).Item("V_Tokenno").ToString
                    Txt_Tokenno.Tag = .Rows(0).Item("V_ApointID").ToString
                End If

                'OP Validation
                If .Rows(0).Item("V_OPID").ToString = "" Then
                    Lbl_OPValidator.Text = "OP REGISTRATION NOT DONE"
                    Lbl_OPValidator.Tag = 2
                    Btn_Save.Enabled = False
                ElseIf CDate(.Rows(0).Item("V_OPValidity").ToString) < Tran_Date Then
                    Lbl_OPValidator.Text = "OP EXPIRED"
                    Lbl_OPValidator.Tag = 0
                    Btn_Save.Enabled = False
                Else
                    Lbl_OPValidator.Text = "ON QUEUE"
                    Lbl_OPValidator.Tag = 1
                    Btn_Save.Enabled = True

                End If

                If Lbl_OPValidator.Tag <> 1 Then
                    Timer2.Enabled = True
                    Timer2_Tick(Nothing, Nothing)
                End If

                Txt_Visitor_SSNO.Text = .Rows(0).Item("V_SSNo").ToString
                Txt_Visitor_Name.Text = .Rows(0).Item("V_Name").ToString.ToUpper
                Txt_Visitor_Addr.Text = .Rows(0).Item("V_Addr").ToString
                Txt_Visitor_Familyname.Text = .Rows(0).Item("V_Familyname").ToString
                Txt_Visitor_Age.Text = .Rows(0).Item("V_Age").ToString
                Txt_Visitor_Age.Text = IIf(Txt_Visitor_Age.Text.Trim = "0", "", Txt_Visitor_Age.Text)
                Txt_Visitor_Mobile.Text = .Rows(0).Item("V_Mobile").ToString
                Txt_Visitor_Phone.Text = .Rows(0).Item("V_Phone").ToString
                Txt_Gender.Text = .Rows(0).Item("V_Gender").ToString
                Txt_Gender.Text = IIf(Txt_Gender.Text.Trim = "M", "Male", "Female")
                Txt_Nationality.Text = .Rows(0).Item("V_Country").ToString.ToUpper
            End With

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Clear_Grid()
        Try
            With Dgrd_Appointment

                .RowCount = 0

            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Function Populate_ApointmentQueue(ByVal DocID As Int32, ByVal ServiceID As Int32) As Boolean
        Try
            Apoint_Bl = New Appointment_BL_Cls
            Call Clear_Form()

            If Not Apoint_Bl.Get_ApointmentQueue(Apoint_Dtbl, DocID, ServiceID, Tran_Date, Branch_Code) Then Return False
            Txt_Tokenno.Text = ""
            With Dgrd_Appointment
                For i = 0 To Apoint_Dtbl.Rows.Count - 1
                    .Rows.Add()
                    .Rows(.RowCount - 1).Cells("Token").Value = Apoint_Dtbl.Rows(i).Item("Apoint_Tokenno").ToString
                    If Txt_Tokenno.Text = "" Then
                        Txt_Tokenno.Text = Apoint_Dtbl.Rows(i).Item("Apoint_Tokenno").ToString
                        Txt_Tokenno.Tag = Apoint_Dtbl.Rows(i).Item("Apoint_ID").ToString
                    End If

                    .Rows(.RowCount - 1).Cells("Token").Value += vbCrLf + Apoint_Dtbl.Rows(i).Item("Visitor_Name").ToString
                    .Rows(.RowCount - 1).Cells("Token").Tag = Apoint_Dtbl.Rows(i).Item("Apoint_ID").ToString
                    .Rows(.RowCount - 1).Cells("Time").Value = Apoint_Dtbl.Rows(i).Item("Apoint_AproxStime").ToString
                    .Rows(.RowCount - 1).Cells("Visitor").Value = Apoint_Dtbl.Rows(i).Item("Visitor_Name").ToString
                Next
                Lbl_Wnos.Text = .RowCount
                If .RowCount > 0 Then
                    Call Locate_Values(.Rows(0).Cells("Token").Tag, Branch_Code)
                    Lbl_Wnos.Text = .RowCount
                End If
            End With



        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Refresh_Grid()
        Try
            Call Populate_ApointmentQueue(Seldoctor_ID, Cmb_Service.SelectedValue)
            Timer1.Enabled = True
            tick_Ctr = 0
            Call Timer1_Tick(Nothing, Nothing)
        Catch ex As Exception

        End Try
    End Sub

    Private Function Validate_Fields() As Boolean
        Try


            If Val(Txt_Tokenno.Tag) = 0 Then
                MessageBox.Show("Invalid Apointment,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Txt_Tokenno.Focus() : Return False
            End If

            If Lbl_OPValidator.Tag = 0 Then
                MessageBox.Show("OP Expired,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Txt_Tokenno.Focus() : Return False
            ElseIf Lbl_OPValidator.Tag = 0 Then
                MessageBox.Show("OP Registration not done,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Txt_Tokenno.Focus() : Return False
            End If

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

#End Region

    Private Sub AppointmentvisitReg_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Try
            If e.KeyCode = Keys.F5 Then Call Btn_Refresh_Click(Nothing, Nothing)
            If e.KeyCode = Keys.Enter Then Call SendKeyTab()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub AppointmentvisitReg_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub AppointmentvisitReg_Frm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            hms_helper = New Hms_Helperimpliments

            frm_Heading = Lbl_Heading.Text

            If hms_helper.Get_ApointmentServices(Service_Dtbl, Branch_Code) Then
                Call Fill_Combo(Cmb_Service, Service_Dtbl, "Service Name", "Service_ID")
            End If

            If Cmb_Service.Items.Count > 0 Then
                Cmb_Service.SelectedIndex = -1
                Cmb_Service.SelectedIndex = 0
            End If

            With Cmb_Status
                .Items.Clear()
                .Items.Add("Visited")
                .Items.Add("Abscent")
                .SelectedIndex = 0
            End With

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Cmb_Service_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_Service.SelectedIndexChanged
        Try
            Me.App_Service_ID = 0
            Me.App_Service_ID = Cmb_Service.SelectedValue

        Catch ex As Exception

        End Try
    End Sub

    Private Sub TlStrp_Doctors_ItemClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles TlStrp_Doctors.ItemClicked
        Try

            Dim btn_Doctor As ToolStripButton
            btn_Doctor = New ToolStripButton

            For Each btn_Doctor In TlStrp_Doctors.Items
                btn_Doctor.BackColor = Color.White
                btn_Doctor.ForeColor = Color.DarkBlue
            Next

            btn_Doctor = e.ClickedItem


            e.ClickedItem.BackColor = Color.FromArgb(60, 113, 193)
            e.ClickedItem.ForeColor = Color.White

            Lbl_Heading.Text = frm_Heading + "  of  " + e.ClickedItem.Text.ToUpper

            Call Clear_Form()
            Seldoctor_ID = 0

            With btn_Doctor
                Timer1.Enabled = False
                Seldoctor_ID = Val(.Tag)
                Call Populate_ApointmentQueue(Seldoctor_ID, Cmb_Service.SelectedValue)
                Timer1.Enabled = True
                Call Timer1_Tick(Nothing, Nothing)
            End With

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Timer1_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Try
            Lbl_Date.Text = Format(Tran_Date, "dd-MM-yyyy") + "    " + Format(Now, "hh:mm:ss tt")
            tick_Ctr += 1
            If tick_Ctr = 30 Then
                If Seldoctor_ID = 0 Then Return
                If App_Service_ID = 0 Then Return
                Call Populate_ApointmentQueue(Seldoctor_ID, Cmb_Service.SelectedValue)
                tick_Ctr = 0
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Try
            Me.Close()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try

            '------------------------------------------------------------------------------------
            'Validating Fields
            If Not Validate_Fields() Then Return

            '------------------------------------------------------------------------------------

            Apoint_Bl = New Appointment_BL_Cls
            Dim dtbl As DataTable = Nothing
            With Apoint_Bl
                If Not .Update_Appointmentstatus(dtbl, Val(Txt_Tokenno.Tag), Strings.Left(Cmb_Status.Text, 1), Format(Now, "hh:mm:ss tt"), Branch_Code) Then
                    MessageBox.Show("Error Occured While Updating Appointment Status,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Else
                    If dtbl.Rows(0).Item("Apoint_Status") = "Y" Then
                        MessageBox.Show("Appointment Status Updated", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Else
                        MessageBox.Show("Error Occured While Updating Appointment Status,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                End If
                ' MessageBox.Show("Appointment Status Updated", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Call Refresh_Grid()
            End With


        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Dgrd_Appointment_CellDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgrd_Appointment.CellDoubleClick
        Try
            With Dgrd_Appointment
                If e.RowIndex = -1 Then Exit Sub
                If e.ColumnIndex = -1 Then Exit Sub
                If .Rows(e.RowIndex).Cells("Token").Tag = "" Then
                    Return
                End If
                Call Locate_Values(.Rows(e.RowIndex).Cells("Token").Tag, Branch_Code)

                tick_Ctr = 0
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgrd_Appointment_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Dgrd_Appointment.KeyDown
        Try
            If Not e.KeyCode = Keys.Enter Then Exit Sub
            With Dgrd_Appointment
                If .CurrentRow Is Nothing Then Exit Sub
                If .CurrentCell Is Nothing Then Exit Sub
                If .Rows(.CurrentRow.Index).Cells("Token").Tag = "" Then
                    Return
                End If
                Call Locate_Values(.Rows(.CurrentRow.Index).Cells("Token").Tag, Branch_Code)

                tick_Ctr = 0
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Refresh_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Refresh.Click
        Try
            Call Refresh_Grid()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Timer2_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        Try
            If Timer2.Tag = 1 Then
                Lbl_OPValidator.ForeColor = Color.Red
                Timer2.Tag = 0
            Else
                Lbl_OPValidator.ForeColor = Color.DarkBlue
                Timer2.Tag = 1
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try
            Call Timer1_Tick(Nothing, Nothing)
        Catch ex As Exception

        End Try
    End Sub

End Class