﻿
Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls

Public Class Inpatient_Master_Frm
#Region "Declarations"
    'Object of Patient Details Bussiness Layer
    ' Private Doctor_BL As OutPatient_BL_Cls
    Private hms_helper As HMS_Helper = Nothing
    Private InPatient_BL As InPatientMaster_BL_Cls

    Private mTr_Mode As Tran_Mode
    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_IP_ID.BackColor = Color.White
                    Me.Txt_IP_ID.ReadOnly = False
                    Me.Txt_PatientID.ReadOnly = True
                    Me.Txt_PatientID.BackColor = Color.Silver
                    Me.Txt_OP_ID.ReadOnly = False
                    Me.Txt_OP_ID.BackColor = Color.White
                    Me.Txt_PatientID.BackColor = Color.White
                    Me.Dtp_TranDate.Enabled = False


                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_IP_ID.BackColor = Color.Silver
                    Me.Txt_IP_ID.ReadOnly = True
                    Me.Txt_PatientID.ReadOnly = True
                    Me.Txt_PatientID.BackColor = Color.Silver
                    Me.Txt_OP_ID.ReadOnly = True
                    Me.Txt_OP_ID.BackColor = Color.Silver
                    Me.Dtp_TranDate.Enabled = True
                    Me.Btn_Delete.Enabled = True

            End Select
        End Set
    End Property

#End Region

    Private Sub Inpatient_Master_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then SendKeyTab()
    End Sub

    Private Sub Inpatient_Master_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub Inpatient_Master_Frm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try

            Dtp_TranDate.Enabled = False
            Timer1_Tick(sender, e)

            InPatient_BL = New InPatientMaster_BL_Cls
            hms_helper = New Hms_Helperimpliments
            'Gen data filling
            Call hms_helper.Fill_GenData(Cmb_ArrivalMode, Gendatatype.Arrival_Mode)
            Call hms_helper.Fill_GenData(Cmb_Dept, Gendatatype.Department)
            Call hms_helper.Fill_GenData(Cmb_AdmitType, Gendatatype.Admit_Type)
            Call hms_helper.Fill_GenData(Cmb_Status, Gendatatype.Patient_Status)

            'Doctor 
            hms_helper.Fill_Doctors(Cmb_Doctor)
            hms_helper.Fill_Doctors(Cmb_DR_InCharge)
            'servises
            hms_helper.Fill_Service(Cmb_Service)
            'Fill Diagnose
            hms_helper.Fill_Diagnosis(Cmb_Diagnose)
            Btn_Delete.Enabled = False

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#Region "Methods"
    Private Function Validate_Fields() As Boolean
        Try
            If Tr_Mode <> Tran_Mode.New_Mode Then
                If Txt_IP_ID.Text.Trim = "" Then MessageBox.Show("Invalid IP ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_IP_ID.Focus() : Exit Function
                If Txt_OP_ID.Text.Trim = "" Then MessageBox.Show("Invalid OP ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_OP_ID.Focus() : Exit Function
            End If
            'Assigning Default values
            If Txt_OP_ID.Text.Trim = "" Then MessageBox.Show("Invalid OP ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_OP_ID.Focus() : Exit Function
            If IsDate(Dtp_TranDate.Value) = False Then MessageBox.Show("Invalid Date,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Dtp_TranDate.Focus() : Exit Function
            If Txt_PatientID.Text.Trim = "" Then MessageBox.Show("Invalid Patient ID, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_PatientID.Focus() : Exit Function
            If Txt_AdmitReason.Text.Trim = "" Then MessageBox.Show("Invalid Admit Reason, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_AdmitReason.Focus() : Exit Function
            If Txt_AmbulatoryStatus.Text.Trim = "" Then MessageBox.Show("Invalid Ambulatory Status, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_AmbulatoryStatus.Focus() : Exit Function
            If Val(Txt_StayDays.Text) <= 0 Then MessageBox.Show("Invalid Stay Days,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_StayDays.Focus() : Exit Function

            Return True
        Catch ex As Exception
            Return False
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function
#End Region

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try
            Dim Dr As DataTableReader = Nothing
            Dim Dtbl As DataTable = Nothing

            InPatient_BL = New InPatientMaster_BL_Cls
            If Not Validate_Fields() Then Exit Sub

            With InPatient_BL
                .IPD_ID = IIf(Tr_Mode <> Tran_Mode.New_Mode, Txt_IP_ID.Text.Trim, 0)
                .Tr_Date = Dtp_TranDate.Value
                .OPD_ID = Txt_OP_ID.Text.Trim
                .Patient_ID = Txt_PatientID.Text.Trim
                .Service_ID = Cmb_Service.SelectedValue
                .Dep_ID = Cmb_Dept.SelectedValue
                .Admit_Doc_ID = Cmb_Doctor.SelectedValue
                .Admit_Reason = Txt_AdmitReason.Text.Trim
                .Admit_Type = Cmb_AdmitType.SelectedValue
                .Admittime_DigID = Cmb_Diagnose.SelectedValue
                .Arrival_Mode = Cmb_ArrivalMode.SelectedValue
                .Ambulatory_Status = Txt_AmbulatoryStatus.Text.Trim
                .Doctor_Incharge = Cmb_DR_InCharge.SelectedValue
                .Exp_ServiceTakenday = DTP_ServiceDay.Value
                .Exp_Staydays = Txt_StayDays.Text.Trim
                .ACC_ID = Txt_AccID.Text.Trim
                .Curr_Status = Cmb_Status.SelectedValue

                Dtbl = Nothing
                If InPatient_BL.Save_InPatient_Details(Dtbl, Tr_Mode, IIf(Tr_Mode <> Tran_Mode.New_Mode, Txt_IP_ID.Text.Trim, 0)) Then
                    MessageBox.Show("In-Patient Details Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Call Clear_Form()
                    'Call Assigntocontrols(Dtbl)
                    'Tr_Mode = Tran_Mode.Edit_Mode
                    Btn_Delete.Enabled = False
                    Txt_OP_ID.Focus()
                Else
                    MessageBox.Show("In-Patient Details Not Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Clear_Form()
        Try

            Txt_IP_ID.Text = ""
            Txt_OP_ID.Text = ""
            Txt_AccID.Text = ""
            Txt_AdmitReason.Text = ""
            Txt_AmbulatoryStatus.Text = ""

            Txt_PatientID.Text = ""
            Txt_StayDays.Text = ""
            Cmb_AdmitType.SelectedIndex = 0
            Cmb_ArrivalMode.SelectedIndex = 0
            Cmb_Dept.SelectedIndex = 0
            Cmb_Diagnose.SelectedIndex = 0
            Cmb_Doctor.SelectedIndex = 0
            Cmb_DR_InCharge.SelectedIndex = 0
            Cmb_Service.SelectedIndex = 0
            Cmb_Status.SelectedIndex = 0



            Txt_IP_ID.Tag = ""
            Txt_OP_ID.Tag = ""
            Txt_PatientID.Tag = ""

            Tr_Mode = Tran_Mode.New_Mode
            Btn_Delete.Enabled = False
            Txt_IP_ID.Focus()

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Function Assigntocontrols(ByVal D_Table As DataTable) As Boolean
        Try

            Dr = D_Table.CreateDataReader()
            Dr.Read()

            With Dr
                Txt_IP_ID.Text = .Item("IPD_ID").ToString
                Txt_IP_ID.Tag = .Item("IPD_ID").ToString
                Txt_OP_ID.Text = .Item("OPD_ID").ToString
                Dtp_TranDate.Text = .Item("Tr_Date").ToString
                Txt_PatientID.Text = .Item("Patient_ID").ToString
                Txt_PatientID.Tag = .Item("Patient_ID").ToString
                Cmb_Service.SelectedValue = .Item("Service_ID").ToString
                Cmb_ArrivalMode.SelectedValue = .Item("Arrival_Mode").ToString
                Cmb_Dept.SelectedValue = .Item("Dep_ID").ToString
                Cmb_AdmitType.SelectedValue = .Item("Admit_Type").ToString
                Cmb_Doctor.SelectedValue = .Item("Admit_Doc_ID").ToString
                Cmb_Diagnose.SelectedValue = .Item("Admittime_DigID").ToString
                Txt_AdmitReason.Text = .Item("Admit_Reason").ToString
                Cmb_ArrivalMode.SelectedValue = .Item("Arrival_Mode").ToString
                Txt_AmbulatoryStatus.Text = .Item("Ambulatory_Status").ToString
                Cmb_DR_InCharge.SelectedValue = .Item("Doctor_Incharge").ToString
                DTP_ServiceDay.Text = .Item("Exp_ServiceTakenday").ToString
                Txt_StayDays.Text = .Item("Exp_Staydays").ToString
                Cmb_Status.SelectedValue = .Item("Curr_Status").ToString
                Txt_AccID.Text = .Item("ACC_ID").ToString
            End With
            Return True
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        Finally
            D_Table = Nothing
        End Try
    End Function

    Private Sub Txt_OP_ID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_OP_ID.KeyDown
        If e.KeyCode = Keys.F2 Then Btn_Find1_Click(sender, e)
    End Sub

    Private Sub Txt_OP_ID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_OP_ID.Validating
        Try

            If Me.Txt_OP_ID.Text.Trim <> "" And Me.Txt_OP_ID.Text.Trim <> CStr(Me.Txt_OP_ID.Tag) Then
                If FillOp_Detail(Txt_OP_ID.Text.Trim) Then

                    If Txt_PatientID.Text.Trim <> "" And Me.Txt_PatientID.Text.Trim <> Me.Txt_PatientID.Tag Then
                        'If Locate_Patient(Txt_PatientID.Text.Trim) Then
                        '    If Dtp_TranDate.Enabled = False Then
                        '        Cmb_Service.Focus()
                        '        Exit Sub
                        '    Else
                        '        Dtp_TranDate.Focus()
                        '        Exit Sub
                        '    End If
                        'Else
                        '    MessageBox.Show("Patient Id not exists", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                        '    Txt_PatientID.Text = ""
                        '    e.Cancel = True
                        '    Exit Sub
                        'End If
                    End If

                    e.Cancel = False
                Else
                    MessageBox.Show("Invalid OP ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Txt_OP_ID.Focus()
                    Txt_OP_ID.Text = ""
                    e.Cancel = True
                End If
            Else
                Btn_Find1.Focus()
                Exit Sub
            End If

            
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)

        End Try
    End Sub

    Public Function Locate_Patient(ByVal Patient_ID As Integer) As Boolean
        Try
            Dim dtbl As DataTable = Nothing
            Dim dr As DataTableReader = Nothing

            hms_helper = New Hms_Helperimpliments
            Txt_PatientID.Tag = ""
            If hms_helper.Get_Patient_Info(dtbl, Patient_ID) Then
                dr = dtbl.CreateDataReader
                dr.Read()
                With dr
                    Dim StrAdd As String
                    Dim strValues As String
                    strValues = ""

                    StrAdd = ""
                    StrAdd = StrAdd + " Name" + vbCrLf
                    StrAdd = StrAdd + " Address" + vbCrLf
                    StrAdd = StrAdd + " City" + vbCrLf
                    StrAdd = StrAdd + " State" + vbCrLf
                    StrAdd = StrAdd + " Country" + vbCrLf
                    StrAdd = StrAdd + " Phone" + vbCrLf
                    StrAdd = StrAdd + " Mobile" + vbCrLf
                    'StrAdd = StrAdd + " Email" + vbCrLf
                    'StrAdd = StrAdd + " Status" + vbCrLf


                    strValues = strValues + ":  " + dr.Item("Patient_Name").ToString + vbCrLf
                    strValues = strValues + ":  " + dr.Item("Patient_Addr").ToString + vbCrLf
                    strValues = strValues + ":  " + dr.Item("Patient_City").ToString + vbCrLf
                    strValues = strValues + ":  " + dr.Item("State").ToString + vbCrLf
                    strValues = strValues + ":  " + dr.Item("Country").ToString + vbCrLf
                    strValues = strValues + ":  " + dr.Item("Phone").ToString + vbCrLf
                    strValues = strValues + ":  " + dr.Item("Mobile").ToString + vbCrLf
                    'strValues = strValues + ":  " + dr.Item("Email").ToString + vbCrLf
                    'strValues = strValues + ":  " + dr.Item("Patient Status").ToString + vbCrLf

                    Txt_PatientID.Tag = Patient_ID


                End With

                'Locating Images if available
                'Call ShowImageviewer(Me, Patient_ID, Customer_Type.Employee)
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            Return False
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function

    Private Sub Btn_Find1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find1.Click
        Try

            If Txt_OP_ID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "150|125|100|50|50|150"

                'Sql = "SELECT   [Patient Name],Doctor,Service,[Status],[Patient Type],[Tran Date],OPD_ID  FROM OPD_Master_Vw where OPD_ID NOT IN(Select OPD_ID from IPD_Master_Tbl)"
                Sql = "SELECT   [Patient Name],OPD_ID,Doctor,Service,[Status],[Patient Type],[Tran Date]  FROM OPD_Master_Vw where [Tran Date] ='" & Format(Tran_Date, "MM/dd/yyyy") & "' and OPD_ID NOT IN(Select OPD_ID from IPD_Master_Tbl)"
                Call ShowSearchengine(Txt_OP_ID, Sql, 1, "Patient Name", Colwidth, , 0)
            End If

            If Txt_OP_ID.Text.Trim = "" Then
                Txt_OP_ID.Focus() : Exit Sub
            End If

            'Locate patient details 
            If FillOp_Detail(Txt_OP_ID.Text.Trim) Then

                'If Locate_Patient(Txt_PatientID.Text.Trim) Then
                '    If Tr_Mode = Tran_Mode.New_Mode Then
                '        Cmb_Service.Focus()
                '    Else
                '        Dtp_TranDate.Focus()
                '    End If
                '    'Dtp_TranDate.Focus()

                '    Exit Sub
                'End If

                If Tr_Mode = Tran_Mode.New_Mode Then
                    Cmb_Doctor.Focus()
                Else
                    Dtp_TranDate.Focus()
                End If
                'Dtp_TranDate.Focus()
                Exit Sub

            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Public Function FillOp_Detail(ByVal OpId As String) As Boolean
        Try
            Dim dtbl As DataTable = Nothing
            Dim dr As DataTableReader = Nothing

            hms_helper = New Hms_Helperimpliments
            Txt_PatientID.Tag = ""
            If hms_helper.Get_OP_Details(dtbl, OpId) Then
                dr = dtbl.CreateDataReader
                dr.Read()
                With dr
                    Txt_PatientID.Text = dr.Item("Patient ID").ToString
                    Txt_AccID.Text = dr.Item("ACC_ID")
                End With

                'Locating Images if available
                'Call ShowImageviewer(Me, Patient_ID, Customer_Type.Employee)
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            Return False
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Function

    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try
            If Tr_Mode = Tran_Mode.New_Mode Then
                If Txt_IP_ID.Text.Trim = "" Then
                    Dim Sql As String
                    Dim Colwidth As String = ""
                    Colwidth = "150|150|65|150|50|60|60"
                    Sql = "SELECT  [Patient Name],IPD_ID,[Admit Doctor],Department,[Doctor In Charge],[Current Status],Tr_Date,OPD_ID  FROM    IPD_Master_Vw"

                    Call ShowSearchengine(Txt_IP_ID, Sql, 1, "Patient Name", Colwidth, , 0)
                End If

                If Txt_IP_ID.Text.Trim = "" Then
                    Txt_IP_ID.Focus() : Exit Sub
                End If

                'Locate IN Patient details
                If Locate_Values(Txt_IP_ID.Text.Trim) Then
                    Tr_Mode = Tran_Mode.Edit_Mode
                    Btn_Delete.Enabled = True
                    If FillOp_Detail(Txt_OP_ID.Text.Trim) Then
                        'If Locate_Patient(Txt_PatientID.Text.Trim) Then
                        '    Txt_IP_ID.Focus()
                        '    Exit Sub
                        'End If
                    End If
                Else
                    MessageBox.Show("IP ID Does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            Else
                Txt_IP_ID.Focus()
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Function Locate_Values(ByVal IPD_ID As String) As Boolean
        Try
            Dim dtbl As DataTable = Nothing
            Dim dr As DataTableReader = Nothing

            InPatient_BL = New InPatientMaster_BL_Cls
            dtbl = Nothing
            Call Clear_Form()

            Txt_IP_ID.Text = IPD_ID

            'Retreiving Inpatient Assign the values to respective controls
            If InPatient_BL.Get_InPatient_Details(dtbl, IPD_ID) Then
                Return Assigntocontrols(dtbl)
                'Locate patient details                 
                Call ShowImageviewer(Me, Txt_PatientID.Text, Customer_Type.Patient)
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            Return False
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function
    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Call Clear_Form()
    End Sub
    Private Sub Cmb_Dept_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cmb_Dept.GotFocus
        Btn_New.Visible = True
        Me.Btn_New.Location = Get_Newgendatabuttonposition(Cmb_Dept)
        Me.Btn_New.Tag = "Cmb_Dept|" & Gendatatype.Department
    End Sub
    Private Sub Cmb_ArrivalMode_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cmb_ArrivalMode.GotFocus
        Btn_New.Visible = True

        Me.Btn_New.Location = Get_Newgendatabuttonposition(Cmb_ArrivalMode)
        Me.Btn_New.Tag = "Cmb_ArrivalMode|" & Gendatatype.Arrival_Mode
    End Sub
    Private Sub Cmb_AdmitType_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cmb_AdmitType.GotFocus
        Btn_New.Visible = True
        Me.Btn_New.Location = Get_Newgendatabuttonposition(Cmb_AdmitType)
        Me.Btn_New.Tag = "Cmb_AdmitType|" & Gendatatype.Admit_Type
    End Sub
    Private Sub Cmb_Status_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cmb_Status.GotFocus
        Btn_New.Visible = True
        Me.Btn_New.Location = Get_Newgendatabuttonposition(Cmb_Status)
        Me.Btn_New.Tag = "Cmb_Status|" & Gendatatype.Patient_Status
    End Sub
    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
    End Sub
    Private Sub Btn_NewOP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_NewOP.Click
        Try
            With OP_Register_Frm
                .MdiParent = Me.MdiParent
                '.Req_Ctrl = Txt_OP_ID
                .Show()
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If Tr_Mode = Tran_Mode.New_Mode Then
            Dtp_TranDate.Text = (Format(Now, "dd/MM/yyyy hh:mm:ss tt"))
        End If
    End Sub
    Private Sub Txt_PatientID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_PatientID.TextChanged
        Try
            With Patient_Info1
                .Viewmoreform_Name = "Patient_InfoSheet_Frm"
                .MDIform_Name = Me.MdiParent
                .Patient_ID = Txt_PatientID.Text.Trim
            End With
        Catch ex As Exception

        End Try
    End Sub
    Private Sub Txt_AdmitReason_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Txt_AdmitReason.GotFocus
        Txt_AdmitReason.SelectionStart = Len(Txt_AdmitReason.Text.Trim)
    End Sub
    Private Sub Txt_AmbulatoryStatus_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Txt_AmbulatoryStatus.GotFocus
        Txt_AmbulatoryStatus.SelectionStart = Len(Txt_AmbulatoryStatus.Text.Trim)
    End Sub
    Private Sub Txt_IP_ID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_IP_ID.KeyDown
        If e.KeyCode = Keys.F2 Then Btn_Find_Click(sender, e)
    End Sub
    Private Sub Txt_IP_ID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_IP_ID.Validating
        Try
            If Txt_IP_ID.Text.Trim <> "" And Me.Txt_IP_ID.Text.Trim <> Me.Txt_IP_ID.Tag Then
                If Locate_Values(Txt_IP_ID.Text.Trim) Then
                    Tr_Mode = Tran_Mode.Edit_Mode
                    Btn_Delete.Enabled = True
                    Txt_OP_ID.Focus()
                Else
                    MessageBox.Show("IP ID does not exit", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Txt_IP_ID.Text = ""
                    e.Cancel = True
                End If
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click
        Try
            'Validating Mandatory fields for Deleting
            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If

            If Txt_IP_ID.Text.Trim = "" Then
                MessageBox.Show("Invalid IP ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_IP_ID.Focus() : Exit Sub
            End If
            InPatient_BL = New InPatientMaster_BL_Cls
            If MessageBox.Show("Are you sure wan't to delete the selected InPatient  Details", Product_Name, MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                If InPatient_BL.Del_Inpatient_Detail(Txt_IP_ID.Text.Trim) Then
                    MessageBox.Show("Deleted Inpatient Details successfully", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Call Clear_Form()
                Else
                    MessageBox.Show("You cannot delete this InPatient details" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub
    'Private Sub Btn_New_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_New.Click
    '    Try
    '        Dim newpoint As Point = Nothing
    '        Dim cname As String = ""
    '        Dim Fill_ID As String = ""
    '        Dim i_Start As Int16 = InStr(Me.Btn_New.Tag, "|", CompareMethod.Text)
    '        cname = Mid(Me.Btn_New.Tag, 1, i_Start - 1)
    '        Fill_ID = Mid(Me.Btn_New.Tag, i_Start + 1, Len(Me.Btn_New.Tag))

    '        Dim ctr As Object
    '        ctr = DirectCast(Me.Controls(cname), ComboBox)

    '        With Generaldatasave_Frm
    '            newpoint = Get_GendatasaveformPosition(Me, ctr)
    '            .Point_Frm = newpoint
    '            .Data_CatID = Fill_ID
    '            .Req_Ctrl = ctr
    '            .ShowDialog()
    '        End With
    '    Catch ex As Exception
    '        MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
    '    End Try
    'End Sub
    Private Sub Txt_StayDays_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_StayDays.KeyPress
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_StayDays.Text, Data_Type.Integer_Type, 12))
    End Sub
   
    Private Sub Btn_Close_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

#Region "A D D  New GenData"

    Private Sub Set_NewGendatabutton(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cmb_Dept.GotFocus, Cmb_AdmitType.GotFocus, Cmb_ArrivalMode.GotFocus, Cmb_Status.GotFocus, Cmb_Status.GotFocus
        Try
            Dim AddReqCtrl As Control = CType(sender, Control)

            Btn_New.Visible = True
            Me.Btn_New.Location = Get_Newgendatabuttonposition(AddReqCtrl)
            Me.Btn_New.Tag = AddReqCtrl.Name & "|" & Val(AddReqCtrl.Tag)

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_New_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_New.Click
        Try

            Call AddNewGendata(Btn_New)

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Call_Btnnew(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Cmb_Dept.KeyDown, Cmb_AdmitType.KeyDown, Cmb_ArrivalMode.KeyDown, Cmb_Status.KeyDown
        Try
            If e.KeyCode = Keys.Add Then Call Btn_New_Click(Nothing, Nothing)
        Catch ex As Exception

        End Try
    End Sub

#End Region
End Class
