﻿'Developed by   : PRAMODBHASKER
'Date           : 21-09-2010
'Purpose        : Transaction Grid User Control

Public Class Trangrid


    Private mPaymode_Datasource As DataTable
    Public WriteOnly Property Paymode_Datasource() As DataTable
        Set(ByVal value As DataTable)
            mPaymode_Datasource = value
        End Set
    End Property

    Public WriteOnly Property Datastructure() As DataTable
        Set(ByVal value As DataTable)
            With Tr_GridView
                .Rows.Clear()

                For i = 0 To value.Rows.Count - 1
                    .Rows.Add(1)
                    .Rows(i).Cells("Particulars").Value = value.Rows(i).Item("Particulars").ToString
                    .Rows(i).Cells("GL_Code").Value = value.Rows(i).Item("GL_Code").ToString
                    .Rows(i).Cells("Def_Trantype").Value = value.Rows(i).Item("Def_Trantype").ToString
                Next
            End With
        End Set
    End Property


End Class
