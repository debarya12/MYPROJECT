﻿

Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls

Public Class General_Voucher_Frm

#Region " D e c l a r a t i o n s "

    Private hms_helper As HMS_Helper = Nothing
    Private Gen_Tran_BL As Gen_Transaction_BL_Cls
    Private Acc_Dtbl As DataTable = Nothing
    Private IsHandleAdded As Boolean


#End Region

#Region " P r o p e r t i e s "

    'Transaction Mode checking Property
    Private mTr_Mode As Tran_Mode
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_BatchID.BackColor = Color.White
                    Me.Txt_BatchID.ReadOnly = False
                    Me.Dtp_Trandate.Enabled = True
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_BatchID.BackColor = Color.Silver
                    Me.Txt_BatchID.ReadOnly = True
                    Me.Dtp_Trandate.Enabled = False
            End Select
        End Set
    End Property


#End Region

#Region " M e t h o d s "

    Private Sub Populate_Combobox()
        Try

            If Not hms_helper.Get_AccountDetails(Acc_Dtbl) Then Return

            With Dgvw_Tran
                Dim Acc_HeadColumn As DataGridViewComboBoxColumn = .Columns("Account_Head")
                Acc_HeadColumn.DataSource = Acc_Dtbl
                Acc_HeadColumn.DisplayMember = "Account Name"
                Acc_HeadColumn.ValueMember = "Account Code"

                .Rows.Add(10)

            End With

            'Populate Transaction type
            Fill_Transaction_Type(Cmb_TranType, "< Select >")
            If Cmb_TranType.Items.Count > 0 Then Cmb_TranType.SelectedIndex = 0
            'Populate Mode of Payment
            hms_helper.Fill_GenData(Cmb_PaymentMode, Gendatatype.Payment_Mode, "< Select >")
            If Cmb_PaymentMode.Items.Count > 0 Then Cmb_PaymentMode.SelectedIndex = 0


        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End Try
    End Sub

    Private Sub Totaling_Amount()
        Try
            Lbl_TotalAmount.Text = ""
            Dim Totalamt As Double = 0

            With Dgvw_Tran
                For i = 0 To .Rows.Count - 1
                    Totalamt += .Rows(i).Cells("Amount").Value
                Next
            End With
            Lbl_TotalAmount.Text = Totalamt.ToString("0.00")

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Function Validate_Fields() As Boolean
        Try
            Dim i_Ctr As Int32 = 0

            If Me.Tr_Mode = Tran_Mode.Edit_Mode Then
                If Txt_BatchID.Text.Trim = String.Empty Then
                    MessageBox.Show("Invalid Transaction Batch-ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Txt_BatchID.Focus() : Return False
                End If
            End If

            If Cmb_PaymentMode.SelectedIndex = 0 Then MessageBox.Show("Please Select Payment mode and Proceed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Cmb_PaymentMode.Focus() : Return False
            If Cmb_TranType.SelectedIndex = 0 Then MessageBox.Show("Please Select Transaction Type and Proceed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Cmb_TranType.Focus() : Return False

            If Val(Lbl_TotalAmount.Text) <= 0 Then
                MessageBox.Show("Invalid Transaction Amount,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Dgvw_Tran.Focus() : Return False
            End If

            'if Common Narration is empty then individual remarks is neccessary
            If Txt_Narration.Text.Trim = String.Empty Then
                With Dgvw_Tran
                    For i_Ctr = 0 To .Rows.Count - 1
                        If .Rows(i_Ctr).Cells("Account_Head").Value <> String.Empty Then
                            If .Rows(i_Ctr).Cells("Remarks").Value = String.Empty Then
                                MessageBox.Show("Please Enter Transaction Remarks", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                                .CurrentCell = .Rows(i_Ctr).Cells("Remarks")
                                .Focus() : Return False
                            End If
                            If Val(.Rows(i_Ctr).Cells("Amount").Value) <= 0 Then
                                MessageBox.Show("Invalid Transaction Amount", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                                .CurrentCell = .Rows(i_Ctr).Cells("Amount")
                                .Focus() : Return False
                            End If
                        End If
                    Next
                End With
            End If

           
            Return True

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function

    Private Function Locate_Values(ByVal Tran_BatchID As String, ByVal Tr_Date As Date) As Boolean
        Try
            'Clear Field Values
            Call Clear_Form()

            Gen_Tran_BL = New Gen_Transaction_BL_Cls

            Dim Dtbl As DataTable = Nothing
            Dim i_Ctr As Int32 = 0
            Dim row_Cnt As Int32 = 0

            'Locating Transaction Batch
            If Not Gen_Tran_BL.Get_Gen_Transaction(Dtbl, Tran_BatchID, Tr_Date, Branch_Code) Then
                MessageBox.Show("Invalid Transaction Batch-ID", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Return False
            End If

            'Assigning General Information
            With Dtbl
                Txt_BatchID.Text = .Rows(0).Item("Tran_BatchID").ToString
                Txt_BatchID.Tag = Txt_BatchID.Text
                Txt_Narration.Text = .Rows(0).Item("Tr_Narration").ToString
                Dtp_Trandate.Value = .Rows(0).Item("Tr_date").ToString
                Cmb_PaymentMode.SelectedValue = .Rows(0).Item("Tr_Pay_Mode").ToString
                Cmb_TranType.SelectedValue = .Rows(0).Item("Tr_Type").ToString
            End With

            'Assigning Values to Grid
            With Dgvw_Tran
                Dim Acc_HeadColumn As DataGridViewComboBoxColumn = .Columns("Account_Head")
                Dim Acc_HeadCell As DataGridViewComboBoxCell = .Rows(0).Cells("Account_Head")

                For i_Ctr = 0 To Dtbl.Rows.Count - 1
                    Acc_HeadCell = .Rows(row_Cnt).Cells("Account_Head")
                    If Dtbl.Rows(i_Ctr).Item("Account Head").ToString <> "" Then
                        Acc_HeadCell.Value = Dtbl.Rows(i_Ctr).Item("Acc_Code").ToString
                        .Rows(row_Cnt).Cells("Amount").Value = Dtbl.Rows(i_Ctr).Item("Tr_Amount").ToString
                        .Rows(row_Cnt).Cells("Remarks").Value = Dtbl.Rows(i_Ctr).Item("Tr_Remarks").ToString
                        .Rows(row_Cnt).Cells("Tran_ID").Value = Dtbl.Rows(i_Ctr).Item("Tran_ID").ToString
                        row_Cnt += 1
                    End If
                Next

                'Calculating Total
                Call Totaling_Amount()

            End With

            Me.Tr_Mode = Tran_Mode.Edit_Mode

            Me.Btn_Save.Enabled = True
            Me.Btn_Print.Enabled = True
            Me.Btn_CancelBatch.Enabled = True

            Return True


        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function

    Private Sub Clear_Form()
        Try

            With Dgvw_Tran
                .Rows.Clear()
                .Rows.Add(10)
            End With

            With Me
                .Txt_BatchID.Text = String.Empty
                .Txt_BatchID.Tag = String.Empty
                .Txt_Narration.Text = String.Empty
                .Lbl_TotalAmount.Text = String.Empty

                .Btn_Save.Enabled = False
                .Btn_Print.Enabled = False
                .Btn_CancelBatch.Enabled = False
                .Btn_Showtranlist.Visible = True
                .Tr_Mode = Tran_Mode.New_Mode

            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Function Get_TranbatchID(ByVal Tr_Date As Date, ByVal Isincriment As Boolean, ByVal Br_Code As Integer) As String
        Try

            Dim Tran_BL As New TranMaster_BL_Cls

            Return Tran_BL.Get_TranBatchID(Tran_Date, True, Branch_Code)

        Catch ex As Exception
            Return ""
        End Try

    End Function

    Private Function Save_Transaction() As Boolean
        Try

            Dim Acc_HeadColumn As DataGridViewComboBoxCell
            Dim Dtbl As DataTable = Nothing

            If Tr_Mode = Tran_Mode.New_Mode Then
                Txt_BatchID.Text = Get_TranbatchID(Tran_Date, True, Branch_Code)
            End If
            Gen_Tran_BL = New Gen_Transaction_BL_Cls


            With Gen_Tran_BL

                .Tran_BatchID = Txt_BatchID.Text.Trim
                .Tr_Date = Dtp_Trandate.Value
                .Tr_Narration = Txt_Narration.Text.Trim
                .Tr_Pay_Mode = Cmb_PaymentMode.SelectedValue
                .Tr_Type = Cmb_TranType.SelectedValue
                .Tr_RefNo = "Gen"
            End With

            'Saving Transaction by Row by Row
            With Dgvw_Tran
                Dim i_Ctr As Int32 = 0
                For i_Ctr = 0 To .Rows.Count - 1

                    If Val(.Rows(i_Ctr).Cells("Amount").Value) > 0 Then

                        If Tr_Mode = Tran_Mode.Edit_Mode Then
                            If (.Rows(i_Ctr).Cells("Tran_ID").Value Is Nothing) Then
                                Gen_Tran_BL.Tran_ID = 0
                            Else
                                Gen_Tran_BL.Tran_ID = .Rows(i_Ctr).Cells("Tran_ID").Value.ToString.Trim
                            End If
                        End If

                        Acc_HeadColumn = .Rows(i_Ctr).Cells("Account_Head")

                        Gen_Tran_BL.Acc_Code = Acc_HeadColumn.Value.ToString
                        Gen_Tran_BL.Tr_Remarks = .Rows(i_Ctr).Cells("Remarks").Value.ToString
                        Gen_Tran_BL.Tr_Amount = .Rows(i_Ctr).Cells("Amount").Value.ToString

                        If Gen_Tran_BL.Save_Gen_Transaction(Dtbl, Tr_Mode, Txt_BatchID.Text) Then
                            If Dtbl.Rows(0).Item(0).ToString = "0" Then
                                GoTo Error_Point
                            End If
                        Else
                            GoTo Error_Point
                        End If

                    End If

                Next

            End With

Exit_Point:

            Return True
Error_Point:

            If Not Gen_Tran_BL.Del_Gen_Transaction(Txt_BatchID.Text.Trim, Dtp_Trandate.Value) Then
                MessageBox.Show("Error Occured While Reverting Saved Transaction,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If


        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function

    Private Function Populate_Transaction(ByVal Tr_Date As Date) As Boolean
        Try
            Dim Dtbl As DataTable = Nothing
            Gen_Tran_BL = New Gen_Transaction_BL_Cls

            BindingSource1.DataSource = Dtbl

            Nav_Tranlist.BindingSource = BindingSource1
            
            'Locating Transaction Batch
            If Not Gen_Tran_BL.Get_GenTranList(Dtbl, Tr_Date, Branch_Code) Then Return False


            BindingSource1.DataSource = Dtbl

            Nav_Tranlist.BindingSource = BindingSource1

        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function Show_Reciept() As Boolean
        Try

            If Txt_BatchID.Text.Trim = "" Then
                MessageBox.Show("Invalid  Batch ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Txt_BatchID.Focus()
                Return False
            End If


            If Val(Lbl_TotalAmount.Text) <= 0 Then Return False


            Dim mRpt_Vwr As ReportViewer_Cls
            Dim Rpt_BL As HMS_BL.Reports_BL_Cls

            Dim Rpt_Ds As DataSet = Nothing
            Dim Rpt_Formulafields As String = "Company| " & Company_Name & "|Branch|" & Branch_Name
            Dim Rpt_Filename As String = ""
            Dim mReport_ID As String = ""
            Dim Report_Heading As String = ""
            Dim Add_Query As String = ""

            mRpt_Vwr = New ReportViewer_Cls

            Add_Query = ""
            Add_Query = "Where [Batch No] = " & Txt_BatchID.Text & " "
            Rpt_Filename = File_Path & "\Gen_Tran_Reciept.rpt"
            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Get_GenTran_Reciept(Rpt_Ds, Add_Query) Then

                REM for Geting total amount 
                Dim dtbl As DataTable = Rpt_Ds.Tables(0)
                Dim dr As DataTableReader
                Dim Amt As Double
                Amt = 0
                dr = dtbl.CreateDataReader

                While dr.Read
                    Amt = Amt + Val(dr.Item("Tr_Amount").ToString)
                End While
                REM .....

                Report_Heading = "|Heading| Receipt|Footer3|Authorised Signatory"
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading & "|words|" & Towords(Amt)
                With mRpt_Vwr
                    .Show_Mode = Report_Showmode.Condensedmode
                    .RptFrm_Height = 600
                    .RptFrm_Width = 800
                    .MDI_Form = Me
                End With


                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            Else
                MessageBox.Show("Invalid Batch ID .. Please enter valid Batch ID", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function

#End Region

    Private Sub General_Voucher_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Try

            If e.KeyCode = Keys.Enter Then
                Call SendKeyTab()
            End If

            With Dgvw_Tran
                If e.KeyCode = Keys.F3 Then Dgvw_Tran.Rows.Add(1)
                If e.KeyCode = Keys.F12 Then
                    .Rows.Remove(.CurrentRow)

                End If

            End With


        Catch ex As Exception

        End Try
    End Sub

    Private Sub General_Voucher_Frm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            hms_helper = New Hms_Helperimpliments

            Call Populate_Combobox()

            Dtp_Trandate.Value = Tran_Date
            Dtp_Trandate.MaxDate = Tran_Date

            Call Clear_Form()


        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgvw_Tran_CellBeginEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellCancelEventArgs) Handles Dgvw_Tran.CellBeginEdit
        Try
            With Dgvw_Tran
                If .Columns(.CurrentCell.ColumnIndex).Name <> "Account_Head" Then
                    If .Rows(e.RowIndex).Cells("Account_Head").FormattedValue.ToString = String.Empty Then
                        .EndEdit(True)
                        e.Cancel = True
                    End If
                End If
            End With

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgvw_Tran_CellValueChanged(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgvw_Tran.CellValueChanged
        Try
            If Dgvw_Tran.Columns(Dgvw_Tran.CurrentCell.ColumnIndex).Name = "Amount" Then
                Call Totaling_Amount()
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgvw_Tran_RowsAdded(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowsAddedEventArgs) Handles Dgvw_Tran.RowsAdded
        Try
            With Dgvw_Tran
                .CurrentCell = Dgvw_Tran(1, e.RowIndex)
                Dim i_Ctr As Int32 = 0
                For i_Ctr = 0 To .Rows.Count - 1
                    .Rows(i_Ctr).Cells("SL_No").Value = (i_Ctr + 1).ToString
                Next

            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgvw_Tran_RowsRemoved(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowsRemovedEventArgs) Handles Dgvw_Tran.RowsRemoved
        Try
            With Dgvw_Tran
                Dim i_Ctr As Int32 = 0
                For i_Ctr = 0 To .Rows.Count - 1
                    .Rows(i_Ctr).Cells("SL_No").Value = (i_Ctr + 1).ToString
                Next
            End With
            Call Totaling_Amount()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgvw_Tran_EditingControlShowing(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewEditingControlShowingEventArgs) Handles Dgvw_Tran.EditingControlShowing
        Try
            If Dgvw_Tran.Columns(Dgvw_Tran.CurrentCell.ColumnIndex).Name = "Amount" Then

                Dim tx As TextBox = CType(e.Control, TextBox)

                If (Not (tx) Is Nothing) Then
                    AddHandler tx.KeyPress, AddressOf Me.tx_KeyPress
                    Me.IsHandleAdded = True
                End If

            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub tx_KeyPress(ByVal sender As Object, ByVal e As KeyPressEventArgs)
        Try
            With Dgvw_Tran
                If .Columns(.CurrentCell.ColumnIndex).Name = "Amount" Then
                    Dim Txt As TextBox = CType(sender, TextBox)
                    e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt.Text, Data_Type.Double_Type, 13))
                End If
            End With


        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgvw_Tran_CellValidating(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellValidatingEventArgs) Handles Dgvw_Tran.CellValidating
        Try
            With Dgvw_Tran
                If .Columns(.CurrentCell.ColumnIndex).Name = "Account_Head" Then

                    Dim Acc_HeadColumn As DataGridViewComboBoxCell = .Rows(e.RowIndex).Cells(e.ColumnIndex)

                    Dim Acc_Head As String = e.FormattedValue.ToString.ToUpper.Trim

                    If Acc_Head Is Nothing Then Return
                    For i_Ctr As Int32 = 0 To .Rows.Count - 1
                        If i_Ctr <> e.RowIndex And .Rows(i_Ctr).Cells("Account_Head").FormattedValue.ToString <> String.Empty Then
                            If .Rows(i_Ctr).Cells("Account_Head").FormattedValue.ToString.ToUpper.Trim = Acc_Head Then

                                MessageBox.Show("Selected Account Head is Already in the List", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)

                                e.Cancel = True

                                Return
                            End If
                        End If
                    Next
                End If
            End With

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Lbl_TotalAmount_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Lbl_TotalAmount.TextChanged
        Try
            Lbl_Words.Text = Towords(Val(Lbl_TotalAmount.Text))

            If Val(Lbl_TotalAmount.Text) > 0 Then
                Btn_Save.Enabled = True
            Else
                Btn_Save.Enabled = False
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Save_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try
            If Not Validate_Fields() Then Return

            If Save_Transaction() Then
                MessageBox.Show("Transaction Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Call Clear_Form()
                Txt_BatchID.Focus()
            Else
                MessageBox.Show("Error Occured While Saving Transaction,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try
            If Txt_BatchID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "10|10|10|100"
                Sql = "SELECT  [Batch No], [Account Head], [Transaction Type], [Payment  Mode], Tr_Amount, Narration"
                Sql += " FROM  Gen_Transactiongroup_Vw where  Date = '" & Format(Tran_Date, "MM/dd/yyyy") & "' and ([Ref No] ='Gen' or [Ref No] ='') and Cancelled = 'N' and Br_Code = " & Branch_Code & " "
                Call ShowSearchengine(Txt_BatchID, Sql, 0, "[Account Head]", Colwidth, , 0)
            End If

            If Txt_BatchID.Text.Trim = "" Then
                Txt_BatchID.Focus() : Exit Sub
            End If

            'Locate Transaction Batch details 
            If Locate_Values(Txt_BatchID.Text.Trim, Dtp_Trandate.Value) Then
                Txt_BatchID.Focus()
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try
            Call Clear_Form()
            Txt_BatchID.Focus()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Try
            Me.Close()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_BatchID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_BatchID.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then Call Btn_Find_Click(Nothing, Nothing)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_BatchID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_BatchID.Validating
        Try
            If Me.Txt_BatchID.Text.Trim <> "" And Me.Txt_BatchID.Text <> Me.Txt_BatchID.Tag Then
                If Not Locate_Values(Txt_BatchID.Text.Trim, Tran_Date) Then
                    Txt_BatchID.Focus()
                    e.Cancel = True
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub BindingSource1_PositionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles BindingSource1.PositionChanged
        Try
            If BindingSource1.Count <= 0 Or (BindingSource1.Position < 0) Then
                Exit Sub
            End If

            Txt_BatchID.Text = BindingSource1.Item(BindingSource1.Position)(0).ToString()

            If Txt_BatchID.Text.Trim <> String.Empty Then
                Call Btn_Find_Click(Nothing, Nothing)
            End If

        Catch ex As Exception

        End Try


    End Sub

    Private Sub Btn_Print_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Print.Click
        Try
            Call Show_Reciept()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_CancelBatch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_CancelBatch.Click
        Try

            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If


            If MessageBox.Show("Are you sure wan't to Cancel this transaction", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.No Then Exit Sub

            Dim dtbl As DataTable = Nothing

            Gen_Tran_BL = New Gen_Transaction_BL_Cls


            If Gen_Tran_BL.Cancell_General_Transaction(dtbl, Txt_BatchID.Text.Trim, Txt_Narration.Text, Tran_Date, Tran_Date, Branch_Code) Then
                MessageBox.Show("Transaction Cancelled Successfully", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Call Clear_Form()
                Txt_BatchID.Focus()
            Else
                MessageBox.Show("Transaction Cancellation failed,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If



        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Utility_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Utility.Click
        Try
            Show_ChildForm("Gen_Transaction_Uttility", Me.MdiParent, Me.Tag)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Showtranlist_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Showtranlist.Click
        Try

            If Not Populate_Transaction(Dtp_Trandate.Value) Then
                Btn_Showtranlist.Visible = True
                MessageBox.Show("No Records Found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Else
                Btn_Showtranlist.Visible = False
            End If

        Catch ex As Exception

        End Try
    End Sub

End Class