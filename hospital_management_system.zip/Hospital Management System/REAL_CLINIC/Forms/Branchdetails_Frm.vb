﻿

Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls
Public Class Branchdetails_Frm

#Region "Declarations"
    'Object of Employee Details Bussiness Layer
    Private Comp_BL As Company_Profile_BL_Cls
    Private hms_helper As HMS_Helper = Nothing


    Private mTr_Mode As Tran_Mode

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing

    Private mReq_Ctrl As Object = Nothing

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_Branchcode.BackColor = Color.White
                    Me.Txt_Branchcode.ReadOnly = False
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_Branchcode.BackColor = Color.Silver
                    Me.Txt_Branchcode.ReadOnly = True
            End Select
        End Set
    End Property

    Public WriteOnly Property Req_Ctrl() As Object
        Set(ByVal Value As Object)
            mReq_Ctrl = Value
        End Set
    End Property


#End Region

#Region "M e t h o d s"

    Private Function Validate_Fields() As Boolean
        Try
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If

            If Tr_Mode <> Tran_Mode.New_Mode Then
                If Txt_Branchcode.Text.Trim = "" Then MessageBox.Show("Invalid Branch Code,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Branchcode.Focus() : Exit Function
            End If

            If Txt_Branch_Name.Text.Trim = "" Then MessageBox.Show("Invalid Branch Name,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Branch_Name.Focus() : Exit Function
            If Txt_Branch_Addr.Text.Trim = "" Then MessageBox.Show("Invalid Branch Address,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Branch_Addr.Focus() : Exit Function
            If Cmb_Country.SelectedIndex <= 0 Then MessageBox.Show("Invalid Country Name,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_Country.Focus() : Exit Function


            If Txt_Branch_Email.Text.Trim = "" Then
                Txt_Branch_Email.Text = ""
            Else
                If Not Email_Validation(Txt_Branch_Email.Text.Trim, True) Then Txt_Branch_Email.Focus() : Exit Function
            End If

            'Assigning Default values
            If Txt_Branch_Phone1.Text.Trim = "" Then Txt_Branch_Phone1.Text = ""
            If Txt_Branch_Phone2.Text.Trim = "" Then Txt_Branch_Phone2.Text = ""
            If Txt_Fax.Text.Trim = "" Then Txt_Fax.Text = ""

            If Txt_Defbrcode.Text.Trim = String.Empty Then
                If MessageBox.Show("Wan't to continue without loading default Branch settings", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.No Then
                    Txt_Defbrcode.Focus()
                    Return False
                End If
            End If

            Return True

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try

    End Function

    Private Sub Clear_Form()
        Try

            Txt_Branchcode.Text = ""
            Txt_Branchcode.Tag = ""
            Txt_Branch_Name.Text = ""
            Txt_Branch_Addr.Text = ""
            Txt_Branch_Phone1.Text = ""
            Txt_Branch_Phone2.Text = ""
            Txt_Branch_Email.Text = ""
            Txt_Fax.Text = ""

            Txt_BrAcchead.Text = ""
            Txt_BrAcchead.Tag = ""

            Txt_Defbrcode.Text = ""
            Txt_Defbranch.Text = ""

            Lbl_Loaded.Visible = False
            Txt_Defbrcode.ReadOnly = False
            Txt_Defbrcode.BackColor = Color.White
            Btn_DefbrF2.Enabled = True


            Tr_Mode = Tran_Mode.New_Mode


            Btn_Save.Enabled = True
            Btn_Delete.Enabled = False


        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Function Locate_Values(ByVal Br_Code As Integer) As Boolean

        Try

            'Initialising BL Object
            Comp_BL = New Company_Profile_BL_Cls
            Dtbl = Nothing
            Call Clear_Form()

            Txt_Branchcode.Text = Br_Code

            'Retreiving Branch Details and Assign the values to respective controls
            If Comp_BL.Get_Branchprofile(Dtbl, Br_Code) Then
                Dr = Dtbl.CreateDataReader()
                Dr.Read()
                With Dr

                    Txt_Branchcode.Text = Br_Code
                    Txt_Branchcode.Tag = Br_Code
                    Txt_Branch_Name.Text = .Item("Branch Name")
                    Txt_Branch_Addr.Text = .Item("Address")
                    Txt_Branch_Phone1.Text = .Item("Phone1")
                    Txt_Branch_Phone2.Text = .Item("Phone2")
                    Cmb_Country.SelectedValue = .Item("Br_CountryID")
                    Txt_Branch_Email.Text = .Item("Email")
                    Txt_Fax.Text = .Item("Fax")

                    Txt_BrAcchead.Text = .Item("Br_Acc_code")
                    If Txt_BrAcchead.Text.Trim <> String.Empty Then
                        Call Btn_BrAccheadF2_Click(Nothing, Nothing)
                    End If

                    Txt_Defbrcode.Text = .Item("Br_Defbranch")
                    If Txt_Defbrcode.Text.Trim <> "0" AndAlso Txt_Defbrcode.Text.Trim <> String.Empty Then
                        Call Btn_DefbrF2_Click(Nothing, Nothing)
                        Lbl_Loaded.Visible = True
                        Txt_Defbrcode.ReadOnly = True
                        Txt_Defbrcode.BackColor = Color.Silver
                        Btn_DefbrF2.Enabled = False
                    Else
                        Txt_Defbrcode.Text = ""
                    End If




                End With
                Return True
            Else
                Return False
            End If



        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        Finally
            Dr = Nothing
            Dtbl = Nothing
            Comp_BL = Nothing
        End Try

    End Function

    Private Function Locate_ValuesDefbranch(ByVal Br_Code As Integer) As Boolean

        Try

            'Initialising BL Object
            Comp_BL = New Company_Profile_BL_Cls
            Dtbl = Nothing
            Txt_Defbranch.Text = ""

            'Retreiving Branch Details and Assign the values to respective controls
            If Comp_BL.Get_Branchprofile(Dtbl, Br_Code) Then
                Dr = Dtbl.CreateDataReader()
                Dr.Read()
                With Dr
                    If .Item("Br_Defbranch") = 0 Then
                        MessageBox.Show("Selected Branch settings also not done,Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    End If
                    Txt_Defbrcode.Tag = Br_Code
                    Txt_Defbranch.Text = .Item("Branch Name") + vbCrLf
                    Txt_Defbranch.Text += .Item("Address")
                End With
                Return True
            Else
                Return False
            End If



        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        Finally
            Dr = Nothing
            Dtbl = Nothing
            Comp_BL = Nothing
        End Try

    End Function

#End Region

    Private Sub Close_Btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

    Private Sub Branchdetails_Frm_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If TypeOf mReq_Ctrl Is TextBox And Txt_Branchcode.Text.Trim <> "" Then
            mReq_Ctrl.text = Txt_Branchcode.Text

            If mReq_Ctrl.Visible Then mReq_Ctrl.focus()
            'Me.Close()
            Exit Sub
        End If

    End Sub
    Private Sub Emp_Details_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then Call SendKeyTab()
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Clear_Btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try
            Call Clear_Form()
            Txt_Branchcode.Focus()
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub
    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try
            If Txt_Branchcode.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "200|200|50|"
                Sql = "SELECT [Branch Name], Address, Br_Code, Phone1, Email, Country FROM Branch_Master_Vw "
                Call ShowSearchengine(Txt_Branchcode, Sql, 2, "Branch Name", Colwidth, , 0)
            End If



            'Validating Mandatory fields for locating
            If Txt_Branchcode.Text.Trim = "" Then
                'MessageBox.Show("Invalid Employee ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_Branchcode.Focus() : Exit Sub
            End If

            If Locate_Values(Txt_Branchcode.Text.Trim) Then
                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Delete.Enabled = True
            Else
                MessageBox.Show("Branch Code does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub Save_Btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try
            'Initialising BL Object
            Comp_BL = New Company_Profile_BL_Cls

            'Validating Data controls
            If Not Validate_Fields() Then Exit Sub

            'Assigning Values to BL Properties
            With Comp_BL
                .Br_Code = Val(Txt_Branchcode.Text)
                .Br_Name = Txt_Branch_Name.Text
                .Br_Address = Txt_Branch_Addr.Text
                .Br_phone1 = Txt_Branch_Phone1.Text
                .Br_phone2 = Txt_Branch_Phone2.Text
                .Br_Country = Cmb_Country.Text
                .Br_CountryID = Cmb_Country.SelectedValue
                .Br_Email = Txt_Branch_Email.Text
                .Br_Fax = Txt_Fax.Text
                .Br_Acc_code = Txt_BrAcchead.Tag
                .Br_Defbranch = Val(Txt_Defbrcode.Text.Trim)
                .Br_Regdate = Tran_Date
            End With
            Dtbl = Nothing

            'Saving Branch Details using BL method
            If Comp_BL.Save_Branchprofile(Dtbl, Tr_Mode) Then
                If Dtbl.Rows(0).Item(0).ToString <> "0" Then

                    MessageBox.Show("Branch profile saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)

                    If Not mReq_Ctrl Is Nothing Then
                        If TypeOf mReq_Ctrl Is TextBox Then
                            mReq_Ctrl.text = Dtbl.Rows(0).Item(0).ToString
                            Me.Close()
                            Return
                        End If
                    End If

                    Call Clear_Form()
                    Dr = Dtbl.CreateDataReader()
                    Dr.Read()
                    With Dr
                        Txt_Branchcode.Text = .GetValue(0).ToString.Trim
                        Call Btn_Find_Click(sender, e)
                    End With
                    

                    Btn_Clear.Focus()
                Else
                    MessageBox.Show("Branch profile not Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)

                End If
            Else
                MessageBox.Show("Branch profile not Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_Branch_Phone1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Branch_Phone1.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Branch_Phone1.Text, Data_Type.Integer_Type, 12))
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    
    Private Sub Txt_Branch_Phone2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Branch_Phone2.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Branch_Phone2.Text, Data_Type.Integer_Type, 12))
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_Branchcode_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Branchcode.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then Btn_Find_Click(sender, e)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Branchcode_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Txt_Branchcode.TextChanged
        If Txt_Branchcode.Text.Trim = "" Then
            Call Clear_Form()
        End If
    End Sub

    Private Sub Txt_Branchcode_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_Branchcode.Validating
        Try
            If Me.Txt_Branchcode.Text.Trim <> "" And Me.Txt_Branchcode.Text <> Me.Txt_Branchcode.Tag Then
                If Locate_Values(Txt_Branchcode.Text.Trim) Then
                    Tr_Mode = Tran_Mode.Edit_Mode
                    Btn_Delete.Enabled = True
                    Txt_Branch_Name.Focus()
                Else
                    MessageBox.Show("Branch Code does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Txt_Branch_Name.Focus()
                    e.Cancel = True
                End If

            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_Branch_Addr_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Branch_Addr.KeyDown
        If e.KeyCode = Keys.Enter Then Txt_Branch_Addr.Select(Len(Txt_Branch_Addr.Text), 0)
    End Sub

    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click
        Try
            'Validating Mandatory fields for Deleting
            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If


            If Tr_Mode = Tran_Mode.New_Mode Then
                MessageBox.Show("You have to locate details before deleting the record", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

            If Txt_Branchcode.Text.Trim = "" Then
                MessageBox.Show("Invalid Branch Code,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_Branchcode.Focus() : Exit Sub
            End If

            'Confirm before delete the record
            If MessageBox.Show("Are you sure want to delete the selected Branch", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = Windows.Forms.DialogResult.No Then
                Exit Sub
            End If

            'Initialising BL Object
            Comp_BL = New Company_Profile_BL_Cls

            If Comp_BL.Delete_Branchprofile(Txt_Branchcode.Text.Trim) Then
                Call Clear_Btn_Click(sender, e)
                MessageBox.Show("Selected Branch details Deleted", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("You cannot delete this Branch details" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            Comp_BL = Nothing
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Branchdetails_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub
  
    Private Sub Branchdetails_Frm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            HMS_Helper = New Hms_Helperimpliments
            Call HMS_Helper.Fill_GenData(Cmb_Country, Gendatatype.Country)
            If Cmb_Country.Items.Count > 0 Then Cmb_Country.SelectedValue = Branch_CountryID
        Catch ex As Exception

        End Try
    End Sub

#Region "A D D  New GenData"

    Private Sub Set_NewGendatabutton(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cmb_Country.GotFocus
        Try
            Dim AddReqCtrl As Control = CType(sender, Control)

            Btn_New.Visible = True
            Me.Btn_New.Location = Get_Newgendatabuttonposition(AddReqCtrl)
            Me.Btn_New.Tag = AddReqCtrl.Name & "|" & Val(AddReqCtrl.Tag)

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_New_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_New.Click
        Try

            Call AddNewGendata(Btn_New)

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Call_Btnnew(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Cmb_Country.KeyDown
        Try
            If e.KeyCode = Keys.Add Then Call Btn_New_Click(Nothing, Nothing)
        Catch ex As Exception

        End Try
    End Sub

#End Region

    Private Sub Btn_DefbrF2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_DefbrF2.Click
        Try
            If Txt_Defbrcode.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "200|200|50|"
                Sql = "SELECT [Branch Name], Address, Br_Code, Phone1, Email, Country FROM Branch_Master_Vw "
                Sql += " Where Br_Defbranch <> 0 "
                If Txt_Branchcode.Text.Trim <> String.Empty AndAlso Me.Tr_Mode <> Tran_Mode.New_Mode Then
                    Sql += "And Br_Code <> " & Txt_Branchcode.Text.Trim & ""
                End If
                Call ShowSearchengine(Txt_Defbrcode, Sql, 2, "Branch Name", Colwidth, , 0)
            End If



            'Validating Mandatory fields for locating
            If Txt_Defbrcode.Text.Trim = "" Then
                'MessageBox.Show("Invalid Employee ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_Defbrcode.Focus() : Exit Sub
            End If

            If Not Locate_ValuesDefbranch(Txt_Defbrcode.Text.Trim) Then
                MessageBox.Show("Invalid Branch Code ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_Defbrcode_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Defbrcode.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then Btn_DefbrF2_Click(sender, e)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Defbrcode_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Defbrcode.TextChanged
        Try
            If Txt_Defbrcode.Text = "" Then Txt_Defbranch.Text = "" : Txt_Defbrcode.Tag = ""
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Defbrcode_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_Defbrcode.Validating
        Try
            If Me.Txt_Defbrcode.Text.Trim <> "" And Me.Txt_Defbrcode.Text <> Me.Txt_Defbrcode.Tag Then
                If Not Locate_Values(Txt_Defbrcode.Text.Trim) Then
                    MessageBox.Show("Invalid Branch Code,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Txt_Defbrcode.Focus()
                    e.Cancel = True
                End If

            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_BrAccheadF2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_BrAccheadF2.Click
        Try

            ' search engine
            If Txt_BrAcchead.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "300|100|100|50|"
                Sql = "SELECT [Acc Name], [Short Name], [Group Name], [Acc Code]"
                Sql += " FROM Accounts_Master_Vw "
                Sql += " Where [Branch Code] = " & Branch_Code & " "
                Call ShowSearchengine(Txt_BrAcchead, Sql, 3, "Acc Name", Colwidth, "Acc Name", 0)
            End If


            'Validating Mandatory fields for locating
            If Txt_BrAcchead.Text.Trim = "" Then
                ' MessageBox.Show("Invalid Head ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_BrAcchead.Focus() : Exit Sub
            End If

            Dim Dtbl As DataTable = Nothing
                If hms_helper.Get_AccountDetailsHeadWise(Dtbl, Txt_BrAcchead.Text) Then
                Txt_BrAcchead.Tag = Txt_BrAcchead.Text
                Txt_BrAcchead.Text = Dtbl.Rows(0).Item("Acc Name").ToString
                Call SendKeyTab()
            Else
                MessageBox.Show("Invalid Account Code,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_BrAcchead_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_BrAcchead.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then Call Btn_BrAccheadF2_Click(Nothing, Nothing)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_BrAcchead_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_BrAcchead.TextChanged
        Try
            If Txt_BrAcchead.Text.Trim = "" Then Txt_BrAcchead.Tag = ""
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_BrAcchead_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_BrAcchead.Validating
        Try
            If Me.Txt_BrAcchead.Text.Trim <> "" Then
                Dim Dtbl As DataTable = Nothing
                Dim Acc_Code As Integer
                If Not Integer.TryParse(Txt_BrAcchead.Text, Acc_Code) Then
                    Acc_Code = Val(Txt_BrAcchead.Tag)
                Else
                    Acc_Code = (Txt_BrAcchead.Text)
                End If
                If hms_helper.Get_AccountDetailsHeadWise(Dtbl, Acc_Code) Then
                    Txt_BrAcchead.Tag = Acc_Code
                    Txt_BrAcchead.Text = Dtbl.Rows(0).Item("Acc Name").ToString
                Else
                    MessageBox.Show("Invalid Account Code,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub
End Class