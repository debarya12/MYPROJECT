﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class HMS_MDIMain_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub


    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(HMS_MDIMain_Frm))
        Me.ToolTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.Tbtn_Apointment = New System.Windows.Forms.ToolStripButton()
        Me.Tbtn_OPReg = New System.Windows.Forms.ToolStripButton()
        Me.Tbtn_Billing = New System.Windows.Forms.ToolStripButton()
        Me.TBtn_Reports = New System.Windows.Forms.ToolStripButton()
        Me.TBtn_Lock = New System.Windows.Forms.ToolStripButton()
        Me.Lbl_Branch = New System.Windows.Forms.Label()
        Me.Lbl_Company = New System.Windows.Forms.Label()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.Tvw_Mainmenu = New System.Windows.Forms.TreeView()
        Me.Txt_Menucommand = New System.Windows.Forms.TextBox()
        Me.StatusStrip = New System.Windows.Forms.StatusStrip()
        Me.DCMGT_Statusbar = New System.Windows.Forms.ToolStripStatusLabel()
        Me.HMS_Timebar = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Lbl_Nwkstatus = New System.Windows.Forms.ToolStripStatusLabel()
        Me.MenuStrip = New System.Windows.Forms.MenuStrip()
        Me.mnu_System = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnu_ShowHideShortcutMenuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnu_Lock = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnu_LogOff = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnu_Close = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnu_HMSoptions = New System.Windows.Forms.ToolStripMenuItem()
        Me.DatabaseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BackupToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RestoreToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnu_Utility = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnu_Pwdmanagement = New System.Windows.Forms.ToolStripMenuItem()
        Me.SMSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NotepadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CalculatorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WordpadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MSWordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TaskManagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SystemInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnu_Exit = New System.Windows.Forms.ToolStripMenuItem()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Pnl_Openedforms = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.TlStrp_Openedforms = New System.Windows.Forms.ToolStrip()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.TlStrp_menuHistoryutility = New System.Windows.Forms.ToolStrip()
        Me.Clearhistory = New System.Windows.Forms.ToolStripButton()
        Me.Tlbtn_View = New System.Windows.Forms.ToolStripDropDownButton()
        Me.Tlbtn_Cascade = New System.Windows.Forms.ToolStripMenuItem()
        Me.Tlbtn_Tilevertical = New System.Windows.Forms.ToolStripMenuItem()
        Me.Tlbtn_Tilehorizontal = New System.Windows.Forms.ToolStripMenuItem()
        Me.Tlbtn_CloseAll = New System.Windows.Forms.ToolStripMenuItem()
        Me.Splitter1 = New System.Windows.Forms.Splitter()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        Me.StatusStrip.SuspendLayout()
        Me.MenuStrip.SuspendLayout()
        Me.Pnl_Openedforms.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.TlStrp_menuHistoryutility.SuspendLayout()
        Me.SuspendLayout()
        '
        'SplitContainer1
        '
        Me.SplitContainer1.BackColor = System.Drawing.Color.FromArgb(CType(CType(250, Byte), Integer), CType(CType(254, Byte), Integer), CType(CType(254, Byte), Integer))
        Me.SplitContainer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Top
        Me.SplitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 24)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.SplitContainer1.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.SplitContainer1.Panel1.Controls.Add(Me.ToolStrip1)
        Me.SplitContainer1.Panel1MinSize = 110
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.BackgroundImage = CType(resources.GetObject("SplitContainer1.Panel2.BackgroundImage"), System.Drawing.Image)
        Me.SplitContainer1.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.SplitContainer1.Panel2.Controls.Add(Me.Lbl_Branch)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Lbl_Company)
        Me.SplitContainer1.Size = New System.Drawing.Size(841, 50)
        Me.SplitContainer1.SplitterDistance = 584
        Me.SplitContainer1.SplitterWidth = 1
        Me.SplitContainer1.TabIndex = 10
        '
        'ToolStrip1
        '
        Me.ToolStrip1.BackColor = System.Drawing.Color.Transparent
        Me.ToolStrip1.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Toolbar_Bkg
        Me.ToolStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ToolStrip1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Tbtn_Apointment, Me.Tbtn_OPReg, Me.Tbtn_Billing, Me.TBtn_Reports, Me.TBtn_Lock})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Padding = New System.Windows.Forms.Padding(0)
        Me.ToolStrip1.Size = New System.Drawing.Size(582, 48)
        Me.ToolStrip1.TabIndex = 0
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'Tbtn_Apointment
        '
        Me.Tbtn_Apointment.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbtn_Apointment.Image = Global.REAL_CLINIC.My.Resources.Resources.time_sheduled_512
        Me.Tbtn_Apointment.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Tbtn_Apointment.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.Tbtn_Apointment.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.Tbtn_Apointment.Name = "Tbtn_Apointment"
        Me.Tbtn_Apointment.Size = New System.Drawing.Size(131, 45)
        Me.Tbtn_Apointment.Text = "Apointment(Ctrl+F3)   "
        Me.Tbtn_Apointment.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'Tbtn_OPReg
        '
        Me.Tbtn_OPReg.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbtn_OPReg.Image = Global.REAL_CLINIC.My.Resources.Resources.Health_care_shield_32
        Me.Tbtn_OPReg.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Tbtn_OPReg.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.Tbtn_OPReg.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.Tbtn_OPReg.Name = "Tbtn_OPReg"
        Me.Tbtn_OPReg.Size = New System.Drawing.Size(106, 45)
        Me.Tbtn_OPReg.Text = "OP Reg(Ctrl+F4)   "
        Me.Tbtn_OPReg.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'Tbtn_Billing
        '
        Me.Tbtn_Billing.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tbtn_Billing.Image = CType(resources.GetObject("Tbtn_Billing.Image"), System.Drawing.Image)
        Me.Tbtn_Billing.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Tbtn_Billing.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.Tbtn_Billing.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.Tbtn_Billing.Name = "Tbtn_Billing"
        Me.Tbtn_Billing.Size = New System.Drawing.Size(100, 45)
        Me.Tbtn_Billing.Text = "Billing(Ctrl+F5)   "
        Me.Tbtn_Billing.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'TBtn_Reports
        '
        Me.TBtn_Reports.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TBtn_Reports.Image = CType(resources.GetObject("TBtn_Reports.Image"), System.Drawing.Image)
        Me.TBtn_Reports.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.TBtn_Reports.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.TBtn_Reports.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.TBtn_Reports.Name = "TBtn_Reports"
        Me.TBtn_Reports.Size = New System.Drawing.Size(107, 45)
        Me.TBtn_Reports.Text = "Reports(Ctrl+F6)   "
        Me.TBtn_Reports.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'TBtn_Lock
        '
        Me.TBtn_Lock.Font = New System.Drawing.Font("Segoe UI Semibold", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TBtn_Lock.Image = CType(resources.GetObject("TBtn_Lock.Image"), System.Drawing.Image)
        Me.TBtn_Lock.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.TBtn_Lock.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.TBtn_Lock.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.TBtn_Lock.Name = "TBtn_Lock"
        Me.TBtn_Lock.Size = New System.Drawing.Size(91, 45)
        Me.TBtn_Lock.Text = "Lock(Ctrl+F7)   "
        Me.TBtn_Lock.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'Lbl_Branch
        '
        Me.Lbl_Branch.AutoSize = True
        Me.Lbl_Branch.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Branch.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Lbl_Branch.Location = New System.Drawing.Point(8, 28)
        Me.Lbl_Branch.Name = "Lbl_Branch"
        Me.Lbl_Branch.Size = New System.Drawing.Size(0, 13)
        Me.Lbl_Branch.TabIndex = 1
        '
        'Lbl_Company
        '
        Me.Lbl_Company.AutoSize = True
        Me.Lbl_Company.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Company.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Lbl_Company.Location = New System.Drawing.Point(8, 8)
        Me.Lbl_Company.Name = "Lbl_Company"
        Me.Lbl_Company.Size = New System.Drawing.Size(0, 16)
        Me.Lbl_Company.TabIndex = 0
        '
        'SplitContainer2
        '
        Me.SplitContainer2.BackColor = System.Drawing.Color.Silver
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Left
        Me.SplitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel2
        Me.SplitContainer2.IsSplitterFixed = True
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 74)
        Me.SplitContainer2.Margin = New System.Windows.Forms.Padding(0)
        Me.SplitContainer2.Name = "SplitContainer2"
        Me.SplitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.F2_Button
        Me.SplitContainer2.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.SplitContainer2.Panel1.Controls.Add(Me.Tvw_Mainmenu)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(228, Byte), Integer), CType(CType(237, Byte), Integer), CType(CType(243, Byte), Integer))
        Me.SplitContainer2.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.SplitContainer2.Panel2.Controls.Add(Me.Txt_Menucommand)
        Me.SplitContainer2.Panel2.Padding = New System.Windows.Forms.Padding(5)
        Me.SplitContainer2.Panel2MinSize = 35
        Me.SplitContainer2.Size = New System.Drawing.Size(175, 348)
        Me.SplitContainer2.SplitterDistance = 311
        Me.SplitContainer2.SplitterWidth = 2
        Me.SplitContainer2.TabIndex = 11
        '
        'Tvw_Mainmenu
        '
        Me.Tvw_Mainmenu.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(252, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Tvw_Mainmenu.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Tvw_Mainmenu.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Tvw_Mainmenu.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tvw_Mainmenu.Indent = 8
        Me.Tvw_Mainmenu.ItemHeight = 22
        Me.Tvw_Mainmenu.Location = New System.Drawing.Point(0, 0)
        Me.Tvw_Mainmenu.Margin = New System.Windows.Forms.Padding(1, 2, 2, 2)
        Me.Tvw_Mainmenu.Name = "Tvw_Mainmenu"
        Me.Tvw_Mainmenu.ShowLines = False
        Me.Tvw_Mainmenu.ShowRootLines = False
        Me.Tvw_Mainmenu.Size = New System.Drawing.Size(175, 311)
        Me.Tvw_Mainmenu.TabIndex = 1
        '
        'Txt_Menucommand
        '
        Me.Txt_Menucommand.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(113, Byte), Integer), CType(CType(193, Byte), Integer))
        Me.Txt_Menucommand.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Menucommand.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.Txt_Menucommand.Dock = System.Windows.Forms.DockStyle.Top
        Me.Txt_Menucommand.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Menucommand.ForeColor = System.Drawing.Color.White
        Me.Txt_Menucommand.Location = New System.Drawing.Point(5, 5)
        Me.Txt_Menucommand.Name = "Txt_Menucommand"
        Me.Txt_Menucommand.Size = New System.Drawing.Size(165, 21)
        Me.Txt_Menucommand.TabIndex = 0
        Me.Txt_Menucommand.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'StatusStrip
        '
        Me.StatusStrip.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.StatusStrip.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatusStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DCMGT_Statusbar, Me.HMS_Timebar, Me.Lbl_Nwkstatus})
        Me.StatusStrip.Location = New System.Drawing.Point(0, 422)
        Me.StatusStrip.Name = "StatusStrip"
        Me.StatusStrip.Size = New System.Drawing.Size(841, 22)
        Me.StatusStrip.TabIndex = 9
        Me.StatusStrip.Text = "StatusStrip"
        '
        'DCMGT_Statusbar
        '
        Me.DCMGT_Statusbar.BackColor = System.Drawing.Color.Transparent
        Me.DCMGT_Statusbar.ForeColor = System.Drawing.Color.White
        Me.DCMGT_Statusbar.Name = "DCMGT_Statusbar"
        Me.DCMGT_Statusbar.Size = New System.Drawing.Size(385, 17)
        Me.DCMGT_Statusbar.Text = "User name : PULSAR :  Designation : System Administrator"
        '
        'HMS_Timebar
        '
        Me.HMS_Timebar.BackColor = System.Drawing.Color.Transparent
        Me.HMS_Timebar.ForeColor = System.Drawing.Color.White
        Me.HMS_Timebar.Name = "HMS_Timebar"
        Me.HMS_Timebar.Size = New System.Drawing.Size(103, 17)
        Me.HMS_Timebar.Text = "System Time : "
        '
        'Lbl_Nwkstatus
        '
        Me.Lbl_Nwkstatus.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Nwkstatus.ForeColor = System.Drawing.Color.Cyan
        Me.Lbl_Nwkstatus.Name = "Lbl_Nwkstatus"
        Me.Lbl_Nwkstatus.Size = New System.Drawing.Size(152, 17)
        Me.Lbl_Nwkstatus.Text = "Network Not Available"
        Me.Lbl_Nwkstatus.Visible = False
        '
        'MenuStrip
        '
        Me.MenuStrip.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.MainMenu_Bkg
        Me.MenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnu_System, Me.mnu_HMSoptions, Me.DatabaseToolStripMenuItem, Me.mnu_Utility, Me.AboutToolStripMenuItem, Me.mnu_Exit})
        Me.MenuStrip.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip.Name = "MenuStrip"
        Me.MenuStrip.Size = New System.Drawing.Size(841, 24)
        Me.MenuStrip.TabIndex = 5
        Me.MenuStrip.Text = "MenuStrip"
        '
        'mnu_System
        '
        Me.mnu_System.BackColor = System.Drawing.Color.Transparent
        Me.mnu_System.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.mnu_System.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnu_ShowHideShortcutMenuToolStripMenuItem, Me.mnu_Lock, Me.mnu_LogOff, Me.mnu_Close})
        Me.mnu_System.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mnu_System.ForeColor = System.Drawing.Color.Black
        Me.mnu_System.ImageTransparentColor = System.Drawing.Color.Transparent
        Me.mnu_System.Name = "mnu_System"
        Me.mnu_System.Size = New System.Drawing.Size(60, 20)
        Me.mnu_System.Text = "System"
        '
        'mnu_ShowHideShortcutMenuToolStripMenuItem
        '
        Me.mnu_ShowHideShortcutMenuToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mnu_ShowHideShortcutMenuToolStripMenuItem.Name = "mnu_ShowHideShortcutMenuToolStripMenuItem"
        Me.mnu_ShowHideShortcutMenuToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.F12), System.Windows.Forms.Keys)
        Me.mnu_ShowHideShortcutMenuToolStripMenuItem.Size = New System.Drawing.Size(284, 22)
        Me.mnu_ShowHideShortcutMenuToolStripMenuItem.Text = "Show / Hide Shortcut Menu"
        '
        'mnu_Lock
        '
        Me.mnu_Lock.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mnu_Lock.Name = "mnu_Lock"
        Me.mnu_Lock.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.F7), System.Windows.Forms.Keys)
        Me.mnu_Lock.Size = New System.Drawing.Size(284, 22)
        Me.mnu_Lock.Text = "Lock"
        '
        'mnu_LogOff
        '
        Me.mnu_LogOff.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mnu_LogOff.Name = "mnu_LogOff"
        Me.mnu_LogOff.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.F9), System.Windows.Forms.Keys)
        Me.mnu_LogOff.Size = New System.Drawing.Size(284, 22)
        Me.mnu_LogOff.Text = "Log off"
        '
        'mnu_Close
        '
        Me.mnu_Close.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mnu_Close.Name = "mnu_Close"
        Me.mnu_Close.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.F8), System.Windows.Forms.Keys)
        Me.mnu_Close.Size = New System.Drawing.Size(284, 22)
        Me.mnu_Close.Text = "Exit"
        '
        'mnu_HMSoptions
        '
        Me.mnu_HMSoptions.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mnu_HMSoptions.ForeColor = System.Drawing.Color.Black
        Me.mnu_HMSoptions.Name = "mnu_HMSoptions"
        Me.mnu_HMSoptions.Size = New System.Drawing.Size(92, 20)
        Me.mnu_HMSoptions.Text = "HMS Options"
        '
        'DatabaseToolStripMenuItem
        '
        Me.DatabaseToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BackupToolStripMenuItem, Me.RestoreToolStripMenuItem})
        Me.DatabaseToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DatabaseToolStripMenuItem.Name = "DatabaseToolStripMenuItem"
        Me.DatabaseToolStripMenuItem.Size = New System.Drawing.Size(70, 20)
        Me.DatabaseToolStripMenuItem.Text = "Database"
        '
        'BackupToolStripMenuItem
        '
        Me.BackupToolStripMenuItem.Name = "BackupToolStripMenuItem"
        Me.BackupToolStripMenuItem.Size = New System.Drawing.Size(118, 22)
        Me.BackupToolStripMenuItem.Text = "Backup"
        '
        'RestoreToolStripMenuItem
        '
        Me.RestoreToolStripMenuItem.Name = "RestoreToolStripMenuItem"
        Me.RestoreToolStripMenuItem.Size = New System.Drawing.Size(118, 22)
        Me.RestoreToolStripMenuItem.Text = "Restore"
        '
        'mnu_Utility
        '
        Me.mnu_Utility.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnu_Pwdmanagement, Me.SMSToolStripMenuItem, Me.NotepadToolStripMenuItem, Me.CalculatorToolStripMenuItem, Me.WordpadToolStripMenuItem, Me.MSWordToolStripMenuItem, Me.TaskManagerToolStripMenuItem, Me.SystemInfoToolStripMenuItem})
        Me.mnu_Utility.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mnu_Utility.ForeColor = System.Drawing.Color.Black
        Me.mnu_Utility.Name = "mnu_Utility"
        Me.mnu_Utility.Size = New System.Drawing.Size(47, 20)
        Me.mnu_Utility.Text = "Tools"
        '
        'mnu_Pwdmanagement
        '
        Me.mnu_Pwdmanagement.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mnu_Pwdmanagement.Name = "mnu_Pwdmanagement"
        Me.mnu_Pwdmanagement.Size = New System.Drawing.Size(203, 22)
        Me.mnu_Pwdmanagement.Text = "Password Management"
        '
        'SMSToolStripMenuItem
        '
        Me.SMSToolStripMenuItem.Name = "SMSToolStripMenuItem"
        Me.SMSToolStripMenuItem.Size = New System.Drawing.Size(203, 22)
        Me.SMSToolStripMenuItem.Text = "SMS Setting"
        '
        'NotepadToolStripMenuItem
        '
        Me.NotepadToolStripMenuItem.Name = "NotepadToolStripMenuItem"
        Me.NotepadToolStripMenuItem.Size = New System.Drawing.Size(203, 22)
        Me.NotepadToolStripMenuItem.Text = "Notepad"
        '
        'CalculatorToolStripMenuItem
        '
        Me.CalculatorToolStripMenuItem.Name = "CalculatorToolStripMenuItem"
        Me.CalculatorToolStripMenuItem.Size = New System.Drawing.Size(203, 22)
        Me.CalculatorToolStripMenuItem.Text = "Calculator"
        '
        'WordpadToolStripMenuItem
        '
        Me.WordpadToolStripMenuItem.Name = "WordpadToolStripMenuItem"
        Me.WordpadToolStripMenuItem.Size = New System.Drawing.Size(203, 22)
        Me.WordpadToolStripMenuItem.Text = "Wordpad"
        '
        'MSWordToolStripMenuItem
        '
        Me.MSWordToolStripMenuItem.Name = "MSWordToolStripMenuItem"
        Me.MSWordToolStripMenuItem.Size = New System.Drawing.Size(203, 22)
        Me.MSWordToolStripMenuItem.Text = "MS Word"
        '
        'TaskManagerToolStripMenuItem
        '
        Me.TaskManagerToolStripMenuItem.Name = "TaskManagerToolStripMenuItem"
        Me.TaskManagerToolStripMenuItem.Size = New System.Drawing.Size(203, 22)
        Me.TaskManagerToolStripMenuItem.Text = "Task Manager"
        '
        'SystemInfoToolStripMenuItem
        '
        Me.SystemInfoToolStripMenuItem.Name = "SystemInfoToolStripMenuItem"
        Me.SystemInfoToolStripMenuItem.Size = New System.Drawing.Size(203, 22)
        Me.SystemInfoToolStripMenuItem.Text = "System Info"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(53, 20)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'mnu_Exit
        '
        Me.mnu_Exit.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.mnu_Exit.ForeColor = System.Drawing.Color.Black
        Me.mnu_Exit.Name = "mnu_Exit"
        Me.mnu_Exit.Size = New System.Drawing.Size(61, 20)
        Me.mnu_Exit.Text = "Log out"
        '
        'Timer1
        '
        '
        'Pnl_Openedforms
        '
        Me.Pnl_Openedforms.BackColor = System.Drawing.Color.White
        Me.Pnl_Openedforms.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Openedforms.Controls.Add(Me.Panel2)
        Me.Pnl_Openedforms.Controls.Add(Me.Panel1)
        Me.Pnl_Openedforms.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Openedforms.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Openedforms.Location = New System.Drawing.Point(175, 74)
        Me.Pnl_Openedforms.Name = "Pnl_Openedforms"
        Me.Pnl_Openedforms.Size = New System.Drawing.Size(666, 22)
        Me.Pnl_Openedforms.TabIndex = 13
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.TlStrp_Openedforms)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(128, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(536, 24)
        Me.Panel2.TabIndex = 4
        '
        'TlStrp_Openedforms
        '
        Me.TlStrp_Openedforms.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.TlStrp_Openedforms.CanOverflow = False
        Me.TlStrp_Openedforms.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.TlStrp_Openedforms.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TlStrp_Openedforms.Location = New System.Drawing.Point(0, -1)
        Me.TlStrp_Openedforms.Name = "TlStrp_Openedforms"
        Me.TlStrp_Openedforms.Size = New System.Drawing.Size(536, 25)
        Me.TlStrp_Openedforms.TabIndex = 2
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.TlStrp_menuHistoryutility)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(128, 20)
        Me.Panel1.TabIndex = 3
        '
        'TlStrp_menuHistoryutility
        '
        Me.TlStrp_menuHistoryutility.AllowMerge = False
        Me.TlStrp_menuHistoryutility.AutoSize = False
        Me.TlStrp_menuHistoryutility.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.TlStrp_menuHistoryutility.CanOverflow = False
        Me.TlStrp_menuHistoryutility.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TlStrp_menuHistoryutility.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TlStrp_menuHistoryutility.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Clearhistory, Me.Tlbtn_View})
        Me.TlStrp_menuHistoryutility.Location = New System.Drawing.Point(0, 0)
        Me.TlStrp_menuHistoryutility.Name = "TlStrp_menuHistoryutility"
        Me.TlStrp_menuHistoryutility.Padding = New System.Windows.Forms.Padding(0)
        Me.TlStrp_menuHistoryutility.Size = New System.Drawing.Size(128, 20)
        Me.TlStrp_menuHistoryutility.TabIndex = 1
        Me.TlStrp_menuHistoryutility.Text = "Clear History"
        '
        'Clearhistory
        '
        Me.Clearhistory.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.Clearhistory.ForeColor = System.Drawing.Color.White
        Me.Clearhistory.Image = CType(resources.GetObject("Clearhistory.Image"), System.Drawing.Image)
        Me.Clearhistory.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Clearhistory.Margin = New System.Windows.Forms.Padding(1)
        Me.Clearhistory.Name = "Clearhistory"
        Me.Clearhistory.Size = New System.Drawing.Size(37, 18)
        Me.Clearhistory.Text = "Clear"
        Me.Clearhistory.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'Tlbtn_View
        '
        Me.Tlbtn_View.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.Tlbtn_View.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Tlbtn_Cascade, Me.Tlbtn_Tilevertical, Me.Tlbtn_Tilehorizontal, Me.Tlbtn_CloseAll})
        Me.Tlbtn_View.ForeColor = System.Drawing.Color.White
        Me.Tlbtn_View.Image = CType(resources.GetObject("Tlbtn_View.Image"), System.Drawing.Image)
        Me.Tlbtn_View.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.Tlbtn_View.Name = "Tlbtn_View"
        Me.Tlbtn_View.Size = New System.Drawing.Size(47, 17)
        Me.Tlbtn_View.Text = "View"
        Me.Tlbtn_View.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        '
        'Tlbtn_Cascade
        '
        Me.Tlbtn_Cascade.Name = "Tlbtn_Cascade"
        Me.Tlbtn_Cascade.Size = New System.Drawing.Size(150, 22)
        Me.Tlbtn_Cascade.Text = "&Cascade"
        '
        'Tlbtn_Tilevertical
        '
        Me.Tlbtn_Tilevertical.Name = "Tlbtn_Tilevertical"
        Me.Tlbtn_Tilevertical.Size = New System.Drawing.Size(150, 22)
        Me.Tlbtn_Tilevertical.Text = "Tile &Vertical"
        '
        'Tlbtn_Tilehorizontal
        '
        Me.Tlbtn_Tilehorizontal.Name = "Tlbtn_Tilehorizontal"
        Me.Tlbtn_Tilehorizontal.Size = New System.Drawing.Size(150, 22)
        Me.Tlbtn_Tilehorizontal.Text = "Tile &Horizontal"
        '
        'Tlbtn_CloseAll
        '
        Me.Tlbtn_CloseAll.Name = "Tlbtn_CloseAll"
        Me.Tlbtn_CloseAll.Size = New System.Drawing.Size(150, 22)
        Me.Tlbtn_CloseAll.Text = "C&lose All"
        '
        'Splitter1
        '
        Me.Splitter1.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(113, Byte), Integer), CType(CType(193, Byte), Integer))
        Me.Splitter1.Cursor = System.Windows.Forms.Cursors.NoMoveHoriz
        Me.Splitter1.Location = New System.Drawing.Point(175, 96)
        Me.Splitter1.Name = "Splitter1"
        Me.Splitter1.Size = New System.Drawing.Size(4, 326)
        Me.Splitter1.TabIndex = 15
        Me.Splitter1.TabStop = False
        '
        'Timer2
        '
        Me.Timer2.Interval = 500
        '
        'Timer3
        '
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'HMS_MDIMain_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSkyBlue
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(841, 444)
        Me.Controls.Add(Me.Splitter1)
        Me.Controls.Add(Me.Pnl_Openedforms)
        Me.Controls.Add(Me.SplitContainer2)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Controls.Add(Me.StatusStrip)
        Me.Controls.Add(Me.MenuStrip)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip
        Me.Name = "HMS_MDIMain_Frm"
        Me.Text = "Main Menu [Hospital Management Soft]"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel1.PerformLayout()
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.Panel2.PerformLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        Me.SplitContainer2.Panel2.PerformLayout()
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer2.ResumeLayout(False)
        Me.StatusStrip.ResumeLayout(False)
        Me.StatusStrip.PerformLayout()
        Me.MenuStrip.ResumeLayout(False)
        Me.MenuStrip.PerformLayout()
        Me.Pnl_Openedforms.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.TlStrp_menuHistoryutility.ResumeLayout(False)
        Me.TlStrp_menuHistoryutility.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ToolTip As System.Windows.Forms.ToolTip
    Friend WithEvents MenuStrip As System.Windows.Forms.MenuStrip
    Friend WithEvents StatusStrip As System.Windows.Forms.StatusStrip
    Friend WithEvents DCMGT_Statusbar As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents HMS_Timebar As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents TBtn_Reports As System.Windows.Forms.ToolStripButton
    Friend WithEvents TBtn_Lock As System.Windows.Forms.ToolStripButton
    Friend WithEvents Lbl_Branch As System.Windows.Forms.Label
    Friend WithEvents Lbl_Company As System.Windows.Forms.Label
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents mnu_System As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_Lock As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_Close As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_HMSoptions As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_Exit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_Utility As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_Pwdmanagement As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Txt_Menucommand As System.Windows.Forms.TextBox
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Tvw_Mainmenu As System.Windows.Forms.TreeView
    Friend WithEvents Pnl_Openedforms As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents TlStrp_Openedforms As System.Windows.Forms.ToolStrip
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents TlStrp_menuHistoryutility As System.Windows.Forms.ToolStrip
    Friend WithEvents Clearhistory As System.Windows.Forms.ToolStripButton
    Friend WithEvents Tlbtn_View As System.Windows.Forms.ToolStripDropDownButton
    Friend WithEvents Tlbtn_Cascade As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Tlbtn_Tilevertical As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Tlbtn_Tilehorizontal As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Tlbtn_CloseAll As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Splitter1 As System.Windows.Forms.Splitter
    Friend WithEvents mnu_ShowHideShortcutMenuToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnu_LogOff As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Tbtn_OPReg As System.Windows.Forms.ToolStripButton
    Friend WithEvents Tbtn_Apointment As System.Windows.Forms.ToolStripButton
    Friend WithEvents Tbtn_Billing As System.Windows.Forms.ToolStripButton
    Friend WithEvents Lbl_Nwkstatus As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DatabaseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BackupToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RestoreToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Timer3 As System.Windows.Forms.Timer
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents NotepadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CalculatorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents WordpadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MSWordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TaskManagerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SystemInfoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SMSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
