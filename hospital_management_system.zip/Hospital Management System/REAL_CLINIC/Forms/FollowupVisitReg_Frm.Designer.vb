﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FollowupVisitReg_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FollowupVisitReg_Frm))
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Lbl_Heading = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Lbl_Doctordetails = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Cmb_Service = New System.Windows.Forms.ComboBox
        Me.Pnl_Doctors = New System.Windows.Forms.Panel
        Me.TlStrp_Doctors = New System.Windows.Forms.ToolStrip
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton
        Me.Label2 = New System.Windows.Forms.Label
        Me.Pnl_1 = New System.Windows.Forms.Panel
        Me.Btn_NewOP = New System.Windows.Forms.Button
        Me.Label12 = New System.Windows.Forms.Label
        Me.Lbl_OPValidDays = New System.Windows.Forms.Label
        Me.Lbl_OPValidity = New System.Windows.Forms.Label
        Me.Txt_PMRID = New System.Windows.Forms.TextBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.Txt_OPID = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Btn_Find = New System.Windows.Forms.Button
        Me.Pnl_3 = New System.Windows.Forms.Panel
        Me.Lbl_Currentstatus = New System.Windows.Forms.Label
        Me.Label36 = New System.Windows.Forms.Label
        Me.Lbl_Billingmethod = New System.Windows.Forms.Label
        Me.Label33 = New System.Windows.Forms.Label
        Me.Lbl_Patienttype = New System.Windows.Forms.Label
        Me.Label31 = New System.Windows.Forms.Label
        Me.Lbl_Nof_Visits = New System.Windows.Forms.Label
        Me.Label29 = New System.Windows.Forms.Label
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Pnl_2 = New System.Windows.Forms.Panel
        Me.Txt_Remarks = New System.Windows.Forms.TextBox
        Me.Label28 = New System.Windows.Forms.Label
        Me.Pnl_Apoint = New System.Windows.Forms.Panel
        Me.Txt_ApointID = New System.Windows.Forms.TextBox
        Me.Label18 = New System.Windows.Forms.Label
        Me.Btn_AppIDF2 = New System.Windows.Forms.Button
        Me.Btn_Appointment = New System.Windows.Forms.Button
        Me.Panel4 = New System.Windows.Forms.Panel
        Me.Lbl_Mesageaproxtime = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.Lbl_MesageTokenno = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.Pnl_Othersdetails = New System.Windows.Forms.Panel
        Me.Txt_Nationality = New System.Windows.Forms.TextBox
        Me.Txt_Gender = New System.Windows.Forms.TextBox
        Me.Txt_PatientID = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.Txt_Visitor_Familyname = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Txt_Visitor_SSNO = New System.Windows.Forms.TextBox
        Me.Label35 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Txt_Visitor_Age = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Txt_Visitor_Mobile = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.Txt_Visitor_Phone = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Txt_Visitor_Addr = New System.Windows.Forms.TextBox
        Me.Txt_Visitor_Name = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Btn_PMRIDF2 = New System.Windows.Forms.Button
        Me.Pnl_Header.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Pnl_Doctors.SuspendLayout()
        Me.TlStrp_Doctors.SuspendLayout()
        Me.Pnl_1.SuspendLayout()
        Me.Pnl_3.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.Pnl_2.SuspendLayout()
        Me.Pnl_Apoint.SuspendLayout()
        Me.Pnl_Othersdetails.SuspendLayout()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = CType(resources.GetObject("Pnl_Header.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Header.Controls.Add(Me.Lbl_Heading)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(724, 21)
        Me.Pnl_Header.TabIndex = 102
        '
        'Lbl_Heading
        '
        Me.Lbl_Heading.AutoSize = True
        Me.Lbl_Heading.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Heading.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Heading.ForeColor = System.Drawing.Color.White
        Me.Lbl_Heading.Location = New System.Drawing.Point(8, 0)
        Me.Lbl_Heading.Name = "Lbl_Heading"
        Me.Lbl_Heading.Size = New System.Drawing.Size(259, 18)
        Me.Lbl_Heading.TabIndex = 121
        Me.Lbl_Heading.Text = "F o l l o w u p  V i s i t   R e g i s t e r "
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label19.Location = New System.Drawing.Point(-66, 63)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(52, 14)
        Me.Label19.TabIndex = 100075
        Me.Label19.Text = "SERVICE"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Lbl_Doctordetails)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Cmb_Service)
        Me.Panel1.Controls.Add(Me.Pnl_Doctors)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 21)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(724, 80)
        Me.Panel1.TabIndex = 0
        '
        'Lbl_Doctordetails
        '
        Me.Lbl_Doctordetails.BackColor = System.Drawing.Color.FromArgb(CType(CType(58, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(139, Byte), Integer))
        Me.Lbl_Doctordetails.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Lbl_Doctordetails.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Doctordetails.ForeColor = System.Drawing.Color.AliceBlue
        Me.Lbl_Doctordetails.Location = New System.Drawing.Point(361, 47)
        Me.Lbl_Doctordetails.Name = "Lbl_Doctordetails"
        Me.Lbl_Doctordetails.Padding = New System.Windows.Forms.Padding(5, 0, 0, 0)
        Me.Lbl_Doctordetails.Size = New System.Drawing.Size(361, 32)
        Me.Lbl_Doctordetails.TabIndex = 100078
        Me.Lbl_Doctordetails.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label1.Location = New System.Drawing.Point(3, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(52, 14)
        Me.Label1.TabIndex = 100077
        Me.Label1.Text = "SERVICE"
        '
        'Cmb_Service
        '
        Me.Cmb_Service.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Service.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_Service.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Service.FormattingEnabled = True
        Me.Cmb_Service.ItemHeight = 13
        Me.Cmb_Service.Location = New System.Drawing.Point(75, 25)
        Me.Cmb_Service.Name = "Cmb_Service"
        Me.Cmb_Service.Size = New System.Drawing.Size(169, 21)
        Me.Cmb_Service.TabIndex = 1
        '
        'Pnl_Doctors
        '
        Me.Pnl_Doctors.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Doctors.Controls.Add(Me.TlStrp_Doctors)
        Me.Pnl_Doctors.Location = New System.Drawing.Point(247, 3)
        Me.Pnl_Doctors.Margin = New System.Windows.Forms.Padding(0)
        Me.Pnl_Doctors.Name = "Pnl_Doctors"
        Me.Pnl_Doctors.Padding = New System.Windows.Forms.Padding(2)
        Me.Pnl_Doctors.Size = New System.Drawing.Size(477, 45)
        Me.Pnl_Doctors.TabIndex = 2
        '
        'TlStrp_Doctors
        '
        Me.TlStrp_Doctors.BackColor = System.Drawing.Color.White
        Me.TlStrp_Doctors.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TlStrp_Doctors.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TlStrp_Doctors.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TlStrp_Doctors.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton1})
        Me.TlStrp_Doctors.Location = New System.Drawing.Point(2, 2)
        Me.TlStrp_Doctors.Name = "TlStrp_Doctors"
        Me.TlStrp_Doctors.Size = New System.Drawing.Size(473, 41)
        Me.TlStrp_Doctors.TabIndex = 1
        Me.TlStrp_Doctors.TabStop = True
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton1.Image = CType(resources.GetObject("ToolStripButton1.Image"), System.Drawing.Image)
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(23, 38)
        Me.ToolStripButton1.Text = "ToolStripButton1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label2.Location = New System.Drawing.Point(280, 56)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(43, 14)
        Me.Label2.TabIndex = 100079
        Me.Label2.Text = "Doctor"
        '
        'Pnl_1
        '
        Me.Pnl_1.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_1.Controls.Add(Me.Btn_PMRIDF2)
        Me.Pnl_1.Controls.Add(Me.Btn_NewOP)
        Me.Pnl_1.Controls.Add(Me.Label12)
        Me.Pnl_1.Controls.Add(Me.Lbl_OPValidDays)
        Me.Pnl_1.Controls.Add(Me.Lbl_OPValidity)
        Me.Pnl_1.Controls.Add(Me.Txt_PMRID)
        Me.Pnl_1.Controls.Add(Me.Label17)
        Me.Pnl_1.Controls.Add(Me.Txt_OPID)
        Me.Pnl_1.Controls.Add(Me.Label3)
        Me.Pnl_1.Controls.Add(Me.Btn_Find)
        Me.Pnl_1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_1.Enabled = False
        Me.Pnl_1.Location = New System.Drawing.Point(0, 101)
        Me.Pnl_1.Name = "Pnl_1"
        Me.Pnl_1.Size = New System.Drawing.Size(724, 71)
        Me.Pnl_1.TabIndex = 1
        '
        'Btn_NewOP
        '
        Me.Btn_NewOP.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_NewOP.BackgroundImage = CType(resources.GetObject("Btn_NewOP.BackgroundImage"), System.Drawing.Image)
        Me.Btn_NewOP.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_NewOP.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_NewOP.ForeColor = System.Drawing.Color.White
        Me.Btn_NewOP.Location = New System.Drawing.Point(544, 13)
        Me.Btn_NewOP.Name = "Btn_NewOP"
        Me.Btn_NewOP.Size = New System.Drawing.Size(84, 21)
        Me.Btn_NewOP.TabIndex = 100087
        Me.Btn_NewOP.TabStop = False
        Me.Btn_NewOP.Text = "NEW &OP (F3)"
        Me.Btn_NewOP.UseVisualStyleBackColor = False
        Me.Btn_NewOP.Visible = False
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label12.Location = New System.Drawing.Point(279, 16)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(65, 14)
        Me.Label12.TabIndex = 100086
        Me.Label12.Text = "OP Validity"
        '
        'Lbl_OPValidDays
        '
        Me.Lbl_OPValidDays.BackColor = System.Drawing.Color.White
        Me.Lbl_OPValidDays.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Lbl_OPValidDays.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_OPValidDays.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Lbl_OPValidDays.Location = New System.Drawing.Point(360, 13)
        Me.Lbl_OPValidDays.Name = "Lbl_OPValidDays"
        Me.Lbl_OPValidDays.Size = New System.Drawing.Size(90, 21)
        Me.Lbl_OPValidDays.TabIndex = 100085
        Me.Lbl_OPValidDays.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Lbl_OPValidity
        '
        Me.Lbl_OPValidity.BackColor = System.Drawing.Color.White
        Me.Lbl_OPValidity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Lbl_OPValidity.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_OPValidity.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Lbl_OPValidity.Location = New System.Drawing.Point(452, 13)
        Me.Lbl_OPValidity.Name = "Lbl_OPValidity"
        Me.Lbl_OPValidity.Size = New System.Drawing.Size(91, 21)
        Me.Lbl_OPValidity.TabIndex = 100084
        Me.Lbl_OPValidity.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Txt_PMRID
        '
        Me.Txt_PMRID.BackColor = System.Drawing.Color.White
        Me.Txt_PMRID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_PMRID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PMRID.Location = New System.Drawing.Point(74, 37)
        Me.Txt_PMRID.Name = "Txt_PMRID"
        Me.Txt_PMRID.ReadOnly = True
        Me.Txt_PMRID.Size = New System.Drawing.Size(152, 21)
        Me.Txt_PMRID.TabIndex = 3
        Me.Txt_PMRID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label17.Location = New System.Drawing.Point(3, 42)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(45, 14)
        Me.Label17.TabIndex = 220
        Me.Label17.Text = "PMR-ID"
        '
        'Txt_OPID
        '
        Me.Txt_OPID.BackColor = System.Drawing.Color.White
        Me.Txt_OPID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_OPID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_OPID.Location = New System.Drawing.Point(74, 13)
        Me.Txt_OPID.MaxLength = 10
        Me.Txt_OPID.Name = "Txt_OPID"
        Me.Txt_OPID.Size = New System.Drawing.Size(152, 21)
        Me.Txt_OPID.TabIndex = 1
        Me.Txt_OPID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label3.Location = New System.Drawing.Point(3, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(35, 14)
        Me.Label3.TabIndex = 217
        Me.Label3.Text = "OP ID"
        '
        'Btn_Find
        '
        Me.Btn_Find.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find.BackgroundImage = CType(resources.GetObject("Btn_Find.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find.ForeColor = System.Drawing.Color.White
        Me.Btn_Find.Location = New System.Drawing.Point(227, 13)
        Me.Btn_Find.Name = "Btn_Find"
        Me.Btn_Find.Size = New System.Drawing.Size(29, 21)
        Me.Btn_Find.TabIndex = 2
        Me.Btn_Find.TabStop = False
        Me.Btn_Find.Text = "F2"
        Me.Btn_Find.UseVisualStyleBackColor = False
        '
        'Pnl_3
        '
        Me.Pnl_3.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_3.Controls.Add(Me.Lbl_Currentstatus)
        Me.Pnl_3.Controls.Add(Me.Label36)
        Me.Pnl_3.Controls.Add(Me.Lbl_Billingmethod)
        Me.Pnl_3.Controls.Add(Me.Label33)
        Me.Pnl_3.Controls.Add(Me.Lbl_Patienttype)
        Me.Pnl_3.Controls.Add(Me.Label31)
        Me.Pnl_3.Controls.Add(Me.Lbl_Nof_Visits)
        Me.Pnl_3.Controls.Add(Me.Label29)
        Me.Pnl_3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_3.Enabled = False
        Me.Pnl_3.Location = New System.Drawing.Point(0, 172)
        Me.Pnl_3.Name = "Pnl_3"
        Me.Pnl_3.Size = New System.Drawing.Size(724, 54)
        Me.Pnl_3.TabIndex = 2
        '
        'Lbl_Currentstatus
        '
        Me.Lbl_Currentstatus.AutoSize = True
        Me.Lbl_Currentstatus.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Currentstatus.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Currentstatus.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Lbl_Currentstatus.Location = New System.Drawing.Point(183, 29)
        Me.Lbl_Currentstatus.Name = "Lbl_Currentstatus"
        Me.Lbl_Currentstatus.Size = New System.Drawing.Size(13, 16)
        Me.Lbl_Currentstatus.TabIndex = 100058
        Me.Lbl_Currentstatus.Text = "*"
        Me.Lbl_Currentstatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.BackColor = System.Drawing.Color.Transparent
        Me.Label36.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label36.Location = New System.Drawing.Point(73, 30)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(97, 14)
        Me.Label36.TabIndex = 100057
        Me.Label36.Text = "Current Status  :"
        '
        'Lbl_Billingmethod
        '
        Me.Lbl_Billingmethod.AutoSize = True
        Me.Lbl_Billingmethod.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Billingmethod.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Billingmethod.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Lbl_Billingmethod.Location = New System.Drawing.Point(183, 4)
        Me.Lbl_Billingmethod.Name = "Lbl_Billingmethod"
        Me.Lbl_Billingmethod.Size = New System.Drawing.Size(13, 16)
        Me.Lbl_Billingmethod.TabIndex = 100056
        Me.Lbl_Billingmethod.Text = "*"
        Me.Lbl_Billingmethod.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.BackColor = System.Drawing.Color.Transparent
        Me.Label33.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label33.Location = New System.Drawing.Point(73, 5)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(97, 14)
        Me.Label33.TabIndex = 100055
        Me.Label33.Text = "Billing Method   :"
        '
        'Lbl_Patienttype
        '
        Me.Lbl_Patienttype.AutoSize = True
        Me.Lbl_Patienttype.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Patienttype.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Patienttype.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Lbl_Patienttype.Location = New System.Drawing.Point(477, 4)
        Me.Lbl_Patienttype.Name = "Lbl_Patienttype"
        Me.Lbl_Patienttype.Size = New System.Drawing.Size(13, 16)
        Me.Lbl_Patienttype.TabIndex = 100054
        Me.Lbl_Patienttype.Text = "*"
        Me.Lbl_Patienttype.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.BackColor = System.Drawing.Color.Transparent
        Me.Label31.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label31.Location = New System.Drawing.Point(361, 5)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(96, 14)
        Me.Label31.TabIndex = 100053
        Me.Label31.Text = "Patient Type      :"
        '
        'Lbl_Nof_Visits
        '
        Me.Lbl_Nof_Visits.AutoSize = True
        Me.Lbl_Nof_Visits.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Nof_Visits.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Nof_Visits.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Lbl_Nof_Visits.Location = New System.Drawing.Point(474, 24)
        Me.Lbl_Nof_Visits.Name = "Lbl_Nof_Visits"
        Me.Lbl_Nof_Visits.Size = New System.Drawing.Size(21, 25)
        Me.Lbl_Nof_Visits.TabIndex = 100052
        Me.Lbl_Nof_Visits.Text = "*"
        Me.Lbl_Nof_Visits.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.BackColor = System.Drawing.Color.Transparent
        Me.Label29.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label29.Location = New System.Drawing.Point(361, 29)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(97, 14)
        Me.Label29.TabIndex = 100051
        Me.Label29.Text = "No of Visits        :"
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(449, 446)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(271, 33)
        Me.Pnl_Common_Btn.TabIndex = 4
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Close.Location = New System.Drawing.Point(179, 3)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(88, 26)
        Me.Btn_Close.TabIndex = 4
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Clear.Location = New System.Drawing.Point(91, 3)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(88, 26)
        Me.Btn_Clear.TabIndex = 3
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = CType(resources.GetObject("Btn_Save.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Save.Enabled = False
        Me.Btn_Save.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(3, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(88, 26)
        Me.Btn_Save.TabIndex = 1
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Timer1
        '
        Me.Timer1.Interval = 500
        '
        'Pnl_2
        '
        Me.Pnl_2.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_2.Controls.Add(Me.Txt_Remarks)
        Me.Pnl_2.Controls.Add(Me.Label28)
        Me.Pnl_2.Controls.Add(Me.Pnl_Apoint)
        Me.Pnl_2.Controls.Add(Me.Panel4)
        Me.Pnl_2.Controls.Add(Me.Lbl_Mesageaproxtime)
        Me.Pnl_2.Controls.Add(Me.Label25)
        Me.Pnl_2.Controls.Add(Me.Lbl_MesageTokenno)
        Me.Pnl_2.Controls.Add(Me.Label24)
        Me.Pnl_2.Controls.Add(Me.Pnl_Othersdetails)
        Me.Pnl_2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_2.Enabled = False
        Me.Pnl_2.Location = New System.Drawing.Point(0, 226)
        Me.Pnl_2.Name = "Pnl_2"
        Me.Pnl_2.Size = New System.Drawing.Size(724, 218)
        Me.Pnl_2.TabIndex = 3
        '
        'Txt_Remarks
        '
        Me.Txt_Remarks.BackColor = System.Drawing.Color.White
        Me.Txt_Remarks.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Remarks.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Remarks.Location = New System.Drawing.Point(361, 194)
        Me.Txt_Remarks.MaxLength = 250
        Me.Txt_Remarks.Name = "Txt_Remarks"
        Me.Txt_Remarks.Size = New System.Drawing.Size(358, 20)
        Me.Txt_Remarks.TabIndex = 3
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.BackColor = System.Drawing.Color.Transparent
        Me.Label28.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label28.Location = New System.Drawing.Point(280, 196)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(57, 14)
        Me.Label28.TabIndex = 100084
        Me.Label28.Text = "Remarks"
        '
        'Pnl_Apoint
        '
        Me.Pnl_Apoint.Controls.Add(Me.Txt_ApointID)
        Me.Pnl_Apoint.Controls.Add(Me.Label18)
        Me.Pnl_Apoint.Controls.Add(Me.Btn_AppIDF2)
        Me.Pnl_Apoint.Controls.Add(Me.Btn_Appointment)
        Me.Pnl_Apoint.Location = New System.Drawing.Point(3, 1)
        Me.Pnl_Apoint.Name = "Pnl_Apoint"
        Me.Pnl_Apoint.Size = New System.Drawing.Size(259, 28)
        Me.Pnl_Apoint.TabIndex = 1
        '
        'Txt_ApointID
        '
        Me.Txt_ApointID.BackColor = System.Drawing.Color.White
        Me.Txt_ApointID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_ApointID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_ApointID.Location = New System.Drawing.Point(72, 3)
        Me.Txt_ApointID.Name = "Txt_ApointID"
        Me.Txt_ApointID.Size = New System.Drawing.Size(100, 21)
        Me.Txt_ApointID.TabIndex = 1
        Me.Txt_ApointID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.Transparent
        Me.Label18.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label18.Location = New System.Drawing.Point(1, 6)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(63, 14)
        Me.Label18.TabIndex = 208
        Me.Label18.Text = "Appoint ID"
        '
        'Btn_AppIDF2
        '
        Me.Btn_AppIDF2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_AppIDF2.BackgroundImage = CType(resources.GetObject("Btn_AppIDF2.BackgroundImage"), System.Drawing.Image)
        Me.Btn_AppIDF2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_AppIDF2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_AppIDF2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_AppIDF2.ForeColor = System.Drawing.Color.White
        Me.Btn_AppIDF2.Location = New System.Drawing.Point(173, 3)
        Me.Btn_AppIDF2.Name = "Btn_AppIDF2"
        Me.Btn_AppIDF2.Size = New System.Drawing.Size(27, 21)
        Me.Btn_AppIDF2.TabIndex = 2
        Me.Btn_AppIDF2.TabStop = False
        Me.Btn_AppIDF2.Text = "F2"
        Me.Btn_AppIDF2.UseVisualStyleBackColor = False
        '
        'Btn_Appointment
        '
        Me.Btn_Appointment.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Appointment.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.F2_Button
        Me.Btn_Appointment.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Appointment.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Appointment.ForeColor = System.Drawing.Color.White
        Me.Btn_Appointment.Location = New System.Drawing.Point(201, 3)
        Me.Btn_Appointment.Name = "Btn_Appointment"
        Me.Btn_Appointment.Size = New System.Drawing.Size(54, 21)
        Me.Btn_Appointment.TabIndex = 3
        Me.Btn_Appointment.TabStop = False
        Me.Btn_Appointment.Text = "&New F3"
        Me.Btn_Appointment.UseVisualStyleBackColor = False
        '
        'Panel4
        '
        Me.Panel4.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel4.Location = New System.Drawing.Point(266, 1)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(6, 190)
        Me.Panel4.TabIndex = 100053
        '
        'Lbl_Mesageaproxtime
        '
        Me.Lbl_Mesageaproxtime.AutoSize = True
        Me.Lbl_Mesageaproxtime.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Mesageaproxtime.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Mesageaproxtime.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Lbl_Mesageaproxtime.Location = New System.Drawing.Point(133, 114)
        Me.Lbl_Mesageaproxtime.Name = "Lbl_Mesageaproxtime"
        Me.Lbl_Mesageaproxtime.Size = New System.Drawing.Size(21, 25)
        Me.Lbl_Mesageaproxtime.TabIndex = 100050
        Me.Lbl_Mesageaproxtime.Text = "*"
        Me.Lbl_Mesageaproxtime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.BackColor = System.Drawing.Color.Transparent
        Me.Label25.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label25.Location = New System.Drawing.Point(13, 118)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(108, 14)
        Me.Label25.TabIndex = 100049
        Me.Label25.Text = "Aproximate Time :"
        '
        'Lbl_MesageTokenno
        '
        Me.Lbl_MesageTokenno.AutoSize = True
        Me.Lbl_MesageTokenno.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_MesageTokenno.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_MesageTokenno.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Lbl_MesageTokenno.Location = New System.Drawing.Point(123, 45)
        Me.Lbl_MesageTokenno.Name = "Lbl_MesageTokenno"
        Me.Lbl_MesageTokenno.Size = New System.Drawing.Size(44, 55)
        Me.Lbl_MesageTokenno.TabIndex = 100048
        Me.Lbl_MesageTokenno.Text = "*"
        Me.Lbl_MesageTokenno.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.BackColor = System.Drawing.Color.Transparent
        Me.Label24.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label24.Location = New System.Drawing.Point(56, 67)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(65, 14)
        Me.Label24.TabIndex = 100047
        Me.Label24.Text = "Token No :"
        '
        'Pnl_Othersdetails
        '
        Me.Pnl_Othersdetails.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Othersdetails.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Nationality)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Gender)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_PatientID)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label9)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_Familyname)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label6)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_SSNO)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label35)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label5)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_Age)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label15)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label13)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_Mobile)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label11)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_Phone)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label8)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label4)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_Addr)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_Name)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label7)
        Me.Pnl_Othersdetails.Location = New System.Drawing.Point(265, 0)
        Me.Pnl_Othersdetails.Name = "Pnl_Othersdetails"
        Me.Pnl_Othersdetails.Size = New System.Drawing.Size(459, 192)
        Me.Pnl_Othersdetails.TabIndex = 2
        '
        'Txt_Nationality
        '
        Me.Txt_Nationality.BackColor = System.Drawing.Color.White
        Me.Txt_Nationality.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Nationality.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Nationality.Location = New System.Drawing.Point(95, 165)
        Me.Txt_Nationality.MaxLength = 250
        Me.Txt_Nationality.Name = "Txt_Nationality"
        Me.Txt_Nationality.ReadOnly = True
        Me.Txt_Nationality.Size = New System.Drawing.Size(358, 21)
        Me.Txt_Nationality.TabIndex = 10
        Me.Txt_Nationality.TabStop = False
        '
        'Txt_Gender
        '
        Me.Txt_Gender.BackColor = System.Drawing.Color.White
        Me.Txt_Gender.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Gender.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Gender.Location = New System.Drawing.Point(95, 115)
        Me.Txt_Gender.MaxLength = 250
        Me.Txt_Gender.Name = "Txt_Gender"
        Me.Txt_Gender.ReadOnly = True
        Me.Txt_Gender.Size = New System.Drawing.Size(138, 21)
        Me.Txt_Gender.TabIndex = 6
        Me.Txt_Gender.TabStop = False
        '
        'Txt_PatientID
        '
        Me.Txt_PatientID.BackColor = System.Drawing.Color.White
        Me.Txt_PatientID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_PatientID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PatientID.Location = New System.Drawing.Point(95, 3)
        Me.Txt_PatientID.MaxLength = 50
        Me.Txt_PatientID.Name = "Txt_PatientID"
        Me.Txt_PatientID.ReadOnly = True
        Me.Txt_PatientID.Size = New System.Drawing.Size(138, 21)
        Me.Txt_PatientID.TabIndex = 1
        Me.Txt_PatientID.TabStop = False
        Me.Txt_PatientID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label9.Location = New System.Drawing.Point(13, 7)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(58, 14)
        Me.Label9.TabIndex = 100047
        Me.Label9.Text = "Patient ID"
        '
        'Txt_Visitor_Familyname
        '
        Me.Txt_Visitor_Familyname.BackColor = System.Drawing.Color.White
        Me.Txt_Visitor_Familyname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Familyname.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Familyname.Location = New System.Drawing.Point(95, 91)
        Me.Txt_Visitor_Familyname.MaxLength = 250
        Me.Txt_Visitor_Familyname.Name = "Txt_Visitor_Familyname"
        Me.Txt_Visitor_Familyname.ReadOnly = True
        Me.Txt_Visitor_Familyname.Size = New System.Drawing.Size(358, 21)
        Me.Txt_Visitor_Familyname.TabIndex = 5
        Me.Txt_Visitor_Familyname.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label6.Location = New System.Drawing.Point(13, 94)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(76, 14)
        Me.Label6.TabIndex = 100044
        Me.Label6.Text = "Family Name"
        '
        'Txt_Visitor_SSNO
        '
        Me.Txt_Visitor_SSNO.BackColor = System.Drawing.Color.White
        Me.Txt_Visitor_SSNO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_SSNO.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_SSNO.Location = New System.Drawing.Point(307, 3)
        Me.Txt_Visitor_SSNO.MaxLength = 50
        Me.Txt_Visitor_SSNO.Name = "Txt_Visitor_SSNO"
        Me.Txt_Visitor_SSNO.ReadOnly = True
        Me.Txt_Visitor_SSNO.Size = New System.Drawing.Size(146, 21)
        Me.Txt_Visitor_SSNO.TabIndex = 2
        Me.Txt_Visitor_SSNO.TabStop = False
        Me.Txt_Visitor_SSNO.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.BackColor = System.Drawing.Color.Transparent
        Me.Label35.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label35.Location = New System.Drawing.Point(236, 5)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(67, 14)
        Me.Label35.TabIndex = 100042
        Me.Label35.Text = "Soc Sec No"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label5.Location = New System.Drawing.Point(13, 166)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(63, 14)
        Me.Label5.TabIndex = 100041
        Me.Label5.Text = "Nationality"
        '
        'Txt_Visitor_Age
        '
        Me.Txt_Visitor_Age.BackColor = System.Drawing.Color.White
        Me.Txt_Visitor_Age.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Age.Cursor = System.Windows.Forms.Cursors.Default
        Me.Txt_Visitor_Age.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Age.Location = New System.Drawing.Point(307, 115)
        Me.Txt_Visitor_Age.MaxLength = 3
        Me.Txt_Visitor_Age.Name = "Txt_Visitor_Age"
        Me.Txt_Visitor_Age.ReadOnly = True
        Me.Txt_Visitor_Age.Size = New System.Drawing.Size(64, 21)
        Me.Txt_Visitor_Age.TabIndex = 7
        Me.Txt_Visitor_Age.TabStop = False
        Me.Txt_Visitor_Age.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label15.Location = New System.Drawing.Point(279, 117)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(29, 14)
        Me.Label15.TabIndex = 100040
        Me.Label15.Text = "Age"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label13.Location = New System.Drawing.Point(13, 118)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(48, 14)
        Me.Label13.TabIndex = 100039
        Me.Label13.Text = "Gender"
        '
        'Txt_Visitor_Mobile
        '
        Me.Txt_Visitor_Mobile.BackColor = System.Drawing.Color.White
        Me.Txt_Visitor_Mobile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Mobile.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Mobile.Location = New System.Drawing.Point(307, 140)
        Me.Txt_Visitor_Mobile.MaxLength = 10
        Me.Txt_Visitor_Mobile.Name = "Txt_Visitor_Mobile"
        Me.Txt_Visitor_Mobile.ReadOnly = True
        Me.Txt_Visitor_Mobile.Size = New System.Drawing.Size(146, 21)
        Me.Txt_Visitor_Mobile.TabIndex = 9
        Me.Txt_Visitor_Mobile.TabStop = False
        Me.Txt_Visitor_Mobile.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label11.Location = New System.Drawing.Point(264, 142)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(44, 14)
        Me.Label11.TabIndex = 100038
        Me.Label11.Text = "Mobile"
        '
        'Txt_Visitor_Phone
        '
        Me.Txt_Visitor_Phone.BackColor = System.Drawing.Color.White
        Me.Txt_Visitor_Phone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Phone.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Phone.Location = New System.Drawing.Point(95, 140)
        Me.Txt_Visitor_Phone.MaxLength = 11
        Me.Txt_Visitor_Phone.Name = "Txt_Visitor_Phone"
        Me.Txt_Visitor_Phone.ReadOnly = True
        Me.Txt_Visitor_Phone.Size = New System.Drawing.Size(138, 21)
        Me.Txt_Visitor_Phone.TabIndex = 8
        Me.Txt_Visitor_Phone.TabStop = False
        Me.Txt_Visitor_Phone.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label8.Location = New System.Drawing.Point(13, 143)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(42, 14)
        Me.Label8.TabIndex = 100037
        Me.Label8.Text = "Phone"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label4.Location = New System.Drawing.Point(13, 56)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(55, 14)
        Me.Label4.TabIndex = 100036
        Me.Label4.Text = "Address"
        '
        'Txt_Visitor_Addr
        '
        Me.Txt_Visitor_Addr.BackColor = System.Drawing.Color.White
        Me.Txt_Visitor_Addr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Addr.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Addr.Location = New System.Drawing.Point(95, 54)
        Me.Txt_Visitor_Addr.MaxLength = 500
        Me.Txt_Visitor_Addr.Multiline = True
        Me.Txt_Visitor_Addr.Name = "Txt_Visitor_Addr"
        Me.Txt_Visitor_Addr.ReadOnly = True
        Me.Txt_Visitor_Addr.Size = New System.Drawing.Size(358, 33)
        Me.Txt_Visitor_Addr.TabIndex = 4
        Me.Txt_Visitor_Addr.TabStop = False
        '
        'Txt_Visitor_Name
        '
        Me.Txt_Visitor_Name.BackColor = System.Drawing.Color.LightSteelBlue
        Me.Txt_Visitor_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Name.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.Txt_Visitor_Name.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Name.Location = New System.Drawing.Point(95, 28)
        Me.Txt_Visitor_Name.MaxLength = 250
        Me.Txt_Visitor_Name.Name = "Txt_Visitor_Name"
        Me.Txt_Visitor_Name.ReadOnly = True
        Me.Txt_Visitor_Name.Size = New System.Drawing.Size(358, 22)
        Me.Txt_Visitor_Name.TabIndex = 3
        Me.Txt_Visitor_Name.TabStop = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label7.Location = New System.Drawing.Point(13, 30)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(79, 14)
        Me.Label7.TabIndex = 100035
        Me.Label7.Text = "Patient Name"
        '
        'Btn_PMRIDF2
        '
        Me.Btn_PMRIDF2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_PMRIDF2.BackgroundImage = CType(resources.GetObject("Btn_PMRIDF2.BackgroundImage"), System.Drawing.Image)
        Me.Btn_PMRIDF2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_PMRIDF2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_PMRIDF2.ForeColor = System.Drawing.Color.White
        Me.Btn_PMRIDF2.Location = New System.Drawing.Point(227, 37)
        Me.Btn_PMRIDF2.Name = "Btn_PMRIDF2"
        Me.Btn_PMRIDF2.Size = New System.Drawing.Size(29, 21)
        Me.Btn_PMRIDF2.TabIndex = 4
        Me.Btn_PMRIDF2.TabStop = False
        Me.Btn_PMRIDF2.Text = "F2"
        Me.Btn_PMRIDF2.UseVisualStyleBackColor = False
        '
        'FollowupVisitReg_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.LeftGradiant
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(724, 483)
        Me.Controls.Add(Me.Pnl_2)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.Pnl_3)
        Me.Controls.Add(Me.Pnl_1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "FollowupVisitReg_Frm"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Pnl_Doctors.ResumeLayout(False)
        Me.Pnl_Doctors.PerformLayout()
        Me.TlStrp_Doctors.ResumeLayout(False)
        Me.TlStrp_Doctors.PerformLayout()
        Me.Pnl_1.ResumeLayout(False)
        Me.Pnl_1.PerformLayout()
        Me.Pnl_3.ResumeLayout(False)
        Me.Pnl_3.PerformLayout()
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.Pnl_2.ResumeLayout(False)
        Me.Pnl_2.PerformLayout()
        Me.Pnl_Apoint.ResumeLayout(False)
        Me.Pnl_Apoint.PerformLayout()
        Me.Pnl_Othersdetails.ResumeLayout(False)
        Me.Pnl_Othersdetails.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Heading As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Cmb_Service As System.Windows.Forms.ComboBox
    Friend WithEvents Pnl_Doctors As System.Windows.Forms.Panel
    Friend WithEvents TlStrp_Doctors As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripButton1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Doctordetails As System.Windows.Forms.Label
    Friend WithEvents Pnl_1 As System.Windows.Forms.Panel
    Friend WithEvents Txt_PMRID As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Txt_OPID As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Btn_Find As System.Windows.Forms.Button
    Friend WithEvents Pnl_3 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Currentstatus As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Billingmethod As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Patienttype As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Nof_Visits As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Lbl_OPValidDays As System.Windows.Forms.Label
    Friend WithEvents Lbl_OPValidity As System.Windows.Forms.Label
    Friend WithEvents Btn_NewOP As System.Windows.Forms.Button
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Pnl_2 As System.Windows.Forms.Panel
    Friend WithEvents Pnl_Apoint As System.Windows.Forms.Panel
    Friend WithEvents Txt_ApointID As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Btn_AppIDF2 As System.Windows.Forms.Button
    Friend WithEvents Btn_Appointment As System.Windows.Forms.Button
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Mesageaproxtime As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Lbl_MesageTokenno As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Othersdetails As System.Windows.Forms.Panel
    Friend WithEvents Txt_Nationality As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Gender As System.Windows.Forms.TextBox
    Friend WithEvents Txt_PatientID As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_Familyname As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_SSNO As System.Windows.Forms.TextBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_Age As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_Mobile As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_Phone As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_Addr As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Visitor_Name As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Txt_Remarks As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Btn_PMRIDF2 As System.Windows.Forms.Button
End Class
