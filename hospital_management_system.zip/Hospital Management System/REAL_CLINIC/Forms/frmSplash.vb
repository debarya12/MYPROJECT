﻿Imports System.Data.SqlClient
Public Class frmSplash

    Private Sub Timer1_Tick(sender As System.Object, e As System.EventArgs) Handles Timer1.Tick
        Try
                ProgressBar1.Visible = True
                ProgressBar1.Value = ProgressBar1.Value + 2
                If (ProgressBar1.Value = 10) Then
                    Label1.Text = "Reading modules.."
                ElseIf (ProgressBar1.Value = 20) Then
                    Label1.Text = "Turning on modules."
                ElseIf (ProgressBar1.Value = 40) Then
                    Label1.Text = "Starting modules.."
                ElseIf (ProgressBar1.Value = 60) Then
                    Label1.Text = "Loading modules.."
                ElseIf (ProgressBar1.Value = 80) Then
                    Label1.Text = "Done Loading modules.."
                ElseIf (ProgressBar1.Value = 100) Then
                LoginForm.Show()
                    Timer1.Enabled = False
                    Me.Hide()
                End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "Error!")
        End Try
    End Sub

End Class