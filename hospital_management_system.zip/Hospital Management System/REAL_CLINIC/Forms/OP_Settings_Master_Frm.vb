﻿Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls
Public Class OP_Settings_Master_Frm

#Region "Declarations"
    'Object of Patient Details Bussiness Layer
    ' Private Doctor_BL As OutPatient_BL_Cls

    Private hms_helper As HMS_Helper = Nothing
    Private OP_Settings_Mas_BL As OP_Settings_Master_BL_Cls
    Private Com_BL As HMS_Common_BL_Cls

    Private mReq_Ctrl As Object = Nothing
    Private mTr_Mode As Long
    Private Form_Closing As Boolean

    Dim IntListSelect As Integer

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing

    Dim IntRow As Integer
    Dim IntSelectRow As Integer

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    'Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    'Me.TXT_Acc_ID.BackColor = Color.White
                    'Me.TXT_Acc_ID.ReadOnly = False
                Case Tran_Mode.Edit_Mode
                    'Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    'Me.TXT_Acc_ID.ReadOnly = True
                    'Me.TXT_Acc_ID.BackColor = Color.Silver
            End Select
        End Set
    End Property
#End Region

#Region "Methods"
    Private Function Validate_Fields() As Boolean
        Try
           


            If Val(Txt_ValidDays.Text) <= 0 Then MessageBox.Show("Invalid valid days  Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_ValidDays.Focus() : Exit Function
            If Val(Txt_perDayVisit.Text) <= 0 Then MessageBox.Show("Invalid per day visit , Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_perDayVisit.Focus() : Exit Function
            If Val(Txt_MaxVisit.Text) <= 0 Then MessageBox.Show("Invalid max visit , Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_MaxVisit.Focus() : Exit Function


            Return True
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function
    Private Sub ShowInGrid()
        Try
            Dim StrQry As String
            Com_BL = New HMS_Common_BL_Cls
            Dim Sr_Dtbl As DataTable = Nothing

            StrQry = "Select * from OP_Settings_Latest_VW Where Br_Code = " & Branch_Code & ""
            If Com_BL.Get_Data(StrQry, Sr_Dtbl) Then
                With Dgrd_OP_Settings
                    .DataSource = Nothing
                    .DataSource = Sr_Dtbl
                    .Refresh()
                    .Columns(0).MinimumWidth = 125
                    .Columns(1).MinimumWidth = 50
                    .Columns(2).MinimumWidth = 125
                    .Columns(3).Width = 75
                    .Columns(4).Width = 75
                    .Columns(5).Width = 75
                    .Columns(6).Width = 75
                    .Columns(7).Width = 1


                    '.Columns(3).AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells


                End With
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try
    End Sub
    Private Sub Clear_Form()
        Try

            Txt_MaxVisit.Text = ""
            Txt_perDayVisit.Text = ""
            Txt_ValidDays.Text = ""

            ListTDrs.Items.Clear()
            ListFDrs.Focus()

        Catch ex As Exception

        End Try

    End Sub
#End Region

    Private Sub OP_Settings_Master_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then Call SendKeyTab()
    End Sub

    Private Sub OP_Settings_Master_Frm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        hms_helper = New Hms_Helperimpliments
        hms_helper.Fill_Doctors_List(ListFDrs)
        Call hms_helper.Fill_GenData(Cmb_OpCategory, Gendatatype.OP_Category)
        Cmb_Renewal.SelectedIndex = 0
        Dtp_TranDate.Text = Tran_Date
        Call ShowInGrid()
    End Sub

    Private Sub ListFDrs_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListFDrs.DoubleClick
        Try

            Dim ValueMem As Integer
            Dim ValueDesc As String
            ValueDesc = ListFDrs.SelectedItem.ToString
            Dim i As Integer = 0
            For i = 0 To ListTDrs.Items.Count - 1
                If ListTDrs.Items(i).ToString = ValueDesc Then
                    MessageBox.Show(" Doctor Name already added in list", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
            Next

            'If Isexistsinlist(ListTDrs, ValueDesc) Then
            '    MessageBox.Show(" Doctor Name already added in list", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            '    Exit Sub
            'Else

            ValueMem = Getlist_Item_Value(ListFDrs, ListFDrs.SelectedIndex)
            Call Addlist_Item_Value(ListTDrs, ValueDesc, ValueMem)


        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click

        Try
            If Validate_Fields() Then
                OP_Settings_Mas_BL = New OP_Settings_Master_BL_Cls
                Dim i As Integer
                'Dim Item As Object
                Dim Dtbl As DataTable = Nothing
                For i = 0 To ListTDrs.Items.Count - 1
                    ListTDrs.SelectedIndex = i
                    With OP_Settings_Mas_BL
                        .OP_Category = Cmb_OpCategory.SelectedValue
                        .OP_MaxVisitNo = Val(Txt_MaxVisit.Text)
                        .OP_Renewal = Strings.Left(Cmb_Renewal.Text, 1)
                        .OP_PerdayMaxVisitNo = Val(Txt_perDayVisit.Text)
                        .OP_Validitydays = Val(Txt_ValidDays.Text)
                        .Reg_Date = Tran_Date
                        'ListTDrs.
                        '.Doc_ID = Getlist_Item_Value(ListTDrs, ListTDrs.Items.Item(i))
                        .Doc_ID = Getlist_Item_Value(ListTDrs, ListTDrs.SelectedIndex)
                        Dtbl = Nothing
                        OP_Settings_Mas_BL.Delete_OP_Settings_Master(.Doc_ID, Tran_Date)
                        If Not .Save_OP_Master_Settings(Dtbl, Tran_Mode.New_Mode, 0) Then
                            MessageBox.Show("OP Settings Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                        End If
                    End With
                Next
                MessageBox.Show("OP Settings Completed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Call ShowInGrid()
                Btn_Clear.Focus()

            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub ListTDrs_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListTDrs.Click
        IntListSelect = ListTDrs.SelectedIndex
    End Sub

    Private Sub Btn_RemoveAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try
            ListTDrs.Items.Clear()
        Catch ex As Exception

        End Try
    End Sub
    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub
    Private Sub Txt_MaxVisit_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_MaxVisit.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_MaxVisit.Text, Data_Type.Integer_Type, 12))
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_ValidDays_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_ValidDays.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_ValidDays.Text, Data_Type.Integer_Type, 12))
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_perDayVisit_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_perDayVisit.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_perDayVisit.Text, Data_Type.Integer_Type, 12))
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Call Clear_Form()
    End Sub

    
    Private Sub Forward_Select_Pic_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Forward_Select_Pic.Click
        Try

            Dim ValueMem As Integer
            Dim ValueDesc As String
            ValueDesc = ListFDrs.SelectedItem.ToString
            Dim i As Integer = 0
            For i = 0 To ListTDrs.Items.Count - 1
                If ListTDrs.Items(i).ToString = ValueDesc Then
                    MessageBox.Show(" Doctor Name already added in list", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
            Next

            ValueMem = Getlist_Item_Value(ListFDrs, ListFDrs.SelectedIndex)
            Call Addlist_Item_Value(ListTDrs, ValueDesc, ValueMem)

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Backward_Select_Pic_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Backward_Select_Pic.Click
        Try
            ListTDrs.Items.RemoveAt(IntListSelect)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Forward_Select_All_Pic_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Forward_Select_All_Pic.Click
        Try
            Dim ValueMem As Integer
            Dim ValueDesc As String

            Dim i As Integer = 0
            Dim X As Integer = 0
            For i = 0 To ListFDrs.Items.Count - 1
                ListFDrs.SelectedIndex = i
                ValueDesc = ListFDrs.SelectedItem.ToString
                For X = 0 To ListTDrs.Items.Count - 1
                    ListTDrs.SelectedIndex = X
                    If ListTDrs.Items(X).ToString = ValueDesc Then
                        MessageBox.Show(" Doctor Name already added in list", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If
                Next
                ValueMem = Getlist_Item_Value(ListFDrs, ListFDrs.SelectedIndex)
                Call Addlist_Item_Value(ListTDrs, ValueDesc, ValueMem)
            Next

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

   
    Private Sub Backward_Select_ALL_Pic_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Backward_Select_ALL_Pic.Click
        Try
            ListTDrs.Items.Clear()

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Pnl_Header_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Pnl_Header.Paint

    End Sub
End Class