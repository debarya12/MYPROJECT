﻿
Imports HMS_Common.Common_Cls

Module Common_Mdl

    Declare Function SetParent Lib "user32" (ByVal hWndChild As Integer, ByVal hWndNewParent As Integer) As Integer


#Region "D e c l a r a t i o n s"

    Private Point_Frm As Point

    Private WriteOnly Property Navigator_CommandText() As String
        Set(ByVal value As String)
            If value = "" Then HMS_MDIMain_Frm.Txt_Menucommand.Text = ""
        End Set
    End Property

#End Region

#Region "P r o c e d u r e s"

    Public Sub ShowSearchengine(ByRef Req_Ctrl As Object, _
                                ByVal Req_Qry As String, _
                                ByVal Req_Fieldno As Short, _
                                ByVal Def_Filterfield As String, _
                                Optional ByVal Req_Colwidth As String = "", _
                                Optional ByVal Req_Orderbyfield As String = "", _
                                Optional ByVal Def_Rowsdiplayed As Short = 0 _
                                )
        Try
            With Searchengine_Frm
                .Clear_Values()
                .Req_Ctrl = Req_Ctrl
                .Req_Qry = Req_Qry
                .Req_Fieldno = Req_Fieldno
                .Def_Filterfield = Def_Filterfield
                .Req_Colwidth = Req_Colwidth
                .Req_Orderbyfield = Req_Orderbyfield
                .Def_Rowsdiplayed = Def_Rowsdiplayed
                .Search()

                .ShowDialog()
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Sub ShowImageviewer(ByRef Reqform As Form, _
                               ByVal Cust_ID As String, _
                               ByVal Cust_Type As Customer_Type)
        Try
            With ImageViewer_Frm
                Point_Frm.X = Reqform.Location.X + Reqform.Width + 201
                Point_Frm.Y = Reqform.Location.Y + 125
                .Location = Point_Frm
                .CUST_TYPE = Cust_Type
                .CUST_ID = Cust_ID

            End With
            For Each Form In ImageViewer_Frm.OwnedForms
                Form.RemoveOwnedForm(ImageViewer_Frm)
            Next
            Reqform.AddOwnedForm(ImageViewer_Frm)
            ImageViewer_Frm.Show()
            Call Set_Parentform(Reqform.MdiParent, ImageViewer_Frm)

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Sub KeepRightofme(ByRef Mainform As Form, _
                             ByRef Childform As Form)
        Try
            If Not Mainform.Visible Then
                Childform.Visible = False
            End If
            If Childform.Visible Then
                Point_Frm.X = Mainform.Location.X + Mainform.Width + 201
                Point_Frm.Y = Mainform.Location.Y + 125
                Childform.Location = Point_Frm
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Sub Show_ChildForm(ByVal Showform As String, ByRef Masterform As Form, ByVal Menuid As Int32, Optional ByVal TvwSelect As Boolean = False)
        Try

            If Showform.Trim = "" Then Exit Sub

            Dim objForm As Form
            Dim FullTypeName As String
            Dim FormInstanceType As Type
            ' Assume that form classes' namespace is the same as ProductName
            FullTypeName = "REAL_CLINIC" & "." & Showform.Trim
            ' Now, get the actual type
            FormInstanceType = Type.GetType(FullTypeName, True, True)
            ' Create an instance of this form type
            objForm = CType(Activator.CreateInstance(FormInstanceType), Form)


            AddHandler objForm.Load, AddressOf HMS_MDIMain_Frm.Childfrm_Load

            'If Already open or Shown then Bring to Front
            For Each ChildForm As Form In Masterform.MdiChildren
                If ChildForm.Name = objForm.Name Then
                    ChildForm.BringToFront()
                    Exit Sub
                End If
            Next

            ' Show the form instance
            objForm.MdiParent = Masterform

            objForm.Tag = Menuid
            objForm.Show()
            objForm.BringToFront()
            objForm.Focus()

            'If TvwSelect Then
            '    Call SendKeyTab()
            '    Call SendKeyTab()
            'End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Public Sub Clear_Openedfromsmenus(ByRef Menuctrl As ToolStrip)
        Try
            With Menuctrl
                .Items.Clear()
            End With
        Catch ex As Exception

        End Try
    End Sub

    Public Sub Select_TreeviewMenuoption(ByRef MenuCtrl As TreeView, ByRef Masterform As Form)
        Try
            Dim MenuID As String = ""
            Dim _iMenuid As Int32 = 0
            Dim MenuFormname As String = ""
            With MenuCtrl
                Try


                    MenuID = .SelectedNode.Name
                    MenuFormname = .SelectedNode.Tag
                    If MenuFormname Is Nothing Then MenuFormname = ""
                    If MenuFormname.Trim = "" Then Exit Sub

                    MenuFormname = IIf(Strings.Left(MenuFormname, 1) = "\", Strings.Right(MenuFormname, Len(MenuFormname) - 1), MenuFormname)

                Catch ex As Exception

                End Try

                If MenuID <> "" Then
                    If Strings.Left(MenuID, 1) = "G" Then
                        MenuID = "G"
                    ElseIf Strings.Left(MenuID, 1) = "M" Then
                        MenuID = Strings.Right(MenuID, Len(MenuID) - 1)
                    End If
                Else
                    MenuID = "G"
                End If

                If MenuID = "G" Then Exit Sub

                _iMenuid = MenuID
                If Not Check_Userright(_iMenuid, Access_Type.View) Then
                    Masterform.Focus()
                    Return
                End If
                Call Show_ChildForm(MenuFormname, Masterform, _iMenuid)


            End With
        Catch ex As Exception

        End Try
    End Sub

    Public Sub Show_menuoption(ByVal Menu_ID As String, ByVal Menuformname As String, ByRef Masterform As Form)
        Try
            If Menu_ID = "" Then Exit Sub
            If Menuformname = "" Then Exit Sub

            If Not Check_Userright(Menu_ID, Access_Type.View) Then
                Masterform.Focus()
                Return
            End If
            Call Show_ChildForm(Menuformname, Masterform, CInt(Menu_ID))

        Catch ex As Exception

        End Try
    End Sub

    Public Sub Select_Navigatormenuoption(ByRef MenuCtrl As DataGridView, ByRef Masterform As Form)
        Dim MenuID As Int32 = 0
        Dim MenuFormname As String = ""

        Try


            With MenuCtrl
                If .Rows.Count = 0 Then Exit Sub
                If .CurrentRow Is Nothing Then Exit Sub
                MenuFormname = .Item(2, .CurrentCell.RowIndex).Value.ToString.Trim
                MenuID = .Item(1, .CurrentCell.RowIndex).Value
            End With

            If Not Check_Userright(MenuID, Access_Type.View) Then
                Masterform.Focus()
                Return
            End If

            Call Show_ChildForm(MenuFormname, Masterform, MenuID)
            Navigator_CommandText = ""
            MenuCtrl.DataSource = Nothing
            Navigator_Frm.Hide()
        Catch ex As Exception

        Finally

        End Try



    End Sub

    Public Sub Fill_Menuoptions(ByRef MenuCtrl As TreeView, Optional ByRef Parentmenu As ToolStripMenuItem = Nothing)
        Try
            Dim Dtbl As DataTable = Nothing
            Dim Dr As DataTableReader = Nothing
            Dim tvRoot As TreeNode
            Dim tvNode As TreeNode
            Dim Childmenu As ToolStripMenuItem = Nothing
            Dim Groupmenu As ToolStripMenuItem = Nothing
            Dim menu_Bl As New HMS_BL.Menumaster_BL_Cls

            If menu_Bl.Get_Reportoptions(Dtbl) Then

                Dr = Dtbl.CreateDataReader

                With MenuCtrl
                    While Dr.Read
                        For i = 0 To .Nodes(0).Nodes.Count - 1
                            If .Nodes(0).Nodes(i).Name = "G" & Dr.Item("Menu_GrpID").ToString Then
                                tvRoot = .Nodes(0).Nodes(i)
                                tvNode = tvRoot.Nodes.Add(Dr.Item("Menu_ID"), Dr.Item("Menu_Name"))
                                tvNode.ForeColor = System.Drawing.Color.DarkBlue
                                tvNode.Name = "M" & Dr.Item("Menu_ID").ToString
                                tvNode.Tag = Dr.Item("Menu_Formname").ToString

                                tvNode.NodeFont = New System.Drawing.Font("Tahoma", 8, System.Drawing.FontStyle.Regular)
                                '.Nodes(0).Nodes(i).Expand()
                                Exit For
                            End If
                        Next

                        If Not Parentmenu Is Nothing Then
                            For i = 0 To Parentmenu.DropDownItems.Count - 1
                                If Parentmenu.DropDownItems(i).Name = Dr.Item("Menu_GrpID").ToString Then
                                    Groupmenu = Parentmenu.DropDownItems(i)
                                    Childmenu = New ToolStripMenuItem
                                    With Childmenu
                                        .Name = Dr.Item("Menu_ID").ToString
                                        .Text = Dr.Item("Menu_Name").ToString
                                        .Tag = Dr.Item("Menu_Formname").ToString
                                        If Dr.Item("Menu_Shortcutkey").ToString.Trim <> "" Then
                                            .ShowShortcutKeys = True
                                            .ShortcutKeys = CDbl(Dr.Item("Menu_Shortcutkey").ToString)
                                            '.ShortcutKeys = System.Windows.Forms.Shortcut.CtrlF5
                                            '.ShortcutKeys = System.Windows.Forms.Shortcut.CtrlF5
                                        End If
                                    End With
                                    Groupmenu.DropDownItems.Add(Childmenu)
                                    AddHandler Childmenu.Click, AddressOf HMS_MDIMain_Frm.HMS_Menuoptons_Click
                                    Exit For
                                End If
                            Next
                        End If
                    End While
                End With

            End If


        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

#End Region

#Region "M e t h o d s"

    Public Function Get_Formobjectusingstring(ByVal Formname As String) As Form
        Try
            Dim objForm As Form
            Dim FullTypeName As String
            Dim FormInstanceType As Type
            ' Assume that form classes' namespace is the same as ProductName
            FullTypeName = "REAL_CLINIC" & "." & Formname.Trim
            ' Now, get the actual type
            FormInstanceType = Type.GetType(FullTypeName, True, True)
            ' Create an instance of this form type
            objForm = CType(Activator.CreateInstance(FormInstanceType), Form)
            Return objForm

        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Function Set_Openedformsmenus(ByRef Menuctrl As ToolStrip, ByVal Formname As String) As Boolean
        Try
            Dim btnSomething As New ToolStripButton
            btnSomething.Text = Formname
            'btnSomething.ToolTipText = "This is Just a Test"
            With Menuctrl
                .Items.Add(btnSomething)
            End With
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function Get_Navigatorformlocation(ByRef Txtbox As TextBox) As Point
        Try
            Dim newpoint As Point = Nothing
            Dim Ctrl_point As Point = Nothing

            Dim Txt_ParentCtrl As Object = Txtbox.Parent

            Ctrl_point = Txt_ParentCtrl.PointToScreen(Txtbox.Location)

            newpoint = New Point(Ctrl_point.X - 13, Ctrl_point.Y - Navigator_Frm.Height - 1)

            Return newpoint


        Catch ex As Exception

        End Try
    End Function

    Public Function AddNewGendata(ByRef Btnnew As Button) As Boolean
        Try

            '---------------------------------------------------------------------------------------------

            Dim cname As String = ""
            Dim Fill_ID As String = ""
            Dim newpoint As Point = Nothing
            Dim Ctrl_point As Point = Nothing
            Dim ctr As Object
            Dim Btnnew_ParentCtrl As Object

            Dim i_Start As Int16 = InStr(Btnnew.Tag, "|", CompareMethod.Text)

            '---------------------------------------------------------------------------------------------

            cname = Mid(Btnnew.Tag, 1, i_Start - 1)
            Fill_ID = Mid(Btnnew.Tag, i_Start + 1, Len(Btnnew.Tag))

            Btnnew_ParentCtrl = Btnnew.Parent

            ctr = DirectCast(Btnnew_ParentCtrl.Controls(cname), ComboBox)

            Ctrl_point = Btnnew_ParentCtrl.PointToScreen(ctr.Location)

            '---------------------------------------------------------------------------------------------

            With Generaldatasave_Frm
                'Creating New Point for the Save Form
                newpoint = New Point(Ctrl_point.X - 1, Ctrl_point.Y - Generaldatasave_Frm.Height - 1)
                'Positioning the Save Form near to Respective Controls
                .Point_Frm = newpoint
                .Data_CatID = Fill_ID
                .Req_Ctrl = ctr
                .ShowDialog()
            End With

            '---------------------------------------------------------------------------------------------

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function

    Public Function Get_Newgendatabuttonposition(ByRef ReqCtrl As Object) As Point
        Try
            Dim Ctrl_point As Point
            With Ctrl_point

                .X = ReqCtrl.Location.X + ReqCtrl.Width + 1
                .Y = ReqCtrl.Location.Y

            End With
            Return Ctrl_point

        Catch ex As Exception
            Return Nothing
        End Try
    End Function

    Public Function Validate_Transactionright(ByVal Tranmode As Tran_Mode, ByVal Form_Name As String) As Boolean
        Try
            Dim Menu_ID As Int32 = 0
            Dim Hms_helper As HMS_BL.HMS_Helper
            Hms_helper = New HMS_BL.Hms_Helperimpliments

            Menu_ID = Hms_helper.Get_MenuIDUsingFormname(Form_Name)

            If Menu_ID = 0 Then Return True

            If Tranmode = Tran_Mode.New_Mode Then
                Return Hms_helper.Check_Accessright(Access_Type.Add, Menu_ID)
            ElseIf Tranmode = Tran_Mode.Edit_Mode Then
                Return Hms_helper.Check_Accessright(Access_Type.Edit, Menu_ID)
            ElseIf Tranmode = Tran_Mode.Delete_Mode Then
                Return Hms_helper.Check_Accessright(Access_Type.Delete, Menu_ID)
            End If

            Return False

        Catch ex As Exception
            Return False
        End Try
    End Function

#End Region


#Region " U s e r  R i g h t s "

    Public Function Check_Userright(ByVal Menu_ID As Int32, ByVal Accesstype As Access_Type) As Boolean
        Try

            Dim Hms_helper As HMS_BL.HMS_Helper
            Dim msgstr As String = ""

            Hms_helper = New HMS_BL.Hms_Helperimpliments

            If Hms_helper.Check_Accessright(Accesstype, Menu_ID) Then
                Return True
            Else

                If Accesstype = Access_Type.View Then
                    msgstr = "Access Denied for this Menu,Please Contact System Administrator "
                ElseIf Accesstype = Access_Type.Add Then
                    msgstr = "Save Permission Denied for this Menu,Please Contact System Administrator"
                ElseIf Accesstype = Access_Type.Edit Then
                    msgstr = "Modify Permission Denied for this Menu,Please Contact System Administrator"
                ElseIf Accesstype = Access_Type.Delete Then
                    msgstr = "Delete Permission Denied for this Menu,Please Contact System Administrator"
                End If
                MessageBox.Show(msgstr, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Stop)
                Return False
            End If



        Catch ex As Exception

        End Try
    End Function

    Public Function Check_Userright(ByVal Menu_Name As String, ByVal Accesstype As Access_Type) As Boolean
        Try

            Dim Hms_helper As HMS_BL.HMS_Helper
            Hms_helper = New HMS_BL.Hms_Helperimpliments
            Return Hms_helper.Check_Accessright(Accesstype, Menu_Name)

        Catch ex As Exception

        End Try
    End Function

#End Region

#Region " PMR-ID V a l i d a t i o n "

    Public Function Validate_PMRID(ByRef Dtbl As DataTable, Optional ByVal Ismsgbox As Boolean = True) As Boolean
        Try
            With Dtbl

                If .Rows.Count <= 0 Then Return False

                If .Rows(0).Item("Cancelled").ToString = "Y" Then
                    If Ismsgbox Then MessageBox.Show("PMR-ID is already Cancelled,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
                If .Rows(0).Item("Active").ToString = "N" Then
                    If Ismsgbox Then MessageBox.Show("PMR-ID is not Active,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
                If .Rows(0).Item("Authorised").ToString = "N" Then
                    If Ismsgbox Then MessageBox.Show("PMR-ID is not Authorised,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
            End With

            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

#End Region

End Module
