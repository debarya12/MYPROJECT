﻿

Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls

Public Class Appointments_Frm

#Region " D e c l a r a t i o n s "
    'Object of Appointments Details Bussiness Layer

    Private Apoint_Bl As Appointment_BL_Cls
    Private hms_helper As HMS_Helper = Nothing
    Private mTr_Mode As Tran_Mode

    Dim Service_Dtbl As DataTable = Nothing
    Dim doc_Dtbl As DataTable = Nothing
    Dim Visitortype_Dtbl As DataTable = Nothing
    Dim Bookingmode_Dtbl As DataTable = Nothing
    Dim Nationality_Dtbl As DataTable = Nothing
    Dim Visittype_Dtbl As DataTable = Nothing

    Dim frm_Heading As String = ""

    Private Ctrl_Point As Point
    Private mReq_Ctrl As Object = Nothing

#End Region

#Region " E n u m s "

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
        End Set
    End Property

#End Region

#Region " P r o p e r t i e s "

    'Appointment Service Property
    Private _App_Service_ID As Integer = 0
    Private Property App_Service_ID() As Integer
        Get
            Return _App_Service_ID
        End Get
        Set(ByVal value As Integer)
            _App_Service_ID = value

            If _App_Service_ID = 0 Then Exit Property

            Call Populate_Doctorlist(_App_Service_ID)

        End Set
    End Property

    Private _Seldoctor_ID As Integer = 0
    Private Property Seldoctor_ID() As Integer
        Get
            Return _Seldoctor_ID
        End Get
        Set(ByVal value As Integer)
            _Seldoctor_ID = value
        End Set
    End Property

    Private _Seldoctor_A_interval As Integer = 0
    Private Property Seldoctor_A_interval() As Integer
        Get
            Return _Seldoctor_A_interval
        End Get
        Set(ByVal value As Integer)
            _Seldoctor_A_interval = value
        End Set
    End Property

    Private _Seldoctor_Offday As String
    Public Property Seldoctor_Offday() As String
        Get
            Return _Seldoctor_Offday
        End Get
        Set(ByVal value As String)
            _Seldoctor_Offday = value
        End Set
    End Property

    Public WriteOnly Property Req_Ctrl() As Object
        Set(ByVal Value As Object)
            mReq_Ctrl = Value
        End Set
    End Property

#End Region

#Region " M e t h o d s "

    Private Function Set_GridColumns(ByVal Startdate As Date, ByVal Nodays As Int16) As Boolean
        Try

            Dim W_Dayname As String = ""
            Dim Currdate As Date = Startdate

            With Dgrd_Appointment

                .Columns.Add("Time", "Time".ToUpper)
                .Columns("Time").CellTemplate.Style.BackColor = Color.FromArgb(75, 103, 131)
                .Columns("Time").CellTemplate.Style.ForeColor = Color.White
                .Columns("Time").Width = 70
                .Columns("Time").SortMode = DataGridViewColumnSortMode.NotSortable

                While Currdate < Startdate.AddDays(Nodays)
                    W_Dayname = Format(Currdate, "dddd").ToString
                    .Columns.Add(Format(Currdate, "dd-MM-yyyy").ToString, W_Dayname.ToUpper + vbCrLf + Format(Currdate, "dd/MM/yyyy").ToString)
                    .Columns(Format(Currdate, "dd-MM-yyyy").ToString).CellTemplate.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
                    .Columns(Format(Currdate, "dd-MM-yyyy").ToString).SortMode = DataGridViewColumnSortMode.NotSortable
                    .Columns(Format(Currdate, "dd-MM-yyyy").ToString).Width = 106
                    Currdate = Currdate.AddDays(1)
                End While

            End With

            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Set_BlankGrid(ByVal Start_Time As Date, _
                                   ByVal End_Time As Date, _
                                   ByVal A_Interval As Double) As Boolean
        Try


            With Dgrd_Appointment
                .RowCount = 0
                'End_Time = End_Time.AddMinutes(A_Interval * -1)
                While Start_Time <= End_Time
                    .Rows.Add()
                    .Rows(.Rows.Count - 1).Cells("Time").Value = Format(Start_Time, " hh : mm tt")
                    '.Rows(i).Cells(k).Style.BackColor = Color.FromArgb(138, 162, 187)
                    Start_Time = Start_Time.AddMinutes(A_Interval)

                End While

            End With
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Mark_OffTimings(ByVal Offday As String)
        Try
            Dim G_Offday As String = ""
            Select Case Offday.ToUpper
                Case "MON"
                    G_Offday = "Monday"
                Case "TUE"
                    G_Offday = "Tuesday"
                Case "WED"
                    G_Offday = "Wednesday"
                Case "THU"
                    G_Offday = "Thursday"
                Case "FRI"
                    G_Offday = "Friday"
                Case "SAT"
                    G_Offday = "Saturday"
                Case "SUN"
                    G_Offday = "Sunday"
            End Select

            With Dgrd_Appointment
                For k = 1 To .Columns.Count - 1
                    'If .Columns(k).Name = Format(Tran_Date, "dddd").ToString Then
                    '    .Columns(Format(Tran_Date, "dddd").ToString).CellTemplate.Style.BackColor = Color.LightBlue
                    'End If
                    For i = 0 To .Rows.Count - 1
                        If .Rows(i).Cells(k).Value = "" Then
                            .Rows(i).Cells(k).Style.BackColor = Color.FromArgb(138, 162, 187)
                        End If
                    Next
                Next
                .Invalidate()
                .ClearSelection()
            End With


        Catch ex As Exception

        End Try
    End Sub

    Private Sub Refresh_Apointmentchart(ByVal DocID As Integer, _
                                        ByVal ServiceID As Integer, _
                                        ByVal Demand_Datefrm As Date, _
                                        ByVal Demand_Dateto As Date)
        Try
            Apoint_Bl = New Appointment_BL_Cls
            Dim A_Dtbl As DataTable = Nothing
            Dim A_Time As Date
            Dim SelRow As DataGridViewRow = Nothing
            Dim Has_Apointment, A_ApointID, A_BatchID, A_Details As String


            If Apoint_Bl.Get_DocApointmentchartbetweendates(A_Dtbl, DocID, ServiceID, Demand_Datefrm, Demand_Dateto) Then

                With Dgrd_Appointment
                    For i = 0 To A_Dtbl.Rows.Count - 1
                        Has_Apointment = "" : A_ApointID = "" : A_BatchID = "" : A_Details = ""
                        A_Time = A_Dtbl.Rows(i).Item("Fromtime").ToString
                        SelRow = Nothing
                        SelRow = (From Rows In .Rows.Cast(Of DataGridViewRow)() _
                                    Where Rows.Cells("Time").Value.ToString() = Format(A_Time, " hh : mm tt")).FirstOrDefault
                        If Not IsNothing(SelRow) Then
                            '========================================================================================================
                            Has_Apointment = A_Dtbl.Rows(i).Item("Has_Apointment").ToString
                            A_BatchID = A_Dtbl.Rows(i).Item("A_BatchID").ToString
                            'Setting The Default Color to Active Time Cell
                            SelRow.Cells(Format(CDate(A_Dtbl.Rows(i).Item("Req_Date").ToString), "dd-MM-yyyy")).Style.BackColor = Color.White

                            If A_Dtbl.Rows(i).Item("A_Timemode").ToString = "C" Then    'Confirmed

                                If Has_Apointment = "Y" Then
                                    A_Details = A_Dtbl.Rows(i).Item("Apoint_Tokenno").ToString
                                    A_ApointID = A_Dtbl.Rows(i).Item("Apoint_ID").ToString

                                    'Change the Cell Color as Has Appointment
                                    SelRow.Cells(Format(CDate(A_Dtbl.Rows(i).Item("Req_Date").ToString), "dd-MM-yyyy")).Style.BackColor = Color.PaleVioletRed
                                    SelRow.Cells(Format(CDate(A_Dtbl.Rows(i).Item("Req_Date").ToString), "dd-MM-yyyy")).Style.ForeColor = Color.White
                                Else
                                    Has_Apointment = "N"
                                    A_ApointID = "F"
                                End If

                                If Has_Apointment = "Y" Then A_Details += vbCrLf + A_Dtbl.Rows(i).Item("Visitor_Name").ToString.ToLower
                                SelRow.Cells(Format(CDate(A_Dtbl.Rows(i).Item("Req_Date").ToString), "dd-MM-yyyy")).Value = A_Details
                                SelRow.Cells(Format(CDate(A_Dtbl.Rows(i).Item("Req_Date").ToString), "dd-MM-yyyy")).Tag = A_ApointID + "|" + A_BatchID

                            ElseIf A_Dtbl.Rows(i).Item("A_Timemode").ToString = "W" Then 'Waiting
                                A_ApointID = "W"
                                SelRow.Cells(Format(CDate(A_Dtbl.Rows(i).Item("Req_Date").ToString), "dd-MM-yyyy")).Style.BackColor = Color.FromArgb(233, 211, 223)
                                If Has_Apointment = "Y" Then
                                    A_Details = A_Dtbl.Rows(i).Item("Apoint_Tokenno").ToString
                                End If
                                A_Details += vbCrLf + "Not Confirm"
                                SelRow.Cells(Format(CDate(A_Dtbl.Rows(i).Item("Req_Date").ToString), "dd-MM-yyyy")).Value = A_Details
                                SelRow.Cells(Format(CDate(A_Dtbl.Rows(i).Item("Req_Date").ToString), "dd-MM-yyyy")).Tag = A_ApointID + "|" + A_BatchID
                            End If


                        End If

                    Next
                End With

            End If


        Catch ex As Exception

        End Try
    End Sub

    Private Function Populate_Doctorlist(ByVal ServiceID As Integer) As Boolean
        Try

            Dim btnSomething As ToolStripButton

            TlStrp_Doctors.Items.Clear()

            If hms_helper.Get_Doctorswithservices(doc_Dtbl, ServiceID, Tran_Date, Branch_Code) Then

                For i = 0 To doc_Dtbl.Rows.Count - 1
                    btnSomething = New ToolStripButton
                    With btnSomething
                        .Text = doc_Dtbl.Rows(i).Item("Name").ToString

                        .Tag = doc_Dtbl.Rows(i).Item("DoctorID").ToString
                        .Image = My.Resources.Health_care_shield_32
                        .ImageAlign = ContentAlignment.TopCenter
                        .ImageScaling = ToolStripItemImageScaling.None
                        .ForeColor = Color.Maroon
                        .DisplayStyle = ToolStripItemDisplayStyle.ImageAndText
                        .TextImageRelation = TextImageRelation.ImageAboveText
                    End With
                    TlStrp_Doctors.Items.Add(btnSomething)
                Next

            End If
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Show_DocAppointmentchart(ByVal selDocID As String)
        Try
            Dim Start_Time, End_Time As Date
            Dim A_Interval As Double = 0
            Dim Offday As String = ""
            Dim Timings_Dtbl As DataTable = Nothing

            If Not hms_helper.Get_DoctorsDutytimings(Timings_Dtbl, selDocID, Tran_Date) Then
                MessageBox.Show("Selected Doctors Duty Timings not available,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return
            End If

            'Assign Paramater Values
            Start_Time = Timings_Dtbl.Rows(0).Item("D_DutyStarttime").ToString
            End_Time = Timings_Dtbl.Rows(0).Item("D_DutyEndtime").ToString

            A_Interval = Timings_Dtbl.Rows(0).Item("D_Appointmentinterval").ToString
            Seldoctor_A_interval = A_Interval

            Seldoctor_Offday = Offday

            If Set_BlankGrid(Start_Time, End_Time, A_Interval) Then
                'If Set_ApGrid(Timings_Dtbl, selDocID, Me.App_Service_ID) Then
                '    Call Mark_OffTimings(Offday)
                'End If
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Clear_Grid(ByVal Isdata As Boolean)
        Try
            With Dgrd_Appointment
                If Not Isdata Then
                    .RowCount = 0
                Else

                End If

            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Show_Registrationform(ByVal Isbysel As Boolean, _
                                      ByVal SelTime As String, _
                                      ByVal Seldate As Date, _
                                      Optional ByVal ApointID As String = "")

        Try
            Dim BatchID As String = ""
            With Appointment_Reg_Frm
                .Clear_Form()

                .Populate_Appoinmentstatus()
                .Populate_Visitortype(Visitortype_Dtbl)
                .Populate_Visittype(Visittype_Dtbl)
                .Populate_Bookingtype()
                .Populate_Bookingmode(Bookingmode_Dtbl)
                .Populate_Nationality(Nationality_Dtbl)
                .Populate_Gender()

                'Populate Service Details
                .Populate_Service(Service_Dtbl)
                If .Cmb_Service.Items.Count > 0 Then .Cmb_Service.SelectedValue = Me.App_Service_ID

                .App_Service_ID = Me.App_Service_ID
                .App_Doctor_ID = Me.Seldoctor_ID
                .Dtp_Apointdate.Value = Seldate

                .Seldoctor_A_interval = Seldoctor_A_interval
                .Seldoctor_Offday = Seldoctor_Offday
                .Select_ApointDoctor(Me.Seldoctor_ID)


                If Isbysel = True Then
                    BatchID = Mid(ApointID, InStr(ApointID, "|") + 1)
                    ApointID = Mid(ApointID, 1, InStr(ApointID, "|") - 1)

                    If ApointID = "F" Or ApointID = "W" Then
                        If ApointID <> "W" Then
                            .Cmb_Bookingtype.SelectedIndex = 1
                            If .Cmb_Timefrom.FindStringExact(SelTime) >= 0 Then
                                .Cmb_Timefrom.Text = SelTime
                            End If
                            Dim totime As Date = CDate(SelTime).AddMinutes(Seldoctor_A_interval)

                            If .Cmb_Timeto.FindStringExact(Format(totime, " hh : mm tt")) >= 0 Then
                                .Cmb_Timeto.Text = Format(totime, " hh : mm tt")
                            End If
                        Else
                            .Cmb_Bookingtype.SelectedIndex = -1
                            .Cmb_Bookingtype.SelectedIndex = 0
                            If .Cmb_Timefrom.Items.Count > 0 Then
                                .Cmb_Timefrom.Text = .Cmb_Timefrom.Items(0).ToString
                                .Cmb_Timeto.Text = .Cmb_Timeto.Items(0).ToString
                            End If
                        End If
                    Else
                        .Txt_ApointID.Text = ApointID
                        Call .Btn_Find_Click(Nothing, Nothing)
                    End If
                Else

                    .Cmb_Bookingtype.SelectedIndex = 0
                    If .Cmb_Timefrom.Items.Count > 0 Then
                        .Cmb_Timefrom.Text = .Cmb_Timefrom.Items(0).ToString
                        .Cmb_Timeto.Text = .Cmb_Timeto.Items(0).ToString
                    End If

                End If


                'Dim wdth As Int64 = 0
                'For i = 0 To Me.Dgrd_Appointment.ColumnCount - 1
                '    wdth += Me.Dgrd_Appointment.Columns(i).Width
                'Next

                '.Top = Me.Dgrd_Appointment.Top + 52
                '.Left = (Me.Left + wdth) - 518

                Me.Timer1.Enabled = False
                .ShowDialog(Me.MdiParent)
                Me.Timer1.Enabled = True
                Call Timer1_Tick(Nothing, Nothing)


            End With

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Populate_Days()
        Try
            With Cmb_Days
                .Items.Add("1")
                .Items.Add("7")
                .Items.Add("14")
                .Items.Add("28")
                .SelectedIndex = 1
            End With
        Catch ex As Exception

        End Try
    End Sub

#End Region

    Private Sub Appointments_Frm_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Try
            Appointment_Reg_Frm.Dispose()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Appointments_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Try
            If e.KeyCode = Keys.F10 Then Call Btn_Register_Click(Nothing, Nothing)


        Catch ex As Exception

        End Try
    End Sub

    Private Sub Appointments_Frm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            Me.Height = Me.ParentForm.Height - 155
            Me.Width = Me.ParentForm.Width - 198

            hms_helper = New Hms_Helperimpliments

            Me.Left = 0
            Me.Top = 0
            frm_Heading = Lbl_Heading.Text


            If hms_helper.Get_ApointmentServices(Service_Dtbl, Branch_Code) Then
                Call Fill_Combo(Cmb_Service, Service_Dtbl, "Service Name", "Service_ID")
            End If

            If Cmb_Service.Items.Count > 0 Then
                Cmb_Service.SelectedIndex = -1
                Cmb_Service.SelectedIndex = 0
            End If

            Call Populate_Days()

            Dtp_Admitdate.Value = Tran_Date

            Call Set_GridColumns(Tran_Date, Val(Cmb_Days.Text))

            Call hms_helper.Get_Gendata(Visitortype_Dtbl, Gendatatype.Visitor_Type)
            Call hms_helper.Get_Gendata(Visittype_Dtbl, Gendatatype.Visit_Type)
            Call hms_helper.Get_Gendata(Bookingmode_Dtbl, Gendatatype.Booking_Mode)
            Call hms_helper.Get_Gendata(Nationality_Dtbl, Gendatatype.Country)

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

    Private Sub Cmb_Service_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_Service.SelectedIndexChanged
        Try
            Me.App_Service_ID = 0
            Me.App_Service_ID = Cmb_Service.SelectedValue

        Catch ex As Exception

        End Try
    End Sub

    Private Sub TlStrp_Doctors_ItemClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles TlStrp_Doctors.ItemClicked
        Try

            Dim btn_Doctor As ToolStripButton
            btn_Doctor = New ToolStripButton

            For Each btn_Doctor In TlStrp_Doctors.Items
                btn_Doctor.BackColor = Color.White
                btn_Doctor.ForeColor = Color.DarkBlue
            Next

            btn_Doctor = e.ClickedItem

            e.ClickedItem.BackColor = Color.FromArgb(60, 113, 193)
            e.ClickedItem.ForeColor = Color.White

            Lbl_Heading.Text = frm_Heading + "  of  " + e.ClickedItem.Text.ToUpper

            Call Clear_Grid(False)
            Seldoctor_ID = 0

            With btn_Doctor
                Timer1.Enabled = False
                Call Show_DocAppointmentchart(.Tag)
                Seldoctor_ID = .Tag
                Timer1.Enabled = True
                Call Timer1_Tick(Nothing, Nothing)
            End With

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgrd_Appointment_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgrd_Appointment.CellClick
        Try

            With Dgrd_Appointment
                If e.RowIndex = -1 Then Exit Sub
                If e.ColumnIndex = 0 Then Exit Sub
                If .Rows(e.RowIndex).Cells(e.ColumnIndex).Tag = "" Then
                    Return
                End If


                Dim Seldate As Date
                Dim seltime As String
                Dim ApointID As String = ""

                ApointID = .Rows(e.RowIndex).Cells(e.ColumnIndex).Tag
                Seldate = CDate(.Columns(e.ColumnIndex).Name)
                seltime = .Rows(e.RowIndex).Cells("Time").Value.ToString
                Call Show_Registrationform(True, seltime, Seldate, ApointID)

            End With

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgrd_Appointment_CellEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgrd_Appointment.CellEnter
        Try
            With Dgrd_Appointment
                If e.RowIndex = -1 Then Exit Sub
                If e.ColumnIndex = 0 Then Exit Sub
                If .Rows(e.RowIndex).Cells(e.ColumnIndex).Tag = "" Then
                    If Strings.Left(Format((.Columns(e.ColumnIndex).Name), "dddd").ToString, 3).ToUpper = Seldoctor_Offday.ToUpper Then
                        .Rows(e.RowIndex).Cells(e.ColumnIndex).Value = "OFF DAY"
                    Else
                        .Rows(e.RowIndex).Cells(e.ColumnIndex).Value = "OFF TIME"
                    End If
                    Return
                End If
            End With

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgrd_Appointment_CellLeave(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgrd_Appointment.CellLeave
        Try
            With Dgrd_Appointment
                If e.RowIndex = -1 Then Exit Sub
                If e.ColumnIndex = 0 Then Exit Sub
                If .Rows(e.RowIndex).Cells(e.ColumnIndex).Tag = "" Then
                    .Rows(e.RowIndex).Cells(e.ColumnIndex).Value = ""

                End If
            End With

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgrd_Appointment_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Dgrd_Appointment.KeyDown
        Try
            If Not e.KeyCode = Keys.Enter Then Exit Sub

            With Dgrd_Appointment
                If .CurrentRow Is Nothing Then Exit Sub
                If .CurrentCell Is Nothing Then Exit Sub

                If .Rows(.CurrentRow.Index).Cells(.CurrentCell.ColumnIndex).Tag = "" Then
                    Return
                End If
                Dim Seldate As Date
                Dim seltime As String
                Dim ApointID As String = ""

                ApointID = .Rows(.CurrentRow.Index).Cells(.CurrentCell.ColumnIndex).Tag
                Seldate = CDate(.Columns(.CurrentCell.ColumnIndex).Name)
                seltime = .Rows(.CurrentRow.Index).Cells("Time").Value.ToString
                Call Show_Registrationform(True, seltime, Seldate, ApointID)
            End With

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Register_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Register.Click
        Try
            If Seldoctor_ID = 0 Then MessageBox.Show("Please Select a Doctor and Proceed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Return
            If App_Service_ID = 0 Then MessageBox.Show("Please Select a Service and Proceed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Return

            Call Show_Registrationform(False, "", Tran_Date, "")

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Timer1_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Try
            If Seldoctor_ID = 0 Then Return
            If App_Service_ID = 0 Then Return
            Call Refresh_Apointmentchart(Seldoctor_ID, App_Service_ID, Tran_Date, Tran_Date.AddDays(Dgrd_Appointment.ColumnCount - 1))
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Cmb_Days_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_Days.SelectedIndexChanged
        Try
            If Seldoctor_ID = 0 Then Return
            If App_Service_ID = 0 Then Return

            Call Set_GridColumns(Tran_Date, Val(Cmb_Days.Text))
            Call Refresh_Apointmentchart(Seldoctor_ID, App_Service_ID, Tran_Date, Tran_Date.AddDays(Dgrd_Appointment.ColumnCount - 1))

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgrd_Appointment_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgrd_Appointment.CellContentClick

    End Sub
End Class