﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Navigator_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Navigator_Frm))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.DGvw_Menulist = New System.Windows.Forms.DataGridView
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DGvw_Menulist, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(3, 4)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(258, 195)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'DGvw_Menulist
        '
        Me.DGvw_Menulist.AllowUserToAddRows = False
        Me.DGvw_Menulist.AllowUserToDeleteRows = False
        Me.DGvw_Menulist.AllowUserToOrderColumns = True
        Me.DGvw_Menulist.AllowUserToResizeColumns = False
        Me.DGvw_Menulist.AllowUserToResizeRows = False
        Me.DGvw_Menulist.BackgroundColor = System.Drawing.Color.SteelBlue
        Me.DGvw_Menulist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGvw_Menulist.ColumnHeadersVisible = False
        Me.DGvw_Menulist.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.DGvw_Menulist.GridColor = System.Drawing.Color.SteelBlue
        Me.DGvw_Menulist.Location = New System.Drawing.Point(19, 16)
        Me.DGvw_Menulist.MultiSelect = False
        Me.DGvw_Menulist.Name = "DGvw_Menulist"
        Me.DGvw_Menulist.RowHeadersVisible = False
        Me.DGvw_Menulist.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.SteelBlue
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.AliceBlue
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.DGvw_Menulist.RowsDefaultCellStyle = DataGridViewCellStyle1
        Me.DGvw_Menulist.RowTemplate.Height = 20
        Me.DGvw_Menulist.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.DGvw_Menulist.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DGvw_Menulist.Size = New System.Drawing.Size(225, 128)
        Me.DGvw_Menulist.StandardTab = True
        Me.DGvw_Menulist.TabIndex = 47
        '
        'Navigator_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Lime
        Me.ClientSize = New System.Drawing.Size(265, 203)
        Me.ControlBox = False
        Me.Controls.Add(Me.DGvw_Menulist)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Navigator_Frm"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.TransparencyKey = System.Drawing.Color.Lime
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DGvw_Menulist, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents DGvw_Menulist As System.Windows.Forms.DataGridView
End Class
