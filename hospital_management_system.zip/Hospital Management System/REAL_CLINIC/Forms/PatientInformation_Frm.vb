﻿Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls

Public Class PatientInformation_Frm

#Region "Declarations"
    'Object of Employee Details Bussiness Layer


    Private Patient_BL As PatientInformation_BL_Cls
    Private hms_helper As HMS_Helper = Nothing

    Private mTr_Mode As Tran_Mode

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing
    Private Ctrl_Point As Point

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_Pat_ID.BackColor = Color.White
                    Me.Txt_Pat_Soc_SecNo.BackColor = Color.White
                    Me.Txt_Pat_ID.ReadOnly = False
                    Me.Txt_Pat_Soc_SecNo.ReadOnly = False
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_Pat_ID.BackColor = Color.Silver
                    Me.Txt_Pat_Soc_SecNo.BackColor = Color.Silver
                    Me.Txt_Pat_ID.ReadOnly = True
                    Me.Txt_Pat_Soc_SecNo.ReadOnly = True
            End Select
        End Set
    End Property


#End Region

#Region "Methods"
    'clear controls
    Public Sub Clear_Form()
        Try
            If Cmb_Pat_Country.Items.Count > 0 Then Cmb_Pat_Country.SelectedIndex = 0
            If Cmb_Pat_Income.Items.Count > 0 Then Cmb_Pat_Income.SelectedIndex = 0
            If Cmb_Pat_Insure.Items.Count > 0 Then Cmb_Pat_Insure.SelectedIndex = 0
            If Cmb_Pat_Martial.Items.Count > 0 Then Cmb_Pat_Martial.SelectedIndex = 0
            If cmb_Pat_Religion.Items.Count > 0 Then cmb_Pat_Religion.SelectedIndex = 0
            If Cmb_Pat_Social.Items.Count > 0 Then Cmb_Pat_Social.SelectedIndex = 0
            If cmb_Pat_State.Items.Count > 0 Then cmb_Pat_State.SelectedIndex = 0
            If cmb_Pat_Status.Items.Count > 0 Then cmb_Pat_Status.SelectedIndex = 0
            If Cmb_Pat_Gender.Items.Count > 0 Then Cmb_Pat_Gender.SelectedIndex = 0


            Dtp_LastAdmitDate.Value = Tran_Date
            Dtp_Pat_DOB.Text = "##/##/####"
            Dtp_Pat_RegDt.Value = Tran_Date
            Txt_Nominee_Relate.Text = ""
            Txt_Pat_Add.Text = ""
            Txt_Pat_Soc_SecNo.Text = ""
            Txt_Pat_Age.Text = ""
            Txt_Pat_City.Text = ""
            Txt_Pat_Email.Text = ""
            Txt_Pat_Employer.Text = ""
            Txt_Pat_FamilyDr.Text = ""
            Txt_Pat_ID.Text = ""
            Txt_Pat_Identity.Text = ""
            Txt_Pat_Mobile1.Text = ""
            Txt_Pat_Mobile2.Text = ""
            Txt_Pat_Name.Text = ""
            Txt_FamilyName.Text = ""
            Txt_Pat_Nominee.Text = ""
            Txt_Pat_Occupation.Text = ""
            Txt_Pat_Phone1.Text = ""
            Txt_Pat_Phone2.Text = ""
            Txt_Pat_Pin.Text = ""
            Txt_Pat_Remarks.Text = ""

            TabControl1.SelectedIndex = 0

            Tr_Mode = Tran_Mode.New_Mode
            Btn_Save.Enabled = True
            Btn_Delete.Enabled = False
          
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    'assigning values to controls
    Private Sub AssignToControl(ByVal dtbl As DataTable)
        Try

            Dim dr As DataTableReader = Nothing
            dr = dtbl.CreateDataReader()
            dr.Read()

            With dr
                Txt_Pat_ID.Text = .Item("Patient_ID").ToString
                Txt_Pat_Name.Text = .Item("Name").ToString
                Txt_FamilyName.Text = .Item("Family").ToString
                Txt_Pat_Add.Text = .Item("Address").ToString
                Txt_Pat_Soc_SecNo.Text = .Item("Social-Security-No").ToString
                Txt_Pat_City.Text = .Item("City").ToString
                Txt_Pat_Pin.Text = .Item("Pin").ToString
                Txt_Pat_Phone1.Text = .Item("Phone").ToString
                Txt_Pat_Phone2.Text = .Item("Patient_Phone2").ToString
                Txt_Pat_Mobile1.Text = .Item("Mobile").ToString
                Txt_Pat_Mobile2.Text = .Item("Patient_Mobile2").ToString
                Txt_Pat_Age.Text = .Item("Age").ToString
                Txt_Pat_Email.Text = .Item("Email").ToString
                Txt_Pat_Occupation.Text = .Item("Occupation").ToString
                Txt_Pat_Employer.Text = .Item("Employer").ToString
                Txt_Pat_Nominee.Text = .Item("Nominee").ToString
                Txt_Nominee_Relate.Text = .Item("Nominee relation").ToString
                Txt_Pat_FamilyDr.Text = .Item("Family Doctor").ToString
                Txt_Pat_Remarks.Text = .Item("Remarks").ToString
                Txt_Pat_Identity.Text = .Item("Patient_Identitydetails").ToString

                Dtp_Pat_DOB.Text = IIf(CDate(.Item("Date of birth")) = CDate("01/01/1900"), "##/##/####", CDate(.Item("Date of birth")))
                If Not IsDate(Dtp_Pat_DOB.Text) Then Txt_Pat_Age.Text = .Item("Age").ToString
                If Val(Txt_Pat_Age.Text) = 0 Then Txt_Pat_Age.Text = ""

                Dtp_Pat_RegDt.Value = .Item("Admit Date").ToString
                Dtp_LastAdmitDate.Value = .Item("Last Admit Date").ToString

                cmb_Pat_Status.SelectedValue = .Item("Patient_Status")
                cmb_Pat_Religion.SelectedValue = .Item("Patient_Religion")
                Cmb_Pat_Martial.SelectedValue = .Item("Marital Status")
                Cmb_Pat_Insure.SelectedValue = .Item("Insured")
                Cmb_Pat_Social.SelectedValue = .Item("Patient_Socialstatus")
                Cmb_Pat_Income.SelectedValue = .Item("Patient_AnnualIncome")
                cmb_Pat_State.SelectedValue = .Item("Patient_State")
                Cmb_Pat_Country.SelectedValue = .Item("Patient_Country")

                Cmb_Pat_Gender.SelectedIndex = IIf(.Item("Gender").ToString.Trim = "M", 1, 2)
                Cmb_Pat_Insure.SelectedIndex = IIf(.Item("Insured").ToString = "Y", 1, 2)

                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Save.Enabled = True
                Btn_Delete.Enabled = True

                With Imageviewer1
                    .CUST_TYPE = Customer_Type.Patient
                    .CUST_ID = Txt_Pat_ID.Text.Trim
                End With

            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    'validating fields 
    Private Function Validate_Fields() As Boolean
        Try

            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If

            If Tr_Mode <> Tran_Mode.New_Mode Then
                If Txt_Pat_ID.Text.Trim = "" Then MessageBox.Show("Invalid Patient ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Pat_ID.Focus() : Return False
            End If
            'validating all mandatory fields
            If Is_SSnumberneeded And Txt_Pat_Soc_SecNo.Text.Trim = "" Then MessageBox.Show("Invalid Soc Security Number, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : TabControl1.SelectedIndex = 0 : Txt_Pat_Soc_SecNo.Focus() : Return False
            If Txt_Pat_Name.Text.Trim = "" Then MessageBox.Show("Invalid Patient Name, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : TabControl1.SelectedIndex = 0 : Txt_Pat_Name.Focus() : Return False
            If Txt_Pat_Add.Text.Trim = "" Then MessageBox.Show("Invalid Patient Address, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : TabControl1.SelectedIndex = 0 : Txt_Pat_Add.Focus() : Return False
            If Txt_Pat_Mobile1.Text.Trim = "" Then MessageBox.Show("Invalid Mobile Number, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : TabControl1.SelectedIndex = 0 : Txt_Pat_Mobile1.Focus() : Return False

            If Cmb_Pat_Gender.SelectedIndex = 0 Then MessageBox.Show("Invalid Gender selection, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : TabControl1.SelectedIndex = 0 : Cmb_Pat_Gender.Focus() : Return False
            If Cmb_Pat_Insure.SelectedIndex = 0 Then MessageBox.Show("Invalid Inssurance selection, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : TabControl1.SelectedIndex = 0 : Cmb_Pat_Insure.Focus() : Return False

            'Checking entered valid phone/mobile/email/age
            If Txt_Pat_Age.Text.Trim <> "" Then If Val(Txt_Pat_Age.Text.Trim) > 250 Then MessageBox.Show("Invalid Patient Age, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : TabControl1.SelectedIndex = 0 : Txt_Pat_Age.Focus() : Return False
            If Txt_Pat_Email.Text.Trim <> "" Then If Not Email_Validation(Txt_Pat_Email.Text.Trim, True) Then Txt_Pat_Email.Focus() : Return False
            If Txt_Pat_Mobile1.Text.Trim <> "" Then If Not Mobile_Validation(Txt_Pat_Mobile1.Text.Trim, True) Then Txt_Pat_Mobile1.Focus() : Return False
            If Txt_Pat_Mobile2.Text.Trim <> "" Then If Not Mobile_Validation(Txt_Pat_Mobile2.Text.Trim, True) Then Txt_Pat_Mobile2.Focus() : Return False
            If Txt_Pat_Phone1.Text.Trim <> "" Then If Not Phone_Validation(Txt_Pat_Phone1.Text.Trim, True) Then Txt_Pat_Phone1.Focus() : Return False
            If Txt_Pat_Phone2.Text.Trim <> "" Then If Not Phone_Validation(Txt_Pat_Phone2.Text.Trim, True) Then Txt_Pat_Phone1.Focus() : Return False

            REM assigning Defalt values to controls
            If Txt_Pat_Age.Text.Trim = "" Then Txt_Pat_Age.Text = 0

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    'Locate values from BL
    Public Function Locate_Values(ByVal Patient_ID As String) As Boolean
        Patient_BL = New PatientInformation_BL_Cls
        Dim dtbl As DataTable = Nothing
        Try
            If Patient_BL.Get_Patient_Info(dtbl, Patient_ID) Then
                Call AssignToControl(dtbl)
                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Delete.Enabled = True
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Function

    'Locate values from BL
    Public Function Locate_Values_SSNO(ByVal Patient_SS_No As String) As Boolean
        Patient_BL = New PatientInformation_BL_Cls
        Dim dtbl As DataTable = Nothing
        Try
            If Patient_BL.Get_Patient_Info_SSNo(dtbl, Patient_SS_No) Then
                Call AssignToControl(dtbl)
                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Delete.Enabled = True
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Function

    Private Function Locate_Insurance_Company(ByVal IComp_ID As Integer) As Boolean
        Try
            hms_helper = New Hms_Helperimpliments
            Dim dtbl As DataTable = Nothing

            If hms_helper.Get_Insurance_Master_Details(dtbl, IComp_ID) Then
                With dtbl

                    Txt_Contact_Person_Name.Text = .Rows(0).Item("Contact Person").ToString
                    Txt_Company_Address.Text = .Rows(0).Item("Address").ToString
                    Txt_Contact_Person_Address.Text = .Rows(0).Item("Contact Person Address").ToString
                    Txt_Contact_Person_Email.Text = .Rows(0).Item("Contact Person Email").ToString
                    Txt_Contact_Person_Fax.Text = .Rows(0).Item("Contact Person Fax").ToString
                    Txt_Contact_Person_Phone.Text = .Rows(0).Item("Contact Person Phone").ToString
                    Txt_Contact_Person_Mobile.Text = .Rows(0).Item("Contact Person Mobile").ToString
                    Txt_Company_Mob.Text = .Rows(0).Item("Mobile").ToString
                    Txt_Company_Phone.Text = .Rows(0).Item("Phone").ToString

                    Return True
                End With
            Else
                Return False
            End If

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Clear_Insurance_Details()
        Try

            Cmb_Insurance_Company.SelectedIndex = 0
            Txt_Company_Address.Text = ""
            Txt_Contact_Person_Name.Text = ""
            Txt_Contact_Person_Address.Text = ""
            Txt_Contact_Person_Email.Text = ""
            Txt_Contact_Person_Fax.Text = ""
            Txt_Contact_Person_Phone.Text = ""
            Txt_Contact_Person_Mobile.Text = ""

            Txt_Company_Mob.Text = ""
            Txt_Company_Phone.Text = ""

        Catch ex As Exception

        End Try

    End Sub

#End Region

    Private Sub PatientInformation_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then SendKeyTab()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub PatientInformation_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        Try
            If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub PatientInformation_Frm_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Leave

    End Sub

    Private Sub PatientInformation_Frm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try


            hms_helper = New Hms_Helperimpliments
            Call hms_helper.Fill_GenData(Cmb_Pat_Country, Gendatatype.Country)
            Call hms_helper.Fill_GenData(cmb_Pat_State, Gendatatype.State)
            Call hms_helper.Fill_GenData(Cmb_Pat_Martial, Gendatatype.Martial_Status)
            Call hms_helper.Fill_GenData(cmb_Pat_Religion, Gendatatype.Religion)
            Call hms_helper.Fill_GenData(cmb_Pat_Status, Gendatatype.Patient_Status)
            Call hms_helper.Fill_GenData(Cmb_Pat_Social, Gendatatype.Patient_Social_Status)
            Call hms_helper.Fill_GenData(Cmb_Pat_Income, Gendatatype.Income_range)
            Call hms_helper.Fill_Insurance_Companies(Cmb_Insurance_Company, "Select")

            With Cmb_Pat_Gender
                .Items.Add("Select")
                .Items.Add("Male")
                .Items.Add("Female")
            End With

            With Cmb_Pat_Insure
                .Items.Add("Select")
                .Items.Add("Yes")
                .Items.Add("No")
            End With

            Txt_Pat_ID.Focus()
            Cmb_Pat_Insure.SelectedIndex = 0
            Cmb_Pat_Gender.SelectedIndex = 0

            Dtp_Pat_RegDt.Value = Today
            Dtp_LastAdmitDate.Value = Today
        Catch ex As Exception

        End Try
    End Sub
   
    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try

            Patient_BL = New PatientInformation_BL_Cls
            If Not Validate_Fields() Then Exit Sub

            Patient_BL.Patient_ID = Txt_Pat_ID.Text.Trim
            Patient_BL.Patient_Name = Txt_Pat_Name.Text.Trim
            Patient_BL.Patient_FamilyName = Txt_FamilyName.Text.Trim
            Patient_BL.Patient_Addr = Txt_Pat_Add.Text.Trim
            Patient_BL.Patient_SS_No = Txt_Pat_Soc_SecNo.Text.Trim
            Patient_BL.Patient_City = Txt_Pat_City.Text.Trim
            Patient_BL.Patient_State = cmb_Pat_State.SelectedValue
            Patient_BL.Patient_Country = Cmb_Pat_Country.SelectedValue
            Patient_BL.Patient_Gender = Strings.Left(Cmb_Pat_Gender.Text.Trim, 1)
            Patient_BL.Patient_PIN = Txt_Pat_Pin.Text.Trim
            Patient_BL.Patient_Phone1 = Txt_Pat_Phone1.Text.Trim
            Patient_BL.Patient_Phone2 = Txt_Pat_Phone2.Text.Trim
            Patient_BL.Patient_Mobile1 = Txt_Pat_Mobile1.Text.Trim
            Patient_BL.Patient_Mobile2 = Txt_Pat_Mobile2.Text.Trim
            If IsDate(Dtp_Pat_DOB.Text) Then
                Patient_BL.Patient_DOB = CDate(Dtp_Pat_DOB.Text)
            Else
                Patient_BL.Patient_DOB = "01/01/1900"
            End If

            Patient_BL.Patient_Age = Txt_Pat_Age.Text.Trim
            Patient_BL.Patient_Religion = cmb_Pat_Religion.SelectedValue
            Patient_BL.Patient_Maritalstatus = Cmb_Pat_Martial.SelectedValue
            Patient_BL.Patient_Email = Txt_Pat_Email.Text.Trim
            Patient_BL.Patient_Occupation = Txt_Pat_Occupation.Text.Trim
            Patient_BL.Patient_Employer = Txt_Pat_Employer.Text.Trim
            Patient_BL.Patient_Insured = Cmb_Pat_Insure.SelectedValue
            Patient_BL.Patient_Nominee = Txt_Pat_Nominee.Text.Trim
            Patient_BL.Patient_Nomrelation = Txt_Nominee_Relate.Text.Trim
            Patient_BL.Patient_FamilyDoctor = Txt_Pat_FamilyDr.Text.Trim
            Patient_BL.Patient_Remarks = Txt_Pat_Remarks.Text.Trim
            Patient_BL.Patient_Status = cmb_Pat_Status.SelectedValue
            Patient_BL.Patient_Regdate = Dtp_Pat_RegDt.Value
            Patient_BL.Patient_LastAdmitdate = Dtp_LastAdmitDate.Value
            Patient_BL.Patient_Socialstatus = Cmb_Pat_Social.SelectedValue
            Patient_BL.Patient_AnnualIncome = Cmb_Pat_Income.SelectedValue
            Patient_BL.Patient_Identitydetails = Txt_Pat_Identity.Text.Trim
            Patient_BL.Patient_Insured = Strings.Left(Cmb_Pat_Insure.Text, 1)


            If Patient_BL.Save_PatientInformation(Dtbl, Tr_Mode, Txt_Pat_ID.Text.Trim) Then
                If Dtbl.Rows(0).Item(0).ToString = "0" Then
                    MessageBox.Show("Patient Information Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Else
                    MessageBox.Show("Patient Information Details Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Call Clear_Form()
                    Btn_Clear.Focus()
                End If

            Else
                MessageBox.Show("Patient Information Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try
            Call Clear_Form()
            Txt_Pat_ID.Focus()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Pat_ID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Pat_ID.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then Btn_FindID_Click(sender, e)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Pat_ID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_Pat_ID.Validating
        Try

            If Txt_Pat_ID.Text.Trim <> "" Then
                If Not Locate_Values(Txt_Pat_ID.Text.Trim) Then
                    MessageBox.Show("Invalid Patient ID, Please Check ", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Txt_Pat_ID.Focus()
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Tab1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Tab1.Click
        Try
            TabControl1.SelectedIndex = 0
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Btn_Tab2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Tab2.Click
        Try
            TabControl1.SelectedIndex = 1
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            TabControl1.SelectedIndex = 2
            Cmb_Insurance_Company.Focus()
        Catch ex As Exception

        End Try
    End Sub

    Public Sub Btn_FindID_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_FindID.Click
        Try
            If Txt_Pat_ID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "150|75|200|200|200"
                'Sql = "Select  Name,Patient_ID,[Family Name], Address, [SS_No],City,State,Country from Get_Patient_Info_Vw " '"SELECT *  FROM    Patient_Info_Short_Vw"
                Sql = "Select  Name,Patient_ID,[Social-Security-No],Family,Address,City,State,Country,Mobile from Get_Patient_Info_Vw where Br_code='" & Branch_Code & "' "
                Call ShowSearchengine(Txt_Pat_ID, Sql, 1, "Name", Colwidth, , 0)
            End If

            If Txt_Pat_ID.Text.Trim = "" Then
                Txt_Pat_ID.Focus() : Exit Sub
            End If

            'Locate Employee details 
            If Not Locate_Values(Txt_Pat_ID.Text.Trim) Then
                MessageBox.Show("Invalid Patient ID, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Txt_Pat_ID.Focus() : Exit Sub
            Else
                Txt_Pat_Name.Focus()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Lbl_Back_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try
            TabControl1.SelectedIndex = 0
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Lbl_Forward_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try
            TabControl1.SelectedIndex = 1
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Lbl_Back_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try
            TabControl1.SelectedIndex = 0
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Cmb_Pat_Insure_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Cmb_Pat_Insure.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then TabControl1.SelectedIndex = 1
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Pat_Phone1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Pat_Phone1.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Pat_Phone1.Text, Data_Type.Integer_Type, 12))
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Pat_Phone2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Pat_Phone2.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Pat_Phone2.Text, Data_Type.Integer_Type, 12))
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Pat_Mobile1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Pat_Mobile1.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Pat_Mobile1.Text, Data_Type.Integer_Type, 12))
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Pat_Mobile2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Pat_Mobile2.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Pat_Mobile2.Text, Data_Type.Integer_Type, 12))
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Pat_Pin_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Pat_Pin.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Pat_Pin.Text, Data_Type.Integer_Type, 12))
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Pat_Age_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Pat_Age.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Pat_Age.Text, Data_Type.Integer_Type, 12))
        Catch ex As Exception

        End Try
    End Sub

   

    Private Sub Txt_Pat_Add_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Pat_Add.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then Txt_Pat_Add.Select(Len(Txt_Pat_Add.Text), 0)
            If Len(Txt_Pat_Add.Text) > 150 Then Txt_Pat_Add.ScrollBars = ScrollBars.Both Else Txt_Pat_Add.ScrollBars = ScrollBars.None
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Pat_Employer_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Pat_Employer.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then Txt_Pat_Employer.Select(Len(Txt_Pat_Employer.Text), 0)
            If Len(Txt_Pat_Employer.Text) > 150 Then Txt_Pat_Employer.ScrollBars = ScrollBars.Both Else Txt_Pat_Employer.ScrollBars = ScrollBars.None
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Pat_FamilyDr_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Pat_FamilyDr.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then Txt_Pat_FamilyDr.Select(Len(Txt_Pat_FamilyDr.Text), 0)
            If Len(Txt_Pat_FamilyDr.Text) > 150 Then Txt_Pat_FamilyDr.ScrollBars = ScrollBars.Both Else Txt_Pat_FamilyDr.ScrollBars = ScrollBars.None
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Pat_Remarks_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Pat_Remarks.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then Txt_Pat_Remarks.Select(Len(Txt_Pat_Remarks.Text), 0)
            If Len(Txt_Pat_Remarks.Text) > 150 Then Txt_Pat_Remarks.ScrollBars = ScrollBars.Both Else Txt_Pat_Remarks.ScrollBars = ScrollBars.None
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Pat_Identity_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Pat_Identity.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then Txt_Pat_Identity.Select(Len(Txt_Pat_Identity.Text), 0)
            If Len(Txt_Pat_Identity.Text) > 150 Then Txt_Pat_Identity.ScrollBars = ScrollBars.Both Else Txt_Pat_Identity.ScrollBars = ScrollBars.None
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Try
            Me.Close()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click
        Try
            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If


            Patient_BL = New PatientInformation_BL_Cls
            Dim dtbl As DataTable = Nothing
            Dim dr As DataTableReader = Nothing
            If MessageBox.Show("Are you sure want to delete the  record ", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                If Patient_BL.Del_Patient_Info(dtbl, Txt_Pat_ID.Text.Trim) Then
                    dr = dtbl.CreateDataReader()
                    dr.Read()
                    If dr.Item("DelStatus").ToString = True Then
                        MessageBox.Show("Patient Information Deleted", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                        Call Clear_Form()
                        Txt_Pat_ID.Focus()
                    Else
                        MessageBox.Show("You cannot delete this Patient Information" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                Else
                    MessageBox.Show("You cannot delete this Patient Information" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub TabPage2_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TabPage2.GotFocus
        Try
            Txt_Pat_Employer.Focus()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Pat_Name_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Pat_Name.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then SendKeyTab()
        Catch ex As Exception

        End Try
    End Sub
    
    Public Sub Btn_Find2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find2.Click
        Try
            If Txt_Pat_Soc_SecNo.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "150|75|75|200"
                'Sql = "SELECT  SS_No as [Soc Sec No],Name, Address, City, State, Gender, Phone1, Mobile1  FROM         Patient_Info_Short_Vw"
                Sql = "Select  Name,Patient_ID,[Social-Security-No],Family,Address,City,State,Country,Mobile from Get_Patient_Info_Vw Where Br_Code = " & Branch_Code & ""
                Call ShowSearchengine(Txt_Pat_Soc_SecNo, Sql, 2, "Name", Colwidth, , 0)
            End If

            If Txt_Pat_Soc_SecNo.Text.Trim = "" Then
                Txt_Pat_Soc_SecNo.Focus() : Exit Sub
            End If

            'Locate Employee details 
            If Not Locate_Values_SSNO(Txt_Pat_Soc_SecNo.Text.Trim) Then
                MessageBox.Show("Invalid Patient Social Seccurity Number, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Txt_Pat_Soc_SecNo.Focus() : Exit Sub
            Else
                Txt_Pat_Name.Focus()
            End If
        Catch ex As Exception

        End Try
    End Sub


    Private Sub Txt_Pat_Soc_SecNo_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Pat_Soc_SecNo.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then Btn_Find2_Click(sender, e)
        Catch ex As Exception

        End Try

    End Sub

#Region "A D D  New GenData"

    Private Sub Set_NewGendatabutton(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cmb_Pat_Country.GotFocus, cmb_Pat_State.GotFocus, Cmb_Pat_Income.GotFocus, cmb_Pat_Religion.GotFocus, Cmb_Pat_Social.GotFocus
        Try
            Dim AddReqCtrl As Control = CType(sender, Control)

            If TabControl1.SelectedIndex = 0 Then
                Btn_New.Visible = True
                Me.Btn_New.Location = Get_Newgendatabuttonposition(AddReqCtrl)
                Me.Btn_New.Tag = AddReqCtrl.Name & "|" & Val(AddReqCtrl.Tag)

            Else
                Btn_New1.Visible = True
                Me.Btn_New1.Location = Get_Newgendatabuttonposition(AddReqCtrl)
                Me.Btn_New1.Tag = AddReqCtrl.Name & "|" & Val(AddReqCtrl.Tag)

            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_New_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_New.Click, Btn_New1.Click
        Try
            Dim AddBtnCtrl As Control = CType(sender, Control)
            Call AddNewGendata(AddBtnCtrl)

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Call_Btnnew(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Cmb_Pat_Country.KeyDown, cmb_Pat_State.KeyDown, Cmb_Pat_Income.KeyDown, cmb_Pat_Religion.KeyDown, Cmb_Pat_Social.KeyDown
        Try
            If TabControl1.SelectedIndex = 0 Then
                If e.KeyCode = Keys.Add Then Call Btn_New_Click(Btn_New, Nothing)

            Else
                If e.KeyCode = Keys.Add Then Call Btn_New_Click(Btn_New1, Nothing)

            End If
        Catch ex As Exception

        End Try
    End Sub

#End Region
    Private Sub Dtp_Pat_DOB_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Dtp_Pat_DOB.TextChanged
        Try

            If Not IsDate(Dtp_Pat_DOB.Text) Then Exit Sub
            Txt_Pat_Age.Text = Int(DateDiff(DateInterval.Month, CDate(Dtp_Pat_DOB.Text), Tran_Date) / 12).ToString

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Cmb_Insurance_Company_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_Insurance_Company.SelectedIndexChanged
        Try

            If Not Locate_Insurance_Company(Cmb_Insurance_Company.SelectedValue) Then
                Call Clear_Insurance_Details()
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_FindIns_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_FindIns.Click
        Try

            If Cmb_Insurance_Company.SelectedIndex = 0 Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "150|75|200|200|200"
                Sql = "select * from Insurance_Master_Vw "
                Call ShowSearchengine(Cmb_Insurance_Company, Sql, 0, "IComp_ID", Colwidth, , 0)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Try
            TabControl1.SelectedIndex = 3
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Cmb_Pat_Insure_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_Pat_Insure.SelectedIndexChanged
        Try
            If Cmb_Pat_Insure.Text = "Yes" Then
                Pnl_Insurance_Det.Enabled = True
            Else
                Call Clear_Insurance_Details()
                Pnl_Insurance_Det.Enabled = False
            End If
        Catch ex As Exception

        End Try
    End Sub
End Class
