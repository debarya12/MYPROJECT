﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class OP_Register_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(OP_Register_Frm))
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Lbl_Heading = New System.Windows.Forms.Label
        Me.Pnl_1 = New System.Windows.Forms.Panel
        Me.Label26 = New System.Windows.Forms.Label
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label
        Me.Btn_PMRIDF2 = New System.Windows.Forms.Button
        Me.Txt_PMRID = New System.Windows.Forms.TextBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.Txt_OPID = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Btn_Find = New System.Windows.Forms.Button
        Me.Pnl_Doc = New System.Windows.Forms.Panel
        Me.Btn_Followupreg = New System.Windows.Forms.Button
        Me.Label20 = New System.Windows.Forms.Label
        Me.Cmb_Visittype = New System.Windows.Forms.ComboBox
        Me.Label23 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Lbl_Doctordetails = New System.Windows.Forms.Label
        Me.Cmb_Service = New System.Windows.Forms.ComboBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.Pnl_Doctors = New System.Windows.Forms.Panel
        Me.TlStrp_Doctors = New System.Windows.Forms.ToolStrip
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton
        Me.Pnl_2 = New System.Windows.Forms.Panel
        Me.Pnl_Apoint = New System.Windows.Forms.Panel
        Me.Txt_ApointID = New System.Windows.Forms.TextBox
        Me.Label18 = New System.Windows.Forms.Label
        Me.Btn_Appointment = New System.Windows.Forms.Button
        Me.Btn_AppIDF2 = New System.Windows.Forms.Button
        Me.Txt_Visitortype = New System.Windows.Forms.TextBox
        Me.Lbl_Mesageaproxtime = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.Lbl_MesageTokenno = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.Pnl_Othersdetails = New System.Windows.Forms.Panel
        Me.Txt_Nationality = New System.Windows.Forms.TextBox
        Me.Txt_Gender = New System.Windows.Forms.TextBox
        Me.Txt_PatientID = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.Txt_Visitor_Familyname = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Txt_Visitor_SSNO = New System.Windows.Forms.TextBox
        Me.Label35 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Txt_Visitor_Age = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Txt_Visitor_Mobile = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.Txt_Visitor_Phone = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Txt_Visitor_Addr = New System.Windows.Forms.TextBox
        Me.Txt_Visitor_Name = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Pnl_3 = New System.Windows.Forms.Panel
        Me.Label22 = New System.Windows.Forms.Label
        Me.Lbl_OPValidDays = New System.Windows.Forms.Label
        Me.Lbl_OPValidity = New System.Windows.Forms.Label
        Me.Btn_New = New System.Windows.Forms.Button
        Me.Txt_Remarks = New System.Windows.Forms.TextBox
        Me.Label28 = New System.Windows.Forms.Label
        Me.Trancontrol1 = New Tran_Controls.Trancontrol
        Me.Cmb_Status = New System.Windows.Forms.ComboBox
        Me.Label21 = New System.Windows.Forms.Label
        Me.Cmb_PatientType = New System.Windows.Forms.ComboBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.Cmb_BillingMethod = New System.Windows.Forms.ComboBox
        Me.Label16 = New System.Windows.Forms.Label
        Me.Txt_AmbulatoryStatus = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.Cmb_ArrivalMode = New System.Windows.Forms.ComboBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Print = New System.Windows.Forms.Button
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_CancelOP = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.Panel4 = New System.Windows.Forms.Panel
        Me.Pnl_Header.SuspendLayout()
        Me.Pnl_1.SuspendLayout()
        Me.Pnl_Tran_mode.SuspendLayout()
        Me.Pnl_Doc.SuspendLayout()
        Me.Pnl_Doctors.SuspendLayout()
        Me.TlStrp_Doctors.SuspendLayout()
        Me.Pnl_2.SuspendLayout()
        Me.Pnl_Apoint.SuspendLayout()
        Me.Pnl_Othersdetails.SuspendLayout()
        Me.Pnl_3.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = CType(resources.GetObject("Pnl_Header.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Header.Controls.Add(Me.Lbl_Heading)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(802, 21)
        Me.Pnl_Header.TabIndex = 101
        '
        'Lbl_Heading
        '
        Me.Lbl_Heading.AutoSize = True
        Me.Lbl_Heading.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Heading.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Heading.ForeColor = System.Drawing.Color.White
        Me.Lbl_Heading.Location = New System.Drawing.Point(8, 0)
        Me.Lbl_Heading.Name = "Lbl_Heading"
        Me.Lbl_Heading.Size = New System.Drawing.Size(233, 18)
        Me.Lbl_Heading.TabIndex = 121
        Me.Lbl_Heading.Text = "O u t  P a t i e n t   R e g i s t e r "
        '
        'Pnl_1
        '
        Me.Pnl_1.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_1.Controls.Add(Me.Label26)
        Me.Pnl_1.Controls.Add(Me.Pnl_Tran_mode)
        Me.Pnl_1.Controls.Add(Me.Btn_PMRIDF2)
        Me.Pnl_1.Controls.Add(Me.Txt_PMRID)
        Me.Pnl_1.Controls.Add(Me.Label17)
        Me.Pnl_1.Controls.Add(Me.Txt_OPID)
        Me.Pnl_1.Controls.Add(Me.Label2)
        Me.Pnl_1.Controls.Add(Me.Btn_Find)
        Me.Pnl_1.Enabled = False
        Me.Pnl_1.Location = New System.Drawing.Point(0, 94)
        Me.Pnl_1.Name = "Pnl_1"
        Me.Pnl_1.Size = New System.Drawing.Size(803, 46)
        Me.Pnl_1.TabIndex = 1
        '
        'Label26
        '
        Me.Label26.BackColor = System.Drawing.Color.AliceBlue
        Me.Label26.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label26.Location = New System.Drawing.Point(-3, 44)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(809, 1)
        Me.Label26.TabIndex = 100076
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(725, 11)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(74, 22)
        Me.Pnl_Tran_mode.TabIndex = 221
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(0, 0)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(72, 20)
        Me.Lbl_Tran_Mode.TabIndex = 122
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Btn_PMRIDF2
        '
        Me.Btn_PMRIDF2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_PMRIDF2.BackgroundImage = CType(resources.GetObject("Btn_PMRIDF2.BackgroundImage"), System.Drawing.Image)
        Me.Btn_PMRIDF2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_PMRIDF2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_PMRIDF2.ForeColor = System.Drawing.Color.White
        Me.Btn_PMRIDF2.Location = New System.Drawing.Point(516, 11)
        Me.Btn_PMRIDF2.Name = "Btn_PMRIDF2"
        Me.Btn_PMRIDF2.Size = New System.Drawing.Size(29, 21)
        Me.Btn_PMRIDF2.TabIndex = 4
        Me.Btn_PMRIDF2.TabStop = False
        Me.Btn_PMRIDF2.Text = "F2"
        Me.Btn_PMRIDF2.UseVisualStyleBackColor = False
        '
        'Txt_PMRID
        '
        Me.Txt_PMRID.BackColor = System.Drawing.Color.White
        Me.Txt_PMRID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_PMRID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PMRID.Location = New System.Drawing.Point(361, 11)
        Me.Txt_PMRID.Name = "Txt_PMRID"
        Me.Txt_PMRID.ReadOnly = True
        Me.Txt_PMRID.Size = New System.Drawing.Size(153, 21)
        Me.Txt_PMRID.TabIndex = 3
        Me.Txt_PMRID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label17.Location = New System.Drawing.Point(282, 15)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(45, 14)
        Me.Label17.TabIndex = 220
        Me.Label17.Text = "PMR-ID"
        '
        'Txt_OPID
        '
        Me.Txt_OPID.BackColor = System.Drawing.Color.White
        Me.Txt_OPID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_OPID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_OPID.Location = New System.Drawing.Point(75, 11)
        Me.Txt_OPID.MaxLength = 10
        Me.Txt_OPID.Name = "Txt_OPID"
        Me.Txt_OPID.Size = New System.Drawing.Size(152, 21)
        Me.Txt_OPID.TabIndex = 1
        Me.Txt_OPID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label2.Location = New System.Drawing.Point(3, 14)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(35, 14)
        Me.Label2.TabIndex = 217
        Me.Label2.Text = "OP ID"
        '
        'Btn_Find
        '
        Me.Btn_Find.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find.BackgroundImage = CType(resources.GetObject("Btn_Find.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find.ForeColor = System.Drawing.Color.White
        Me.Btn_Find.Location = New System.Drawing.Point(228, 11)
        Me.Btn_Find.Name = "Btn_Find"
        Me.Btn_Find.Size = New System.Drawing.Size(29, 21)
        Me.Btn_Find.TabIndex = 2
        Me.Btn_Find.TabStop = False
        Me.Btn_Find.Text = "F2"
        Me.Btn_Find.UseVisualStyleBackColor = False
        '
        'Pnl_Doc
        '
        Me.Pnl_Doc.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Doc.Controls.Add(Me.Btn_Followupreg)
        Me.Pnl_Doc.Controls.Add(Me.Label20)
        Me.Pnl_Doc.Controls.Add(Me.Cmb_Visittype)
        Me.Pnl_Doc.Controls.Add(Me.Label23)
        Me.Pnl_Doc.Controls.Add(Me.Label1)
        Me.Pnl_Doc.Controls.Add(Me.Lbl_Doctordetails)
        Me.Pnl_Doc.Controls.Add(Me.Cmb_Service)
        Me.Pnl_Doc.Controls.Add(Me.Label19)
        Me.Pnl_Doc.Controls.Add(Me.Pnl_Doctors)
        Me.Pnl_Doc.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Doc.ForeColor = System.Drawing.Color.Black
        Me.Pnl_Doc.Location = New System.Drawing.Point(0, 21)
        Me.Pnl_Doc.Name = "Pnl_Doc"
        Me.Pnl_Doc.Size = New System.Drawing.Size(802, 73)
        Me.Pnl_Doc.TabIndex = 0
        '
        'Btn_Followupreg
        '
        Me.Btn_Followupreg.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Followupreg.BackgroundImage = CType(resources.GetObject("Btn_Followupreg.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Followupreg.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Followupreg.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Followupreg.ForeColor = System.Drawing.Color.White
        Me.Btn_Followupreg.Location = New System.Drawing.Point(229, 42)
        Me.Btn_Followupreg.Name = "Btn_Followupreg"
        Me.Btn_Followupreg.Size = New System.Drawing.Size(29, 23)
        Me.Btn_Followupreg.TabIndex = 100078
        Me.Btn_Followupreg.TabStop = False
        Me.Btn_Followupreg.Text = "F4"
        Me.Btn_Followupreg.UseVisualStyleBackColor = False
        Me.Btn_Followupreg.Visible = False
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.Color.Transparent
        Me.Label20.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label20.Location = New System.Drawing.Point(2, 46)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(65, 14)
        Me.Label20.TabIndex = 100077
        Me.Label20.Text = "VISIT TYPE"
        '
        'Cmb_Visittype
        '
        Me.Cmb_Visittype.BackColor = System.Drawing.Color.White
        Me.Cmb_Visittype.CausesValidation = False
        Me.Cmb_Visittype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Visittype.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_Visittype.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Visittype.FormattingEnabled = True
        Me.Cmb_Visittype.ItemHeight = 13
        Me.Cmb_Visittype.Location = New System.Drawing.Point(76, 43)
        Me.Cmb_Visittype.Name = "Cmb_Visittype"
        Me.Cmb_Visittype.Size = New System.Drawing.Size(152, 21)
        Me.Cmb_Visittype.TabIndex = 3
        '
        'Label23
        '
        Me.Label23.BackColor = System.Drawing.Color.AliceBlue
        Me.Label23.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label23.Location = New System.Drawing.Point(-3, 71)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(809, 1)
        Me.Label23.TabIndex = 100075
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label1.Location = New System.Drawing.Point(283, 50)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(43, 14)
        Me.Label1.TabIndex = 100074
        Me.Label1.Text = "Doctor"
        '
        'Lbl_Doctordetails
        '
        Me.Lbl_Doctordetails.BackColor = System.Drawing.Color.FromArgb(CType(CType(58, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(139, Byte), Integer))
        Me.Lbl_Doctordetails.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Lbl_Doctordetails.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Doctordetails.ForeColor = System.Drawing.Color.AliceBlue
        Me.Lbl_Doctordetails.Location = New System.Drawing.Point(361, 42)
        Me.Lbl_Doctordetails.Name = "Lbl_Doctordetails"
        Me.Lbl_Doctordetails.Padding = New System.Windows.Forms.Padding(5, 0, 0, 0)
        Me.Lbl_Doctordetails.Size = New System.Drawing.Size(438, 29)
        Me.Lbl_Doctordetails.TabIndex = 100073
        Me.Lbl_Doctordetails.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Cmb_Service
        '
        Me.Cmb_Service.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Service.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_Service.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Service.FormattingEnabled = True
        Me.Cmb_Service.ItemHeight = 13
        Me.Cmb_Service.Location = New System.Drawing.Point(76, 12)
        Me.Cmb_Service.Name = "Cmb_Service"
        Me.Cmb_Service.Size = New System.Drawing.Size(180, 21)
        Me.Cmb_Service.TabIndex = 1
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label19.Location = New System.Drawing.Point(2, 16)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(52, 14)
        Me.Label19.TabIndex = 100072
        Me.Label19.Text = "SERVICE"
        '
        'Pnl_Doctors
        '
        Me.Pnl_Doctors.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Doctors.Controls.Add(Me.TlStrp_Doctors)
        Me.Pnl_Doctors.Location = New System.Drawing.Point(259, 0)
        Me.Pnl_Doctors.Margin = New System.Windows.Forms.Padding(0)
        Me.Pnl_Doctors.Name = "Pnl_Doctors"
        Me.Pnl_Doctors.Padding = New System.Windows.Forms.Padding(2)
        Me.Pnl_Doctors.Size = New System.Drawing.Size(542, 45)
        Me.Pnl_Doctors.TabIndex = 2
        '
        'TlStrp_Doctors
        '
        Me.TlStrp_Doctors.BackColor = System.Drawing.Color.White
        Me.TlStrp_Doctors.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TlStrp_Doctors.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TlStrp_Doctors.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TlStrp_Doctors.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton1})
        Me.TlStrp_Doctors.Location = New System.Drawing.Point(2, 2)
        Me.TlStrp_Doctors.Name = "TlStrp_Doctors"
        Me.TlStrp_Doctors.Size = New System.Drawing.Size(538, 41)
        Me.TlStrp_Doctors.TabIndex = 2
        Me.TlStrp_Doctors.TabStop = True
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolStripButton1.Image = CType(resources.GetObject("ToolStripButton1.Image"), System.Drawing.Image)
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(23, 38)
        Me.ToolStripButton1.Text = "ToolStripButton1"
        '
        'Pnl_2
        '
        Me.Pnl_2.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_2.Controls.Add(Me.Pnl_Apoint)
        Me.Pnl_2.Controls.Add(Me.Txt_Visitortype)
        Me.Pnl_2.Controls.Add(Me.Lbl_Mesageaproxtime)
        Me.Pnl_2.Controls.Add(Me.Label25)
        Me.Pnl_2.Controls.Add(Me.Lbl_MesageTokenno)
        Me.Pnl_2.Controls.Add(Me.Label24)
        Me.Pnl_2.Controls.Add(Me.Pnl_Othersdetails)
        Me.Pnl_2.Controls.Add(Me.Label3)
        Me.Pnl_2.Enabled = False
        Me.Pnl_2.Location = New System.Drawing.Point(0, 139)
        Me.Pnl_2.Name = "Pnl_2"
        Me.Pnl_2.Size = New System.Drawing.Size(803, 190)
        Me.Pnl_2.TabIndex = 2
        '
        'Pnl_Apoint
        '
        Me.Pnl_Apoint.Controls.Add(Me.Txt_ApointID)
        Me.Pnl_Apoint.Controls.Add(Me.Label18)
        Me.Pnl_Apoint.Controls.Add(Me.Btn_Appointment)
        Me.Pnl_Apoint.Controls.Add(Me.Btn_AppIDF2)
        Me.Pnl_Apoint.Location = New System.Drawing.Point(2, 2)
        Me.Pnl_Apoint.Name = "Pnl_Apoint"
        Me.Pnl_Apoint.Size = New System.Drawing.Size(257, 26)
        Me.Pnl_Apoint.TabIndex = 1
        '
        'Txt_ApointID
        '
        Me.Txt_ApointID.BackColor = System.Drawing.Color.White
        Me.Txt_ApointID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_ApointID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_ApointID.Location = New System.Drawing.Point(73, 2)
        Me.Txt_ApointID.Name = "Txt_ApointID"
        Me.Txt_ApointID.Size = New System.Drawing.Size(100, 21)
        Me.Txt_ApointID.TabIndex = 1
        Me.Txt_ApointID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.Transparent
        Me.Label18.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label18.Location = New System.Drawing.Point(0, 5)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(63, 14)
        Me.Label18.TabIndex = 208
        Me.Label18.Text = "Appoint ID"
        '
        'Btn_Appointment
        '
        Me.Btn_Appointment.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Appointment.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.F2_Button
        Me.Btn_Appointment.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Appointment.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Appointment.ForeColor = System.Drawing.Color.White
        Me.Btn_Appointment.Location = New System.Drawing.Point(202, 2)
        Me.Btn_Appointment.Name = "Btn_Appointment"
        Me.Btn_Appointment.Size = New System.Drawing.Size(54, 21)
        Me.Btn_Appointment.TabIndex = 3
        Me.Btn_Appointment.TabStop = False
        Me.Btn_Appointment.Text = "&New F3"
        Me.Btn_Appointment.UseVisualStyleBackColor = False
        '
        'Btn_AppIDF2
        '
        Me.Btn_AppIDF2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_AppIDF2.BackgroundImage = CType(resources.GetObject("Btn_AppIDF2.BackgroundImage"), System.Drawing.Image)
        Me.Btn_AppIDF2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_AppIDF2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_AppIDF2.ForeColor = System.Drawing.Color.White
        Me.Btn_AppIDF2.Location = New System.Drawing.Point(174, 2)
        Me.Btn_AppIDF2.Name = "Btn_AppIDF2"
        Me.Btn_AppIDF2.Size = New System.Drawing.Size(27, 21)
        Me.Btn_AppIDF2.TabIndex = 2
        Me.Btn_AppIDF2.TabStop = False
        Me.Btn_AppIDF2.Text = "F2"
        Me.Btn_AppIDF2.UseVisualStyleBackColor = False
        '
        'Txt_Visitortype
        '
        Me.Txt_Visitortype.BackColor = System.Drawing.Color.White
        Me.Txt_Visitortype.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitortype.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitortype.Location = New System.Drawing.Point(75, 29)
        Me.Txt_Visitortype.MaxLength = 50
        Me.Txt_Visitortype.Name = "Txt_Visitortype"
        Me.Txt_Visitortype.ReadOnly = True
        Me.Txt_Visitortype.Size = New System.Drawing.Size(183, 21)
        Me.Txt_Visitortype.TabIndex = 4
        Me.Txt_Visitortype.TabStop = False
        Me.Txt_Visitortype.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Lbl_Mesageaproxtime
        '
        Me.Lbl_Mesageaproxtime.AutoSize = True
        Me.Lbl_Mesageaproxtime.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Mesageaproxtime.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Mesageaproxtime.ForeColor = System.Drawing.Color.GhostWhite
        Me.Lbl_Mesageaproxtime.Location = New System.Drawing.Point(129, 157)
        Me.Lbl_Mesageaproxtime.Name = "Lbl_Mesageaproxtime"
        Me.Lbl_Mesageaproxtime.Size = New System.Drawing.Size(21, 25)
        Me.Lbl_Mesageaproxtime.TabIndex = 100050
        Me.Lbl_Mesageaproxtime.Text = "*"
        Me.Lbl_Mesageaproxtime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.BackColor = System.Drawing.Color.Transparent
        Me.Label25.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.ForeColor = System.Drawing.Color.Lavender
        Me.Label25.Location = New System.Drawing.Point(12, 161)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(108, 14)
        Me.Label25.TabIndex = 100049
        Me.Label25.Text = "Aproximate Time :"
        '
        'Lbl_MesageTokenno
        '
        Me.Lbl_MesageTokenno.AutoSize = True
        Me.Lbl_MesageTokenno.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_MesageTokenno.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_MesageTokenno.ForeColor = System.Drawing.Color.GhostWhite
        Me.Lbl_MesageTokenno.Location = New System.Drawing.Point(136, 79)
        Me.Lbl_MesageTokenno.Name = "Lbl_MesageTokenno"
        Me.Lbl_MesageTokenno.Size = New System.Drawing.Size(44, 55)
        Me.Lbl_MesageTokenno.TabIndex = 100048
        Me.Lbl_MesageTokenno.Text = "*"
        Me.Lbl_MesageTokenno.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.BackColor = System.Drawing.Color.Transparent
        Me.Label24.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.Lavender
        Me.Label24.Location = New System.Drawing.Point(55, 101)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(65, 14)
        Me.Label24.TabIndex = 100047
        Me.Label24.Text = "Token No :"
        '
        'Pnl_Othersdetails
        '
        Me.Pnl_Othersdetails.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Nationality)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Gender)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_PatientID)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label9)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_Familyname)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label6)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_SSNO)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label35)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label5)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_Age)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label15)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label13)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_Mobile)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label11)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_Phone)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label8)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label4)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_Addr)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_Name)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label7)
        Me.Pnl_Othersdetails.Dock = System.Windows.Forms.DockStyle.Right
        Me.Pnl_Othersdetails.Location = New System.Drawing.Point(261, 0)
        Me.Pnl_Othersdetails.Name = "Pnl_Othersdetails"
        Me.Pnl_Othersdetails.Size = New System.Drawing.Size(542, 190)
        Me.Pnl_Othersdetails.TabIndex = 2
        '
        'Txt_Nationality
        '
        Me.Txt_Nationality.BackColor = System.Drawing.Color.White
        Me.Txt_Nationality.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Nationality.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Nationality.Location = New System.Drawing.Point(100, 169)
        Me.Txt_Nationality.MaxLength = 250
        Me.Txt_Nationality.Name = "Txt_Nationality"
        Me.Txt_Nationality.ReadOnly = True
        Me.Txt_Nationality.Size = New System.Drawing.Size(411, 21)
        Me.Txt_Nationality.TabIndex = 10
        Me.Txt_Nationality.TabStop = False
        '
        'Txt_Gender
        '
        Me.Txt_Gender.BackColor = System.Drawing.Color.White
        Me.Txt_Gender.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Gender.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Gender.Location = New System.Drawing.Point(100, 121)
        Me.Txt_Gender.MaxLength = 250
        Me.Txt_Gender.Name = "Txt_Gender"
        Me.Txt_Gender.ReadOnly = True
        Me.Txt_Gender.Size = New System.Drawing.Size(153, 21)
        Me.Txt_Gender.TabIndex = 6
        Me.Txt_Gender.TabStop = False
        '
        'Txt_PatientID
        '
        Me.Txt_PatientID.BackColor = System.Drawing.Color.White
        Me.Txt_PatientID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_PatientID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PatientID.Location = New System.Drawing.Point(100, 3)
        Me.Txt_PatientID.MaxLength = 50
        Me.Txt_PatientID.Name = "Txt_PatientID"
        Me.Txt_PatientID.ReadOnly = True
        Me.Txt_PatientID.Size = New System.Drawing.Size(153, 21)
        Me.Txt_PatientID.TabIndex = 1
        Me.Txt_PatientID.TabStop = False
        Me.Txt_PatientID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label9.Location = New System.Drawing.Point(21, 7)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(58, 14)
        Me.Label9.TabIndex = 100047
        Me.Label9.Text = "Patient ID"
        '
        'Txt_Visitor_Familyname
        '
        Me.Txt_Visitor_Familyname.BackColor = System.Drawing.Color.White
        Me.Txt_Visitor_Familyname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Familyname.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Familyname.Location = New System.Drawing.Point(100, 97)
        Me.Txt_Visitor_Familyname.MaxLength = 250
        Me.Txt_Visitor_Familyname.Name = "Txt_Visitor_Familyname"
        Me.Txt_Visitor_Familyname.ReadOnly = True
        Me.Txt_Visitor_Familyname.Size = New System.Drawing.Size(411, 21)
        Me.Txt_Visitor_Familyname.TabIndex = 5
        Me.Txt_Visitor_Familyname.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Lavender
        Me.Label6.Location = New System.Drawing.Point(21, 100)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(76, 14)
        Me.Label6.TabIndex = 100044
        Me.Label6.Text = "Family Name"
        '
        'Txt_Visitor_SSNO
        '
        Me.Txt_Visitor_SSNO.BackColor = System.Drawing.Color.White
        Me.Txt_Visitor_SSNO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_SSNO.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_SSNO.Location = New System.Drawing.Point(371, 3)
        Me.Txt_Visitor_SSNO.MaxLength = 50
        Me.Txt_Visitor_SSNO.Name = "Txt_Visitor_SSNO"
        Me.Txt_Visitor_SSNO.ReadOnly = True
        Me.Txt_Visitor_SSNO.Size = New System.Drawing.Size(140, 21)
        Me.Txt_Visitor_SSNO.TabIndex = 2
        Me.Txt_Visitor_SSNO.TabStop = False
        Me.Txt_Visitor_SSNO.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.BackColor = System.Drawing.Color.Transparent
        Me.Label35.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.ForeColor = System.Drawing.Color.Lavender
        Me.Label35.Location = New System.Drawing.Point(296, 5)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(67, 14)
        Me.Label35.TabIndex = 100042
        Me.Label35.Text = "Soc Sec No"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Lavender
        Me.Label5.Location = New System.Drawing.Point(21, 170)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(63, 14)
        Me.Label5.TabIndex = 100041
        Me.Label5.Text = "Nationality"
        '
        'Txt_Visitor_Age
        '
        Me.Txt_Visitor_Age.BackColor = System.Drawing.Color.White
        Me.Txt_Visitor_Age.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Age.Cursor = System.Windows.Forms.Cursors.Default
        Me.Txt_Visitor_Age.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Age.Location = New System.Drawing.Point(371, 121)
        Me.Txt_Visitor_Age.MaxLength = 3
        Me.Txt_Visitor_Age.Name = "Txt_Visitor_Age"
        Me.Txt_Visitor_Age.ReadOnly = True
        Me.Txt_Visitor_Age.Size = New System.Drawing.Size(64, 21)
        Me.Txt_Visitor_Age.TabIndex = 7
        Me.Txt_Visitor_Age.TabStop = False
        Me.Txt_Visitor_Age.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.Lavender
        Me.Label15.Location = New System.Drawing.Point(334, 123)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(29, 14)
        Me.Label15.TabIndex = 100040
        Me.Label15.Text = "Age"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.Lavender
        Me.Label13.Location = New System.Drawing.Point(21, 124)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(48, 14)
        Me.Label13.TabIndex = 100039
        Me.Label13.Text = "Gender"
        '
        'Txt_Visitor_Mobile
        '
        Me.Txt_Visitor_Mobile.BackColor = System.Drawing.Color.White
        Me.Txt_Visitor_Mobile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Mobile.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Mobile.Location = New System.Drawing.Point(371, 145)
        Me.Txt_Visitor_Mobile.MaxLength = 10
        Me.Txt_Visitor_Mobile.Name = "Txt_Visitor_Mobile"
        Me.Txt_Visitor_Mobile.ReadOnly = True
        Me.Txt_Visitor_Mobile.Size = New System.Drawing.Size(140, 21)
        Me.Txt_Visitor_Mobile.TabIndex = 9
        Me.Txt_Visitor_Mobile.TabStop = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Lavender
        Me.Label11.Location = New System.Drawing.Point(319, 147)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(44, 14)
        Me.Label11.TabIndex = 100038
        Me.Label11.Text = "Mobile"
        '
        'Txt_Visitor_Phone
        '
        Me.Txt_Visitor_Phone.BackColor = System.Drawing.Color.White
        Me.Txt_Visitor_Phone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Phone.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Phone.Location = New System.Drawing.Point(100, 145)
        Me.Txt_Visitor_Phone.MaxLength = 11
        Me.Txt_Visitor_Phone.Name = "Txt_Visitor_Phone"
        Me.Txt_Visitor_Phone.ReadOnly = True
        Me.Txt_Visitor_Phone.Size = New System.Drawing.Size(153, 21)
        Me.Txt_Visitor_Phone.TabIndex = 8
        Me.Txt_Visitor_Phone.TabStop = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Lavender
        Me.Label8.Location = New System.Drawing.Point(21, 148)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(42, 14)
        Me.Label8.TabIndex = 100037
        Me.Label8.Text = "Phone"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Lavender
        Me.Label4.Location = New System.Drawing.Point(21, 57)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(55, 14)
        Me.Label4.TabIndex = 100036
        Me.Label4.Text = "Address"
        '
        'Txt_Visitor_Addr
        '
        Me.Txt_Visitor_Addr.BackColor = System.Drawing.Color.White
        Me.Txt_Visitor_Addr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Addr.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Addr.Location = New System.Drawing.Point(100, 54)
        Me.Txt_Visitor_Addr.MaxLength = 500
        Me.Txt_Visitor_Addr.Multiline = True
        Me.Txt_Visitor_Addr.Name = "Txt_Visitor_Addr"
        Me.Txt_Visitor_Addr.ReadOnly = True
        Me.Txt_Visitor_Addr.Size = New System.Drawing.Size(411, 40)
        Me.Txt_Visitor_Addr.TabIndex = 4
        Me.Txt_Visitor_Addr.TabStop = False
        '
        'Txt_Visitor_Name
        '
        Me.Txt_Visitor_Name.BackColor = System.Drawing.Color.LightSteelBlue
        Me.Txt_Visitor_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Name.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.Txt_Visitor_Name.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Name.Location = New System.Drawing.Point(100, 26)
        Me.Txt_Visitor_Name.MaxLength = 250
        Me.Txt_Visitor_Name.Name = "Txt_Visitor_Name"
        Me.Txt_Visitor_Name.ReadOnly = True
        Me.Txt_Visitor_Name.Size = New System.Drawing.Size(411, 26)
        Me.Txt_Visitor_Name.TabIndex = 3
        Me.Txt_Visitor_Name.TabStop = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Lavender
        Me.Label7.Location = New System.Drawing.Point(21, 29)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(79, 14)
        Me.Label7.TabIndex = 100035
        Me.Label7.Text = "Patient Name"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Lavender
        Me.Label3.Location = New System.Drawing.Point(2, 32)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(74, 14)
        Me.Label3.TabIndex = 106
        Me.Label3.Text = "Visitor Type"
        '
        'Pnl_3
        '
        Me.Pnl_3.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_3.Controls.Add(Me.Label22)
        Me.Pnl_3.Controls.Add(Me.Lbl_OPValidDays)
        Me.Pnl_3.Controls.Add(Me.Lbl_OPValidity)
        Me.Pnl_3.Controls.Add(Me.Btn_New)
        Me.Pnl_3.Controls.Add(Me.Txt_Remarks)
        Me.Pnl_3.Controls.Add(Me.Label28)
        Me.Pnl_3.Controls.Add(Me.Trancontrol1)
        Me.Pnl_3.Controls.Add(Me.Cmb_Status)
        Me.Pnl_3.Controls.Add(Me.Label21)
        Me.Pnl_3.Controls.Add(Me.Cmb_PatientType)
        Me.Pnl_3.Controls.Add(Me.Label14)
        Me.Pnl_3.Controls.Add(Me.Cmb_BillingMethod)
        Me.Pnl_3.Controls.Add(Me.Label16)
        Me.Pnl_3.Controls.Add(Me.Txt_AmbulatoryStatus)
        Me.Pnl_3.Controls.Add(Me.Label12)
        Me.Pnl_3.Controls.Add(Me.Cmb_ArrivalMode)
        Me.Pnl_3.Controls.Add(Me.Label10)
        Me.Pnl_3.Enabled = False
        Me.Pnl_3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_3.Location = New System.Drawing.Point(-1, 329)
        Me.Pnl_3.Name = "Pnl_3"
        Me.Pnl_3.Size = New System.Drawing.Size(805, 181)
        Me.Pnl_3.TabIndex = 4
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.BackColor = System.Drawing.Color.Transparent
        Me.Label22.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label22.Location = New System.Drawing.Point(2, 128)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(65, 14)
        Me.Label22.TabIndex = 100083
        Me.Label22.Text = "OP Validity"
        '
        'Lbl_OPValidDays
        '
        Me.Lbl_OPValidDays.BackColor = System.Drawing.Color.LightSkyBlue
        Me.Lbl_OPValidDays.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Lbl_OPValidDays.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Lbl_OPValidDays.Location = New System.Drawing.Point(75, 127)
        Me.Lbl_OPValidDays.Name = "Lbl_OPValidDays"
        Me.Lbl_OPValidDays.Size = New System.Drawing.Size(90, 19)
        Me.Lbl_OPValidDays.TabIndex = 100082
        '
        'Lbl_OPValidity
        '
        Me.Lbl_OPValidity.BackColor = System.Drawing.Color.LightSkyBlue
        Me.Lbl_OPValidity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Lbl_OPValidity.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Lbl_OPValidity.Location = New System.Drawing.Point(167, 127)
        Me.Lbl_OPValidity.Name = "Lbl_OPValidity"
        Me.Lbl_OPValidity.Size = New System.Drawing.Size(90, 19)
        Me.Lbl_OPValidity.TabIndex = 100081
        '
        'Btn_New
        '
        Me.Btn_New.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_New.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Add_3
        Me.Btn_New.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_New.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_New.Font = New System.Drawing.Font("Tahoma", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_New.ForeColor = System.Drawing.Color.White
        Me.Btn_New.Location = New System.Drawing.Point(259, 4)
        Me.Btn_New.Name = "Btn_New"
        Me.Btn_New.Size = New System.Drawing.Size(27, 21)
        Me.Btn_New.TabIndex = 100
        Me.Btn_New.TabStop = False
        Me.Btn_New.UseVisualStyleBackColor = False
        Me.Btn_New.Visible = False
        '
        'Txt_Remarks
        '
        Me.Txt_Remarks.BackColor = System.Drawing.Color.White
        Me.Txt_Remarks.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Remarks.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Remarks.Location = New System.Drawing.Point(361, 156)
        Me.Txt_Remarks.MaxLength = 250
        Me.Txt_Remarks.Name = "Txt_Remarks"
        Me.Txt_Remarks.Size = New System.Drawing.Size(437, 21)
        Me.Txt_Remarks.TabIndex = 8
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.BackColor = System.Drawing.Color.Transparent
        Me.Label28.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label28.Location = New System.Drawing.Point(290, 159)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(57, 14)
        Me.Label28.TabIndex = 100059
        Me.Label28.Text = "Remarks"
        '
        'Trancontrol1
        '
        Me.Trancontrol1.BackColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(123, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Trancontrol1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Trancontrol1.Location = New System.Drawing.Point(361, 26)
        Me.Trancontrol1.Name = "Trancontrol1"
        Me.Trancontrol1.Padding = New System.Windows.Forms.Padding(3)
        Me.Trancontrol1.Size = New System.Drawing.Size(437, 128)
        Me.Trancontrol1.TabIndex = 7
        '
        'Cmb_Status
        '
        Me.Cmb_Status.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Status.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_Status.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Status.FormattingEnabled = True
        Me.Cmb_Status.ItemHeight = 13
        Me.Cmb_Status.Location = New System.Drawing.Point(76, 97)
        Me.Cmb_Status.Name = "Cmb_Status"
        Me.Cmb_Status.Size = New System.Drawing.Size(182, 21)
        Me.Cmb_Status.TabIndex = 5
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.Color.Transparent
        Me.Label21.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label21.Location = New System.Drawing.Point(1, 102)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(42, 14)
        Me.Label21.TabIndex = 100052
        Me.Label21.Text = "Status"
        '
        'Cmb_PatientType
        '
        Me.Cmb_PatientType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_PatientType.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_PatientType.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_PatientType.FormattingEnabled = True
        Me.Cmb_PatientType.ItemHeight = 13
        Me.Cmb_PatientType.Location = New System.Drawing.Point(76, 35)
        Me.Cmb_PatientType.Name = "Cmb_PatientType"
        Me.Cmb_PatientType.Size = New System.Drawing.Size(182, 21)
        Me.Cmb_PatientType.TabIndex = 3
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label14.Location = New System.Drawing.Point(1, 41)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(75, 14)
        Me.Label14.TabIndex = 117
        Me.Label14.Text = "Patient Type"
        '
        'Cmb_BillingMethod
        '
        Me.Cmb_BillingMethod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_BillingMethod.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_BillingMethod.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_BillingMethod.FormattingEnabled = True
        Me.Cmb_BillingMethod.ItemHeight = 13
        Me.Cmb_BillingMethod.Location = New System.Drawing.Point(76, 66)
        Me.Cmb_BillingMethod.Name = "Cmb_BillingMethod"
        Me.Cmb_BillingMethod.Size = New System.Drawing.Size(182, 21)
        Me.Cmb_BillingMethod.TabIndex = 4
        '
        'Label16
        '
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label16.Location = New System.Drawing.Point(3, 64)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(62, 28)
        Me.Label16.TabIndex = 116
        Me.Label16.Text = "Billing Method"
        '
        'Txt_AmbulatoryStatus
        '
        Me.Txt_AmbulatoryStatus.BackColor = System.Drawing.Color.White
        Me.Txt_AmbulatoryStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_AmbulatoryStatus.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_AmbulatoryStatus.Location = New System.Drawing.Point(361, 3)
        Me.Txt_AmbulatoryStatus.MaxLength = 150
        Me.Txt_AmbulatoryStatus.Multiline = True
        Me.Txt_AmbulatoryStatus.Name = "Txt_AmbulatoryStatus"
        Me.Txt_AmbulatoryStatus.Size = New System.Drawing.Size(437, 21)
        Me.Txt_AmbulatoryStatus.TabIndex = 6
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label12.Location = New System.Drawing.Point(290, 6)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(81, 31)
        Me.Label12.TabIndex = 112
        Me.Label12.Text = "Ambulatory Status"
        '
        'Cmb_ArrivalMode
        '
        Me.Cmb_ArrivalMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_ArrivalMode.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_ArrivalMode.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_ArrivalMode.FormattingEnabled = True
        Me.Cmb_ArrivalMode.ItemHeight = 13
        Me.Cmb_ArrivalMode.Location = New System.Drawing.Point(76, 4)
        Me.Cmb_ArrivalMode.Name = "Cmb_ArrivalMode"
        Me.Cmb_ArrivalMode.Size = New System.Drawing.Size(182, 21)
        Me.Cmb_ArrivalMode.TabIndex = 2
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label10.Location = New System.Drawing.Point(1, 9)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(77, 14)
        Me.Label10.TabIndex = 110
        Me.Label10.Text = "Arrival Mode"
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Print)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_CancelOP)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(435, 512)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(363, 34)
        Me.Pnl_Common_Btn.TabIndex = 5
        '
        'Btn_Print
        '
        Me.Btn_Print.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Print.BackgroundImage = CType(resources.GetObject("Btn_Print.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Print.Enabled = False
        Me.Btn_Print.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Print.ForeColor = System.Drawing.Color.White
        Me.Btn_Print.Location = New System.Drawing.Point(74, 3)
        Me.Btn_Print.Name = "Btn_Print"
        Me.Btn_Print.Size = New System.Drawing.Size(71, 26)
        Me.Btn_Print.TabIndex = 2
        Me.Btn_Print.Text = "&Print"
        Me.Btn_Print.UseVisualStyleBackColor = False
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Clear.Location = New System.Drawing.Point(216, 3)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(71, 26)
        Me.Btn_Clear.TabIndex = 4
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Close.Location = New System.Drawing.Point(287, 3)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(71, 26)
        Me.Btn_Close.TabIndex = 5
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_CancelOP
        '
        Me.Btn_CancelOP.BackgroundImage = CType(resources.GetObject("Btn_CancelOP.BackgroundImage"), System.Drawing.Image)
        Me.Btn_CancelOP.Enabled = False
        Me.Btn_CancelOP.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_CancelOP.Location = New System.Drawing.Point(145, 3)
        Me.Btn_CancelOP.Name = "Btn_CancelOP"
        Me.Btn_CancelOP.Size = New System.Drawing.Size(71, 26)
        Me.Btn_CancelOP.TabIndex = 3
        Me.Btn_CancelOP.Text = "Ca&ncel OP"
        Me.Btn_CancelOP.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = CType(resources.GetObject("Btn_Save.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Save.Enabled = False
        Me.Btn_Save.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(3, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(71, 26)
        Me.Btn_Save.TabIndex = 1
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Panel4
        '
        Me.Panel4.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel4.Location = New System.Drawing.Point(267, 140)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(6, 187)
        Me.Panel4.TabIndex = 100052
        '
        'OP_Register_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(802, 548)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Pnl_2)
        Me.Controls.Add(Me.Pnl_Doc)
        Me.Controls.Add(Me.Pnl_1)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.Pnl_3)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "OP_Register_Frm"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Pnl_1.ResumeLayout(False)
        Me.Pnl_1.PerformLayout()
        Me.Pnl_Tran_mode.ResumeLayout(False)
        Me.Pnl_Doc.ResumeLayout(False)
        Me.Pnl_Doc.PerformLayout()
        Me.Pnl_Doctors.ResumeLayout(False)
        Me.Pnl_Doctors.PerformLayout()
        Me.TlStrp_Doctors.ResumeLayout(False)
        Me.TlStrp_Doctors.PerformLayout()
        Me.Pnl_2.ResumeLayout(False)
        Me.Pnl_2.PerformLayout()
        Me.Pnl_Apoint.ResumeLayout(False)
        Me.Pnl_Apoint.PerformLayout()
        Me.Pnl_Othersdetails.ResumeLayout(False)
        Me.Pnl_Othersdetails.PerformLayout()
        Me.Pnl_3.ResumeLayout(False)
        Me.Pnl_3.PerformLayout()
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Heading As System.Windows.Forms.Label
    Friend WithEvents Pnl_1 As System.Windows.Forms.Panel
    Friend WithEvents Pnl_Doc As System.Windows.Forms.Panel
    Friend WithEvents Pnl_Doctors As System.Windows.Forms.Panel
    Friend WithEvents TlStrp_Doctors As System.Windows.Forms.ToolStrip
    Friend WithEvents Cmb_Service As System.Windows.Forms.ComboBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Pnl_2 As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Btn_AppIDF2 As System.Windows.Forms.Button
    Friend WithEvents Txt_ApointID As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Othersdetails As System.Windows.Forms.Panel
    Friend WithEvents Txt_Visitor_Familyname As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_SSNO As System.Windows.Forms.TextBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_Age As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_Mobile As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_Phone As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_Addr As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Visitor_Name As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Txt_PatientID As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Pnl_3 As System.Windows.Forms.Panel
    Friend WithEvents Cmb_ArrivalMode As System.Windows.Forms.ComboBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Txt_AmbulatoryStatus As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Cmb_PatientType As System.Windows.Forms.ComboBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Cmb_BillingMethod As System.Windows.Forms.ComboBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Status As System.Windows.Forms.ComboBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Trancontrol1 As Tran_Controls.Trancontrol
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_CancelOP As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Lbl_Mesageaproxtime As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Lbl_MesageTokenno As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Doctordetails As System.Windows.Forms.Label
    Friend WithEvents Btn_Appointment As System.Windows.Forms.Button
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Btn_PMRIDF2 As System.Windows.Forms.Button
    Friend WithEvents Txt_PMRID As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Txt_OPID As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Btn_Find As System.Windows.Forms.Button
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Txt_Nationality As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Gender As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Visitortype As System.Windows.Forms.TextBox
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Btn_Print As System.Windows.Forms.Button
    Friend WithEvents ToolStripButton1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents Txt_Remarks As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Btn_New As System.Windows.Forms.Button
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Visittype As System.Windows.Forms.ComboBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Lbl_OPValidDays As System.Windows.Forms.Label
    Friend WithEvents Lbl_OPValidity As System.Windows.Forms.Label
    Friend WithEvents Btn_Followupreg As System.Windows.Forms.Button
    Friend WithEvents Pnl_Apoint As System.Windows.Forms.Panel
End Class
