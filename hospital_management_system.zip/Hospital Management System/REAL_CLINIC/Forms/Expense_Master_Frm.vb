﻿
Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls
Public Class Expense_Master_Frm

#Region "Declarations"
    'Variable declaration/ object for Business Layer objects

    Private mTr_Mode As Tran_Mode
    Private hms_helper As HMS_Helper = Nothing
    Private Expense_BL As Expense_BL_Cls
    'Private Com_Bl As HMS_Common_BL_Cls


    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode2.Text = "NEW MODE"
                    Me.Lbl_Tran_Mode1.Text = "NEW MODE"
                    Me.Txt_ExpGroupID.BackColor = Color.White
                    Me.Txt_ExpID.BackColor = Color.White
                    Me.Txt_ExpGroupName.BackColor = Color.White
                    Me.Txt_ExpName.BackColor = Color.White
                    Me.Txt_ExpGroupID.ReadOnly = False
                    Me.Txt_ExpID.ReadOnly = False
                    Me.Txt_ExpGroupName.ReadOnly = False
                    Me.Txt_ExpName.ReadOnly = False

                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode2.Text = "EDIT MODE"
                    Me.Lbl_Tran_Mode1.Text = "EDIT MODE"
                    Me.Txt_ExpGroupID.BackColor = Color.Silver
                    Me.Txt_ExpID.BackColor = Color.Silver
                    'Me.Txt_ExpGroupName.BackColor = Color.Silver
                    'Me.Txt_ExpName.BackColor = Color.Silver
                    Me.Txt_ExpGroupID.ReadOnly = True
                    Me.Txt_ExpID.ReadOnly = True
                    'Me.Txt_ExpGroupName.ReadOnly = True
                    'Me.Txt_ExpName.ReadOnly = True
            End Select
        End Set

    End Property


#End Region


    Private Sub Account_Head_Frm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try

            REM Account Group Filling  

            Expense_BL = New Expense_BL_Cls
            'resource [accountheads|GetAccountGroup]
            ' fill Expense Group
            Expense_BL.Fill_ExpenseGroup(Cmb_ExpParrantGroup, "Not Applicable")
            Expense_BL.Fill_ExpenseGroup(Cmb_GrpName, "< Select >")
            Expense_BL.Fill_ExpenseMaster(Cmb_ParrentExpID, "Not Applicable")

            REM filling values to grid
                Call Fill_GroupDetails()
            'Call Fill_HeadDetails()


            Cmb_GroupActive.Items.Clear()
            With Cmb_GroupActive
                .Items.Add("Yes")
                .Items.Add("No")
                .SelectedIndex = 0
            End With

            Cmb_ExpActive.Items.Clear()
            With Cmb_ExpActive
                .Items.Add("Yes")
                .Items.Add("No")
                .SelectedIndex = 0
            End With


            Cmb_DiscAllowed.Items.Clear()
            With Cmb_DiscAllowed
                .Items.Add("Yes")
                .Items.Add("No")
                .SelectedIndex = 0
            End With

            Btn_Delete.Enabled = False

            Txt_ExpGroupID.Focus()
            SendKeyTab()

           
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    'Group
    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

    'Master
    Private Sub Btn_Close1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close1.Click
        Me.Close()
    End Sub

    'Group
    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Call Clear_Form()
        Txt_ExpGroupID.Focus()
    End Sub

    'Master
    Private Sub Btn_Clear1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear1.Click
        Call Clear_Form()
        Txt_ExpID.Focus()
    End Sub

    'Saving Expense Group details
    Private Sub Btn_Save_Click(ByVal sendr As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try

            'Validating Data controls
            If Not Validate_Fields() Then Exit Sub
            ' declaration of variables for data reading 
            Dim dr As DataTableReader = Nothing
            Dim dtbl As DataTable = Nothing

            'Initialising  object for BL
            Expense_BL = New Expense_BL_Cls

            'assigning values to propeties for saving
            Expense_BL.Exp_GrpID = IIf(Tr_Mode <> Tran_Mode.New_Mode, Txt_ExpGroupID.Text, 0)
            Expense_BL.Exp_Groupname = Txt_ExpGroupName.Text
            Expense_BL.Exp_GrpOrder = Txt_ExpGroup_Order.Text
            Expense_BL.Exp_GrpParentID = Cmb_ExpParrantGroup.SelectedValue
            Expense_BL.Exp_GrpActive = Strings.Left(Cmb_GroupActive.Text, 1)

            'Save function from BL
            'resource:accountHeads|[Save_AccountGroup]
            If Expense_BL.Save_Expense_Groupe(dtbl, Tr_Mode, Val(Txt_ExpGroupID.Text)) Then
                MessageBox.Show("Expense Group Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)

                Expense_BL.Fill_ExpenseGroup(Cmb_ExpParrantGroup, "Not Applicable")
                Call AssignToControl(dtbl)
                Call Fill_GroupDetails()
                Btn_Clear.Focus()
            Else
                MessageBox.Show("Expense Group Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)

        End Try

    End Sub

    'Saving Expense head Details
    Private Sub Btn_Save1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save1.Click
        Try

            'Validating Data controls
            If Not Validate_Fields() Then Exit Sub
            ' declaration of variables for data reading 

            Dim dtbl As DataTable = Nothing

            'creating object for BL
            Expense_BL = New Expense_BL_Cls

            'assigning values to propeties for saving
            Expense_BL.Exp_ID = IIf(Tr_Mode <> Tran_Mode.New_Mode, Txt_ExpID.Text, 0)
            Expense_BL.Exp_Name = Txt_ExpName.Text
            Expense_BL.Exp_Order = Txt_ExpOrder.Text
            Expense_BL.Exp_ParentID = Cmb_ParrentExpID.SelectedValue
            Expense_BL.Exp_GrpID = Cmb_GrpName.SelectedValue
            Expense_BL.Exp_Discountallowed = Strings.Left(Cmb_DiscAllowed.Text, 1)
            Expense_BL.Exp_Active = Strings.Left(Cmb_ExpActive.Text, 1)


            'Save function from BL
            'resource [AccountHeads|Save_AccountHead]
            If Expense_BL.Save_Expense_Master(dtbl, Tr_Mode, Val(Txt_ExpID.Text)) Then
                MessageBox.Show("Expense Head  Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)

                Expense_BL.Fill_ExpenseMaster(Cmb_ParrentExpID, "Not Applicable")
                Call AssignToControl(dtbl)
                Call Fill_HeadDetails()
                Btn_Clear1.Focus()
            Else
                MessageBox.Show("Expense Head Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub
   
    'Group
    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try

            'search engine
            If Txt_ExpGroupID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "50|100|100|100|10"
                Sql = "SELECT *  FROM  dBO.Get_ExpenseGrpAll_Vw where Br_Code=" & Branch_Code & ""
                Call ShowSearchengine(Txt_ExpGroupID, Sql, 0, "[Group]", Colwidth, , 0)
            End If

            'Validating Mandatory fields for locating
            If Txt_ExpGroupID.Text.Trim = "" Then
                'MessageBox.Show("Invalid Group ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_ExpGroupID.Focus() : Exit Sub
            End If

            If Locate_Values_Group(Txt_ExpGroupID.Text) Then
                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Delete.Enabled = True
                Txt_ExpGroupName.Focus()
            Else
                MessageBox.Show("Group ID does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    'Master
    Private Sub Btn_Find1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find1.Click
        Try

            ' search engine
            If Txt_ExpID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "50|100|100|100|10"
                Sql = "Select * From Get_ExpMasterAll_Vw where Br_Code=" & Branch_Code & ""
                Call ShowSearchengine(Txt_ExpID, Sql, 0, "[Name]", Colwidth, , 0)
            End If


            'Validating Mandatory fields for locating
            If Txt_ExpID.Text.Trim = "" Then
                ' MessageBox.Show("Invalid Head ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_ExpID.Focus() : Exit Sub
            End If

            If Locate_Values_ExpenseMaster(Txt_ExpID.Text) Then
                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Delete1.Enabled = True
                Txt_ExpID.Focus()
            Else
                MessageBox.Show("Head ID does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    'delete Expense group
    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click
        Try
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If

            If MessageBox.Show("Are You Sure Delete the Account Group ", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.No Then Exit Sub
            Expense_BL = New Expense_BL_Cls
            If Expense_BL.Del_ExpGroup(Txt_ExpGroupID.Text) Then
                MessageBox.Show("Expense Group Deleted Successfully", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)

                Call Fill_GroupDetails()
                Call Clear_Form()
                Expense_BL.Fill_ExpenseGroup(Cmb_ExpParrantGroup, "Not Applicable")
            Else
                MessageBox.Show("You cannot delete this Expense Group" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Btn_Clear.Focus()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    'delete Expense master
    Private Sub Btn_Delete1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete1.Click
        Try
            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If

            If MessageBox.Show("Are You Sure Delete the Account Head ", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.No Then Exit Sub
            Expense_BL = New Expense_BL_Cls
            If Expense_BL.Del_ExpMaster(Txt_ExpID.Text) Then
                MessageBox.Show("Expense Head Deleted Successfully", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Call Fill_HeadDetails()
                Call Clear_Form()
            Else
                MessageBox.Show("You cannot delete this Expense Head" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Btn_Clear1.Focus()

            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Murali
    Public Function SetGrid_Colwidth(ByVal Req_Colwidth As String, ByVal Dgrd As Object) As Boolean
        Try

            Dim Col_Width() As String
            Col_Width = Split(Req_Colwidth, "|")
            If Col_Width.Length > 0 Then
                Dim i_Ctr As Short = 0
                With Dgrd
                    For i_Ctr = 0 To Col_Width.Length - 1
                        If .Columns.Count >= i_Ctr And Col_Width(i_Ctr).ToString.Trim <> "" Then
                            .Columns(i_Ctr).MinimumWidth = CInt(Col_Width(i_Ctr).ToString.Trim)
                        End If
                    Next
                End With
            End If
            Return True
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function

    Private Sub Txt_ExpGroupName_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_ExpGroupName.KeyUp
        Try
            If Tr_Mode = Tran_Mode.New_Mode Then
                If Txt_ExpGroupName.Text.Trim = String.Empty Then Return

                With Grid_Searchhelper1
                    .Search_Query = "SELECT Distinct Exp_Groupname, Exp_GrpID"
                    .Search_Query += " FROM Exp_Groupmaster_Tbl "
                    .Search_Query += " WHERE     (Br_Code <> " & Branch_Code & ") AND Exp_Groupname LIKE "
                    .Show_Result(Txt_ExpGroupName, Txt_ExpGroupID)
                End With
            End If
        Catch ex As Exception

        End Try
    End Sub

   

    

    'getting max Expense group order
    Private Sub Txt_GroupName_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_ExpGroupName.Validating
        Try

        
            'Getting Max account group order
            'return true or false
            ' If Txt_ExpGroupName.Text <> "" And Cmb_ExpParrantGroup.Items.Count > 0 Then

            hms_helper = New Hms_Helperimpliments
            If Tr_Mode = Tran_Mode.New_Mode Then
                If hms_helper.Check_Duplicatedataexists("Exp_Groupmaster_Tbl", "Exp_Groupname", Data_Type.General_Type, Txt_ExpGroupName.Text.Trim, Branch_Code) Then
                    MessageBox.Show("Expence Group Already Exist,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_ExpGroupName.Focus()
                    Txt_ExpGroupName.Text = ""
                    Txt_ExpGroupID.Text = ""
                    e.Cancel = True
                    Exit Sub
                End If
                If Txt_ExpGroupName.Tag <> "" Then
                    Locate_Exp_Group_Valueshelper(Txt_ExpGroupName.Tag)
                    Txt_ExpGroup_Order.Focus()
                    Exit Sub
                End If
            Else
                If hms_helper.Check_Duplicatedataexists("Exp_Groupmaster_Tbl", "Exp_Groupname", Data_Type.General_Type, Txt_ExpGroupName.Text.Trim, Branch_Code, , "Exp_GrpID", Data_Type.Integer_Type, Txt_ExpGroupID.Text.Trim) Then
                    MessageBox.Show("Expense Head Already Exist .", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_ExpName.Focus()
                    Txt_ExpName.Text = ""
                    e.Cancel = True
                End If

            End If

            If Txt_ExpGroup_Order.Text = "" Then
                If Txt_ExpGroupName.Text <> "" And Tr_Mode = Tran_Mode.New_Mode Then
                    Expense_BL = New Expense_BL_Cls
                    Txt_ExpGroup_Order.Text = Expense_BL.Get_MaxExpenseGrporder()
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_ExpName_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_ExpName.KeyUp

        Try

            If Txt_ExpName.Text.Trim = String.Empty Then Return
            If Me.Tr_Mode <> Tran_Mode.New_Mode Then Return
            With Grid_Searchhelper2
                .Search_Query = "Select Distinct Exp_Name,Exp_ID "
                .Search_Query += " from Expense_Master_Tbl "
                .Search_Query += " Where (Br_Code <> " & Branch_Code & ") and Exp_Name like "
                .Show_Result(Txt_ExpName, Txt_ExpID)

            End With
        Catch ex As Exception

        End Try


    End Sub

    Private Sub Account_Head_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub Tab_AccountHead_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tab_AccountHead.SelectedIndexChanged
        Try


            Call Clear_Form()
            If Tab_AccountHead.SelectedIndex = 0 Then
                Txt_ExpGroupID.Focus()
                Call Fill_GroupDetails()

                Expense_BL.Fill_ExpenseGroup(Cmb_ExpParrantGroup, "Not Applicable")
            Else
                Expense_BL.Fill_ExpenseGroup(Cmb_GrpName, "< Select >")
                Expense_BL.Fill_ExpenseMaster(Cmb_ParrentExpID, "Not Applicable")

                Txt_ExpID.Focus()
                Call Fill_HeadDetails()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_GroupID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_ExpGroupID.KeyDown

    End Sub

    Private Sub Txt_Group_Order_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_ExpGroup_Order.KeyPress
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_ExpGroup_Order.Text, Data_Type.Integer_Type, 12))
    End Sub

    Private Sub Txt_HeadOrder_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_ExpOrder.KeyPress
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_ExpGroup_Order.Text, Data_Type.Integer_Type, 12))
    End Sub

    Private Sub Txt_GroupID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_ExpGroupID.TextChanged
        If Txt_ExpGroupID.Text = "" Then
            Call Clear_Form()
        End If
    End Sub

    Private Sub Txt_HeadID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_ExpID.KeyDown
        If e.KeyCode = Keys.F2 Then Btn_Find1_Click(sender, e)
    End Sub

    Private Sub Txt_HeadID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_ExpID.TextChanged
        If Txt_ExpID.Text = "" Then Call Clear_Form()
    End Sub

    Private Sub Account_Head_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then Call SendKeyTab()
        If e.KeyCode = Keys.F2 Then Btn_Find_Click(sender, e)

    End Sub

    Private Sub Dgrd_History_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Dgrd_History.DoubleClick
        Try
            With Dgrd_History
                If .CurrentRow Is Nothing Then Exit Sub
                Txt_ExpGroupID.Text = .Item(0, .CurrentCell.RowIndex).Value.ToString.Trim
                Call Btn_Find_Click(sender, e)
                Txt_ExpGroupID.Focus()
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgrd_History1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Dgrd_History1.DoubleClick
        Try
            With Dgrd_History1
                If .CurrentRow Is Nothing Then Exit Sub
                Txt_ExpID.Text = .Item(0, .CurrentCell.RowIndex).Value.ToString.Trim
                Call Btn_Find1_Click(sender, e)
                Txt_ExpID.Focus()
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_ExpGroupID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_ExpGroupID.Validating
        Try
            If Me.Txt_ExpGroupID.Text.Trim <> "" And Me.Txt_ExpGroupID.Text <> Me.Txt_ExpGroupID.Tag Then
                If Locate_Values_Group(Txt_ExpGroupID.Text.Trim) Then

                    Tr_Mode = Tran_Mode.Edit_Mode
                    Btn_Delete.Enabled = True
                Else
                    MessageBox.Show("Expense Group ID does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Txt_ExpGroupID.Focus()
                    e.Cancel = True
                End If
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_ExpID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_ExpID.Validating
        Try

            If Me.Txt_ExpID.Text.Trim <> "" And Me.Txt_ExpID.Text <> Me.Txt_ExpID.Tag Then
                If Locate_Values_ExpenseMaster(Txt_ExpID.Text.Trim) Then

                    Tr_Mode = Tran_Mode.Edit_Mode
                    Btn_Delete.Enabled = True
                Else
                    MessageBox.Show("Expense Master ID does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Txt_ExpID.Focus()
                    e.Cancel = True
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

#Region "Functions"

    Private Sub AssignToControl(ByVal dtbl As DataTable)
        Try

            Dim dr As DataTableReader = Nothing
            REM Account Group 
            If Tab_AccountHead.SelectedIndex = 0 Then

                dr = dtbl.CreateDataReader()
                dr.Read()
                With dr
                    Txt_ExpGroupID.Text = .Item("Exp_GrpID").ToString
                    Txt_ExpGroupName.Text = .Item("Exp_Groupname").ToString
                    Txt_ExpGroup_Order.Text = .Item("Exp_GrpOrder").ToString
                    Cmb_ExpParrantGroup.SelectedValue = .Item("Exp_GrpParentID").ToString

                    If .Item("Exp_GrpActive").ToString = "Y" Then
                        Cmb_GroupActive.SelectedIndex = 0
                    Else
                        Cmb_GroupActive.SelectedIndex = 1
                    End If

                   

                End With

            Else
                REM Account heads
                dr = dtbl.CreateDataReader()
                dr.Read()
                With dr

                    Txt_ExpID.Text = .Item("Exp_ID").ToString
                    Txt_ExpName.Text = .Item("Exp_Name").ToString
                    Txt_ExpOrder.Text = .Item("Exp_Order").ToString
                    Cmb_ParrentExpID.SelectedValue = .Item("Exp_ParentID").ToString
                    Cmb_GrpName.SelectedValue = .Item("Exp_GrpID").ToString

                    If .Item("Exp_Discountallowed").ToString = "Y" Then
                        Cmb_DiscAllowed.SelectedIndex = 0
                    Else
                        Cmb_DiscAllowed.SelectedIndex = 1
                    End If

                    If .Item("Exp_Active").ToString = "Y" Then
                        Cmb_ExpActive.SelectedIndex = 0
                    Else
                        Cmb_ExpActive.SelectedIndex = 1
                    End If

                   
                End With
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Clear_Form()
        Try

            If Tab_AccountHead.SelectedIndex = 0 Then
                Txt_ExpGroupID.Text = ""
                Txt_ExpGroupName.Text = ""
                Txt_ExpGroupName.Tag = ""
                Txt_ExpGroup_Order.Text = ""
                If Cmb_GroupActive.Items.Count > 0 Then Cmb_GroupActive.SelectedIndex = 0
                If Cmb_ExpParrantGroup.Items.Count > 0 Then Cmb_ExpParrantGroup.SelectedIndex = 0


                Tr_Mode = Tran_Mode.New_Mode
                Btn_Save.Enabled = True
                Btn_Delete.Enabled = False
            Else
                Txt_ExpName.Text = ""
                Txt_ExpOrder.Text = ""
                Txt_ExpID.Text = ""

                If Cmb_ExpActive.Items.Count > 0 Then Cmb_ExpActive.SelectedIndex = 0
                If Cmb_ParrentExpID.Items.Count > 0 Then Cmb_ParrentExpID.SelectedIndex = 0
                If Cmb_GrpName.Items.Count > 0 Then Cmb_GrpName.SelectedIndex = 0
                If Cmb_DiscAllowed.Items.Count > 0 Then Cmb_DiscAllowed.SelectedIndex = 0
                Tr_Mode = Tran_Mode.New_Mode
                Btn_Save1.Enabled = True
                Btn_Delete1.Enabled = False
            End If

        Catch ex As Exception

        End Try
    End Sub

    'function for validate fields 
    'return boolean
    Private Function Validate_Fields() As Boolean
        Try

            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If

            If Tab_AccountHead.SelectedIndex = 0 Then

                If Tr_Mode <> Tran_Mode.New_Mode Then
                    If Txt_ExpGroupID.Text.Trim = "" Then MessageBox.Show("Invalid Expense Group ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_ExpGroupID.Focus() : Exit Function
                End If
                'Assigning Default values
                If Txt_ExpGroupName.Text.Trim = "" Then MessageBox.Show("Invalid Expense Group Name, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_ExpGroupName.Focus() : Exit Function
                If Txt_ExpGroup_Order.Text.Trim = "" Then MessageBox.Show("Invalid Expense Group Order, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_ExpGroup_Order.Focus() : Exit Function
                Return True

            Else
                If Tr_Mode <> Tran_Mode.New_Mode Then
                    If Txt_ExpID.Text.Trim = "" Then MessageBox.Show("Invalid Expense Head ID, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_ExpID.Focus() : Exit Function
                End If

                'Assigning Default values
                If Txt_ExpName.Text.Trim = "" Then MessageBox.Show("Invalid Expense Head Name, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_ExpName.Focus() : Exit Function
                If Txt_ExpOrder.Text.Trim = "" Then MessageBox.Show("Invalid Expense Head Order, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_ExpOrder.Focus() : Exit Function
                If Cmb_GrpName.SelectedIndex <= 0 Then MessageBox.Show("Invalid Expense Group Name, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_GrpName.Focus() : Exit Function

                Return True
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try

    End Function
    'function for fill Group details into grid
    'return boolean
    Public Function Fill_GroupDetails() As Boolean
        Try

            'declaring variable for data reading
            Dim dtbl As DataTable = Nothing
            Dim dr As DataTableReader = Nothing

            'initialising BL Object
            Expense_BL = New Expense_BL_Cls
            'resource name [accounts|Get_ExpenseGrpAll]
            Dgrd_History.DataSource = Nothing

            If Expense_BL.Get_ExpenseGrpAll(dtbl) Then
                Dgrd_History.DataSource = dtbl
                SetGrid_Colwidth("10|150|140|10", Dgrd_History)
                Dgrd_History.Refresh()
                Return True
            Else
                Return False
            End If

            dr = Nothing
            dtbl = Nothing
        Catch ex As Exception
            Return False
        End Try
    End Function
    'Locating Group details
    'return Boolean
    Public Function Locate_Values_Group(ByVal Group_ID As String) As Boolean
        Try


            'dim variable declaration for data retrive
            Dim dr As DataTableReader = Nothing
            Dim dtbl As DataTable = Nothing

            'initialising BL Object
            Expense_BL = New Expense_BL_Cls
            'resource name [accounts|Get_ExpGroupMaster]
            If Expense_BL.Get_ExpGroupMaster(dtbl, Group_ID) Then
                dr = dtbl.CreateDataReader
                dr.Read()
                With dr

                    Txt_ExpGroupName.Text = .Item("Exp_Groupname").ToString
                    Txt_ExpGroupName.Tag = .Item("Exp_Groupname").ToString

                    Txt_ExpGroup_Order.Text = .Item("Exp_GrpOrder").ToString
                    Cmb_ExpParrantGroup.SelectedValue = .Item("Exp_GrpParentID").ToString
                    If .Item("Exp_GrpActive").ToString = "Y" Then
                        Cmb_GroupActive.SelectedIndex = 0
                    Else
                        Cmb_GroupActive.SelectedIndex = 1
                    End If

                End With
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            Return False
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Function


    'Location Account master Details
    'return boolean
    Public Function Locate_Values_ExpenseMaster_Valueshelper(ByVal Exp_ID As String) As Boolean
        Try


            'dim variable declaration for data retrive
            Dim dr As DataTableReader = Nothing
            Dim dtbl As DataTable = Nothing

            'initialising BL Object
            Expense_BL = New Expense_BL_Cls

            If Expense_BL.Get_ExpMaster_OtherBranch(dtbl, Exp_ID) Then
                dr = dtbl.CreateDataReader
                dr.Read()
                With dr
                    Txt_ExpID.Text = .Item("Exp_ID").ToString
                    Txt_ExpName.Text = .Item("Exp_Name").ToString
                    Txt_ExpOrder.Text = .Item("Exp_Order").ToString

                    If Isexistsinlist(Cmb_GrpName, .Item("Expence Group").ToString) Then
                        Cmb_GrpName.SelectedValue = .Item("Exp_GrpID")
                    Else
                        Txt_ExpID.Text = ""
                        Txt_ExpName.Text = ""
                        Txt_ExpOrder.Text = ""
                        Txt_ExpName.Tag = ""
                        MessageBox.Show("In Expence Group , " & .Item("Expence Group").ToString() & " Not Found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Txt_ExpName.Focus()
                        Exit Function
                    End If

                    Cmb_ParrentExpID.SelectedValue = .Item("Exp_ParentID")
                    Cmb_GrpName.SelectedValue = .Item("Exp_GrpID")
                    If .Item("Exp_Active").ToString = "Y" Then
                        Cmb_ExpActive.SelectedIndex = 0
                    Else
                        Cmb_ExpActive.SelectedIndex = 1
                    End If

                    If .Item("Exp_Discountallowed").ToString = "Y" Then
                        Cmb_DiscAllowed.SelectedIndex = 0
                    Else
                        Cmb_DiscAllowed.SelectedIndex = 1
                    End If

                    Txt_ExpID.ReadOnly = True
                    Txt_ExpID.BackColor = Color.Silver
                    Txt_ExpName.BackColor = Color.Silver
                    Txt_ExpName.ReadOnly = True
                End With
                Return True
            Else

                Return False
            End If

        Catch ex As Exception
            Return False
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Function

    Public Function Locate_Values_ExpenseMaster(ByVal Exp_ID As String) As Boolean
        Try


            'dim variable declaration for data retrive
            Dim dr As DataTableReader = Nothing
            Dim dtbl As DataTable = Nothing

            'initialising BL Object
            Expense_BL = New Expense_BL_Cls

            If Expense_BL.Get_ExpMaster(dtbl, Exp_ID) Then
                dr = dtbl.CreateDataReader
                dr.Read()
                With dr
                    Txt_ExpID.Text = .Item("Exp_ID").ToString
                    Txt_ExpName.Text = .Item("Exp_Name").ToString
                    Txt_ExpOrder.Text = .Item("Exp_Order").ToString
                    Cmb_ParrentExpID.SelectedValue = .Item("Exp_ParentID")
                    Cmb_GrpName.SelectedValue = .Item("Exp_GrpID")
                    If .Item("Exp_Active").ToString = "Y" Then
                        Cmb_ExpActive.SelectedIndex = 0
                    Else
                        Cmb_ExpActive.SelectedIndex = 1
                    End If

                    If .Item("Exp_Discountallowed").ToString = "Y" Then
                        Cmb_DiscAllowed.SelectedIndex = 0
                    Else
                        Cmb_DiscAllowed.SelectedIndex = 1
                    End If

                End With
                Return True
            Else

                Return False
            End If

        Catch ex As Exception
            Return False
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Function

    Public Function Locate_Exp_Group_Valueshelper(ByVal Exp_ID As String) As Boolean
        Try


            'dim variable declaration for data retrive
            Dim dr As DataTableReader = Nothing
            Dim dtbl As DataTable = Nothing

            'initialising BL Object
            Expense_BL = New Expense_BL_Cls

            If Expense_BL.Get_ExpGroupMaster_OtherBranch(dtbl, Exp_ID) Then
                dr = dtbl.CreateDataReader
                dr.Read()
                With dr
                    Txt_ExpGroupName.Text = .Item("Exp_Groupname").ToString
                    Txt_ExpGroupName.Tag = .Item("Exp_Groupname").ToString

                    Txt_ExpGroup_Order.Text = .Item("Exp_GrpOrder").ToString
                    Cmb_ExpParrantGroup.SelectedValue = .Item("Exp_GrpParentID").ToString
                    If .Item("Exp_GrpActive").ToString = "Y" Then
                        Cmb_GroupActive.SelectedIndex = 0
                    Else
                        Cmb_GroupActive.SelectedIndex = 1
                    End If

                    Txt_ExpGroupName.ReadOnly = True
                    Txt_ExpGroupName.BackColor = Color.Silver
                    Txt_ExpGroupID.ReadOnly = True
                    Txt_ExpGroupID.BackColor = Color.Silver


                End With
                Return True
            Else

                Return False
            End If

        Catch ex As Exception
            'Return False
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Function
    ''function for fill account master details into grid
    'return boolean
    Public Function Fill_HeadDetails() As Boolean
        Try

            'declaring variable for data reading
            Dim dtbl As DataTable = Nothing
            Dim dr As DataTableReader = Nothing

            'initialising BL Object
            Expense_BL = New Expense_BL_Cls
            Dgrd_History1.DataSource = Nothing

            If Expense_BL.Get_ExpMasterAll(dtbl) Then
                Dgrd_History1.DataSource = dtbl
                SetGrid_Colwidth("10|50|50|50|", Dgrd_History1)
                Dgrd_History1.Refresh()
                Return True
            Else
                Return False
            End If

            dr = Nothing
            dtbl = Nothing
        Catch ex As Exception
            Return False
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function

#End Region

    Private Sub Btn_ExpGroup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_ExpGroup.Click
        Tab_AccountHead.SelectedIndex = 0
    End Sub

    Private Sub Btn_ExpMaster_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_ExpMaster.Click
        Tab_AccountHead.SelectedIndex = 1
    End Sub

   
    Private Sub Txt_ExpName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_ExpName.TextChanged

    End Sub

    Private Sub Txt_ExpGroupName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_ExpGroupName.TextChanged

    End Sub

    Private Sub Txt_ExpName_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_ExpName.Validating
        Try

            'Getting Max account head order
            'return true or false
            hms_helper = New Hms_Helperimpliments
            If Tr_Mode = Tran_Mode.New_Mode Then
                REM duplicate name checking in new mode

                If hms_helper.Check_Duplicatedataexists("Expense_Master_Tbl", "Exp_Name", Data_Type.General_Type, Txt_ExpName.Text.Trim, Branch_Code) Then
                    MessageBox.Show("Expense Head Already Exist .", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_ExpName.Focus()
                    Txt_ExpName.Text = ""
                    Txt_ExpID.Text = ""
                    e.Cancel = True
                    Exit Sub
                End If
                If Txt_ExpName.Tag <> "" Then
                    Locate_Values_ExpenseMaster_Valueshelper(Txt_ExpName.Tag)
                    Exit Sub
                End If
            Else
                REM duplicate name checking in edit mode

                If hms_helper.Check_Duplicatedataexists("Expense_Master_Tbl", "Exp_Name", Data_Type.General_Type, Txt_ExpName.Text.Trim, Branch_Code, , "Exp_ID", Data_Type.Integer_Type, Txt_ExpID.Text.Trim) Then
                    MessageBox.Show("Expense Head Already Exist .", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_ExpName.Focus()
                    Txt_ExpName.Text = ""
                    e.Cancel = True
                End If

            End If

            If Txt_ExpName.Text <> "" And Tr_Mode = Tran_Mode.New_Mode Then
                Expense_BL = New Expense_BL_Cls
                Txt_ExpOrder.Text = Expense_BL.Get_MaxExpenseMasterOrder()
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
End Class