﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PatientInfo_Short_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PatientInfo_Short_Frm))
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Label3 = New System.Windows.Forms.Label
        Me.Txt_Pat_ID = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Txt_Pat_Name = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Delete = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label
        Me.Btn_FindID = New System.Windows.Forms.Button
        Me.Txt_Pat_Age = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Cmb_Pat_Gender = New System.Windows.Forms.ComboBox
        Me.Txt_Pat_Mobile1 = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.Txt_Pat_Phone1 = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Txt_Pat_Add = New System.Windows.Forms.TextBox
        Me.Cmb_Pat_Country = New System.Windows.Forms.ComboBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Dtp_LastAdmitDate = New System.Windows.Forms.DateTimePicker
        Me.Label21 = New System.Windows.Forms.Label
        Me.Dtp_Pat_RegDt = New System.Windows.Forms.DateTimePicker
        Me.Label20 = New System.Windows.Forms.Label
        Me.Txt_Pat_Soc_SecNo = New System.Windows.Forms.TextBox
        Me.Label35 = New System.Windows.Forms.Label
        Me.Btn_Find2 = New System.Windows.Forms.Button
        Me.Txt_FamilyName = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Pnl_Header.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.Pnl_Tran_mode.SuspendLayout()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = CType(resources.GetObject("Pnl_Header.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Header.Controls.Add(Me.Label3)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(521, 24)
        Me.Pnl_Header.TabIndex = 100000
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(3, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(309, 19)
        Me.Label3.TabIndex = 10000
        Me.Label3.Text = "P a t i e n t   I n f o r m a t i o n   S h o r t"
        '
        'Txt_Pat_ID
        '
        Me.Txt_Pat_ID.BackColor = System.Drawing.Color.White
        Me.Txt_Pat_ID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Pat_ID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Pat_ID.ForeColor = System.Drawing.Color.Black
        Me.Txt_Pat_ID.Location = New System.Drawing.Point(126, 43)
        Me.Txt_Pat_ID.MaxLength = 10
        Me.Txt_Pat_ID.Name = "Txt_Pat_ID"
        Me.Txt_Pat_ID.Size = New System.Drawing.Size(128, 21)
        Me.Txt_Pat_ID.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(22, 45)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 13)
        Me.Label2.TabIndex = 115
        Me.Label2.Text = "Patient ID"
        '
        'Txt_Pat_Name
        '
        Me.Txt_Pat_Name.BackColor = System.Drawing.Color.White
        Me.Txt_Pat_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Pat_Name.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Pat_Name.Location = New System.Drawing.Point(126, 101)
        Me.Txt_Pat_Name.MaxLength = 250
        Me.Txt_Pat_Name.Name = "Txt_Pat_Name"
        Me.Txt_Pat_Name.Size = New System.Drawing.Size(380, 21)
        Me.Txt_Pat_Name.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(22, 103)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(83, 13)
        Me.Label1.TabIndex = 117
        Me.Label1.Text = "Patient Name"
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Delete)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(440, 278)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(66, 123)
        Me.Pnl_Common_Btn.TabIndex = 119
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(4, 60)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear.TabIndex = 16
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(4, 88)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 17
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Delete
        '
        Me.Btn_Delete.BackgroundImage = CType(resources.GetObject("Btn_Delete.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Delete.Location = New System.Drawing.Point(4, 32)
        Me.Btn_Delete.Name = "Btn_Delete"
        Me.Btn_Delete.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Delete.TabIndex = 15
        Me.Btn_Delete.Text = "Delete"
        Me.Btn_Delete.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = CType(resources.GetObject("Btn_Save.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(4, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save.TabIndex = 14
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(432, 45)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(74, 21)
        Me.Pnl_Tran_mode.TabIndex = 30000
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(1, 1)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(68, 16)
        Me.Lbl_Tran_Mode.TabIndex = 126
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Btn_FindID
        '
        Me.Btn_FindID.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_FindID.BackgroundImage = CType(resources.GetObject("Btn_FindID.BackgroundImage"), System.Drawing.Image)
        Me.Btn_FindID.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_FindID.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_FindID.ForeColor = System.Drawing.Color.White
        Me.Btn_FindID.Location = New System.Drawing.Point(260, 43)
        Me.Btn_FindID.Name = "Btn_FindID"
        Me.Btn_FindID.Size = New System.Drawing.Size(29, 21)
        Me.Btn_FindID.TabIndex = 1
        Me.Btn_FindID.TabStop = False
        Me.Btn_FindID.Text = "F2"
        Me.Btn_FindID.UseVisualStyleBackColor = False
        '
        'Txt_Pat_Age
        '
        Me.Txt_Pat_Age.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Pat_Age.Cursor = System.Windows.Forms.Cursors.Default
        Me.Txt_Pat_Age.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Pat_Age.Location = New System.Drawing.Point(126, 272)
        Me.Txt_Pat_Age.MaxLength = 3
        Me.Txt_Pat_Age.Name = "Txt_Pat_Age"
        Me.Txt_Pat_Age.Size = New System.Drawing.Size(96, 21)
        Me.Txt_Pat_Age.TabIndex = 8
        Me.Txt_Pat_Age.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label15.Location = New System.Drawing.Point(22, 274)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(29, 13)
        Me.Label15.TabIndex = 171
        Me.Label15.Text = "Age"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.ForeColor = System.Drawing.Color.Black
        Me.Label13.Location = New System.Drawing.Point(22, 246)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(48, 13)
        Me.Label13.TabIndex = 170
        Me.Label13.Text = "Gender"
        '
        'Cmb_Pat_Gender
        '
        Me.Cmb_Pat_Gender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Pat_Gender.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Pat_Gender.FormattingEnabled = True
        Me.Cmb_Pat_Gender.ItemHeight = 13
        Me.Cmb_Pat_Gender.Location = New System.Drawing.Point(126, 243)
        Me.Cmb_Pat_Gender.Name = "Cmb_Pat_Gender"
        Me.Cmb_Pat_Gender.Size = New System.Drawing.Size(96, 21)
        Me.Cmb_Pat_Gender.TabIndex = 7
        '
        'Txt_Pat_Mobile1
        '
        Me.Txt_Pat_Mobile1.BackColor = System.Drawing.Color.White
        Me.Txt_Pat_Mobile1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Pat_Mobile1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Pat_Mobile1.Location = New System.Drawing.Point(126, 359)
        Me.Txt_Pat_Mobile1.MaxLength = 10
        Me.Txt_Pat_Mobile1.Name = "Txt_Pat_Mobile1"
        Me.Txt_Pat_Mobile1.Size = New System.Drawing.Size(215, 21)
        Me.Txt_Pat_Mobile1.TabIndex = 11
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(22, 367)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(54, 13)
        Me.Label11.TabIndex = 169
        Me.Label11.Text = "Mobile 1"
        '
        'Txt_Pat_Phone1
        '
        Me.Txt_Pat_Phone1.BackColor = System.Drawing.Color.White
        Me.Txt_Pat_Phone1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Pat_Phone1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Pat_Phone1.Location = New System.Drawing.Point(126, 330)
        Me.Txt_Pat_Phone1.MaxLength = 11
        Me.Txt_Pat_Phone1.Name = "Txt_Pat_Phone1"
        Me.Txt_Pat_Phone1.Size = New System.Drawing.Size(215, 21)
        Me.Txt_Pat_Phone1.TabIndex = 10
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(22, 332)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(52, 13)
        Me.Label8.TabIndex = 168
        Me.Label8.Text = "Phone 1"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(22, 160)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(53, 13)
        Me.Label4.TabIndex = 167
        Me.Label4.Text = "Address"
        '
        'Txt_Pat_Add
        '
        Me.Txt_Pat_Add.BackColor = System.Drawing.Color.White
        Me.Txt_Pat_Add.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Pat_Add.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Pat_Add.Location = New System.Drawing.Point(126, 160)
        Me.Txt_Pat_Add.MaxLength = 500
        Me.Txt_Pat_Add.Multiline = True
        Me.Txt_Pat_Add.Name = "Txt_Pat_Add"
        Me.Txt_Pat_Add.Size = New System.Drawing.Size(380, 75)
        Me.Txt_Pat_Add.TabIndex = 6
        '
        'Cmb_Pat_Country
        '
        Me.Cmb_Pat_Country.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Pat_Country.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Pat_Country.FormattingEnabled = True
        Me.Cmb_Pat_Country.Location = New System.Drawing.Point(126, 301)
        Me.Cmb_Pat_Country.Name = "Cmb_Pat_Country"
        Me.Cmb_Pat_Country.Size = New System.Drawing.Size(215, 21)
        Me.Cmb_Pat_Country.TabIndex = 9
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label5.Location = New System.Drawing.Point(22, 304)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(52, 13)
        Me.Label5.TabIndex = 173
        Me.Label5.Text = "Country"
        '
        'Dtp_LastAdmitDate
        '
        Me.Dtp_LastAdmitDate.Cursor = System.Windows.Forms.Cursors.Default
        Me.Dtp_LastAdmitDate.CustomFormat = "dd/MM/yyyy"
        Me.Dtp_LastAdmitDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_LastAdmitDate.Location = New System.Drawing.Point(324, 388)
        Me.Dtp_LastAdmitDate.Name = "Dtp_LastAdmitDate"
        Me.Dtp_LastAdmitDate.Size = New System.Drawing.Size(98, 21)
        Me.Dtp_LastAdmitDate.TabIndex = 13
        Me.Dtp_LastAdmitDate.TabStop = False
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.Color.Transparent
        Me.Label21.ForeColor = System.Drawing.Color.Black
        Me.Label21.Location = New System.Drawing.Point(230, 394)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(88, 13)
        Me.Label21.TabIndex = 175
        Me.Label21.Text = "Last Visit Date"
        '
        'Dtp_Pat_RegDt
        '
        Me.Dtp_Pat_RegDt.Cursor = System.Windows.Forms.Cursors.Default
        Me.Dtp_Pat_RegDt.CustomFormat = "dd/MM/yyyy"
        Me.Dtp_Pat_RegDt.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_Pat_RegDt.Location = New System.Drawing.Point(126, 388)
        Me.Dtp_Pat_RegDt.Name = "Dtp_Pat_RegDt"
        Me.Dtp_Pat_RegDt.Size = New System.Drawing.Size(98, 21)
        Me.Dtp_Pat_RegDt.TabIndex = 12
        Me.Dtp_Pat_RegDt.TabStop = False
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.Color.Transparent
        Me.Label20.ForeColor = System.Drawing.Color.Black
        Me.Label20.Location = New System.Drawing.Point(22, 394)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(85, 13)
        Me.Label20.TabIndex = 177
        Me.Label20.Text = "Register Date"
        '
        'Txt_Pat_Soc_SecNo
        '
        Me.Txt_Pat_Soc_SecNo.BackColor = System.Drawing.Color.White
        Me.Txt_Pat_Soc_SecNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Pat_Soc_SecNo.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Pat_Soc_SecNo.Location = New System.Drawing.Point(126, 72)
        Me.Txt_Pat_Soc_SecNo.MaxLength = 50
        Me.Txt_Pat_Soc_SecNo.Name = "Txt_Pat_Soc_SecNo"
        Me.Txt_Pat_Soc_SecNo.Size = New System.Drawing.Size(128, 21)
        Me.Txt_Pat_Soc_SecNo.TabIndex = 2
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.BackColor = System.Drawing.Color.Transparent
        Me.Label35.ForeColor = System.Drawing.Color.Black
        Me.Label35.Location = New System.Drawing.Point(22, 74)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(67, 13)
        Me.Label35.TabIndex = 100004
        Me.Label35.Text = "Soc Sec No"
        '
        'Btn_Find2
        '
        Me.Btn_Find2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find2.BackgroundImage = CType(resources.GetObject("Btn_Find2.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find2.ForeColor = System.Drawing.Color.White
        Me.Btn_Find2.Location = New System.Drawing.Point(260, 72)
        Me.Btn_Find2.Name = "Btn_Find2"
        Me.Btn_Find2.Size = New System.Drawing.Size(29, 21)
        Me.Btn_Find2.TabIndex = 3
        Me.Btn_Find2.TabStop = False
        Me.Btn_Find2.Text = "F2"
        Me.Btn_Find2.UseVisualStyleBackColor = False
        '
        'Txt_FamilyName
        '
        Me.Txt_FamilyName.BackColor = System.Drawing.Color.White
        Me.Txt_FamilyName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_FamilyName.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_FamilyName.Location = New System.Drawing.Point(126, 128)
        Me.Txt_FamilyName.MaxLength = 250
        Me.Txt_FamilyName.Name = "Txt_FamilyName"
        Me.Txt_FamilyName.Size = New System.Drawing.Size(380, 21)
        Me.Txt_FamilyName.TabIndex = 5
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(22, 130)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(79, 13)
        Me.Label6.TabIndex = 100006
        Me.Label6.Text = "Family Name"
        '
        'PatientInfo_Short_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.LeftGradiant
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(521, 463)
        Me.Controls.Add(Me.Txt_FamilyName)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Btn_Find2)
        Me.Controls.Add(Me.Txt_Pat_Soc_SecNo)
        Me.Controls.Add(Me.Label35)
        Me.Controls.Add(Me.Dtp_LastAdmitDate)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Dtp_Pat_RegDt)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Cmb_Pat_Country)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Txt_Pat_Age)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Cmb_Pat_Gender)
        Me.Controls.Add(Me.Txt_Pat_Mobile1)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Txt_Pat_Phone1)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Txt_Pat_Add)
        Me.Controls.Add(Me.Pnl_Tran_mode)
        Me.Controls.Add(Me.Btn_FindID)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.Txt_Pat_Name)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Txt_Pat_ID)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "PatientInfo_Short_Frm"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.Pnl_Tran_mode.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Txt_Pat_ID As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Txt_Pat_Name As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Delete As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Btn_FindID As System.Windows.Forms.Button
    Friend WithEvents Txt_Pat_Age As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Pat_Gender As System.Windows.Forms.ComboBox
    Friend WithEvents Txt_Pat_Mobile1 As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Txt_Pat_Phone1 As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Txt_Pat_Add As System.Windows.Forms.TextBox
    Friend WithEvents Cmb_Pat_Country As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Dtp_LastAdmitDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Dtp_Pat_RegDt As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Txt_Pat_Soc_SecNo As System.Windows.Forms.TextBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Btn_Find2 As System.Windows.Forms.Button
    Friend WithEvents Txt_FamilyName As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
End Class
