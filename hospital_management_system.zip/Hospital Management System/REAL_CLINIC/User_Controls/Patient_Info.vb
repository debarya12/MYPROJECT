﻿

Option Explicit On
Imports HMS_BL

Public Class Patient_Info

    Private HMS_Helper As HMS_Helper
    Private P_Dtbl As DataTable = Nothing

    Private _Viewmoreform_Name As String = ""
    Private _MDI_Form As Form = Nothing
    Private _Patient_ID As String = ""

    Private Sub Clear_Me()
        Try
            Me.PatientName.Text = ""
            Me.Patientaddress.Text = ""
            Me.Patientphone.Text = ""
            Me.PatientSSN.Text = ""
            Me.Patientmobile.Text = ""
            Me.Patientfamilyname.Text = ""
            Me._Patient_ID = ""

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Assign_Values(ByVal Patientinfo_Dtbl As DataTable)
        Try
            Call Clear_Me()
            If Patientinfo_Dtbl Is Nothing Then Exit Sub
            If Patientinfo_Dtbl.Rows.Count = 0 Then Exit Sub

            With Patientinfo_Dtbl
                Me.PatientName.Text = .Rows(0).Item("Name").ToString.ToUpper
                Me.Patientaddress.Text = .Rows(0).Item("Address").ToString
                Me.Patientaddress.Text += vbCrLf & .Rows(0).Item("City").ToString
                Me.Patientaddress.Text += vbCrLf & .Rows(0).Item("State").ToString
                Me.Patientaddress.Text += vbCrLf & .Rows(0).Item("Country").ToString
                Me.Patientfamilyname.Text = .Rows(0).Item("Family Name").ToString
                Me.Patientphone.Text = .Rows(0).Item("Phone1").ToString
                Me.Patientmobile.Text = .Rows(0).Item("Mobile1").ToString
                Me.PatientSSN.Text = .Rows(0).Item("SS_No").ToString
            End With

        Catch ex As Exception

        End Try
    End Sub

    Public WriteOnly Property Patient_ID() As String
        Set(ByVal value As String)
            Call Clear_Me()
            Call Locate_Values(value)
            _Patient_ID = value
        End Set
    End Property

    Public WriteOnly Property Viewmoreform_Name() As String
        Set(ByVal value As String)
            _Viewmoreform_Name = value
        End Set
    End Property

    Public WriteOnly Property MDIform_Name() As Form
        Set(ByVal value As Form)
            _MDI_Form = value
        End Set
    End Property
    Public ReadOnly Property Is_Valid() As Boolean
        Get
            If Me.PatientName.Text = "" Then
                Return False
            Else
                Return True
            End If
        End Get
    End Property

    Private Function Locate_Values(ByVal PatientID As String) As Boolean
        Try

            If PatientID = "" Then Return False

            HMS_Helper = New Hms_Helperimpliments
            Dim Qry As String = ""
            Qry = "SELECT  Patient_ID, Name, Address, City, State, Country, " _
                  & "Phone1, Phone2, Mobile1, Mobile2, SS_No,[Family Name] " _
                  & "FROM Patient_Info_Vw " _
                  & "WHERE (Patient_ID = '" & PatientID & "')"

            If HMS_Helper.Get_Data(Qry, P_Dtbl) Then
                Call Assign_Values(P_Dtbl)
                Btn_viewmore.Enabled = True
                Return True
            Else
                Btn_viewmore.Enabled = False
                Return False
            End If

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Btn_viewmore_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_viewmore.Click
        Try



            With Patient_InfoSheet_Frm
                .Patient_ID = _Patient_ID
                If _MDI_Form Is Nothing Then
                    .MdiParent = _MDI_Form
                Else
                    .MdiParent = HMS_MDIMain_Frm
                End If

                .Show()
            End With

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Patient_Info_BackColorChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.BackColorChanged
        Try
            Me.PatientName.BackColor = Me.BackColor
            Me.Patientaddress.BackColor = Me.BackColor
            Me.Patientphone.BackColor = Me.BackColor
            Me.PatientSSN.BackColor = Me.BackColor
            Me.Patientmobile.BackColor = Me.BackColor
            Me.Patientfamilyname.BackColor = Me.BackColor
            Me.Btn_viewmore.BackColor = Me.BackColor


            Me.Lbl_Name.BackColor = Me.BackColor
            Me.Lbl_Address.BackColor = Me.BackColor
            Me.Lbl_Phone.BackColor = Me.BackColor
            Me.Lbl_SSN.BackColor = Me.BackColor
            Me.Lbl_Mobile.BackColor = Me.BackColor
            Me.Lbl_Familyname.BackColor = Me.BackColor


        Catch ex As Exception

        End Try
    End Sub

    Private Sub Patient_Info_FontChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.FontChanged
        Try
            Me.PatientName.Font = Me.Font
            Me.Patientaddress.Font = Me.Font
            Me.Patientphone.Font = Me.Font
            Me.PatientSSN.Font = Me.Font
            Me.Patientmobile.Font = Me.Font
            Me.Patientfamilyname.Font = Me.Font
            Me.Btn_viewmore.Font = Me.Font

            Me.Lbl_Name.Font = Me.Font
            Me.Lbl_Address.Font = Me.Font
            Me.Lbl_Phone.Font = Me.Font
            Me.Lbl_SSN.Font = Me.Font
            Me.Lbl_Mobile.Font = Me.Font
            Me.Lbl_Familyname.Font = Me.Font


        Catch ex As Exception

        End Try
    End Sub

    Private Sub Patient_Info_ForeColorChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.ForeColorChanged
        Try
            Me.PatientName.ForeColor = Me.ForeColor
            Me.Patientaddress.ForeColor = Me.ForeColor
            Me.Patientphone.ForeColor = Me.ForeColor
            Me.PatientSSN.ForeColor = Me.ForeColor
            Me.Patientmobile.ForeColor = Me.ForeColor
            Me.Patientfamilyname.ForeColor = Me.ForeColor
            Me.Btn_viewmore.ForeColor = Me.ForeColor

            Me.Lbl_Name.ForeColor = Me.ForeColor
            Me.Lbl_Address.ForeColor = Me.ForeColor
            Me.Lbl_Phone.ForeColor = Me.ForeColor
            Me.Lbl_SSN.ForeColor = Me.ForeColor
            Me.Lbl_Mobile.ForeColor = Me.ForeColor
            Me.Lbl_Familyname.ForeColor = Me.ForeColor

        Catch ex As Exception

        End Try
    End Sub
End Class
