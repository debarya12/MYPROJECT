﻿

Option Explicit On
Imports HMS_Common.Common_Cls

Public Class Tran_DGridview
    Inherits DataGridView
    'Private is_Moved As Boolean = False

    Protected Overloads Overrides Function ProcessDialogKey(ByVal keyData As Keys) As Boolean
        Try
            If keyData = Keys.Enter Then
                Dim row As Integer = Me.CurrentCell.RowIndex

                'is_Moved = False

                If Me.CurrentCell.IsInEditMode Then
                    MyBase.OnKeyDown(New KeyEventArgs(Keys.Tab))
                    'is_Moved = True
                    Return False
                Else
                    MyBase.OnKeyDown(New KeyEventArgs(keyData))
                    Return True
                End If
            End If
            Return MyBase.ProcessDialogKey(keyData)
        Catch ex As Exception
            Return MyBase.ProcessDialogKey(keyData)
        End Try
    End Function

    Protected Overloads Overrides Sub OnKeyDown(ByVal e As KeyEventArgs)
        Try
            If e.KeyData = Keys.Enter Then
                '// Do Nothing              
            Else
                MyBase.OnKeyDown(e)
            End If
        Catch ex As Exception

        End Try
    End Sub

    'Protected Overloads Overrides Sub OnKeyUp(ByVal e As KeyEventArgs)
    '    Try

    '        If e.KeyData = Keys.Enter Then
    '            If is_Moved Then is_Moved = False : Exit Sub

    '            MyBase.OnKeyDown(New KeyEventArgs(Keys.Tab))
    '            Return
    '        Else
    '            MyBase.OnKeyUp(e)
    '        End If

    '    Catch ex As Exception

    '    End Try
    'End Sub


End Class
