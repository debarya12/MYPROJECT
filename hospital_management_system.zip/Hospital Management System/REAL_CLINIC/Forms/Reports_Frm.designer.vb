﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Reports_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Reports_Frm))
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.SplitContainer = New System.Windows.Forms.SplitContainer
        Me.Tvw_Reportoptions = New System.Windows.Forms.TreeView
        Me.Pnl_Common = New System.Windows.Forms.Panel
        Me.Pnl_Cmb_4 = New System.Windows.Forms.Panel
        Me.Lbl_Cmb4 = New System.Windows.Forms.Label
        Me.Cmb_4 = New System.Windows.Forms.ComboBox
        Me.Pnl_Cmb_3 = New System.Windows.Forms.Panel
        Me.Lbl_Cmb3 = New System.Windows.Forms.Label
        Me.Cmb_3 = New System.Windows.Forms.ComboBox
        Me.Pnl_Cmb_2 = New System.Windows.Forms.Panel
        Me.Cmb_2 = New System.Windows.Forms.ComboBox
        Me.Lbl_Cmb2 = New System.Windows.Forms.Label
        Me.Pnl_Text_2 = New System.Windows.Forms.Panel
        Me.Pnl_Text_2_Btn_Find = New System.Windows.Forms.Button
        Me.Txt_Box2 = New System.Windows.Forms.TextBox
        Me.Lbl_Txt2 = New System.Windows.Forms.Label
        Me.Pnl_Text_1 = New System.Windows.Forms.Panel
        Me.Pnl_Text_1_Btn_Find = New System.Windows.Forms.Button
        Me.Txt_Box1 = New System.Windows.Forms.TextBox
        Me.Lbl_Txt1 = New System.Windows.Forms.Label
        Me.Pnl_Heading = New System.Windows.Forms.Panel
        Me.Label2 = New System.Windows.Forms.Label
        Me.Lbl_Heading = New System.Windows.Forms.Label
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Process = New System.Windows.Forms.Button
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Show = New System.Windows.Forms.Button
        Me.Pnl_Cmb_1 = New System.Windows.Forms.Panel
        Me.Lbl_Cmb1 = New System.Windows.Forms.Label
        Me.Cmb_1 = New System.Windows.Forms.ComboBox
        Me.Pnl_Dtp_1 = New System.Windows.Forms.Panel
        Me.Dtp_1 = New System.Windows.Forms.DateTimePicker
        Me.Lbl_Date1 = New System.Windows.Forms.Label
        Me.Pnl_Dtp_2 = New System.Windows.Forms.Panel
        Me.Dtp_2 = New System.Windows.Forms.DateTimePicker
        Me.Lbl_Date2 = New System.Windows.Forms.Label
        Me.Pnl_Header.SuspendLayout()
        Me.SplitContainer.Panel1.SuspendLayout()
        Me.SplitContainer.Panel2.SuspendLayout()
        Me.SplitContainer.SuspendLayout()
        Me.Pnl_Common.SuspendLayout()
        Me.Pnl_Cmb_4.SuspendLayout()
        Me.Pnl_Cmb_3.SuspendLayout()
        Me.Pnl_Cmb_2.SuspendLayout()
        Me.Pnl_Text_2.SuspendLayout()
        Me.Pnl_Text_1.SuspendLayout()
        Me.Pnl_Heading.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.Pnl_Cmb_1.SuspendLayout()
        Me.Pnl_Dtp_1.SuspendLayout()
        Me.Pnl_Dtp_2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Menu_Bkg
        Me.Pnl_Header.Controls.Add(Me.Label1)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(796, 24)
        Me.Pnl_Header.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(7, 1)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(121, 18)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Report Options"
        '
        'SplitContainer
        '
        Me.SplitContainer.BackColor = System.Drawing.Color.Transparent
        Me.SplitContainer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer.Location = New System.Drawing.Point(0, 24)
        Me.SplitContainer.Name = "SplitContainer"
        '
        'SplitContainer.Panel1
        '
        Me.SplitContainer.Panel1.Controls.Add(Me.Tvw_Reportoptions)
        '
        'SplitContainer.Panel2
        '
        Me.SplitContainer.Panel2.Controls.Add(Me.Pnl_Common)
        Me.SplitContainer.Size = New System.Drawing.Size(796, 529)
        Me.SplitContainer.SplitterDistance = 261
        Me.SplitContainer.SplitterWidth = 5
        Me.SplitContainer.TabIndex = 2
        Me.SplitContainer.Text = "SplitContainer1"
        '
        'Tvw_Reportoptions
        '
        Me.Tvw_Reportoptions.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tvw_Reportoptions.ItemHeight = 22
        Me.Tvw_Reportoptions.Location = New System.Drawing.Point(0, 0)
        Me.Tvw_Reportoptions.Name = "Tvw_Reportoptions"
        Me.Tvw_Reportoptions.Size = New System.Drawing.Size(258, 529)
        Me.Tvw_Reportoptions.TabIndex = 0
        '
        'Pnl_Common
        '
        Me.Pnl_Common.Controls.Add(Me.Pnl_Cmb_4)
        Me.Pnl_Common.Controls.Add(Me.Pnl_Cmb_3)
        Me.Pnl_Common.Controls.Add(Me.Pnl_Cmb_2)
        Me.Pnl_Common.Controls.Add(Me.Pnl_Text_2)
        Me.Pnl_Common.Controls.Add(Me.Pnl_Text_1)
        Me.Pnl_Common.Controls.Add(Me.Pnl_Heading)
        Me.Pnl_Common.Controls.Add(Me.Pnl_Common_Btn)
        Me.Pnl_Common.Controls.Add(Me.Pnl_Cmb_1)
        Me.Pnl_Common.Controls.Add(Me.Pnl_Dtp_1)
        Me.Pnl_Common.Controls.Add(Me.Pnl_Dtp_2)
        Me.Pnl_Common.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Pnl_Common.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Common.Name = "Pnl_Common"
        Me.Pnl_Common.Size = New System.Drawing.Size(530, 529)
        Me.Pnl_Common.TabIndex = 0
        '
        'Pnl_Cmb_4
        '
        Me.Pnl_Cmb_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Cmb_4.Controls.Add(Me.Lbl_Cmb4)
        Me.Pnl_Cmb_4.Controls.Add(Me.Cmb_4)
        Me.Pnl_Cmb_4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Pnl_Cmb_4.Location = New System.Drawing.Point(58, 301)
        Me.Pnl_Cmb_4.Name = "Pnl_Cmb_4"
        Me.Pnl_Cmb_4.Size = New System.Drawing.Size(426, 27)
        Me.Pnl_Cmb_4.TabIndex = 38
        '
        'Lbl_Cmb4
        '
        Me.Lbl_Cmb4.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Cmb4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Lbl_Cmb4.Location = New System.Drawing.Point(4, 4)
        Me.Lbl_Cmb4.Name = "Lbl_Cmb4"
        Me.Lbl_Cmb4.Size = New System.Drawing.Size(171, 18)
        Me.Lbl_Cmb4.TabIndex = 32
        Me.Lbl_Cmb4.Text = "Lbl_Cmb4"
        Me.Lbl_Cmb4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Cmb_4
        '
        Me.Cmb_4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_4.FormattingEnabled = True
        Me.Cmb_4.Location = New System.Drawing.Point(181, 2)
        Me.Cmb_4.Name = "Cmb_4"
        Me.Cmb_4.Size = New System.Drawing.Size(240, 21)
        Me.Cmb_4.TabIndex = 31
        '
        'Pnl_Cmb_3
        '
        Me.Pnl_Cmb_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Cmb_3.Controls.Add(Me.Lbl_Cmb3)
        Me.Pnl_Cmb_3.Controls.Add(Me.Cmb_3)
        Me.Pnl_Cmb_3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Pnl_Cmb_3.Location = New System.Drawing.Point(58, 268)
        Me.Pnl_Cmb_3.Name = "Pnl_Cmb_3"
        Me.Pnl_Cmb_3.Size = New System.Drawing.Size(426, 27)
        Me.Pnl_Cmb_3.TabIndex = 37
        '
        'Lbl_Cmb3
        '
        Me.Lbl_Cmb3.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Cmb3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Lbl_Cmb3.Location = New System.Drawing.Point(4, 4)
        Me.Lbl_Cmb3.Name = "Lbl_Cmb3"
        Me.Lbl_Cmb3.Size = New System.Drawing.Size(171, 18)
        Me.Lbl_Cmb3.TabIndex = 32
        Me.Lbl_Cmb3.Text = "Lbl_Cmb3"
        Me.Lbl_Cmb3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Cmb_3
        '
        Me.Cmb_3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_3.FormattingEnabled = True
        Me.Cmb_3.Location = New System.Drawing.Point(181, 3)
        Me.Cmb_3.Name = "Cmb_3"
        Me.Cmb_3.Size = New System.Drawing.Size(240, 21)
        Me.Cmb_3.TabIndex = 31
        '
        'Pnl_Cmb_2
        '
        Me.Pnl_Cmb_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Cmb_2.Controls.Add(Me.Cmb_2)
        Me.Pnl_Cmb_2.Controls.Add(Me.Lbl_Cmb2)
        Me.Pnl_Cmb_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Pnl_Cmb_2.Location = New System.Drawing.Point(58, 235)
        Me.Pnl_Cmb_2.Name = "Pnl_Cmb_2"
        Me.Pnl_Cmb_2.Size = New System.Drawing.Size(426, 27)
        Me.Pnl_Cmb_2.TabIndex = 36
        '
        'Cmb_2
        '
        Me.Cmb_2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_2.FormattingEnabled = True
        Me.Cmb_2.Location = New System.Drawing.Point(181, 2)
        Me.Cmb_2.Name = "Cmb_2"
        Me.Cmb_2.Size = New System.Drawing.Size(240, 21)
        Me.Cmb_2.TabIndex = 33
        '
        'Lbl_Cmb2
        '
        Me.Lbl_Cmb2.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Cmb2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Lbl_Cmb2.Location = New System.Drawing.Point(4, 4)
        Me.Lbl_Cmb2.Name = "Lbl_Cmb2"
        Me.Lbl_Cmb2.Size = New System.Drawing.Size(171, 18)
        Me.Lbl_Cmb2.TabIndex = 32
        Me.Lbl_Cmb2.Text = "Lbl_Cmb2"
        Me.Lbl_Cmb2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Pnl_Text_2
        '
        Me.Pnl_Text_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Text_2.Controls.Add(Me.Pnl_Text_2_Btn_Find)
        Me.Pnl_Text_2.Controls.Add(Me.Txt_Box2)
        Me.Pnl_Text_2.Controls.Add(Me.Lbl_Txt2)
        Me.Pnl_Text_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Pnl_Text_2.Location = New System.Drawing.Point(58, 174)
        Me.Pnl_Text_2.Name = "Pnl_Text_2"
        Me.Pnl_Text_2.Size = New System.Drawing.Size(426, 27)
        Me.Pnl_Text_2.TabIndex = 35
        '
        'Pnl_Text_2_Btn_Find
        '
        Me.Pnl_Text_2_Btn_Find.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Pnl_Text_2_Btn_Find.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.F2_Button
        Me.Pnl_Text_2_Btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Pnl_Text_2_Btn_Find.ForeColor = System.Drawing.Color.White
        Me.Pnl_Text_2_Btn_Find.Location = New System.Drawing.Point(391, 2)
        Me.Pnl_Text_2_Btn_Find.Name = "Pnl_Text_2_Btn_Find"
        Me.Pnl_Text_2_Btn_Find.Size = New System.Drawing.Size(29, 21)
        Me.Pnl_Text_2_Btn_Find.TabIndex = 38
        Me.Pnl_Text_2_Btn_Find.TabStop = False
        Me.Pnl_Text_2_Btn_Find.Text = "F2"
        Me.Pnl_Text_2_Btn_Find.UseVisualStyleBackColor = False
        '
        'Txt_Box2
        '
        Me.Txt_Box2.Location = New System.Drawing.Point(181, 2)
        Me.Txt_Box2.Name = "Txt_Box2"
        Me.Txt_Box2.Size = New System.Drawing.Size(208, 21)
        Me.Txt_Box2.TabIndex = 37
        '
        'Lbl_Txt2
        '
        Me.Lbl_Txt2.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Txt2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Lbl_Txt2.Location = New System.Drawing.Point(4, 4)
        Me.Lbl_Txt2.Name = "Lbl_Txt2"
        Me.Lbl_Txt2.Size = New System.Drawing.Size(171, 18)
        Me.Lbl_Txt2.TabIndex = 36
        Me.Lbl_Txt2.Text = "Lbl_Txt2"
        Me.Lbl_Txt2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Pnl_Text_1
        '
        Me.Pnl_Text_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Text_1.Controls.Add(Me.Pnl_Text_1_Btn_Find)
        Me.Pnl_Text_1.Controls.Add(Me.Txt_Box1)
        Me.Pnl_Text_1.Controls.Add(Me.Lbl_Txt1)
        Me.Pnl_Text_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Pnl_Text_1.Location = New System.Drawing.Point(58, 141)
        Me.Pnl_Text_1.Name = "Pnl_Text_1"
        Me.Pnl_Text_1.Size = New System.Drawing.Size(426, 27)
        Me.Pnl_Text_1.TabIndex = 34
        '
        'Pnl_Text_1_Btn_Find
        '
        Me.Pnl_Text_1_Btn_Find.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Pnl_Text_1_Btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Pnl_Text_1_Btn_Find.ForeColor = System.Drawing.Color.White
        Me.Pnl_Text_1_Btn_Find.Location = New System.Drawing.Point(391, 2)
        Me.Pnl_Text_1_Btn_Find.Name = "Pnl_Text_1_Btn_Find"
        Me.Pnl_Text_1_Btn_Find.Size = New System.Drawing.Size(29, 21)
        Me.Pnl_Text_1_Btn_Find.TabIndex = 34
        Me.Pnl_Text_1_Btn_Find.TabStop = False
        Me.Pnl_Text_1_Btn_Find.Text = "F2"
        Me.Pnl_Text_1_Btn_Find.UseVisualStyleBackColor = False
        '
        'Txt_Box1
        '
        Me.Txt_Box1.Location = New System.Drawing.Point(181, 2)
        Me.Txt_Box1.Name = "Txt_Box1"
        Me.Txt_Box1.Size = New System.Drawing.Size(208, 21)
        Me.Txt_Box1.TabIndex = 33
        '
        'Lbl_Txt1
        '
        Me.Lbl_Txt1.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Txt1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Lbl_Txt1.Location = New System.Drawing.Point(4, 4)
        Me.Lbl_Txt1.Name = "Lbl_Txt1"
        Me.Lbl_Txt1.Size = New System.Drawing.Size(171, 18)
        Me.Lbl_Txt1.TabIndex = 32
        Me.Lbl_Txt1.Text = "Lbl_Txt1"
        Me.Lbl_Txt1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Pnl_Heading
        '
        Me.Pnl_Heading.Controls.Add(Me.Label2)
        Me.Pnl_Heading.Controls.Add(Me.Lbl_Heading)
        Me.Pnl_Heading.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Heading.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Heading.Name = "Pnl_Heading"
        Me.Pnl_Heading.Size = New System.Drawing.Size(530, 33)
        Me.Pnl_Heading.TabIndex = 33
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(8, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(128, 14)
        Me.Label2.TabIndex = 34
        Me.Label2.Text = "SELECTED REPORT :"
        '
        'Lbl_Heading
        '
        Me.Lbl_Heading.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Heading.Dock = System.Windows.Forms.DockStyle.Right
        Me.Lbl_Heading.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Lbl_Heading.Location = New System.Drawing.Point(155, 0)
        Me.Lbl_Heading.Name = "Lbl_Heading"
        Me.Lbl_Heading.Size = New System.Drawing.Size(375, 33)
        Me.Lbl_Heading.TabIndex = 33
        Me.Lbl_Heading.Text = "REPORT NAME"
        Me.Lbl_Heading.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Process)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Show)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(169, 453)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(249, 36)
        Me.Pnl_Common_Btn.TabIndex = 32
        '
        'Btn_Process
        '
        Me.Btn_Process.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Process.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Process.ForeColor = System.Drawing.Color.White
        Me.Btn_Process.Location = New System.Drawing.Point(4, 3)
        Me.Btn_Process.Name = "Btn_Process"
        Me.Btn_Process.Size = New System.Drawing.Size(60, 28)
        Me.Btn_Process.TabIndex = 16
        Me.Btn_Process.Text = "&Process"
        Me.Btn_Process.UseVisualStyleBackColor = False
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(124, 3)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(60, 28)
        Me.Btn_Clear.TabIndex = 14
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(184, 3)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(60, 28)
        Me.Btn_Close.TabIndex = 15
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Show
        '
        Me.Btn_Show.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Show.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Show.ForeColor = System.Drawing.Color.White
        Me.Btn_Show.Location = New System.Drawing.Point(64, 3)
        Me.Btn_Show.Name = "Btn_Show"
        Me.Btn_Show.Size = New System.Drawing.Size(60, 28)
        Me.Btn_Show.TabIndex = 12
        Me.Btn_Show.Text = "&Show"
        Me.Btn_Show.UseVisualStyleBackColor = False
        '
        'Pnl_Cmb_1
        '
        Me.Pnl_Cmb_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Cmb_1.Controls.Add(Me.Lbl_Cmb1)
        Me.Pnl_Cmb_1.Controls.Add(Me.Cmb_1)
        Me.Pnl_Cmb_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Pnl_Cmb_1.Location = New System.Drawing.Point(58, 204)
        Me.Pnl_Cmb_1.Name = "Pnl_Cmb_1"
        Me.Pnl_Cmb_1.Size = New System.Drawing.Size(426, 27)
        Me.Pnl_Cmb_1.TabIndex = 31
        '
        'Lbl_Cmb1
        '
        Me.Lbl_Cmb1.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Cmb1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Lbl_Cmb1.Location = New System.Drawing.Point(4, 4)
        Me.Lbl_Cmb1.Name = "Lbl_Cmb1"
        Me.Lbl_Cmb1.Size = New System.Drawing.Size(171, 18)
        Me.Lbl_Cmb1.TabIndex = 32
        Me.Lbl_Cmb1.Text = "Lbl_Cmb1"
        Me.Lbl_Cmb1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Cmb_1
        '
        Me.Cmb_1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_1.FormattingEnabled = True
        Me.Cmb_1.Location = New System.Drawing.Point(181, 2)
        Me.Cmb_1.Name = "Cmb_1"
        Me.Cmb_1.Size = New System.Drawing.Size(240, 21)
        Me.Cmb_1.TabIndex = 31
        '
        'Pnl_Dtp_1
        '
        Me.Pnl_Dtp_1.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Dtp_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Dtp_1.Controls.Add(Me.Dtp_1)
        Me.Pnl_Dtp_1.Controls.Add(Me.Lbl_Date1)
        Me.Pnl_Dtp_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Pnl_Dtp_1.Location = New System.Drawing.Point(96, 351)
        Me.Pnl_Dtp_1.Name = "Pnl_Dtp_1"
        Me.Pnl_Dtp_1.Size = New System.Drawing.Size(272, 27)
        Me.Pnl_Dtp_1.TabIndex = 28
        '
        'Dtp_1
        '
        Me.Dtp_1.CustomFormat = "dd/MM/yyyy"
        Me.Dtp_1.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_1.Location = New System.Drawing.Point(153, 2)
        Me.Dtp_1.Name = "Dtp_1"
        Me.Dtp_1.Size = New System.Drawing.Size(114, 21)
        Me.Dtp_1.TabIndex = 9
        '
        'Lbl_Date1
        '
        Me.Lbl_Date1.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Date1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Lbl_Date1.Location = New System.Drawing.Point(3, 2)
        Me.Lbl_Date1.Name = "Lbl_Date1"
        Me.Lbl_Date1.Size = New System.Drawing.Size(144, 21)
        Me.Lbl_Date1.TabIndex = 23
        Me.Lbl_Date1.Text = "From"
        Me.Lbl_Date1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Pnl_Dtp_2
        '
        Me.Pnl_Dtp_2.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Dtp_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Dtp_2.Controls.Add(Me.Dtp_2)
        Me.Pnl_Dtp_2.Controls.Add(Me.Lbl_Date2)
        Me.Pnl_Dtp_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Pnl_Dtp_2.Location = New System.Drawing.Point(96, 401)
        Me.Pnl_Dtp_2.Name = "Pnl_Dtp_2"
        Me.Pnl_Dtp_2.Size = New System.Drawing.Size(272, 26)
        Me.Pnl_Dtp_2.TabIndex = 27
        '
        'Dtp_2
        '
        Me.Dtp_2.CustomFormat = "dd/MM/yyyy"
        Me.Dtp_2.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_2.Location = New System.Drawing.Point(153, 2)
        Me.Dtp_2.Name = "Dtp_2"
        Me.Dtp_2.Size = New System.Drawing.Size(114, 21)
        Me.Dtp_2.TabIndex = 9
        '
        'Lbl_Date2
        '
        Me.Lbl_Date2.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Date2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Lbl_Date2.Location = New System.Drawing.Point(3, 0)
        Me.Lbl_Date2.Name = "Lbl_Date2"
        Me.Lbl_Date2.Size = New System.Drawing.Size(144, 23)
        Me.Lbl_Date2.TabIndex = 23
        Me.Lbl_Date2.Text = "To"
        Me.Lbl_Date2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Reports_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.LeftGradiant
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(796, 553)
        Me.Controls.Add(Me.SplitContainer)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Reports_Frm"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.SplitContainer.Panel1.ResumeLayout(False)
        Me.SplitContainer.Panel2.ResumeLayout(False)
        Me.SplitContainer.ResumeLayout(False)
        Me.Pnl_Common.ResumeLayout(False)
        Me.Pnl_Cmb_4.ResumeLayout(False)
        Me.Pnl_Cmb_3.ResumeLayout(False)
        Me.Pnl_Cmb_2.ResumeLayout(False)
        Me.Pnl_Text_2.ResumeLayout(False)
        Me.Pnl_Text_2.PerformLayout()
        Me.Pnl_Text_1.ResumeLayout(False)
        Me.Pnl_Text_1.PerformLayout()
        Me.Pnl_Heading.ResumeLayout(False)
        Me.Pnl_Heading.PerformLayout()
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.Pnl_Cmb_1.ResumeLayout(False)
        Me.Pnl_Dtp_1.ResumeLayout(False)
        Me.Pnl_Dtp_2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents SplitContainer As System.Windows.Forms.SplitContainer
    Friend WithEvents Tvw_Reportoptions As System.Windows.Forms.TreeView
    Friend WithEvents Pnl_Common As System.Windows.Forms.Panel
    Friend WithEvents Pnl_Dtp_1 As System.Windows.Forms.Panel
    Friend WithEvents Dtp_1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Lbl_Date1 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Dtp_2 As System.Windows.Forms.Panel
    Friend WithEvents Dtp_2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Lbl_Date2 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Cmb_1 As System.Windows.Forms.Panel
    Friend WithEvents Cmb_1 As System.Windows.Forms.ComboBox
    Friend WithEvents Lbl_Cmb1 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Show As System.Windows.Forms.Button
    Friend WithEvents Pnl_Heading As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Heading As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Text_1 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Txt1 As System.Windows.Forms.Label
    Friend WithEvents Txt_Box1 As System.Windows.Forms.TextBox
    Friend WithEvents Pnl_Text_2 As System.Windows.Forms.Panel
    Friend WithEvents Pnl_Cmb_3 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Cmb3 As System.Windows.Forms.Label
    Friend WithEvents Cmb_3 As System.Windows.Forms.ComboBox
    Friend WithEvents Pnl_Cmb_2 As System.Windows.Forms.Panel
    Friend WithEvents Cmb_2 As System.Windows.Forms.ComboBox
    Friend WithEvents Lbl_Cmb2 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Cmb_4 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Cmb4 As System.Windows.Forms.Label
    Friend WithEvents Cmb_4 As System.Windows.Forms.ComboBox
    Friend WithEvents Pnl_Text_1_Btn_Find As System.Windows.Forms.Button
    Friend WithEvents Pnl_Text_2_Btn_Find As System.Windows.Forms.Button
    Friend WithEvents Txt_Box2 As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_Txt2 As System.Windows.Forms.Label
    Friend WithEvents Btn_Process As System.Windows.Forms.Button
End Class
