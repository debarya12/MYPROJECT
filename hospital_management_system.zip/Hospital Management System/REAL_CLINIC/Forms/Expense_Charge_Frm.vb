﻿

Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls
Public Class Expense_Charge_Frm

#Region "Declarations"
    'Object of Gendata Bussiness Layer

    Private Expense_Chg_BL As Expense_Charge_BL_Cls
    'Private Account_Bl As Accounts_Master_BL_Cls
    Private hms_helper As HMS_Helper = Nothing
    Private mTr_Mode As Tran_Mode

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode

                    Me.Txt_ExpenseID.BackColor = Color.White
                    Me.Txt_ExpenseID.ReadOnly = False
                Case Tran_Mode.Edit_Mode

                    Me.Txt_ExpenseID.BackColor = Color.Silver
                    Me.Txt_ExpenseID.ReadOnly = True
            End Select
        End Set
    End Property


#End Region
    'userdefined Functions 
#Region " Methods"
    'Populating General Data category
    Private Sub Fill_Gendatacategory()
        Try
            Expense_Chg_BL = New Expense_Charge_BL_Cls
            Expense_Chg_BL.Fill_ExpenseGroupsList(DGvw_Gendatacategory)
            With DGvw_Gendatacategory
                If .Rows.Count > 0 Then
                    If .Columns.Count > 0 Then
                        .Columns(0).MinimumWidth = 500
                        For i_Ctr = 1 To .Columns.Count - 1
                            .Columns(i_Ctr).Width = 0
                        Next

                    End If
                End If
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Fill_ExpenseMasterdata() Handles DGvw_Gendatacategory.Click, DGvw_Gendatacategory.KeyUp, DGvw_Gendatacategory.DoubleClick
        Try
            With DGvw_Gendatacategory

                '---------------------------------------------------------------------
                DGvw_Gendata.DataSource = Nothing
                Lst_Gendata.Items.Clear()
                Call Clear_Datadetails()
                '---------------------------------------------------------------------

                If .Rows.Count = 0 Then Exit Sub
                If .CurrentRow Is Nothing Then Exit Sub
                'If Lbl_Seldatacategory.Tag <> .Item(1, .CurrentCell.RowIndex).Value.ToString.Trim Then
                Lbl_Seldatacategory.Text = .Item(0, .CurrentCell.RowIndex).Value.ToString.Trim
                Lbl_Seldatacategory.Tag = .Item(1, .CurrentCell.RowIndex).Value.ToString.Trim
                Expense_Chg_BL = New Expense_Charge_BL_Cls
                Expense_Chg_BL.Fill_ExpenseMasterlist(DGvw_Gendata, CInt(Val(Lbl_Seldatacategory.Tag)))
                Call Fill_ExpensedataEditlist()
                'End If
                Call Clear_ExpenseCtl()
                Dgv_Chargesettings.RowCount = 0

                If Lst_Gendata.Items.Count > 0 Then
                    Btn_Movedown.Enabled = True
                    Btn_Moveup.Enabled = True

                    Btn_Saveorder.Enabled = True
                Else
                    Btn_Movedown.Enabled = False
                    Btn_Moveup.Enabled = False

                    Btn_Saveorder.Enabled = False
                End If

            End With

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Function Fill_ExpensedataEditlist() As Boolean
        Try
            Dim Datadesc As String = ""
            Dim Datavalue As String = ""

            '' ''------------------------------------------------------------------
            ' ''Cmb_AccountHead.Items.Clear()
            ' ''Call Addlist_Item_Value(Cmb_AccountHead, "Not Applicable", "0")
            '' ''------------------------------------------------------------------

            With DGvw_Gendata
                Lst_Gendata.Items.Clear()
                For i_Ctr = 0 To .Rows.Count - 1
                    If Not .Item(2, i_Ctr).Value Is Nothing Then
                        Datadesc = .Item(2, i_Ctr).Value.ToString.Trim
                        Datavalue = .Item(0, i_Ctr).Value.ToString.Trim
                        If Datadesc.Trim <> "" Then
                            Call Addlist_Item_Value(Lst_Gendata, Datadesc, Datavalue)
                            'Call Addlist_Item_Value(Cmb_AccountHead, Datadesc, Datavalue)
                        End If
                    End If
                Next
            End With
            ' If Cmb_AccountHead.Items.Count > 0 Then Cmb_AccountHead.SelectedIndex = 0
            Return True
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function

    Private Function Is_Itemlocked(ByVal Itemvalue As String) As Boolean
        Try
            With DGvw_Gendata
                For i_ctr = 0 To .Rows.Count - 1
                    If Itemvalue.ToString.Trim = .Item(0, i_ctr).Value.ToString.Trim Then
                        If .Item(5, i_ctr).Value.ToString.Trim = "Y" Then
                            Return True
                        Else
                            Return False
                        End If
                    End If
                Next
            End With
            Return False
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Save_Dataorder() As Boolean
        Try
            Dim Sel_Text As String = ""
            Dim Sel_Value As String = ""

            Expense_Chg_BL = New Expense_Charge_BL_Cls
            With Lst_Gendata
                For i_Ctr = 0 To .Items.Count - 1
                    .SelectedIndex = i_Ctr
                    If Not Selectlist_Item_Value(Lst_Gendata, Sel_Text, Sel_Value) Then Exit Function
                    Expense_Chg_BL.Update_Expenseorder(Sel_Value, i_Ctr + 1)
                Next
            End With
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Clear_Datadetails()
        Try
            Txt_ExpenseID.Text = ""
            Txt_ExpenseID.Tag = ""
            Txt_ExpenseHead.Text = ""
            Txt_ExpenseHead.Tag = ""
            Tr_Mode = Tran_Mode.New_Mode

            Dgv_Chargesettings.ClearSelection()
            Dgv_Chargesettings.RowCount = 0

            Call Clear_ExpenseCtl()
        Catch ex As Exception

        End Try
    End Sub

    Private Function Validate_Fields() As Boolean
        Try
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If

            If Txt_ExpenseID.Text.Trim = "" Then MessageBox.Show("Invalid Expense ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_ExpenseID.Focus() : Exit Function
            If Txt_ExpenseHead.Text.Trim = "" Then MessageBox.Show("Invalid Expense Head,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_ExpenseHead.Focus() : Exit Function
            If Dgv_Chargesettings.Rows.Count = 0 Then MessageBox.Show("No Expense head added, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_AccountHead.Focus() : Exit Function


            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Locate_Values(ByVal Exp_ID As Integer) As Boolean
        Try

            Dim dtbl As DataTable = Nothing
            Dim dtbl1 As DataTable = Nothing
            Dim dr As DataTableReader = Nothing
            Expense_Chg_BL = New Expense_Charge_BL_Cls
            Call Clear_Datadetails()

            If Expense_Chg_BL.Get_ExpenseMaster(dtbl, Exp_ID, Tran_Date) Then

                Dgv_Chargesettings.RowCount = dtbl.Rows.Count
                Txt_ExpenseID.Text = Exp_ID
                Txt_ExpenseHead.Text = dtbl.Rows(0).Item("Exp_Name").ToString
                Txt_ExpenseHead.Tag = dtbl.Rows(0).Item("Exp_Name").ToString
            End If
            dtbl = Nothing
            If Expense_Chg_BL.Get_Exp_Chargesmaster(dtbl, Exp_ID, Tran_Date) Then

                With dtbl
                    For i = 0 To .Rows.Count - 1

                        Dgv_Chargesettings.Rows(i).Cells("Particulars").Value = .Rows(i).Item("Particulars").ToString

                        If .Rows(i).Item("Charge_Calctype").ToString = "F" Then
                            Dgv_Chargesettings.Rows(i).Cells("type").Value = "Fixed"
                        ElseIf .Rows(i).Item("Charge_Calctype").ToString = "D" Then
                            Dgv_Chargesettings.Rows(i).Cells("type").Value = "Dynamic"
                        ElseIf .Rows(i).Item("Charge_Calctype").ToString = "P" Then
                            Dgv_Chargesettings.Rows(i).Cells("type").Value = "Percentage"
                        End If

                        If .Rows(i).Item("Percentage_Of").ToString <> "0" Then
                            Expense_Chg_BL.Get_ExpenseItems(dtbl1, Exp_ID, Tran_Date, .Rows(i).Item("Percentage_Of").ToString)
                            Dgv_Chargesettings.Rows(i).Cells("Percentage").Value = dtbl1.Rows(0).Item(0).ToString
                        End If
                        Dgv_Chargesettings.Rows(i).Cells("Charge").Value = .Rows(i).Item("Exp_Amount").ToString
                        Dgv_Chargesettings.Rows(i).Cells("Acc_Name").Value = .Rows(i).Item("Account Head").ToString
                        Dgv_Chargesettings.Rows(i).Cells("Acc_Code").Value = .Rows(i).Item("Exp_Acc_Code").ToString

                        Dgv_Chargesettings.Rows(i).Cells("Exp_Subtype").Value = .Rows(i).Item("Exp_Subtype").ToString
                        Dgv_Chargesettings.Rows(i).Cells("PercentageID").Value = .Rows(i).Item("Percentage_Of").ToString
                    Next
                    Dgv_Chargesettings.ClearSelection()
                    Clear_ExpenseCtl()
                End With

                Return True
            Else
                Txt_ExpenseID.Text = Exp_ID
                Txt_ExpenseHead.Text = Lst_Gendata.SelectedItem.ToString
                Return True
            End If

        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Sub AssignValuesToControl(ByVal dtbl As DataTable)
        Try
            Dim dr As DataTableReader = Nothing
            dr = dtbl.CreateDataReader()
            dr.Read()
            With dr
                Txt_ExpenseID.Text = .Item("Exp_ID").ToString
                Txt_ExpenseHead.Text = Lst_Gendata.SelectedItem.ToString
                Txt_Charge.Text = .Item("Exp_Amount").ToString
                Cmb_AccountHead.SelectedValue = .Item("Exp_AccountHead").ToString
                Cmb_Type.SelectedIndex = IIf(.Item("Exp_Active").ToString = "Y", 0, 1)
                Cmb_Percentageof.SelectedIndex = IIf(.Item("Exp_Discountallowed").ToString = "Y", 0, 1)
            End With

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Clear_ExpenseCtl()
        Try
            Txt_particulars.Text = ""
            Txt_Charge.Text = ""
            Btn_Add.Tag = ""
            Cmb_AccountHead.SelectedIndex = 0
            Cmb_AccountHead.Focus()
        Catch ex As Exception

        End Try
    End Sub

    Private Function Validate_GridValues() As Boolean
        Try
            If Cmb_AccountHead.SelectedIndex = 0 Then MessageBox.Show("Invalid Account Head, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Cmb_AccountHead.Focus() : Return False
            If Txt_particulars.Text.Trim = "" Then MessageBox.Show("Particular does not left blank", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_particulars.Focus() : Return False
            If Cmb_Type.Text = "" Then MessageBox.Show("Invalid Type Selection", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Cmb_Type.Focus() : Return False
            If Strings.Left(Cmb_Type.Text, 1) = "P" Then
                If Cmb_Percentageof.Text = "" Then MessageBox.Show("Invalid Percentage item Selection", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Cmb_Percentageof.Focus() : Return False
            End If
            If Strings.Left(Cmb_Type.Text, 1) <> "D" Then
                If Txt_Charge.Text.Trim = "" Then MessageBox.Show("Invalid Charge amount, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_Charge.Focus() : Return False
            End If
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Populate_ParticularCombo()
        Try
            Dim Dtbl As New DataTable
            Dim Dr As DataRow

            With Dtbl

                .Columns.Add("Exp_Subtyp")
                .Columns.Add("Particulars")

            End With


            With Dgv_Chargesettings

                For i = 0 To .Rows.Count - 1

                    Dr = Dtbl.NewRow
                    Dr(0) = .Rows(i).Cells("Exp_Subtype").Value.ToString.Trim
                    Dr(1) = .Rows(i).Cells("Particulars").Value.ToString.Trim
                    Dtbl.Rows.Add(Dr)

                Next

            End With
            Cmb_Percentageof.DataSource = Dtbl
            Cmb_Percentageof.DisplayMember = "Particulars"
            Cmb_Percentageof.ValueMember = "Exp_Subtyp"

            'Populating combo 
            ' Fill_Combo(Cmb_Percentageof, Dtbl, "Exp_Subtype", "Particulars")

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

#End Region

    Private Sub Expense_Charge_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    'Form Load
    Private Sub Generaldata_Frm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            Call Fill_Gendatacategory()
            Call Fill_ExpenseMasterdata()
            hms_helper = New Hms_Helperimpliments
            Call hms_helper.Fill_AccountMaster(Cmb_AccountHead, "< Select >")
            Cmb_AccountHead.SelectedIndex = 0


            With Cmb_Type
                .Items.Add("Select")
                .Items.Add("Dynamic")
                .Items.Add("Fixed")
                .Items.Add("Percentage")
                .SelectedIndex = 0
            End With

            Dtp_TranDate.Value = Tran_Date
        Catch ex As Exception

        End Try
    End Sub
    'Save function
    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try

            'Validating Data
            If Not Validate_Fields() Then Exit Sub

            Call Expense_Chg_BL.Del_Expense_Chg(Txt_ExpenseID.Text.Trim, Dtp_TranDate.Value)

            Expense_Chg_BL = New Expense_Charge_BL_Cls
            Expense_Chg_BL.Exp_ID = Val(Txt_ExpenseID.Text)
            Expense_Chg_BL.Amd_Date = Dtp_TranDate.Value



            With Dgv_Chargesettings
                For i = 0 To .Rows.Count - 1

                    Expense_Chg_BL.Exp_Subtype = .Rows(i).Cells("Exp_Subtype").Value.ToString.Trim
                    Expense_Chg_BL.Particulars = .Rows(i).Cells("Particulars").Value.ToString.Trim
                    Expense_Chg_BL.Charge_Calctype = Strings.Left(.Rows(i).Cells("type").Value.ToString.Trim, 1).ToUpper
                    If Not .Rows(i).Cells("PercentageID").Value Is Nothing Then
                        Expense_Chg_BL.Percentage_Of = .Rows(i).Cells("PercentageID").Value
                    End If
                    If Not .Rows(i).Cells("Charge").Value Is Nothing Then
                        Expense_Chg_BL.Exp_Amount = Val(.Rows(i).Cells("Charge").Value.ToString)
                    Else
                        Expense_Chg_BL.Exp_Amount = 0
                    End If
                    Expense_Chg_BL.Exp_Acc_Code = .Rows(i).Cells("Acc_Code").Value
                    Expense_Chg_BL.Exp_Sutypeorder = i + 1

                    Expense_Chg_BL.Save_Expense_Charges(Dtbl, Tr_Mode, Val(Txt_ExpenseID.Text.Trim))
                Next
            End With

            MessageBox.Show("Expense Charge Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)

            Call Locate_Values(Txt_ExpenseID.Text.Trim)
            Btn_Clear.Focus()

        Catch ex As Exception

        End Try
    End Sub
    'close
    Private Sub Close_Btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

    Private Sub Generaldata_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then Call SendKeyTab()
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Movedown_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Movedown.Click
        Try
            Call MoveListItem(Lst_Gendata, Move_Position.Movedown)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Moveup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Moveup.Click
        Try
            Call MoveListItem(Lst_Gendata, Move_Position.Moveup)
        Catch ex As Exception

        End Try
    End Sub
    'save Expnese order
    Private Sub Btn_Saveorder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Saveorder.Click
        Try
            'Confirm before delete the record
            If MessageBox.Show("Are you sure wan't to Save the selected Item Order", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = Windows.Forms.DialogResult.No Then
                Exit Sub
            End If

            If Save_Dataorder() Then
                Call Fill_ExpenseMasterdata()
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try
            Call Clear_Datadetails()
            Txt_ExpenseID.Focus()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Lst_Gendata_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Lst_Gendata.Click
        Try
            Dim Sel_Value As String = ""
            Dim Sel_Text As String = ""
            If Not Selectlist_Item_Value(Lst_Gendata, Sel_Text, Sel_Value) Then Exit Sub

            If Not Locate_Values(Sel_Value) Then
                Call Clear_Datadetails()
                Txt_Charge.Focus()
            Else
                Tr_Mode = Tran_Mode.New_Mode
                Cmb_AccountHead.Focus()

            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Lst_Gendata_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Lst_Gendata.DoubleClick
        Try

            Dim Sel_Value As String = ""
            Dim Sel_Text As String = ""
            If Not Selectlist_Item_Value(Lst_Gendata, Sel_Text, Sel_Value) Then Exit Sub

            If Not Locate_Values(Sel_Value) Then
                Call Clear_Datadetails()
                Txt_Charge.Focus()
            Else
                Tr_Mode = Tran_Mode.New_Mode
                Cmb_AccountHead.Focus()

            End If


        Catch ex As Exception

        End Try
    End Sub

    Private Sub Lst_Gendata_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Lst_Gendata.KeyDown
        If e.KeyCode = Keys.Enter Then
            Call Lst_Gendata_DoubleClick(sender, e)
        End If
    End Sub
    Private Sub Dtp_TranDate_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Dtp_TranDate.ValueChanged
        If Dtp_TranDate.Value < Tran_Date Then Dtp_TranDate.Value = Tran_Date
    End Sub

    Private Sub Txt_Charge_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Charge.KeyPress
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Charge.Text, Data_Type.Double_Type, 12))
    End Sub

    Private Sub Txt_particulars_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_particulars.Validating
        Try
            If Txt_particulars.Text.Trim <> "" Then
                If Dgv_Chargesettings.Rows.Count = 0 Then
                    Cmb_Type.Text = "Fixed"
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Cmb_Type_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_Type.SelectedIndexChanged
        Try
            If Cmb_Type.Text = "Fixed" Or Cmb_Type.Text = "Dynamic" Then
                Cmb_Percentageof.Enabled = False
            Else
                Cmb_Percentageof.Enabled = True
            End If

            If Cmb_Type.Text = "Dynamic" Then
                Cmb_Percentageof.SelectedIndex = -1
                Cmb_Percentageof.Enabled = False
                Txt_Charge.Text = ""
                Txt_Charge.Enabled = False
            ElseIf Cmb_Type.Text = "Fixed" Then
                Cmb_Percentageof.SelectedIndex = -1
                Cmb_Percentageof.Enabled = False
            Else
                Cmb_Percentageof.Enabled = True
                Txt_Charge.Enabled = True
            End If

           

            If Strings.Left(Cmb_Type.Text, 1) = "P" Then
                Call Populate_ParticularCombo()
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Add_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Add.Click
        Try

            Dim cnt As Integer
            'validating grid adding fields 
            If Not Validate_GridValues() Then Exit Sub
            With Dgv_Chargesettings
                If Btn_Add.Tag <> "" Then

                    For cnt = 0 To .Rows.Count - 1

                        If .Rows(cnt).Cells("Exp_Subtype").Value = Btn_Add.Tag Then
                            .Rows(cnt).Cells("Particulars").Value = Txt_particulars.Text.Trim
                            .Rows(cnt).Cells("type").Value = Cmb_Type.Text.Trim
                            .Rows(cnt).Cells("Percentage").Value = Cmb_Percentageof.Text

                            .Rows(cnt).Cells("Charge").Value = Txt_Charge.Text.Trim
                            .Rows(cnt).Cells("Acc_Name").Value = Cmb_AccountHead.Text.Trim
                            .Rows(cnt).Cells("Acc_Code").Value = Cmb_AccountHead.SelectedValue
                            If Cmb_Percentageof.SelectedIndex >= 0 Then
                                .Rows(cnt).Cells("PercentageID").Value = Cmb_Percentageof.SelectedValue
                            End If
                        End If

                    Next

                Else


                    .Rows.Add()
                    .Rows(.Rows.Count - 1).Cells("Particulars").Value = Txt_particulars.Text.Trim
                    .Rows(.Rows.Count - 1).Cells("type").Value = Cmb_Type.Text.Trim
                    .Rows(.Rows.Count - 1).Cells("Percentage").Value = Cmb_Percentageof.Text.Trim

                    .Rows(.Rows.Count - 1).Cells("Charge").Value = Txt_Charge.Text.Trim
                    .Rows(.Rows.Count - 1).Cells("Acc_Name").Value = Cmb_AccountHead.Text.Trim
                    .Rows(.Rows.Count - 1).Cells("Acc_Code").Value = Cmb_AccountHead.SelectedValue
                    .Rows(.Rows.Count - 1).Cells("Exp_Subtype").Value = .Rows.Count

                    If Cmb_Percentageof.SelectedIndex >= 0 Then
                        .Rows(.Rows.Count - 1).Cells("PercentageID").Value = Cmb_Percentageof.SelectedValue
                    End If


                End If
            End With
            Call Clear_ExpenseCtl()

        Catch ex As Exception

        End Try
    End Sub
    Private Sub Cmb_Percentageof_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_Percentageof.SelectedIndexChanged
        If Strings.Left(Cmb_Type.Text, 1) = "F" Then Cmb_Percentageof.SelectedIndex = -1
    End Sub

    Private Sub Btn_GridUp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_GridUp.Click
        Try
            With Dgv_Chargesettings
                If .Rows.Count = 0 Then Exit Sub
                Call ReOrder_ChargeSubcategory(Move_Position.Moveup)
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_GridDown_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_GridDown.Click
        Try
            With Dgv_Chargesettings
                If .Rows.Count = 0 Then Exit Sub
                Call ReOrder_ChargeSubcategory(Move_Position.Movedown)
            End With
        Catch ex As Exception

        End Try

    End Sub

    Private Function ReOrder_ChargeSubcategory(ByVal moveposition As Move_Position) As Boolean
        Try
            Dim G_Dtbl As New DataTable
            Dim G_Row As DataRow = Nothing
            Dim S_Row As DataRow = Nothing
            Dim S_Index As Int32 = Dgv_Chargesettings.CurrentRow.Index
            Dim N_Index As Int32 = 0

            If moveposition = Move_Position.Movedown Then
                N_Index = S_Index + 1
            ElseIf moveposition = Move_Position.Moveup Then
                N_Index = S_Index - 1
            End If

            If N_Index < 0 Then Return False
            If N_Index = S_Index Then Return False
            If N_Index > Dgv_Chargesettings.RowCount - 1 Then Return False

            With G_Dtbl
                .Columns.Add("Particulars")
                .Columns.Add("type")
                .Columns.Add("Percentage")
                .Columns.Add("Charge")
                .Columns.Add("Acc_Name")
                .Columns.Add("Acc_Code")
                .Columns.Add("Exp_Subtype")
                .Columns.Add("PercentageID")
            End With
            With Dgv_Chargesettings
                For i = 0 To Dgv_Chargesettings.Rows.Count - 1
                    If i = S_Index Then

                        S_Row = G_Dtbl.NewRow()
                        S_Row("Particulars") = .Rows(i).Cells("Particulars").Value.ToString
                        S_Row("type") = .Rows(i).Cells("type").Value.ToString
                        S_Row("Percentage") = .Rows(i).Cells("Percentage").Value
                        S_Row("Charge") = .Rows(i).Cells("Charge").Value.ToString
                        S_Row("Acc_Name") = .Rows(i).Cells("Acc_Name").Value.ToString
                        S_Row("Acc_Code") = .Rows(i).Cells("Acc_Code").Value.ToString
                        S_Row("Exp_Subtype") = .Rows(i).Cells("Exp_Subtype").Value.ToString
                        S_Row("PercentageID") = .Rows(i).Cells("PercentageID").Value.ToString

                    Else

                        G_Row = G_Dtbl.NewRow()
                        G_Row("Particulars") = .Rows(i).Cells("Particulars").Value.ToString
                        G_Row("type") = .Rows(i).Cells("type").Value.ToString
                        G_Row("Percentage") = .Rows(i).Cells("Percentage").Value
                        G_Row("Charge") = .Rows(i).Cells("Charge").Value.ToString
                        G_Row("Acc_Name") = .Rows(i).Cells("Acc_Name").Value.ToString
                        G_Row("Acc_Code") = .Rows(i).Cells("Acc_Code").Value.ToString
                        G_Row("Exp_Subtype") = .Rows(i).Cells("Exp_Subtype").Value.ToString
                        G_Row("PercentageID") = .Rows(i).Cells("PercentageID").Value.ToString
                        G_Dtbl.Rows.Add(G_Row)

                    End If

                Next

                If Not S_Row Is Nothing Then
                    G_Dtbl.Rows.InsertAt(S_Row, N_Index)
                End If
                .RowCount = 0
                For i = 0 To G_Dtbl.Rows.Count - 1
                    .Rows.Add()
                    .Rows(.Rows.Count - 1).Cells("Particulars").Value = G_Dtbl.Rows(i).Item("Particulars").ToString
                    .Rows(.Rows.Count - 1).Cells("type").Value = G_Dtbl.Rows(i).Item("type").ToString
                    .Rows(.Rows.Count - 1).Cells("Percentage").Value = G_Dtbl.Rows(i).Item("Percentage").ToString
                    .Rows(.Rows.Count - 1).Cells("Charge").Value = G_Dtbl.Rows(i).Item("Charge").ToString
                    .Rows(.Rows.Count - 1).Cells("Acc_Name").Value = G_Dtbl.Rows(i).Item("Acc_Name").ToString
                    .Rows(.Rows.Count - 1).Cells("Acc_Code").Value = G_Dtbl.Rows(i).Item("Acc_Code").ToString
                    .Rows(.Rows.Count - 1).Cells("Exp_Subtype").Value = G_Dtbl.Rows(i).Item("Exp_Subtype").ToString
                    .Rows(.Rows.Count - 1).Cells("PercentageID").Value = G_Dtbl.Rows(i).Item("PercentageID").ToString
                Next
                .CurrentCell = Dgv_Chargesettings(0, N_Index)
                .SelectionMode = DataGridViewSelectionMode.FullRowSelect
            End With

        Catch ex As Exception

        End Try
    End Function

    Private Function Delete_ChargeSubcategory() As Boolean
        Try
            With Dgv_Chargesettings
                .Rows.RemoveAt(.CurrentRow.Index)
            End With

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Btn_Removeitem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Removeitem.Click
        Try

            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If

            If Dgv_Chargesettings.CurrentRow Is Nothing Then Exit Sub

            'Confirm before delete the record
            If MessageBox.Show("Are you sure wan't to delete the selected Item", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = Windows.Forms.DialogResult.No Then
                Exit Sub
            End If
            Call Delete_ChargeSubcategory()

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgv_Chargesettings_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Dgv_Chargesettings.SelectionChanged
        Try
            Btn_Add.Tag = ""
            With Dgv_Chargesettings
                Txt_particulars.Text = .CurrentRow.Cells("Particulars").Value.ToString
                Cmb_Type.Text = .CurrentRow.Cells("Type").Value.ToString

                If .CurrentRow.Cells("Percentage").Value <> "" Then _
                    Cmb_Percentageof.Text = .CurrentRow.Cells("Percentage").Value.ToString.Trim Else _
                    Cmb_Percentageof.SelectedIndex = -1

                Txt_Charge.Text = .CurrentRow.Cells("Charge").Value.ToString
                Cmb_AccountHead.SelectedValue = .CurrentRow.Cells("Acc_Code").Value.ToString
                Btn_Add.Tag = .CurrentRow.Cells("Exp_Subtype").Value.ToString
                Dgv_Chargesettings.SelectionMode = DataGridViewSelectionMode.FullRowSelect
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Cmb_AccountHead_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Cmb_AccountHead.Validating
        Try
            If Tr_Mode = Tran_Mode.New_Mode Then
                If Cmb_AccountHead.SelectedIndex > 0 Then
                    Txt_particulars.Text = Cmb_AccountHead.Text
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub DGvw_Gendatacategory_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DGvw_Gendatacategory.CellContentClick

    End Sub

    Private Sub Lst_Gendata_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Lst_Gendata.SelectedIndexChanged

    End Sub
End Class