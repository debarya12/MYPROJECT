﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dr_Recomendations_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Dr_Recomendations_Frm))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.Txt_PMRID = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Btn_Find = New System.Windows.Forms.Button
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Report = New System.Windows.Forms.Button
        Me.Btn_Uttility = New System.Windows.Forms.Button
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Cancel = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.Btn_Add = New System.Windows.Forms.Button
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label
        Me.Txt_BatchID = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Btn_FindBatch = New System.Windows.Forms.Button
        Me.Btn_Deletegridrow = New System.Windows.Forms.Button
        Me.Txt_Details = New System.Windows.Forms.TextBox
        Me.Txt_Footer = New System.Windows.Forms.TextBox
        Me.Btn_FindDoc = New System.Windows.Forms.Button
        Me.Txt_DocID = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Txt_PatientID = New System.Windows.Forms.TextBox
        Me.Btn_AddHeading = New System.Windows.Forms.Button
        Me.Txt_Heading = New System.Windows.Forms.TextBox
        Me.Txt_DocDetails = New System.Windows.Forms.TextBox
        Me.Txt_OPID = New System.Windows.Forms.TextBox
        Me.Btn_Clearentry = New System.Windows.Forms.Button
        Me.Dgw_HeadingHistory = New REAL_CLINIC.Hms_DGridview(Me.components)
        Me.Imageviewer1 = New REAL_CLINIC.Imageviewer
        Me.Patient_Info2 = New REAL_CLINIC.Patient_Info
        Me.Dgv_CaseRecord = New REAL_CLINIC.Hms_DGridview(Me.components)
        Me.Slno = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Heading = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Details = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Footer = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.BatchID = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Rec_ID = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Pnl_Header.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.Pnl_Tran_mode.SuspendLayout()
        CType(Me.Dgw_HeadingHistory, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Dgv_CaseRecord, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Menu_Bkg
        Me.Pnl_Header.Controls.Add(Me.Label1)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(809, 24)
        Me.Pnl_Header.TabIndex = 10000
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(7, 1)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(502, 19)
        Me.Label1.TabIndex = 100000
        Me.Label1.Text = "C o n s u l t a n t   C o m m e n t s   a n d   R e c o m e n d a t i o n s"
        '
        'Txt_PMRID
        '
        Me.Txt_PMRID.BackColor = System.Drawing.Color.White
        Me.Txt_PMRID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_PMRID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PMRID.Location = New System.Drawing.Point(103, 54)
        Me.Txt_PMRID.MaxLength = 10
        Me.Txt_PMRID.Name = "Txt_PMRID"
        Me.Txt_PMRID.Size = New System.Drawing.Size(142, 21)
        Me.Txt_PMRID.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(8, 58)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(50, 13)
        Me.Label2.TabIndex = 210
        Me.Label2.Text = "PMR-ID"
        '
        'Btn_Find
        '
        Me.Btn_Find.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find.BackgroundImage = CType(resources.GetObject("Btn_Find.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find.ForeColor = System.Drawing.Color.White
        Me.Btn_Find.Location = New System.Drawing.Point(246, 54)
        Me.Btn_Find.Name = "Btn_Find"
        Me.Btn_Find.Size = New System.Drawing.Size(29, 21)
        Me.Btn_Find.TabIndex = 3
        Me.Btn_Find.TabStop = False
        Me.Btn_Find.Text = "F2"
        Me.Btn_Find.UseVisualStyleBackColor = False
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Report)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Uttility)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Cancel)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(301, 517)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(347, 35)
        Me.Pnl_Common_Btn.TabIndex = 218
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(286, 3)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 17
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Report
        '
        Me.Btn_Report.BackgroundImage = CType(resources.GetObject("Btn_Report.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Report.CausesValidation = False
        Me.Btn_Report.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Report.Location = New System.Drawing.Point(231, 3)
        Me.Btn_Report.Name = "Btn_Report"
        Me.Btn_Report.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Report.TabIndex = 16
        Me.Btn_Report.Text = "&Print"
        Me.Btn_Report.UseVisualStyleBackColor = True
        '
        'Btn_Uttility
        '
        Me.Btn_Uttility.BackgroundImage = CType(resources.GetObject("Btn_Uttility.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Uttility.CausesValidation = False
        Me.Btn_Uttility.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Uttility.Location = New System.Drawing.Point(176, 3)
        Me.Btn_Uttility.Name = "Btn_Uttility"
        Me.Btn_Uttility.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Uttility.TabIndex = 15
        Me.Btn_Uttility.Text = "&Uttility"
        Me.Btn_Uttility.UseVisualStyleBackColor = True
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(114, 3)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(63, 28)
        Me.Btn_Clear.TabIndex = 14
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Cancel
        '
        Me.Btn_Cancel.BackgroundImage = CType(resources.GetObject("Btn_Cancel.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Cancel.Location = New System.Drawing.Point(59, 3)
        Me.Btn_Cancel.Name = "Btn_Cancel"
        Me.Btn_Cancel.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Cancel.TabIndex = 13
        Me.Btn_Cancel.Text = "C&ancel"
        Me.Btn_Cancel.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = CType(resources.GetObject("Btn_Save.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(4, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save.TabIndex = 12
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Btn_Add
        '
        Me.Btn_Add.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Add.BackgroundImage = CType(resources.GetObject("Btn_Add.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Add.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Add.ForeColor = System.Drawing.Color.White
        Me.Btn_Add.Location = New System.Drawing.Point(526, 268)
        Me.Btn_Add.Name = "Btn_Add"
        Me.Btn_Add.Size = New System.Drawing.Size(56, 21)
        Me.Btn_Add.TabIndex = 10
        Me.Btn_Add.Text = "&Add"
        Me.Btn_Add.UseVisualStyleBackColor = False
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(734, 25)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(74, 21)
        Me.Pnl_Tran_mode.TabIndex = 10001
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(3, 1)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(67, 16)
        Me.Lbl_Tran_Mode.TabIndex = 122
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Txt_BatchID
        '
        Me.Txt_BatchID.BackColor = System.Drawing.Color.White
        Me.Txt_BatchID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_BatchID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_BatchID.Location = New System.Drawing.Point(103, 30)
        Me.Txt_BatchID.MaxLength = 10
        Me.Txt_BatchID.Name = "Txt_BatchID"
        Me.Txt_BatchID.Size = New System.Drawing.Size(142, 21)
        Me.Txt_BatchID.TabIndex = 0
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(8, 34)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(55, 13)
        Me.Label6.TabIndex = 10006
        Me.Label6.Text = "Batch ID"
        '
        'Btn_FindBatch
        '
        Me.Btn_FindBatch.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_FindBatch.BackgroundImage = CType(resources.GetObject("Btn_FindBatch.BackgroundImage"), System.Drawing.Image)
        Me.Btn_FindBatch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_FindBatch.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_FindBatch.ForeColor = System.Drawing.Color.White
        Me.Btn_FindBatch.Location = New System.Drawing.Point(246, 30)
        Me.Btn_FindBatch.Name = "Btn_FindBatch"
        Me.Btn_FindBatch.Size = New System.Drawing.Size(29, 21)
        Me.Btn_FindBatch.TabIndex = 1
        Me.Btn_FindBatch.TabStop = False
        Me.Btn_FindBatch.Text = "F2"
        Me.Btn_FindBatch.UseVisualStyleBackColor = False
        '
        'Btn_Deletegridrow
        '
        Me.Btn_Deletegridrow.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Deletegridrow.BackgroundImage = CType(resources.GetObject("Btn_Deletegridrow.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Deletegridrow.ForeColor = System.Drawing.Color.White
        Me.Btn_Deletegridrow.Location = New System.Drawing.Point(583, 268)
        Me.Btn_Deletegridrow.Name = "Btn_Deletegridrow"
        Me.Btn_Deletegridrow.Size = New System.Drawing.Size(56, 21)
        Me.Btn_Deletegridrow.TabIndex = 11
        Me.Btn_Deletegridrow.Text = "&Delete"
        Me.Btn_Deletegridrow.UseVisualStyleBackColor = False
        '
        'Txt_Details
        '
        Me.Txt_Details.BackColor = System.Drawing.Color.White
        Me.Txt_Details.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Details.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Details.Location = New System.Drawing.Point(103, 212)
        Me.Txt_Details.MaxLength = 2000
        Me.Txt_Details.Multiline = True
        Me.Txt_Details.Name = "Txt_Details"
        Me.Txt_Details.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Txt_Details.Size = New System.Drawing.Size(703, 50)
        Me.Txt_Details.TabIndex = 8
        '
        'Txt_Footer
        '
        Me.Txt_Footer.BackColor = System.Drawing.Color.White
        Me.Txt_Footer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Footer.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Footer.Location = New System.Drawing.Point(103, 268)
        Me.Txt_Footer.MaxLength = 10
        Me.Txt_Footer.Name = "Txt_Footer"
        Me.Txt_Footer.Size = New System.Drawing.Size(422, 21)
        Me.Txt_Footer.TabIndex = 9
        '
        'Btn_FindDoc
        '
        Me.Btn_FindDoc.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_FindDoc.BackgroundImage = CType(resources.GetObject("Btn_FindDoc.BackgroundImage"), System.Drawing.Image)
        Me.Btn_FindDoc.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_FindDoc.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_FindDoc.ForeColor = System.Drawing.Color.White
        Me.Btn_FindDoc.Location = New System.Drawing.Point(246, 78)
        Me.Btn_FindDoc.Name = "Btn_FindDoc"
        Me.Btn_FindDoc.Size = New System.Drawing.Size(29, 21)
        Me.Btn_FindDoc.TabIndex = 5
        Me.Btn_FindDoc.TabStop = False
        Me.Btn_FindDoc.Text = "F2"
        Me.Btn_FindDoc.UseVisualStyleBackColor = False
        '
        'Txt_DocID
        '
        Me.Txt_DocID.BackColor = System.Drawing.Color.White
        Me.Txt_DocID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_DocID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_DocID.Location = New System.Drawing.Point(103, 78)
        Me.Txt_DocID.MaxLength = 10
        Me.Txt_DocID.Name = "Txt_DocID"
        Me.Txt_DocID.Size = New System.Drawing.Size(142, 21)
        Me.Txt_DocID.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(8, 80)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 13)
        Me.Label3.TabIndex = 10020
        Me.Label3.Text = "Doctor "
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(8, 185)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(53, 13)
        Me.Label4.TabIndex = 10021
        Me.Label4.Text = "Heading"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(8, 215)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(68, 13)
        Me.Label5.TabIndex = 10022
        Me.Label5.Text = "Comments"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(8, 270)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(44, 13)
        Me.Label7.TabIndex = 10023
        Me.Label7.Text = "Footer"
        '
        'Txt_PatientID
        '
        Me.Txt_PatientID.BackColor = System.Drawing.Color.White
        Me.Txt_PatientID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_PatientID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PatientID.Location = New System.Drawing.Point(657, 522)
        Me.Txt_PatientID.MaxLength = 10
        Me.Txt_PatientID.Name = "Txt_PatientID"
        Me.Txt_PatientID.Size = New System.Drawing.Size(140, 21)
        Me.Txt_PatientID.TabIndex = 10024
        Me.Txt_PatientID.Visible = False
        '
        'Btn_AddHeading
        '
        Me.Btn_AddHeading.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_AddHeading.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Add_3
        Me.Btn_AddHeading.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_AddHeading.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_AddHeading.ForeColor = System.Drawing.Color.White
        Me.Btn_AddHeading.Location = New System.Drawing.Point(526, 185)
        Me.Btn_AddHeading.Name = "Btn_AddHeading"
        Me.Btn_AddHeading.Size = New System.Drawing.Size(24, 21)
        Me.Btn_AddHeading.TabIndex = 7
        Me.Btn_AddHeading.TabStop = False
        Me.Btn_AddHeading.UseVisualStyleBackColor = False
        '
        'Txt_Heading
        '
        Me.Txt_Heading.BackColor = System.Drawing.Color.White
        Me.Txt_Heading.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Heading.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Heading.Location = New System.Drawing.Point(103, 185)
        Me.Txt_Heading.MaxLength = 250
        Me.Txt_Heading.Name = "Txt_Heading"
        Me.Txt_Heading.Size = New System.Drawing.Size(422, 21)
        Me.Txt_Heading.TabIndex = 6
        '
        'Txt_DocDetails
        '
        Me.Txt_DocDetails.BackColor = System.Drawing.Color.White
        Me.Txt_DocDetails.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_DocDetails.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_DocDetails.Location = New System.Drawing.Point(103, 101)
        Me.Txt_DocDetails.MaxLength = 500
        Me.Txt_DocDetails.Multiline = True
        Me.Txt_DocDetails.Name = "Txt_DocDetails"
        Me.Txt_DocDetails.ReadOnly = True
        Me.Txt_DocDetails.Size = New System.Drawing.Size(308, 67)
        Me.Txt_DocDetails.TabIndex = 10026
        Me.Txt_DocDetails.TabStop = False
        '
        'Txt_OPID
        '
        Me.Txt_OPID.BackColor = System.Drawing.Color.White
        Me.Txt_OPID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_OPID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_OPID.Location = New System.Drawing.Point(657, 531)
        Me.Txt_OPID.MaxLength = 10
        Me.Txt_OPID.Name = "Txt_OPID"
        Me.Txt_OPID.Size = New System.Drawing.Size(142, 21)
        Me.Txt_OPID.TabIndex = 10027
        Me.Txt_OPID.Visible = False
        '
        'Btn_Clearentry
        '
        Me.Btn_Clearentry.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Clearentry.BackgroundImage = CType(resources.GetObject("Btn_Clearentry.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clearentry.ForeColor = System.Drawing.Color.White
        Me.Btn_Clearentry.Location = New System.Drawing.Point(639, 268)
        Me.Btn_Clearentry.Name = "Btn_Clearentry"
        Me.Btn_Clearentry.Size = New System.Drawing.Size(56, 21)
        Me.Btn_Clearentry.TabIndex = 10028
        Me.Btn_Clearentry.Text = "Clea&r"
        Me.Btn_Clearentry.UseVisualStyleBackColor = False
        '
        'Dgw_HeadingHistory
        '
        Me.Dgw_HeadingHistory.AllowUserToAddRows = False
        Me.Dgw_HeadingHistory.AllowUserToDeleteRows = False
        Me.Dgw_HeadingHistory.AllowUserToResizeColumns = False
        Me.Dgw_HeadingHistory.AllowUserToResizeRows = False
        Me.Dgw_HeadingHistory.BackgroundColor = System.Drawing.Color.White
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(87, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(162, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.AliceBlue
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgw_HeadingHistory.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.Dgw_HeadingHistory.ColumnHeadersHeight = 25
        Me.Dgw_HeadingHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.Dgw_HeadingHistory.ColumnHeadersVisible = False
        Me.Dgw_HeadingHistory.Location = New System.Drawing.Point(103, 207)
        Me.Dgw_HeadingHistory.Name = "Dgw_HeadingHistory"
        Me.Dgw_HeadingHistory.ReadOnly = True
        Me.Dgw_HeadingHistory.RowHeadersVisible = False
        Me.Dgw_HeadingHistory.Size = New System.Drawing.Size(422, 125)
        Me.Dgw_HeadingHistory.TabIndex = 10025
        Me.Dgw_HeadingHistory.TabStop = False
        Me.Dgw_HeadingHistory.Visible = False
        '
        'Imageviewer1
        '
        Me.Imageviewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Imageviewer1.CUST_ID = ""
        Me.Imageviewer1.CUST_TYPE = HMS_Common.Common_Cls.Customer_Type.Employee
        Me.Imageviewer1.Location = New System.Drawing.Point(649, 306)
        Me.Imageviewer1.Name = "Imageviewer1"
        Me.Imageviewer1.Scan_Enabled = True
        Me.Imageviewer1.Size = New System.Drawing.Size(162, 206)
        Me.Imageviewer1.TabIndex = 215
        '
        'Patient_Info2
        '
        Me.Patient_Info2.BackColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(201, Byte), Integer), CType(CType(231, Byte), Integer))
        Me.Patient_Info2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Patient_Info2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Patient_Info2.ForeColor = System.Drawing.Color.DarkBlue
        Me.Patient_Info2.Location = New System.Drawing.Point(413, 47)
        Me.Patient_Info2.Name = "Patient_Info2"
        Me.Patient_Info2.Padding = New System.Windows.Forms.Padding(2)
        Me.Patient_Info2.Size = New System.Drawing.Size(395, 121)
        Me.Patient_Info2.TabIndex = 212
        '
        'Dgv_CaseRecord
        '
        Me.Dgv_CaseRecord.AllowUserToAddRows = False
        Me.Dgv_CaseRecord.AllowUserToDeleteRows = False
        Me.Dgv_CaseRecord.AllowUserToResizeColumns = False
        Me.Dgv_CaseRecord.AllowUserToResizeRows = False
        Me.Dgv_CaseRecord.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(118, Byte), Integer), CType(CType(155, Byte), Integer), CType(CType(197, Byte), Integer))
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(87, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(162, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.AliceBlue
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgv_CaseRecord.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.Dgv_CaseRecord.ColumnHeadersHeight = 25
        Me.Dgv_CaseRecord.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.Dgv_CaseRecord.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Slno, Me.Heading, Me.Details, Me.Footer, Me.BatchID, Me.Rec_ID})
        Me.Dgv_CaseRecord.Location = New System.Drawing.Point(5, 306)
        Me.Dgv_CaseRecord.Name = "Dgv_CaseRecord"
        Me.Dgv_CaseRecord.ReadOnly = True
        Me.Dgv_CaseRecord.RowHeadersVisible = False
        Me.Dgv_CaseRecord.Size = New System.Drawing.Size(643, 205)
        Me.Dgv_CaseRecord.TabIndex = 127
        Me.Dgv_CaseRecord.TabStop = False
        '
        'Slno
        '
        Me.Slno.HeaderText = "No"
        Me.Slno.Name = "Slno"
        Me.Slno.ReadOnly = True
        Me.Slno.Width = 25
        '
        'Heading
        '
        Me.Heading.HeaderText = "Heading"
        Me.Heading.Name = "Heading"
        Me.Heading.ReadOnly = True
        Me.Heading.Width = 200
        '
        'Details
        '
        Me.Details.HeaderText = "Details"
        Me.Details.Name = "Details"
        Me.Details.ReadOnly = True
        Me.Details.Width = 215
        '
        'Footer
        '
        Me.Footer.HeaderText = "Footer"
        Me.Footer.Name = "Footer"
        Me.Footer.ReadOnly = True
        Me.Footer.Width = 200
        '
        'BatchID
        '
        Me.BatchID.HeaderText = "BatchID"
        Me.BatchID.Name = "BatchID"
        Me.BatchID.ReadOnly = True
        Me.BatchID.Visible = False
        '
        'Rec_ID
        '
        Me.Rec_ID.HeaderText = "Rec_ID"
        Me.Rec_ID.Name = "Rec_ID"
        Me.Rec_ID.ReadOnly = True
        Me.Rec_ID.Visible = False
        '
        'Dr_Recomendations_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.LeftGradiant
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(809, 555)
        Me.Controls.Add(Me.Btn_Clearentry)
        Me.Controls.Add(Me.Txt_OPID)
        Me.Controls.Add(Me.Txt_DocDetails)
        Me.Controls.Add(Me.Txt_Heading)
        Me.Controls.Add(Me.Btn_AddHeading)
        Me.Controls.Add(Me.Dgw_HeadingHistory)
        Me.Controls.Add(Me.Txt_PatientID)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Txt_DocID)
        Me.Controls.Add(Me.Btn_FindDoc)
        Me.Controls.Add(Me.Txt_Footer)
        Me.Controls.Add(Me.Txt_Details)
        Me.Controls.Add(Me.Btn_Deletegridrow)
        Me.Controls.Add(Me.Txt_BatchID)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Btn_FindBatch)
        Me.Controls.Add(Me.Pnl_Tran_mode)
        Me.Controls.Add(Me.Btn_Add)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.Imageviewer1)
        Me.Controls.Add(Me.Patient_Info2)
        Me.Controls.Add(Me.Txt_PMRID)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Btn_Find)
        Me.Controls.Add(Me.Dgv_CaseRecord)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Dr_Recomendations_Frm"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.Pnl_Tran_mode.ResumeLayout(False)
        CType(Me.Dgw_HeadingHistory, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Dgv_CaseRecord, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Dgv_CaseRecord As REAL_CLINIC.Hms_DGridview
    Friend WithEvents Patient_Info2 As REAL_CLINIC.Patient_Info
    Friend WithEvents Txt_PMRID As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Btn_Find As System.Windows.Forms.Button
    Friend WithEvents Imageviewer1 As REAL_CLINIC.Imageviewer
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Cancel As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Btn_Add As System.Windows.Forms.Button
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Txt_BatchID As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Btn_FindBatch As System.Windows.Forms.Button
    Friend WithEvents Btn_Deletegridrow As System.Windows.Forms.Button
    Friend WithEvents Btn_Uttility As System.Windows.Forms.Button
    Friend WithEvents Btn_Report As System.Windows.Forms.Button
    Friend WithEvents Txt_Details As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Footer As System.Windows.Forms.TextBox
    Friend WithEvents Btn_FindDoc As System.Windows.Forms.Button
    Friend WithEvents Txt_DocID As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Txt_PatientID As System.Windows.Forms.TextBox
    Friend WithEvents Dgw_HeadingHistory As REAL_CLINIC.Hms_DGridview
    Friend WithEvents Btn_AddHeading As System.Windows.Forms.Button
    Friend WithEvents Txt_Heading As System.Windows.Forms.TextBox
    Friend WithEvents Txt_DocDetails As System.Windows.Forms.TextBox
    Friend WithEvents Txt_OPID As System.Windows.Forms.TextBox
    Friend WithEvents Slno As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Heading As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Details As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Footer As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents BatchID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Rec_ID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Btn_Clearentry As System.Windows.Forms.Button
End Class
