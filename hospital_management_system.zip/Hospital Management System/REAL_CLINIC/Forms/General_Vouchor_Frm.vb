﻿
Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls

Public Class General_Vouchor_Frm
    Private Gen_Tran_BL As Gen_Transaction_BL_Cls
    Private hms_helper As HMS_Helper = Nothing
    Private mTr_Mode As Tran_Mode

    Private mRpt_Vwr As ReportViewer_Cls
    Private Rpt_BL As HMS_BL.Reports_BL_Cls

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_BatchID.BackColor = Color.White
                    Me.Txt_BatchID.ReadOnly = False
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_BatchID.BackColor = Color.Silver
                    Me.Txt_BatchID.ReadOnly = True
            End Select
        End Set
    End Property

    Private rowsindex As Integer = -1

#Region "Methods"
    Private Function Set_GridViewColumn() As Boolean
        Try
            Dim Col_1 As New DataGridViewTextBoxColumn
            Dim Col_2 As New DataGridViewTextBoxColumn
            Dim Col_3 As New DataGridViewTextBoxColumn
            Dim Col_4 As New DataGridViewTextBoxColumn


            Dim p As New Windows.Forms.Padding
            p.Left = 2
            p.Right = 2

            Col_1.Name = "AccountHead"
            Col_1.HeaderText = "Account Head"
            Col_1.Width = 250
            Col_1.CellTemplate.Style.Alignment = DataGridViewContentAlignment.MiddleLeft
            Cmb_AccountHead.Width = Col_1.Width
            Col_1.SortMode = DataGridViewColumnSortMode.NotSortable
            Col_1.CellTemplate.Style.Padding = p

            Col_2.Name = "Narration"
            Col_2.HeaderText = "Narration"
            Col_2.Width = 230
            Col_2.ReadOnly = True
            Txt_Narration.Width = Col_2.Width
            Col_2.SortMode = DataGridViewColumnSortMode.NotSortable
            Col_2.CellTemplate.Style.Alignment = DataGridViewContentAlignment.MiddleLeft
            Col_2.CellTemplate.Style.Padding = p

            Col_3.Name = "Amount"
            Col_3.HeaderText = "Amount"
            Col_3.Width = 200
            Txt_Cash.Width = Col_3.Width
            Col_3.SortMode = DataGridViewColumnSortMode.NotSortable
            Col_3.CellTemplate.Style.Padding = p
            Col_3.CellTemplate.Style.Alignment = DataGridViewContentAlignment.MiddleRight

            Col_4.Name = "Tran_ID"
            Col_4.HeaderText = ""
            Col_4.Width = 0
            Col_4.ReadOnly = True
            Col_4.SortMode = DataGridViewColumnSortMode.NotSortable


            Col_4.Visible = False

            With Dgvw_GeneralVouchor

                .Columns.Add(Col_1)
                .Columns.Add(Col_2)
                .Columns.Add(Col_3)
                .Columns.Add(Col_4)

            End With

            Dgvw_GeneralVouchor.RowCount = 1

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Sub Set_PositionContorl()
        Try
            With Dgvw_GeneralVouchor

                If .Columns(.CurrentCell.ColumnIndex).Name = "AccountHead" Then
                    Call Set_CellFocus("AccountHead", Nothing, Cmb_AccountHead)
                ElseIf .Columns(.CurrentCell.ColumnIndex).Name = "Narration" Then
                    Call Set_CellFocus("Narration", Txt_Narration)
                ElseIf .Columns(.CurrentCell.ColumnIndex).Name = "Amount" Then
                    Call Set_CellFocus("Amount", Txt_Cash)
                End If

            End With
        Catch ex As Exception

        End Try
    End Sub

    Public Sub Show_GridComponents(ByVal show As Boolean)
        Try
            Cmb_AccountHead.Visible = show
            Txt_Narration.Visible = show
            Txt_Cash.Visible = show

        Catch ex As Exception

        End Try
    End Sub

    Public Sub Set_CellFocus(ByVal ColName As String, Optional ByRef TextCtrl As TextBox = Nothing, Optional ByRef CmbCtrl As ComboBox = Nothing)
        Try
            With Dgvw_GeneralVouchor

                If Not TextCtrl Is Nothing Then
                    If .Columns(.CurrentCell.ColumnIndex).Name = ColName Then

                        If .Item(0, .CurrentCell.RowIndex).Value = "" Then Clear_Grid_Row(.CurrentCell.RowIndex) : Exit Sub
                        Dim X As Integer = .GetCellDisplayRectangle(.CurrentCell.ColumnIndex, .CurrentCell.RowIndex, False).Left + .Left
                        Dim Y As Integer = .GetCellDisplayRectangle(.CurrentCell.ColumnIndex, .CurrentCell.RowIndex, False).Bottom + .Top
                        TextCtrl.Text = .Item(.CurrentCell.ColumnIndex, .CurrentCell.RowIndex).Value
                        Call Set_Visible_GridControl(False, .CurrentCell.ColumnIndex)
                        TextCtrl.Location = New Point(X, Y - 22)
                        TextCtrl.Visible = True
                        TextCtrl.BringToFront()
                        TextCtrl.Focus()
                    End If
                End If

                If Not CmbCtrl Is Nothing Then
                    If .Columns(.CurrentCell.ColumnIndex).Name = ColName Then

                        Dim X As Integer = .GetCellDisplayRectangle(.CurrentCell.ColumnIndex, .CurrentCell.RowIndex, False).Left + .Left
                        Dim Y As Integer = .GetCellDisplayRectangle(.CurrentCell.ColumnIndex, .CurrentCell.RowIndex, False).Bottom + .Top
                        CmbCtrl.Text = .Item(.CurrentCell.ColumnIndex, .CurrentCell.RowIndex).Value
                        Call Set_Visible_GridControl(False, .CurrentCell.ColumnIndex)
                        CmbCtrl.Location = New Point(X, Y - 22)
                        If .Item(.CurrentCell.ColumnIndex, .CurrentCell.RowIndex).Value <> "" Then
                            CmbCtrl.Text = .Item(.CurrentCell.ColumnIndex, .CurrentCell.RowIndex).Value
                        Else
                            CmbCtrl.SelectedIndex = 0
                        End If
                        CmbCtrl.Visible = True
                        CmbCtrl.BringToFront()
                        CmbCtrl.Focus()

                    End If
                End If


            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Calculate_Total()
        Try
            Txt_Totalamount.Text = 0
            Dim Total_Amt As Double = 0
            With Dgvw_GeneralVouchor
                For cnt = 0 To .Rows.Count - 1
                    Total_Amt += Val(.Rows(cnt).Cells("Amount").Value)
                Next
            End With
            Txt_Totalamount.Text = Total_Amt.ToString("0.00")
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Set_Visible_GridControl(ByVal IsVis As Boolean, ByVal ColumnIndex As Integer)
        Try
            If Not IsVis Then

                If ColumnIndex = 1 Then
                    Cmb_AccountHead.Visible = False
                    Txt_Cash.Text = ""
                    Txt_Cash.Visible = False

                ElseIf ColumnIndex = 2 Then
                    Cmb_AccountHead.Visible = False
                    Txt_Narration.Text = ""
                    Txt_Narration.Visible = False
                Else
                    Txt_Cash.Text = ""
                    Txt_Cash.Visible = False
                    Txt_Narration.Text = ""
                    Txt_Narration.Visible = False
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Function Validate_Fields() As Boolean
        Try
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If

            If Tr_Mode <> Tran_Mode.New_Mode Then
                If Txt_BatchID.Text.Trim = "" Then MessageBox.Show("Invalid Bach ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_BatchID.Focus() : Return False
            End If

            If Cmb_PaymentMode.SelectedIndex = 0 Then MessageBox.Show("Invalid Payment Mode Selection, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Cmb_PaymentMode.Focus() : Return False
            If Cmb_TranType.SelectedIndex = 0 Then MessageBox.Show("Invalid Transaction Type, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Cmb_TranType.Focus() : Return False

            If Dgvw_GeneralVouchor.Rows.Count = 0 Then MessageBox.Show("Not transaction found, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Cmb_PaymentMode.Focus() : Return False



            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Validate_GridView() As Boolean
        Try
            With Dgvw_GeneralVouchor
                For i = 0 To .Rows.Count - 1

                    If Val(.Rows(i).Cells("Amount").Value) > 0 Then

                        If .Rows(i).Cells("AccountHead").Value.ToString = "" Then _
                        MessageBox.Show("Invalid Account Head, Please Check", Product_Name, _
                        MessageBoxButtons.OK, MessageBoxIcon.Error) : .Rows(i).Cells("AccountHead").Selected = True : Cmb_AccountHead.Focus() : Return False

                    End If

                Next
            End With

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function Locate_Values(ByVal Batch_ID As String) As Boolean
        Try
            Dim dtbl As DataTable = Nothing
            Dim dr As DataTableReader = Nothing
            Tr_Mode = Tran_Mode.Edit_Mode
            Gen_Tran_BL = New Gen_Transaction_BL_Cls
            Dim cnt As Integer = 0

            Call Clear_GridView()

            If Gen_Tran_BL.Get_Gen_Transaction(dtbl, Batch_ID, Tran_Date, 1) Then



                Txt_BatchID.Text = dtbl.Rows(0).Item("Tran_BatchID").ToString
                Txt_Narr.Text = dtbl.Rows(0).Item("Tr_Narration").ToString
                Dtp_Trandate.Value = dtbl.Rows(0).Item("Tr_date").ToString

                Cmb_PaymentMode.SelectedValue = dtbl.Rows(0).Item("Tr_Pay_Mode").ToString
                Cmb_TranType.SelectedValue = dtbl.Rows(0).Item("Tr_Type").ToString

                With Dgvw_GeneralVouchor


                    For cnt = 0 To dtbl.Rows.Count - 1
                        .Rows.Add()
                        .Rows(cnt).Cells("AccountHead").Value = dtbl.Rows(cnt).Item("Account Head").ToString
                        .Rows(cnt).Cells("Narration").Value = dtbl.Rows(cnt).Item("Tr_Remarks").ToString
                        .Rows(cnt).Cells("Amount").Value = dtbl.Rows(cnt).Item("Tr_Amount").ToString
                        .Rows(cnt).Cells("Tran_ID").Value = dtbl.Rows(cnt).Item("Tran_ID").ToString

                    Next

                End With

                dtbl = Nothing
                Dgvw_GeneralVouchor.Focus()
                Return True

            Else
                Return False
            End If

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Clear_GridView()
        Try

            With Dgvw_GeneralVouchor
                .RowCount = 1
                For i = 0 To .Rows.Count - 1

                    .Rows(i).Cells("AccountHead").Value = ""
                    .Rows(i).Cells("Narration").Value = ""
                    .Rows(i).Cells("Amount").Value = ""

                Next
            End With
            Txt_Cash.Text = ""
            Txt_Narration.Text = ""
            Cmb_AccountHead.SelectedIndex = 0
            Txt_Cash.Visible = False
            Txt_Narration.Visible = False
            Cmb_AccountHead.Visible = False

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Clear_Grid_Row(ByVal Rowindex As Integer)
        Try

            With Dgvw_GeneralVouchor


                .Rows(Rowindex).Cells("AccountHead").Value = ""
                .Rows(Rowindex).Cells("Narration").Value = ""
                .Rows(Rowindex).Cells("Amount").Value = ""


            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Clear_Form()
        Try
            Txt_BatchID.Text = ""
            Txt_Narr.Text = ""
            Dtp_Trandate.Value = Tran_Date

            If Cmb_PaymentMode.Items.Count > 0 Then Cmb_PaymentMode.SelectedIndex = 0
            If Cmb_TranType.Items.Count > 0 Then Cmb_TranType.SelectedIndex = 0

            Call Clear_GridView()

            Tr_Mode = Tran_Mode.New_Mode
            Btn_Save.Enabled = True
            Btn_Delete.Enabled = False
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Hide_GridContorls()
        Cmb_AccountHead.Visible = False
        Txt_Cash.Visible = False
        Txt_Narration.Visible = False
        Dgvw_GeneralVouchor.CurrentCell = Dgvw_GeneralVouchor(0, 0)
    End Sub

    Public Function Show_Reciept() As Boolean
        Try
            If Txt_BatchID.Text.Trim = "" Then MessageBox.Show("Invalid  Batch ID .. Please enter valid Tran Id", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Exit Function

            If Val(Txt_Totalamount.Text) <= 0 Then Exit Function
            Dim Rpt_Ds As DataSet = Nothing
            Dim Rpt_Formulafields As String = "Company| " & Company_Name & "|Branch|" & Branch_Name
            Dim Rpt_Filename As String = ""
            Dim mReport_ID As String = ""
            Dim Report_Heading As String = ""
            Dim Add_Query As String = ""

            mRpt_Vwr = New ReportViewer_Cls

            Add_Query = ""
            Add_Query = "Where [Batch No] = " & Txt_BatchID.Text & " "
            Rpt_Filename = File_Path & "\Gen_Tran_Reciept.rpt"
            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Get_GenTran_Reciept(Rpt_Ds, Add_Query) Then

                REM for Geting total amount 
                Dim dtbl As DataTable = Rpt_Ds.Tables(0)
                Dim dr As DataTableReader
                Dim Amt As Double
                Amt = 0
                dr = dtbl.CreateDataReader

                While dr.Read
                    Amt = Amt + Val(dr.Item("Tr_Amount").ToString)
                End While
                REM .....

                Report_Heading = "|Heading| Receipt|Footer3|Authorised Signatory"
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading & "|words|" & Towords(Amt)
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            Else
                MessageBox.Show("Invalid Batch ID .. Please enter valid Batch ID", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function
#End Region
    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

    Private Sub General_Vouchor_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.F2 Then Btn_Find_Click(sender, e)
    End Sub

    Private Sub General_Vouchor_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub General_Vouchor_Frm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try

            Call Set_GridViewColumn()
            'populating Account Master combo
            hms_helper = New Hms_Helperimpliments
            hms_helper.Fill_AccountMaster(Cmb_AccountHead, "< Select >")
            Cmb_AccountHead.SelectedIndex = 0

            'populate Transaction type
            Fill_Transaction_Type(Cmb_TranType, "< Select >")
            Cmb_TranType.SelectedIndex = 0
            'populate Mode of Payment
            hms_helper.Fill_GenData(Cmb_PaymentMode, Gendatatype.Payment_Mode, "< Select >")
            Cmb_PaymentMode.SelectedIndex = 0

            Txt_BatchID.Focus()

            Dtp_Trandate.Value = Tran_Date
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Cmb_AccountHead_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Cmb_AccountHead.KeyDown
        Try

    
            If e.KeyCode = Keys.Enter Then

                If Cmb_AccountHead.SelectedIndex = 0 Then MessageBox.Show("Select Valid Account Head", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Cmb_AccountHead.Focus() : Exit Sub
                With Dgvw_GeneralVouchor
                    .Item(.CurrentCell.ColumnIndex, .CurrentCell.RowIndex).Value = Cmb_AccountHead.Text
                End With

                Dgvw_GeneralVouchor.CurrentCell = Dgvw_GeneralVouchor(1, Dgvw_GeneralVouchor.CurrentCell.RowIndex)
                Call Set_CellFocus("Narration", Txt_Narration)

            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Narration_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Narration.KeyDown
        Try

       
            If e.KeyCode = Keys.Enter Then

                With Dgvw_GeneralVouchor
                    .Item(.CurrentCell.ColumnIndex, .CurrentCell.RowIndex).Value = Txt_Narration.Text
                End With

                Dgvw_GeneralVouchor.CurrentCell = Dgvw_GeneralVouchor(2, Dgvw_GeneralVouchor.CurrentCell.RowIndex)
                Call Set_CellFocus("Amount", Txt_Cash)

            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Cash_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Cash.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then

                With Dgvw_GeneralVouchor
                    .Item(.CurrentCell.ColumnIndex, .CurrentCell.RowIndex).Value = Txt_Cash.Text
                End With

                Call Show_GridComponents(False)

                If Dgvw_GeneralVouchor.Rows.Count = Dgvw_GeneralVouchor.CurrentCell.RowIndex + 1 Then
                    Dgvw_GeneralVouchor.Rows.Add()
                End If

                Dgvw_GeneralVouchor.CurrentCell = Dgvw_GeneralVouchor(0, Dgvw_GeneralVouchor.CurrentCell.RowIndex + 1)
                Call Set_CellFocus("AccountHead", Nothing, Cmb_AccountHead)

            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Cash_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Cash.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Cash.Text, Data_Type.Double_Type, 12))
            rowsindex = Dgvw_GeneralVouchor.CurrentCell.RowIndex
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Cash_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_Cash.Validating
        Try
            If Txt_Cash.Text.Trim <> "" Then
                If rowsindex >= 0 Then Dgvw_GeneralVouchor.Item(2, rowsindex).Value = Txt_Cash.Text.Trim
                rowsindex = -1
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgvw_GeneralVouchor_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgvw_GeneralVouchor.CellClick
        Try
            Call Set_PositionContorl()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Narration_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Narration.KeyPress
        Try
            rowsindex = Dgvw_GeneralVouchor.CurrentCell.RowIndex
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Narration_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_Narration.Validating
        If Txt_Narration.Text.Trim <> "" Then
            If rowsindex >= 0 Then Dgvw_GeneralVouchor.Item(1, rowsindex).Value = Txt_Narration.Text.Trim
            rowsindex = -1
        End If
    End Sub

    Private Sub Cmb_AccountHead_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cmb_AccountHead.SelectedIndexChanged
        rowsindex = Dgvw_GeneralVouchor.CurrentCell.RowIndex
        If Cmb_AccountHead.SelectedIndex = 0 Then Clear_Grid_Row(Dgvw_GeneralVouchor.CurrentCell.RowIndex)
    End Sub

    Private Sub Cmb_AccountHead_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Cmb_AccountHead.Validating
        If Cmb_AccountHead.SelectedIndex <> 0 Then
            If rowsindex >= 0 Then Dgvw_GeneralVouchor.Item(0, rowsindex).Value = Cmb_AccountHead.Text.Trim
            rowsindex = -1
        End If
    End Sub

    Private Sub Dgvw_GeneralVouchor_CellValueChanged(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgvw_GeneralVouchor.CellValueChanged
        Try
            If e.ColumnIndex = Dgvw_GeneralVouchor.Columns("Amount").Index Then
                Call Calculate_Total()
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgvw_GeneralVouchor_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Dgvw_GeneralVouchor.GotFocus
        Try
            With Dgvw_GeneralVouchor
                If .CurrentCell.RowIndex = 0 And .CurrentCell.ColumnIndex = 0 Then
                    Call Set_PositionContorl()
                End If
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_BatchID_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Txt_BatchID.Click
        Hide_GridContorls()
    End Sub

    Private Sub Txt_BatchID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_BatchID.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then
                If Txt_BatchID.Text.Trim <> "" Then
                    If Not Locate_Values(Txt_BatchID.Text.Trim) Then
                        MessageBox.Show("Invalid Batch ID, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Clear_Form()
                    End If
                Else
                    Txt_Narr.Focus()
                End If
            End If


        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_RefNo_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs)
        Try
            If e.KeyCode = Keys.Enter Then
                Txt_Narr.Focus()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Cmb_TranType_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cmb_TranType.Click
        Call Hide_GridContorls()
    End Sub

    Private Sub Cmb_TranType_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Cmb_TranType.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then
                Cmb_PaymentMode.Focus()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Cmb_PaymentMode_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cmb_PaymentMode.Click
        Call Hide_GridContorls()
    End Sub

    Private Sub Cmb_PaymentMode_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Cmb_PaymentMode.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then
                Dgvw_GeneralVouchor.Focus()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Narr_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Txt_Narr.Click
        Call Hide_GridContorls()
    End Sub

    Private Sub Txt_Narr_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Narr.KeyDown '
        Try
            If e.KeyCode = Keys.Enter Then
                Cmb_TranType.Focus()
            End If
        Catch ex As Exception

        End Try
    End Sub
   
    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try
            Dim Dr As DataTableReader = Nothing
            Dim Dtbl As DataTable = Nothing
            Dim SaveFlg As Integer = 0

            Gen_Tran_BL = New Gen_Transaction_BL_Cls
            hms_helper = New Hms_Helperimpliments

            'Call Hide_GridContorls()

            'Validating Data controls
            If Not Validate_Fields() Then Exit Sub

            'Validating DataGridView controls
            If Not Validate_GridView() Then Exit Sub


            With Gen_Tran_BL

                .Tran_BatchID = Txt_BatchID.Text.Trim
                .Tr_Date = Dtp_Trandate.Value
                .Tr_Narration = Txt_Narr.Text.Trim
                .Tr_Pay_Mode = Cmb_PaymentMode.SelectedValue
                .Tr_Type = Cmb_TranType.SelectedValue
                .Tr_RefNo = "Gen"

                If Tr_Mode = Tran_Mode.New_Mode Then

                    If Gen_Tran_BL.Get_Maxmimum_BatchNo_GenTran(Dtbl) Then
                        Dr = Dtbl.CreateDataReader
                        Dr.Read()
                        Gen_Tran_BL.Tran_BatchID = Dr.GetValue(0).ToString.Trim
                        Txt_BatchID.Text = Dr.GetValue(0).ToString.Trim
                        If Txt_BatchID.Text.Trim = "" Then Gen_Tran_BL.Tran_BatchID = "0000000001" _
                      : Txt_BatchID.Text = "0000000001"

                    End If

                End If

                Dtbl = Nothing

                'Getting Transaction one by one saving 
                With Dgvw_GeneralVouchor

                    For i = 0 To .Rows.Count - 1

                        If Val(.Rows(i).Cells("Amount").Value) > 0 Then

                            If Tr_Mode = Tran_Mode.Edit_Mode Then

                                If (.Rows(i).Cells("Tran_ID").Value Is Nothing) Then
                                    Gen_Tran_BL.Tran_ID = 0
                                Else
                                    Gen_Tran_BL.Tran_ID = .Rows(i).Cells("Tran_ID").Value.ToString.Trim
                                End If


                            End If

                            Cmb_AccountHead.Text = .Rows(i).Cells("AccountHead").Value.ToString
                            Gen_Tran_BL.Acc_Code = Cmb_AccountHead.SelectedValue
                            Gen_Tran_BL.Tr_Remarks = .Rows(i).Cells("Narration").Value.ToString
                            Gen_Tran_BL.Tr_Amount = .Rows(i).Cells("Amount").Value.ToString

                            If Gen_Tran_BL.Save_Gen_Transaction(Dtbl, Tr_Mode, Txt_BatchID.Text) Then
                                If Dtbl.Rows(0).Item(0).ToString = "0" Then
                                    Gen_Tran_BL.Del_Gen_Transaction(Txt_BatchID.Text.Trim, Dtp_Trandate.Value)
                                    SaveFlg = 0
                                    Exit For
                                End If
                                SaveFlg = 1
                            Else
                                Gen_Tran_BL.Del_Gen_Transaction(Txt_BatchID.Text.Trim, Dtp_Trandate.Value)
                                SaveFlg = 0
                                Exit For
                            End If

                        End If

                    Next

                End With


                Dtbl = Nothing
                If SaveFlg = 1 Then
                    MessageBox.Show("General Transaction Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Call Locate_Values(Txt_BatchID.Text.Trim)
                    Btn_Clear_Click(sender, e)
                Else
                    MessageBox.Show("General Transaction Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If


            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Call Clear_Form()
        Txt_BatchID.Focus()
    End Sub

    Private Sub Txt_Totalamount_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Totalamount.TextChanged
        Try
            Lbl_Words.Text = Towords(Val(Txt_Totalamount.Text))
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try
            If Txt_BatchID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "10|10|10|100"
                Sql = "SELECT  [Batch No], [Account Head], [Transaction Type], [Payment  Mode], Tr_Amount, Narration"
                Sql += " FROM  Gen_Transaction_All_Vw where  Date = '" & Format(Tran_Date, "MM/dd/yyyy") & "' and ([Ref No] ='Gen' or [Ref No] ='') and Cancelled = 'N' and Br_Code = " & Branch_Code & " "
                Call ShowSearchengine(Txt_BatchID, Sql, 0, "[Account Head]", Colwidth, , 0)
            End If

            If Txt_BatchID.Text.Trim = "" Then
                Txt_BatchID.Focus() : Exit Sub
            End If

            'Locate Employee details 
            If Locate_Values(Txt_BatchID.Text.Trim) Then
                Btn_Delete.Enabled = True
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Print_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Print.Click
        Call Show_Reciept()
    End Sub

    Private Sub Btn_Uttility_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Uttility.Click
        Show_ChildForm("Gen_Transaction_Uttility", Me.MdiParent, Me.Tag)
    End Sub

    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click
        Try

            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If


            Dim dtbl As DataTable = Nothing

            Gen_Tran_BL = New Gen_Transaction_BL_Cls
            If MessageBox.Show("Cancel this transaction..(Y/N) ?", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.No Then Exit Sub

            If Gen_Tran_BL.Cancell_General_Transaction(dtbl, Txt_BatchID.Text.Trim, Txt_Narr.Text, Tran_Date, Tran_Date, Branch_Code) Then
                With Dgvw_GeneralVouchor
                    For i = 0 To .Rows.Count - 1
                        If .Rows(i).Cells("Amount").Value > 0 Then .Rows(i).Cells("Amount").Value = 0
                    Next
                End With
                MessageBox.Show("General Transaction Cancelled", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("General Transaction Not Cancelled", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

            Call Locate_Values(Txt_BatchID.Text)

        Catch ex As Exception

        End Try
    End Sub
End Class