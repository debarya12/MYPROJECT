﻿
Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls

Public Class AttendenceMaster_Frm

#Region "Declarations"
    'Object of Attendence Details Bussiness Layer
    Private Attendence_BL As Attendence_BL_Cls
    Private hms_helper As HMS_Helper = Nothing
    'Private Emp_BL As EmpDetails_BL_Cls
    Private mTr_Mode As Tran_Mode

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_PunchingID.BackColor = Color.White
                    Me.Txt_PunchingID.ReadOnly = False
                    Btn_Delete.Enabled = False
                    Timer1.Enabled = True
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_PunchingID.BackColor = Color.Silver
                    Me.Txt_PunchingID.ReadOnly = True
                    Btn_Delete.Enabled = False
                    Timer1.Enabled = False
            End Select
        End Set
    End Property

#End Region

#Region "Methods"

    Private Sub Clear_Form()
        Try



            Txt_PunchingID.Tag = ""
            Txt_PunchingID.Text = ""

            Txt_EmpID.Text = ""
            Txt_EmpID.Tag = ""
            Dgrd_History.DataSource = Nothing
            Dgrd_History.Refresh()
            Call Locate_Employee(0)
            Cmb_PunchingMode.SelectedIndex = 0

            Tr_Mode = Tran_Mode.New_Mode
            Btn_Save.Enabled = True
            Btn_Delete.Enabled = False

        Catch ex As Exception

        End Try
    End Sub

    Public Function Locate_Values(ByVal Punching_ID As Integer) As Boolean
        Try
            Dim dtbl As DataTable = Nothing
            Dim dr As DataTableReader = Nothing

            Attendence_BL = New Attendence_BL_Cls
            If Attendence_BL.Get_EmployeeAttendence(dtbl, Punching_ID) Then
                dr = dtbl.CreateDataReader
                dr.Read()
                With dr
                    Txt_EmpID.Text = dr.Item("Emp_ID").ToString
                    Call Locate_Employee(Txt_EmpID.Text.Trim)
                    Dtp_TranDate.Value = dr.Item("Tr_Date").ToString
                    Txt_PunchingTime.Text = dr.Item("Punching_Time").ToString
                End With
                Timer1.Enabled = False
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function

    Public Function AssignToControl(ByVal dtbl As DataTable) As Boolean
        Try
            Dim dr As DataTableReader
            Dr = dtbl.CreateDataReader()
            Dr.Read()
            With dr
                Txt_PunchingID.Text = .Item("Punching_ID").ToString
                Txt_EmpID.Text = .Item("Emp_ID").ToString
                Dtp_TranDate.Text = .Item("Tr_Date").ToString
                If dr.Item("Punching_Type").ToString = "I" Then
                    Cmb_PunchingMode.SelectedIndex = 0
                Else
                    Cmb_PunchingMode.SelectedIndex = 1
                End If
                Txt_PunchingTime.Text = dr.Item("Punching_Time").ToString
            End With
            Call Locate_Employee(Txt_EmpID.Text)
            Return True

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function

    Public Function Locate_Employee(ByVal Employee_ID As Integer) As Boolean
        Try

            With Imageviewer1
                .CUST_TYPE = Customer_Type.Employee
                .CUST_ID = Employee_ID

            End With
            Employee_Info1.Employee_ID = Employee_ID
            If Not Employee_Info1.Is_Valid Then Return False

            Call Set_PunchingType(Employee_ID)
            Call ShowGrid()
            Return True


        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try

    End Function

    Public Sub Set_PunchingType(ByVal Emp_ID As Integer)
        Dim dtbl As DataTable = Nothing
        Dim dr As DataTableReader = Nothing
        'Change the status of type(IN or Out)               

        Attendence_BL = New Attendence_BL_Cls
        Try
            If Attendence_BL.Get_EmpLastAttendence(dtbl, Emp_ID) Then
                dr = dtbl.CreateDataReader
                dr.Read()
                If dr.Item("Punching_Type").ToString = "I" Then
                    Cmb_PunchingMode.SelectedIndex = 1
                Else
                    Cmb_PunchingMode.SelectedIndex = 0
                End If
            Else
                Cmb_PunchingMode.SelectedIndex = 0
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Function Validate_Fields() As Boolean
        Try

            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If

            If Tr_Mode <> Tran_Mode.New_Mode Then
                If Txt_PunchingID.Text.Trim = "" Then MessageBox.Show("Invalid Punching ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_PunchingID.Focus() : Exit Function
            End If
            If Txt_EmpID.Text.Trim = "" Then MessageBox.Show("Invalid Employee ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_EmpID.Focus() : Exit Function
            If Txt_PunchingTime.Text.Trim = "" Then MessageBox.Show("Invalid Punching Time, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_EmpID.Focus() : Exit Function
            Return True

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try

    End Function

    Public Sub ShowGrid()
        Try
            Dim dtbl As DataTable = Nothing
            Dgrd_History.DataSource = Nothing
            Dgrd_History.Refresh()
            Attendence_BL = New Attendence_BL_Cls
            If Attendence_BL.Get_EmpLogdetails(dtbl, Txt_EmpID.Text) Then
                Dgrd_History.DataSource = Nothing
                Dgrd_History.DataSource = dtbl
                SetGrid_Colwidth("10|10|170", Dgrd_History)
                Dgrd_History.Refresh()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Function SetGrid_Colwidth(ByVal Req_Colwidth As String, ByVal Dgrd As Object) As Boolean
        Try

            Dim Col_Width() As String
            Col_Width = Split(Req_Colwidth, "|")
            If Col_Width.Length > 0 Then
                Dim i_Ctr As Short = 0
                With Dgrd
                    For i_Ctr = 0 To Col_Width.Length - 1
                        If .Columns.Count >= i_Ctr And Col_Width(i_Ctr).ToString.Trim <> "" Then
                            .Columns(i_Ctr).MinimumWidth = CInt(Col_Width(i_Ctr).ToString.Trim)
                        End If
                    Next
                End With
            End If
            Return True
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function

#End Region

    Private Sub AttendenceMaster_Frm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try


            Cmb_PunchingMode.Items.Add("In")
            Cmb_PunchingMode.Items.Add("Out")
            Cmb_PunchingMode.SelectedIndex = 0

            Txt_PunchingTime.Text = TimeValue(Now)

            Btn_Delete.Enabled = False
        Catch ex As Exception

        End Try
    End Sub

    Private Sub AttendenceMaster_Frm_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        Try
            Call KeepRightofme(Me, ImageViewer_Frm)
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Try
            Txt_PunchingTime.Text = TimeValue(Now)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try
            If Txt_PunchingID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "10|200|50|"
                Sql = "SELECT * FROM Get_EmployeeAttendence_Vw where br_code='" & Branch_Code & "'"
                Call ShowSearchengine(Txt_PunchingID, Sql, 0, "Name", Colwidth, , 0)
            End If

            If Txt_PunchingID.Text.Trim = "" Then
                Txt_PunchingID.Focus() : Exit Sub
            End If

            Tr_Mode = Tran_Mode.Edit_Mode
            Btn_Delete.Enabled = True

            'Locate Employee details 
            If Locate_Values(Txt_PunchingID.Text.Trim) = False Then
                MessageBox.Show("Punching ID does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_PunchingID.Focus()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_EmpID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_EmpID.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then Btn_Find1_Click(sender, e)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_EmpID_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_EmpID.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_EmpID.Text, Data_Type.Integer_Type, 10))
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_EmpID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_EmpID.TextChanged
        Try
            If Txt_EmpID.Text.Trim = "" Then
                Call Clear_Form()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_EmpID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_EmpID.Validating
        Try
            If Me.Txt_EmpID.Text.Trim <> "" And Me.Txt_EmpID.Text <> Me.Txt_EmpID.Tag Then
                If Locate_Employee(Txt_EmpID.Text.Trim) = False Then
                    MessageBox.Show("Employee ID does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Txt_EmpID.Focus()
                    e.Cancel = True
                End If
                'Seting Next Punching type (In Or Out)
                Call Set_PunchingType(Txt_EmpID.Text)
                Cmb_PunchingMode.Focus()
                Call ShowGrid()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Find1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find1.Click
        Try

            If Txt_EmpID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "10|200|50|"
                Sql = "SELECT * FROM GetEmployeeDetailsAll_Vw where Br_Code = " & Branch_Code & ""
                Call ShowSearchengine(Txt_EmpID, Sql, 0, "Name", Colwidth, , 0)
            End If

            If Txt_EmpID.Text.Trim = "" Then
                Txt_EmpID.Focus() : Exit Sub
            End If

            'Locate Employee details 
            If Locate_Employee(Txt_EmpID.Text.Trim) = False Then
                MessageBox.Show("Employee ID does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_EmpID.Focus()
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub AttendenceMaster_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then Call SendKeyTab()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub AttendenceMaster_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        Try
            If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try
            Call Clear_Form()
            Txt_PunchingID.Focus()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_PunchingID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_PunchingID.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then Btn_Find_Click(sender, e)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try

            Dim Dtbl As DataTable = Nothing

            Attendence_BL = New Attendence_BL_Cls

            'Validating Data controls
            If Not Validate_Fields() Then Exit Sub

            If Cmb_PunchingMode.Text = "In" Then
                If Not Attendence_BL.EnableLogIn(Txt_EmpID.Text) Then
                    MessageBox.Show("Employee not Logged Out, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
            Else
                If Not Attendence_BL.EnableLogOut(Txt_EmpID.Text) Then
                    MessageBox.Show("Employee not Logged In, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

            End If

            'Assigning Values to BL Properties

            Attendence_BL.Punching_ID = Val(Txt_PunchingID.Text)
            Attendence_BL.Emp_ID = Txt_EmpID.Text.Trim
            Attendence_BL.Tr_Date = Dtp_TranDate.Value
            Attendence_BL.Punching_Type = Strings.Left(Cmb_PunchingMode.Text, 1)
            Attendence_BL.Punching_Time = Txt_PunchingTime.Text

            If Attendence_BL.Save_Attendence(Dtbl, Tr_Mode, Val(Txt_PunchingID.Text.Trim)) Then
                MessageBox.Show("Employee Attendence Details Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Call Clear_Form()
                Txt_EmpID.Focus()
            Else
                MessageBox.Show("Employee Attendence Details not Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Try
            Me.Close()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_PunchingID_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_PunchingID.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_PunchingID.Text, Data_Type.Integer_Type, 5))
        Catch ex As Exception

        End Try
    End Sub

End Class