﻿Imports System.IO
Module ConnectionString
    Public Const cs As String = "Data Source=.\sqlexpress;Initial Catalog=hospitaldb;Integrated Security=True"
End Module
