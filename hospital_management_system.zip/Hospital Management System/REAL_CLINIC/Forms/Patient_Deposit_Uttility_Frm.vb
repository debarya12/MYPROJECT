﻿
Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls

Public Class Patient_deposit_Uttility_Frm
    Private Pat_Tran_BL As Patient_Transaction_BL_Cls
    Private Pat_Dep_BL As Patient_Deposit_Details_BL_Cls
    Private mRpt_Vwr As ReportViewer_Cls
    Private Rpt_BL As HMS_BL.Reports_BL_Cls
    Private hms_helper As HMS_Helper = Nothing

    Private Sub Patient_Transaction_Uttility_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then Call SendKeyTab()
    End Sub

    Private Sub Patient_Transaction_Uttility_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub Patient_Transaction_Uttility_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            hms_helper = New Hms_Helperimpliments

            Dim Add_Quary As String = ""

            Call Populate_GridView(Add_Quary)


            Cmb_Transaction_Type.Items.Add("< All >")
            Cmb_Transaction_Type.Items.Add("Reciept")
            Cmb_Transaction_Type.Items.Add("Payment")
            Cmb_Transaction_Type.SelectedIndex = 0

            Dtp_FromDate.Value = Tran_Date
            Dtp_ToDate.Value = Tran_Date
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Populate_GridView(ByVal Add_Quary As String)
        Try


            Dim dtbl As DataTable = Nothing
            Dim dr As DataTableReader = Nothing
            Dim dtst As DataSet = Nothing
            Pat_Dep_BL = New Patient_Deposit_Details_BL_Cls

            If Pat_Dep_BL.Get_Patients_Deposit_Details_All(dtst, Add_Quary) Then
                dtbl = dtst.Tables(0)

                Dim p As New Windows.Forms.Padding
                p.Left = 2
                p.Right = 2

                With Dgvw_SearchGrid
                    .DataSource = Nothing
                    .DataSource = dtbl

                    .Columns(0).Width = 90
                    .Columns(1).Width = 80
                    .Columns(2).Width = 120
                    .Columns(3).Width = 200
                    .Columns(4).Width = 90
                    .Columns(5).Width = 80
                    .Columns(6).Width = 120
                    .Columns(7).CellTemplate.Style.Alignment = DataGridViewContentAlignment.MiddleRight

                    For i = 0 To .Columns.Count - 1
                        .Columns(i).SortMode = DataGridViewColumnSortMode.NotSortable
                        If i <> 7 Then .Columns(i).CellTemplate.Style.Padding = p
                    Next
                    .Refresh()
                End With
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Uttility_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Uttility.Click
        Try

            Dim Add_Quary As String = ""

            REM patient name
            If Txt_PatientName.Text.Trim <> "" Then
                Add_Quary = "Where [Patient Name] like '" & "%" & Txt_PatientName.Text.Trim & "%" & "'"
            End If

            REM patient address
            If Txt_Address.Text.Trim <> "" Then
                If Add_Quary <> "" Then
                    Add_Quary = Add_Quary & " And [Address] like '" & "%" & Txt_Address.Text.Trim & "%" & "'"
                Else
                    Add_Quary = "Where [Address] like '" & "%" & Txt_Address.Text.Trim & "%" & "'"
                End If
            End If

            REM tramsaction date
            If Add_Quary <> "" Then
                Add_Quary = Add_Quary & " And [Tran Date] >= '" & Format(Dtp_FromDate.Value, "MM/dd/yyyy") _
                & "' And    [Tran Date] <= '" & Format(Dtp_ToDate.Value, "MM/dd/yyyy") & "'"
            Else
                Add_Quary = " Where [Tran Date] >= '" & Format(Dtp_FromDate.Value, "MM/dd/yyyy") _
               & "' And    [Tran Date] <= '" & Format(Dtp_ToDate.Value, "MM/dd/yyyy") & "'"
            End If
            REM patient ss number

            If Txt_SSNo.Text.Trim <> "" Then
                If Add_Quary <> "" Then
                    Add_Quary = Add_Quary & " And [S.S.No] = '" & Txt_SSNo.Text.Trim & "'"
                Else
                    Add_Quary = "Where [S.S.No] = '" & Txt_SSNo.Text.Trim & "'"
                End If
            End If

            REM transaction remarks
            If Txt_Remarks.Text <> "" Then
                If Add_Quary <> "" Then
                    Add_Quary = Add_Quary & " And [Narration] like   '" & "%" & Txt_Remarks.Text.Trim & "%" & "'"
                Else
                    Add_Quary = "Where [Narration] = '" & "%" & Txt_Remarks.Text.Trim & "%" & " &'"
                End If
            End If

            If Cmb_Transaction_Type.Text.Trim <> "< All >" Then
                If Add_Quary <> "" Then
                    Add_Quary = Add_Quary & " And [Tran Type]= '" & Cmb_Transaction_Type.Text & "'  "
                Else
                    Add_Quary = "Where [Tran Type]= '" & Cmb_Transaction_Type.Text & "' "
                End If

            End If

            Call Populate_GridView(Add_Quary)

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Clear_Form()
        Try

            Txt_Address.Text = ""
            Txt_Remarks.Text = ""



            Dtp_FromDate.Value = Tran_Date
            Dtp_ToDate.Value = Tran_Date

            Dim Add_Quary As String = ""
            Call Populate_GridView(Add_Quary)

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Call Clear_Form()
    End Sub

    Public Function Show_Reciept(ByVal Batch_ID As String) As Boolean
        Try
            If Batch_ID = "" Then MessageBox.Show("Invalid  Batch ID .. Please enter valid Tran Id", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Exit Function
            Dim Rpt_Ds As DataSet = Nothing
            Dim Rpt_Formulafields As String = "Company| " & Company_Name & "|Branch|" & Branch_Name
            Dim Rpt_Filename As String = ""
            Dim mReport_ID As String = ""
            Dim Report_Heading As String = ""
            Dim Add_Query As String = ""

            mRpt_Vwr = New ReportViewer_Cls

            Add_Query = ""
            Add_Query = "Where [Batch No] = " & Batch_ID & " "
            Rpt_Filename = File_Path & "\Gen_Tran_Reciept.rpt"
            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Get_GenTran_Reciept(Rpt_Ds, Add_Query) Then

                REM for Geting total amount 
                Dim dtbl As DataTable = Rpt_Ds.Tables(0)
                Dim dr As DataTableReader
                Dim Amt As Double
                Amt = 0
                dr = dtbl.CreateDataReader

                While dr.Read
                    Amt = Amt + Val(dr.Item("Tr_Amount").ToString)
                End While
                REM .....

                Report_Heading = "|Heading| Receipt|Footer3|Authorised Signatory"
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading & "|words|" & Towords(Amt)
                ' mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", , )
            Else
                MessageBox.Show("Invalid Batch ID .. Please enter valid Batch ID", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function

    Private Sub Dgvw_SearchGrid_CellClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgvw_SearchGrid.CellClick
        Try
            If Dgvw_SearchGrid.CurrentRow Is Nothing Then Exit Sub
            Dgvw_SearchGrid.CurrentRow.Selected = True

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgvw_SearchGrid_CellPainting(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellPaintingEventArgs) Handles Dgvw_SearchGrid.CellPainting
        Try
            If e.ColumnIndex = 0 AndAlso e.RowIndex <> -1 Then

                Using gridBrush As Brush = New SolidBrush(Me.Dgvw_SearchGrid.GridColor), backColorBrush As Brush = New SolidBrush(e.CellStyle.BackColor)

                    Using gridLinePen As Pen = New Pen(gridBrush)
                        ' Clear cell  
                        e.Graphics.FillRectangle(backColorBrush, e.CellBounds)

                        ' Draw line (bottom border and right border of current cell)  
                        'If next row cell has different content, only draw bottom border line of current cell  
                        If e.RowIndex < Dgvw_SearchGrid.Rows.Count - 2 AndAlso Dgvw_SearchGrid.Rows(e.RowIndex + 1).Cells(e.ColumnIndex).Value.ToString() <> e.Value.ToString() Then
                            e.Graphics.DrawLine(gridLinePen, e.CellBounds.Left, e.CellBounds.Bottom - 1, e.CellBounds.Right - 1, e.CellBounds.Bottom - 1)
                        End If

                        ' Draw right border line of current cell  
                        e.Graphics.DrawLine(gridLinePen, e.CellBounds.Right - 1, e.CellBounds.Top, e.CellBounds.Right - 1, e.CellBounds.Bottom)

                        ' draw/fill content in current cell, and fill only one cell of multiple same cells  
                        If Not e.Value Is Nothing Then
                            If e.RowIndex > 0 AndAlso Dgvw_SearchGrid.Rows(e.RowIndex - 1).Cells(e.ColumnIndex).Value.ToString() = e.Value.ToString() Then
                            Else
                                e.Graphics.DrawString(CType(e.Value, String), e.CellStyle.Font, Brushes.Black, e.CellBounds.X + 2, e.CellBounds.Y + 5, StringFormat.GenericDefault)
                            End If
                        End If

                        e.Handled = True
                    End Using
                End Using
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub Btn_Locate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Locate.Click
        Try
            Dim dtbl As DataTable = Nothing
            Dim dtst As DataSet = Nothing
            Pat_Dep_BL = New Patient_Deposit_Details_BL_Cls

            If Dgvw_SearchGrid.CurrentRow Is Nothing Then
                MessageBox.Show("Select a row befor Locate", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            If Pat_Dep_BL.Get_Patient_Deposit(dtbl, Dgvw_SearchGrid.CurrentRow.Cells("Tran_ID").Value.ToString, Branch_Code) Then

                With Patient_Deposit_Reg_Frm


                    hms_helper = New Hms_Helperimpliments
                    hms_helper.Fill_GenData(.Cmb_Payment_Mode, Gendatatype.Payment_Mode, "< Select >")
                    .Txt_PMRID.Text = dtbl.Rows(0).Item("Account ID").ToString.Trim
                    .Txt_Amount.Text = dtbl.Rows(0).Item("Amount").ToString.Trim
                    .Txt_Narration.Text = dtbl.Rows(0).Item("Narration").ToString.Trim
                    .Cmb_Payment_Mode.Text = dtbl.Rows(0).Item("Tran_Mode").ToString.Trim
                    .Txt_OutPatientID.Text = dtbl.Rows(0).Item("OP ID").ToString.Trim
                    .Txt_PatientID.Text = dtbl.Rows(0).Item("Patient ID").ToString.Trim
                    .Patient_Info2.Patient_ID = dtbl.Rows(0).Item("Patient ID").ToString.Trim
                    .Populate_Grid(dtbl.Rows(0).Item("Account ID").ToString.Trim)
                    .Txt_TranID.Text = dtbl.Rows(0).Item("Tran_ID").ToString.Trim
                    .Txt_Tran_BatchID.Text = dtbl.Rows(0).Item("Tran_BatchID").ToString.Trim

                    .Tr_Mode = Tran_Mode.Edit_Mode
                    If dtbl.Rows(0).Item("Tran_type").ToString.Trim <> "R" Or DateDiff(DateInterval.Day, Tran_Date, dtbl.Rows(0).Item("Tran date")) <> 0 Then
                        .Btn_Save.Enabled = False
                        .Btn_Cancel.Enabled = False
                    Else
                        .Txt_Amount.Enabled = False
                        .Btn_Save.Enabled = False
                        .Btn_Cancel.Enabled = True
                    End If

                    Call .Get_Patient_CreditPosition(dtbl.Rows(0).Item("Patient ID").ToString.Trim, dtbl.Rows(0).Item("OP ID").ToString.Trim)
                    .MdiParent = Me.MdiParent
                    If .Visible Then
                        .BringToFront()
                    Else
                        .Show()
                        Me.Close()
                    End If
                End With
                Exit Sub


            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgvw_SearchGrid_CellDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgvw_SearchGrid.CellDoubleClick
        Try
            Call Btn_Locate_Click(sender, e)
        Catch ex As Exception

        End Try
    End Sub

End Class