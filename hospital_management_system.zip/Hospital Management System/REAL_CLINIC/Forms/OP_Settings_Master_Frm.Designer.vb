﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class OP_Settings_Master_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(OP_Settings_Master_Frm))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Backward_Select_ALL_Pic = New System.Windows.Forms.PictureBox
        Me.Forward_Select_All_Pic = New System.Windows.Forms.PictureBox
        Me.Backward_Select_Pic = New System.Windows.Forms.PictureBox
        Me.Forward_Select_Pic = New System.Windows.Forms.PictureBox
        Me.ListTDrs = New System.Windows.Forms.ListBox
        Me.ListFDrs = New System.Windows.Forms.ListBox
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Txt_perDayVisit = New System.Windows.Forms.TextBox
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Delete = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.Label_PerdDayVisit = New System.Windows.Forms.Label
        Me.Txt_MaxVisit = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Cmb_Renewal = New System.Windows.Forms.ComboBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Txt_ValidDays = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Cmb_OpCategory = New System.Windows.Forms.ComboBox
        Me.Label16 = New System.Windows.Forms.Label
        Me.Dtp_TranDate = New System.Windows.Forms.DateTimePicker
        Me.Panel4 = New System.Windows.Forms.Panel
        Me.Dgrd_OP_Settings = New System.Windows.Forms.DataGridView
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Label5 = New System.Windows.Forms.Label
        Me.Panel2.SuspendLayout()
        CType(Me.Backward_Select_ALL_Pic, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Forward_Select_All_Pic, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Backward_Select_Pic, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Forward_Select_Pic, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Pnl_Tran_mode.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.Panel4.SuspendLayout()
        CType(Me.Dgrd_OP_Settings, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Pnl_Header.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel2
        '
        Me.Panel2.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel2.Controls.Add(Me.Backward_Select_ALL_Pic)
        Me.Panel2.Controls.Add(Me.Forward_Select_All_Pic)
        Me.Panel2.Controls.Add(Me.Backward_Select_Pic)
        Me.Panel2.Controls.Add(Me.Forward_Select_Pic)
        Me.Panel2.Controls.Add(Me.ListTDrs)
        Me.Panel2.Controls.Add(Me.ListFDrs)
        Me.Panel2.Location = New System.Drawing.Point(7, 26)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(674, 214)
        Me.Panel2.TabIndex = 0
        '
        'Backward_Select_ALL_Pic
        '
        Me.Backward_Select_ALL_Pic.BackColor = System.Drawing.Color.Transparent
        Me.Backward_Select_ALL_Pic.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.arrows_seek_back
        Me.Backward_Select_ALL_Pic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Backward_Select_ALL_Pic.Location = New System.Drawing.Point(328, 163)
        Me.Backward_Select_ALL_Pic.Name = "Backward_Select_ALL_Pic"
        Me.Backward_Select_ALL_Pic.Size = New System.Drawing.Size(23, 33)
        Me.Backward_Select_ALL_Pic.TabIndex = 11
        Me.Backward_Select_ALL_Pic.TabStop = False
        '
        'Forward_Select_All_Pic
        '
        Me.Forward_Select_All_Pic.BackColor = System.Drawing.Color.Transparent
        Me.Forward_Select_All_Pic.BackgroundImage = CType(resources.GetObject("Forward_Select_All_Pic.BackgroundImage"), System.Drawing.Image)
        Me.Forward_Select_All_Pic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Forward_Select_All_Pic.Location = New System.Drawing.Point(328, 59)
        Me.Forward_Select_All_Pic.Name = "Forward_Select_All_Pic"
        Me.Forward_Select_All_Pic.Size = New System.Drawing.Size(23, 33)
        Me.Forward_Select_All_Pic.TabIndex = 10
        Me.Forward_Select_All_Pic.TabStop = False
        '
        'Backward_Select_Pic
        '
        Me.Backward_Select_Pic.BackColor = System.Drawing.Color.Transparent
        Me.Backward_Select_Pic.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.arrow_back
        Me.Backward_Select_Pic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Backward_Select_Pic.Location = New System.Drawing.Point(328, 124)
        Me.Backward_Select_Pic.Name = "Backward_Select_Pic"
        Me.Backward_Select_Pic.Size = New System.Drawing.Size(23, 33)
        Me.Backward_Select_Pic.TabIndex = 9
        Me.Backward_Select_Pic.TabStop = False
        '
        'Forward_Select_Pic
        '
        Me.Forward_Select_Pic.BackColor = System.Drawing.Color.Transparent
        Me.Forward_Select_Pic.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.arrow_forward1
        Me.Forward_Select_Pic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Forward_Select_Pic.Location = New System.Drawing.Point(328, 20)
        Me.Forward_Select_Pic.Name = "Forward_Select_Pic"
        Me.Forward_Select_Pic.Size = New System.Drawing.Size(23, 33)
        Me.Forward_Select_Pic.TabIndex = 8
        Me.Forward_Select_Pic.TabStop = False
        '
        'ListTDrs
        '
        Me.ListTDrs.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListTDrs.FormattingEnabled = True
        Me.ListTDrs.Location = New System.Drawing.Point(355, 8)
        Me.ListTDrs.Name = "ListTDrs"
        Me.ListTDrs.Size = New System.Drawing.Size(306, 199)
        Me.ListTDrs.TabIndex = 3
        '
        'ListFDrs
        '
        Me.ListFDrs.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListFDrs.FormattingEnabled = True
        Me.ListFDrs.Location = New System.Drawing.Point(15, 8)
        Me.ListFDrs.Name = "ListFDrs"
        Me.ListFDrs.Size = New System.Drawing.Size(307, 199)
        Me.ListFDrs.TabIndex = 0
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(129, Byte), Integer))
        Me.Panel3.Controls.Add(Me.Panel1)
        Me.Panel3.Location = New System.Drawing.Point(7, 242)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(674, 136)
        Me.Panel3.TabIndex = 6
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(124, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel1.Controls.Add(Me.Txt_perDayVisit)
        Me.Panel1.Controls.Add(Me.Pnl_Tran_mode)
        Me.Panel1.Controls.Add(Me.Pnl_Common_Btn)
        Me.Panel1.Controls.Add(Me.Label_PerdDayVisit)
        Me.Panel1.Controls.Add(Me.Txt_MaxVisit)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Cmb_Renewal)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Txt_ValidDays)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.Cmb_OpCategory)
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Controls.Add(Me.Dtp_TranDate)
        Me.Panel1.Location = New System.Drawing.Point(1, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(672, 132)
        Me.Panel1.TabIndex = 1
        '
        'Txt_perDayVisit
        '
        Me.Txt_perDayVisit.Location = New System.Drawing.Point(200, 63)
        Me.Txt_perDayVisit.Name = "Txt_perDayVisit"
        Me.Txt_perDayVisit.Size = New System.Drawing.Size(118, 21)
        Me.Txt_perDayVisit.TabIndex = 4
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(506, 7)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(74, 22)
        Me.Pnl_Tran_mode.TabIndex = 105
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(1, 1)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(68, 16)
        Me.Lbl_Tran_Mode.TabIndex = 126
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(75, Byte), Integer), CType(CType(158, Byte), Integer), CType(CType(214, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Delete)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(586, 4)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(74, 126)
        Me.Pnl_Common_Btn.TabIndex = 1082
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(8, 63)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear.TabIndex = 14
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(8, 94)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 15
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Delete
        '
        Me.Btn_Delete.BackgroundImage = CType(resources.GetObject("Btn_Delete.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Delete.Location = New System.Drawing.Point(8, 33)
        Me.Btn_Delete.Name = "Btn_Delete"
        Me.Btn_Delete.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Delete.TabIndex = 13
        Me.Btn_Delete.Text = "&Delete"
        Me.Btn_Delete.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = CType(resources.GetObject("Btn_Save.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(8, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save.TabIndex = 7
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Label_PerdDayVisit
        '
        Me.Label_PerdDayVisit.AutoSize = True
        Me.Label_PerdDayVisit.BackColor = System.Drawing.Color.Transparent
        Me.Label_PerdDayVisit.ForeColor = System.Drawing.Color.White
        Me.Label_PerdDayVisit.Location = New System.Drawing.Point(197, 47)
        Me.Label_PerdDayVisit.Name = "Label_PerdDayVisit"
        Me.Label_PerdDayVisit.Size = New System.Drawing.Size(113, 13)
        Me.Label_PerdDayVisit.TabIndex = 1081
        Me.Label_PerdDayVisit.Text = "OP.Per Day Visit No"
        '
        'Txt_MaxVisit
        '
        Me.Txt_MaxVisit.Location = New System.Drawing.Point(14, 103)
        Me.Txt_MaxVisit.Name = "Txt_MaxVisit"
        Me.Txt_MaxVisit.Size = New System.Drawing.Size(98, 21)
        Me.Txt_MaxVisit.TabIndex = 5
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(12, 87)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(93, 13)
        Me.Label4.TabIndex = 1078
        Me.Label4.Text = "OP.Max Visit No"
        '
        'Cmb_Renewal
        '
        Me.Cmb_Renewal.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Renewal.FormattingEnabled = True
        Me.Cmb_Renewal.Items.AddRange(New Object() {"Yes", "No"})
        Me.Cmb_Renewal.Location = New System.Drawing.Point(199, 23)
        Me.Cmb_Renewal.Name = "Cmb_Renewal"
        Me.Cmb_Renewal.Size = New System.Drawing.Size(119, 21)
        Me.Cmb_Renewal.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(197, 7)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(73, 13)
        Me.Label3.TabIndex = 1076
        Me.Label3.Text = "OP.Renewal"
        '
        'Txt_ValidDays
        '
        Me.Txt_ValidDays.Location = New System.Drawing.Point(14, 63)
        Me.Txt_ValidDays.Name = "Txt_ValidDays"
        Me.Txt_ValidDays.Size = New System.Drawing.Size(98, 21)
        Me.Txt_ValidDays.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(12, 47)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(98, 13)
        Me.Label2.TabIndex = 1074
        Me.Label2.Text = "OP.Validity Days"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(11, 7)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(77, 13)
        Me.Label1.TabIndex = 1073
        Me.Label1.Text = "OP.Category"
        '
        'Cmb_OpCategory
        '
        Me.Cmb_OpCategory.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_OpCategory.FormattingEnabled = True
        Me.Cmb_OpCategory.Location = New System.Drawing.Point(14, 23)
        Me.Cmb_OpCategory.Name = "Cmb_OpCategory"
        Me.Cmb_OpCategory.Size = New System.Drawing.Size(170, 21)
        Me.Cmb_OpCategory.TabIndex = 1
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(197, 87)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(34, 13)
        Me.Label16.TabIndex = 1071
        Me.Label16.Text = "Date"
        '
        'Dtp_TranDate
        '
        Me.Dtp_TranDate.CustomFormat = "dd/MM/yyyy"
        Me.Dtp_TranDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_TranDate.Location = New System.Drawing.Point(199, 103)
        Me.Dtp_TranDate.Name = "Dtp_TranDate"
        Me.Dtp_TranDate.Size = New System.Drawing.Size(121, 21)
        Me.Dtp_TranDate.TabIndex = 6
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.Blue
        Me.Panel4.Controls.Add(Me.Dgrd_OP_Settings)
        Me.Panel4.Location = New System.Drawing.Point(7, 379)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(674, 182)
        Me.Panel4.TabIndex = 7
        '
        'Dgrd_OP_Settings
        '
        Me.Dgrd_OP_Settings.AllowUserToAddRows = False
        Me.Dgrd_OP_Settings.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(252, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.Navy
        Me.Dgrd_OP_Settings.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.Dgrd_OP_Settings.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Dgrd_OP_Settings.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(87, Byte), Integer), CType(CType(157, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgrd_OP_Settings.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.Dgrd_OP_Settings.ColumnHeadersHeight = 20
        Me.Dgrd_OP_Settings.Location = New System.Drawing.Point(2, 2)
        Me.Dgrd_OP_Settings.MultiSelect = False
        Me.Dgrd_OP_Settings.Name = "Dgrd_OP_Settings"
        Me.Dgrd_OP_Settings.ReadOnly = True
        Me.Dgrd_OP_Settings.RowHeadersVisible = False
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(254, Byte), Integer))
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.Navy
        Me.Dgrd_OP_Settings.RowsDefaultCellStyle = DataGridViewCellStyle3
        Me.Dgrd_OP_Settings.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.Dgrd_OP_Settings.Size = New System.Drawing.Size(670, 177)
        Me.Dgrd_OP_Settings.TabIndex = 132
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = CType(resources.GetObject("Pnl_Header.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Header.Controls.Add(Me.Label5)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(686, 24)
        Me.Pnl_Header.TabIndex = 100001
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(3, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(232, 19)
        Me.Label5.TabIndex = 10000
        Me.Label5.Text = "O P   S e t t i n g s    M a s t e r"
        '
        'OP_Settings_Master_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.MainMenu_Bkg
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(686, 567)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "OP_Settings_Master_Frm"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Panel2.ResumeLayout(False)
        CType(Me.Backward_Select_ALL_Pic, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Forward_Select_All_Pic, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Backward_Select_Pic, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Forward_Select_Pic, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Pnl_Tran_mode.ResumeLayout(False)
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        CType(Me.Dgrd_OP_Settings, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents ListTDrs As System.Windows.Forms.ListBox
    Friend WithEvents ListFDrs As System.Windows.Forms.ListBox
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Delete As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Label_PerdDayVisit As System.Windows.Forms.Label
    Friend WithEvents Txt_MaxVisit As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Renewal As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Txt_ValidDays As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Cmb_OpCategory As System.Windows.Forms.ComboBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Dtp_TranDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Dgrd_OP_Settings As System.Windows.Forms.DataGridView
    Friend WithEvents Txt_perDayVisit As System.Windows.Forms.TextBox
    Friend WithEvents Forward_Select_Pic As System.Windows.Forms.PictureBox
    Friend WithEvents Backward_Select_Pic As System.Windows.Forms.PictureBox
    Friend WithEvents Forward_Select_All_Pic As System.Windows.Forms.PictureBox
    Friend WithEvents Backward_Select_ALL_Pic As System.Windows.Forms.PictureBox
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label5 As System.Windows.Forms.Label
End Class
