﻿

Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls

Public Class Userrights_Frm

#Region " D e c l a  r a t i o n s "

    Dim menu_Bl As Menumaster_BL_Cls
    Dim Emp_Bl As EmpDetails_BL_Cls
    Dim Dtbl As DataTable = Nothing

#End Region

#Region " P r o p e r t i e s "

    Dim _Emp_ID As Int32
    Private Property Emp_ID() As Int32
        Get
            Return _Emp_ID
        End Get
        Set(ByVal value As Int32)
            _Emp_ID = value
            If _Emp_ID = 0 Then
                Txt_Emp_Name.Text = ""
                Txt_Emp_Add.Text = ""
            End If
        End Set
    End Property

    Dim _eDesig_ID As Int32 = 0
    Private Property eDesig_ID() As Int32
        Get
            Return _eDesig_ID
        End Get
        Set(ByVal value As Int32)
            _eDesig_ID = value
        End Set
    End Property

#End Region

#Region " M e t h o d s "

    Private Sub Populate_Menugroup()
        Try
            menu_Bl = New Menumaster_BL_Cls

            If menu_Bl.Get_Reportgroup(Dtbl) Then
                Dim Drow As DataRow = Dtbl.NewRow
                Drow(0) = 0
                Drow(1) = "     <    A L L      >    "
                Dtbl.Rows.InsertAt(Drow, 0)

                Drow = Dtbl.NewRow
                Drow(0) = -1
                Drow(1) = "     <    S E L E C T   >            "
                Dtbl.Rows.InsertAt(Drow, 0)
                Call Fill_Combo(Cmb_Menugroup, Dtbl, "Menu_GroupName", "Menu_GrpID")
                If Cmb_Menugroup.Items.Count > 0 Then Cmb_Menugroup.SelectedIndex = 0
            End If


        Catch ex As Exception

        End Try

    End Sub

    Private Function Populate_Menuoptions(ByVal MenugrpID As Int32) As Boolean
        Try

            menu_Bl = New Menumaster_BL_Cls

            If menu_Bl.Get_Menuoptions(Dtbl, MenugrpID) Then

                With Dgv_Userrights
                    .RowCount = 0
                    .Columns("Formname").Width = 347
                    For i = 0 To Dtbl.Rows.Count - 1
                        .Rows.Add()
                        .Rows(i).Cells("Formname").Value = Dtbl.Rows(i).Item("Menu_Name").ToString
                        .Rows(i).Cells("FormID").Value = Dtbl.Rows(i).Item("Menu_ID").ToString
                    Next
                    Dim DGVVerticalScroll = .Controls.OfType(Of VScrollBar).SingleOrDefault
                    If DGVVerticalScroll.Visible Then
                        .Columns("Formname").Width = 330
                    End If
                End With


            End If


            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Populate_Allotmenttype()
        Try
            With Cmb_Allotmenttype
                .Items.Add("    <   S E L E C T     >   ")
                .Items.Add("Designation Wise")
                .Items.Add("Employee Wise")
                .SelectedIndex = 0
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Pupulate_Designations()
        Try
            Dim Hms_Helper As HMS_Helper = New Hms_Helperimpliments

            Hms_Helper.Fill_Designations(ChkLst_Designations)
        Catch ex As Exception

        End Try
    End Sub

    Private Function Locate_EmpDetails(ByVal _EmpID As Int32) As Boolean


        Try

            'Initialising BL Object
            Emp_Bl = New EmpDetails_BL_Cls

            Dtbl = Nothing
            Call Clear_Grid()
            Emp_ID = 0 'TO Clear Emplyee details
            Emp_ID = _EmpID

            Btn_Loaddefault.Visible = False

            'Retreiving Employee Details and Assign the values to respective controls
            If Emp_Bl.GetEmp_Details(Dtbl, _EmpID) Then

                Emp_ID = _EmpID

                Txt_Emp_Name.Text = Dtbl.Rows(0).Item("Name").ToString
                Txt_Emp_Add.Text = Dtbl.Rows(0).Item("Address").ToString
                eDesig_ID = Dtbl.Rows(0).Item("Desig_ID").ToString
                Call Locate_Employee_Rights(_EmpID)
                Btn_Loaddefault.Visible = True
                Return True
            Else
                Return False
            End If



        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False

        End Try

    End Function

    Private Sub Clear_Form()
        Try

            Cmb_Menugroup.SelectedIndex = 0
            Cmb_Allotmenttype.SelectedIndex = 0
            Emp_ID = 0
            eDesig_ID = 0

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Clear_Grid()
        Try
            With Dgv_Userrights
                For i = 0 To .Rows.Count - 1
                    .Rows(i).Cells("Viewright").Value = False
                    .Rows(i).Cells("Addright").Value = False
                    .Rows(i).Cells("Editright").Value = False
                    .Rows(i).Cells("Deleteright").Value = False
                Next
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Function Save_User_Rights(ByVal EMPID As String) As Boolean
        Try

            Dim Dtbl As DataTable = Nothing
            Dim Userrights_Dtbl As DataTable = Nothing

            Dim Viewright, Addright, Editright, Delright As Boolean
            Dim ViewrightColvalue, AddrightColvalue, EditrightColvalue, DelrightColvalue As String
            Dim sEmp_ID As String = Strings.Right("000" + EMPID, 3)

            Dim Is_Alreadydataexists As Boolean = False

            Emp_Bl = New EmpDetails_BL_Cls
            If Emp_Bl.Get_User_Rights(Userrights_Dtbl, Tran_Date) Then
                Is_Alreadydataexists = True

            End If



            With Dgv_Userrights
                For i = 0 To .Rows.Count - 1

                    Viewright = .Rows(i).Cells("Viewright").Value()
                    Addright = .Rows(i).Cells("Addright").Value()
                    Editright = .Rows(i).Cells("Editright").Value()
                    Delright = .Rows(i).Cells("Deleteright").Value()

                    'Initialising 
                    ViewrightColvalue = ""
                    AddrightColvalue = ""
                    EditrightColvalue = ""
                    DelrightColvalue = ""

                    If Viewright Then ViewrightColvalue = sEmp_ID + "|"
                    If Addright Then AddrightColvalue = sEmp_ID + "|"
                    If Editright Then EditrightColvalue = sEmp_ID + "|"
                    If Delright Then DelrightColvalue = sEmp_ID + "|"

                    If Is_Alreadydataexists Then
                        If Not Set_Colvalue(Userrights_Dtbl, .Rows(i).Cells("FormID").Value.ToString, _
                                            sEmp_ID, Viewright, Addright, Editright, Delright, _
                                            ViewrightColvalue, AddrightColvalue, EditrightColvalue, _
                                            DelrightColvalue) Then
                            Return False
                        End If
                    End If

                    If Not Emp_Bl.Save_User_Rights(Dtbl, Tran_Mode.New_Mode, _
                                                   Tran_Date, _
                                                   .Rows(i).Cells("FormID").Value.ToString, _
                                                   ViewrightColvalue, _
                                                   AddrightColvalue, _
                                                   EditrightColvalue, _
                                                   DelrightColvalue) Then
                        Return False
                    End If
                Next
            End With
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Set_Colvalue(ByVal Dtbl As DataTable, _
                                  ByVal FormID As Int32, _
                                  ByVal EmpID As String, _
                                  ByVal Viewright As Boolean, _
                                  ByVal Addright As Boolean, _
                                  ByVal Editright As Boolean, _
                                  ByVal Delright As Boolean, _
                                  ByRef ViewrightColvalue As String, _
                                  ByRef AddrightColvalue As String, _
                                  ByRef EditrightColvalue As String, _
                                  ByRef DelrightColvalue As String) As Boolean
        Try


            Dim tempdtbl As DataTable = Nothing
            Dim rowSet As DataRow()
            Dim myRow As DataRow
            Dim Searchstr As String = EmpID + "|"


            If Dtbl Is Nothing Then Return True
            rowSet = Dtbl.Select("(Menu_ID = " + FormID.ToString + ")")
            tempdtbl = New DataTable
            tempdtbl = Dtbl.Clone

            Dim Drow As DataRow

            For Each myRow In rowSet
                Drow = tempdtbl.NewRow
                For i = 0 To myRow.ItemArray.Count - 1
                    Drow.Item(i) = myRow.Item(i).ToString
                Next
                tempdtbl.Rows.Add(Drow)
            Next myRow

            If tempdtbl.Rows.Count = 0 Then Return True



            'View Right
            ViewrightColvalue = tempdtbl.Rows(0).Item("Viewright").ToString
            ViewrightColvalue = Replace(ViewrightColvalue, Searchstr, "")
            If Viewright Then
                ViewrightColvalue = ViewrightColvalue + Searchstr
            End If

            'Add Right
            AddrightColvalue = tempdtbl.Rows(0).Item("Addright").ToString
            AddrightColvalue = Replace(AddrightColvalue, Searchstr, "")
            If Addright Then
                AddrightColvalue = AddrightColvalue + Searchstr
            End If

            'Edit Right
            EditrightColvalue = tempdtbl.Rows(0).Item("Editright").ToString
            EditrightColvalue = Replace(EditrightColvalue, Searchstr, "")
            If Editright Then
                EditrightColvalue = EditrightColvalue + Searchstr
            End If

            'Delete Right
            DelrightColvalue = tempdtbl.Rows(0).Item("Deleteright").ToString
            DelrightColvalue = Replace(DelrightColvalue, Searchstr, "")
            If Delright Then
                DelrightColvalue = DelrightColvalue + Searchstr
            End If

            Return True


        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Locate_Employee_Rights(ByVal EmpID As String) As Boolean
        Try


            Dim e_Dtbl As DataTable = Nothing
            Dim _Formid As String = ""
            Dim _viewright, _Addright, _Editright, _Delright As Boolean
            Dim Searchstring As String = ""


            EmpID = Strings.Right("000" + EmpID, 3)


            Emp_Bl = New EmpDetails_BL_Cls
            If Emp_Bl.Get_User_Rights(e_Dtbl, Tran_Date) Then
                With Dgv_Userrights
                    For i = 0 To e_Dtbl.Rows.Count - 1

                        _viewright = False : _Addright = False : _Editright = False : _Delright = False
                        _Formid = e_Dtbl.Rows(i).Item("Menu_ID").ToString

                        Searchstring = e_Dtbl.Rows(i).Item("Viewright").ToString()
                        If Strings.InStr(Searchstring, EmpID) > 0 Then
                            _viewright = True
                        End If
                        Searchstring = e_Dtbl.Rows(i).Item("Addright").ToString()
                        If Strings.InStr(Searchstring, EmpID) > 0 Then
                            _Addright = True
                        End If
                        Searchstring = e_Dtbl.Rows(i).Item("Editright").ToString()
                        If Strings.InStr(Searchstring, EmpID) > 0 Then
                            _Editright = True
                        End If
                        Searchstring = e_Dtbl.Rows(i).Item("Deleteright").ToString()
                        If Strings.InStr(Searchstring, EmpID) > 0 Then
                            _Delright = True
                        End If


                        Dim SelRow As DataGridViewRow = (From Rows In Dgv_Userrights.Rows.Cast(Of DataGridViewRow)() _
                                                         Where Rows.Cells("FormID").Value.ToString() = _Formid).FirstOrDefault

                        If Not IsNothing(SelRow) Then
                            SelRow.Cells("Viewright").Value = _viewright
                            SelRow.Cells("Addright").Value = _Addright
                            SelRow.Cells("Editright").Value = _Editright
                            SelRow.Cells("Deleteright").Value = _Delright
                        End If

                    Next
                End With
            End If

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Mark_RightVertical(ByVal Markcolumn As String, ByVal Mark As Boolean)
        Try
            With Dgv_Userrights
                For i = 0 To .Rows.Count - 1
                    .Rows(i).Cells(Markcolumn).Value = Mark
                Next
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Mark_RightHorizontal(ByVal Markrowindex As Integer, ByVal Mark As Boolean)
        Try
            With Dgv_Userrights

                .Rows(Markrowindex).Cells("Viewright").Value = Mark
                .Rows(Markrowindex).Cells("Addright").Value = Mark
                .Rows(Markrowindex).Cells("Editright").Value = Mark
                .Rows(Markrowindex).Cells("Deleteright").Value = Mark
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Function Save_Designation_Rights() As Boolean
        Try
            Dim Dtbl As DataTable = Nothing


            Dim Viewright, Addright, Editright, Delright As Boolean
            Dim ViewrightColvalue, AddrightColvalue, EditrightColvalue, DelrightColvalue As String
            Dim _FormID As String = ""
            Dim _Desig_ID As Int32 = 0
            Dim _Sel_Text As String = ""
            Dim _Sel_Value As String = ""

            Emp_Bl = New EmpDetails_BL_Cls




            With Dgv_Userrights

                For k = 0 To ChkLst_Designations.Items.Count - 1
                    If ChkLst_Designations.GetItemCheckState(k) = CheckState.Checked Then

                        ChkLst_Designations.SelectedIndex = k

                        If Not Selectlist_Item_Value(ChkLst_Designations, _Sel_Text, _Sel_Value) Then Return False
                        _Desig_ID = _Sel_Value

                        'Initialising 
                        ViewrightColvalue = ""
                        AddrightColvalue = ""
                        EditrightColvalue = ""
                        DelrightColvalue = ""

                        For i = 0 To .Rows.Count - 1

                            _FormID = Strings.Right("000" + .Rows(i).Cells("FormID").Value(), 3)

                            Viewright = .Rows(i).Cells("Viewright").Value()
                            Addright = .Rows(i).Cells("Addright").Value()
                            Editright = .Rows(i).Cells("Editright").Value()
                            Delright = .Rows(i).Cells("Deleteright").Value()



                            If Viewright Then ViewrightColvalue += _FormID + "|"
                            If Addright Then AddrightColvalue += _FormID + "|"
                            If Editright Then EditrightColvalue += _FormID + "|"
                            If Delright Then DelrightColvalue += _FormID + "|"


                        Next
                        If Not Emp_Bl.Save_Desig_Rights(Dtbl, Tran_Mode.New_Mode, _
                                                           Tran_Date, _
                                                           _Desig_ID, _
                                                           ViewrightColvalue, _
                                                           AddrightColvalue, _
                                                           EditrightColvalue, _
                                                           DelrightColvalue) Then
                            Return False
                        End If
                    End If
                Next
            End With

            Return True
        Catch ex As Exception
            Return False
        End Try

    End Function

    Private Function Locate_Desig_Rights(ByVal Desig_ID As String) As Boolean
        Try


            Dim d_Dtbl As DataTable = Nothing
            Dim _Formid As String = ""
            Dim _viewright, _Addright, _Editright, _Delright As Boolean
            Dim Searchstring As String = ""


            Emp_Bl = New EmpDetails_BL_Cls

            If Emp_Bl.Get_Desig_Rights(d_Dtbl, Desig_ID, Tran_Date) Then
                With Dgv_Userrights
                    For i = 0 To .Rows.Count - 1
                        _Formid = Strings.Right("000" + .Rows(i).Cells("FormID").Value(), 3)
                        _viewright = False : _Addright = False : _Editright = False : _Delright = False

                        Searchstring = d_Dtbl.Rows(0).Item("Viewright").ToString()
                        If Strings.InStr(Searchstring, _Formid) > 0 Then
                            _viewright = True
                        End If
                        Searchstring = d_Dtbl.Rows(0).Item("Addright").ToString()
                        If Strings.InStr(Searchstring, _Formid) > 0 Then
                            _Addright = True
                        End If
                        Searchstring = d_Dtbl.Rows(0).Item("Editright").ToString()
                        If Strings.InStr(Searchstring, _Formid) > 0 Then
                            _Editright = True
                        End If
                        Searchstring = d_Dtbl.Rows(0).Item("Deleteright").ToString()
                        If Strings.InStr(Searchstring, _Formid) > 0 Then
                            _Delright = True
                        End If

                        .Rows(i).Cells("Viewright").Value = _viewright
                        .Rows(i).Cells("Addright").Value = _Addright
                        .Rows(i).Cells("Editright").Value = _Editright
                        .Rows(i).Cells("Deleteright").Value = _Delright


                    Next
                End With
            End If

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Validate_Fields() As Boolean
        Try

            Dim Accesstype As Access_Type = Access_Type.Add
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If


            If Cmb_Menugroup.SelectedIndex = 0 Then MessageBox.Show("Please Select Menu Group and Proceed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_Menugroup.Focus() : Exit Function
            If Cmb_Allotmenttype.SelectedIndex = 0 Then MessageBox.Show("Please Select Allotmenttype and Proceed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_Allotmenttype.Focus() : Exit Function

            If Pnl_Designations.Enabled Then
                If ChkLst_Designations.CheckedItems.Count = 0 Then MessageBox.Show("Please Select Atleast one Designation and Proceed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : ChkLst_Designations.Focus() : Exit Function
            End If

            If Pnl_Empdetails.Visible Then
                If Emp_ID = 0 Then MessageBox.Show("Invalid Employee Details,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Emp_Name.Focus() : Exit Function
            End If

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

#End Region


    Private Sub Userrights_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then SendKeyTab()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Userrights_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub Userrights_Frm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            Call Populate_Menugroup()
            Call Populate_Allotmenttype()
            Call Pupulate_Designations()

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

    Private Sub Cmb_Menugroup_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_Menugroup.SelectedIndexChanged
        Try
            If Cmb_Menugroup.SelectedIndex = 0 Then
                With Dgv_Userrights
                    .RowCount = 0
                End With
                Exit Sub
            End If

            Call Populate_Menuoptions(Cmb_Menugroup.SelectedValue)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try
            If Txt_Emp_Name.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "25|200|200|"
                Sql = "SELECT Name, Address, Phone, Mobile, Email, Status, [Admit Date], [Deactivate Date], Emp_ID From Emp_Details_Vw"
                Call ShowSearchengine(Txt_Emp_Name, Sql, 8, "Name", Colwidth, , 0)
            End If

            Emp_ID = Val(Txt_Emp_Name.Text)

            'Validating Mandatory fields for locating
            If Emp_ID = 0 Then
                'MessageBox.Show("Invalid Employee ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_Emp_Name.Focus() : Exit Sub
            End If


            If Not Locate_EmpDetails(Emp_ID) Then
                MessageBox.Show("Employee ID does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Dgv_Userrights_CellMouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles Dgv_Userrights.CellMouseDoubleClick
        Try
            If e.RowIndex = -1 Then Exit Sub
            If e.ColumnIndex <> 0 Then Exit Sub

            Call Mark_RightHorizontal(e.RowIndex, Not Dgv_Userrights.Rows(e.RowIndex).Cells("Viewright").Value)

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgv_Userrights_ColumnHeaderMouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles Dgv_Userrights.ColumnHeaderMouseDoubleClick
        Try
            Dim Columname As String = Dgv_Userrights.Columns(e.ColumnIndex).Name
            With Dgv_Userrights
                If .Rows.Count <= 0 Then Exit Sub
                .CurrentCell = Dgv_Userrights(0, 0)
                Call Mark_RightVertical(Columname, Not .Rows(0).Cells(Columname).Value)
            End With

        Catch ex As Exception

        End Try
    End Sub


    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try

            'Validating Fields
            If Not Validate_Fields() Then Exit Sub

            If Cmb_Allotmenttype.SelectedIndex = 1 Then
                If Save_Designation_Rights() Then
                    MessageBox.Show("Designation Rights Assignment Completed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Else
                    MessageBox.Show("Designation Rights Assignment not performed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
            ElseIf Cmb_Allotmenttype.SelectedIndex = 2 Then
                If Save_User_Rights(_Emp_ID) Then
                    MessageBox.Show("User Rights Assignment Completed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)

                Else
                    MessageBox.Show("User Rights Assignment not performed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try
            Call Clear_Form()
            Cmb_Menugroup.Focus()

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Cmb_Allotmenttype_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_Allotmenttype.SelectedIndexChanged
        Try
            Pnl_Designations.Enabled = False
            Pnl_Empdetails.Visible = False
            Dgv_Userrights.Enabled = True


            Select Case Cmb_Allotmenttype.SelectedIndex
                Case 0
                    Dgv_Userrights.Enabled = False
                Case 1
                    Pnl_Designations.Enabled = True
                Case 2
                    Pnl_Empdetails.Visible = True
            End Select
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Pnl_Designations_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Pnl_Designations.EnabledChanged
        Try
            With ChkLst_Designations
                For i = 0 To .Items.Count - 1
                    .SetItemChecked(i, False)
                Next
            End With

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Pnl_Empdetails_VisibleChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Pnl_Empdetails.VisibleChanged
        Try
            Txt_Emp_Name.Text = ""
            Txt_Emp_Add.Text = ""
            If Not Pnl_Empdetails.Visible Then
                Btn_Loaddefault.Visible = False
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub ChkLst_Designations_ItemCheck(ByVal sender As Object, ByVal e As System.Windows.Forms.ItemCheckEventArgs) Handles ChkLst_Designations.ItemCheck
        Try

            Call Clear_Grid()
            With ChkLst_Designations
                If e.NewValue = CheckState.Checked Then
                    Dim _Sel_Text As String = ""
                    Dim _Sel_Value As String = ""

                    If Not Selectlist_Item_Value(ChkLst_Designations, _Sel_Text, _Sel_Value) Then Return
                    Call Locate_Desig_Rights(_Sel_Value)
                End If
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Loaddefault_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Loaddefault.Click
        Try
            If _eDesig_ID = 0 Then Exit Sub

            Call Locate_Desig_Rights(_eDesig_ID)

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Emp_Name_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Emp_Name.TextChanged
        Try
            If Txt_Emp_Name.Text = "" Then Txt_Emp_Add.Text = ""
        Catch ex As Exception

        End Try
    End Sub


End Class