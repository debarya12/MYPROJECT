﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Billing_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Billing_Frm))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.Lst_Search = New System.Windows.Forms.ListBox
        Me.Txt_PatientID = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Txt_OutPatientID = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Btn_Find = New System.Windows.Forms.Button
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Txt_ExpenseMaster = New System.Windows.Forms.TextBox
        Me.Tvw_ExpenseList = New System.Windows.Forms.TreeView
        Me.Button1 = New System.Windows.Forms.Button
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Lbl_Words = New System.Windows.Forms.Label
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Delete = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.Btn_Add = New System.Windows.Forms.Button
        Me.Trancontrol1 = New Tran_Controls.Trancontrol
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label
        Me.Imageviewer1 = New TECHNO_CLINIC.Imageviewer
        Me.Patient_Info2 = New TECHNO_CLINIC.Patient_Info
        Me.Dgv_ChargesGrid = New TECHNO_CLINIC.Hms_DGridview(Me.components)
        Me.Expense = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Particulars = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Amount = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Acc_Code = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Particulars_ID = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Def_TranType = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Editable = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Exp_ID = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Pnl_Header.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.Pnl_Tran_mode.SuspendLayout()
        CType(Me.Dgv_ChargesGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = Global.TECHNO_CLINIC.My.Resources.Resources.Menu_Bkg
        Me.Pnl_Header.Controls.Add(Me.Label1)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(809, 24)
        Me.Pnl_Header.TabIndex = 10000
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(7, 1)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(84, 18)
        Me.Label1.TabIndex = 100000
        Me.Label1.Text = "B i l l i n g "
        '
        'Lst_Search
        '
        Me.Lst_Search.BackColor = System.Drawing.Color.White
        Me.Lst_Search.FormattingEnabled = True
        Me.Lst_Search.Location = New System.Drawing.Point(3, 27)
        Me.Lst_Search.Name = "Lst_Search"
        Me.Lst_Search.Size = New System.Drawing.Size(261, 108)
        Me.Lst_Search.TabIndex = 126
        Me.Lst_Search.Visible = False
        '
        'Txt_PatientID
        '
        Me.Txt_PatientID.BackColor = System.Drawing.Color.White
        Me.Txt_PatientID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_PatientID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PatientID.Location = New System.Drawing.Point(277, 46)
        Me.Txt_PatientID.MaxLength = 10
        Me.Txt_PatientID.Name = "Txt_PatientID"
        Me.Txt_PatientID.Size = New System.Drawing.Size(184, 21)
        Me.Txt_PatientID.TabIndex = 206
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(274, 30)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(64, 13)
        Me.Label5.TabIndex = 211
        Me.Label5.Text = "Patient ID"
        '
        'Txt_OutPatientID
        '
        Me.Txt_OutPatientID.BackColor = System.Drawing.Color.White
        Me.Txt_OutPatientID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_OutPatientID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_OutPatientID.Location = New System.Drawing.Point(5, 42)
        Me.Txt_OutPatientID.MaxLength = 10
        Me.Txt_OutPatientID.Name = "Txt_OutPatientID"
        Me.Txt_OutPatientID.Size = New System.Drawing.Size(154, 21)
        Me.Txt_OutPatientID.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(2, 26)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 13)
        Me.Label2.TabIndex = 210
        Me.Label2.Text = "OP ID"
        '
        'Btn_Find
        '
        Me.Btn_Find.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find.BackgroundImage = CType(resources.GetObject("Btn_Find.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find.ForeColor = System.Drawing.Color.White
        Me.Btn_Find.Location = New System.Drawing.Point(161, 42)
        Me.Btn_Find.Name = "Btn_Find"
        Me.Btn_Find.Size = New System.Drawing.Size(29, 21)
        Me.Btn_Find.TabIndex = 205
        Me.Btn_Find.TabStop = False
        Me.Btn_Find.Text = "F2"
        Me.Btn_Find.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.Controls.Add(Me.Txt_ExpenseMaster)
        Me.Panel1.Controls.Add(Me.Lst_Search)
        Me.Panel1.Controls.Add(Me.Tvw_ExpenseList)
        Me.Panel1.Location = New System.Drawing.Point(2, 65)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(270, 467)
        Me.Panel1.TabIndex = 213
        '
        'Txt_ExpenseMaster
        '
        Me.Txt_ExpenseMaster.BackColor = System.Drawing.Color.White
        Me.Txt_ExpenseMaster.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_ExpenseMaster.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_ExpenseMaster.Location = New System.Drawing.Point(3, 3)
        Me.Txt_ExpenseMaster.Name = "Txt_ExpenseMaster"
        Me.Txt_ExpenseMaster.Size = New System.Drawing.Size(260, 21)
        Me.Txt_ExpenseMaster.TabIndex = 1
        '
        'Tvw_ExpenseList
        '
        Me.Tvw_ExpenseList.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Tvw_ExpenseList.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tvw_ExpenseList.ItemHeight = 22
        Me.Tvw_ExpenseList.Location = New System.Drawing.Point(3, 27)
        Me.Tvw_ExpenseList.Name = "Tvw_ExpenseList"
        Me.Tvw_ExpenseList.Size = New System.Drawing.Size(263, 437)
        Me.Tvw_ExpenseList.TabIndex = 127
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button1.BackgroundImage = CType(resources.GetObject("Button1.BackgroundImage"), System.Drawing.Image)
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(467, 46)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(29, 21)
        Me.Button1.TabIndex = 214
        Me.Button1.TabStop = False
        Me.Button1.Text = "F2"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Transparent
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Location = New System.Drawing.Point(571, 468)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(229, 20)
        Me.Panel2.TabIndex = 216
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.Color.Blue
        Me.Label4.Location = New System.Drawing.Point(74, 6)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(147, 13)
        Me.Label4.TabIndex = 212
        Me.Label4.Text = "00.00"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.Blue
        Me.Label3.Location = New System.Drawing.Point(3, 6)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(42, 13)
        Me.Label3.TabIndex = 211
        Me.Label3.Text = "Total :"
        '
        'Lbl_Words
        '
        Me.Lbl_Words.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Words.ForeColor = System.Drawing.Color.Maroon
        Me.Lbl_Words.Location = New System.Drawing.Point(274, 491)
        Me.Lbl_Words.Name = "Lbl_Words"
        Me.Lbl_Words.Size = New System.Drawing.Size(526, 17)
        Me.Lbl_Words.TabIndex = 217
        Me.Lbl_Words.Text = "Words"
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Delete)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(571, 514)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(229, 35)
        Me.Pnl_Common_Btn.TabIndex = 218
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(168, 3)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 16
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(113, 3)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear.TabIndex = 15
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Delete
        '
        Me.Btn_Delete.BackgroundImage = CType(resources.GetObject("Btn_Delete.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Delete.Location = New System.Drawing.Point(58, 3)
        Me.Btn_Delete.Name = "Btn_Delete"
        Me.Btn_Delete.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Delete.TabIndex = 14
        Me.Btn_Delete.Text = "&Delete"
        Me.Btn_Delete.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = CType(resources.GetObject("Btn_Save.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(3, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save.TabIndex = 13
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Btn_Add
        '
        Me.Btn_Add.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Add.BackgroundImage = CType(resources.GetObject("Btn_Add.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Add.ForeColor = System.Drawing.Color.White
        Me.Btn_Add.Location = New System.Drawing.Point(652, 313)
        Me.Btn_Add.Name = "Btn_Add"
        Me.Btn_Add.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Add.TabIndex = 219
        Me.Btn_Add.Text = "&Add"
        Me.Btn_Add.UseVisualStyleBackColor = False
        '
        'Trancontrol1
        '
        Me.Trancontrol1.BackColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(123, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Trancontrol1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Trancontrol1.Location = New System.Drawing.Point(277, 190)
        Me.Trancontrol1.Name = "Trancontrol1"
        Me.Trancontrol1.Padding = New System.Windows.Forms.Padding(3)
        Me.Trancontrol1.Size = New System.Drawing.Size(369, 151)
        Me.Trancontrol1.TabIndex = 123
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(502, 46)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(74, 22)
        Me.Pnl_Tran_mode.TabIndex = 10001
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(3, 1)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(67, 16)
        Me.Lbl_Tran_Mode.TabIndex = 122
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Imageviewer1
        '
        Me.Imageviewer1.CUST_ID = ""
        Me.Imageviewer1.CUST_TYPE = HMS_Common.Common_Cls.Customer_Type.Employee
        Me.Imageviewer1.Location = New System.Drawing.Point(650, 42)
        Me.Imageviewer1.Name = "Imageviewer1"
        Me.Imageviewer1.Scan_Enabled = True
        Me.Imageviewer1.Size = New System.Drawing.Size(160, 255)
        Me.Imageviewer1.TabIndex = 215
        '
        'Patient_Info2
        '
        Me.Patient_Info2.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(175, Byte), Integer))
        Me.Patient_Info2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Patient_Info2.Location = New System.Drawing.Point(277, 68)
        Me.Patient_Info2.Name = "Patient_Info2"
        Me.Patient_Info2.Padding = New System.Windows.Forms.Padding(2)
        Me.Patient_Info2.Size = New System.Drawing.Size(369, 119)
        Me.Patient_Info2.TabIndex = 212
        '
        'Dgv_ChargesGrid
        '
        Me.Dgv_ChargesGrid.AllowUserToAddRows = False
        Me.Dgv_ChargesGrid.AllowUserToDeleteRows = False
        Me.Dgv_ChargesGrid.AllowUserToResizeColumns = False
        Me.Dgv_ChargesGrid.AllowUserToResizeRows = False
        Me.Dgv_ChargesGrid.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(118, Byte), Integer), CType(CType(155, Byte), Integer), CType(CType(197, Byte), Integer))
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(87, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(162, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.AliceBlue
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgv_ChargesGrid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.Dgv_ChargesGrid.ColumnHeadersHeight = 25
        Me.Dgv_ChargesGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.Dgv_ChargesGrid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Expense, Me.Particulars, Me.Amount, Me.Acc_Code, Me.Particulars_ID, Me.Def_TranType, Me.Editable, Me.Exp_ID})
        Me.Dgv_ChargesGrid.Location = New System.Drawing.Point(277, 346)
        Me.Dgv_ChargesGrid.Name = "Dgv_ChargesGrid"
        Me.Dgv_ChargesGrid.ReadOnly = True
        Me.Dgv_ChargesGrid.RowHeadersVisible = False
        Me.Dgv_ChargesGrid.Size = New System.Drawing.Size(523, 120)
        Me.Dgv_ChargesGrid.TabIndex = 127
        Me.Dgv_ChargesGrid.TabStop = False
        '
        'Expense
        '
        Me.Expense.HeaderText = "Expense"
        Me.Expense.Name = "Expense"
        Me.Expense.ReadOnly = True
        Me.Expense.Width = 215
        '
        'Particulars
        '
        Me.Particulars.HeaderText = "Particulars"
        Me.Particulars.Name = "Particulars"
        Me.Particulars.ReadOnly = True
        Me.Particulars.Width = 150
        '
        'Amount
        '
        Me.Amount.HeaderText = "Amount"
        Me.Amount.Name = "Amount"
        Me.Amount.ReadOnly = True
        Me.Amount.Width = 150
        '
        'Acc_Code
        '
        Me.Acc_Code.HeaderText = "Acc_Code"
        Me.Acc_Code.Name = "Acc_Code"
        Me.Acc_Code.ReadOnly = True
        Me.Acc_Code.Visible = False
        '
        'Particulars_ID
        '
        Me.Particulars_ID.HeaderText = "Particulars_ID"
        Me.Particulars_ID.Name = "Particulars_ID"
        Me.Particulars_ID.ReadOnly = True
        Me.Particulars_ID.Visible = False
        '
        'Def_TranType
        '
        Me.Def_TranType.HeaderText = "Def_TranType"
        Me.Def_TranType.Name = "Def_TranType"
        Me.Def_TranType.ReadOnly = True
        Me.Def_TranType.Visible = False
        '
        'Editable
        '
        Me.Editable.HeaderText = "Editable"
        Me.Editable.Name = "Editable"
        Me.Editable.ReadOnly = True
        Me.Editable.Visible = False
        '
        'Exp_ID
        '
        Me.Exp_ID.HeaderText = "Exp_ID"
        Me.Exp_ID.Name = "Exp_ID"
        Me.Exp_ID.ReadOnly = True
        Me.Exp_ID.Visible = False
        '
        'Billing_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.TECHNO_CLINIC.My.Resources.Resources.LeftGradiant
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(809, 555)
        Me.Controls.Add(Me.Pnl_Tran_mode)
        Me.Controls.Add(Me.Btn_Add)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.Lbl_Words)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Imageviewer1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Patient_Info2)
        Me.Controls.Add(Me.Txt_PatientID)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Txt_OutPatientID)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Btn_Find)
        Me.Controls.Add(Me.Dgv_ChargesGrid)
        Me.Controls.Add(Me.Trancontrol1)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Billing_Frm"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.Pnl_Tran_mode.ResumeLayout(False)
        CType(Me.Dgv_ChargesGrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Lst_Search As System.Windows.Forms.ListBox
    Friend WithEvents Dgv_ChargesGrid As TECHNO_CLINIC.Hms_DGridview
    Friend WithEvents Expense As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Particulars As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Amount As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Acc_Code As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Particulars_ID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Def_TranType As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Editable As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Exp_ID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Trancontrol1 As Tran_Controls.Trancontrol
    Friend WithEvents Patient_Info2 As TECHNO_CLINIC.Patient_Info
    Friend WithEvents Txt_PatientID As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Txt_OutPatientID As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Btn_Find As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Txt_ExpenseMaster As System.Windows.Forms.TextBox
    Friend WithEvents Tvw_ExpenseList As System.Windows.Forms.TreeView
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Imageviewer1 As TECHNO_CLINIC.Imageviewer
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Words As System.Windows.Forms.Label
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Delete As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Btn_Add As System.Windows.Forms.Button
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
End Class
