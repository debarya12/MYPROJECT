﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Patient_Deposit_Reg_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Patient_Deposit_Reg_Frm))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.Txt_PatientID = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Txt_OutPatientID = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Lbl_Words = New System.Windows.Forms.Label
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Utl = New System.Windows.Forms.Button
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Report = New System.Windows.Forms.Button
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Cancel = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label
        Me.Txt_TranID = New System.Windows.Forms.TextBox
        Me.Txt_Amount = New System.Windows.Forms.TextBox
        Me.Cmb_Payment_Mode = New System.Windows.Forms.ComboBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Txt_Narration = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.Dgv_Patient_Dep = New System.Windows.Forms.DataGridView
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.Txt_PMRID = New System.Windows.Forms.TextBox
        Me.Btn_PMRFind = New System.Windows.Forms.Button
        Me.Txt_DepositBalance = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Txt_Tran_BatchID = New System.Windows.Forms.TextBox
        Me.Btn_Utility = New REAL_CLINIC.Imageviewer
        Me.Patient_Info2 = New REAL_CLINIC.Patient_Info
        Me.Dtp_Trandate = New System.Windows.Forms.DateTimePicker
        Me.Pnl_Header.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.Pnl_Tran_mode.SuspendLayout()
        CType(Me.Dgv_Patient_Dep, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Menu_Bkg
        Me.Pnl_Header.Controls.Add(Me.Label1)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(648, 24)
        Me.Pnl_Header.TabIndex = 10000
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(7, 1)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(292, 19)
        Me.Label1.TabIndex = 100000
        Me.Label1.Text = "P a t i e n t   D e p o s i t   R e g i s t e r"
        '
        'Txt_PatientID
        '
        Me.Txt_PatientID.BackColor = System.Drawing.Color.White
        Me.Txt_PatientID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_PatientID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PatientID.Location = New System.Drawing.Point(219, 124)
        Me.Txt_PatientID.MaxLength = 10
        Me.Txt_PatientID.Name = "Txt_PatientID"
        Me.Txt_PatientID.Size = New System.Drawing.Size(175, 21)
        Me.Txt_PatientID.TabIndex = 4
        Me.Txt_PatientID.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(216, 68)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(64, 13)
        Me.Label5.TabIndex = 211
        Me.Label5.Text = "Patient ID"
        '
        'Txt_OutPatientID
        '
        Me.Txt_OutPatientID.BackColor = System.Drawing.Color.White
        Me.Txt_OutPatientID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_OutPatientID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_OutPatientID.Location = New System.Drawing.Point(3, 84)
        Me.Txt_OutPatientID.MaxLength = 10
        Me.Txt_OutPatientID.Name = "Txt_OutPatientID"
        Me.Txt_OutPatientID.Size = New System.Drawing.Size(176, 21)
        Me.Txt_OutPatientID.TabIndex = 20000
        Me.Txt_OutPatientID.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(5, 68)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 13)
        Me.Label2.TabIndex = 210
        Me.Label2.Text = "OP ID"
        '
        'Lbl_Words
        '
        Me.Lbl_Words.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Words.ForeColor = System.Drawing.Color.Maroon
        Me.Lbl_Words.Location = New System.Drawing.Point(0, 247)
        Me.Lbl_Words.Name = "Lbl_Words"
        Me.Lbl_Words.Size = New System.Drawing.Size(350, 21)
        Me.Lbl_Words.TabIndex = 217
        Me.Lbl_Words.Text = "Words"
        Me.Lbl_Words.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Utl)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Report)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Cancel)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(156, 430)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(342, 35)
        Me.Pnl_Common_Btn.TabIndex = 8
        '
        'Btn_Utl
        '
        Me.Btn_Utl.BackgroundImage = CType(resources.GetObject("Btn_Utl.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Utl.CausesValidation = False
        Me.Btn_Utl.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Utl.Location = New System.Drawing.Point(224, 3)
        Me.Btn_Utl.Name = "Btn_Utl"
        Me.Btn_Utl.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Utl.TabIndex = 7
        Me.Btn_Utl.Text = "&Utility"
        Me.Btn_Utl.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(280, 3)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 6
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Report
        '
        Me.Btn_Report.BackgroundImage = CType(resources.GetObject("Btn_Report.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Report.CausesValidation = False
        Me.Btn_Report.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Report.Location = New System.Drawing.Point(169, 3)
        Me.Btn_Report.Name = "Btn_Report"
        Me.Btn_Report.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Report.TabIndex = 5
        Me.Btn_Report.Text = "S&how"
        Me.Btn_Report.UseVisualStyleBackColor = True
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(114, 3)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear.TabIndex = 3
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Cancel
        '
        Me.Btn_Cancel.BackgroundImage = CType(resources.GetObject("Btn_Cancel.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Cancel.Location = New System.Drawing.Point(59, 3)
        Me.Btn_Cancel.Name = "Btn_Cancel"
        Me.Btn_Cancel.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Cancel.TabIndex = 2
        Me.Btn_Cancel.Text = "C&ancel"
        Me.Btn_Cancel.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = CType(resources.GetObject("Btn_Save.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(4, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save.TabIndex = 1
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(349, 37)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(74, 22)
        Me.Pnl_Tran_mode.TabIndex = 10001
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(3, 1)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(67, 19)
        Me.Lbl_Tran_Mode.TabIndex = 122
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Txt_TranID
        '
        Me.Txt_TranID.BackColor = System.Drawing.Color.White
        Me.Txt_TranID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_TranID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_TranID.Location = New System.Drawing.Point(209, 86)
        Me.Txt_TranID.MaxLength = 10
        Me.Txt_TranID.Name = "Txt_TranID"
        Me.Txt_TranID.Size = New System.Drawing.Size(173, 21)
        Me.Txt_TranID.TabIndex = 0
        Me.Txt_TranID.TabStop = False
        '
        'Txt_Amount
        '
        Me.Txt_Amount.BackColor = System.Drawing.Color.White
        Me.Txt_Amount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Amount.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Amount.Location = New System.Drawing.Point(64, 200)
        Me.Txt_Amount.MaxLength = 10
        Me.Txt_Amount.Name = "Txt_Amount"
        Me.Txt_Amount.Size = New System.Drawing.Size(117, 21)
        Me.Txt_Amount.TabIndex = 6
        '
        'Cmb_Payment_Mode
        '
        Me.Cmb_Payment_Mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.Cmb_Payment_Mode.CausesValidation = False
        Me.Cmb_Payment_Mode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Payment_Mode.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_Payment_Mode.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Payment_Mode.FormattingEnabled = True
        Me.Cmb_Payment_Mode.ItemHeight = 13
        Me.Cmb_Payment_Mode.Location = New System.Drawing.Point(279, 200)
        Me.Cmb_Payment_Mode.Name = "Cmb_Payment_Mode"
        Me.Cmb_Payment_Mode.Size = New System.Drawing.Size(144, 21)
        Me.Cmb_Payment_Mode.TabIndex = 7
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(181, 203)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(92, 13)
        Me.Label3.TabIndex = 10010
        Me.Label3.Text = "Payment Mode"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(0, 202)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(52, 13)
        Me.Label4.TabIndex = 10011
        Me.Label4.Text = "Amount"
        '
        'Txt_Narration
        '
        Me.Txt_Narration.BackColor = System.Drawing.Color.White
        Me.Txt_Narration.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Narration.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Narration.Location = New System.Drawing.Point(64, 227)
        Me.Txt_Narration.MaxLength = 200
        Me.Txt_Narration.Name = "Txt_Narration"
        Me.Txt_Narration.Size = New System.Drawing.Size(359, 21)
        Me.Txt_Narration.TabIndex = 7
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(0, 229)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(58, 13)
        Me.Label8.TabIndex = 30005
        Me.Label8.Text = "Remarks"
        '
        'Dgv_Patient_Dep
        '
        Me.Dgv_Patient_Dep.AllowUserToAddRows = False
        Me.Dgv_Patient_Dep.AllowUserToDeleteRows = False
        Me.Dgv_Patient_Dep.AllowUserToResizeColumns = False
        Me.Dgv_Patient_Dep.AllowUserToResizeRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(248, Byte), Integer))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.DarkBlue
        Me.Dgv_Patient_Dep.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.Dgv_Patient_Dep.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(236, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Dgv_Patient_Dep.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(75, Byte), Integer), CType(CType(116, Byte), Integer), CType(CType(165, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgv_Patient_Dep.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.Dgv_Patient_Dep.ColumnHeadersHeight = 20
        Me.Dgv_Patient_Dep.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.Dgv_Patient_Dep.Location = New System.Drawing.Point(3, 277)
        Me.Dgv_Patient_Dep.Name = "Dgv_Patient_Dep"
        Me.Dgv_Patient_Dep.ReadOnly = True
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(179, Byte), Integer))
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgv_Patient_Dep.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.Dgv_Patient_Dep.RowHeadersVisible = False
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(CType(CType(219, Byte), Integer), CType(CType(227, Byte), Integer), CType(CType(249, Byte), Integer))
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.Color.DarkBlue
        Me.Dgv_Patient_Dep.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.Dgv_Patient_Dep.Size = New System.Drawing.Size(635, 140)
        Me.Dgv_Patient_Dep.TabIndex = 30007
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(0, 39)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(0, 13)
        Me.Label6.TabIndex = 30008
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label17.Location = New System.Drawing.Point(0, 39)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(45, 14)
        Me.Label17.TabIndex = 30009
        Me.Label17.Text = "PMR-ID"
        '
        'Txt_PMRID
        '
        Me.Txt_PMRID.BackColor = System.Drawing.Color.White
        Me.Txt_PMRID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_PMRID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PMRID.Location = New System.Drawing.Point(64, 37)
        Me.Txt_PMRID.MaxLength = 15
        Me.Txt_PMRID.Name = "Txt_PMRID"
        Me.Txt_PMRID.Size = New System.Drawing.Size(152, 21)
        Me.Txt_PMRID.TabIndex = 0
        Me.Txt_PMRID.Tag = ""
        '
        'Btn_PMRFind
        '
        Me.Btn_PMRFind.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_PMRFind.BackgroundImage = CType(resources.GetObject("Btn_PMRFind.BackgroundImage"), System.Drawing.Image)
        Me.Btn_PMRFind.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_PMRFind.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_PMRFind.ForeColor = System.Drawing.Color.White
        Me.Btn_PMRFind.Location = New System.Drawing.Point(217, 37)
        Me.Btn_PMRFind.Name = "Btn_PMRFind"
        Me.Btn_PMRFind.Size = New System.Drawing.Size(28, 21)
        Me.Btn_PMRFind.TabIndex = 1
        Me.Btn_PMRFind.TabStop = False
        Me.Btn_PMRFind.Text = "F2"
        Me.Btn_PMRFind.UseVisualStyleBackColor = False
        '
        'Txt_DepositBalance
        '
        Me.Txt_DepositBalance.BackColor = System.Drawing.Color.White
        Me.Txt_DepositBalance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_DepositBalance.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_DepositBalance.Location = New System.Drawing.Point(456, 247)
        Me.Txt_DepositBalance.MaxLength = 10
        Me.Txt_DepositBalance.Name = "Txt_DepositBalance"
        Me.Txt_DepositBalance.ReadOnly = True
        Me.Txt_DepositBalance.Size = New System.Drawing.Size(180, 24)
        Me.Txt_DepositBalance.TabIndex = 100008
        Me.Txt_DepositBalance.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(399, 255)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(51, 13)
        Me.Label7.TabIndex = 100009
        Me.Label7.Text = "Balance"
        '
        'Txt_Tran_BatchID
        '
        Me.Txt_Tran_BatchID.BackColor = System.Drawing.Color.White
        Me.Txt_Tran_BatchID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Tran_BatchID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Tran_BatchID.Location = New System.Drawing.Point(253, 84)
        Me.Txt_Tran_BatchID.MaxLength = 15
        Me.Txt_Tran_BatchID.Name = "Txt_Tran_BatchID"
        Me.Txt_Tran_BatchID.Size = New System.Drawing.Size(152, 21)
        Me.Txt_Tran_BatchID.TabIndex = 100010
        Me.Txt_Tran_BatchID.Tag = ""
        Me.Txt_Tran_BatchID.Visible = False
        '
        'Btn_Utility
        '
        Me.Btn_Utility.CUST_ID = ""
        Me.Btn_Utility.CUST_TYPE = HMS_Common.Common_Cls.Customer_Type.Employee
        Me.Btn_Utility.Location = New System.Drawing.Point(456, 30)
        Me.Btn_Utility.Name = "Btn_Utility"
        Me.Btn_Utility.Scan_Enabled = True
        Me.Btn_Utility.Size = New System.Drawing.Size(182, 212)
        Me.Btn_Utility.TabIndex = 10007
        '
        'Patient_Info2
        '
        Me.Patient_Info2.BackColor = System.Drawing.Color.AliceBlue
        Me.Patient_Info2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Patient_Info2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Patient_Info2.ForeColor = System.Drawing.Color.Navy
        Me.Patient_Info2.Location = New System.Drawing.Point(3, 61)
        Me.Patient_Info2.Name = "Patient_Info2"
        Me.Patient_Info2.Padding = New System.Windows.Forms.Padding(2)
        Me.Patient_Info2.Size = New System.Drawing.Size(420, 121)
        Me.Patient_Info2.TabIndex = 212
        '
        'Dtp_Trandate
        '
        Me.Dtp_Trandate.CustomFormat = "dd/MM/yyyy"
        Me.Dtp_Trandate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_Trandate.Location = New System.Drawing.Point(251, 37)
        Me.Dtp_Trandate.Name = "Dtp_Trandate"
        Me.Dtp_Trandate.Size = New System.Drawing.Size(92, 21)
        Me.Dtp_Trandate.TabIndex = 100011
        '
        'Patient_Deposit_Reg_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(648, 477)
        Me.Controls.Add(Me.Dtp_Trandate)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Txt_DepositBalance)
        Me.Controls.Add(Me.Btn_PMRFind)
        Me.Controls.Add(Me.Txt_PMRID)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Dgv_Patient_Dep)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Txt_Narration)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Cmb_Payment_Mode)
        Me.Controls.Add(Me.Txt_Amount)
        Me.Controls.Add(Me.Btn_Utility)
        Me.Controls.Add(Me.Pnl_Tran_mode)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.Lbl_Words)
        Me.Controls.Add(Me.Patient_Info2)
        Me.Controls.Add(Me.Txt_PatientID)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Txt_OutPatientID)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Controls.Add(Me.Txt_TranID)
        Me.Controls.Add(Me.Txt_Tran_BatchID)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Patient_Deposit_Reg_Frm"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.Pnl_Tran_mode.ResumeLayout(False)
        CType(Me.Dgv_Patient_Dep, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Patient_Info2 As REAL_CLINIC.Patient_Info
    Friend WithEvents Txt_PatientID As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Txt_OutPatientID As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Words As System.Windows.Forms.Label
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Cancel As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Btn_Report As System.Windows.Forms.Button
    Friend WithEvents Txt_TranID As System.Windows.Forms.TextBox
    Friend WithEvents Btn_Utility As REAL_CLINIC.Imageviewer
    Friend WithEvents Txt_Amount As System.Windows.Forms.TextBox
    Friend WithEvents Cmb_Payment_Mode As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Txt_Narration As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Dgv_Patient_Dep As System.Windows.Forms.DataGridView
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Txt_PMRID As System.Windows.Forms.TextBox
    Friend WithEvents Btn_PMRFind As System.Windows.Forms.Button
    Friend WithEvents Txt_DepositBalance As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Btn_Utl As System.Windows.Forms.Button
    Friend WithEvents Txt_Tran_BatchID As System.Windows.Forms.TextBox
    Friend WithEvents Dtp_Trandate As System.Windows.Forms.DateTimePicker
End Class
