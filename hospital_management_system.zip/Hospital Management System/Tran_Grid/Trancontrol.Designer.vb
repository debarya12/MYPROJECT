﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Trancontrol
    Inherits System.Windows.Forms.UserControl

    'UserControl1 overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Pnl_Header = New System.Windows.Forms.Panel()
        Me.Btn_Clear = New System.Windows.Forms.Button()
        Me.Pnl_paymode = New System.Windows.Forms.Panel()
        Me.Cmb_Paymode = New System.Windows.Forms.ComboBox()
        Me.Lbl_Pay = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Tran_Grid = New Tran_Controls.Tran_Grid(Me.components)
        Me.Slno = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Particulars = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Amount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Acc_Code = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Exp_Subtype = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Def_Trantype = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Editable = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Charge_Calctype = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Percentage_Of = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Percentage = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Lbl_TotalAmount = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Pnl_Header.SuspendLayout()
        Me.Pnl_paymode.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.Tran_Grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.Pnl_Header.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Header.Controls.Add(Me.Pnl_paymode)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(1, 1)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(409, 24)
        Me.Pnl_Header.TabIndex = 2
        '
        'Btn_Clear
        '
        Me.Btn_Clear.Dock = System.Windows.Forms.DockStyle.Right
        Me.Btn_Clear.FlatAppearance.BorderSize = 0
        Me.Btn_Clear.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Clear.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Clear.ForeColor = System.Drawing.Color.White
        Me.Btn_Clear.Location = New System.Drawing.Point(333, 0)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(76, 24)
        Me.Btn_Clear.TabIndex = 5
        Me.Btn_Clear.TabStop = False
        Me.Btn_Clear.Text = "&Clear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Pnl_paymode
        '
        Me.Pnl_paymode.Controls.Add(Me.Cmb_Paymode)
        Me.Pnl_paymode.Controls.Add(Me.Lbl_Pay)
        Me.Pnl_paymode.Dock = System.Windows.Forms.DockStyle.Left
        Me.Pnl_paymode.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_paymode.Name = "Pnl_paymode"
        Me.Pnl_paymode.Padding = New System.Windows.Forms.Padding(1)
        Me.Pnl_paymode.Size = New System.Drawing.Size(224, 24)
        Me.Pnl_paymode.TabIndex = 4
        '
        'Cmb_Paymode
        '
        Me.Cmb_Paymode.Dock = System.Windows.Forms.DockStyle.Right
        Me.Cmb_Paymode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Paymode.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_Paymode.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Paymode.FormattingEnabled = True
        Me.Cmb_Paymode.Location = New System.Drawing.Point(94, 1)
        Me.Cmb_Paymode.Name = "Cmb_Paymode"
        Me.Cmb_Paymode.Size = New System.Drawing.Size(129, 21)
        Me.Cmb_Paymode.TabIndex = 1
        '
        'Lbl_Pay
        '
        Me.Lbl_Pay.AutoSize = True
        Me.Lbl_Pay.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Pay.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Pay.ForeColor = System.Drawing.Color.White
        Me.Lbl_Pay.Location = New System.Drawing.Point(2, 5)
        Me.Lbl_Pay.Name = "Lbl_Pay"
        Me.Lbl_Pay.Size = New System.Drawing.Size(92, 13)
        Me.Lbl_Pay.TabIndex = 28
        Me.Lbl_Pay.Text = "Payment Mode"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.Controls.Add(Me.Tran_Grid)
        Me.Panel1.Controls.Add(Me.Panel3)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(1, 25)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(409, 177)
        Me.Panel1.TabIndex = 21
        '
        'Tran_Grid
        '
        Me.Tran_Grid.AllowUserToAddRows = False
        Me.Tran_Grid.AllowUserToDeleteRows = False
        Me.Tran_Grid.AllowUserToResizeRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(234, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(249, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tran_Grid.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.Tran_Grid.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(249, Byte), Integer), CType(CType(254, Byte), Integer))
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(51, Byte), Integer), CType(CType(97, Byte), Integer), CType(CType(157, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Tran_Grid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.Tran_Grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Tran_Grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Slno, Me.Particulars, Me.Amount, Me.Acc_Code, Me.Exp_Subtype, Me.Def_Trantype, Me.Editable, Me.Charge_Calctype, Me.Percentage_Of, Me.Percentage})
        Me.Tran_Grid.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Tran_Grid.Location = New System.Drawing.Point(0, 0)
        Me.Tran_Grid.Name = "Tran_Grid"
        Me.Tran_Grid.RowHeadersVisible = False
        Me.Tran_Grid.RowTemplate.DefaultCellStyle.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tran_Grid.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Tran_Grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.Tran_Grid.Size = New System.Drawing.Size(409, 161)
        Me.Tran_Grid.TabIndex = 2
        '
        'Slno
        '
        Me.Slno.Frozen = True
        Me.Slno.HeaderText = "#"
        Me.Slno.Name = "Slno"
        Me.Slno.ReadOnly = True
        Me.Slno.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Slno.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Slno.Width = 25
        '
        'Particulars
        '
        Me.Particulars.Frozen = True
        Me.Particulars.HeaderText = "P a r t i c u l a r s"
        Me.Particulars.MinimumWidth = 100
        Me.Particulars.Name = "Particulars"
        Me.Particulars.ReadOnly = True
        Me.Particulars.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Particulars.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Particulars.Width = 230
        '
        'Amount
        '
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle3.Format = "N2"
        DataGridViewCellStyle3.NullValue = Nothing
        DataGridViewCellStyle3.Padding = New System.Windows.Forms.Padding(2)
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Amount.DefaultCellStyle = DataGridViewCellStyle3
        Me.Amount.Frozen = True
        Me.Amount.HeaderText = "A m o u n t"
        Me.Amount.MaxInputLength = 15
        Me.Amount.MinimumWidth = 75
        Me.Amount.Name = "Amount"
        Me.Amount.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Amount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Amount.Width = 150
        '
        'Acc_Code
        '
        Me.Acc_Code.Frozen = True
        Me.Acc_Code.HeaderText = "Acc_Code"
        Me.Acc_Code.Name = "Acc_Code"
        Me.Acc_Code.Visible = False
        '
        'Exp_Subtype
        '
        Me.Exp_Subtype.Frozen = True
        Me.Exp_Subtype.HeaderText = "Exp_Subtype"
        Me.Exp_Subtype.Name = "Exp_Subtype"
        Me.Exp_Subtype.Visible = False
        '
        'Def_Trantype
        '
        Me.Def_Trantype.Frozen = True
        Me.Def_Trantype.HeaderText = "Def_Trantype"
        Me.Def_Trantype.Name = "Def_Trantype"
        Me.Def_Trantype.Visible = False
        '
        'Editable
        '
        Me.Editable.Frozen = True
        Me.Editable.HeaderText = "Editable"
        Me.Editable.Name = "Editable"
        Me.Editable.ReadOnly = True
        Me.Editable.Visible = False
        '
        'Charge_Calctype
        '
        Me.Charge_Calctype.HeaderText = "Charge_Calctype"
        Me.Charge_Calctype.Name = "Charge_Calctype"
        Me.Charge_Calctype.Visible = False
        '
        'Percentage_Of
        '
        Me.Percentage_Of.HeaderText = "Percentage_Of"
        Me.Percentage_Of.Name = "Percentage_Of"
        Me.Percentage_Of.Visible = False
        '
        'Percentage
        '
        Me.Percentage.HeaderText = "Percentage"
        Me.Percentage.Name = "Percentage"
        Me.Percentage.Visible = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.Panel3.Controls.Add(Me.Lbl_TotalAmount)
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel3.Location = New System.Drawing.Point(0, 161)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Padding = New System.Windows.Forms.Padding(1)
        Me.Panel3.Size = New System.Drawing.Size(409, 16)
        Me.Panel3.TabIndex = 2
        '
        'Lbl_TotalAmount
        '
        Me.Lbl_TotalAmount.AutoSize = True
        Me.Lbl_TotalAmount.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_TotalAmount.Dock = System.Windows.Forms.DockStyle.Right
        Me.Lbl_TotalAmount.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_TotalAmount.ForeColor = System.Drawing.Color.White
        Me.Lbl_TotalAmount.Location = New System.Drawing.Point(408, 1)
        Me.Lbl_TotalAmount.Name = "Lbl_TotalAmount"
        Me.Lbl_TotalAmount.Size = New System.Drawing.Size(0, 14)
        Me.Lbl_TotalAmount.TabIndex = 29
        Me.Lbl_TotalAmount.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(205, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(54, 14)
        Me.Label2.TabIndex = 28
        Me.Label2.Text = "TOTAL :"
        '
        'Trancontrol
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(123, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "Trancontrol"
        Me.Padding = New System.Windows.Forms.Padding(1)
        Me.Size = New System.Drawing.Size(411, 203)
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_paymode.ResumeLayout(False)
        Me.Pnl_paymode.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        CType(Me.Tran_Grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Pnl_paymode As System.Windows.Forms.Panel

    Friend WithEvents Lbl_Pay As System.Windows.Forms.Label

    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label


    Public WithEvents Cmb_Paymode As System.Windows.Forms.ComboBox
    Public WithEvents Tran_Grid As Tran_Controls.Tran_Grid
    Public WithEvents Lbl_TotalAmount As System.Windows.Forms.Label
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Slno As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Particulars As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Amount As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Acc_Code As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Exp_Subtype As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Def_Trantype As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Editable As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Charge_Calctype As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Percentage_Of As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Percentage As System.Windows.Forms.DataGridViewTextBoxColumn

End Class
