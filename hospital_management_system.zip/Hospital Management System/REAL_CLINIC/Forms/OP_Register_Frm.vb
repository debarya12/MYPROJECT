﻿

Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls
Public Class OP_Register_Frm


#Region " D e c l a r a t i o n s "

    Private hms_helper As HMS_Helper = Nothing
    Private Tran_BL As TranMaster_BL_Cls
    Private OP_BL As OutPatient_BL_Cls
    Private Apoint_Bl As Appointment_BL_Cls
    Private Bk_Tran_Bl As BankAccount_BL_Cls

    Dim frm_Heading As String = String.Empty

    Dim Assignvalue_Dtbl As DataTable = Nothing

    Dim Service_Dtbl As DataTable = Nothing
    Dim doc_Dtbl As DataTable = Nothing
    Dim Visitortype_Dtbl As DataTable = Nothing
    Dim Bookingmode_Dtbl As DataTable = Nothing
    Dim Nationality_Dtbl As DataTable = Nothing
    Dim Visittype_Dtbl As DataTable = Nothing

    Private Ctrl_Point As Point
    Private mReq_Ctrl As Object = Nothing

#End Region

#Region " E n u m s "

    Public Enum enm_Visitor_Type
        New_Visitor
        Pre_Visitor
        Employee
    End Enum

    Public Enum enm_Visit_Type
        New_Visit
        Followup_Visit
    End Enum


#End Region

#Region " P r o p e r t i e s "

    'Transaction Mode checking Property
    Private mTr_Mode As Tran_Mode
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_OPID.BackColor = Color.White
                    Me.Txt_OPID.ReadOnly = False
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_OPID.BackColor = Color.Silver
                    Me.Txt_OPID.ReadOnly = True
            End Select
        End Set
    End Property

    'Appointment Service Property
    Private _OP_Service_ID As Integer = 0
    Public Property OP_Service_ID() As Integer
        Get
            Return _OP_Service_ID
        End Get
        Set(ByVal value As Integer)
            _OP_Service_ID = value

            If _OP_Service_ID = 0 Then Exit Property

            Call Populate_Doctorlist(_OP_Service_ID)

        End Set
    End Property

    Private _Seldoctor_ID As Integer = 0
    Public Property Seldoctor_ID() As Integer
        Get
            Return _Seldoctor_ID
        End Get
        Set(ByVal value As Integer)
            _Seldoctor_ID = value
            If value = 0 Then
                Pnl_1.Enabled = False
                Pnl_2.Enabled = False
                Pnl_3.Enabled = False
                Return
            Else
                Pnl_1.Enabled = True
                Pnl_2.Enabled = True
                Pnl_3.Enabled = True
            End If

            Call Get_Doctordetails(value)
            Call Fill_Trancontrol(value)
        End Set
    End Property

    Private _App_Doctor_name As String
    Public Property App_Doctor_Name() As String
        Get
            Return _App_Doctor_name
        End Get
        Set(ByVal value As String)
            _App_Doctor_name = value
            Lbl_Heading.Text = frm_Heading
            If Not value = String.Empty Then Lbl_Heading.Text = frm_Heading + "  of  " + value
        End Set
    End Property

    Private _Visitortype As enm_Visitor_Type
    Public Property Visitortype() As enm_Visitor_Type
        Get
            Return _Visitortype
        End Get
        Set(ByVal value As enm_Visitor_Type)
            _Visitortype = value
            If value = enm_Visitor_Type.New_Visitor Then
                Txt_Visitortype.Text = "NEW VISITOR"
            ElseIf value = enm_Visitor_Type.Pre_Visitor Then
                Txt_Visitortype.Text = "PRE VISITOR"
            Else
                Txt_Visitortype.Text = "STAFF"
            End If
        End Set
    End Property

    Private _Visit_Type As enm_Visit_Type
    Public Property Visit_Type() As enm_Visit_Type
        Get
            Return _Visit_Type
        End Get
        Set(ByVal value As enm_Visit_Type)
            _Visit_Type = value
            If _Visit_Type = enm_Visit_Type.Followup_Visit Then
                Txt_OPID.Enabled = False
                Btn_Find.Enabled = False
                Txt_PMRID.Enabled = True
                Btn_PMRIDF2.Enabled = True
                Btn_Followupreg.Visible = True
            Else
                Txt_OPID.Enabled = True
                Btn_Find.Enabled = True
                Txt_PMRID.Enabled = False
                Btn_PMRIDF2.Enabled = False
                Btn_Followupreg.Visible = False
            End If
        End Set
    End Property

    Private _RegExpID As Integer = 1
    Private Property RegExpID() As Integer
        Get
            Return _RegExpID
        End Get
        Set(ByVal value As Integer)
            _RegExpID = value
        End Set
    End Property

    Private _Tran_BatchID As String = String.Empty
    Private Property Tran_BatchID() As String
        Get
            Return _Tran_BatchID
        End Get
        Set(ByVal value As String)
            _Tran_BatchID = value
        End Set
    End Property

    Private _Tran_RefNo As String = "OP"
    Private Property Tran_RefNo() As String
        Get
            Return _Tran_RefNo
        End Get
        Set(ByVal value As String)
            _Tran_RefNo = value
        End Set
    End Property

    Private _BK_TranID As String = "0"
    Private Property BK_TranID() As String
        Get
            Return _BK_TranID
        End Get
        Set(ByVal value As String)
            _BK_TranID = value
        End Set
    End Property

    Private _IsValid_OP As Boolean = False
    Private Property IsValid_OP() As Boolean
        Get
            Return _IsValid_OP
        End Get
        Set(ByVal value As Boolean)
            _IsValid_OP = value
        End Set
    End Property

#End Region

#Region " M e t h o d s "

    Private Function Populate_Doctorlist(ByVal ServiceID As Integer) As Boolean
        Try

            Dim btnSomething As ToolStripButton
            Dim doc_Dtbl As DataTable = Nothing

            TlStrp_Doctors.Items.Clear()

            If hms_helper.Get_Doctorswithservices(doc_Dtbl, ServiceID, Tran_Date, Branch_Code) Then

                For i = 0 To doc_Dtbl.Rows.Count - 1
                    btnSomething = New ToolStripButton
                    With btnSomething
                        .Text = doc_Dtbl.Rows(i).Item("Name").ToString
                        .Tag = doc_Dtbl.Rows(i).Item("DoctorID").ToString
                        .Image = My.Resources.Health_care_shield_32
                        .ImageAlign = ContentAlignment.TopCenter
                        .ImageScaling = ToolStripItemImageScaling.None
                        .ForeColor = Color.Maroon
                        .DisplayStyle = ToolStripItemDisplayStyle.ImageAndText
                        .TextImageRelation = TextImageRelation.ImageAboveText
                    End With
                    TlStrp_Doctors.Items.Add(btnSomething)
                Next

            End If
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Clear_Apointmentinfo()
        Try
            With Me
                .Txt_ApointID.Tag = ""
                .Lbl_MesageTokenno.Text = "*"
                .Lbl_Mesageaproxtime.Text = "*"
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Function Locate_ApointDetails(ByVal ApointID As Long) As Boolean
        Try
            Dim Dtbl As DataTable = Nothing
            Apoint_Bl = New Appointment_BL_Cls

            Call Clear_Apointmentinfo()

            If Not Apoint_Bl.Get_AppointMent_Details(Dtbl, ApointID) Then Return False

            With Dtbl


                If CDate(.Rows(0).Item("Apoint_Date").ToString()) <> Tran_Date Then
                    MessageBox.Show("Apointment is not taken on this date,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Return False
                End If

                Me.Txt_ApointID.Text = ApointID
                Me.Txt_ApointID.Tag = ApointID
                '=====================================================================================================

                Lbl_MesageTokenno.Text = .Rows(0).Item("Apoint_Tokenno").ToString
                Lbl_Mesageaproxtime.Text = CDate(.Rows(0).Item("Apoint_AproxStime").ToString).ToString("hh:mm tt")

                '=====================================================================================================

                Me.Txt_Visitortype.Text = .Rows(0).Item("Visitor_TypeID").ToString

                '---------------- Hard Coded    -----------------
                Select Case Me.Txt_Visitortype.Text
                    Case 76

                        Me.Visitortype = enm_Visitor_Type.Pre_Visitor

                    Case 71

                        Me.Visitortype = enm_Visitor_Type.Employee

                    Case Else

                        Me.Visitortype = enm_Visitor_Type.New_Visitor

                End Select
                '---------------- Hard Coded    -----------------


                Me.Cmb_Status.SelectedIndex = 0


                Txt_PatientID.Text = .Rows(0).Item("Visitor_ID").ToString
                Txt_PatientID.Tag = Txt_PatientID.Text

                If Txt_PMRID.Text.Trim = String.Empty Then

                    If Not Apoint_Bl.Get_ApointmentVisitordetails(Dtbl, ApointID, Branch_Code) Then Return False

                    With Dtbl
                        Txt_Visitor_SSNO.Text = .Rows(0).Item("V_SSNo").ToString
                        Txt_Visitor_Name.Text = .Rows(0).Item("V_Name").ToString
                        Txt_Visitor_Addr.Text = .Rows(0).Item("V_Addr").ToString
                        Txt_Visitor_Familyname.Text = .Rows(0).Item("V_Familyname").ToString
                        Txt_Visitor_Age.Text = .Rows(0).Item("V_Age").ToString
                        Txt_Visitor_Mobile.Text = .Rows(0).Item("V_Mobile").ToString
                        Txt_Visitor_Phone.Text = .Rows(0).Item("V_Phone").ToString
                        Txt_Gender.Text = IIf(.Rows(0).Item("V_Gender").ToString = "M", "Male", "Female")
                        Txt_Nationality.Text = .Rows(0).Item("V_Country").ToString

                    End With



                    If Not Cmb_Service.SelectedValue = .Rows(0).Item("Service_ID").ToString Then
                        If MessageBox.Show("This Appointment is not Registered for the selected Service" + vbCrLf + "Wan't to Change ", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.No Then
                            Call Clear_Apointmentinfo()
                            Return False
                        End If
                    End If

                    Btn_Save.Enabled = True
                    Cmb_Visittype.SelectedValue = .Rows(0).Item("Visit_TypeID").ToString
                    Cmb_Visittype.Focus()

                End If

            End With
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Clear_Form()
        Try
            Call Clear_Apointmentinfo()
            Call Clear_Patientdetails()

            With Me
                .Pnl_Doc.Enabled = True
                .Pnl_Apoint.Enabled = True
                .Btn_Followupreg.Visible = False
                .Txt_OPID.Text = String.Empty
                .Txt_OPID.Tag = String.Empty
                .Txt_ApointID.Text = String.Empty
                .Txt_ApointID.Tag = String.Empty
                .Txt_Visitortype.Text = String.Empty
                .Txt_Nationality.Text = String.Empty
                .Txt_Gender.Text = String.Empty
                .Txt_PMRID.Text = String.Empty
                .Cmb_BillingMethod.SelectedIndex = 0
                .Cmb_ArrivalMode.SelectedIndex = 0
                .Cmb_PatientType.SelectedIndex = 0
                .Cmb_Status.SelectedIndex = 0
                .Txt_AmbulatoryStatus.Text = String.Empty
                .Tr_Mode = Tran_Mode.New_Mode
                .Tran_BatchID = String.Empty
                .Tran_RefNo = String.Empty
                .Txt_Remarks.Text = String.Empty
                Btn_CancelOP.Enabled = False
                Btn_Print.Enabled = False
                Btn_Save.Enabled = False
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Function Fill_Trancontrol(ByVal Doc_ID As Integer) As Boolean
        Try
            Dim dtbl As DataTable = Nothing
            Dim DtblDr As DataTable = Nothing

            Dim Gridsorce_Dtbl As New DataTable


            Dim Drow, Amt_Drow As DataRow
            Dim Paymentmodesource_Dtbl As DataTable = Nothing

            With Gridsorce_Dtbl
                .Columns.Add("Particulars")
                .Columns.Add("Acc_Code")
                .Columns.Add("Exp_Subtype")
                .Columns.Add("Def_Trantype")
                .Columns.Add("Editable")
                .Columns.Add("Charge_Calctype")
                .Columns.Add("Percentage_Of")
                .Columns.Add("Percentage")

            End With
            Assignvalue_Dtbl = New DataTable
            With Assignvalue_Dtbl
                .Columns.Add("Exp_Subtype")
                .Columns.Add("Amount")
            End With


            If Not hms_helper.Get_OP_RegistrationFee(dtbl, Doc_ID, Tran_Date, Branch_Code) Then
                MessageBox.Show("Registration Fee settings not done,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If


            For i = 0 To dtbl.Rows.Count - 1
                '------------------------------------------------------------------------
                Drow = Gridsorce_Dtbl.NewRow()
                Drow("Particulars") = dtbl.Rows(i).Item("Particulars").ToString
                Drow("Acc_Code") = dtbl.Rows(i).Item("Exp_Acc_Code").ToString
                Drow("Exp_Subtype") = dtbl.Rows(i).Item("Exp_Subtype").ToString

                Drow("Def_Trantype") = "C"
                Drow("Editable") = "Y"
                Drow("Charge_Calctype") = dtbl.Rows(i).Item("Charge_Calctype").ToString
                Drow("Percentage_Of") = dtbl.Rows(i).Item("Percentage_Of").ToString
                Drow("Percentage") = dtbl.Rows(i).Item("Exp_Amount").ToString
                'MsgBox(dtbl.Rows(i).Item("Exp_Amount").ToString)

                Gridsorce_Dtbl.Rows.Add(Drow)
                '------------------------------------------------------------------------

                Amt_Drow = Assignvalue_Dtbl.NewRow
                Amt_Drow("Exp_Subtype") = dtbl.Rows(i).Item("Exp_Subtype").ToString
                Amt_Drow("Amount") = dtbl.Rows(i).Item("Exp_Amount").ToString
                Assignvalue_Dtbl.Rows.Add(Amt_Drow)

                '------------------------------------------------------------------------

            Next

            If hms_helper.Get_Gendata(Paymentmodesource_Dtbl, Gendatatype.Payment_Mode) Then
                If Trancontrol1.Set_Tranenvironment(Gridsorce_Dtbl, Paymentmodesource_Dtbl) Then
                    Trancontrol1.Assign_Values(Assignvalue_Dtbl, Gendatatype.Payment_Mode)
                    Trancontrol1.Amount_Editable = True
                    If Trancontrol1.Cmb_Paymode.Items.Count > 0 Then Trancontrol1.Cmb_Paymode.SelectedIndex = 0
                    End If
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function

    Private Function Setting_AmountDtbl(ByVal S_Dtbl As DataTable, ByRef Res_Dtbl As DataTable) As Boolean
        Try
            Dim Amt_Drow As DataRow = Nothing
            Dim Value_Dtbl As New DataTable

            With Value_Dtbl
                .Columns.Add("Exp_Subtype")
                .Columns.Add("Amount")
            End With

            For i = 0 To S_Dtbl.Rows.Count - 1
                Amt_Drow = Value_Dtbl.NewRow
                Amt_Drow("Exp_Subtype") = S_Dtbl.Rows(i).Item("Exp_Subtype").ToString
                Amt_Drow("Amount") = S_Dtbl.Rows(i).Item("Tr_Amount").ToString
                Value_Dtbl.Rows.Add(Amt_Drow)
            Next

            Res_Dtbl = Value_Dtbl
            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Get_Doctordetails(ByVal Doc_ID As String) As Boolean
        Try
            Lbl_Doctordetails.Text = String.Empty

            Dim Dtbl As New DataTable
            If hms_helper.Get_Doctordetails(Dtbl, Doc_ID) Then
                Me.App_Doctor_Name = Dtbl.Rows(0).Item("Name").ToString
                Lbl_Doctordetails.Text = Dtbl.Rows(0).Item("Name").ToString.ToUpper
                Lbl_Doctordetails.Text += vbCrLf + Dtbl.Rows(0).Item("Qualification").ToString
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Clear_Patientdetails()
        Try
            With Me
                Txt_Visitortype.Text = String.Empty
                Cmb_Status.SelectedIndex = 0
                Lbl_MesageTokenno.Text = "*"
                Lbl_Mesageaproxtime.Text = "*"

                Txt_PatientID.Text = String.Empty
                Txt_Visitor_SSNO.Text = String.Empty
                Txt_Visitor_Name.Text = String.Empty
                Txt_Visitor_Addr.Text = String.Empty
                Txt_Visitor_Familyname.Text = String.Empty
                Txt_Visitor_Age.Text = String.Empty
                Txt_Visitor_Mobile.Text = String.Empty
                Txt_Visitor_Phone.Text = String.Empty
                Txt_Gender.Text = String.Empty
                Txt_Nationality.Text = String.Empty

            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Function Locate_PMR_Masterinfo(ByVal PMR_ID As String) As Boolean
        Try

            '-----------------   Clear Patient Info   -----------------------------------

            Call Clear_Patientdetails()

            '----------------------------------------------------------------------------

            Dim Dtbl As DataTable = Nothing
            '-----------------  Locate Pateint Medical Record Master info   -------------
            If Not hms_helper.Get_PMR_Masterinfo(Dtbl, PMR_ID, Branch_Code) Then Return False

            With Dtbl
                Txt_PatientID.Text = .Rows(0).Item("Patient ID").ToString
                Txt_Visitor_SSNO.Text = .Rows(0).Item("S.S.No").ToString
                Txt_Visitor_Name.Text = .Rows(0).Item("Patient Name").ToString
                Txt_Visitor_Addr.Text = .Rows(0).Item("Address").ToString
                Txt_Visitor_Familyname.Text = .Rows(0).Item("Family Name").ToString
                Txt_Visitor_Age.Text = .Rows(0).Item("Age").ToString
                Txt_Visitor_Mobile.Text = .Rows(0).Item("Mobile1").ToString
                Txt_Visitor_Phone.Text = .Rows(0).Item("Phone1").ToString
                Txt_Gender.Text = IIf(.Rows(0).Item("Gender").ToString = "M", "Male", "Female")
                Txt_Nationality.Text = .Rows(0).Item("Country").ToString
                Txt_Nationality.Text = hms_helper.Get_Gendatadescription(Val(Txt_Nationality.Text.Trim))
            End With

            Me.Visitortype = enm_Visitor_Type.Pre_Visitor

            If Txt_PMRID.Text.Trim <> String.Empty And Txt_PatientID.Text.Trim <> String.Empty And Txt_OPID.Text.Trim = String.Empty Then
                If Not Locate_PatientApointment(Txt_PatientID.Text.Trim) Then
                    Me.Txt_ApointID.Text = String.Empty
                    Me.Lbl_MesageTokenno.Text = String.Empty
                    Me.Lbl_Mesageaproxtime.Text = String.Empty
                End If
            End If

            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Locate_PatientApointment(ByVal Patient_ID As String) As Boolean
        Try
            Dim Dtbl As DataTable = Nothing
            Apoint_Bl = New Appointment_BL_Cls

            Lbl_MesageTokenno.Text = String.Empty
            Lbl_Mesageaproxtime.Text = String.Empty

            If Not Apoint_Bl.Get_PatientAppointment(Dtbl, Patient_ID, Tran_Date) Then Return False

            With Dtbl

                '=====================================================================================================

                If Not Cmb_Service.SelectedValue = .Rows(0).Item("Service_ID").ToString Then
                    Return False
                End If

                '=====================================================================================================

                Me.Txt_ApointID.Text = .Rows(0).Item("Apoint_ID").ToString
                Me.Txt_ApointID.Tag = .Rows(0).Item("Apoint_ID").ToString

                Lbl_MesageTokenno.Text = .Rows(0).Item("Apoint_Tokenno").ToString
                Lbl_Mesageaproxtime.Text = CDate(.Rows(0).Item("Apoint_AproxStime").ToString).ToString("hh:mm tt")

                '=====================================================================================================

            End With

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Save_OPRegistration(ByVal strBatch_ID As String) As Boolean
        Try


            '-------------------------------------------
            'Validating Fields
            If Not Validate_Fields() Then Exit Function
            '-------------------------------------------

            '===================================================================================================================================================
            '       ASSIGNING VALUES TO BL
            OP_BL = New OutPatient_BL_Cls
            With OP_BL
                .Service_ID = OP_Service_ID
                .Doc_ID = Seldoctor_ID
                .OPD_ID = Val(Txt_OPID.Text.Trim)
                .ACC_ID = Txt_PMRID.Text.Trim
                .Appoint_ID = Val(Txt_ApointID.Text.Trim)

                .Visit_Type = Cmb_Visittype.SelectedValue
                .Arrival_Mode = Cmb_ArrivalMode.SelectedValue
                .Patient_Type = Cmb_PatientType.SelectedValue
                .Patient_Satus = Cmb_Status.SelectedValue
                .Billing_Method = Cmb_BillingMethod.SelectedValue
                .Ambulatory_Status = Txt_AmbulatoryStatus.Text.Trim
                .Tr_Date = Tran_Date
                .Active = "Y"
                .Tran_BatchID = strBatch_ID
            End With

            '===========================================================================
            '       P A T I E N T  R E G I S T R A T I O N

            If Not Save_Patientinfo() Then Return False
            OP_BL.Patient_ID = Txt_PatientID.Text.Trim.Trim

            '===========================================================================
            '       O U T - P A T I E N T  R E G I S T R A T I O N

            Dim Dtbl As DataTable = Nothing
            If Not OP_BL.Save_OutPatient_Register(Dtbl, Me.Tr_Mode, Txt_OPID.Text.Trim) Then
                MessageBox.Show("Error Occured While Saving Outpatient Details,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Return False
            End If

            '===========================================================================
            'Assign New OP ID to Control
            If Dtbl.Rows(0).Item("OPD_ID") <> "0" Then
                Txt_OPID.Text = Dtbl.Rows(0).Item("OPD_ID").ToString
                'Return True
            Else
                MessageBox.Show("Error Occured While Saving Outpatient Details,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Return False
            End If


            '===========================================================================
            '       T R A N S A C T I O N  -  P A R T
            If Not Save_RegFeeTransaction(strBatch_ID) Then
                MessageBox.Show("Error Occured While Saving Outpatient Transaction" + vbCrLf + "Transaction Revert Back", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                GoTo Error_Point
            End If

            '===========================================================================
            'Updating Apointment OP ID
            If Not Update_ApointmentOPID(Txt_OPID.Text.Trim) Then
                GoTo Error_Point
            End If

            '===========================================================================

Exit_point:
            Return True
Error_Point:

            'Reverting Op Registration
            If Not OP_BL.Revert_OPRegistration(Dtbl, Txt_OPID.Text.Trim, Tran_Date, Branch_Code) Then
                MessageBox.Show("Error Occured While Reverting Outpatient Registration,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            'Reverting Patient Registration
            If Me.Visitortype <> enm_Visitor_Type.Pre_Visitor Then
                If Not Del_Patientinfo(Txt_PatientID.Text.Trim) Then
                    MessageBox.Show("Error Occured While Reverting Patient Registration,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
            End If
            Return False

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Save_Patientinfo() As Boolean
        Try
            Dim Dtbl As DataTable = Nothing

            'Register Patient Info if its a New Visitor
            If Me.Visitortype = enm_Visitor_Type.New_Visitor Then
                If Not OP_BL.Save_PatientinfoTemp(Dtbl, Me.Tr_Mode, Txt_PatientID.Text.Trim) Then
                    MessageBox.Show("Error Occured While Saving Patient Info,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Return False
                Else
                    If Dtbl.Rows(0).Item(0).ToString = "0" Then
                        MessageBox.Show("Error Occured While Saving Patient Info,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                        Return False
                    End If
                End If
                'Assign New Patient ID to Control
                If Dtbl.Rows(0).Item("Patient_ID") <> "0" Then
                    Txt_PatientID.Text = Dtbl.Rows(0).Item("Patient_ID").ToString
                Else
                    MessageBox.Show("Error Occured While Saving Patient Info,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Return False
                End If

                'Register Patient Info if its a Employee
            ElseIf Me.Visitortype = enm_Visitor_Type.Employee Then
                If Not OP_BL.Save_PatientinfoEmp(Dtbl, Me.Tr_Mode, Txt_PatientID.Text.Trim) Then
                    MessageBox.Show("Error Occured While Saving Patient Info,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Return False
                End If
                'Assign New Patient ID to Control
                If Dtbl.Rows(0).Item("Patient_ID") <> "0" Then
                    Txt_PatientID.Text = Dtbl.Rows(0).Item("Patient_ID").ToString
                Else
                    MessageBox.Show("Error Occured While Saving Patient Info,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Return False
                End If
            End If

            '===================================================================================================================================================

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Del_Patientinfo(ByVal PatientID As String) As Boolean
        Try
            Dim pat_Bl As New PatientInformation_BL_Cls
            Dim Dtbl As DataTable = Nothing
            Return pat_Bl.Del_Patient_Info(Dtbl, PatientID)

        Catch ex As Exception

        End Try
    End Function

    Private Function Validate_Fields() As Boolean
        Try
            If OP_Service_ID = 0 Then MessageBox.Show("Please Select a Service and Proceed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_Service.Focus() : Return False
            If Seldoctor_ID = 0 Then MessageBox.Show("Please Select a Doctor and Proceed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : TlStrp_Doctors.Focus() : Return False

            If Tr_Mode <> Tran_Mode.New_Mode Then
                If Txt_OPID.Text.Trim = String.Empty Then MessageBox.Show("Invalid OP - ID, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_OPID.Focus() : Return False
            End If

            If Txt_ApointID.Text.Trim = String.Empty Then MessageBox.Show("Invalid Apoint - ID, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_ApointID.Focus() : Return False

            If Trancontrol1.Total_Amount <= 0 Then
                MessageBox.Show("Invalid Transaction Amount, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Trancontrol1.Focus() : Return False
            End If


            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Locate_OPRegister(ByVal OP_ID As String, ByVal Br_Code As Integer) As Boolean
        Try

            Call Clear_Form()

            OP_BL = New OutPatient_BL_Cls

            Dim Dtbl As DataTable = Nothing
            Dim Tramt_Dtbl As DataTable = Nothing
            Dim Op_Tran_Dtbl As DataTable = Nothing
            Dim BkTran_Dtbl As DataTable = Nothing



            Dim Tr_Refno As String = "OP"

            
            If Not OP_BL.Get_OutPatient_Details(Dtbl, OP_ID) Then
                MessageBox.Show("Invalid OP-ID or OP-ID does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return False
            End If


            With Dtbl
                '-------------------------------------------------------------

                Txt_OPID.Text = .Rows(0).Item("OPD_ID").ToString
                Txt_OPID.Tag = Txt_OPID.Text
                Cmb_Service.SelectedValue = .Rows(0).Item("Service ID").ToString
                OP_Service_ID = .Rows(0).Item("Service ID").ToString
                Seldoctor_ID = .Rows(0).Item("Doc_ID").ToString
                '-------------------------------------------------------------

                Me.Txt_PMRID.Text = .Rows(0).Item("Acc_ID").ToString
                Call Btn_PMRIDF2_Click(Nothing, Nothing)
                Me.Txt_ApointID.Text = .Rows(0).Item("Appoint ID").ToString
                Call Btn_AppIDF2_Click(Nothing, Nothing)
                Pnl_Apoint.Enabled = False

                '-------------------------------------------------------------

                Cmb_ArrivalMode.SelectedValue = .Rows(0).Item("Arrival_Mode").ToString
                Cmb_PatientType.SelectedValue = .Rows(0).Item("Patient_Type").ToString
                Cmb_Status.SelectedValue = .Rows(0).Item("Curr_Status").ToString
                Cmb_BillingMethod.SelectedValue = .Rows(0).Item("Billing_Method").ToString
                Txt_AmbulatoryStatus.Text = .Rows(0).Item("Ambulatory Status").ToString


                '--------------------------------------------------------------
                'T R A N S A C T I O N  P A R T

                Tran_BatchID = .Rows(0).Item("Tran_BatchID").ToString
                Tr_Refno = "OP"

                If OP_BL.Get_OutPatient_Trandetails(Op_Tran_Dtbl, Tran_Date, Tran_BatchID, Tr_Refno, Br_Code) Then
                    Txt_Remarks.Text = Op_Tran_Dtbl.Rows(0).Item("Tr_Remarks").ToString
                    If Setting_AmountDtbl(Op_Tran_Dtbl, Tramt_Dtbl) Then
                        Trancontrol1.Assign_Values(Tramt_Dtbl, Op_Tran_Dtbl.Rows(0).Item("Tr_Pay_Mode"))
                        Trancontrol1.Amount_Editable = True
                    Else
                        Return False
                    End If
                Else
                    Return False
                End If

                'Checking whether Cash or not
                If Trancontrol1.Cmb_Paymode.SelectedValue <> 45 Then
                    Bk_Tran_Bl = New BankAccount_BL_Cls
                    If Bk_Tran_Bl.Get_BankAccountTrandetails(BkTran_Dtbl, Tran_Date, Tran_BatchID, Tr_Refno, Branch_Code) Then
                        Me.BK_TranID = BkTran_Dtbl.Rows(0).Item("Tran_ID").ToString
                    End If
                End If

                '--------------------------------------------------------------
                Me.Btn_Print.Enabled = True
                Me.Tr_Mode = Tran_Mode.Edit_Mode
                Me.Pnl_Doc.Enabled = False
                Return True

            End With

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Validate_ExistingOP(ByRef Dtbl As DataTable, ByRef IsvalidOP As Boolean, ByVal OP_ID As String, ByVal Br_Code As Integer) As Boolean
        Try
            OP_BL = New OutPatient_BL_Cls

            If Not OP_BL.Get_OutPatient_Details(Dtbl, OP_ID) Then Return False


            Dim OP_Perioddays As Integer = CInt(Dtbl.Rows(0).Item("OP Period Days").ToString())
            Dim OP_Regdate As Date = CDate(Dtbl.Rows(0).Item("Tran Date").ToString())

            Lbl_OPValidDays.Text = CStr(OP_Perioddays)
            Lbl_OPValidity.Text = CStr(DateAdd(DateInterval.Day, OP_Perioddays, OP_Regdate))

            If DateAdd(DateInterval.Day, OP_Perioddays, OP_Regdate) < Tran_Date Then
                IsvalidOP = False
            Else
                IsvalidOP = True
            End If

            Return True

        Catch ex As Exception

        End Try
    End Function

    Private Function Validate_Trancontrol() As Boolean
        Try
            Dim i As Integer
            With Trancontrol1.Tran_Grid
                If Trancontrol1.Total_Amount <= 0 Then
                    MessageBox.Show("Invalid Transaction Amount, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If

                For i = 0 To Trancontrol1.Tran_Grid.Rows.Count - 1
                    If Val(.Rows(i).Cells("Amount").Value) > 0 Then
                        If Trancontrol1.Tran_Grid.Rows(i).Cells("Particulars").Value.ToString = String.Empty Then _
                        MessageBox.Show("Invalid Account Head, Please Check", Product_Name, _
                        MessageBoxButtons.OK, MessageBoxIcon.Error) : .Rows(i).Cells("AccountHead").Selected = True : Trancontrol1.Focus() : Return False
                    End If
                Next
            End With
            Return True

        Catch ex As Exception
            MessageBox.Show(ex.Message)
            Return False
        End Try
    End Function

    Private Function Save_RegFeeTransaction(ByVal strBatch_ID As String) As Boolean

        Try
            Dim Dr As DataTableReader = Nothing
            Dim Dtbl As DataTable = Nothing
            Dim Bk_Dtbl As DataTable = Nothing



            Tran_BL = New TranMaster_BL_Cls



            'Validating Transaction control
            If Not Validate_Trancontrol() Then Exit Function

            With Tran_BL
                Tran_RefNo = "OP"
                .Tran_BatchID = strBatch_ID
                .Tr_Date = Tran_Date
                .Tr_Narration = Txt_Remarks.Text.Trim
                .Tr_Remarks = Txt_Remarks.Text.Trim
                .Tr_Pay_Mode = Trancontrol1.Cmb_Paymode.SelectedValue
                .Tr_Type = "R"
                .Tr_RefNo = Tran_RefNo

                'Saving Transaction for each expense subtype

                For i = 0 To Trancontrol1.Tran_Grid.Rows.Count - 1
                    If Val(Trancontrol1.Tran_Grid.Rows(i).Cells("Amount").Value.ToString) > 0 Then
                        .Acc_Code = Trancontrol1.Tran_Grid.Rows(i).Cells("Acc_Code").Value.ToString
                        .Tr_Remarks = Txt_Remarks.Text.Trim
                        .Tr_Amount = Trancontrol1.Tran_Grid.Rows(i).Cells("Amount").Value.ToString
                        .Exp_ID = Me.RegExpID

                        .Exp_Subtype = Trancontrol1.Tran_Grid.Rows(i).Cells("Exp_Subtype").Value.ToString

                        Dtbl = Nothing
                        If Not Tran_BL.Save_Transaction(Dtbl, Me.Tr_Mode) Then
                            Return False
                        Else
                            If Dtbl.Rows(0).Item(0).ToString = "E" Then Return False
                        End If
                    End If
                Next

            End With

            If Trancontrol1.Cmb_Paymode.SelectedValue <> 45 Then
                Bk_Tran_Bl = New BankAccount_BL_Cls

                If Bk_Tran_Bl.Get_BankAccountinfo(Bk_Dtbl, Tran_Date, Branch_Code) Then
                    With Bk_Tran_Bl
                        .Acc_Category = Bk_Dtbl.Rows(0).Item("Acc_Code").ToString
                        .Acc_Code = Bk_Dtbl.Rows(0).Item("Acc_Code").ToString
                        .Acc_No = Bk_Dtbl.Rows(0).Item("Acc_No").ToString

                        .BankAcc_ID = Bk_Dtbl.Rows(0).Item("Acc_No").ToString
                        .Tr_Amount = Trancontrol1.Total_Amount
                        .Tr_Date = Tran_Date
                        .Tr_Pay_Mode = Trancontrol1.Cmb_Paymode.SelectedValue
                        .Tr_RefNo = Tran_RefNo
                        .Tr_Remarks = Txt_Remarks.Text.Trim
                        .Tr_Type = "P"
                        .Tran_BatchID = strBatch_ID
                        .Tran_ID = Me.BK_TranID
                        If Not Bk_Tran_Bl.Save_BankAccountTran(Bk_Dtbl, Me.Tr_Mode) Then
                            Return False
                        Else
                            If Dtbl.Rows(0).Item(0).ToString = "0" Then Return False
                        End If
                    End With
                Else
                    MessageBox.Show("Invalid Bank Account Details or Bank Account Details not Set,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Return False
                End If



            End If


            Return True

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function

    Private Function Get_TranbatchID(ByVal Tr_Date As Date, ByVal Isincriment As Boolean, ByVal Br_Code As Integer) As String
        Try

            Tran_BL = New TranMaster_BL_Cls

            Return Tran_BL.Get_TranBatchID(Tran_Date, True, Branch_Code)

        Catch ex As Exception
            Return ""
        End Try

    End Function

    Private Sub GenerateAppointment(ByVal DrId As Integer, _
                                    Optional ByVal ApointID As String = "")

        With Appointment_Reg_Frm
            .Clear_Form()
            .MdiParent = Me.MdiParent
            .Req_Ctrl = Txt_ApointID
            .ShowDialog(Me)
        End With

    End Sub

    Private Function Update_ApointmentOPID(ByVal OPD_ID As String) As Boolean
        Try
            Apoint_Bl = New Appointment_BL_Cls
            Dim Dtbl As DataTable = Nothing
            If Apoint_Bl.Update_AppointmentOPID(Dtbl, Val(Txt_ApointID.Text.Trim), Branch_Code, OPD_ID) Then
                If Dtbl.Rows(0).Item(0).ToString = "0" Then
                    MessageBox.Show("Appointment OP-ID Updation failed,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                Else
                    Return True
                End If
            Else
                Return False
            End If

        Catch ex As Exception

        End Try
    End Function

    Public Sub Initialising_form()
        Try
            hms_helper = New Hms_Helperimpliments

            frm_Heading = Lbl_Heading.Text

            'Populating Combo box
            Call hms_helper.Fill_GenData(Cmb_ArrivalMode, Gendatatype.Arrival_Mode)
            Call hms_helper.Fill_GenData(Cmb_BillingMethod, Gendatatype.Billing_Method)
            Call hms_helper.Fill_GenData(Cmb_Status, Gendatatype.Patient_Status)
            Call hms_helper.Fill_GenData(Cmb_PatientType, Gendatatype.Patient_Type)

            Call hms_helper.Fill_GenData(Cmb_Visittype, Gendatatype.Visit_Type)


            Call hms_helper.Fill_ApointmentServices(Cmb_Service)
            'Just Changed the index to Populate Doctor List
            If Cmb_Service.Items.Count > 0 Then
                Cmb_Service.SelectedIndex = -1
                Cmb_Service.SelectedIndex = 0
            End If
        Catch ex As Exception

        End Try
    End Sub

    Public Function Show_Voucher(ByVal Tr_Date As Date, ByVal OP_ID As String, ByVal Br_Code As Integer) As Boolean
        Try

            If OP_ID.Trim = "" Then
                MessageBox.Show("Please provide  OP-ID and Proceed ", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Txt_OPID.Focus()
                Return False
            End If


            If Val(Trancontrol1.Total_Amount) <= 0 Then
                MessageBox.Show("Invalid Transaction Amount,please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Txt_OPID.Focus()
                Return False
            End If



            Dim mRpt_Vwr As ReportViewer_Cls

            OP_BL = New OutPatient_BL_Cls

            Dim Rpt_Ds As DataSet = Nothing
            Dim Rpt_Formulafields As String = "Company| " & Company_Name & "|Branch|" & Branch_Name
            Dim Rpt_Filename As String = ""
            Dim mReport_ID As String = ""
            Dim Report_Heading As String = ""

            Dim dtbl As DataTable = Nothing
            mRpt_Vwr = New ReportViewer_Cls


            Rpt_Filename = File_Path & "\OP_Voucher.rpt"

            If OP_BL.Get_OPRegVoucherDetails(dtbl, OP_ID, Tr_Date, Br_Code) Then


                Dim Total_Amt As Double = CDbl(dtbl.Rows(0).Item("Amt_Total").ToString)


                Report_Heading = "|Heading| OP RECEIPT |Footer1|Authorised Signatory"
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading & "|Tot_Inwords|" & Towords(Total_Amt)
                With mRpt_Vwr
                    .Show_Mode = Report_Showmode.Condensedmode
                    .RptFrm_Height = 510
                    .RptFrm_Width = 600
                    .MDI_Form = Me
                End With


                mRpt_Vwr.ShowReport(dtbl, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            Else
                MessageBox.Show("Invalid OP-ID .. Please enter valid OP-ID", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function

#End Region

#Region " A d d  New GenData "

    Private Sub Set_NewGendatabutton(ByVal sender As Object, ByVal e As System.EventArgs) Handles Cmb_Status.GotFocus, Cmb_PatientType.GotFocus, Cmb_BillingMethod.GotFocus, Cmb_ArrivalMode.GotFocus
        Try
            Dim AddReqCtrl As Control = CType(sender, Control)

            Btn_New.Visible = True
            Me.Btn_New.Location = Get_Newgendatabuttonposition(AddReqCtrl)
            Me.Btn_New.Tag = AddReqCtrl.Name & "|" & Val(AddReqCtrl.Tag)

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_New_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_New.Click
        Try

            Call AddNewGendata(Btn_New)

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Call_Btnnew(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Cmb_Status.KeyDown, Cmb_BillingMethod.KeyDown, Cmb_PatientType.KeyDown, Cmb_ArrivalMode.KeyDown
        Try
            If e.KeyCode = Keys.Add Then Call Btn_New_Click(Nothing, Nothing)
        Catch ex As Exception

        End Try
    End Sub

#End Region


    Private Sub OP_Registration_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then Call SendKeyTab()

        Catch ex As Exception

        End Try
    End Sub

    Private Sub OP_Register_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub OP_Registration_Frm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            If frm_Heading.Trim = String.Empty Then
                Call Initialising_form()
            Else
                Cmb_ArrivalMode.Focus()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If


            If Tr_Mode = Tran_Mode.New_Mode Then
                Tran_BatchID = Get_TranbatchID(Tran_Date, True, Branch_Code)
            End If


            If Save_OPRegistration(Tran_BatchID) Then
                Btn_Save.Enabled = False
                MessageBox.Show("Out patient Registration Completed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Btn_Clear_Click(Nothing, Nothing)
                Txt_OPID.Focus()
            End If


        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Cmb_Service_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_Service.SelectedIndexChanged
        Try
            Me.OP_Service_ID = 0
            Me.OP_Service_ID = Cmb_Service.SelectedValue
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Try
            Me.Close()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_AppIDF2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_AppIDF2.Click
        Try
            If Txt_ApointID.Text.Trim = String.Empty Then
                Dim Sql As String
                Dim Colwidth As String = String.Empty
                Colwidth = "200|50|50|70|"
                Sql = " SELECT   a.Visitor_Name , a.Apoint_Tokenno as [Token No], a.Apoint_Date as [Apoint Date], a.Apoint_AproxStime as [Apoint Time],a.Doctor, a.Apoint_ID"
                Sql += "  FROM   Appointments_Vw a "
                Sql += " WHERE  (Apoint_Date = '" & Format(Tran_Date, "MM/dd/yyyy") & "') AND (Doc_ID = " & Seldoctor_ID & ") AND (Apoint_Status = 'B') AND Br_code ='" & Branch_Code & "'"

                If Txt_PatientID.Text <> String.Empty Then
                    Sql += " And (Visitor_ID = '" & Txt_PatientID.Text.Trim & "')"
                End If

                'Sql += "   AND	(Exists(Select * "
                'Sql += "  From   dbo.[Get_Doctorswithservices_Fn](" & Cmb_Service.SelectedValue & ",'" & Format(Tran_Date, "MM/dd/yyyy") & "') d Where d.DoctorID = a.Doc_ID))"

                Call ShowSearchengine(Txt_ApointID, Sql, 5, "Visitor_Name", Colwidth, , 0)
            End If

            'Validating Mandatory fields for locating
            If Txt_ApointID.Text.Trim = String.Empty Then
                'MessageBox.Show("Invalid Appointment ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_ApointID.Focus() : Exit Sub
            End If

            If Not Locate_ApointDetails(Val(Txt_ApointID.Text.Trim)) Then
                Call Clear_Apointmentinfo()
                Return
            Else
                Cmb_ArrivalMode.Focus()
                Return
            End If

        Catch ex As Exception
        End Try
    End Sub

    Private Sub TlStrp_Doctors_ItemClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles TlStrp_Doctors.ItemClicked
        Try

            Dim btn_Doctor As ToolStripButton
            btn_Doctor = New ToolStripButton

            For Each btn_Doctor In TlStrp_Doctors.Items
                btn_Doctor.BackColor = Color.White
                btn_Doctor.ForeColor = Color.DarkBlue
            Next

            btn_Doctor = e.ClickedItem

            e.ClickedItem.BackColor = Color.LightSkyBlue ' Color.FromArgb(60, 113, 193)
            'e.ClickedItem.ForeColor = Color.White

            Lbl_Heading.Text = frm_Heading + "  of  " + e.ClickedItem.Text.ToUpper

            Call Clear_Form()
            Seldoctor_ID = 0

            With btn_Doctor
                Seldoctor_ID = Val(.Tag)
                SendKeyTab()
            End With

            Dim Offday As String = String.Empty
            Dim Timings_Dtbl As DataTable = Nothing

            If Not hms_helper.Get_DoctorsDutytimings(Timings_Dtbl, Seldoctor_ID, Tran_Date) Then
                MessageBox.Show("Selected Doctors Duty Timings not available,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Return
            End If

            Dim StrDt As String
            StrDt = Format(Tran_Date, "ddd").ToString()
            Offday = Timings_Dtbl.Rows(0).Item("D_OffDay").ToString
            If InStr(Offday, StrDt) > 0 Then
                MessageBox.Show("Off day for the selected doctor", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Seldoctor_ID = 0
                Lbl_Doctordetails.Text = String.Empty
                Exit Sub
            End If

            Txt_OPID.Focus()

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try
            Call Clear_Form()

            Txt_OPID.Focus()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_ApointID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_ApointID.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then Call Btn_AppIDF2_Click(sender, e)
            If e.KeyCode = Keys.F3 Then Call Btn_Appointment_Click(Nothing, Nothing)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Appointment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Appointment.Click
        Try

            'GenerateAppointment(Seldoctor_ID)
            Try

                If Txt_ApointID.Text.Trim <> "" Then Exit Sub

                If Seldoctor_ID = 0 Then
                    MessageBox.Show("Select a doctor from list", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    TlStrp_Doctors.Focus()
                    Exit Sub
                End If
                With Appointment_Reg_Frm
                    '.MdiParent = Me.MdiParent
                    .Req_Ctrl = Txt_ApointID

                    If .Set_Environment(OP_Service_ID, _
                                        Seldoctor_ID, _
                                        Tran_Date, _
                                        IIf(Txt_PMRID.Text.Trim = String.Empty, 0, 1)) Then

                        If Txt_PMRID.Text.Trim <> String.Empty Then
                            .Txt_PMRID.Text = Txt_PMRID.Text.Trim
                            .Btn_FindPMRID_Click(Nothing, Nothing)
                        End If

                        .IsLoaded = True
                        .ShowDialog(Me)

                        '==================================================
                        '   Locating Apointment details
                        If Txt_ApointID.Text.Trim <> "" Then
                            Call Btn_AppIDF2_Click(Nothing, Nothing)
                            Cmb_ArrivalMode.Focus()
                            Return
                        End If
                        '==================================================

                    End If
                End With

            Catch ex As Exception
                MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

        Catch ex As Exception

        End Try
    End Sub

    Public Sub Btn_PMRIDF2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_PMRIDF2.Click
        Try
            If Txt_PMRID.Text.Trim = String.Empty Then
                Dim Sql As String
                Dim Colwidth As String = String.Empty
                Colwidth = "200|50|300|70|"

                Sql = " SELECT [Patient Name], [SS No], ([Family Name] + Address + City) AS Address, PMR_ID, OPD_ID, Patient_ID"
                Sql += " FROM Pateint_Accountsearch_Vw WHERE (Cancelled = 'N') AND (Authorised = 'Y')"

                Call ShowSearchengine(Txt_PMRID, Sql, 3, "[Patient Name]", Colwidth, , 0)
            End If

            'Validating Mandatory fields for locating
            If Txt_PMRID.Text.Trim = String.Empty Then
                'MessageBox.Show("Invalid Appointment ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_PMRID.Focus() : Exit Sub
            End If

            If Locate_PMR_Masterinfo(Txt_PMRID.Text.Trim) Then
                Btn_Save.Enabled = True
                If Txt_ApointID.Text.Trim <> String.Empty Then
                    Pnl_Apoint.Enabled = False
                    Cmb_ArrivalMode.Focus()
                Else
                    Pnl_Apoint.Enabled = True
                    Txt_ApointID.Focus()
                End If

            Else
                MessageBox.Show("Invalid PMR ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_ApointID_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Txt_ApointID.TextChanged
        Try
            If Txt_ApointID.Text.Trim = String.Empty Then
                Call Clear_Apointmentinfo()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_ApointID_Validating(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_ApointID.Validating
        Try
            If Txt_ApointID.Text.Trim <> String.Empty And Me.Txt_OPID.Text <> Me.Txt_OPID.Tag Then
                If Not Locate_ApointDetails(Val(Txt_ApointID.Text.Trim)) Then
                    e.Cancel = True
                    Return
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try
            If Txt_OPID.Text.Trim = String.Empty Then
                Dim Sql As String
                Dim Colwidth As String = String.Empty
                Colwidth = "145|145|75|50|50|50"
                'Sql = "SELECT   [Patient Name],Doctor,[Status],[Patient Type],Cure_Status, [Tran Date],OPD_ID  FROM OPD_Master_Vw where [Tran Date] = '" & Format(Tran_Date, "MM/dd/yyyy") & "' and Br_Code = " & Branch_Code & " and  Active='Y' and Cancelled='N' "
                Sql = "SELECT   [Patient Name],Address,OPD_ID,[Status],[Cure Status], [Tran Date],[Patient Type]  FROM OPD_Master_Vw where Br_Code = " & Branch_Code & " and  Active='Y' and Cancelled='N' "
                Call ShowSearchengine(Txt_OPID, Sql, 2, "Patient Name", Colwidth, , 0)
            End If
            If Txt_OPID.Text.Trim = String.Empty Then
                Txt_OPID.Focus() : Exit Sub
            End If

            If Txt_OPID.Text.Trim <> "" Then
                If Locate_OPRegister(Txt_OPID.Text.Trim, Branch_Code) Then
                    Tr_Mode = Tran_Mode.Edit_Mode
                    Btn_CancelOP.Enabled = True
                    Btn_Print.Enabled = True
                    Btn_Save.Enabled = True
                End If
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_OPID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_OPID.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then Call Btn_Find_Click(Nothing, Nothing)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_OPID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_OPID.Validating
        Try
            If Me.Txt_OPID.Text.Trim <> "" And Me.Txt_OPID.Text <> Me.Txt_OPID.Tag Then
                If Locate_OPRegister(Txt_OPID.Text.Trim, Branch_Code) Then
                    Tr_Mode = Tran_Mode.Edit_Mode
                    Btn_CancelOP.Enabled = True
                    Btn_Print.Enabled = True
                    Btn_Save.Enabled = True
                Else
                    Txt_OPID.Focus()
                    e.Cancel = True
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_CancelOP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_CancelOP.Click
        Try
            '------------------------------------------------------------------------------------------------------------------
            'Validating Mandatory fields for Deleting

            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If


            Dim Dtbl As DataTable = Nothing
            If Tr_Mode = Tran_Mode.New_Mode Then
                MessageBox.Show("You have to locate details before cancelling the record", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_OPID.Focus()
                Exit Sub
            End If
            If Txt_OPID.Text.Trim = String.Empty Then
                MessageBox.Show("Invalid OP ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_OPID.Focus() : Exit Sub
            End If
            '------------------------------------------------------------------------------------------------------------------

            OP_BL = New OutPatient_BL_Cls
            If MessageBox.Show("Are you sure wan't to Cancel the selected OP Details", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                If OP_BL.Cancell_OP_Register(Dtbl, Txt_OPID.Text.Trim, Tran_Date, Branch_Code) Then
                    MessageBox.Show("OP Details Cancelled successfully", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Call Clear_Form()
                Else
                    MessageBox.Show("You Cannot Cancell this OP details" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            End If
            '------------------------------------------------------------------------------------------------------------------

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_PMRID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_PMRID.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then Call Btn_PMRIDF2_Click(Nothing, Nothing)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Cmb_Visittype_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Cmb_Visittype.KeyDown
        Try
            If e.KeyCode = Keys.F4 Then Call Btn_Followupreg_Click(Nothing, Nothing)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Cmb_Visittype_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_Visittype.SelectedIndexChanged
        Try
            If Cmb_Visittype.SelectedIndex = 0 Then
                Me.Visit_Type = enm_Visit_Type.New_Visit
            Else
                Me.Visit_Type = enm_Visit_Type.Followup_Visit
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Followupreg_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Followupreg.Click
        Try
            With FollowupVisitReg_Frm
                .Initialiseform()
                .Cmb_Service.SelectedValue = Me.Cmb_Service.SelectedValue
                .Seldoctor_ID = Me.Seldoctor_ID
                .Show()
            End With
        Catch ex As Exception

        End Try
    End Sub

  
    Private Sub Btn_Print_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Print.Click
        Try
            Call Show_Voucher(Tran_Date, Txt_OPID.Text.Trim, Branch_Code)
        Catch ex As Exception

        End Try
    End Sub
End Class