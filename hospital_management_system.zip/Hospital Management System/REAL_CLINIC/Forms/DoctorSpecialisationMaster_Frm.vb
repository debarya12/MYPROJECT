﻿Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls
Public Class DoctorSpecialisationMaster_Frm
#Region "Declarations"

    'Object of Employee Details Bussiness Layer
    Private BL_DoctorSpcialisation As DoctorSpecialisationMaster_BL_Cls
    Private mTr_Mode As Tran_Mode
    Private StrQry As String

    Private Com_BL As HMS_Common_BL_Cls

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_DrSpecial_ID.BackColor = Color.White
                    Me.Txt_DrSpecial_ID.ReadOnly = False
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_DrSpecial_ID.BackColor = Color.Silver
                    Me.Txt_DrSpecial_ID.ReadOnly = True
            End Select
        End Set
    End Property

#End Region

    Private Sub DoctorSpecialisationMaster_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.F2 Then Btn_Find_Click(sender, e)
        If e.KeyCode = Keys.Enter Then SendKeyTab()
    End Sub

    Private Sub DoctorSpecialisationMaster_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub DoctorSpecialisationMaster_Frm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'SendKeyTab()
        'SendKeyTab()

        ShowInGrid()
        Cmb_Active.SelectedIndex = 0
        Btn_Delete.Enabled = False
    End Sub

#Region "Functions"
    Private Sub Clear_Form()
        Try
            Txt_DrSpecial_ID.Text = ""
            Txt_DrSpecial_ID.Tag = ""
            Txt_Specilisation_Name.Text = ""
            Cmb_Active.SelectedIndex = 0
            Tr_Mode = Tran_Mode.New_Mode
            Btn_Delete.Enabled = False

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        
    End Sub
    Private Function Locate_Values(ByVal Spec_ID As Integer) As Boolean
        Try

            'Initialising BL Object
            BL_DoctorSpcialisation = New DoctorSpecialisationMaster_BL_Cls

            Dtbl = Nothing
            Call Clear_Form()

            Txt_DrSpecial_ID.Text = Spec_ID


            'Retreiving Doctor Specialisation Details and Assign the values to respective controls
            If BL_DoctorSpcialisation.Get_DRSpecialisation(Dtbl, Spec_ID) Then
                Return Assigntocontrols(Dtbl)
            Else
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        Finally
            Dr = Nothing
            Dtbl = Nothing
            BL_DoctorSpcialisation = Nothing
        End Try
    End Function

    Private Function Assigntocontrols(ByVal D_Table As DataTable) As Boolean
        Try

            Dr = D_Table.CreateDataReader()
            Dr.Read()
            With Dr
                Txt_DrSpecial_ID.Text = .Item("Spec_ID")
                Txt_Specilisation_Name.Text = .Item("Specialization")
                If .Item("Active").ToString.Trim = "A" Then
                    Cmb_Active.SelectedIndex = 0
                Else
                    Cmb_Active.SelectedIndex = 1
                End If

            End With

            Return True
        Catch ex As Exception
            Return False
        Finally
            D_Table = Nothing
        End Try
    End Function

    Private Sub ShowInGrid()
        Try
            Com_BL = New HMS_Common_BL_Cls
            Dim Sr_Dtbl As DataTable = Nothing

            StrQry = "Select Spec_ID,Specialization,Active from Doc_Specializationmaster_Vw "
            If Com_BL.Get_Data(StrQry, Sr_Dtbl) Then
                With Dgrd_DrSpl
                    .DataSource = Nothing
                    .DataSource = Sr_Dtbl

                    .Columns(0).MinimumWidth = 50
                    .Columns(1).MinimumWidth = 225 'DataGridViewAutoSizeColumnMode.DisplayedCells
                    .Columns(2).MinimumWidth = 35

                    '.Columns(3).AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells
                    '.Columns(4).Width = 0
                    .Refresh()
                End With
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try
    End Sub

    Private Function Validate_Fields() As Boolean
        Try
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If

            If Tr_Mode <> Tran_Mode.New_Mode Then
                If Txt_DrSpecial_ID.Text.Trim = "" Then MessageBox.Show("Invalid Specialisation ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_DrSpecial_ID.Focus() : Exit Function
            End If
            If Txt_Specilisation_Name.Text.Trim = "" Then MessageBox.Show("Invalid Specialisation Name,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Specilisation_Name.Focus() : Exit Function
            'If Cmb_Dep_Lid.Text.Trim 
            Return True
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function

#End Region

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try

            If Not Validate_Fields() Then Exit Sub
            BL_DoctorSpcialisation = New DoctorSpecialisationMaster_BL_Cls
            With BL_DoctorSpcialisation
                .Spec_ID = IIf(Tr_Mode <> Tran_Mode.New_Mode, Txt_DrSpecial_ID.Text.Trim, 0)
                .Specialization = Txt_Specilisation_Name.Text.Trim
                .Active = Strings.Left(Cmb_Active.Text, 1).Trim
            End With

            Dtbl = Nothing
            If BL_DoctorSpcialisation.Save_DrSpecialisation_Master(Dtbl, Val(Txt_DrSpecial_ID.Text.Trim), Tr_Mode) Then
                MessageBox.Show("Doctor's Specialisation Details Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Call Clear_Form()
                If Assigntocontrols(Dtbl) Then
                    Tr_Mode = Tran_Mode.Edit_Mode
                    Btn_Delete.Enabled = True
                End If
                Call ShowInGrid()
            Else
                MessageBox.Show("Doctor's Specialisation not Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
            Btn_Clear.Focus()

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click

        Try

            If Txt_DrSpecial_ID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "300|50|50"
                Sql = "Select  Specialization, Active,Spec_ID from Doc_Specializationmaster_Vw  where Br_Code = " & Branch_Code & ""
                Call ShowSearchengine(Txt_DrSpecial_ID, Sql, 2, "Specialization", Colwidth, , 0)
            End If

            'Validating Mandatory fields for locating
            If Txt_DrSpecial_ID.Text.Trim = "" Then
                Txt_DrSpecial_ID.Focus() : Exit Sub
            End If

            If Locate_Values(Txt_DrSpecial_ID.Text.Trim) Then
                Tr_Mode = Tran_Mode.Edit_Mode
                Txt_DrSpecial_ID.Focus()
                Btn_Delete.Enabled = True
            Else
                MessageBox.Show("Doctor Specialisation Master does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Call Clear_Form()
        Txt_DrSpecial_ID.Focus()
    End Sub

    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click
        Try
            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If

            If Tr_Mode = Tran_Mode.New_Mode Then
                MessageBox.Show("You have to locate details before deleting the record", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

            If Txt_DrSpecial_ID.Text.Trim = "" Then
                MessageBox.Show("Invalid Doctor Specialisation,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_DrSpecial_ID.Focus() : Exit Sub
            End If

            'Confirm before delete the record
            If MessageBox.Show("Are you sure wan't to delete the selected doctor specialisation", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = Windows.Forms.DialogResult.No Then
                Exit Sub
            End If


            'Initialising BL Object
            BL_DoctorSpcialisation = New DoctorSpecialisationMaster_BL_Cls

            If BL_DoctorSpcialisation.Del_DoctorSpecialisation(Txt_DrSpecial_ID.Text.Trim) Then
                Call Btn_Clear_Click(sender, e)
                Call ShowInGrid()
            Else
                MessageBox.Show("You cannot delete this doctor specialisation details" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Close()
    End Sub

    Private Sub Txt_DrSpecial_ID_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_DrSpecial_ID.KeyPress
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_DrSpecial_ID.Text, Data_Type.Integer_Type, 12))
    End Sub

    Private Sub Txt_DrSpecial_ID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_DrSpecial_ID.Validating
        Try
            If Txt_DrSpecial_ID.Text.Trim <> "" And Me.Txt_DrSpecial_ID.Text.Trim <> Me.Txt_DrSpecial_ID.Tag Then
                If Locate_Values(Txt_DrSpecial_ID.Text.Trim) Then
                    Btn_Delete.Enabled = True
                    Tr_Mode = Tran_Mode.Edit_Mode
                Else
                    MessageBox.Show("Doctors Specialisation does not exist", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Btn_Delete.Enabled = False
                    Tr_Mode = Tran_Mode.New_Mode
                    e.Cancel = True
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Specilisation_Name_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Specilisation_Name.KeyPress

    End Sub

    Private Sub Txt_Specilisation_Name_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_Specilisation_Name.Validating
        Try
            'Duplicate Checking" ============================================================================

            If Tr_Mode = Tran_Mode.New_Mode Then
                If Com_BL.Check_Duplicatedataexists("Doc_Specializationmaster_Tbl", "Specialization", Data_Type.General_Type, Txt_Specilisation_Name.Text.Trim) Then
                    MessageBox.Show("Specialization Name already exists , Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    e.Cancel = True
                    Txt_Specilisation_Name.Text = ""
                End If
            Else
                If Com_BL.Check_Duplicatedataexists("Doc_Specializationmaster_Tbl", "Specialization", Data_Type.General_Type, Txt_Specilisation_Name.Text.Trim, , , "Spec_ID", Data_Type.Integer_Type, Txt_DrSpecial_ID.Text.Trim) Then
                    MessageBox.Show("Specialization Name already exists , Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    e.Cancel = True
                    Txt_Specilisation_Name.Text = ""
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Dgrd_DrSpl_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs)
        Try
            With Dgrd_DrSpl
                If .CurrentRow Is Nothing Then Exit Sub
                Txt_DrSpecial_ID.Text = .Item("Spec_ID", .CurrentCell.RowIndex).Value.ToString.Trim
                Call Btn_Find_Click(sender, e)
                Txt_DrSpecial_ID.Focus()
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub Dgrd_DrSpl_DoubleClick1(ByVal sender As Object, ByVal e As System.EventArgs) Handles Dgrd_DrSpl.DoubleClick
        Try
            With Dgrd_DrSpl
                If .CurrentRow Is Nothing Then Exit Sub
                Txt_DrSpecial_ID.Text = .Item("Spec_ID", .CurrentCell.RowIndex).Value.ToString
                Call Btn_Find_Click(sender, e)
                Txt_DrSpecial_ID.Focus()
            End With
        Catch ex As Exception

        End Try
    End Sub

  
End Class