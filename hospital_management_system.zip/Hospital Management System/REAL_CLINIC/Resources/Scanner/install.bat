expand IMAGEVUE.IN_ %SystemRoot%\system32\IMAGEVUE.INF
expand WANGIMG.EX_ %SystemRoot%\system32\WANGIMG.EXE
expand IMGADMIN.OC_ %SystemRoot%\system32\IMGADMIN.OCX
expand IMGCMN.DL_ %SystemRoot%\system32\IMGCMN.DLL
expand IMGEDIT.OC_ %SystemRoot%\system32\IMGEDIT.OCX
expand IMGHELP.HL_ %SystemRoot%\system32\IMGHELP.HLP
expand IMGMGT.CH_ %SystemRoot%\system32\IMGMGT.CHM
expand IMGMGT.HL_ %SystemRoot%\system32\IMGMGT.HLP
expand IMGSCAN.OC_ %SystemRoot%\system32\IMGSCAN.OCX
expand IMGSHL.DL_ %SystemRoot%\system32\IMGSHL.DLL
expand IMGTASKS.CH_ %SystemRoot%\system32\IMGTASKS.CHM
expand IMGTHUMB.OC_ %SystemRoot%\system32\IMGTHUMB.OCX
expand IMGVIEW.CH_ %SystemRoot%\system32\IMGVIEW.CHM
expand JPEG1X32.DL_ %SystemRoot%\system32\JPEG1X32.DLL
expand JPEG2X32.DL_ %SystemRoot%\system32\JPEG2X32.DLL
expand KODAKIMG.EX_ %SystemRoot%\system32\KODAKIMG.EXE
expand KODAKPRV.EX_ %SystemRoot%\system32\KODAKPRV.EXE
expand OIENG400.DL_ %SystemRoot%\system32\OIENG400.DLL
expand OIPRT400.DL_ %SystemRoot%\system32\OIPRT400.DLL
expand OISLB400.DL_ %SystemRoot%\system32\OISLB400.DLL
expand OISSQ400.DL_ %SystemRoot%\system32\OISSQ400.DLL
expand OITWA400.DL_ %SystemRoot%\system32\OITWA400.DLL
expand OIUI400.DL_ %SystemRoot%\system32\OIUI400.DLL
expand TIFFLT.DL_ %SystemRoot%\system32\TIFFLT.DLL
expand XIFFR3_0.DL_ %SystemRoot%\system32\XIFFR3_0.DLL
%SystemRoot%\system32\rundll32.exe setupapi,InstallHinfSection DefaultInstall 132 IMAGEVUE.INF
%SystemRoot%\system32\regsvr32 IMGADMIN.OCX
%SystemRoot%\system32\regsvr32 IMGEDIT.OCX
%SystemRoot%\system32\regsvr32 IMGSCAN.OCX
%SystemRoot%\system32\regsvr32 IMGTHUMB.OCX