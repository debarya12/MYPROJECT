﻿
Option Explicit On
Imports System.IO
Imports HMS_BL
Imports HMS_Common.Common_Cls
Public Class Patient_Transaction_Frm

#Region "Declaration"
    Private mTr_Mode As Tran_Mode
    Private hms_helper As HMS_Helper = Nothing
    Private Patient_Tran_BL As Patient_Transaction_BL_Cls

    Private mRpt_Vwr As ReportViewer_Cls
    Private Rpt_BL As HMS_BL.Reports_BL_Cls


    'Transaction Mode checking Property
    Public Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_BatchID.BackColor = Color.White
                    Me.Txt_OutPatientID.ReadOnly = False
                    Me.Txt_PatientID.ReadOnly = False
                    Me.Txt_BatchID.ReadOnly = False
                    Me.Btn_Save.Enabled = True
                    Btn_Add.Enabled = True

                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_BatchID.BackColor = Color.Silver
                    Me.Txt_OutPatientID.ReadOnly = True
                    Me.Txt_PatientID.ReadOnly = True
                    Me.Txt_BatchID.ReadOnly = True
                    Me.Btn_Save.Enabled = False
                    Btn_Add.Enabled = False


            End Select
        End Set
    End Property



    Dim tvRoot As TreeNode
    Dim tvNode As TreeNode
    Dim tvNode1 As TreeNode


    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing
#End Region

#Region "Methods"
    Private Sub Clear_Form()
        Try
            Clear_Values()
            Tr_Mode = Tran_Mode.New_Mode
            Btn_Cancel.Enabled = False
            'Txt_BatchID.Focus()
            Txt_OutPatientID.Tag = ""
            Txt_PatientID.Tag = ""
            Txt_PMRID.Text = ""
            Txt_PMRID.Tag = ""
            Txt_ExpenseDetails.Text = ""
            Txt_PMRID.Focus()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Clear_Values()
        Try
            Txt_BatchID.Text = ""
            Txt_BatchID.Tag = ""
            Txt_PatientID.Text = ""
            Txt_OutPatientID.Text = ""
            Txt_ExpenseMaster.Tag = ""
            Txt_ExpenseMaster.Text = ""
            Txt_ExpID.Text = ""
            Lbl_TotalAmount.Text = ""
            Txt_Remarks.Text = ""
            Lbl_Doctor.Text = ""

            Lbl_DepositAmt.Text = ""
            Lbl_Paid_BillAmt.Text = ""
            Lbl_UnPaid_BillAmt.Text = ""
            Lbl_BalanceAmt.Text = ""

            Txt_Trandate.Text = Strings.Left(Tran_Date.ToString, 10)

            Patient_Info2.Patient_ID = -1
            Dgv_ChargesGrid.RowCount = 0
            Dgv_PatientBill_Grid.RowCount = 0
            Trancontrol1.Clear_AllValues()

        Catch ex As Exception

        End Try

    End Sub

    Private Sub Clear_Trangrid()
        Try
            Trancontrol1.Clear_AllValues()
            Txt_Charge.Text = ""
            Txt_ExpenseDetails.Text = ""
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Fill_ExpenseGroup()
        Try
            Dtbl = Nothing
            Dr = Nothing
            hms_helper = New Hms_Helperimpliments

            If hms_helper.Get_ExpenseGrouplist(Dtbl) Then
                tvRoot = Me.Tvw_ExpenseList.Nodes.Add("Expense Heads")

                Dr = Dtbl.CreateDataReader
                With Dr
                    While Dr.Read
                        tvNode = tvRoot.Nodes.Add(Dr.Item("Exp_GrpID"), Dr.Item("Exp_Groupname"))
                        tvNode.ForeColor = Color.Maroon
                        tvNode.Name = "G" + Dr.Item("Exp_Groupname").ToString
                        tvNode.Tag = Dr.Item("Exp_GrpID").ToString
                    End While
                End With

            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Fill_ExpenseMaster()
        Try
            Dtbl = Nothing
            Dr = Nothing
            If Tvw_ExpenseList.Nodes.Count = 0 Then Exit Sub
            hms_helper = New Hms_Helperimpliments
            With Tvw_ExpenseList

                For i = 0 To .Nodes(0).Nodes.Count - 1
                    Dtbl = Nothing
                    Dr = Nothing

                    If hms_helper.Get_ExpenseMasterdatalist(Dtbl, .Nodes(0).Nodes(i).Tag) Then
                        Dr = Dtbl.CreateDataReader

                        While Dr.Read

                            Lst_Search.Items.Add(Dr.Item("Exp_Name"))

                            tvRoot = .Nodes(0).Nodes(i)
                            tvNode = tvRoot.Nodes.Add(Dr.Item("Exp_ID"), Dr.Item("Exp_Name"))
                            tvNode.ForeColor = Color.DarkBlue
                            tvNode.Name = "N" + Dr.Item("Exp_Name").ToString

                            tvNode.Tag = Dr.Item("Exp_ID").ToString
                            .Nodes(0).Nodes(i).Expand()
                        End While

                    End If
                Next

            End With

            Lst_Search.Sorted = True

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Function Get_ExpenseItemUsingID(ByVal Exp_ID As String) As Boolean
        Try


            With Tvw_ExpenseList
                For i = 0 To .Nodes(0).Nodes.Count - 1
                    tvRoot = .Nodes(0).Nodes(i)
                    For Each node In tvRoot.Nodes
                        tvNode = node
                        If tvNode.Tag = Exp_ID Then
                            Txt_ExpenseMaster.Text = Strings.Right(tvNode.Name, Len(tvNode.Name) - 1)
                            .SelectedNode = tvNode
                            Return True
                        End If
                    Next
                Next
            End With

            Return False
        Catch ex As Exception
            Return False
        End Try

    End Function

    Private Function GetNode(ByVal text As String, ByVal parentCollection As TreeNodeCollection) As TreeNode
        Try


            Dim ret As TreeNode = Nothing
            Dim child As TreeNode

            For Each child In parentCollection 'step through the parentcollection
                If child.Text = text Then
                    ret = child
                ElseIf child.GetNodeCount(False) > 0 Then ' if there is child items then call this function recursively
                    ret = GetNode(text, child.Nodes)
                End If

                If Not ret Is Nothing Then Exit For 'if something was found, exit out of the for loop

            Next

            Return ret
        Catch ex As Exception
            Return Nothing
        End Try

    End Function

    Private Function Locate_Patient(ByVal Patient_ID As String) As Boolean
        Try

            hms_helper = New Hms_Helperimpliments
            If hms_helper.Get_OutPatient_Info_Latest(Dtbl, Txt_PatientID.Text.Trim, Tran_Date, Branch_Code) Then
                Txt_OutPatientID.Text = Dtbl.Rows(0).Item("OPD_ID").ToString
                Txt_PatientID.Tag = Patient_ID
                Call Locate_Outpatient(Txt_OutPatientID.Text.Trim)
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Locate_Outpatient(ByVal OPD_ID As String) As Boolean
        Try
            Dim dtbl As DataTable = Nothing
            REM locating patient information
            hms_helper = New Hms_Helperimpliments

            If hms_helper.Get_OutPatient_Doctor(dtbl, OPD_ID, Branch_Code) Then
                Lbl_Doctor.Text = dtbl.Rows(0).Item("Name").ToString & vbCrLf & dtbl.Rows(0).Item("Category").ToString
                Txt_OutPatientID.Tag = OPD_ID
            End If

            dtbl = Nothing
            If hms_helper.Get_OP_Details(dtbl, Txt_OutPatientID.Text.Trim) Then

                Txt_PatientID.Text = dtbl.Rows(0).Item("Patient ID").ToString

                Call Get_Patient_CreditPosition(Txt_PMRID.Text)

                With Patient_Info2
                    .Viewmoreform_Name = "Patient_InfoSheet_Frm"
                    .MDIform_Name = Me.MdiParent
                    .Patient_ID = Txt_PatientID.Text.Trim
                End With


                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Get_Patient_CreditPosition(ByVal PMR_ID As String)
        Try
            Dim dtbl As DataTable = Nothing
            Patient_Tran_BL = New Patient_Transaction_BL_Cls
            If Patient_Tran_BL.Get_Patient_CreditPosition(dtbl, PMR_ID, Tran_Date, Branch_Code) Then
                Lbl_DepositAmt.Text = dtbl.Rows(0).Item("Deposit").ToString
                Lbl_Paid_BillAmt.Text = dtbl.Rows(0).Item("Paid_Bills").ToString
                Lbl_UnPaid_BillAmt.Text = dtbl.Rows(0).Item("UnPaid_Bills").ToString
                Lbl_BalanceAmt.Text = dtbl.Rows(0).Item("Balance").ToString
            End If


        Catch ex As Exception

        End Try

    End Sub

    Private Function Fill_Trancontrol(ByVal ExpenseID As String) As Boolean
        Try

            Trancontrol1.Clear_Values()


            Dim dtbl As DataTable = Nothing
            Dim Gridsorce_Dtbl As New DataTable
            Dim Assignvalue_Dtbl As New DataTable

            Dim Drow, Amt_Drow As DataRow
            Dim Paymentmodesource_Dtbl As DataTable = Nothing

            With Gridsorce_Dtbl
                .Columns.Add("Particulars")
                .Columns.Add("Acc_Code")
                .Columns.Add("Exp_Subtype")
                .Columns.Add("Def_Trantype")
                .Columns.Add("Editable")
                .Columns.Add("Charge_Calctype")
                .Columns.Add("Percentage_Of")
                .Columns.Add("Percentage")


            End With

            With Assignvalue_Dtbl
                .Columns.Add("Exp_Subtype")
                .Columns.Add("Amount")
            End With


            If Not hms_helper.Get_ExpenseCharges(dtbl, ExpenseID, Tran_Date) Then Return False

            For i = 0 To dtbl.Rows.Count - 1
                Drow = Gridsorce_Dtbl.NewRow()
                Drow("Particulars") = dtbl.Rows(i).Item("Particulars").ToString
                ' MessageBox.Show(dtbl.Rows(i).Item("Particulars").ToString)

                Drow("Acc_Code") = dtbl.Rows(i).Item("Exp_Acc_Code").ToString
                'MessageBox.Show(dtbl.Rows(i).Item("Exp_Acc_Code").ToString)

                Drow("Exp_Subtype") = dtbl.Rows(i).Item("Exp_Subtype").ToString
                'MessageBox.Show(dtbl.Rows(i).Item("Exp_Subtype").ToString)

                Drow("Def_Trantype") = "C"
                Drow("Editable") = "Y"

                Drow("Charge_Calctype") = dtbl.Rows(i).Item("Charge_Calctype").ToString
                Drow("Percentage_Of") = dtbl.Rows(i).Item("Percentage_Of").ToString
                Drow("Percentage") = dtbl.Rows(i).Item("Exp_Amount").ToString


                Gridsorce_Dtbl.Rows.Add(Drow)

                Amt_Drow = Assignvalue_Dtbl.NewRow
                Amt_Drow("Exp_Subtype") = dtbl.Rows(i).Item("Exp_Subtype").ToString
                Amt_Drow("Amount") = dtbl.Rows(i).Item("Exp_Amount").ToString
                Assignvalue_Dtbl.Rows.Add(Amt_Drow)
            Next



            If hms_helper.Get_Gendata(Paymentmodesource_Dtbl, Gendatatype.Payment_Mode) Then
                If Trancontrol1.Set_Tranenvironment(Gridsorce_Dtbl, Paymentmodesource_Dtbl) Then
                    Trancontrol1.Assign_Values(Assignvalue_Dtbl, 48)
                    Trancontrol1.Amount_Editable = True
                End If
            End If
            Return True

        Catch ex As Exception

        End Try
    End Function

    Private Sub Total_BillAmt()
        Try
            Dim Totalamt As Double = 0
            With Dgv_ChargesGrid

                For i = 0 To .Rows.Count - 1
                    Totalamt += .Rows(i).Cells("Amount").Value
                Next

                Lbl_TotalAmount.Text = Totalamt.ToString("0.00")

            End With

        Catch ex As Exception

        End Try
    End Sub

    Private Function Save_Patient_Tran(ByRef PatientTran_BatchID As String) As Boolean
        Try


            Dim dtbl As DataTable = Nothing
            hms_helper = New Hms_Helperimpliments
            Patient_Tran_BL = New Patient_Transaction_BL_Cls
            Patient_Tran_BL.PatientTran_BatchID = Txt_BatchID.Text.Trim

            If Tr_Mode = Tran_Mode.New_Mode Then
                Patient_Tran_BL.Get_PatientTran_BatchNO(dtbl, Branch_Code)
                Txt_BatchID.Text = dtbl.Rows(0).Item(0).ToString
                Patient_Tran_BL.PatientTran_BatchID = Txt_BatchID.Text.Trim
            End If
            dtbl = Nothing
            Patient_Tran_BL.Tr_Date = Tran_Date
            Patient_Tran_BL.ACC_ID = Txt_PMRID.Text
            Patient_Tran_BL.Patient_ID = Txt_PatientID.Text
            Patient_Tran_BL.OPD_ID = Txt_OutPatientID.Text
            Patient_Tran_BL.Tr_Remarks = Txt_Remarks.Text.Trim
            Patient_Tran_BL.Bill_Gen = "N"



            With Dgv_ChargesGrid

                For i = 0 To .Rows.Count - 1


                    Patient_Tran_BL.Tr_Amount = .Rows(i).Cells("Amount").Value.ToString
                    Patient_Tran_BL.Bill_Status = "U"
                    Patient_Tran_BL.Exp_ID = .Rows(i).Cells("Exp_ID").Value.ToString

                    If Not Patient_Tran_BL.Save_Patient_Transaction(dtbl, Txt_BatchID.Text.Trim, Tr_Mode) Then
                        Return False
                    End If

                Next

            End With
            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Sub Save_General_Transaction()
        Try

            Dim Gen_Tran_BL As Gen_Transaction_BL_Cls
            Dim dtbl As DataTable = Nothing
            Gen_Tran_BL = New Gen_Transaction_BL_Cls
            With Gen_Tran_BL

                If Gen_Tran_BL.Get_Maxmimum_BatchNo_GenTran(dtbl) Then
                    Dr = dtbl.CreateDataReader
                    Dr.Read()
                    Gen_Tran_BL.Tran_BatchID = Dr.GetValue(0).ToString.Trim
                    If Gen_Tran_BL.Tran_BatchID = "" Then Gen_Tran_BL.Tran_BatchID = "0000000001"
                    Txt_BatchID.Tag = Gen_Tran_BL.Tran_BatchID
                End If


                .Tr_RefNo = Txt_BatchID.Text
                .Tr_Date = Tran_Date
                .Tr_Narration = Txt_Remarks.Text
                .Tr_Pay_Mode = Trancontrol1.Cmb_Paymode.SelectedValue
                .Tr_Type = "R"
                .Tr_Remarks = Txt_PatientID.Text

                With Dgv_ChargesGrid

                    For i = 0 To .Rows.Count - 1

                        Gen_Tran_BL.Acc_Code = .Rows(i).Cells("Acc_Code").Value.ToString
                        Gen_Tran_BL.Tr_Amount = .Rows(i).Cells("Amount").Value.ToString
                        Gen_Tran_BL.Exp_ID = .Rows(i).Cells("Exp_ID").Value.ToString
                        Gen_Tran_BL.Exp_Subtype = .Rows(i).Cells("Exp_Subtype").Value.ToString

                        dtbl = Nothing
                        If Not Gen_Tran_BL.Save_Gen_Transaction(dtbl, Tran_Mode.New_Mode, Gen_Tran_BL.Tran_BatchID) Then
                            MessageBox.Show("General Transaction Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                        End If

                    Next

                End With




            End With
        Catch ex As Exception

        End Try
    End Sub

    Public Function Locate_Values(ByVal Tran_BatchID As String) As Boolean
        Try
            hms_helper = New Hms_Helperimpliments
            Patient_Tran_BL = New Patient_Transaction_BL_Cls

            Dim dtbl As DataTable = Nothing
            Dim dtbl1 As DataTable = Nothing
            Dgv_ChargesGrid.RowCount = 0
            If Patient_Tran_BL.Get_Patient_Transaction(dtbl, Tran_BatchID, Branch_Code) Then

                Txt_PMRID.Text = dtbl.Rows(0).Item("Acc_ID").ToString

                For i = 0 To dtbl.Rows.Count - 1
                    With Dgv_ChargesGrid

                        .Rows.Add()

                        If hms_helper.Get_Expence_Name(dtbl1, dtbl.Rows(i).Item("Exp_ID").ToString) Then
                            .Rows(i).Cells("Expense").Value = dtbl1.Rows(0).Item(0).ToString.Trim
                        End If

                        .Rows(i).Cells("Amount").Value = dtbl.Rows(i).Item("Tr_Amount").ToString.Trim

                        .Rows(i).Cells("Exp_ID").Value = dtbl.Rows(i).Item("Exp_ID").ToString.Trim

                    End With
                Next

                Txt_Remarks.Text = dtbl.Rows(0).Item("Tr_Remarks").ToString.Trim
                Txt_PatientID.Text = dtbl.Rows(0).Item("Patient_ID").ToString.Trim
                Txt_OutPatientID.Text = dtbl.Rows(0).Item("OPD_ID").ToString.Trim

                Call Get_Patient_CreditPosition(Txt_PMRID.Text)
                dtbl = Nothing
                If hms_helper.Get_OutPatient_Doctor(dtbl, Txt_PMRID.Text.Trim, Branch_Code) Then
                    Lbl_Doctor.Text = dtbl.Rows(0).Item("Name").ToString & vbCrLf & dtbl.Rows(0).Item("category").ToString
                End If

                dtbl = Nothing
                If hms_helper.Get_OP_Details(dtbl, Txt_OutPatientID.Text.Trim) Then

                    Txt_PatientID.Text = dtbl.Rows(0).Item("Patient ID").ToString

                    With Patient_Info2
                        .Viewmoreform_Name = "Patient_InfoSheet_Frm"
                        .MDIform_Name = Me.MdiParent
                        .Patient_ID = Txt_PatientID.Text.Trim
                    End With


                End If

            Else
                Return False
            End If
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Validate_Fields() As Boolean
        Try
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If


            If Tr_Mode <> Tran_Mode.New_Mode Then
                If Txt_PMRID.Text.Trim = "" Then MessageBox.Show("Invalid PMR ID ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_BatchID.Focus() : Return False

            End If
            'validating all mandatory fields

            If Txt_OutPatientID.Text.Trim = "" Then MessageBox.Show("Invalid Patient ID, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_OutPatientID.Focus() : Return False
            If Txt_PatientID.Text.Trim = "" Then MessageBox.Show("Invalid Patient ID, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_PatientID.Focus() : Return False
            If Dgv_ChargesGrid.Rows.Count = 0 Then MessageBox.Show("No Expense Added, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_ExpenseMaster.Focus() : Return False

            Return True

        Catch ex As Exception

        End Try

    End Function

    Private Sub Disable_Controls()
        Try
            If Tr_Mode = Tran_Mode.Edit_Mode Then
                Lst_Search.Enabled = False
                Txt_ExpenseMaster.Enabled = False
                Btn_Add.Enabled = False
                Tvw_ExpenseList.Enabled = False
                Btn_Cancel.Focus()

            Else
                Lst_Search.Enabled = True
                Txt_ExpenseMaster.Enabled = True
                Btn_Add.Enabled = True
                Tvw_ExpenseList.Enabled = True
            End If

        Catch ex As Exception

        End Try
    End Sub

    Public Function Show_Reciept(ByVal OPD_ID As String, ByVal frmDate As Date, ByVal ToDate As Date, ByVal Add_Query1 As String) As Boolean
        Try
            If OPD_ID = "" Then MessageBox.Show("Invalid  Outpatient ID .. Please enter valid Outpatient Id", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Exit Function
            Dim Rpt_Ds As DataSet = Nothing
            Dim Rpt_Formulafields As String = "Company| " & Company_Name & "|Branch|" & Branch_Name
            Dim Rpt_Filename As String = ""
            Dim mReport_ID As String = ""
            Dim Report_Heading As String = ""
            Dim Add_Query As String = ""

            mRpt_Vwr = New ReportViewer_Cls

            Add_Query = ""
            Add_Query = "Where [OPD_ID] = " & OPD_ID & " and Br_Code=" & Branch_Code & " and Tr_Date >='" & Format(frmDate, "MM/dd/yyyy") & "' and Tr_Date <='" & Format(ToDate, "MM/dd/yyyy") & "'"
            If Len(Add_Query1) > 0 Then Add_Query = Add_Query + Add_Query1
            Rpt_Filename = File_Path & "\Patient_Transaction_Reports.rpt"
            Patient_Tran_BL = New Patient_Transaction_BL_Cls
            If Patient_Tran_BL.Get_PatientTran_OutPatient(Rpt_Ds, Add_Query) Then

                REM for Geting total amount 
                Dim dtbl As DataTable = Rpt_Ds.Tables(0)
                Dim dr As DataTableReader
                Dim Amt As Double
                Amt = 0
                dr = dtbl.CreateDataReader

                While dr.Read
                    Amt = Amt + Val(dr.Item("Tr_Amount").ToString)
                End While
                REM .....

                Report_Heading = "|Heading| Outpatient Transaction Details|Footer3|Authorised Signatory"
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading & "|words|" & Towords(Amt)
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "")
            Else
                MessageBox.Show("Invalid Outpatient ID .. Please enter valid Outpatient ID", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function

    Private Function Show_TranReciept() As Boolean
        Try
            If Txt_BatchID.Text.Trim = "" Then MessageBox.Show("Invalid  Batch ID .. Please enter valid Tran Id", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Exit Function

            If Val(Lbl_TotalAmount.Text) <= 0 Then Exit Function
            Dim Rpt_Ds As DataSet = Nothing
            Dim Rpt_Formulafields As String = "Company| " & Company_Name & "|Branch|" & Branch_Name
            Dim Rpt_Filename As String = ""
            Dim mReport_ID As String = ""
            Dim Report_Heading As String = ""
            Dim Add_Query As String = ""

            mRpt_Vwr = New ReportViewer_Cls

            Add_Query = ""
            Add_Query = "Where [Batch No] = " & Txt_BatchID.Tag & " "
            Rpt_Filename = File_Path & "\Gen_Tran_Reciept.rpt"
            Rpt_BL = New HMS_BL.Reports_BL_Cls
            If Rpt_BL.Get_GenTran_Reciept(Rpt_Ds, Add_Query) Then

                REM for Geting total amount 
                Dim dtbl As DataTable = Rpt_Ds.Tables(0)
                Dim dr As DataTableReader
                Dim Amt As Double
                Amt = 0
                dr = dtbl.CreateDataReader

                While dr.Read
                    Amt = Amt + Val(dr.Item("Tr_Amount").ToString)
                End While
                REM .....

                Report_Heading = "|Heading| Receipt|Footer3|Authorised Signatory"
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading & "|words|" & Towords(Amt)
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)
            Else
                MessageBox.Show("Invalid Batch ID .. Please enter valid Batch ID", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function

    Private Function Locate_PMR_info(ByVal PMR_ID As String, ByVal Br_Code As Integer) As Boolean
        Try

            '-----------------   Clear Medical Record   -----------------------------------

            Call Clear_Form()

            '----------------------------------------------------------------------------

            Dim Dtbl As DataTable = Nothing

            '-----------------  Locate Pateint Medical Record Master info   -------------
            If Not hms_helper.Get_PMR_Masterinfo(Dtbl, PMR_ID, Br_Code) Then Return False


            With Dtbl
                Txt_PMRID.Text = PMR_ID
                Patient_Info2.Patient_ID = .Rows(0).Item("Patient ID").ToString
                Txt_PatientID.Text = .Rows(0).Item("Patient ID").ToString
                Txt_OutPatientID.Text = .Rows(0).Item("OP ID").ToString
            End With


            Call Get_Patient_CreditPosition(Txt_PMRID.Text)

            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Save_Patient_Bill() As Boolean
        Try

            Dim dtbl As DataTable = Nothing
            Dim Patient_Tran_Bill_BL = New Patient_Transaction_Bill_BL_Cls
            Patient_Tran_Bill_BL = New Patient_Transaction_Bill_BL_Cls

            Patient_Tran_Bill_BL.Bill_ID = 0
            dtbl = Nothing
            If Patient_Tran_Bill_BL.Get_Max_PatientBillBatch_No(dtbl, Branch_Code) Then
                Patient_Tran_Bill_BL.Bill_BatchNo = dtbl.Rows(0).Item(0).ToString.Trim
            End If
            Patient_Tran_Bill_BL.Bill_Date = Tran_Date
            Patient_Tran_Bill_BL.OPD_ID = Txt_OutPatientID.Text.Trim


            dtbl = Nothing
            If hms_helper.Get_OutPatient_Acc_ID(dtbl, Txt_OutPatientID.Text.Trim, Branch_Code) Then
                Patient_Tran_Bill_BL.ACC_ID = dtbl.Rows(0).Item(0).ToString
            End If
            Patient_Tran_Bill_BL.Patient_ID = Txt_PatientID.Text.Trim

            Patient_Tran_Bill_BL.PatientTran_BatchID = Txt_BatchID.Text

            Patient_Tran_Bill_BL.Bill_Status = "U"



            With Dgv_PatientBill_Grid

                For i = 0 To .Rows.Count - 1

                    Patient_Tran_Bill_BL.Acc_Code = .Rows(i).Cells("Acc_Code").Value.ToString
                    Patient_Tran_Bill_BL.Bill_Amount = .Rows(i).Cells("Amounts").Value.ToString
                    Patient_Tran_Bill_BL.Exp_ID = .Rows(i).Cells("Expense_ID").Value.ToString
                    Patient_Tran_Bill_BL.Exp_Subtype = .Rows(i).Cells("Exp_Subtype").Value.ToString

                    dtbl = Nothing
                    Patient_Tran_Bill_BL.Save_Patient_Tran_Bill(dtbl, Tran_Mode.New_Mode, Patient_Tran_Bill_BL.Bill_BatchNo)
                Next

            End With


            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Add_Patient_BillGrid()
        Try
            If Trancontrol1.Tran_Grid.Rows.Count = 0 Then Txt_ExpenseMaster.Focus() : Exit Sub
            With Dgv_PatientBill_Grid

                For i = 0 To Trancontrol1.Tran_Grid.RowCount - 1
                    .Rows.Add()
                    .Rows(.Rows.Count - 1).Cells("ExpenseName").Value = Txt_ExpenseMaster.Text.Trim
                    .Rows(.Rows.Count - 1).Cells("Particulars").Value = Trancontrol1.Tran_Grid.Rows(i).Cells("Particulars").Value.ToString
                    .Rows(.Rows.Count - 1).Cells("Amounts").Value = Trancontrol1.Tran_Grid.Rows(i).Cells("Amount").Value.ToString
                    .Rows(.Rows.Count - 1).Cells("Acc_Code").Value = Trancontrol1.Tran_Grid.Rows(i).Cells("Acc_Code").Value.ToString
                    .Rows(.Rows.Count - 1).Cells("Exp_Subtype").Value = Trancontrol1.Tran_Grid.Rows(i).Cells("Exp_Subtype").Value.ToString
                    .Rows(.Rows.Count - 1).Cells("Def_TranType").Value = "C"
                    .Rows(.Rows.Count - 1).Cells("Editable").Value = "Y"
                    .Rows(.Rows.Count - 1).Cells("Expense_ID").Value = Txt_ExpenseMaster.Tag
                Next
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Show_CrediPosition()

        Try
            If Pnl_Details.Size.Height = 22 Then
                Pct_UPDown.Image = My.Resources.upArrow
                Pnl_Details.Size = New Size(207, 142)
            Else
                Pct_UPDown.Image = My.Resources.downArrow
                Pnl_Details.Size = New Size(207, 22)
            End If
        Catch ex As Exception

        End Try
    End Sub

#End Region


    Private Sub Patient_Transaction_Frm_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
        Try
            If Tr_Mode = Tran_Mode.Edit_Mode Then
                Btn_Cancel.Enabled = True
                Btn_Cancel.Focus()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Reports_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        Try
            If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Reports_Frm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try

            Call Fill_ExpenseGroup()
            Call Fill_ExpenseMaster()
            Me.Tvw_ExpenseList.ExpandAll()

            With Cmb_PayStatus
                .Items.Add("All")
                .Items.Add("Paid")
                .Items.Add("UnPaid")
            End With
            Cmb_PayStatus.SelectedIndex = 0

            Trancontrol1.Cmb_Paymode.Visible = False
            If Tr_Mode = Tran_Mode.New_Mode Then Txt_Trandate.Text = Strings.Left(Tran_Date.ToString, 10)

            If Not Tr_Mode = Tran_Mode.Edit_Mode Then
                Btn_Cancel.Enabled = True
                Btn_Cancel.Focus()
            Else
                Btn_Cancel.Enabled = False
            End If

            Txt_OutPatientID.Tag = ""
            Txt_Trandate.Text = Tran_Date
            Dtp_FrmDate.Value = Tran_Date
            Dtp_ToDate.Value = Tran_Date
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_ExpenseMaster_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_ExpenseMaster.KeyDown
        Try


            If e.KeyCode = Keys.Enter Then
                If Txt_ExpenseMaster.Text.Trim <> "" Then
                    If Trim(Txt_ExpenseMaster.Text) <> "." Then
                        Txt_ExpenseMaster.Text = Lst_Search.SelectedItem
                        Lst_Search.Visible = False
                        'look for a node with a text property value of 'Node3'
                        Tvw_ExpenseList.SelectedNode = GetNode(Txt_ExpenseMaster.Text, Tvw_ExpenseList.Nodes)
                        'Tvw_ExpenseList the focus set on the node
                        Tvw_ExpenseList.SelectedNode.EnsureVisible()
                        Tvw_ExpenseList.Select()
                        If Txt_ExpenseMaster.Text.Trim <> "" Then
                            Btn_Add.Focus()
                        Else
                            Txt_ExpenseMaster.Focus()
                        End If
                    Else
                        Txt_Remarks.Focus()
                    End If
                    Else
                        MessageBox.Show("Enter Valid Expense Head, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                        Txt_ExpenseMaster.Focus()
                    End If
            ElseIf e.KeyCode = Keys.Down Then
                Lst_Search.SelectedIndex = Lst_Search.SelectedIndex + 1
            ElseIf e.KeyCode = Keys.Up Then
                Lst_Search.SelectedIndex = Lst_Search.SelectedIndex - 1
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_ExpenseMaster_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_ExpenseMaster.TextChanged
        Try
            If Txt_ExpenseMaster.Text.Trim <> "" Then
                'Txt_ExpID.Text = ""
                'Retrieve the item's listindex
                Lst_Search.Visible = True
                Dim i As Integer = Lst_Search.FindString(Txt_ExpenseMaster.Text)

                'highligting the matched ones
                Lst_Search.SelectedIndex = i

            Else : Lst_Search.Visible = False
            End If
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Tvw_ExpenseList_AfterSelect(ByVal sender As System.Object, ByVal e As System.Windows.Forms.TreeViewEventArgs) Handles Tvw_ExpenseList.AfterSelect
        Try

            Trancontrol1.Clear_AllValues()
            If Strings.Left(Tvw_ExpenseList.SelectedNode.Name.ToString, 1) = "N" Then

                Txt_ExpenseMaster.Text = Tvw_ExpenseList.SelectedNode.Text
                Txt_ExpenseDetails.Text = Tvw_ExpenseList.SelectedNode.Text
                Txt_ExpenseMaster.Tag = Tvw_ExpenseList.SelectedNode.Tag
                Txt_ExpID.Text = Tvw_ExpenseList.SelectedNode.Tag
                Lst_Search.Visible = False
                If Fill_Trancontrol(Txt_ExpID.Text.Trim) Then
                    Txt_Charge.Text = Trancontrol1.Lbl_TotalAmount.Text
                Else
                    MessageBox.Show("Fees Settings Not Done , Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)

                    Txt_ExpenseMaster.Text = ""
                    Txt_ExpenseDetails.Text = ""
                    Txt_ExpenseMaster.Focus()
                    Exit Sub
                End If


            End If
        Catch ex As Exception

        End Try

    End Sub

   

    Private Sub Btn_Add_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Add.Click
        Try
            If Txt_PMRID.Text.Trim = "" Then MessageBox.Show("Invalid PMR ID, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_PMRID.Focus() : Exit Sub
            If Trancontrol1.Tran_Grid.Rows.Count = 0 Then MessageBox.Show("Expense Charge Not found, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_ExpenseMaster.Focus() : Exit Sub
            If Not Is_Duplicate(Txt_ExpenseDetails.Text.Trim) Then MessageBox.Show("This expense head already in the list, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_ExpenseMaster.Focus() : Exit Sub

            Call Add_Patient_BillGrid()

            hms_helper = New Hms_Helperimpliments
            With Dgv_ChargesGrid


                .Rows.Add()
                .Rows(.Rows.Count - 1).Cells("Expense").Value = Txt_ExpenseDetails.Text.Trim
                .Rows(.Rows.Count - 1).Cells("Amount").Value = Val(Txt_Charge.Text)
                .Rows(.Rows.Count - 1).Cells("Exp_ID").Value = Txt_ExpenseMaster.Tag

                Dgv_ChargesGrid.Rows(.Rows.Count - 1).Cells("Amount").Style.Alignment = DataGridViewContentAlignment.MiddleRight

            End With
            Dgv_ChargesGrid.Columns("Expense").SortMode = DataGridViewColumnSortMode.NotSortable
            Dgv_ChargesGrid.Columns("Amount").SortMode = DataGridViewColumnSortMode.NotSortable
            Dgv_ChargesGrid.Columns("Amount").HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight
            'clear Tran grid values
            Call Clear_Trangrid()
            'Txt_Remarks.Focus()
            Txt_ExpenseMaster.Text = ""
            Txt_ExpenseMaster.Focus()
        Catch ex As Exception

        End Try
    End Sub

    Private Function Is_Duplicate(ByVal Exp_Name As String) As Boolean
        Try
            With Dgv_ChargesGrid

                For i = 0 To .Rows.Count - 1

                    If .Rows(i).Cells("Expense").Value = Exp_Name Then

                        Return False
                    End If

                Next

            End With
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Try
            Me.Close()
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Dgv_ChargesGrid_CellValueChanged(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgv_ChargesGrid.CellValueChanged
        Try
            If e.ColumnIndex = Dgv_ChargesGrid.Columns("Amount").Index Then
                Call Total_BillAmt()
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Lbl_TotalAmount_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Lbl_TotalAmount.TextChanged
        Try
            Lbl_Words.Text = ""
            If Val(Lbl_TotalAmount.Text) = 0 Then Exit Sub
            Lbl_Words.Text = Towords(Val(Lbl_TotalAmount.Text))
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_OutPatientID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_OutPatientID.TextChanged
        Try
            If Txt_OutPatientID.Text.Trim = "" Then Call Clear_Values() : Txt_OutPatientID.Focus()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try
            Patient_Tran_BL = New Patient_Transaction_BL_Cls

            If Not Validate_Fields() Then Exit Sub

            Dim Tran_BatchID As String = ""
            If Save_Patient_Tran(Tran_BatchID) Then
                MessageBox.Show("Patient Transaction  Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                If Tran_BatchID <> "" Then
                    Patient_Tran_BL.Del_Patient_Transaction(Tran_BatchID, Tran_Date, Txt_PatientID.Text.Trim, Branch_Code)
                End If

                MessageBox.Show("Patient Transaction  Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
            Call Clear_Form()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try
            Call Clear_Form()
            Call Disable_Controls()
        Catch ex As Exception

        End Try
    End Sub

    Public Sub Btn_FindBatch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try
            If Tr_Mode = Tran_Mode.New_Mode Then
                If Txt_BatchID.Text.Trim = "" Then
                    Call Clear_Form()
                    Dim Sql As String
                    Dim Colwidth As String = ""
                    Colwidth = "10|50|50|50|50"
                    Sql = "SELECT *  FROM         dbo.Patient_Transaction_Batch_Vw where Tr_Date ='" & Format(Tran_Date, "MM/dd/yyyy") & "' and Bill_Gen='N' and Cancelled='N' and Br_Code = " & Branch_Code & " "
                    Call ShowSearchengine(Txt_BatchID, Sql, 0, "Patient Name", Colwidth, , 0)
                End If
            End If

            If Txt_BatchID.Text.Trim = "" Then
                Txt_BatchID.Focus() : Exit Sub
            End If

            If Locate_Values(Txt_BatchID.Text.Trim) Then
                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Cancel.Enabled = True
                Btn_Add.Enabled = False
            End If
            Call Disable_Controls()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Cleargrid_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Cleargrid.Click
        Try
            With Dgv_ChargesGrid
                .Rows.RemoveAt(.CurrentRow.Index)
            End With
            Call Clear_Trangrid()
            Txt_ExpenseMaster.Focus()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Cancel.Click
        Try
            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If

            If Patient_Tran_BL.Get_Patient_Transaction(Dtbl, Txt_BatchID.Text.Trim, Branch_Code) Then
                If Dtbl.Rows(0).Item("Bill_Gen") = "Y" Then
                    MessageBox.Show("Bill already generated, Cancell this bill through Bill Payment Uttility", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Exit Sub
                End If
            End If

            If MessageBox.Show("Cancel the entry ..(Y/N) ?", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then

                If Patient_Tran_BL.Cancel_Patient_Transaction(Txt_BatchID.Text.Trim, Tran_Date, Branch_Code) Then
                    If Dtbl.Rows(0).Item(0).ToString = "0" Then MessageBox.Show("Cancellation failed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Exit Sub
                    MessageBox.Show("Patient Transaction  Cancelled", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
                Call Clear_Form()
                Call Disable_Controls()
            Else
                Btn_Clear.Focus()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_BatchID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_BatchID.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then Txt_OutPatientID.Focus()
            If e.KeyCode = Keys.F2 Then Btn_FindBatch_Click(sender, e)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Remarks_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Txt_Remarks.GotFocus
        Try
            Lst_Search.Visible = False
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Remarks_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Remarks.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then Btn_Save.Focus()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Tvw_ExpenseList_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Tvw_ExpenseList.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then Btn_Add.Focus()
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Btn_Add_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Btn_Add.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then
                Txt_Remarks.Focus()
            End If
            If e.KeyCode = Keys.F2 Then Btn_FindBatch_Click(sender, e)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_ExpID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_ExpID.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then
                If Txt_ExpID.Text.Trim = "" Then
                    MessageBox.Show("Enter Valid Expense ID, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Txt_ExpID.Focus()
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_ExpID_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_ExpID.KeyUp
        Try
            Txt_ExpenseMaster.Text = ""
            Call Clear_Trangrid()
            If Get_ExpenseItemUsingID(Txt_ExpID.Text.Trim) Then
                Lst_Search.Visible = False
                Tvw_ExpenseList.SelectedNode.EnsureVisible()
                'Tvw_ExpenseList.Select()
                Txt_ExpID.Select(Len(Txt_ExpID.Text), 0)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_PatientID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_PatientID.KeyDown
        Try

       
            If e.KeyCode = Keys.F2 Then Btn_FindPatientID_Click(sender, e)

            If e.KeyCode = Keys.Enter Then


                If Locate_Patient(Txt_PatientID.Text.Trim) Then

                    Txt_ExpenseMaster.Focus()

                Else

                    MessageBox.Show("Invalid Patient ID, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)

                End If



            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_PatientID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_PatientID.TextChanged
        Try
            If Txt_PatientID.Text.Trim = "" Then Call Clear_Values() : Txt_PatientID.Focus()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_FindPatientID_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_FindPatientID.Click
        Try

            If Txt_PatientID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "10|200|50|"
                Sql = "SELECT     [Patient ID], [Patient Name], Doctor, Service, OPD_ID FROM   OPD_Master_Vw"
                Call ShowSearchengine(Txt_OutPatientID, Sql, 4, "Name", Colwidth, , 0)

                If Txt_OutPatientID.Text.Trim = "" Then
                    Txt_PatientID.Focus() : Exit Sub
                End If

                If Locate_Outpatient(Txt_OutPatientID.Text.Trim) Then
                    Txt_ExpenseMaster.Focus()
                Else
                    MessageBox.Show("Patient ID not found, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Txt_PatientID.Focus()
                End If

                Txt_ExpenseMaster.Focus()
            Else

                Dim dtbl As DataTable = Nothing

                hms_helper = New Hms_Helperimpliments
                If hms_helper.Get_OutPatient_Info_Latest(dtbl, Txt_PatientID.Text.Trim, Tran_Date, Branch_Code) Then
                    Txt_OutPatientID.Text = dtbl.Rows(0).Item("OPD_ID").ToString
                    If Locate_Outpatient(Txt_OutPatientID.Text.Trim) Then
                        Txt_ExpenseMaster.Focus()
                    Else
                        MessageBox.Show("Patient ID not found, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                        Txt_PatientID.Focus()
                    End If
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Uttility_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try
            Show_ChildForm("Patient_Transaction_Uttility_Frm", Me.MdiParent, Me.Tag)
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Btn_Report_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try
            If Txt_OutPatientID.Text.Trim <> "" Then
                Call Show_Reciept(Txt_OutPatientID.Text.Trim, Tran_Date, Tran_Date, "")
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Showtran_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Showtran.Click
        Try
            Pnl_History.Location = New System.Drawing.Point(282, 6)
            Pnl_History.Visible = True

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_CloseHistory_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_CloseHistory.Click
        Try
            Pnl_History.Visible = False
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_ShowHistory_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_ShowHistory.Click
        Try

            If Txt_OutPatientID.Text.Trim <> "" Then
                If Strings.Left(Cmb_PayStatus.Text, 1) = "A" Then
                    Call Show_Reciept(Txt_OutPatientID.Text.Trim, Dtp_FrmDate.Value, Dtp_ToDate.Value, "")
                Else
                    Call Show_Reciept(Txt_OutPatientID.Text.Trim, Dtp_FrmDate.Value, Dtp_ToDate.Value, " And [Bill_Status]='" & Strings.Left(Cmb_PayStatus.Text, 1).Trim & "'")
                End If

            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Pct_UPDown.Click
        Try

            Call Show_CrediPosition()

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_OutPatientID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_OutPatientID.Validating
        Try
            If Me.Txt_OutPatientID.Text.Trim <> "" And Me.Txt_OutPatientID.Text <> Me.Txt_OutPatientID.Tag Then
                If Locate_Outpatient(Txt_OutPatientID.Text) Then
                    Tr_Mode = Tran_Mode.Edit_Mode
                    Btn_Cancel.Enabled = True

                Else
                    MessageBox.Show("Invalid OP ID ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Txt_OutPatientID.Focus()
                    e.Cancel = True
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_PatientID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_PatientID.Validating
        Try
            If Txt_PatientID.Text.Trim <> "" Then
                If Locate_Patient(Txt_PatientID.Text.Trim) Then
                    Txt_ExpenseMaster.Focus()
                    Exit Sub
                Else
                    MessageBox.Show("Invalid Patient ID", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Txt_PatientID.Text = ""
                    e.Cancel = True
                    Exit Sub
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Public Sub Btn_PMRFind_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_PMRFind.Click
        Try
            If Txt_PMRID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "200|50|300|70|"
                Sql = "SELECT [Patient Name], [S.S.No], ([Family Name] + Address + City) as Address, ACC_ID AS [PMR-ID]"
                Sql += "FROM Patient_Account_Vw WHERE ([Account Status] = 'Active') and Br_code='" & Branch_Code & "'"

                Call ShowSearchengine(Txt_PMRID, Sql, 3, "[Patient Name]", Colwidth, , 0)
            End If

            'Validating Mandatory fields for locating
            If Txt_PMRID.Text.Trim = "" Then
                'MessageBox.Show("Invalid Appointment ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_PMRID.Focus() : Exit Sub
            End If

            If Locate_PMR_info(Txt_PMRID.Text.Trim, Branch_Code) Then

                Dtbl = Nothing
                If hms_helper.Get_OutPatient_Doctor(Dtbl, Txt_PMRID.Text.Trim, Branch_Code) Then
                    Lbl_Doctor.Text = Dtbl.Rows(0).Item("Name").ToString & vbCrLf & Dtbl.Rows(0).Item("category").ToString
                End If

                Txt_ExpenseMaster.Focus()
            Else
                MessageBox.Show("Invalid PMR ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_PMRID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_PMRID.KeyDown
        Try

            If e.KeyCode = Keys.F2 Then Btn_PMRFind_Click(Nothing, Nothing)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_PMRID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_PMRID.TextChanged
        Try
            If Txt_PMRID.Text.Trim = "" Then Call Clear_Form()
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Label12_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles Label12.MouseEnter
        Try
            Call Show_CrediPosition()
        Catch ex As Exception

        End Try
    End Sub

  
End Class