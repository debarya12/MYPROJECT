﻿
Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls

Public Class Bank_Accounts_Tran_Frm

#Region "Declarations"
    'Object of Employee Details Bussiness Layer

    Private hms_helper As HMS_Helper = Nothing
    Private Bank_Master_BL As Bank_Master_BL_Cls
    Private Bank_Acc_Reg_BL As Bank_Account_Register_BL_Cls
    Private Bank_Acc_tran_BL As BankAccount_BL_Cls
    Private mTr_Mode As Tran_Mode

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing
    Private IsHandleAdded As Boolean

    Private CellRowindex As Integer
    Private CellColindex As Integer
    Private GridViewMode As Integer = 0

    Private mRpt_Vwr As ReportViewer_Cls
    Private Rpt_BL As HMS_BL.Reports_BL_Cls

    Private GrDtbl As DataTable

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_TranID.BackColor = Color.White
                    Me.Txt_TranID.ReadOnly = False
                    Cmb_Bank_Name.Enabled = True


                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_TranID.BackColor = Color.Silver
                    Me.Txt_TranID.ReadOnly = True
                    Cmb_Bank_Name.Enabled = False

            End Select
        End Set
    End Property

#End Region

#Region "Methods"

    Private Sub Clear_Form()
        Try

            Txt_TranID.Text = ""
            Txt_BankAddress.Text = ""

            Txt_Amount.Text = ""
            Txt_Remarks.Text = ""
            Txt_Balance.Text = ""
            Txt_TransactionBalance.Text = ""

            Cmb_Bank_Name.SelectedIndex = 0
            Cmb_TranType.SelectedIndex = 0
            Cmb_Payment_Mode.SelectedIndex = 0
            Cmb_Account_Type.SelectedIndex = 0
            Cmb_AccNo.DataSource = Nothing
            Lbl_GridName.Text = "B a n k   A c c o u n t   M a s t e r"
            Cmb_AccNo.Enabled = False

            Tr_Mode = Tran_Mode.New_Mode
            Btn_Save.Enabled = True
            Btn_Delete.Enabled = False

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Function Populate_Accno(ByRef Acno_Dtbl As DataTable, ByRef Cmb As ComboBox) As Boolean

        Try
            Dim Dtbl As New DataTable
            Dim Dr As DataRow = Nothing

            With Dtbl
                .Columns.Add("Acc_no")
                .Columns.Add("BankAcc_ID")
            End With

            Dim i_Ctr As Int16 = 0
            With Acno_Dtbl
                Dr = Dtbl.NewRow
                Dr("Acc_no") = " < S E L E C T > "
                Dr("BankAcc_ID") = "0"
                Dtbl.Rows.Add(Dr)


                For i_Ctr = 0 To Acno_Dtbl.Rows.Count - 1
                    Dr = Dtbl.NewRow
                    Dr("Acc_no") = .Rows(i_Ctr).Item("Acc_no").ToString
                    Dr("BankAcc_ID") = .Rows(i_Ctr).Item("BankAcc_ID").ToString
                    Dtbl.Rows.Add(Dr)
                Next
            End With

            If Dtbl.Rows.Count > 1 Then
                With Cmb
                    .DataSource = Nothing
                    .DataSource = Dtbl
                    .DisplayMember = "Acc_no"
                    .ValueMember = "BankAcc_ID"
                    .SelectedIndex = 0
                End With
            End If

            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Locate_Values(ByVal Tran_ID As Integer) As Boolean
        Try
            Me.Tr_Mode = Tran_Mode.Edit_Mode
            Dim dtbl As DataTable = Nothing
            Bank_Acc_tran_BL = New BankAccount_BL_Cls

            If Bank_Acc_tran_BL.Get_Bank_Account_Tran(dtbl, Tran_ID, Branch_Code) Then

                GridViewMode = 1
                Cmb_Bank_Name.SelectedValue = dtbl.Rows(0).Item("Bank_ID").ToString
                Cmb_TranType.SelectedIndex = IIf(dtbl.Rows(0).Item("tr_Type").ToString = "R", 1, 2)
                Cmb_Payment_Mode.SelectedValue = dtbl.Rows(0).Item("Tr_Pay_Mode").ToString.Trim
                Txt_Remarks.Text = dtbl.Rows(0).Item("Tr_Remarks").ToString
                Cmb_Account_Type.SelectedValue = dtbl.Rows(0).Item("Acc_Type").ToString
                Cmb_AccNo.SelectedValue = dtbl.Rows(0).Item("BankAcc_ID").ToString
                Call Arrive_Transaction_Bal_Anydate(dtbl.Rows(0).Item("Balance").ToString, _
                                                    dtbl.Rows(0).Item("tr_Type").ToString, _
                                                     dtbl.Rows(0).Item("Amount").ToString)
                Txt_Amount.Text = dtbl.Rows(0).Item("Amount").ToString


            End If

            Return True
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function

    Private Function Validate_Fields() As Boolean
        Try
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If

            If Tr_Mode <> Tran_Mode.New_Mode Then
                If Txt_TranID.Text.Trim = "" Then MessageBox.Show("Invalid Transaction ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_TranID.Focus() : Return False
            End If
            'Assigning Default values
            If Cmb_Bank_Name.SelectedIndex = 0 Then MessageBox.Show("Invalid Bank Name, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_Bank_Name.Focus() : Return False
            If Cmb_Account_Type.SelectedIndex = 0 Then MessageBox.Show("Invalid Account Type, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_Account_Type.Focus() : Return False
            If Cmb_AccNo.SelectedIndex = 0 Then MessageBox.Show("Account Number not Selected, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_AccNo.Focus() : Return False
            If Cmb_TranType.SelectedIndex = 0 Then MessageBox.Show("Invalid Transaction Type, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_TranType.Focus() : Return False
            If Cmb_Payment_Mode.SelectedIndex = 0 Then MessageBox.Show("Invalid Mode of Payment, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_Payment_Mode.Focus() : Return False
            If Val(Txt_Amount.Text) <= 0 Then MessageBox.Show("Invalid Transaction Amount, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Amount.Focus() : Return False


            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Sub Fill_BankAcc_Grid()
        Try
            Dim dtbl As DataTable
            Bank_Acc_Reg_BL = New Bank_Account_Register_BL_Cls
            Dtbl = Nothing
            If Bank_Acc_Reg_BL.Get_Bank_Account_Register_All(dtbl, Branch_Code) Then
                Dgvw_Bank_Account_Master.DataSource = Nothing
                Dgvw_Bank_Account_Master.DataSource = dtbl
                Dgvw_Bank_Account_Master.Columns(0).Width = 200
                Dgvw_Bank_Account_Master.Columns(1).Width = 150
                Dgvw_Bank_Account_Master.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                Dgvw_Bank_Account_Master.Refresh()
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Public Sub Fill_BankAcc_Tran_Grid()
        Try

            Bank_Acc_tran_BL = New BankAccount_BL_Cls
            Dtbl = Nothing
            If Bank_Acc_tran_BL.Get_Bank_Account_Transaction(Dtbl, Cmb_AccNo.SelectedValue, Cmb_AccNo.Text, Branch_Code) Then
                Dgvw_Bank_Account_Master.DataSource = Dtbl
                Dgvw_Bank_Account_Master.Columns(2).Width = 150
                Dgvw_Bank_Account_Master.Columns(3).Width = 150
                Dgvw_Bank_Account_Master.Columns(4).Width = 150
                Dgvw_Bank_Account_Master.Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                Dgvw_Bank_Account_Master.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                Dgvw_Bank_Account_Master.Columns(5).Visible = False
                Dgvw_Bank_Account_Master.Refresh()
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    REM getting Current Opening Balance of the Account
    Public Function Get_BankAcc_Balance(ByVal Bank_ID As String, _
                                        ByVal Acc_No As String) As Double
        Try
            Dim dtbl As DataTable = Nothing
            Bank_Acc_tran_BL = New BankAccount_BL_Cls

            If Bank_Acc_tran_BL.Get_Bank_Account_Balance(dtbl, Bank_ID, Acc_No, Branch_Code) Then
                Return dtbl.Rows(0).Item(0).ToString
            Else
                Return 0
            End If

        Catch ex As Exception
            Return 0
        End Try
    End Function

    Private Sub Arrive_Transaction_Bal()
        Try

            If Strings.Left(Cmb_TranType.Text, 1).Trim.ToUpper = "R" Then _
            Txt_TransactionBalance.Text = Val(Txt_Balance.Text) + Val(Txt_Amount.Text)

            If Strings.Left(Cmb_TranType.Text, 1).Trim.ToUpper = "P" Then _
           Txt_TransactionBalance.Text = Val(Txt_Balance.Text) - Val(Txt_Amount.Text)
            Txt_TransactionBalance.Text = Format(Val(Txt_TransactionBalance.Text), "00.00")

        Catch ex As Exception

        End Try
    End Sub
    Private Sub Arrive_Transaction_Bal_Anydate(ByVal CurrentBal As Double, _
                                               ByVal Tran_Type As Char, _
                                               ByVal Tran_Amount As Double)
        Try
            CurrentBal = Format(CurrentBal, "00.00")
            Tran_Amount = Format(Tran_Amount, "00.00")

            If Tran_Type.ToString.ToUpper = "R" Then _
            Txt_Balance.Text = CurrentBal - Tran_Amount

            If Tran_Type.ToString.ToUpper = "P" Then _
            Txt_Balance.Text = CurrentBal + Tran_Amount


        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Function Show_Reciept(ByVal Acc_NO As String, ByVal BankAcc_ID As String) As Boolean
        Try
            If Cmb_AccNo.SelectedIndex = 0 Then MessageBox.Show("Invalid  Account Number.. Please Select a Account Number", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_AccNo.Focus() : Exit Function

            Dim Rpt_Ds As DataSet = Nothing
            Dim Rpt_Formulafields As String = "Company| " & Company_Name & "|Branch|" & Branch_Name
            Dim Rpt_Filename As String = ""
            Dim mReport_ID As String = ""
            Dim Report_Heading As String = ""
            Dim Add_Query As String = ""

            mRpt_Vwr = New ReportViewer_Cls

            Bank_Acc_tran_BL = New BankAccount_BL_Cls
            Add_Query = ""
            Add_Query = "Where [BankAcc_ID] = '" & BankAcc_ID & "'  and  [Acc No]='" & Acc_NO & "' and  Br_Code='" & Branch_Code & "'"
            Rpt_Filename = File_Path & "\Bank_Account_Ledger.rpt"

            If Bank_Acc_tran_BL.Get_Bank_Account_Transaction_All(Rpt_Ds, Add_Query) Then
                Report_Heading = "|Heading| B a n k   A c c o u n t   T r a n s a c t i o n   L e d g e r|Footer3|Authorised Signatory"
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading & ")"
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "")
            Else
                MessageBox.Show("Invalid Tran ID, Please enter Tran ID", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Txt_TranID.Focus()
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function
    Private Sub Get_Account_Details(ByRef Bank_ID As String, _
                                    ByRef Acc_Type As String, _
                                    ByRef BankAcc_ID As String)
        Try
            With Dgvw_Bank_Account_Master

                Bank_ID = .Item(8, .CurrentCell.RowIndex).Value.ToString.Trim
                Acc_Type = .Item(9, .CurrentCell.RowIndex).Value.ToString.Trim
                BankAcc_ID = .Item(6, .CurrentCell.RowIndex).Value.ToString.Trim

            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

#End Region

    Private Sub Bank_Accounts_Reg_Frm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try

            Bank_Master_BL = New Bank_Master_BL_Cls

            hms_helper = New Hms_Helperimpliments
            Call hms_helper.Fill_GenData(Cmb_Payment_Mode, Gendatatype.Payment_Mode, "< Select >")
            Call hms_helper.Fill_Investment_Banks(Cmb_Bank_Name, "< Select >")
            Call hms_helper.Fill_GenData(Cmb_Account_Type, Gendatatype.BankAccount_Type, "< Select >")

            With Cmb_TranType
                .Items.Add("< Select >")
                .Items.Add("Reciept")
                .Items.Add("Payment")
            End With

            Cmb_TranType.SelectedIndex = 0

            Call Fill_BankAcc_Grid()

            Txt_TranID.Focus()
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub DoctorMaster_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then Call SendKeyTab()
    End Sub

    Private Sub DoctorMaster_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try

            'Validating Data controls
            If Not Validate_Fields() Then Exit Sub

            Bank_Acc_tran_BL = New BankAccount_BL_Cls
            Bank_Acc_tran_BL.Tran_ID = Val(Txt_TranID.Text)
            Bank_Acc_tran_BL.BankAcc_ID = Cmb_AccNo.SelectedValue
            Bank_Acc_tran_BL.Acc_Code = "10"
            Bank_Acc_tran_BL.Acc_Category = "10"
            Bank_Acc_tran_BL.Acc_No = Cmb_AccNo.Text
            Bank_Acc_tran_BL.Tr_Amount = Val(Txt_Amount.Text)
            Bank_Acc_tran_BL.Tr_Date = Tran_Date
            Bank_Acc_tran_BL.Tr_Pay_Mode = Cmb_Payment_Mode.SelectedValue
            Bank_Acc_tran_BL.Tr_Type = Strings.Left(Cmb_TranType.Text, 1).ToUpper
            Bank_Acc_tran_BL.Tr_Remarks = Txt_Remarks.Text
            Bank_Acc_tran_BL.Tr_RefNo = ""
            Bank_Acc_tran_BL.Cancelled = "N"
            Bank_Acc_tran_BL.C_User = UEmp_ID
            Bank_Acc_tran_BL.C_Time = Tran_Date
            Bank_Acc_tran_BL.Tran_BatchID = " "


            If Bank_Acc_tran_BL.Save_BankAccountTran(Dtbl, Tr_Mode) Then
                If Dtbl.Rows(0).Item(0).ToString = "0" Then
                    MessageBox.Show("Bank Account Transaction Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Exit Sub
                End If
                Txt_TranID.Text = Dtbl.Rows(0).Item("Tran_ID").ToString
                Tr_Mode = Tran_Mode.Edit_Mode
                MessageBox.Show("Bank Account Transaction Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Btn_Clear.Focus()
                Call Fill_BankAcc_Tran_Grid()
            Else
                MessageBox.Show("Bank Account Transaction Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Exit Sub
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_EmpID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try

            If Txt_TranID.Text.Trim = "" Then
                Call Clear_Form()
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try
            If Txt_TranID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "100|100|100|"
                Sql = "SELECT     [Sur Name],[Acc No] ,Tr_Date, [Tran Type], Amount, Balance, "
                Sql = Sql + "[Payment Mode],[Tran_ID] FROM Bank_Account_Transaction_Vw  "
                Sql = Sql + "where Tr_date= '" & Format(Tran_Date, "MM/dd/yyyy") & "' and  Br_Code ='" & Branch_Code & "'"

                Call ShowSearchengine(Txt_TranID, Sql, 7, "Bank Name", Colwidth, , 0)
            End If

            'Validating Mandatory fields for locating
            If Txt_TranID.Text.Trim = "" Then
                'MessageBox.Show("Invalid Transaction ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_TranID.Focus() : Exit Sub
            End If

            If Locate_Values(Txt_TranID.Text.Trim) Then
                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Delete.Enabled = True
            Else
                MessageBox.Show("Account Number does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try
            Call Clear_Form()
            Txt_TranID.Focus()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

    Private Sub Dgvw_Emp_AccountMaster_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Dgvw_Bank_Account_Master.DoubleClick
        Try
            With Dgvw_Bank_Account_Master
                If GridViewMode = 0 Then

                    Dim Bank_ID As String = ""
                    Dim Acc_Type As String = ""
                    Dim BankAcc_ID As String = ""


                    If .CurrentRow Is Nothing Then Exit Sub
                    Call Get_Account_Details(Bank_ID, Acc_Type, BankAcc_ID)
                    Cmb_Bank_Name.SelectedValue = Bank_ID
                    Cmb_Account_Type.SelectedValue = Acc_Type
                    Cmb_AccNo.SelectedValue = BankAcc_ID
                    Cmb_TranType.Focus()

                Else
                    Txt_TranID.Text = .Item(6, .CurrentCell.RowIndex).Value.ToString.Trim
                    If Locate_Values(.Item(6, .CurrentCell.RowIndex).Value.ToString.Trim) Then
                        Btn_Delete.Enabled = True
                    End If
                End If
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click
        Try
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If


            'Validating Mandatory fields for Deleting
            If Tr_Mode = Tran_Mode.New_Mode Then
                MessageBox.Show("You have to locate details before deleting the record", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            If Txt_TranID.Text.Trim = "" Then
                MessageBox.Show("Invalid Tran ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_TranID.Focus() : Exit Sub
            End If

            If Txt_Amount.Text.Trim <= 0 Then
                MessageBox.Show("Transaction already Cancelled, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_TranID.Focus() : Exit Sub
            End If


            'Confirm before delete the record
            If MessageBox.Show("Are you sure want to delete the Selected Transaction", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = Windows.Forms.DialogResult.No Then
                Exit Sub
            End If

            'Declarations
            Bank_Acc_tran_BL = New BankAccount_BL_Cls
            Dim dtbl As DataTable = Nothing

            Bank_Acc_tran_BL.C_User = User_ID

            If Bank_Acc_tran_BL.Cancel_Bank_Acc_Transaction(dtbl, Txt_TranID.Text.Trim, _
                                                            Tran_Date) Then
                If dtbl.Rows(0).Item(0).ToString = "0" Then
                    MessageBox.Show("You cannot Cancel this transaction" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
                MessageBox.Show("Transaction Cancelled", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Call Btn_Clear_Click(sender, e)
                Call Fill_BankAcc_Grid()
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Cmb_Bank_Name_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_Bank_Name.SelectedIndexChanged
        Try
            If Cmb_Bank_Name.SelectedIndex = 0 Then Txt_BankAddress.Text = "" : Cmb_Account_Type.SelectedIndex = 0 : Cmb_Account_Type.Enabled = False
            Cmb_Account_Type.Enabled = True
            Bank_Master_BL = New Bank_Master_BL_Cls
            Dim dtbl As DataTable = Nothing

            If Bank_Master_BL.Get_Bank_Master(dtbl, Cmb_Bank_Name.SelectedValue) Then
                Txt_BankAddress.Text = dtbl.Rows(0).Item("Bank_Name").ToString
                Txt_BankAddress.Text += vbCrLf + dtbl.Rows(0).Item("Branch_Name").ToString + " Branch "
                Txt_BankAddress.Text += vbCrLf + dtbl.Rows(0).Item("Address").ToString
            End If

            Cmb_Account_Type.SelectedIndex = 0
            Cmb_AccNo.SelectedIndex = 0
            Cmb_TranType.SelectedIndex = 0
            Cmb_Payment_Mode.SelectedIndex = 0
            Txt_Amount.Text = ""
            Txt_Remarks.Text = ""
            Cmb_Account_Type.Focus()

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Cmb_AccNo_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_AccNo.SelectedIndexChanged
        Try

            If Cmb_AccNo.SelectedIndex > 0 Then
                Lbl_GridName.Text = "T r a n s a c t i o n   D e t a i l s"
                Call Fill_BankAcc_Tran_Grid()

                Txt_Balance.Text = Get_BankAcc_Balance(Cmb_Bank_Name.SelectedValue, Cmb_AccNo.Text)
                Txt_TransactionBalance.Text = Txt_Balance.Text
                GridViewMode = 1
            End If

            If Cmb_AccNo.SelectedIndex = 0 Then
                Lbl_GridName.Text = "B a n k   A c c o u n t   M a s t e r"
                Call Fill_BankAcc_Grid()
                Txt_Balance.Text = 0
                Txt_TransactionBalance.Text = 0
                GridViewMode = 0
            End If


        Catch ex As Exception

        End Try
    End Sub

        Private Sub Cmb_Account_Type_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_Account_Type.SelectedIndexChanged
        Try

            Dim dtbl As DataTable = Nothing
            Bank_Acc_tran_BL = New BankAccount_BL_Cls

            If Bank_Acc_tran_BL.Get_bankAccount_Numbers(Dtbl, Cmb_Bank_Name.SelectedValue, Cmb_Account_Type.SelectedValue, Branch_Code) Then

                Call Populate_Accno(Dtbl, Cmb_AccNo)
                Cmb_AccNo.Enabled = True
            Else
                Cmb_AccNo.Enabled = False
                Call Fill_BankAcc_Grid()
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Amount_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Amount.TextChanged
        Try

            Txt_TransactionBalance.Text = 0
            Lbl_Words.Text = Towords(Val(Txt_Amount.Text))
            Call Arrive_Transaction_Bal()

        Catch ex As Exception

        End Try
    End Sub
    Private Sub Cmb_TranType_SelectedIndexChanged(ByVal sender As System.Object, _
                                                  ByVal e As System.EventArgs) Handles Cmb_TranType.SelectedIndexChanged
        Try
            Call Arrive_Transaction_Bal()
        Catch ex As Exception

        End Try

    End Sub
    Private Sub Btn_Ledger_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Ledger.Click
        Try
            Call Show_Reciept(Cmb_AccNo.Text, Cmb_AccNo.SelectedValue)
        Catch ex As Exception

        End Try
    End Sub

End Class
