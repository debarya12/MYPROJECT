﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Expense_Charge_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Expense_Charge_Frm))
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.DGvw_Gendatacategory = New System.Windows.Forms.DataGridView
        Me.DGvw_Gendata = New System.Windows.Forms.DataGridView
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.Btn_Movedown = New System.Windows.Forms.Button
        Me.Btn_Moveup = New System.Windows.Forms.Button
        Me.Label8 = New System.Windows.Forms.Label
        Me.Lbl_Seldatacategory = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Lst_Gendata = New System.Windows.Forms.ListBox
        Me.Btn_Saveorder = New System.Windows.Forms.Button
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Btn_Removeitem = New System.Windows.Forms.Button
        Me.Dgv_Chargesettings = New REAL_CLINIC.Hms_DGridview(Me.components)
        Me.Acc_Name = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Particulars = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Type = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Percentage = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Charge = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Acc_Code = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Exp_Subtype = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.PercentageID = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Btn_GridUp = New System.Windows.Forms.Button
        Me.Btn_GridDown = New System.Windows.Forms.Button
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.Cmb_AccountHead = New System.Windows.Forms.ComboBox
        Me.Txt_particulars = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Btn_Add = New System.Windows.Forms.Button
        Me.Cmb_Type = New System.Windows.Forms.ComboBox
        Me.Txt_Charge = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Cmb_Percentageof = New System.Windows.Forms.ComboBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Dtp_TranDate = New System.Windows.Forms.DateTimePicker
        Me.Txt_ExpenseHead = New System.Windows.Forms.TextBox
        Me.Txt_ExpenseID = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Pnl_Header.SuspendLayout()
        CType(Me.DGvw_Gendatacategory, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DGvw_Gendata, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.Dgv_Chargesettings, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Menu_Bkg
        Me.Pnl_Header.Controls.Add(Me.Label1)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(805, 24)
        Me.Pnl_Header.TabIndex = 1000000
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(7, 1)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(280, 18)
        Me.Label1.TabIndex = 10000
        Me.Label1.Text = "E x p e n s e   C h a r g e   S e t t i n g s"
        '
        'DGvw_Gendatacategory
        '
        Me.DGvw_Gendatacategory.AllowUserToAddRows = False
        Me.DGvw_Gendatacategory.AllowUserToDeleteRows = False
        Me.DGvw_Gendatacategory.AllowUserToOrderColumns = True
        Me.DGvw_Gendatacategory.AllowUserToResizeColumns = False
        Me.DGvw_Gendatacategory.AllowUserToResizeRows = False
        Me.DGvw_Gendatacategory.BackgroundColor = System.Drawing.Color.SteelBlue
        Me.DGvw_Gendatacategory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGvw_Gendatacategory.ColumnHeadersVisible = False
        Me.DGvw_Gendatacategory.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.DGvw_Gendatacategory.GridColor = System.Drawing.Color.Silver
        Me.DGvw_Gendatacategory.Location = New System.Drawing.Point(3, 45)
        Me.DGvw_Gendatacategory.MultiSelect = False
        Me.DGvw_Gendatacategory.Name = "DGvw_Gendatacategory"
        Me.DGvw_Gendatacategory.RowHeadersVisible = False
        Me.DGvw_Gendatacategory.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.DGvw_Gendatacategory.RowsDefaultCellStyle = DataGridViewCellStyle1
        Me.DGvw_Gendatacategory.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.DGvw_Gendatacategory.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DGvw_Gendatacategory.Size = New System.Drawing.Size(338, 198)
        Me.DGvw_Gendatacategory.StandardTab = True
        Me.DGvw_Gendatacategory.TabIndex = 0
        Me.DGvw_Gendatacategory.TabStop = False
        '
        'DGvw_Gendata
        '
        Me.DGvw_Gendata.BackgroundColor = System.Drawing.Color.SlateGray
        Me.DGvw_Gendata.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGvw_Gendata.Location = New System.Drawing.Point(375, 68)
        Me.DGvw_Gendata.Name = "DGvw_Gendata"
        Me.DGvw_Gendata.Size = New System.Drawing.Size(334, 108)
        Me.DGvw_Gendata.TabIndex = 17
        Me.DGvw_Gendata.TabStop = False
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(571, 492)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(175, 36)
        Me.Pnl_Common_Btn.TabIndex = 21
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(59, 3)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear.TabIndex = 8
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(115, 3)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 9
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(3, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save.TabIndex = 7
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Btn_Movedown
        '
        Me.Btn_Movedown.BackColor = System.Drawing.Color.Transparent
        Me.Btn_Movedown.BackgroundImage = CType(resources.GetObject("Btn_Movedown.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Movedown.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Movedown.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Btn_Movedown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Movedown.Location = New System.Drawing.Point(763, 75)
        Me.Btn_Movedown.Name = "Btn_Movedown"
        Me.Btn_Movedown.Size = New System.Drawing.Size(29, 39)
        Me.Btn_Movedown.TabIndex = 18
        Me.Btn_Movedown.TabStop = False
        Me.Btn_Movedown.UseVisualStyleBackColor = False
        '
        'Btn_Moveup
        '
        Me.Btn_Moveup.BackColor = System.Drawing.Color.Transparent
        Me.Btn_Moveup.BackgroundImage = CType(resources.GetObject("Btn_Moveup.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Moveup.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Moveup.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Btn_Moveup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Moveup.Location = New System.Drawing.Point(763, 128)
        Me.Btn_Moveup.Name = "Btn_Moveup"
        Me.Btn_Moveup.Size = New System.Drawing.Size(29, 39)
        Me.Btn_Moveup.TabIndex = 19
        Me.Btn_Moveup.TabStop = False
        Me.Btn_Moveup.UseVisualStyleBackColor = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Navy
        Me.Label8.Location = New System.Drawing.Point(3, 29)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(104, 14)
        Me.Label8.TabIndex = 63
        Me.Label8.Text = "Expense Groups"
        '
        'Lbl_Seldatacategory
        '
        Me.Lbl_Seldatacategory.AutoSize = True
        Me.Lbl_Seldatacategory.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Seldatacategory.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Seldatacategory.ForeColor = System.Drawing.Color.Navy
        Me.Lbl_Seldatacategory.Location = New System.Drawing.Point(345, 27)
        Me.Lbl_Seldatacategory.Name = "Lbl_Seldatacategory"
        Me.Lbl_Seldatacategory.Size = New System.Drawing.Size(89, 14)
        Me.Lbl_Seldatacategory.TabIndex = 64
        Me.Lbl_Seldatacategory.Text = "Expenses List"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.SlateGray
        Me.Panel1.Controls.Add(Me.Lst_Gendata)
        Me.Panel1.Location = New System.Drawing.Point(344, 44)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(404, 199)
        Me.Panel1.TabIndex = 1
        '
        'Lst_Gendata
        '
        Me.Lst_Gendata.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Lst_Gendata.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lst_Gendata.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Lst_Gendata.FormattingEnabled = True
        Me.Lst_Gendata.ItemHeight = 16
        Me.Lst_Gendata.Location = New System.Drawing.Point(3, 3)
        Me.Lst_Gendata.Name = "Lst_Gendata"
        Me.Lst_Gendata.Size = New System.Drawing.Size(399, 194)
        Me.Lst_Gendata.TabIndex = 0
        Me.Lst_Gendata.TabStop = False
        '
        'Btn_Saveorder
        '
        Me.Btn_Saveorder.BackColor = System.Drawing.Color.Transparent
        Me.Btn_Saveorder.BackgroundImage = CType(resources.GetObject("Btn_Saveorder.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Saveorder.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Saveorder.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Btn_Saveorder.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Saveorder.Location = New System.Drawing.Point(762, 178)
        Me.Btn_Saveorder.Name = "Btn_Saveorder"
        Me.Btn_Saveorder.Size = New System.Drawing.Size(31, 35)
        Me.Btn_Saveorder.TabIndex = 20
        Me.Btn_Saveorder.TabStop = False
        Me.Btn_Saveorder.UseVisualStyleBackColor = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Transparent
        Me.Panel2.Controls.Add(Me.Btn_Removeitem)
        Me.Panel2.Controls.Add(Me.Dgv_Chargesettings)
        Me.Panel2.Controls.Add(Me.Btn_GridUp)
        Me.Panel2.Controls.Add(Me.Btn_GridDown)
        Me.Panel2.Controls.Add(Me.Panel3)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.Dtp_TranDate)
        Me.Panel2.Controls.Add(Me.Txt_ExpenseHead)
        Me.Panel2.Controls.Add(Me.Txt_ExpenseID)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel2.Location = New System.Drawing.Point(6, 251)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(799, 239)
        Me.Panel2.TabIndex = 65
        '
        'Btn_Removeitem
        '
        Me.Btn_Removeitem.BackColor = System.Drawing.Color.Transparent
        Me.Btn_Removeitem.BackgroundImage = CType(resources.GetObject("Btn_Removeitem.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Removeitem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Removeitem.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Btn_Removeitem.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Removeitem.Location = New System.Drawing.Point(759, 194)
        Me.Btn_Removeitem.Name = "Btn_Removeitem"
        Me.Btn_Removeitem.Size = New System.Drawing.Size(22, 30)
        Me.Btn_Removeitem.TabIndex = 127
        Me.Btn_Removeitem.UseVisualStyleBackColor = False
        '
        'Dgv_Chargesettings
        '
        Me.Dgv_Chargesettings.AllowUserToAddRows = False
        Me.Dgv_Chargesettings.AllowUserToDeleteRows = False
        Me.Dgv_Chargesettings.AllowUserToResizeColumns = False
        Me.Dgv_Chargesettings.AllowUserToResizeRows = False
        Me.Dgv_Chargesettings.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(118, Byte), Integer), CType(CType(155, Byte), Integer), CType(CType(197, Byte), Integer))
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(87, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(162, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.AliceBlue
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgv_Chargesettings.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.Dgv_Chargesettings.ColumnHeadersHeight = 20
        Me.Dgv_Chargesettings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.Dgv_Chargesettings.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Acc_Name, Me.Particulars, Me.Type, Me.Percentage, Me.Charge, Me.Acc_Code, Me.Exp_Subtype, Me.PercentageID})
        Me.Dgv_Chargesettings.Location = New System.Drawing.Point(2, 110)
        Me.Dgv_Chargesettings.Name = "Dgv_Chargesettings"
        Me.Dgv_Chargesettings.ReadOnly = True
        Me.Dgv_Chargesettings.RowHeadersVisible = False
        Me.Dgv_Chargesettings.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.Dgv_Chargesettings.Size = New System.Drawing.Size(738, 128)
        Me.Dgv_Chargesettings.TabIndex = 120
        Me.Dgv_Chargesettings.TabStop = False
        '
        'Acc_Name
        '
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(194, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Acc_Name.DefaultCellStyle = DataGridViewCellStyle3
        Me.Acc_Name.HeaderText = "General Ledger Head"
        Me.Acc_Name.Name = "Acc_Name"
        Me.Acc_Name.ReadOnly = True
        Me.Acc_Name.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Acc_Name.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Acc_Name.Width = 236
        '
        'Particulars
        '
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(248, Byte), Integer))
        Me.Particulars.DefaultCellStyle = DataGridViewCellStyle4
        Me.Particulars.HeaderText = "Particulars"
        Me.Particulars.Name = "Particulars"
        Me.Particulars.ReadOnly = True
        Me.Particulars.Width = 174
        '
        'Type
        '
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(213, Byte), Integer))
        Me.Type.DefaultCellStyle = DataGridViewCellStyle5
        Me.Type.HeaderText = "Type"
        Me.Type.Name = "Type"
        Me.Type.ReadOnly = True
        Me.Type.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Type.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Type.Width = 90
        '
        'Percentage
        '
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(CType(CType(194, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Percentage.DefaultCellStyle = DataGridViewCellStyle6
        Me.Percentage.HeaderText = "Percentage Of"
        Me.Percentage.Name = "Percentage"
        Me.Percentage.ReadOnly = True
        Me.Percentage.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Percentage.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Percentage.Width = 118
        '
        'Charge
        '
        DataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(213, Byte), Integer))
        Me.Charge.DefaultCellStyle = DataGridViewCellStyle7
        Me.Charge.HeaderText = "Charge"
        Me.Charge.Name = "Charge"
        Me.Charge.ReadOnly = True
        Me.Charge.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Charge.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Charge.Width = 112
        '
        'Acc_Code
        '
        Me.Acc_Code.HeaderText = "Acc_Code"
        Me.Acc_Code.Name = "Acc_Code"
        Me.Acc_Code.ReadOnly = True
        Me.Acc_Code.Visible = False
        '
        'Exp_Subtype
        '
        Me.Exp_Subtype.HeaderText = "Exp_Subtype"
        Me.Exp_Subtype.Name = "Exp_Subtype"
        Me.Exp_Subtype.ReadOnly = True
        Me.Exp_Subtype.Visible = False
        '
        'PercentageID
        '
        Me.PercentageID.HeaderText = "PercentageID"
        Me.PercentageID.Name = "PercentageID"
        Me.PercentageID.ReadOnly = True
        Me.PercentageID.Visible = False
        '
        'Btn_GridUp
        '
        Me.Btn_GridUp.BackColor = System.Drawing.Color.Transparent
        Me.Btn_GridUp.BackgroundImage = CType(resources.GetObject("Btn_GridUp.BackgroundImage"), System.Drawing.Image)
        Me.Btn_GridUp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_GridUp.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Btn_GridUp.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_GridUp.Location = New System.Drawing.Point(762, 166)
        Me.Btn_GridUp.Name = "Btn_GridUp"
        Me.Btn_GridUp.Size = New System.Drawing.Size(15, 21)
        Me.Btn_GridUp.TabIndex = 126
        Me.Btn_GridUp.TabStop = False
        Me.Btn_GridUp.UseVisualStyleBackColor = False
        '
        'Btn_GridDown
        '
        Me.Btn_GridDown.BackColor = System.Drawing.Color.Transparent
        Me.Btn_GridDown.BackgroundImage = CType(resources.GetObject("Btn_GridDown.BackgroundImage"), System.Drawing.Image)
        Me.Btn_GridDown.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_GridDown.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Btn_GridDown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_GridDown.Location = New System.Drawing.Point(762, 138)
        Me.Btn_GridDown.Name = "Btn_GridDown"
        Me.Btn_GridDown.Size = New System.Drawing.Size(15, 21)
        Me.Btn_GridDown.TabIndex = 125
        Me.Btn_GridDown.TabStop = False
        Me.Btn_GridDown.UseVisualStyleBackColor = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(193, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.Panel3.Controls.Add(Me.Cmb_AccountHead)
        Me.Panel3.Controls.Add(Me.Txt_particulars)
        Me.Panel3.Controls.Add(Me.Label10)
        Me.Panel3.Controls.Add(Me.Label6)
        Me.Panel3.Controls.Add(Me.Btn_Add)
        Me.Panel3.Controls.Add(Me.Cmb_Type)
        Me.Panel3.Controls.Add(Me.Txt_Charge)
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Controls.Add(Me.Label7)
        Me.Panel3.Controls.Add(Me.Cmb_Percentageof)
        Me.Panel3.Controls.Add(Me.Label5)
        Me.Panel3.Location = New System.Drawing.Point(2, 54)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(794, 55)
        Me.Panel3.TabIndex = 124
        '
        'Cmb_AccountHead
        '
        Me.Cmb_AccountHead.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_AccountHead.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_AccountHead.FormattingEnabled = True
        Me.Cmb_AccountHead.Location = New System.Drawing.Point(-1, 22)
        Me.Cmb_AccountHead.Name = "Cmb_AccountHead"
        Me.Cmb_AccountHead.Size = New System.Drawing.Size(238, 21)
        Me.Cmb_AccountHead.TabIndex = 1
        '
        'Txt_particulars
        '
        Me.Txt_particulars.BackColor = System.Drawing.Color.White
        Me.Txt_particulars.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_particulars.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_particulars.ForeColor = System.Drawing.Color.Black
        Me.Txt_particulars.Location = New System.Drawing.Point(238, 22)
        Me.Txt_particulars.Name = "Txt_particulars"
        Me.Txt_particulars.Size = New System.Drawing.Size(171, 20)
        Me.Txt_particulars.TabIndex = 2
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(237, 6)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(68, 13)
        Me.Label10.TabIndex = 132
        Me.Label10.Text = "Particulars"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(409, 6)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(35, 13)
        Me.Label6.TabIndex = 131
        Me.Label6.Text = "Type"
        '
        'Btn_Add
        '
        Me.Btn_Add.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Add.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Add.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Add.ForeColor = System.Drawing.Color.White
        Me.Btn_Add.Location = New System.Drawing.Point(737, 21)
        Me.Btn_Add.Name = "Btn_Add"
        Me.Btn_Add.Size = New System.Drawing.Size(53, 22)
        Me.Btn_Add.TabIndex = 6
        Me.Btn_Add.Text = "&Add"
        Me.Btn_Add.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btn_Add.UseVisualStyleBackColor = False
        '
        'Cmb_Type
        '
        Me.Cmb_Type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Type.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Type.FormattingEnabled = True
        Me.Cmb_Type.Location = New System.Drawing.Point(411, 22)
        Me.Cmb_Type.Name = "Cmb_Type"
        Me.Cmb_Type.Size = New System.Drawing.Size(88, 21)
        Me.Cmb_Type.TabIndex = 3
        '
        'Txt_Charge
        '
        Me.Txt_Charge.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Charge.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Charge.Location = New System.Drawing.Point(620, 22)
        Me.Txt_Charge.Name = "Txt_Charge"
        Me.Txt_Charge.Size = New System.Drawing.Size(114, 20)
        Me.Txt_Charge.TabIndex = 5
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(619, 6)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(47, 13)
        Me.Label2.TabIndex = 130
        Me.Label2.Text = "Charge"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(499, 6)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(86, 13)
        Me.Label7.TabIndex = 129
        Me.Label7.Text = "Percentage of"
        '
        'Cmb_Percentageof
        '
        Me.Cmb_Percentageof.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Percentageof.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Percentageof.FormattingEnabled = True
        Me.Cmb_Percentageof.Location = New System.Drawing.Point(501, 22)
        Me.Cmb_Percentageof.Name = "Cmb_Percentageof"
        Me.Cmb_Percentageof.Size = New System.Drawing.Size(117, 21)
        Me.Cmb_Percentageof.TabIndex = 4
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(0, 6)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(125, 13)
        Me.Label5.TabIndex = 128
        Me.Label5.Text = "General Ledger Head"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Navy
        Me.Label9.Location = New System.Drawing.Point(160, 2)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(34, 13)
        Me.Label9.TabIndex = 119
        Me.Label9.Text = "Date"
        '
        'Dtp_TranDate
        '
        Me.Dtp_TranDate.CustomFormat = "dd/MM/yyyy"
        Me.Dtp_TranDate.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dtp_TranDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_TranDate.Location = New System.Drawing.Point(160, 20)
        Me.Dtp_TranDate.Name = "Dtp_TranDate"
        Me.Dtp_TranDate.Size = New System.Drawing.Size(94, 21)
        Me.Dtp_TranDate.TabIndex = 118
        Me.Dtp_TranDate.TabStop = False
        '
        'Txt_ExpenseHead
        '
        Me.Txt_ExpenseHead.BackColor = System.Drawing.Color.White
        Me.Txt_ExpenseHead.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_ExpenseHead.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_ExpenseHead.ForeColor = System.Drawing.Color.Black
        Me.Txt_ExpenseHead.Location = New System.Drawing.Point(341, 20)
        Me.Txt_ExpenseHead.Name = "Txt_ExpenseHead"
        Me.Txt_ExpenseHead.ReadOnly = True
        Me.Txt_ExpenseHead.Size = New System.Drawing.Size(402, 21)
        Me.Txt_ExpenseHead.TabIndex = 1
        '
        'Txt_ExpenseID
        '
        Me.Txt_ExpenseID.BackColor = System.Drawing.Color.White
        Me.Txt_ExpenseID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_ExpenseID.Enabled = False
        Me.Txt_ExpenseID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_ExpenseID.Location = New System.Drawing.Point(259, 20)
        Me.Txt_ExpenseID.Name = "Txt_ExpenseID"
        Me.Txt_ExpenseID.ReadOnly = True
        Me.Txt_ExpenseID.Size = New System.Drawing.Size(75, 21)
        Me.Txt_ExpenseID.TabIndex = 0
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Navy
        Me.Label3.Location = New System.Drawing.Point(337, 2)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(71, 13)
        Me.Label3.TabIndex = 113
        Me.Label3.Text = "Description"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Navy
        Me.Label4.Location = New System.Drawing.Point(259, 2)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(43, 13)
        Me.Label4.TabIndex = 112
        Me.Label4.Text = "Exp ID"
        '
        'Expense_Charge_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.LeftGradiant
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(805, 531)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Btn_Saveorder)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Lbl_Seldatacategory)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Btn_Moveup)
        Me.Controls.Add(Me.Btn_Movedown)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.DGvw_Gendata)
        Me.Controls.Add(Me.DGvw_Gendatacategory)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Expense_Charge_Frm"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        CType(Me.DGvw_Gendatacategory, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DGvw_Gendata, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.Dgv_Chargesettings, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents DGvw_Gendatacategory As System.Windows.Forms.DataGridView
    Friend WithEvents DGvw_Gendata As System.Windows.Forms.DataGridView
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Btn_Movedown As System.Windows.Forms.Button
    Friend WithEvents Btn_Moveup As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Seldatacategory As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Lst_Gendata As System.Windows.Forms.ListBox
    Friend WithEvents Btn_Saveorder As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Btn_Add As System.Windows.Forms.Button
    Friend WithEvents Dgv_Chargesettings As REAL_CLINIC.Hms_DGridview
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Dtp_TranDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Txt_ExpenseHead As System.Windows.Forms.TextBox
    Friend WithEvents Txt_ExpenseID As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Acc_Name As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Particulars As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Type As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Percentage As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Charge As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Acc_Code As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Exp_Subtype As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PercentageID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Cmb_AccountHead As System.Windows.Forms.ComboBox
    Friend WithEvents Txt_particulars As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Type As System.Windows.Forms.ComboBox
    Friend WithEvents Txt_Charge As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Percentageof As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Btn_GridUp As System.Windows.Forms.Button
    Friend WithEvents Btn_GridDown As System.Windows.Forms.Button
    Friend WithEvents Btn_Removeitem As System.Windows.Forms.Button

End Class
