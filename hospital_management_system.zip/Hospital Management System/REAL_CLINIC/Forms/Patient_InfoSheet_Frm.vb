﻿Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls

Public Class Patient_InfoSheet_Frm

#Region "Declarations"
    'Object of Employee Details Bussiness Layer

    Private _patient_ID As String = ""
    Private Patient_BL As PatientInformation_BL_Cls
    Private hms_helper As HMS_Helper = Nothing


#End Region

#Region "Methods"
    'clear controls
    Public Sub Clear_Form()
        Try
            _patient_ID = ""

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    'assigning values to controls
    Private Sub AssignToControl(ByVal dtbl As DataTable)
        Try

            Dim dr As DataTableReader = Nothing
            dr = dtbl.CreateDataReader()
            dr.Read()

            With dr

                Lbl_PatientID.Text = .Item("Patient_ID").ToString
                Lbl_SOCNo.Text = .Item("SS_No").ToString
                Lbl_Name.Text = .Item("Name").ToString
                Lbl_FamilyName.Text = .Item("Family Name").ToString
                lbl_Address.Text = .Item("Address").ToString
                Lbl_City.Text = .Item("City").ToString
                Lbl_Pin.Text = .Item("PIN").ToString
                Lbl_Phone1.Text = .Item("Phone1").ToString
                Lbl_Phone2.Text = .Item("Phone2").ToString
                Lbl_Mob1.Text = .Item("Mobile1").ToString
                Lbl_Mob2.Text = .Item("Mobile2").ToString
                Lbl_Age.Text = .Item("Age").ToString
                Lbl_Email.Text = .Item("Email").ToString
                Lbl_Occupation.Text = .Item("Occupation").ToString
                Lbl_Employer.Text = .Item("Employer").ToString
                Lbl_Nominee.Text = .Item("Nominee").ToString
                Lbl_NomineeRel.Text = .Item("Relation").ToString
                Lbl_FamiliyDoctor.Text = .Item("Family Doctor").ToString
                Lbl_remarks.Text = .Item("Remarks").ToString
                Lbl_IdentificationMark.Text = .Item("Identity Details").ToString

                Lbl_DOB.Text = Strings.Left(.Item("Date of Birth").ToString, 10)
                Lbl_RegDate.Text = Strings.Left(.Item("Register Date").ToString, 10)
                Lbl_LastVistdate.Text = Strings.Left(.Item("Last Admit Date").ToString, 10)


                Lbl_Status.Text = .Item("Patient Status").ToString

                Lbl_MartialStatus.Text = .Item("Marital Status").ToString
                Lbl_Insured.Text = .Item("Insured").ToString
                Lbl_Patient_Socialstatus.Text = .Item("Social Status").ToString
                Lbl_AnnualIncome.Text = .Item("Annual Income").ToString
                Lbl_State.Text = .Item("State").ToString
                Lbl_Country.Text = .Item("Country").ToString

                Lbl_Gender.Text = IIf(.Item("Gender").ToString = "M", 0, 1)



            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

   
    'Locate values from BL
    Public Function Locate_Values(ByVal PatientID As String) As Boolean

        
        Try
            If PatientID = "" Then Exit Function
            Patient_BL = New PatientInformation_BL_Cls
            Dim dtbl As DataTable = Nothing
            If Patient_BL.Get_Patient_InfoDetailed(dtbl, PatientID) Then
                Call AssignToControl(dtbl)

                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Function

#End Region

    Private Sub Patient_InfoSheet_Frm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try

            If Locate_Values(_patient_ID) Then

            End If
        Catch ex As Exception

        End Try
       
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub
    Public WriteOnly Property Patient_ID() As String
        Set(ByVal value As String)
            _patient_ID = value
           
        End Set
    End Property


   
    Private Sub Btn_Edit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Edit.Click
        With PatientInformation_Frm
            .Txt_Pat_ID.Text = _patient_ID
            .Btn_FindID_Click(sender, e)
            .MdiParent = Me.MdiParent
            .Show()
        End With
    End Sub


End Class