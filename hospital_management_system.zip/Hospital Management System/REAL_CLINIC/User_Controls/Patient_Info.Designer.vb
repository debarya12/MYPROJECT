﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Patient_Info
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Pnl_Patientname = New System.Windows.Forms.Panel
        Me.PatientName = New System.Windows.Forms.Label
        Me.Lbl_Name = New System.Windows.Forms.Label
        Me.Pnl_PatientSSN = New System.Windows.Forms.Panel
        Me.Btn_viewmore = New System.Windows.Forms.Button
        Me.PatientSSN = New System.Windows.Forms.Label
        Me.Lbl_SSN = New System.Windows.Forms.Label
        Me.Pnl_Phone = New System.Windows.Forms.Panel
        Me.Patientmobile = New System.Windows.Forms.Label
        Me.Lbl_Mobile = New System.Windows.Forms.Label
        Me.Patientphone = New System.Windows.Forms.Label
        Me.Lbl_Phone = New System.Windows.Forms.Label
        Me.Pnl_Patientaddress = New System.Windows.Forms.Panel
        Me.Patientaddress = New System.Windows.Forms.Label
        Me.Lbl_Address = New System.Windows.Forms.Label
        Me.Pnl_Familyname = New System.Windows.Forms.Panel
        Me.Patientfamilyname = New System.Windows.Forms.Label
        Me.Lbl_Familyname = New System.Windows.Forms.Label
        Me.Pnl_Patientname.SuspendLayout()
        Me.Pnl_PatientSSN.SuspendLayout()
        Me.Pnl_Phone.SuspendLayout()
        Me.Pnl_Patientaddress.SuspendLayout()
        Me.Pnl_Familyname.SuspendLayout()
        Me.SuspendLayout()
        '
        'Pnl_Patientname
        '
        Me.Pnl_Patientname.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Patientname.Controls.Add(Me.PatientName)
        Me.Pnl_Patientname.Controls.Add(Me.Lbl_Name)
        Me.Pnl_Patientname.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Patientname.Location = New System.Drawing.Point(2, 2)
        Me.Pnl_Patientname.Name = "Pnl_Patientname"
        Me.Pnl_Patientname.Size = New System.Drawing.Size(386, 31)
        Me.Pnl_Patientname.TabIndex = 2
        '
        'PatientName
        '
        Me.PatientName.BackColor = System.Drawing.Color.Transparent
        Me.PatientName.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PatientName.ForeColor = System.Drawing.Color.DarkBlue
        Me.PatientName.Location = New System.Drawing.Point(85, 0)
        Me.PatientName.Name = "PatientName"
        Me.PatientName.Size = New System.Drawing.Size(301, 31)
        Me.PatientName.TabIndex = 3
        Me.PatientName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Lbl_Name
        '
        Me.Lbl_Name.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Name.Dock = System.Windows.Forms.DockStyle.Left
        Me.Lbl_Name.ForeColor = System.Drawing.Color.RoyalBlue
        Me.Lbl_Name.Location = New System.Drawing.Point(0, 0)
        Me.Lbl_Name.Name = "Lbl_Name"
        Me.Lbl_Name.Size = New System.Drawing.Size(85, 31)
        Me.Lbl_Name.TabIndex = 2
        Me.Lbl_Name.Text = "Name              :"
        Me.Lbl_Name.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Pnl_PatientSSN
        '
        Me.Pnl_PatientSSN.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_PatientSSN.Controls.Add(Me.Btn_viewmore)
        Me.Pnl_PatientSSN.Controls.Add(Me.PatientSSN)
        Me.Pnl_PatientSSN.Controls.Add(Me.Lbl_SSN)
        Me.Pnl_PatientSSN.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Pnl_PatientSSN.Location = New System.Drawing.Point(2, 126)
        Me.Pnl_PatientSSN.Name = "Pnl_PatientSSN"
        Me.Pnl_PatientSSN.Size = New System.Drawing.Size(386, 22)
        Me.Pnl_PatientSSN.TabIndex = 7
        '
        'Btn_viewmore
        '
        Me.Btn_viewmore.BackColor = System.Drawing.Color.Transparent
        Me.Btn_viewmore.Dock = System.Windows.Forms.DockStyle.Right
        Me.Btn_viewmore.Enabled = False
        Me.Btn_viewmore.FlatAppearance.BorderSize = 0
        Me.Btn_viewmore.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_viewmore.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_viewmore.ForeColor = System.Drawing.Color.RoyalBlue
        Me.Btn_viewmore.Location = New System.Drawing.Point(297, 0)
        Me.Btn_viewmore.Name = "Btn_viewmore"
        Me.Btn_viewmore.Size = New System.Drawing.Size(89, 22)
        Me.Btn_viewmore.TabIndex = 6
        Me.Btn_viewmore.TabStop = False
        Me.Btn_viewmore.Text = "&View More"
        Me.Btn_viewmore.UseVisualStyleBackColor = False
        '
        'PatientSSN
        '
        Me.PatientSSN.BackColor = System.Drawing.Color.Transparent
        Me.PatientSSN.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PatientSSN.ForeColor = System.Drawing.Color.DarkBlue
        Me.PatientSSN.Location = New System.Drawing.Point(85, 0)
        Me.PatientSSN.Name = "PatientSSN"
        Me.PatientSSN.Size = New System.Drawing.Size(301, 22)
        Me.PatientSSN.TabIndex = 3
        Me.PatientSSN.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Lbl_SSN
        '
        Me.Lbl_SSN.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_SSN.Dock = System.Windows.Forms.DockStyle.Left
        Me.Lbl_SSN.ForeColor = System.Drawing.Color.RoyalBlue
        Me.Lbl_SSN.Location = New System.Drawing.Point(0, 0)
        Me.Lbl_SSN.Name = "Lbl_SSN"
        Me.Lbl_SSN.Size = New System.Drawing.Size(85, 22)
        Me.Lbl_SSN.TabIndex = 2
        Me.Lbl_SSN.Text = "SSN                  :"
        Me.Lbl_SSN.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Pnl_Phone
        '
        Me.Pnl_Phone.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Phone.Controls.Add(Me.Patientmobile)
        Me.Pnl_Phone.Controls.Add(Me.Lbl_Mobile)
        Me.Pnl_Phone.Controls.Add(Me.Patientphone)
        Me.Pnl_Phone.Controls.Add(Me.Lbl_Phone)
        Me.Pnl_Phone.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Pnl_Phone.Location = New System.Drawing.Point(2, 104)
        Me.Pnl_Phone.Name = "Pnl_Phone"
        Me.Pnl_Phone.Size = New System.Drawing.Size(386, 22)
        Me.Pnl_Phone.TabIndex = 8
        '
        'Patientmobile
        '
        Me.Patientmobile.BackColor = System.Drawing.Color.Transparent
        Me.Patientmobile.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Patientmobile.ForeColor = System.Drawing.Color.DarkBlue
        Me.Patientmobile.Location = New System.Drawing.Point(266, 0)
        Me.Patientmobile.Name = "Patientmobile"
        Me.Patientmobile.Size = New System.Drawing.Size(120, 22)
        Me.Patientmobile.TabIndex = 5
        Me.Patientmobile.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Lbl_Mobile
        '
        Me.Lbl_Mobile.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Mobile.Dock = System.Windows.Forms.DockStyle.Left
        Me.Lbl_Mobile.ForeColor = System.Drawing.Color.RoyalBlue
        Me.Lbl_Mobile.Location = New System.Drawing.Point(212, 0)
        Me.Lbl_Mobile.Name = "Lbl_Mobile"
        Me.Lbl_Mobile.Size = New System.Drawing.Size(54, 22)
        Me.Lbl_Mobile.TabIndex = 4
        Me.Lbl_Mobile.Text = "Mobile  :"
        Me.Lbl_Mobile.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Patientphone
        '
        Me.Patientphone.BackColor = System.Drawing.Color.Transparent
        Me.Patientphone.Dock = System.Windows.Forms.DockStyle.Left
        Me.Patientphone.ForeColor = System.Drawing.Color.DarkBlue
        Me.Patientphone.Location = New System.Drawing.Point(85, 0)
        Me.Patientphone.Name = "Patientphone"
        Me.Patientphone.Size = New System.Drawing.Size(127, 22)
        Me.Patientphone.TabIndex = 3
        Me.Patientphone.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Lbl_Phone
        '
        Me.Lbl_Phone.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Phone.Dock = System.Windows.Forms.DockStyle.Left
        Me.Lbl_Phone.ForeColor = System.Drawing.Color.RoyalBlue
        Me.Lbl_Phone.Location = New System.Drawing.Point(0, 0)
        Me.Lbl_Phone.Name = "Lbl_Phone"
        Me.Lbl_Phone.Size = New System.Drawing.Size(85, 22)
        Me.Lbl_Phone.TabIndex = 2
        Me.Lbl_Phone.Text = "Phone             :"
        Me.Lbl_Phone.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Pnl_Patientaddress
        '
        Me.Pnl_Patientaddress.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Patientaddress.Controls.Add(Me.Patientaddress)
        Me.Pnl_Patientaddress.Controls.Add(Me.Lbl_Address)
        Me.Pnl_Patientaddress.Controls.Add(Me.Pnl_Familyname)
        Me.Pnl_Patientaddress.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Pnl_Patientaddress.Location = New System.Drawing.Point(2, 33)
        Me.Pnl_Patientaddress.Name = "Pnl_Patientaddress"
        Me.Pnl_Patientaddress.Size = New System.Drawing.Size(386, 71)
        Me.Pnl_Patientaddress.TabIndex = 9
        '
        'Patientaddress
        '
        Me.Patientaddress.BackColor = System.Drawing.Color.Transparent
        Me.Patientaddress.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Patientaddress.ForeColor = System.Drawing.Color.DarkBlue
        Me.Patientaddress.Location = New System.Drawing.Point(85, 0)
        Me.Patientaddress.Name = "Patientaddress"
        Me.Patientaddress.Size = New System.Drawing.Size(301, 49)
        Me.Patientaddress.TabIndex = 10
        '
        'Lbl_Address
        '
        Me.Lbl_Address.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Address.Dock = System.Windows.Forms.DockStyle.Left
        Me.Lbl_Address.ForeColor = System.Drawing.Color.RoyalBlue
        Me.Lbl_Address.Location = New System.Drawing.Point(0, 0)
        Me.Lbl_Address.Name = "Lbl_Address"
        Me.Lbl_Address.Size = New System.Drawing.Size(85, 49)
        Me.Lbl_Address.TabIndex = 9
        Me.Lbl_Address.Text = "Address         :"
        '
        'Pnl_Familyname
        '
        Me.Pnl_Familyname.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Familyname.Controls.Add(Me.Patientfamilyname)
        Me.Pnl_Familyname.Controls.Add(Me.Lbl_Familyname)
        Me.Pnl_Familyname.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Pnl_Familyname.Location = New System.Drawing.Point(0, 49)
        Me.Pnl_Familyname.Name = "Pnl_Familyname"
        Me.Pnl_Familyname.Size = New System.Drawing.Size(386, 22)
        Me.Pnl_Familyname.TabIndex = 8
        '
        'Patientfamilyname
        '
        Me.Patientfamilyname.BackColor = System.Drawing.Color.Transparent
        Me.Patientfamilyname.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Patientfamilyname.ForeColor = System.Drawing.Color.DarkBlue
        Me.Patientfamilyname.Location = New System.Drawing.Point(85, 0)
        Me.Patientfamilyname.Name = "Patientfamilyname"
        Me.Patientfamilyname.Size = New System.Drawing.Size(301, 22)
        Me.Patientfamilyname.TabIndex = 3
        Me.Patientfamilyname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Lbl_Familyname
        '
        Me.Lbl_Familyname.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Familyname.Dock = System.Windows.Forms.DockStyle.Left
        Me.Lbl_Familyname.ForeColor = System.Drawing.Color.RoyalBlue
        Me.Lbl_Familyname.Location = New System.Drawing.Point(0, 0)
        Me.Lbl_Familyname.Name = "Lbl_Familyname"
        Me.Lbl_Familyname.Size = New System.Drawing.Size(85, 22)
        Me.Lbl_Familyname.TabIndex = 2
        Me.Lbl_Familyname.Text = "Family Name :"
        Me.Lbl_Familyname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Patient_Info
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Transparent
        Me.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Controls.Add(Me.Pnl_Patientaddress)
        Me.Controls.Add(Me.Pnl_Phone)
        Me.Controls.Add(Me.Pnl_PatientSSN)
        Me.Controls.Add(Me.Pnl_Patientname)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "Patient_Info"
        Me.Padding = New System.Windows.Forms.Padding(2)
        Me.Size = New System.Drawing.Size(390, 150)
        Me.Pnl_Patientname.ResumeLayout(False)
        Me.Pnl_PatientSSN.ResumeLayout(False)
        Me.Pnl_Phone.ResumeLayout(False)
        Me.Pnl_Patientaddress.ResumeLayout(False)
        Me.Pnl_Familyname.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Pnl_Patientname As System.Windows.Forms.Panel
    Friend WithEvents PatientName As System.Windows.Forms.Label
    Friend WithEvents Lbl_Name As System.Windows.Forms.Label
    Friend WithEvents Pnl_PatientSSN As System.Windows.Forms.Panel
    Friend WithEvents Btn_viewmore As System.Windows.Forms.Button
    Friend WithEvents PatientSSN As System.Windows.Forms.Label
    Friend WithEvents Lbl_SSN As System.Windows.Forms.Label
    Friend WithEvents Pnl_Phone As System.Windows.Forms.Panel
    Friend WithEvents Patientmobile As System.Windows.Forms.Label
    Friend WithEvents Lbl_Mobile As System.Windows.Forms.Label
    Friend WithEvents Patientphone As System.Windows.Forms.Label
    Friend WithEvents Lbl_Phone As System.Windows.Forms.Label
    Friend WithEvents Pnl_Patientaddress As System.Windows.Forms.Panel
    Friend WithEvents Patientaddress As System.Windows.Forms.Label
    Friend WithEvents Lbl_Address As System.Windows.Forms.Label
    Friend WithEvents Pnl_Familyname As System.Windows.Forms.Panel
    Friend WithEvents Patientfamilyname As System.Windows.Forms.Label
    Friend WithEvents Lbl_Familyname As System.Windows.Forms.Label

End Class
