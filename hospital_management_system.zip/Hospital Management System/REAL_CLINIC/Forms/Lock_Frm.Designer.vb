﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Lock_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Lock_Frm))
        Me.PBox_Lockuser = New System.Windows.Forms.PictureBox
        Me.Txt_Pwd = New System.Windows.Forms.TextBox
        Me.Lbl_Lockusername = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Btn_Unlock = New System.Windows.Forms.Button
        CType(Me.PBox_Lockuser, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PBox_Lockuser
        '
        Me.PBox_Lockuser.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PBox_Lockuser.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PBox_Lockuser.Image = CType(resources.GetObject("PBox_Lockuser.Image"), System.Drawing.Image)
        Me.PBox_Lockuser.Location = New System.Drawing.Point(44, 35)
        Me.PBox_Lockuser.Name = "PBox_Lockuser"
        Me.PBox_Lockuser.Size = New System.Drawing.Size(158, 169)
        Me.PBox_Lockuser.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PBox_Lockuser.TabIndex = 0
        Me.PBox_Lockuser.TabStop = False
        '
        'Txt_Pwd
        '
        Me.Txt_Pwd.BackColor = System.Drawing.Color.White
        Me.Txt_Pwd.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Pwd.Font = New System.Drawing.Font("Wingdings", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.Txt_Pwd.ForeColor = System.Drawing.Color.Silver
        Me.Txt_Pwd.Location = New System.Drawing.Point(39, 247)
        Me.Txt_Pwd.Name = "Txt_Pwd"
        Me.Txt_Pwd.PasswordChar = Global.Microsoft.VisualBasic.ChrW(108)
        Me.Txt_Pwd.Size = New System.Drawing.Size(169, 22)
        Me.Txt_Pwd.TabIndex = 0
        Me.Txt_Pwd.Text = "Password"
        Me.Txt_Pwd.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Lbl_Lockusername
        '
        Me.Lbl_Lockusername.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Lockusername.Location = New System.Drawing.Point(0, 207)
        Me.Lbl_Lockusername.Name = "Lbl_Lockusername"
        Me.Lbl_Lockusername.Size = New System.Drawing.Size(248, 13)
        Me.Lbl_Lockusername.TabIndex = 7
        Me.Lbl_Lockusername.Text = "PULSAR"
        Me.Lbl_Lockusername.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(103, 221)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 13)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Locked"
        '
        'Btn_Unlock
        '
        Me.Btn_Unlock.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Gendatasave1
        Me.Btn_Unlock.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Unlock.ForeColor = System.Drawing.Color.White
        Me.Btn_Unlock.Location = New System.Drawing.Point(211, 242)
        Me.Btn_Unlock.Name = "Btn_Unlock"
        Me.Btn_Unlock.Size = New System.Drawing.Size(33, 29)
        Me.Btn_Unlock.TabIndex = 1
        Me.Btn_Unlock.Text = "GO"
        Me.Btn_Unlock.UseVisualStyleBackColor = True
        '
        'Lock_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(200, Byte), Integer), CType(CType(217, Byte), Integer), CType(CType(162, Byte), Integer))
        Me.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Gendatasave1
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(246, 274)
        Me.ControlBox = False
        Me.Controls.Add(Me.Btn_Unlock)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Txt_Pwd)
        Me.Controls.Add(Me.Lbl_Lockusername)
        Me.Controls.Add(Me.PBox_Lockuser)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Lock_Frm"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.TopMost = True
        CType(Me.PBox_Lockuser, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PBox_Lockuser As System.Windows.Forms.PictureBox
    Friend WithEvents Txt_Pwd As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_Lockusername As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Btn_Unlock As System.Windows.Forms.Button
End Class
