﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Account_Head_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Account_Head_Frm))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Btn_AccountGroup = New System.Windows.Forms.Button()
        Me.Btn_AccountMaster = New System.Windows.Forms.Button()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Tab_AccHead = New System.Windows.Forms.TabPage()
        Me.Grid_Searchhelper2 = New REAL_CLINIC.Grid_Searchhelper()
        Me.Txt_ShortName = New System.Windows.Forms.TextBox()
        Me.Dgrd_History1 = New System.Windows.Forms.DataGridView()
        Me.Txt_HeadOrder = New System.Windows.Forms.TextBox()
        Me.Txt_AccountHead = New System.Windows.Forms.TextBox()
        Me.Txt_HeadID = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Cmb_ALEI = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Tran_mode_Pnl = New System.Windows.Forms.Panel()
        Me.Lbl_Tran_Mode2 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Btn_Clear1 = New System.Windows.Forms.Button()
        Me.Btn_Close1 = New System.Windows.Forms.Button()
        Me.Btn_Delete1 = New System.Windows.Forms.Button()
        Me.Btn_Save1 = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Cmb_GroupName = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Btn_Find1 = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Tab_AccountHead = New System.Windows.Forms.TabControl()
        Me.Tab_AccGrp = New System.Windows.Forms.TabPage()
        Me.Grid_Searchhelper1 = New REAL_CLINIC.Grid_Searchhelper()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Dgrd_History = New System.Windows.Forms.DataGridView()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Lbl_Tran_Mode1 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Btn_Clear = New System.Windows.Forms.Button()
        Me.Btn_Close = New System.Windows.Forms.Button()
        Me.Btn_Delete = New System.Windows.Forms.Button()
        Me.Btn_Save = New System.Windows.Forms.Button()
        Me.Txt_Group_Order = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Txt_GroupName = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Btn_Find = New System.Windows.Forms.Button()
        Me.Txt_GroupID = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel5.SuspendLayout()
        Me.Tab_AccHead.SuspendLayout()
        CType(Me.Dgrd_History1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Tran_mode_Pnl.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Tab_AccountHead.SuspendLayout()
        Me.Tab_AccGrp.SuspendLayout()
        CType(Me.Dgrd_History, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel6
        '
        Me.Panel6.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Panel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel6.Location = New System.Drawing.Point(57, 46)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(6, 313)
        Me.Panel6.TabIndex = 99
        '
        'Btn_AccountGroup
        '
        Me.Btn_AccountGroup.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_AccountGroup.BackgroundImage = CType(resources.GetObject("Btn_AccountGroup.BackgroundImage"), System.Drawing.Image)
        Me.Btn_AccountGroup.ForeColor = System.Drawing.Color.White
        Me.Btn_AccountGroup.Location = New System.Drawing.Point(-1, -3)
        Me.Btn_AccountGroup.Name = "Btn_AccountGroup"
        Me.Btn_AccountGroup.Size = New System.Drawing.Size(296, 28)
        Me.Btn_AccountGroup.TabIndex = 99
        Me.Btn_AccountGroup.TabStop = False
        Me.Btn_AccountGroup.Text = "A c c o u n t   G r o u p"
        Me.Btn_AccountGroup.UseVisualStyleBackColor = False
        '
        'Btn_AccountMaster
        '
        Me.Btn_AccountMaster.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_AccountMaster.BackgroundImage = CType(resources.GetObject("Btn_AccountMaster.BackgroundImage"), System.Drawing.Image)
        Me.Btn_AccountMaster.ForeColor = System.Drawing.Color.White
        Me.Btn_AccountMaster.Location = New System.Drawing.Point(294, -4)
        Me.Btn_AccountMaster.Name = "Btn_AccountMaster"
        Me.Btn_AccountMaster.Size = New System.Drawing.Size(326, 28)
        Me.Btn_AccountMaster.TabIndex = 100
        Me.Btn_AccountMaster.TabStop = False
        Me.Btn_AccountMaster.Text = "A c c o u n t   M a s t e r"
        Me.Btn_AccountMaster.UseVisualStyleBackColor = False
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.SystemColors.ControlDark
        Me.Panel5.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Panel5.Controls.Add(Me.Btn_AccountMaster)
        Me.Panel5.Controls.Add(Me.Btn_AccountGroup)
        Me.Panel5.Location = New System.Drawing.Point(57, 23)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(620, 24)
        Me.Panel5.TabIndex = 98
        '
        'Tab_AccHead
        '
        Me.Tab_AccHead.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.LeftGradiant
        Me.Tab_AccHead.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Tab_AccHead.Controls.Add(Me.Grid_Searchhelper2)
        Me.Tab_AccHead.Controls.Add(Me.Txt_ShortName)
        Me.Tab_AccHead.Controls.Add(Me.Dgrd_History1)
        Me.Tab_AccHead.Controls.Add(Me.Txt_HeadOrder)
        Me.Tab_AccHead.Controls.Add(Me.Txt_AccountHead)
        Me.Tab_AccHead.Controls.Add(Me.Txt_HeadID)
        Me.Tab_AccHead.Controls.Add(Me.Label11)
        Me.Tab_AccHead.Controls.Add(Me.Label10)
        Me.Tab_AccHead.Controls.Add(Me.Cmb_ALEI)
        Me.Tab_AccHead.Controls.Add(Me.Label9)
        Me.Tab_AccHead.Controls.Add(Me.Tran_mode_Pnl)
        Me.Tab_AccHead.Controls.Add(Me.Panel3)
        Me.Tab_AccHead.Controls.Add(Me.Label8)
        Me.Tab_AccHead.Controls.Add(Me.Cmb_GroupName)
        Me.Tab_AccHead.Controls.Add(Me.Label5)
        Me.Tab_AccHead.Controls.Add(Me.Label6)
        Me.Tab_AccHead.Controls.Add(Me.Btn_Find1)
        Me.Tab_AccHead.Controls.Add(Me.Label7)
        Me.Tab_AccHead.Location = New System.Drawing.Point(4, 22)
        Me.Tab_AccHead.Name = "Tab_AccHead"
        Me.Tab_AccHead.Padding = New System.Windows.Forms.Padding(3)
        Me.Tab_AccHead.Size = New System.Drawing.Size(610, 312)
        Me.Tab_AccHead.TabIndex = 1
        Me.Tab_AccHead.Text = "Account Head Settings"
        Me.Tab_AccHead.UseVisualStyleBackColor = True
        '
        'Grid_Searchhelper2
        '
        Me.Grid_Searchhelper2.BackColor = System.Drawing.Color.RoyalBlue
        Me.Grid_Searchhelper2.Location = New System.Drawing.Point(334, 96)
        Me.Grid_Searchhelper2.Name = "Grid_Searchhelper2"
        Me.Grid_Searchhelper2.Padding = New System.Windows.Forms.Padding(1)
        Me.Grid_Searchhelper2.Search_Query = ""
        Me.Grid_Searchhelper2.Size = New System.Drawing.Size(202, 48)
        Me.Grid_Searchhelper2.TabIndex = 102
        Me.Grid_Searchhelper2.Visible = False
        '
        'Txt_ShortName
        '
        Me.Txt_ShortName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_ShortName.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_ShortName.Location = New System.Drawing.Point(108, 96)
        Me.Txt_ShortName.MaxLength = 10
        Me.Txt_ShortName.Name = "Txt_ShortName"
        Me.Txt_ShortName.Size = New System.Drawing.Size(220, 21)
        Me.Txt_ShortName.TabIndex = 11
        '
        'Dgrd_History1
        '
        Me.Dgrd_History1.AllowUserToAddRows = False
        Me.Dgrd_History1.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(252, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.Navy
        Me.Dgrd_History1.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.Dgrd_History1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Dgrd_History1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(87, Byte), Integer), CType(CType(157, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgrd_History1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.Dgrd_History1.ColumnHeadersHeight = 20
        Me.Dgrd_History1.Location = New System.Drawing.Point(5, 190)
        Me.Dgrd_History1.MultiSelect = False
        Me.Dgrd_History1.Name = "Dgrd_History1"
        Me.Dgrd_History1.ReadOnly = True
        Me.Dgrd_History1.RowHeadersVisible = False
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(254, Byte), Integer))
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.Navy
        Me.Dgrd_History1.RowsDefaultCellStyle = DataGridViewCellStyle3
        Me.Dgrd_History1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.Dgrd_History1.Size = New System.Drawing.Size(599, 117)
        Me.Dgrd_History1.TabIndex = 63
        '
        'Txt_HeadOrder
        '
        Me.Txt_HeadOrder.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_HeadOrder.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_HeadOrder.Location = New System.Drawing.Point(108, 150)
        Me.Txt_HeadOrder.MaxLength = 50
        Me.Txt_HeadOrder.Name = "Txt_HeadOrder"
        Me.Txt_HeadOrder.Size = New System.Drawing.Size(68, 21)
        Me.Txt_HeadOrder.TabIndex = 13
        '
        'Txt_AccountHead
        '
        Me.Txt_AccountHead.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_AccountHead.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_AccountHead.Location = New System.Drawing.Point(108, 69)
        Me.Txt_AccountHead.MaxLength = 100
        Me.Txt_AccountHead.Name = "Txt_AccountHead"
        Me.Txt_AccountHead.Size = New System.Drawing.Size(427, 21)
        Me.Txt_AccountHead.TabIndex = 10
        '
        'Txt_HeadID
        '
        Me.Txt_HeadID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_HeadID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_HeadID.Location = New System.Drawing.Point(108, 15)
        Me.Txt_HeadID.MaxLength = 50
        Me.Txt_HeadID.Name = "Txt_HeadID"
        Me.Txt_HeadID.Size = New System.Drawing.Size(105, 21)
        Me.Txt_HeadID.TabIndex = 8
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Location = New System.Drawing.Point(3, 98)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(70, 13)
        Me.Label11.TabIndex = 101
        Me.Label11.Text = "Short Head"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Location = New System.Drawing.Point(3, 125)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(84, 13)
        Me.Label10.TabIndex = 99
        Me.Label10.Text = "Account Type"
        '
        'Cmb_ALEI
        '
        Me.Cmb_ALEI.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_ALEI.FormattingEnabled = True
        Me.Cmb_ALEI.Location = New System.Drawing.Point(108, 123)
        Me.Cmb_ALEI.Name = "Cmb_ALEI"
        Me.Cmb_ALEI.Size = New System.Drawing.Size(220, 21)
        Me.Cmb_ALEI.TabIndex = 12
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.ForeColor = System.Drawing.Color.OrangeRed
        Me.Label9.Location = New System.Drawing.Point(85, 68)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(14, 13)
        Me.Label9.TabIndex = 97
        Me.Label9.Text = "*"
        '
        'Tran_mode_Pnl
        '
        Me.Tran_mode_Pnl.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Tran_mode_Pnl.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.F2_Button
        Me.Tran_mode_Pnl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Tran_mode_Pnl.Controls.Add(Me.Lbl_Tran_Mode2)
        Me.Tran_mode_Pnl.ForeColor = System.Drawing.Color.White
        Me.Tran_mode_Pnl.Location = New System.Drawing.Point(455, 15)
        Me.Tran_mode_Pnl.Name = "Tran_mode_Pnl"
        Me.Tran_mode_Pnl.Size = New System.Drawing.Size(74, 21)
        Me.Tran_mode_Pnl.TabIndex = 62
        '
        'Lbl_Tran_Mode2
        '
        Me.Lbl_Tran_Mode2.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode2.Location = New System.Drawing.Point(2, 1)
        Me.Lbl_Tran_Mode2.Name = "Lbl_Tran_Mode2"
        Me.Lbl_Tran_Mode2.Size = New System.Drawing.Size(68, 16)
        Me.Lbl_Tran_Mode2.TabIndex = 0
        Me.Lbl_Tran_Mode2.Text = "NEW MODE"
        Me.Lbl_Tran_Mode2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Panel3.Controls.Add(Me.Btn_Clear1)
        Me.Panel3.Controls.Add(Me.Btn_Close1)
        Me.Panel3.Controls.Add(Me.Btn_Delete1)
        Me.Panel3.Controls.Add(Me.Btn_Save1)
        Me.Panel3.ForeColor = System.Drawing.Color.White
        Me.Panel3.Location = New System.Drawing.Point(542, 15)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(62, 126)
        Me.Panel3.TabIndex = 61
        '
        'Btn_Clear1
        '
        Me.Btn_Clear1.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Clear1.CausesValidation = False
        Me.Btn_Clear1.Location = New System.Drawing.Point(3, 64)
        Me.Btn_Clear1.Name = "Btn_Clear1"
        Me.Btn_Clear1.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear1.TabIndex = 16
        Me.Btn_Clear1.Text = "C&lear"
        Me.Btn_Clear1.UseVisualStyleBackColor = True
        '
        'Btn_Close1
        '
        Me.Btn_Close1.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Close1.CausesValidation = False
        Me.Btn_Close1.Location = New System.Drawing.Point(3, 95)
        Me.Btn_Close1.Name = "Btn_Close1"
        Me.Btn_Close1.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close1.TabIndex = 17
        Me.Btn_Close1.Text = "&Close"
        Me.Btn_Close1.UseVisualStyleBackColor = True
        '
        'Btn_Delete1
        '
        Me.Btn_Delete1.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Delete1.Location = New System.Drawing.Point(3, 34)
        Me.Btn_Delete1.Name = "Btn_Delete1"
        Me.Btn_Delete1.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Delete1.TabIndex = 15
        Me.Btn_Delete1.Text = "D&elete"
        Me.Btn_Delete1.UseVisualStyleBackColor = True
        '
        'Btn_Save1
        '
        Me.Btn_Save1.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save1.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Save1.ForeColor = System.Drawing.Color.White
        Me.Btn_Save1.Location = New System.Drawing.Point(3, 4)
        Me.Btn_Save1.Name = "Btn_Save1"
        Me.Btn_Save1.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save1.TabIndex = 14
        Me.Btn_Save1.Text = "&Save"
        Me.Btn_Save1.UseVisualStyleBackColor = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Location = New System.Drawing.Point(3, 44)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(76, 13)
        Me.Label8.TabIndex = 56
        Me.Label8.Text = "Group Name"
        '
        'Cmb_GroupName
        '
        Me.Cmb_GroupName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_GroupName.FormattingEnabled = True
        Me.Cmb_GroupName.Location = New System.Drawing.Point(108, 42)
        Me.Cmb_GroupName.Name = "Cmb_GroupName"
        Me.Cmb_GroupName.Size = New System.Drawing.Size(220, 21)
        Me.Cmb_GroupName.TabIndex = 9
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Location = New System.Drawing.Point(3, 152)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(71, 13)
        Me.Label5.TabIndex = 45
        Me.Label5.Text = "Head Order"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Location = New System.Drawing.Point(3, 71)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(85, 13)
        Me.Label6.TabIndex = 43
        Me.Label6.Text = "Account Head"
        '
        'Btn_Find1
        '
        Me.Btn_Find1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find1.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.F2_Button
        Me.Btn_Find1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find1.ForeColor = System.Drawing.Color.White
        Me.Btn_Find1.Location = New System.Drawing.Point(216, 15)
        Me.Btn_Find1.Name = "Btn_Find1"
        Me.Btn_Find1.Size = New System.Drawing.Size(29, 21)
        Me.Btn_Find1.TabIndex = 41
        Me.Btn_Find1.TabStop = False
        Me.Btn_Find1.Text = "F2"
        Me.Btn_Find1.UseVisualStyleBackColor = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Location = New System.Drawing.Point(3, 17)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(52, 13)
        Me.Label7.TabIndex = 40
        Me.Label7.Text = "Head ID"
        '
        'Tab_AccountHead
        '
        Me.Tab_AccountHead.Controls.Add(Me.Tab_AccGrp)
        Me.Tab_AccountHead.Controls.Add(Me.Tab_AccHead)
        Me.Tab_AccountHead.Location = New System.Drawing.Point(59, 25)
        Me.Tab_AccountHead.Name = "Tab_AccountHead"
        Me.Tab_AccountHead.SelectedIndex = 0
        Me.Tab_AccountHead.Size = New System.Drawing.Size(618, 338)
        Me.Tab_AccountHead.TabIndex = 0
        '
        'Tab_AccGrp
        '
        Me.Tab_AccGrp.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.LeftGradiant
        Me.Tab_AccGrp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Tab_AccGrp.Controls.Add(Me.Grid_Searchhelper1)
        Me.Tab_AccGrp.Controls.Add(Me.Label17)
        Me.Tab_AccGrp.Controls.Add(Me.Dgrd_History)
        Me.Tab_AccGrp.Controls.Add(Me.Panel4)
        Me.Tab_AccGrp.Controls.Add(Me.Panel2)
        Me.Tab_AccGrp.Controls.Add(Me.Txt_Group_Order)
        Me.Tab_AccGrp.Controls.Add(Me.Label4)
        Me.Tab_AccGrp.Controls.Add(Me.Txt_GroupName)
        Me.Tab_AccGrp.Controls.Add(Me.Label3)
        Me.Tab_AccGrp.Controls.Add(Me.Btn_Find)
        Me.Tab_AccGrp.Controls.Add(Me.Txt_GroupID)
        Me.Tab_AccGrp.Controls.Add(Me.Label2)
        Me.Tab_AccGrp.Location = New System.Drawing.Point(4, 22)
        Me.Tab_AccGrp.Name = "Tab_AccGrp"
        Me.Tab_AccGrp.Padding = New System.Windows.Forms.Padding(3)
        Me.Tab_AccGrp.Size = New System.Drawing.Size(610, 312)
        Me.Tab_AccGrp.TabIndex = 0
        Me.Tab_AccGrp.Text = "Account Group Settings"
        Me.Tab_AccGrp.UseVisualStyleBackColor = True
        '
        'Grid_Searchhelper1
        '
        Me.Grid_Searchhelper1.BackColor = System.Drawing.Color.RoyalBlue
        Me.Grid_Searchhelper1.Location = New System.Drawing.Point(217, 69)
        Me.Grid_Searchhelper1.Name = "Grid_Searchhelper1"
        Me.Grid_Searchhelper1.Padding = New System.Windows.Forms.Padding(1)
        Me.Grid_Searchhelper1.Search_Query = ""
        Me.Grid_Searchhelper1.Size = New System.Drawing.Size(105, 27)
        Me.Grid_Searchhelper1.TabIndex = 98
        Me.Grid_Searchhelper1.Visible = False
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.ForeColor = System.Drawing.Color.OrangeRed
        Me.Label17.Location = New System.Drawing.Point(74, 41)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(14, 13)
        Me.Label17.TabIndex = 97
        Me.Label17.Text = "*"
        '
        'Dgrd_History
        '
        Me.Dgrd_History.AllowUserToAddRows = False
        Me.Dgrd_History.AllowUserToDeleteRows = False
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(252, Byte), Integer))
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.Color.Navy
        Me.Dgrd_History.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle4
        Me.Dgrd_History.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Dgrd_History.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(87, Byte), Integer), CType(CType(157, Byte), Integer))
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgrd_History.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle5
        Me.Dgrd_History.ColumnHeadersHeight = 20
        Me.Dgrd_History.Location = New System.Drawing.Point(6, 165)
        Me.Dgrd_History.MultiSelect = False
        Me.Dgrd_History.Name = "Dgrd_History"
        Me.Dgrd_History.ReadOnly = True
        Me.Dgrd_History.RowHeadersVisible = False
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(254, Byte), Integer))
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.Color.Navy
        Me.Dgrd_History.RowsDefaultCellStyle = DataGridViewCellStyle6
        Me.Dgrd_History.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.Dgrd_History.Size = New System.Drawing.Size(599, 139)
        Me.Dgrd_History.TabIndex = 62
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Panel4.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.F2_Button
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Controls.Add(Me.Lbl_Tran_Mode1)
        Me.Panel4.ForeColor = System.Drawing.Color.White
        Me.Panel4.Location = New System.Drawing.Point(380, 15)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(74, 21)
        Me.Panel4.TabIndex = 61
        '
        'Lbl_Tran_Mode1
        '
        Me.Lbl_Tran_Mode1.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode1.Location = New System.Drawing.Point(2, 1)
        Me.Lbl_Tran_Mode1.Name = "Lbl_Tran_Mode1"
        Me.Lbl_Tran_Mode1.Size = New System.Drawing.Size(68, 16)
        Me.Lbl_Tran_Mode1.TabIndex = 0
        Me.Lbl_Tran_Mode1.Text = "NEW MODE"
        Me.Lbl_Tran_Mode1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Panel2.Controls.Add(Me.Btn_Clear)
        Me.Panel2.Controls.Add(Me.Btn_Close)
        Me.Panel2.Controls.Add(Me.Btn_Delete)
        Me.Panel2.Controls.Add(Me.Btn_Save)
        Me.Panel2.ForeColor = System.Drawing.Color.White
        Me.Panel2.Location = New System.Drawing.Point(542, 15)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(62, 126)
        Me.Panel2.TabIndex = 60
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(3, 64)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear.TabIndex = 7
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(3, 95)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 8
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Delete
        '
        Me.Btn_Delete.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Delete.Location = New System.Drawing.Point(3, 34)
        Me.Btn_Delete.Name = "Btn_Delete"
        Me.Btn_Delete.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Delete.TabIndex = 6
        Me.Btn_Delete.Text = "&Delete"
        Me.Btn_Delete.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(3, 4)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save.TabIndex = 5
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Txt_Group_Order
        '
        Me.Txt_Group_Order.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Group_Order.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Group_Order.Location = New System.Drawing.Point(108, 69)
        Me.Txt_Group_Order.MaxLength = 50
        Me.Txt_Group_Order.Name = "Txt_Group_Order"
        Me.Txt_Group_Order.Size = New System.Drawing.Size(68, 21)
        Me.Txt_Group_Order.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Location = New System.Drawing.Point(3, 71)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(76, 13)
        Me.Label4.TabIndex = 38
        Me.Label4.Text = "Group Order"
        '
        'Txt_GroupName
        '
        Me.Txt_GroupName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_GroupName.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_GroupName.Location = New System.Drawing.Point(108, 42)
        Me.Txt_GroupName.MaxLength = 50
        Me.Txt_GroupName.Name = "Txt_GroupName"
        Me.Txt_GroupName.Size = New System.Drawing.Size(346, 21)
        Me.Txt_GroupName.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Location = New System.Drawing.Point(3, 44)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(76, 13)
        Me.Label3.TabIndex = 36
        Me.Label3.Text = "Group Name"
        '
        'Btn_Find
        '
        Me.Btn_Find.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.F2_Button
        Me.Btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find.ForeColor = System.Drawing.Color.White
        Me.Btn_Find.Location = New System.Drawing.Point(217, 15)
        Me.Btn_Find.Name = "Btn_Find"
        Me.Btn_Find.Size = New System.Drawing.Size(29, 21)
        Me.Btn_Find.TabIndex = 2
        Me.Btn_Find.TabStop = False
        Me.Btn_Find.Text = "F2"
        Me.Btn_Find.UseVisualStyleBackColor = False
        '
        'Txt_GroupID
        '
        Me.Txt_GroupID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_GroupID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_GroupID.Location = New System.Drawing.Point(108, 15)
        Me.Txt_GroupID.MaxLength = 50
        Me.Txt_GroupID.Name = "Txt_GroupID"
        Me.Txt_GroupID.Size = New System.Drawing.Size(105, 21)
        Me.Txt_GroupID.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Location = New System.Drawing.Point(3, 17)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(57, 13)
        Me.Label2.TabIndex = 33
        Me.Label2.Text = "Group ID"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(3, 4)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(223, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "A c c o u n t   H e a d   D e t a i l s"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Panel1.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Menu_Bkg
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(686, 20)
        Me.Panel1.TabIndex = 5
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Left
        Me.PictureBox1.Location = New System.Drawing.Point(0, 20)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(53, 343)
        Me.PictureBox1.TabIndex = 24
        Me.PictureBox1.TabStop = False
        '
        'Account_Head_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.LeftGradiant
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(686, 363)
        Me.Controls.Add(Me.Panel6)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Tab_AccountHead)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Account_Head_Frm"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Panel5.ResumeLayout(False)
        Me.Tab_AccHead.ResumeLayout(False)
        Me.Tab_AccHead.PerformLayout()
        CType(Me.Dgrd_History1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Tran_mode_Pnl.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Tab_AccountHead.ResumeLayout(False)
        Me.Tab_AccGrp.ResumeLayout(False)
        Me.Tab_AccGrp.PerformLayout()
        CType(Me.Dgrd_History, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Btn_AccountGroup As System.Windows.Forms.Button
    Friend WithEvents Btn_AccountMaster As System.Windows.Forms.Button
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Tab_AccHead As System.Windows.Forms.TabPage
    Friend WithEvents Txt_ShortName As System.Windows.Forms.TextBox
    Friend WithEvents Dgrd_History1 As System.Windows.Forms.DataGridView
    Friend WithEvents Txt_HeadOrder As System.Windows.Forms.TextBox
    Friend WithEvents Txt_AccountHead As System.Windows.Forms.TextBox
    Friend WithEvents Txt_HeadID As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Cmb_ALEI As System.Windows.Forms.ComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Tran_mode_Pnl As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode2 As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear1 As System.Windows.Forms.Button
    Friend WithEvents Btn_Close1 As System.Windows.Forms.Button
    Friend WithEvents Btn_Delete1 As System.Windows.Forms.Button
    Friend WithEvents Btn_Save1 As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Cmb_GroupName As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Btn_Find1 As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Tab_AccountHead As System.Windows.Forms.TabControl
    Friend WithEvents Tab_AccGrp As System.Windows.Forms.TabPage
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Dgrd_History As System.Windows.Forms.DataGridView
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode1 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Delete As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Txt_Group_Order As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Txt_GroupName As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Btn_Find As System.Windows.Forms.Button
    Friend WithEvents Txt_GroupID As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Grid_Searchhelper1 As REAL_CLINIC.Grid_Searchhelper
    Friend WithEvents Grid_Searchhelper2 As REAL_CLINIC.Grid_Searchhelper
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
End Class
