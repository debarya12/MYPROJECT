﻿
Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls

Public Class Bank_Accounts_Reg_Frm

#Region "Declarations"
    'Object of Employee Details Bussiness Layer

    Private hms_helper As HMS_Helper = Nothing
    Private Bank_Master_BL As Bank_Master_BL_Cls
    Private Bank_Acc_Reg_BL As Bank_Account_Register_BL_Cls
    Private mTr_Mode As Tran_Mode

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing
    Private IsHandleAdded As Boolean

    Private CellRowindex As Integer
    Private CellColindex As Integer


    Private GrDtbl As DataTable

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_BankAcc_ID.BackColor = Color.White
                    Me.Txt_BankAcc_ID.ReadOnly = False
                    Cmb_Acc_Type.Enabled = True
                    Cmb_Bank_Name.Enabled = True

                    'Me.Txt_BankName.BackColor = Color.White
                    'Me.Txt_BankName.ReadOnly = False
                    'Me.Txt_BranchName.ReadOnly = False
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_BankAcc_ID.BackColor = Color.Silver
                    Me.Txt_BankAcc_ID.ReadOnly = True
                    Cmb_Acc_Type.Enabled = False
                    Cmb_Bank_Name.Enabled = False

                    'Me.Txt_BankName.BackColor = Color.Silver
                    'Me.Txt_BankName.ReadOnly = True
                    'Me.Txt_BranchName.ReadOnly = True
            End Select
        End Set
    End Property

#End Region

#Region "Methods"

    Private Sub Clear_Form()
        Try
            Txt_BankAcc_ID.Text = ""
            Txt_BankAddress.Text = ""
            Txt_AccNo.Text = ""
            Txt_Balance.Text = ""
            Txt_Remarks.Text = ""
            Cmb_Bank_Name.SelectedIndex = 0
            Cmb_Active.SelectedIndex = 0
            Cmb_Payment_Mode.SelectedIndex = 0
            Cmb_Acc_Type.SelectedIndex = 0
            Dtp_OpDate.Value = Tran_Date
            Tr_Mode = Tran_Mode.New_Mode
            Btn_Save.Enabled = True
            Btn_Delete.Enabled = False
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Function Locate_Values() As Boolean
        Try
            Dim dtbl As DataTable = Nothing
            Bank_Acc_Reg_BL = New Bank_Account_Register_BL_Cls

            If Bank_Acc_Reg_BL.Get_bank_Account_Master(dtbl, Txt_BankAcc_ID.Text.Trim, Branch_Code) Then

                Cmb_Bank_Name.SelectedValue = dtbl.Rows(0).Item("Bank_ID").ToString
                Txt_AccNo.Text = dtbl.Rows(0).Item("Acc_No").ToString
                Cmb_Acc_Type.SelectedValue = dtbl.Rows(0).Item("Acc_Type").ToString
                Dtp_OpDate.Value = dtbl.Rows(0).Item("Opening_Date").ToString
                Txt_Balance.Text = dtbl.Rows(0).Item("Acc_Balance").ToString
                Txt_Remarks.Text = dtbl.Rows(0).Item("Remarks").ToString
                Cmb_Active.SelectedIndex = IIf(dtbl.Rows(0).Item("Active").ToString = "Y", 0, 1)
                If Bank_Acc_Reg_BL.Get_BankAccount_PaymentMode(dtbl, dtbl.Rows(0).Item("Tran_BatchID").ToString, Branch_Code) Then
                    Cmb_Payment_Mode.SelectedValue = dtbl.Rows(0).Item(0).ToString
                End If
            End If

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Validate_Fields() As Boolean
        Try
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If

            If Tr_Mode <> Tran_Mode.New_Mode Then
                If Txt_BankAcc_ID.Text.Trim = "" Then MessageBox.Show("Invalid Bank Account Id,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_BankAcc_ID.Focus() : Return False
            End If
            'Assigning Default values
            If Cmb_Bank_Name.SelectedIndex = 0 Then MessageBox.Show("Invalid Bank Name, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_Bank_Name.Focus() : Return False
            If Cmb_Acc_Type.SelectedIndex = 0 Then MessageBox.Show("Invalid Account Type, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_Acc_Type.Focus() : Return False
            If Txt_AccNo.Text.Trim = "" Then MessageBox.Show("Invalid Account Number, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_AccNo.Focus() : Return False
            If Cmb_Payment_Mode.SelectedIndex = 0 Then MessageBox.Show("Invalid Mode of Payment, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_Payment_Mode.Focus() : Return False
            If Val(Txt_Balance.Text) <= 0 Then MessageBox.Show("Invalid Balance Amount, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Balance.Focus() : Return False


            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Sub Fill_BankAcc_Grid()
        Try
            Bank_Acc_Reg_BL = New Bank_Account_Register_BL_Cls
            Dtbl = Nothing
            If Bank_Acc_Reg_BL.Get_Bank_Account_Register_All(Dtbl, Branch_Code) Then
                Dgvw_Bank_Account_Master.DataSource = Dtbl
                Dgvw_Bank_Account_Master.Columns(0).Width = 200
                Dgvw_Bank_Account_Master.Columns(1).Width = 150
                Dgvw_Bank_Account_Master.Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                Dgvw_Bank_Account_Master.Refresh()
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

#End Region

    Private Sub Bank_Accounts_Reg_Frm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try

            Bank_Master_BL = New Bank_Master_BL_Cls

            hms_helper = New Hms_Helperimpliments
            Call hms_helper.Fill_GenData(Cmb_Acc_Type, Gendatatype.BankAccount_Type, "< Select >")
            Call hms_helper.Fill_GenData(Cmb_Payment_Mode, Gendatatype.Payment_Mode, "< Select >")

            Cmb_Active.Items.Add("Yes")
            Cmb_Active.Items.Add("No")
            Cmb_Active.SelectedIndex = 0

            Call hms_helper.Fill_Investment_Banks(Cmb_Bank_Name, "< Select >")

            Call Fill_BankAcc_Grid()
            Pnl_BankAccountdet.Enabled = False
            Txt_BankAcc_ID.Focus()
            Dtp_OpDate.Value = Tran_Date


        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_EmpID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try

            If Txt_BankAcc_ID.Text.Trim = "" Then
                Call Clear_Form()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub DoctorMaster_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then Call SendKeyTab()
    End Sub

    Private Sub DoctorMaster_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try
            Dim dtbl As DataTable = Nothing

            'Validating Data controls
            If Not Validate_Fields() Then Exit Sub

            Bank_Acc_Reg_BL = New Bank_Account_Register_BL_Cls

            Bank_Acc_Reg_BL.BankAcc_ID = Val(Txt_BankAcc_ID.Text.Trim)
            Bank_Acc_Reg_BL.Bank_ID = Cmb_Bank_Name.SelectedValue
            Bank_Acc_Reg_BL.Acc_No = Txt_AccNo.Text.Trim
            Bank_Acc_Reg_BL.Acc_Type = Cmb_Acc_Type.SelectedValue
            Bank_Acc_Reg_BL.Opening_Date = Tran_Date
            Bank_Acc_Reg_BL.Acc_Balance = Val(Txt_Balance.Text)
            Bank_Acc_Reg_BL.Closed = "N"
            Bank_Acc_Reg_BL.Closed_Date = Tran_Date
            Bank_Acc_Reg_BL.Last_TrDate = Tran_Date
            Bank_Acc_Reg_BL.Active = Strings.Left(Cmb_Active.Text, 1).Trim.ToUpper
            Bank_Acc_Reg_BL.Tran_BatchID = " "
            Bank_Acc_Reg_BL.Remarks = Txt_Remarks.Text
            Bank_Acc_Reg_BL.Tr_Pay_Mode = Cmb_Payment_Mode.SelectedValue


            If Bank_Acc_Reg_BL.Save_Bank_Account_Reg(Dtbl, Tr_Mode) Then
                If Dtbl.Rows(0).Item(0).ToString = "0" Then
                    MessageBox.Show("Bank Account Register Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Exit Sub
                End If
                Txt_BankAcc_ID.Text = Dtbl.Rows(0).Item(1).ToString
                Tr_Mode = Tran_Mode.Edit_Mode
                MessageBox.Show("Bank Account Register Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Btn_Clear.Focus()
                Call Fill_BankAcc_Grid()
            Else
                MessageBox.Show("Bank Account Register Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Exit Sub
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try
            If Txt_BankAcc_ID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "200|200|50|"
                Sql = "SELECT     [Bank Name], BankAcc_ID AS [bank Account ID], Acc_No AS [Account No], Acc_Balance AS [Balance Amount]  FROM Get_Bank_Account_Master_Vw where Br_Code = " & Branch_Code & ""
                Call ShowSearchengine(Txt_BankAcc_ID, Sql, 1, "Bank Name", Colwidth, , 0)
            End If

            'Validating Mandatory fields for locating
            If Txt_BankAcc_ID.Text.Trim = "" Then
                'MessageBox.Show("Invalid Employee ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_BankAcc_ID.Focus() : Exit Sub
            End If


            If Locate_Values() Then
                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Delete.Enabled = True
            Else
                MessageBox.Show("Account Number does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Call Clear_Form()
        Txt_BankAcc_ID.Focus()
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

    Private Sub Dgvw_Emp_AccountMaster_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Dgvw_Bank_Account_Master.DoubleClick
        Try


            With Dgvw_Bank_Account_Master
                If .CurrentRow Is Nothing Then Exit Sub
                Txt_BankAcc_ID.Text = .Item(6, .CurrentCell.RowIndex).Value.ToString.Trim
                Call Btn_Find_Click(sender, e)
            End With

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click
        Try
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If


            'Validating Mandatory fields for Deleting
            If Tr_Mode = Tran_Mode.New_Mode Then
                MessageBox.Show("You have to locate details before deleting the record", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            If Txt_BankAcc_ID.Text.Trim = "" Then
                MessageBox.Show("Invalid Bank ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_BankAcc_ID.Focus() : Exit Sub
            End If

            'Confirm before delete the record
            If MessageBox.Show("Are you sure wan't to delete the selected Account", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = Windows.Forms.DialogResult.No Then
                Exit Sub
            End If
            Bank_Master_BL = New Bank_Master_BL_Cls
            Dim dtbl As DataTable = Nothing

            If Bank_Master_BL.Delete_Bank_Master(dtbl, Txt_BankAcc_ID.Text.Trim) Then
                If dtbl.Rows(0).Item(0).ToString = "0" Then
                    MessageBox.Show("You cannot delete this Bank Master details" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
                MessageBox.Show("Bank Master Deleted", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Call Btn_Clear_Click(sender, e)
                Call Fill_BankAcc_Grid()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_AccountNo_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_BankAcc_ID.KeyDown
        If e.KeyCode = Keys.F2 Then Btn_Find_Click(sender, e)
    End Sub

    Private Sub Cmb_Bank_Name_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_Bank_Name.SelectedIndexChanged
        Try
            If Cmb_Bank_Name.SelectedIndex = 0 Then Txt_BankAddress.Text = "" : Pnl_BankAccountdet.Enabled = False : Exit Sub
            Pnl_BankAccountdet.Enabled = True
            Bank_Master_BL = New Bank_Master_BL_Cls
            Dim dtbl As DataTable = Nothing

            If Bank_Master_BL.Get_Bank_Master(dtbl, Cmb_Bank_Name.SelectedValue) Then
                Txt_BankAddress.Text = dtbl.Rows(0).Item("Bank_Name").ToString
                Txt_BankAddress.Text += vbCrLf + dtbl.Rows(0).Item("Branch_Name").ToString + " Branch "
                Txt_BankAddress.Text += vbCrLf + dtbl.Rows(0).Item("Address").ToString

            End If


        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_AccNo_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_AccNo.Validating
        Try
            If Txt_AccNo.Text <> "" Then
                Dim dtbl As DataTable
                Bank_Acc_Reg_BL = New Bank_Account_Register_BL_Cls
                dtbl = Nothing

                If Bank_Acc_Reg_BL.Is_Account_No_Exist(dtbl, Txt_AccNo.Text.Trim, Cmb_Acc_Type.SelectedValue, _
                                                       Cmb_Bank_Name.SelectedValue, _
                                                       Branch_Code) Then
                    If dtbl.Rows.Count > 0 Then

                        MessageBox.Show("Account Number already exist for this Type/bank,Please Check", _
                                        Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                        Txt_AccNo.Text = ""
                        e.Cancel = True
                        Exit Sub
                    End If

                End If
            End If


        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgvw_Bank_Account_Master_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgvw_Bank_Account_Master.CellContentClick

    End Sub
End Class
