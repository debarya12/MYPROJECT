﻿Public Class Patient_Diagnosis

End Class