﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Insuarance_Claim_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Insuarance_Claim_Frm))
        Me.Pnl_Header = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Txt_InsClaim_ID = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel()
        Me.Btn_Clear = New System.Windows.Forms.Button()
        Me.Btn_Close = New System.Windows.Forms.Button()
        Me.Btn_Delete = New System.Windows.Forms.Button()
        Me.Btn_Save = New System.Windows.Forms.Button()
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel()
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label()
        Me.Btn_FindID = New System.Windows.Forms.Button()
        Me.Dtp_Company_RegDt = New System.Windows.Forms.DateTimePicker()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Cmb_Approved = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Txt_Company_Address = New System.Windows.Forms.TextBox()
        Me.Btn_Tab2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Txt_RefNO = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Txt_CoverageAmt = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Txt_ClaimAmount = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Cmb_Insur_Comp = New System.Windows.Forms.ComboBox()
        Me.Cmb_Insur_Schem = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Txt_PMRID = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Btn_Find1 = New System.Windows.Forms.Button()
        Me.Patient_Info1 = New REAL_CLINIC.Patient_Info()
        Me.Pnl_Header.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.Pnl_Tran_mode.SuspendLayout()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.Controls.Add(Me.Label3)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(563, 24)
        Me.Pnl_Header.TabIndex = 10000
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(3, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(181, 18)
        Me.Label3.TabIndex = 10000
        Me.Label3.Text = "I n s u r a n c e  C l a i m"
        '
        'Txt_InsClaim_ID
        '
        Me.Txt_InsClaim_ID.BackColor = System.Drawing.Color.White
        Me.Txt_InsClaim_ID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_InsClaim_ID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_InsClaim_ID.ForeColor = System.Drawing.Color.Black
        Me.Txt_InsClaim_ID.Location = New System.Drawing.Point(112, 51)
        Me.Txt_InsClaim_ID.MaxLength = 10
        Me.Txt_InsClaim_ID.Name = "Txt_InsClaim_ID"
        Me.Txt_InsClaim_ID.Size = New System.Drawing.Size(116, 21)
        Me.Txt_InsClaim_ID.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(4, 55)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(20, 13)
        Me.Label2.TabIndex = 115
        Me.Label2.Text = "ID"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(6, 228)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(95, 13)
        Me.Label1.TabIndex = 117
        Me.Label1.Text = "Company Name"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Delete)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(6, 436)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(230, 37)
        Me.Pnl_Common_Btn.TabIndex = 8
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(113, 3)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear.TabIndex = 2
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(169, 3)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 3
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Delete
        '
        Me.Btn_Delete.BackgroundImage = CType(resources.GetObject("Btn_Delete.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Delete.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Delete.Location = New System.Drawing.Point(58, 3)
        Me.Btn_Delete.Name = "Btn_Delete"
        Me.Btn_Delete.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Delete.TabIndex = 1
        Me.Btn_Delete.Text = "Delete"
        Me.Btn_Delete.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = CType(resources.GetObject("Btn_Save.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(2, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save.TabIndex = 0
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(478, 51)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(74, 21)
        Me.Pnl_Tran_mode.TabIndex = 30000
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(1, 1)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(68, 16)
        Me.Lbl_Tran_Mode.TabIndex = 126
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Btn_FindID
        '
        Me.Btn_FindID.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_FindID.BackgroundImage = CType(resources.GetObject("Btn_FindID.BackgroundImage"), System.Drawing.Image)
        Me.Btn_FindID.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_FindID.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_FindID.ForeColor = System.Drawing.Color.White
        Me.Btn_FindID.Location = New System.Drawing.Point(229, 51)
        Me.Btn_FindID.Name = "Btn_FindID"
        Me.Btn_FindID.Size = New System.Drawing.Size(29, 21)
        Me.Btn_FindID.TabIndex = 100000
        Me.Btn_FindID.TabStop = False
        Me.Btn_FindID.Text = "F2"
        Me.Btn_FindID.UseVisualStyleBackColor = False
        '
        'Dtp_Company_RegDt
        '
        Me.Dtp_Company_RegDt.Cursor = System.Windows.Forms.Cursors.Default
        Me.Dtp_Company_RegDt.CustomFormat = "dd/MM/yyyy"
        Me.Dtp_Company_RegDt.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_Company_RegDt.Location = New System.Drawing.Point(375, 51)
        Me.Dtp_Company_RegDt.Name = "Dtp_Company_RegDt"
        Me.Dtp_Company_RegDt.Size = New System.Drawing.Size(97, 21)
        Me.Dtp_Company_RegDt.TabIndex = 11
        Me.Dtp_Company_RegDt.TabStop = False
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.Color.Transparent
        Me.Label20.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label20.Location = New System.Drawing.Point(334, 53)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(34, 13)
        Me.Label20.TabIndex = 100020
        Me.Label20.Text = "Date"
        '
        'Cmb_Approved
        '
        Me.Cmb_Approved.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Approved.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Approved.FormattingEnabled = True
        Me.Cmb_Approved.Location = New System.Drawing.Point(112, 336)
        Me.Cmb_Approved.Name = "Cmb_Approved"
        Me.Cmb_Approved.Size = New System.Drawing.Size(116, 21)
        Me.Cmb_Approved.TabIndex = 4
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(5, 339)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(62, 13)
        Me.Label5.TabIndex = 100010
        Me.Label5.Text = "Approved"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(6, 254)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(53, 13)
        Me.Label4.TabIndex = 100009
        Me.Label4.Text = "Address"
        '
        'Txt_Company_Address
        '
        Me.Txt_Company_Address.BackColor = System.Drawing.Color.White
        Me.Txt_Company_Address.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Company_Address.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Company_Address.Location = New System.Drawing.Point(113, 252)
        Me.Txt_Company_Address.MaxLength = 500
        Me.Txt_Company_Address.Multiline = True
        Me.Txt_Company_Address.Name = "Txt_Company_Address"
        Me.Txt_Company_Address.ReadOnly = True
        Me.Txt_Company_Address.Size = New System.Drawing.Size(360, 49)
        Me.Txt_Company_Address.TabIndex = 2
        '
        'Btn_Tab2
        '
        Me.Btn_Tab2.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Tab2.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Tab2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Tab2.ForeColor = System.Drawing.Color.White
        Me.Btn_Tab2.Location = New System.Drawing.Point(112, 31)
        Me.Btn_Tab2.Name = "Btn_Tab2"
        Me.Btn_Tab2.Size = New System.Drawing.Size(441, 10)
        Me.Btn_Tab2.TabIndex = 100021
        Me.Btn_Tab2.TabStop = False
        Me.Btn_Tab2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Button1.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(112, 370)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(441, 10)
        Me.Button1.TabIndex = 24
        Me.Button1.TabStop = False
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label9.Location = New System.Drawing.Point(3, 27)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(121, 16)
        Me.Label9.TabIndex = 100023
        Me.Label9.Text = "Basic Information"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label10.Location = New System.Drawing.Point(5, 367)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(89, 16)
        Me.Label10.TabIndex = 100024
        Me.Label10.Text = "Claim Details"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Txt_RefNO
        '
        Me.Txt_RefNO.BackColor = System.Drawing.Color.White
        Me.Txt_RefNO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_RefNO.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_RefNO.Location = New System.Drawing.Point(338, 336)
        Me.Txt_RefNO.MaxLength = 100
        Me.Txt_RefNO.Name = "Txt_RefNO"
        Me.Txt_RefNO.Size = New System.Drawing.Size(135, 21)
        Me.Txt_RefNO.TabIndex = 5
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.ForeColor = System.Drawing.Color.White
        Me.Label13.Location = New System.Drawing.Point(288, 339)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(43, 13)
        Me.Label13.TabIndex = 100036
        Me.Label13.Text = "Ref No"
        '
        'Txt_CoverageAmt
        '
        Me.Txt_CoverageAmt.BackColor = System.Drawing.Color.White
        Me.Txt_CoverageAmt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_CoverageAmt.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_CoverageAmt.Location = New System.Drawing.Point(379, 382)
        Me.Txt_CoverageAmt.MaxLength = 11
        Me.Txt_CoverageAmt.Name = "Txt_CoverageAmt"
        Me.Txt_CoverageAmt.Size = New System.Drawing.Size(173, 21)
        Me.Txt_CoverageAmt.TabIndex = 7
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label15.Location = New System.Drawing.Point(264, 388)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(109, 13)
        Me.Label15.TabIndex = 100035
        Me.Label15.Text = "Coverage Amount"
        '
        'Txt_ClaimAmount
        '
        Me.Txt_ClaimAmount.BackColor = System.Drawing.Color.White
        Me.Txt_ClaimAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_ClaimAmount.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_ClaimAmount.Location = New System.Drawing.Point(112, 386)
        Me.Txt_ClaimAmount.MaxLength = 250
        Me.Txt_ClaimAmount.Name = "Txt_ClaimAmount"
        Me.Txt_ClaimAmount.Size = New System.Drawing.Size(146, 21)
        Me.Txt_ClaimAmount.TabIndex = 6
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label19.Location = New System.Drawing.Point(5, 389)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(86, 13)
        Me.Label19.TabIndex = 100026
        Me.Label19.Text = "Claim Amount"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.BackColor = System.Drawing.Color.Transparent
        Me.Label32.ForeColor = System.Drawing.Color.Red
        Me.Label32.Location = New System.Drawing.Point(93, 220)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(14, 13)
        Me.Label32.TabIndex = 100045
        Me.Label32.Text = "*"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.BackColor = System.Drawing.Color.Transparent
        Me.Label25.ForeColor = System.Drawing.Color.Red
        Me.Label25.Location = New System.Drawing.Point(93, 254)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(14, 13)
        Me.Label25.TabIndex = 100046
        Me.Label25.Text = "*"
        '
        'Cmb_Insur_Comp
        '
        Me.Cmb_Insur_Comp.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Insur_Comp.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Insur_Comp.FormattingEnabled = True
        Me.Cmb_Insur_Comp.Location = New System.Drawing.Point(112, 225)
        Me.Cmb_Insur_Comp.Name = "Cmb_Insur_Comp"
        Me.Cmb_Insur_Comp.Size = New System.Drawing.Size(361, 21)
        Me.Cmb_Insur_Comp.TabIndex = 2
        '
        'Cmb_Insur_Schem
        '
        Me.Cmb_Insur_Schem.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Insur_Schem.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Insur_Schem.FormattingEnabled = True
        Me.Cmb_Insur_Schem.Location = New System.Drawing.Point(112, 307)
        Me.Cmb_Insur_Schem.Name = "Cmb_Insur_Schem"
        Me.Cmb_Insur_Schem.Size = New System.Drawing.Size(361, 21)
        Me.Cmb_Insur_Schem.TabIndex = 3
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(6, 310)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(46, 13)
        Me.Label6.TabIndex = 100063
        Me.Label6.Text = "Sheme"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(4, 111)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(90, 13)
        Me.Label7.TabIndex = 100064
        Me.Label7.Text = "Patient Details"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Txt_PMRID
        '
        Me.Txt_PMRID.BackColor = System.Drawing.Color.White
        Me.Txt_PMRID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_PMRID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PMRID.ForeColor = System.Drawing.Color.Black
        Me.Txt_PMRID.Location = New System.Drawing.Point(112, 76)
        Me.Txt_PMRID.MaxLength = 10
        Me.Txt_PMRID.Name = "Txt_PMRID"
        Me.Txt_PMRID.Size = New System.Drawing.Size(116, 21)
        Me.Txt_PMRID.TabIndex = 1
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(4, 80)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(45, 13)
        Me.Label8.TabIndex = 100066
        Me.Label8.Text = "PMRID"
        '
        'Btn_Find1
        '
        Me.Btn_Find1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find1.BackgroundImage = CType(resources.GetObject("Btn_Find1.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find1.ForeColor = System.Drawing.Color.White
        Me.Btn_Find1.Location = New System.Drawing.Point(229, 76)
        Me.Btn_Find1.Name = "Btn_Find1"
        Me.Btn_Find1.Size = New System.Drawing.Size(29, 21)
        Me.Btn_Find1.TabIndex = 100067
        Me.Btn_Find1.TabStop = False
        Me.Btn_Find1.Text = "F2"
        Me.Btn_Find1.UseVisualStyleBackColor = False
        '
        'Patient_Info1
        '
        Me.Patient_Info1.BackColor = System.Drawing.Color.AliceBlue
        Me.Patient_Info1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Patient_Info1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Patient_Info1.ForeColor = System.Drawing.Color.Blue
        Me.Patient_Info1.Location = New System.Drawing.Point(112, 100)
        Me.Patient_Info1.Name = "Patient_Info1"
        Me.Patient_Info1.Padding = New System.Windows.Forms.Padding(2)
        Me.Patient_Info1.Size = New System.Drawing.Size(441, 119)
        Me.Patient_Info1.TabIndex = 100061
        '
        'Insuarance_Claim_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Highlight
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(563, 481)
        Me.Controls.Add(Me.Btn_Find1)
        Me.Controls.Add(Me.Txt_PMRID)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Cmb_Insur_Schem)
        Me.Controls.Add(Me.Patient_Info1)
        Me.Controls.Add(Me.Cmb_Insur_Comp)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label32)
        Me.Controls.Add(Me.Txt_RefNO)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Txt_CoverageAmt)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Txt_ClaimAmount)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Btn_Tab2)
        Me.Controls.Add(Me.Dtp_Company_RegDt)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Cmb_Approved)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Txt_Company_Address)
        Me.Controls.Add(Me.Pnl_Tran_mode)
        Me.Controls.Add(Me.Btn_FindID)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Txt_InsClaim_ID)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Insuarance_Claim_Frm"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.Pnl_Tran_mode.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Txt_InsClaim_ID As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Delete As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Btn_FindID As System.Windows.Forms.Button
    Friend WithEvents Dtp_Company_RegDt As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Approved As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Txt_Company_Address As System.Windows.Forms.TextBox
    Friend WithEvents Btn_Tab2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Txt_RefNO As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Txt_CoverageAmt As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Txt_ClaimAmount As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label


    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Insur_Comp As System.Windows.Forms.ComboBox
    Friend WithEvents Patient_Info1 As REAL_CLINIC.Patient_Info
    Friend WithEvents Cmb_Insur_Schem As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Txt_PMRID As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Btn_Find1 As System.Windows.Forms.Button
End Class
