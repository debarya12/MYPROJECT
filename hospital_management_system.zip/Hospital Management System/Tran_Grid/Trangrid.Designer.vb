﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Trangrid
    Inherits System.Windows.Forms.UserControl

    'UserControl1 overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Tr_GridView = New System.Windows.Forms.DataGridView
        Me.Particulars = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Paymode = New System.Windows.Forms.DataGridViewComboBoxColumn
        Me.Amount = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.GL_Code = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Def_Trantype = New System.Windows.Forms.DataGridViewTextBoxColumn
        CType(Me.Tr_GridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Tr_GridView
        '
        Me.Tr_GridView.AllowUserToAddRows = False
        Me.Tr_GridView.AllowUserToDeleteRows = False
        Me.Tr_GridView.AllowUserToResizeColumns = False
        Me.Tr_GridView.AllowUserToResizeRows = False
        Me.Tr_GridView.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(247, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(253, Byte), Integer))
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(89, Byte), Integer), CType(CType(124, Byte), Integer), CType(CType(183, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Tr_GridView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.Tr_GridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Tr_GridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Particulars, Me.Paymode, Me.Amount, Me.GL_Code, Me.Def_Trantype})
        Me.Tr_GridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Tr_GridView.Location = New System.Drawing.Point(0, 0)
        Me.Tr_GridView.Name = "Tr_GridView"
        Me.Tr_GridView.RowHeadersVisible = False
        Me.Tr_GridView.Size = New System.Drawing.Size(403, 166)
        Me.Tr_GridView.TabIndex = 2
        '
        'Particulars
        '
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        Me.Particulars.DefaultCellStyle = DataGridViewCellStyle2
        Me.Particulars.HeaderText = "Particulars"
        Me.Particulars.MinimumWidth = 150
        Me.Particulars.Name = "Particulars"
        Me.Particulars.ReadOnly = True
        Me.Particulars.Width = 190
        '
        'Paymode
        '
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Paymode.DefaultCellStyle = DataGridViewCellStyle3
        Me.Paymode.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox
        Me.Paymode.HeaderText = "Paymode"
        Me.Paymode.MinimumWidth = 100
        Me.Paymode.Name = "Paymode"
        '
        'Amount
        '
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle4.Format = "N2"
        DataGridViewCellStyle4.NullValue = Nothing
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Amount.DefaultCellStyle = DataGridViewCellStyle4
        Me.Amount.HeaderText = "Amount"
        Me.Amount.MinimumWidth = 100
        Me.Amount.Name = "Amount"
        Me.Amount.Width = 110
        '
        'GL_Code
        '
        Me.GL_Code.HeaderText = "Gl_Code"
        Me.GL_Code.Name = "GL_Code"
        Me.GL_Code.Visible = False
        '
        'Def_Trantype
        '
        Me.Def_Trantype.HeaderText = "Def_Trantype"
        Me.Def_Trantype.Name = "Def_Trantype"
        Me.Def_Trantype.Visible = False
        '
        'Trangrid
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Controls.Add(Me.Tr_GridView)
        Me.Name = "Trangrid"
        Me.Size = New System.Drawing.Size(403, 166)
        CType(Me.Tr_GridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Tr_GridView As System.Windows.Forms.DataGridView
    Friend WithEvents Particulars As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Paymode As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents Amount As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents GL_Code As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Def_Trantype As System.Windows.Forms.DataGridViewTextBoxColumn

End Class
