﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Generaldatasave_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Generaldatasave_Frm))
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Cmb_Parentdata = New System.Windows.Forms.ComboBox
        Me.Txt_Datadescription = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.Pnl_Header.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = CType(resources.GetObject("Pnl_Header.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Header.Controls.Add(Me.Label1)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(439, 24)
        Me.Pnl_Header.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(7, 1)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(220, 16)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "G e n e r a l    D a t a    S e t t i n g s"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.Color.Indigo
        Me.Label5.Location = New System.Drawing.Point(3, 60)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(75, 13)
        Me.Label5.TabIndex = 60
        Me.Label5.Text = "Parent Data"
        '
        'Cmb_Parentdata
        '
        Me.Cmb_Parentdata.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Parentdata.FormattingEnabled = True
        Me.Cmb_Parentdata.Location = New System.Drawing.Point(81, 56)
        Me.Cmb_Parentdata.Name = "Cmb_Parentdata"
        Me.Cmb_Parentdata.Size = New System.Drawing.Size(355, 21)
        Me.Cmb_Parentdata.TabIndex = 1
        '
        'Txt_Datadescription
        '
        Me.Txt_Datadescription.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Datadescription.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Datadescription.Location = New System.Drawing.Point(81, 30)
        Me.Txt_Datadescription.Name = "Txt_Datadescription"
        Me.Txt_Datadescription.Size = New System.Drawing.Size(353, 21)
        Me.Txt_Datadescription.TabIndex = 0
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.Indigo
        Me.Label3.Location = New System.Drawing.Point(2, 33)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(71, 13)
        Me.Label3.TabIndex = 59
        Me.Label3.Text = "Description"
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BackgroundImage = CType(resources.GetObject("Pnl_Common_Btn.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(315, 81)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(120, 36)
        Me.Pnl_Common_Btn.TabIndex = 61
        '
        'Btn_Close
        '
        Me.Btn_Close.BackColor = System.Drawing.Color.Purple
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(59, 3)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 3
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = False
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.Purple
        Me.Btn_Save.BackgroundImage = CType(resources.GetObject("Btn_Save.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(3, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save.TabIndex = 2
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Generaldatasave_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(439, 121)
        Me.ControlBox = False
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Cmb_Parentdata)
        Me.Controls.Add(Me.Txt_Datadescription)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Generaldatasave_Frm"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Parentdata As System.Windows.Forms.ComboBox
    Friend WithEvents Txt_Datadescription As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
End Class
