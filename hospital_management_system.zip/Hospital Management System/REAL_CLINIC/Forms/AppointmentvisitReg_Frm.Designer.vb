﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AppointmentvisitReg_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(AppointmentvisitReg_Frm))
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Lbl_Heading = New System.Windows.Forms.Label
        Me.Cmb_Status = New System.Windows.Forms.ComboBox
        Me.Label26 = New System.Windows.Forms.Label
        Me.Pnl_Othersdetails = New System.Windows.Forms.Panel
        Me.Txt_Nationality = New System.Windows.Forms.Label
        Me.Txt_Gender = New System.Windows.Forms.Label
        Me.Txt_Visitor_Familyname = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Txt_Visitor_SSNO = New System.Windows.Forms.Label
        Me.Label35 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Txt_Visitor_Age = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Txt_Visitor_Mobile = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Txt_Visitor_Phone = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Txt_Visitor_Addr = New System.Windows.Forms.Label
        Me.Txt_Visitor_Name = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.Lbl_Date = New System.Windows.Forms.Label
        Me.Txt_Tokenno = New System.Windows.Forms.Label
        Me.Cmb_Service = New System.Windows.Forms.ComboBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Pnl_Doctors = New System.Windows.Forms.Panel
        Me.TlStrp_Doctors = New System.Windows.Forms.ToolStrip
        Me.Pnl_Apointments = New System.Windows.Forms.Panel
        Me.Dgrd_Appointment = New System.Windows.Forms.DataGridView
        Me.TOKEN = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Time = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Visitor = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Lbl_Wnos = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Label1 = New System.Windows.Forms.Label
        Me.Btn_Refresh = New System.Windows.Forms.Button
        Me.Lbl_OPValidator = New System.Windows.Forms.Label
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Pnl_Header.SuspendLayout()
        Me.Pnl_Othersdetails.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.Pnl_Doctors.SuspendLayout()
        Me.Pnl_Apointments.SuspendLayout()
        CType(Me.Dgrd_Appointment, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Menu_Bkg
        Me.Pnl_Header.Controls.Add(Me.Lbl_Heading)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(699, 21)
        Me.Pnl_Header.TabIndex = 0
        '
        'Lbl_Heading
        '
        Me.Lbl_Heading.AutoSize = True
        Me.Lbl_Heading.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Heading.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Heading.ForeColor = System.Drawing.Color.White
        Me.Lbl_Heading.Location = New System.Drawing.Point(3, 2)
        Me.Lbl_Heading.Name = "Lbl_Heading"
        Me.Lbl_Heading.Size = New System.Drawing.Size(298, 16)
        Me.Lbl_Heading.TabIndex = 1
        Me.Lbl_Heading.Text = "A P P O I N T M E N T    V I S I T    R E G I S T E R"
        '
        'Cmb_Status
        '
        Me.Cmb_Status.BackColor = System.Drawing.Color.SteelBlue
        Me.Cmb_Status.CausesValidation = False
        Me.Cmb_Status.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Status.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_Status.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Status.FormattingEnabled = True
        Me.Cmb_Status.ItemHeight = 16
        Me.Cmb_Status.Location = New System.Drawing.Point(336, 430)
        Me.Cmb_Status.Name = "Cmb_Status"
        Me.Cmb_Status.Size = New System.Drawing.Size(152, 24)
        Me.Cmb_Status.TabIndex = 4
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.BackColor = System.Drawing.Color.Transparent
        Me.Label26.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.ForeColor = System.Drawing.Color.Navy
        Me.Label26.Location = New System.Drawing.Point(239, 434)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(44, 13)
        Me.Label26.TabIndex = 100055
        Me.Label26.Text = "Status"
        '
        'Pnl_Othersdetails
        '
        Me.Pnl_Othersdetails.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Nationality)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Gender)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_Familyname)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label6)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_SSNO)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label35)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label5)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_Age)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label15)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label13)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_Mobile)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label11)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_Phone)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label8)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label4)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_Addr)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_Name)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label2)
        Me.Pnl_Othersdetails.Location = New System.Drawing.Point(234, 200)
        Me.Pnl_Othersdetails.Name = "Pnl_Othersdetails"
        Me.Pnl_Othersdetails.Size = New System.Drawing.Size(463, 210)
        Me.Pnl_Othersdetails.TabIndex = 100058
        '
        'Txt_Nationality
        '
        Me.Txt_Nationality.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.Txt_Nationality.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Nationality.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Nationality.ForeColor = System.Drawing.Color.Black
        Me.Txt_Nationality.Location = New System.Drawing.Point(101, 185)
        Me.Txt_Nationality.Name = "Txt_Nationality"
        Me.Txt_Nationality.Size = New System.Drawing.Size(357, 20)
        Me.Txt_Nationality.TabIndex = 100046
        '
        'Txt_Gender
        '
        Me.Txt_Gender.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.Txt_Gender.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Gender.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Gender.ForeColor = System.Drawing.Color.Navy
        Me.Txt_Gender.Location = New System.Drawing.Point(101, 134)
        Me.Txt_Gender.Name = "Txt_Gender"
        Me.Txt_Gender.Size = New System.Drawing.Size(152, 20)
        Me.Txt_Gender.TabIndex = 100045
        '
        'Txt_Visitor_Familyname
        '
        Me.Txt_Visitor_Familyname.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.Txt_Visitor_Familyname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Familyname.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Familyname.Location = New System.Drawing.Point(101, 109)
        Me.Txt_Visitor_Familyname.Name = "Txt_Visitor_Familyname"
        Me.Txt_Visitor_Familyname.Size = New System.Drawing.Size(358, 21)
        Me.Txt_Visitor_Familyname.TabIndex = 4
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label6.Location = New System.Drawing.Point(1, 111)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(79, 13)
        Me.Label6.TabIndex = 100044
        Me.Label6.Text = "Family Name"
        '
        'Txt_Visitor_SSNO
        '
        Me.Txt_Visitor_SSNO.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.Txt_Visitor_SSNO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_SSNO.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_SSNO.Location = New System.Drawing.Point(101, 4)
        Me.Txt_Visitor_SSNO.Name = "Txt_Visitor_SSNO"
        Me.Txt_Visitor_SSNO.Size = New System.Drawing.Size(183, 21)
        Me.Txt_Visitor_SSNO.TabIndex = 1
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.BackColor = System.Drawing.Color.Transparent
        Me.Label35.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label35.Location = New System.Drawing.Point(1, 6)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(67, 13)
        Me.Label35.TabIndex = 100042
        Me.Label35.Text = "Soc Sec No"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label5.Location = New System.Drawing.Point(1, 190)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(68, 13)
        Me.Label5.TabIndex = 100041
        Me.Label5.Text = "Nationality"
        '
        'Txt_Visitor_Age
        '
        Me.Txt_Visitor_Age.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.Txt_Visitor_Age.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Age.Cursor = System.Windows.Forms.Cursors.Default
        Me.Txt_Visitor_Age.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Age.Location = New System.Drawing.Point(304, 135)
        Me.Txt_Visitor_Age.Name = "Txt_Visitor_Age"
        Me.Txt_Visitor_Age.Size = New System.Drawing.Size(64, 21)
        Me.Txt_Visitor_Age.TabIndex = 6
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label15.Location = New System.Drawing.Point(265, 138)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(29, 13)
        Me.Label15.TabIndex = 100040
        Me.Label15.Text = "Age"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label13.Location = New System.Drawing.Point(1, 139)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(48, 13)
        Me.Label13.TabIndex = 100039
        Me.Label13.Text = "Gender"
        '
        'Txt_Visitor_Mobile
        '
        Me.Txt_Visitor_Mobile.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.Txt_Visitor_Mobile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Mobile.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Mobile.Location = New System.Drawing.Point(304, 160)
        Me.Txt_Visitor_Mobile.Name = "Txt_Visitor_Mobile"
        Me.Txt_Visitor_Mobile.Size = New System.Drawing.Size(153, 21)
        Me.Txt_Visitor_Mobile.TabIndex = 8
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label11.Location = New System.Drawing.Point(260, 162)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(44, 13)
        Me.Label11.TabIndex = 100038
        Me.Label11.Text = "Mobile"
        '
        'Txt_Visitor_Phone
        '
        Me.Txt_Visitor_Phone.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.Txt_Visitor_Phone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Phone.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Phone.Location = New System.Drawing.Point(101, 160)
        Me.Txt_Visitor_Phone.Name = "Txt_Visitor_Phone"
        Me.Txt_Visitor_Phone.Size = New System.Drawing.Size(153, 21)
        Me.Txt_Visitor_Phone.TabIndex = 7
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label8.Location = New System.Drawing.Point(1, 162)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(42, 13)
        Me.Label8.TabIndex = 100037
        Me.Label8.Text = "Phone"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label4.Location = New System.Drawing.Point(1, 59)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(92, 13)
        Me.Label4.TabIndex = 100036
        Me.Label4.Text = "Visitor Address"
        '
        'Txt_Visitor_Addr
        '
        Me.Txt_Visitor_Addr.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.Txt_Visitor_Addr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Addr.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Addr.Location = New System.Drawing.Point(101, 56)
        Me.Txt_Visitor_Addr.Name = "Txt_Visitor_Addr"
        Me.Txt_Visitor_Addr.Size = New System.Drawing.Size(358, 49)
        Me.Txt_Visitor_Addr.TabIndex = 3
        '
        'Txt_Visitor_Name
        '
        Me.Txt_Visitor_Name.BackColor = System.Drawing.Color.LightSteelBlue
        Me.Txt_Visitor_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Name.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Name.Location = New System.Drawing.Point(101, 30)
        Me.Txt_Visitor_Name.Name = "Txt_Visitor_Name"
        Me.Txt_Visitor_Name.Size = New System.Drawing.Size(358, 21)
        Me.Txt_Visitor_Name.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label2.Location = New System.Drawing.Point(1, 33)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(78, 13)
        Me.Label2.TabIndex = 100035
        Me.Label2.Text = "Visitor Name"
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(521, 425)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(174, 34)
        Me.Pnl_Common_Btn.TabIndex = 5
        '
        'Btn_Close
        '
        Me.Btn_Close.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Close.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Close.ForeColor = System.Drawing.Color.White
        Me.Btn_Close.Location = New System.Drawing.Point(114, 2)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 3
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = False
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(58, 2)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear.TabIndex = 2
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = CType(resources.GetObject("Btn_Save.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(2, 2)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save.TabIndex = 1
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Lbl_Date
        '
        Me.Lbl_Date.BackColor = System.Drawing.Color.LightSkyBlue
        Me.Lbl_Date.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Lbl_Date.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Date.ForeColor = System.Drawing.Color.Navy
        Me.Lbl_Date.Location = New System.Drawing.Point(490, 25)
        Me.Lbl_Date.Name = "Lbl_Date"
        Me.Lbl_Date.Size = New System.Drawing.Size(205, 23)
        Me.Lbl_Date.TabIndex = 100064
        Me.Lbl_Date.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Txt_Tokenno
        '
        Me.Txt_Tokenno.BackColor = System.Drawing.Color.LightSkyBlue
        Me.Txt_Tokenno.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Tokenno.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Tokenno.ForeColor = System.Drawing.Color.Navy
        Me.Txt_Tokenno.Location = New System.Drawing.Point(412, 159)
        Me.Txt_Tokenno.Name = "Txt_Tokenno"
        Me.Txt_Tokenno.Size = New System.Drawing.Size(104, 41)
        Me.Txt_Tokenno.TabIndex = 100065
        Me.Txt_Tokenno.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Cmb_Service
        '
        Me.Cmb_Service.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Service.FormattingEnabled = True
        Me.Cmb_Service.Location = New System.Drawing.Point(335, 26)
        Me.Cmb_Service.Name = "Cmb_Service"
        Me.Cmb_Service.Size = New System.Drawing.Size(154, 21)
        Me.Cmb_Service.TabIndex = 1
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label3.Location = New System.Drawing.Point(236, 31)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(49, 13)
        Me.Label3.TabIndex = 100067
        Me.Label3.Text = "Service"
        '
        'Pnl_Doctors
        '
        Me.Pnl_Doctors.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Doctors.Controls.Add(Me.TlStrp_Doctors)
        Me.Pnl_Doctors.Location = New System.Drawing.Point(231, 51)
        Me.Pnl_Doctors.Margin = New System.Windows.Forms.Padding(0)
        Me.Pnl_Doctors.Name = "Pnl_Doctors"
        Me.Pnl_Doctors.Padding = New System.Windows.Forms.Padding(2, 2, 2, 0)
        Me.Pnl_Doctors.Size = New System.Drawing.Size(466, 45)
        Me.Pnl_Doctors.TabIndex = 2
        '
        'TlStrp_Doctors
        '
        Me.TlStrp_Doctors.BackColor = System.Drawing.Color.White
        Me.TlStrp_Doctors.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TlStrp_Doctors.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TlStrp_Doctors.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TlStrp_Doctors.Location = New System.Drawing.Point(2, 2)
        Me.TlStrp_Doctors.Name = "TlStrp_Doctors"
        Me.TlStrp_Doctors.Size = New System.Drawing.Size(462, 43)
        Me.TlStrp_Doctors.TabIndex = 1
        Me.TlStrp_Doctors.TabStop = True
        '
        'Pnl_Apointments
        '
        Me.Pnl_Apointments.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Apointments.Controls.Add(Me.Dgrd_Appointment)
        Me.Pnl_Apointments.Controls.Add(Me.Panel1)
        Me.Pnl_Apointments.Dock = System.Windows.Forms.DockStyle.Left
        Me.Pnl_Apointments.Location = New System.Drawing.Point(0, 21)
        Me.Pnl_Apointments.Name = "Pnl_Apointments"
        Me.Pnl_Apointments.Size = New System.Drawing.Size(230, 442)
        Me.Pnl_Apointments.TabIndex = 100069
        '
        'Dgrd_Appointment
        '
        Me.Dgrd_Appointment.AllowUserToAddRows = False
        Me.Dgrd_Appointment.AllowUserToDeleteRows = False
        Me.Dgrd_Appointment.AllowUserToResizeColumns = False
        Me.Dgrd_Appointment.AllowUserToResizeRows = False
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.AliceBlue
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.Color.DarkBlue
        Me.Dgrd_Appointment.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle6
        Me.Dgrd_Appointment.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(113, Byte), Integer), CType(CType(193, Byte), Integer))
        Me.Dgrd_Appointment.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(CType(CType(75, Byte), Integer), CType(CType(103, Byte), Integer), CType(CType(131, Byte), Integer))
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgrd_Appointment.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.Dgrd_Appointment.ColumnHeadersHeight = 20
        Me.Dgrd_Appointment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.Dgrd_Appointment.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.TOKEN, Me.Time, Me.Visitor})
        Me.Dgrd_Appointment.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Dgrd_Appointment.Location = New System.Drawing.Point(0, 0)
        Me.Dgrd_Appointment.MultiSelect = False
        Me.Dgrd_Appointment.Name = "Dgrd_Appointment"
        Me.Dgrd_Appointment.ReadOnly = True
        Me.Dgrd_Appointment.RowHeadersVisible = False
        DataGridViewCellStyle10.BackColor = System.Drawing.Color.AliceBlue
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.Color.DarkBlue
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgrd_Appointment.RowsDefaultCellStyle = DataGridViewCellStyle10
        Me.Dgrd_Appointment.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.AliceBlue
        Me.Dgrd_Appointment.RowTemplate.DefaultCellStyle.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dgrd_Appointment.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.DarkBlue
        Me.Dgrd_Appointment.RowTemplate.Height = 40
        Me.Dgrd_Appointment.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.Dgrd_Appointment.Size = New System.Drawing.Size(230, 410)
        Me.Dgrd_Appointment.TabIndex = 2
        '
        'TOKEN
        '
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TOKEN.DefaultCellStyle = DataGridViewCellStyle8
        Me.TOKEN.Frozen = True
        Me.TOKEN.HeaderText = "TOKEN"
        Me.TOKEN.Name = "TOKEN"
        Me.TOKEN.ReadOnly = True
        Me.TOKEN.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.TOKEN.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.TOKEN.Width = 130
        '
        'Time
        '
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Time.DefaultCellStyle = DataGridViewCellStyle9
        Me.Time.HeaderText = "Time"
        Me.Time.MinimumWidth = 75
        Me.Time.Name = "Time"
        Me.Time.ReadOnly = True
        Me.Time.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Time.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Time.Width = 75
        '
        'Visitor
        '
        Me.Visitor.HeaderText = "Visitor"
        Me.Visitor.Name = "Visitor"
        Me.Visitor.ReadOnly = True
        Me.Visitor.Visible = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.Controls.Add(Me.Lbl_Wnos)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 410)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(230, 32)
        Me.Panel1.TabIndex = 0
        '
        'Lbl_Wnos
        '
        Me.Lbl_Wnos.BackColor = System.Drawing.Color.LightSkyBlue
        Me.Lbl_Wnos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Lbl_Wnos.Font = New System.Drawing.Font("Tahoma", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Wnos.ForeColor = System.Drawing.Color.Navy
        Me.Lbl_Wnos.Location = New System.Drawing.Point(126, 3)
        Me.Lbl_Wnos.Name = "Lbl_Wnos"
        Me.Lbl_Wnos.Size = New System.Drawing.Size(104, 26)
        Me.Lbl_Wnos.TabIndex = 100072
        Me.Lbl_Wnos.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Navy
        Me.Label7.Location = New System.Drawing.Point(27, 10)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(73, 13)
        Me.Label7.TabIndex = 100071
        Me.Label7.Text = "Waiting Nos"
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label1.Location = New System.Drawing.Point(441, 144)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(42, 13)
        Me.Label1.TabIndex = 100070
        Me.Label1.Text = "TOKEN"
        '
        'Btn_Refresh
        '
        Me.Btn_Refresh.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Refresh.BackgroundImage = CType(resources.GetObject("Btn_Refresh.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Refresh.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Refresh.ForeColor = System.Drawing.Color.White
        Me.Btn_Refresh.Location = New System.Drawing.Point(233, 99)
        Me.Btn_Refresh.Name = "Btn_Refresh"
        Me.Btn_Refresh.Size = New System.Drawing.Size(94, 28)
        Me.Btn_Refresh.TabIndex = 3
        Me.Btn_Refresh.TabStop = False
        Me.Btn_Refresh.Text = "&Refresh (F5)"
        Me.Btn_Refresh.UseVisualStyleBackColor = False
        '
        'Lbl_OPValidator
        '
        Me.Lbl_OPValidator.BackColor = System.Drawing.Color.FromArgb(CType(CType(227, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.Lbl_OPValidator.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Lbl_OPValidator.Font = New System.Drawing.Font("Tahoma", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_OPValidator.ForeColor = System.Drawing.Color.DarkBlue
        Me.Lbl_OPValidator.Location = New System.Drawing.Point(333, 99)
        Me.Lbl_OPValidator.Name = "Lbl_OPValidator"
        Me.Lbl_OPValidator.Size = New System.Drawing.Size(362, 28)
        Me.Lbl_OPValidator.TabIndex = 100072
        Me.Lbl_OPValidator.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Timer2
        '
        Me.Timer2.Interval = 500
        '
        'AppointmentvisitReg_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(699, 463)
        Me.Controls.Add(Me.Lbl_OPValidator)
        Me.Controls.Add(Me.Btn_Refresh)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Pnl_Apointments)
        Me.Controls.Add(Me.Pnl_Doctors)
        Me.Controls.Add(Me.Cmb_Service)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Txt_Tokenno)
        Me.Controls.Add(Me.Lbl_Date)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.Pnl_Othersdetails)
        Me.Controls.Add(Me.Cmb_Status)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Pnl_Header)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "AppointmentvisitReg_Frm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Pnl_Othersdetails.ResumeLayout(False)
        Me.Pnl_Othersdetails.PerformLayout()
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.Pnl_Doctors.ResumeLayout(False)
        Me.Pnl_Doctors.PerformLayout()
        Me.Pnl_Apointments.ResumeLayout(False)
        CType(Me.Dgrd_Appointment, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Cmb_Status As System.Windows.Forms.ComboBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Othersdetails As System.Windows.Forms.Panel
    Friend WithEvents Txt_Nationality As System.Windows.Forms.Label
    Friend WithEvents Txt_Gender As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_Familyname As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_SSNO As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_Age As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_Mobile As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_Phone As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_Addr As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_Name As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Label80 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Heading As System.Windows.Forms.Label
    Friend WithEvents Lbl_Date As System.Windows.Forms.Label
    Friend WithEvents Txt_Tokenno As System.Windows.Forms.Label
    Friend WithEvents Cmb_Service As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Doctors As System.Windows.Forms.Panel
    Friend WithEvents TlStrp_Doctors As System.Windows.Forms.ToolStrip
    Friend WithEvents Pnl_Apointments As System.Windows.Forms.Panel
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Wnos As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Dgrd_Appointment As System.Windows.Forms.DataGridView
    Friend WithEvents TOKEN As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Time As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Visitor As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Btn_Refresh As System.Windows.Forms.Button
    Friend WithEvents Lbl_OPValidator As System.Windows.Forms.Label
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
End Class
