﻿

Option Explicit On
Imports System.IO
Imports HMS_BL
Imports HMS_Common.Common_Cls

Public Class ImageViewer_Frm

#Region " D e c l a r a t i o n s "

    'Object of Image Details Bussiness Layer
    Private Image_BL As Image_BL_Cls

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing


    Private mCust_ID As String = ""
    Private mCust_Type As Customer_Type = Customer_Type.Employee
    Private mScan_Enabled As Boolean = True

#End Region

#Region " P r o p e r t i e s "

    Public Property CUST_ID() As String
        Get
            Return mCust_ID
        End Get
        Set(ByVal value As String)
            mCust_ID = value

            If mCust_ID.Trim = "" Then
                Call Clear_Form()

            Else
                If Not Locate_Images(mCust_ID.Trim, mCust_Type) Then
                    ' Me.Visible = False
                End If
            End If

        End Set
    End Property

    Public Property CUST_TYPE() As Customer_Type
        Get
            Return mCust_Type
        End Get
        Set(ByVal value As Customer_Type)
            mCust_Type = value
            If mCust_ID.Trim = "" Then
                Call Clear_Form()
            Else
                If Not Locate_Images(mCust_ID.Trim, mCust_Type) Then
                    Me.Pic_Photo.Image = Nothing
                End If
            End If
        End Set
    End Property

    Public Property Scan_Enabled() As Boolean
        Get
            Return mScan_Enabled
        End Get
        Set(ByVal value As Boolean)
            mScan_Enabled = value
            Me.Btn_ScanImage.Enabled = mScan_Enabled
        End Set
    End Property

#End Region

#Region " M e t h o d s "

    'Converting and Loading Image Data to Picture box
    Private Sub Convert_BinaryData()
        If BindingSource1.Count <= 0 Or (BindingSource1.Position < 0) Then
            Exit Sub
        End If
        Dim ms = New System.IO.MemoryStream(CType(BindingSource1.Item(BindingSource1.Position)(1), System.Byte()))
        Dim newImage = Image.FromStream(ms)
        ms.Dispose()
        With Pic_Photo
            .Image = Nothing
            .Image = newImage
            .SizeMode = PictureBoxSizeMode.StretchImage
            .Refresh()
        End With
        Lbl_Navimagetype.Text = BindingSource1.Item(BindingSource1.Position)(0).ToString
        'Lbl_Navimagetype.Text = Cmb_Imagetype.Items(Val(Lbl_Navimagetype.Text)).ToString
    End Sub

    'Locate Images of a Customer
    'Returns Boolean
    Private Function Locate_Images(ByVal Cust_ID As String, _
                                   ByVal Cust_type As Customer_Type) As Boolean
        Try
            'Initialising BL Object
            Image_BL = New Image_BL_Cls
            Dtbl = Nothing
            Call Clear_Form()

            'Retreiving Employee Details and Assign the values to respective controls
            If Image_BL.GetImage_Details(Dtbl, Cust_ID, Cust_type) Then

                BindingSource1.DataSource = Dtbl

                Nav_Imageview.BindingSource = BindingSource1

                Call Convert_BinaryData()

                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            Return False
        End Try
    End Function

    'Clear Form Data controls
    Private Sub Clear_Form()
        Try
            Dtbl = Nothing
            BindingSource1.DataSource = Nothing
            Nav_Imageview.BindingSource = Nothing
            Pic_Photo.Image = Nothing

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub



#End Region

    Private Sub BindingSource1_PositionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles BindingSource1.PositionChanged

        Call Convert_BinaryData()

    End Sub

    Private Sub Btn_ScanImage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_ScanImage.Click

    End Sub

End Class