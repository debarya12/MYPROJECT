﻿Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls
Public Class Investigation_Master_Frm

#Region "Declarations"

    'Object of Employee Details Bussiness Layer
    Private InvestGation_Master_BL As InvestigationMaster_BL_Cls
    Private mTr_Mode As Tran_Mode
    Private StrQry As String

    Private Com_BL As HMS_Common_BL_Cls

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_Inv_ID.BackColor = Color.White
                    Me.Txt_Inv_ID.ReadOnly = False
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_Inv_ID.BackColor = Color.Silver
                    Me.Txt_Inv_ID.ReadOnly = True
            End Select
        End Set
    End Property

#End Region

    Private Sub Investigation_Master_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then SendKeyTab()
        If e.KeyCode = Keys.F2 Then Btn_Find_Click(sender, e)
    End Sub

    Private Sub Investigation_Master_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub Investigation_Master_Frm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'SendKeyTab()
        'SendKeyTab()
        'SendKeyTab()
        Call ShowInGrid()
        Btn_Delete.Enabled = False
        Cmb_Active.SelectedIndex = 0
    End Sub

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try
            If Not Validate_Fields() Then Exit Sub
            InvestGation_Master_BL = New InvestigationMaster_BL_Cls
            With InvestGation_Master_BL
                .Invs_ID = Val(Txt_Inv_ID.Text)
                .Invs_Name = Txt_Inv_Name.Text.Trim
                .Approx_Exp = Val(Txt_AppExp.Text)
                .Active = Strings.Left(Cmb_Active.Text, 1).Trim
            End With

            If InvestGation_Master_BL.Save_Investgation_Master(Dtbl, Val(Txt_Inv_ID.Text.Trim), Tr_Mode) Then
                MessageBox.Show("Investgation Master Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Call Clear_Form()
                If Assigntocontrols(Dtbl) Then
                    Tr_Mode = Tran_Mode.Edit_Mode
                    Btn_Delete.Enabled = True
                End If
                Call ShowInGrid()
                Btn_Clear.Focus()
                Exit Sub
            Else
                MessageBox.Show("Investgation Master Not Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click
        Try
            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If


            If Tr_Mode = Tran_Mode.New_Mode Then
                MessageBox.Show("You have to locate details before deleting the record", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_Inv_ID.Focus()
                Exit Sub
            End If
            If MessageBox.Show("Are you sure want to delete the record", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.No Then Exit Sub

            If Txt_Inv_ID.Text.Trim = "" Then
                MessageBox.Show("Invalid investgation Id ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                If Txt_Inv_ID.Enabled = True Then Txt_Inv_ID.Focus() : Exit Sub
            End If

            InvestGation_Master_BL = New InvestigationMaster_BL_Cls
            If InvestGation_Master_BL.Delete_Investigationmaster(Txt_Inv_ID.Text.Trim) Then
                MessageBox.Show("Investigation Details Deleted", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Call Btn_Clear_Click(sender, e)
                Call ShowInGrid()
            Else
                MessageBox.Show("You cannot delete this investgation details" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)

            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Call Clear_Form()
        Txt_Inv_ID.Focus()
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try

            If Txt_Inv_ID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "255|125|50"
                Sql = "SELECT [Investigation Name],[Approximate Expence],Invs_ID,Active from Investigation_Master_Vw"
                Call ShowSearchengine(Txt_Inv_ID, Sql, 2, "Investigation Name", Colwidth, , 0)
            End If

            'Validating Mandatory fields for locating
            If Txt_Inv_ID.Text.Trim = "" Then
                Txt_Inv_ID.Focus() : Exit Sub
            End If

            If Locate_Values(Txt_Inv_ID.Text.Trim) Then
                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Delete.Enabled = True
            Else
                MessageBox.Show("Investigation Master does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

#Region "Methods"

    Private Sub Clear_Form()
        Try
            Txt_Inv_ID.Text = ""
            Txt_Inv_ID.Tag = ""
            Txt_Inv_Name.Text = ""
            Txt_AppExp.Text = ""
            Cmb_Active.SelectedIndex = 0
            Tr_Mode = Tran_Mode.New_Mode
            Btn_Delete.Enabled = False

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Function Locate_Values(ByVal Invs_ID As Integer) As Boolean
        Try

            'Initialising BL Object
            InvestGation_Master_BL = New InvestigationMaster_BL_Cls

            Dtbl = Nothing
            Call Clear_Form()

            Txt_Inv_ID.Text = Invs_ID


            'Retreiving Investigation Details and Assign the values to respective controls
            If InvestGation_Master_BL.Get_InvestigationDetails(Dtbl, Invs_ID) Then
                Return Assigntocontrols(Dtbl)
            Else
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        Finally
            Dr = Nothing
            Dtbl = Nothing
            InvestGation_Master_BL = Nothing
        End Try
    End Function

    Private Function Assigntocontrols(ByVal D_Table As DataTable) As Boolean
        Try
            Dr = D_Table.CreateDataReader()
            Dr.Read()
            With Dr
                Txt_Inv_ID.Text = .Item("Invs_ID")
                Txt_Inv_ID.Tag = .Item("Invs_ID")
                Txt_Inv_Name.Text = .Item("Investigation Name")
                Txt_AppExp.Text = .Item("Approximate Expence")
                If .Item("Active").ToString.Trim = "A" Then
                    Cmb_Active.SelectedIndex = 0
                Else
                    Cmb_Active.SelectedIndex = 1
                End If

            End With

            Return True
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        Finally
            D_Table = Nothing
        End Try
    End Function

    Private Sub ShowInGrid()
        Try
            Com_BL = New HMS_Common_BL_Cls
            Dim Sr_Dtbl As DataTable = Nothing

            StrQry = "SELECT Invs_ID,[Investigation Name],[Approximate Expence],Active from Investigation_Master_Vw "
            If Com_BL.Get_Data(StrQry, Sr_Dtbl) Then
                With Dgrd_InvMas
                    .DataSource = Nothing
                    .DataSource = Sr_Dtbl
                    .Refresh()
                    .Columns(0).MinimumWidth = 25
                    .Columns(1).MinimumWidth = 250
                    .Columns(2).MinimumWidth = 150
                    .Columns(3).AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells
                    '.Columns(4).AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells

                End With
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try
    End Sub

    Private Function Validate_Fields() As Boolean
        Try
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If


            If Tr_Mode <> Tran_Mode.New_Mode Then
                If Txt_Inv_ID.Text.Trim = "" Then MessageBox.Show("Invalid  Investigation Id ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Inv_ID.Focus() : Exit Function
            End If
            If Txt_Inv_Name.Text.Trim = "" Then MessageBox.Show("Invalid Investigation Name,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Inv_Name.Focus() : Exit Function
            If Val(Txt_AppExp.Text) <= 0 Then MessageBox.Show("Invalid Expence,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Txt_AppExp.Focus() : Exit Function

            'If Cmb_Dep_Lid.Text.Trim 
            Return True
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function

#End Region

    Private Sub Txt_Inv_Name_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_Inv_Name.Validating
        Try

            If Tr_Mode = Tran_Mode.New_Mode Then
                If Com_BL.Check_Duplicatedataexists("Investigation_Master_Tbl", "Invs_Name", Data_Type.General_Type, Txt_Inv_Name.Text.Trim) Then
                    MessageBox.Show("Investigation name already exists", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    e.Cancel = True
                    Txt_Inv_Name.Text = ""
                End If
            Else
                If Com_BL.Check_Duplicatedataexists("Investigation_Master_Tbl", "Invs_Name", Data_Type.General_Type, Txt_Inv_Name.Text.Trim, , , "Invs_ID", Data_Type.Integer_Type, Txt_Inv_ID.Text.Trim) Then
                    MessageBox.Show("Investigation name already exists", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    e.Cancel = True
                    Txt_Inv_Name.Text = ""
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Dgrd_InvMas_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Dgrd_InvMas.DoubleClick
        Try
            With Dgrd_InvMas
                If .CurrentRow Is Nothing Then Exit Sub
                Txt_Inv_ID.Text = .Item("Invs_ID", .CurrentCell.RowIndex).Value.ToString
                Call Btn_Find_Click(sender, e)
                Txt_Inv_ID.Focus()
            End With

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_Inv_ID_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Inv_ID.KeyPress
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Inv_ID.Text, Data_Type.Integer_Type, 12))
    End Sub

    Private Sub Txt_Inv_ID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_Inv_ID.Validating
        Try
            If Txt_Inv_ID.Text.Trim <> "" And Txt_Inv_ID.Text.Trim <> Txt_Inv_ID.Tag Then
                If Locate_Values(Txt_Inv_ID.Text.Trim) Then
                    Tr_Mode = Tran_Mode.Edit_Mode
                    Btn_Delete.Enabled = True
                    SendKeyTab()
                Else
                    MessageBox.Show("Invalid Investigation Id, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Tr_Mode = Tran_Mode.New_Mode
                    e.Cancel = True
                End If

            End If
        Catch ex As Exception

        End Try
    End Sub
    Private Sub Txt_AppExp_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_AppExp.KeyPress
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_AppExp.Text, Data_Type.Integer_Type, 12))
    End Sub
   
    Private Sub Txt_Inv_Name_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Inv_Name.TextChanged

    End Sub

    Private Sub Dgrd_InvMas_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgrd_InvMas.CellContentClick

    End Sub

    Private Sub Txt_Inv_ID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Inv_ID.TextChanged

    End Sub
End Class