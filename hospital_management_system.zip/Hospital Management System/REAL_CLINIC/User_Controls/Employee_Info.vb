﻿

Option Explicit On
Imports HMS_BL

Public Class Employee_Info

    Private HMS_Helper As HMS_Helper
    Private P_Dtbl As DataTable = Nothing

    Private _Viewmoreform_Name As String = ""
    Private _MDI_Form As Form = Nothing
    Private _Employee_ID As String = ""

    Private Sub Clear_Me()
        Try
            Me.EmployeeName.Text = ""
            Me.Employeeaddress.Text = ""
            Me.Employeefamilyname.Text = ""
            Me.Employeephone.Text = ""
            Me.EmployeeSSN.Text = ""
            Me.Employeemobile.Text = ""
            Me._Employee_ID = ""

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Assign_Values(ByVal Employeeinfo_Dtbl As DataTable)
        Try
            Call Clear_Me()
            If Employeeinfo_Dtbl Is Nothing Then Exit Sub
            If Employeeinfo_Dtbl.Rows.Count = 0 Then Exit Sub

            With Employeeinfo_Dtbl
                Me.EmployeeName.Text = .Rows(0).Item("Name").ToString.ToUpper
                Me.Employeeaddress.Text = .Rows(0).Item("Address").ToString
                Me.Employeeaddress.Text += vbCrLf & .Rows(0).Item("Country").ToString
                Me.Employeeaddress.Text += vbCrLf & .Rows(0).Item("Email").ToString
                Me.Employeefamilyname.Text = .Rows(0).Item("Family Name").ToString
                Me.Employeephone.Text = .Rows(0).Item("Phone").ToString
                Me.Employeemobile.Text = .Rows(0).Item("Mobile").ToString
                Me.EmployeeSSN.Text = .Rows(0).Item("SS_Number").ToString
            End With

        Catch ex As Exception

        End Try
    End Sub

    Public WriteOnly Property Employee_ID() As String
        Set(ByVal value As String)
            Call Clear_Me()
            Call Locate_Values(value)
            _Employee_ID = value
        End Set
    End Property

    Public WriteOnly Property Viewmoreform_Name() As String
        Set(ByVal value As String)
            _Viewmoreform_Name = value
        End Set
    End Property

    Public WriteOnly Property MDIform_Name() As Form
        Set(ByVal value As Form)
            _MDI_Form = value
        End Set
    End Property

    Public ReadOnly Property Is_Valid() As Boolean
        Get
            If Me.EmployeeName.Text = "" Then
                Return False
            Else
                Return True
            End If
        End Get
    End Property

    Private Function Locate_Values(ByVal EmployeeID As String) As Boolean
        Try

            If EmployeeID = "" Then Return False


            HMS_Helper = New Hms_Helperimpliments
            Dim Qry As String = ""
            Qry = "SELECT   Emp_ID, Name, Address, Country, " _
                & "Phone, Emp_Phone2, Mobile, Emp_Mobile2, SS_Number,Email,[Family Name] " _
                & "FROM   Emp_Details_Vw " _
                & "WHERE (Emp_ID = " & EmployeeID & ")"

            If HMS_Helper.Get_Data(Qry, P_Dtbl) Then
                Call Assign_Values(P_Dtbl)
                Btn_viewmore.Enabled = True
                Return True
            Else
                Btn_viewmore.Enabled = False
                Return False
            End If

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Btn_viewmore_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_viewmore.Click
        Try

            If _MDI_Form Is Nothing Then Exit Sub

            'With Employee_InfoSheet_Frm
            '    .Employee_ID = _Employee_ID
            '    .MdiParent = _MDI_Form
            '    .Show()
            'End With

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Employee_Info_BackColorChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.BackColorChanged
        Try
            Me.EmployeeName.BackColor = Me.BackColor
            Me.Employeeaddress.BackColor = Me.BackColor
            Me.Employeephone.BackColor = Me.BackColor
            Me.EmployeeSSN.BackColor = Me.BackColor
            Me.Employeemobile.BackColor = Me.BackColor
            Me.Employeefamilyname.BackColor = Me.BackColor
            Me.Btn_viewmore.BackColor = Me.BackColor


            Me.Lbl_name.BackColor = Me.BackColor
            Me.Lbl_Address.BackColor = Me.BackColor
            Me.Lbl_Phone.BackColor = Me.BackColor
            Me.Lbl_SSN.BackColor = Me.BackColor
            Me.Lbl_Mobile.BackColor = Me.BackColor
            Me.Lbl_Familyname.BackColor = Me.BackColor
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Employee_Info_FontChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.FontChanged
        Try
            Me.EmployeeName.Font = Me.Font
            Me.Employeeaddress.Font = Me.Font
            Me.Employeephone.Font = Me.Font
            Me.EmployeeSSN.Font = Me.Font
            Me.Employeemobile.Font = Me.Font
            Me.Employeefamilyname.Font = Me.Font
            Me.Btn_viewmore.Font = Me.Font

            Me.Lbl_name.Font = Me.Font
            Me.Lbl_Address.Font = Me.Font
            Me.Lbl_Phone.Font = Me.Font
            Me.Lbl_SSN.Font = Me.Font
            Me.Lbl_Mobile.Font = Me.Font
            Me.Lbl_Familyname.Font = Me.Font


        Catch ex As Exception

        End Try
    End Sub

    Private Sub Employee_Info_ForeColorChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.ForeColorChanged
        Try
            Me.EmployeeName.ForeColor = Me.ForeColor
            Me.Employeeaddress.ForeColor = Me.ForeColor
            Me.Employeephone.ForeColor = Me.ForeColor
            Me.EmployeeSSN.ForeColor = Me.ForeColor
            Me.Employeemobile.ForeColor = Me.ForeColor
            Me.Employeefamilyname.ForeColor = Me.ForeColor
            Me.Btn_viewmore.ForeColor = Me.ForeColor

            Me.Lbl_name.ForeColor = Me.ForeColor
            Me.Lbl_Address.ForeColor = Me.ForeColor
            Me.Lbl_Phone.ForeColor = Me.ForeColor
            Me.Lbl_SSN.ForeColor = Me.ForeColor
            Me.Lbl_Mobile.ForeColor = Me.ForeColor
            Me.Lbl_Familyname.ForeColor = Me.ForeColor

        Catch ex As Exception

        End Try
    End Sub
End Class
