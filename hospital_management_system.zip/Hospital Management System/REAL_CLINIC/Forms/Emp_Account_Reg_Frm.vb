﻿
Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls

Public Class Emp_Account_Reg_Frm

#Region "Declarations"
    'Object of Employee Details Bussiness Layer

    Private hms_helper As HMS_Helper = Nothing
    Private Emp_Acc_Reg_BL As Emp_Account_Reg_BL_Cls
    Private mTr_Mode As Tran_Mode

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing
    Private IsHandleAdded As Boolean

    Private CellRowindex As Integer
    Private CellColindex As Integer


    Private GrDtbl As DataTable

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_AccountNo.BackColor = Color.White
                    Me.Txt_AccountNo.ReadOnly = False
                    Me.Txt_EmpID.BackColor = Color.White
                    Me.Txt_EmpID.ReadOnly = False
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_AccountNo.BackColor = Color.Silver
                    Me.Txt_AccountNo.ReadOnly = True
                    Me.Txt_EmpID.BackColor = Color.Silver
                    Me.Txt_EmpID.ReadOnly = True
            End Select
        End Set
    End Property

#End Region

#Region "Methods"

    Private Sub Clear_Form()
        Try

            Txt_EmpID.Text = ""
            Txt_AccountNo.Text = ""
            If Cmb_status.Items.Count > 0 Then Cmb_status.SelectedIndex = 0

            Tr_Mode = Tran_Mode.New_Mode
            Btn_Save.Enabled = True
            Btn_Delete.Enabled = False

        Catch ex As Exception

        End Try


    End Sub

    Private Function Locate_Values() As Boolean
        Try
            Dim dtbl As DataTable = Nothing

            Emp_Acc_Reg_BL = New Emp_Account_Reg_BL_Cls
            If Emp_Acc_Reg_BL.Get_Emp_Account_Reg(Dtbl, Txt_AccountNo.Text.Trim, Branch_Code) Then
                Txt_EmpID.Text = Dtbl.Rows(0).Item("Emp_ID").ToString
                Cmb_status.SelectedIndex = IIf(dtbl.Rows(0).Item("Active").ToString = "Y", 0, 1)
            End If
            Return True
        Catch ex As Exception

        End Try
    End Function

    Private Function Validate_Fields() As Boolean
        Try
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If

            If Tr_Mode <> Tran_Mode.New_Mode Then
                If Txt_AccountNo.Text.Trim = "" Then MessageBox.Show("Invalid Employee Account Number,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_AccountNo.Focus() : Return False
            End If
            'Assigning Default values
            If Txt_EmpID.Text.Trim = "" Then MessageBox.Show("Invalid Employee ID, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_EmpID.Focus() : Return False
            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Is_Emp_Account_Reg(ByVal Emp_ID As Integer, ByRef Acc_No As String) As Boolean
        Try
            Dim dtbl As DataTable = Nothing

            Emp_Acc_Reg_BL = New Emp_Account_Reg_BL_Cls
            If Emp_Acc_Reg_BL.Is_Emp_Account_Reg(Dtbl, Emp_ID, Branch_Code) Then
                If Dtbl.Rows.Count > 0 Then
                    Acc_No = Dtbl.Rows(0).Item("Acc_no").ToString
                    Return False
                End If
                Return True
            End If
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function


#End Region
    
    Private Sub Emp_Account_Reg_Frm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Dim Dtbl As DataTable
            Emp_Acc_Reg_BL = New Emp_Account_Reg_BL_Cls
            Cmb_status.Items.Add("Yes")
            Cmb_status.Items.Add("No")
            Cmb_status.SelectedIndex = 0

            Dtbl = Nothing
            If Emp_Acc_Reg_BL.Get_Emp_Account_Reg_All(Dtbl, Branch_Code) Then
                Dgvw_Emp_AccountMaster.DataSource = Dtbl
                Dgvw_Emp_AccountMaster.Refresh()
            End If
            Txt_AccountNo.Focus()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_EmpID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_EmpID.KeyDown
        If e.KeyCode = Keys.F2 Then Btn_Find1_Click(sender, e)
    End Sub

    Private Sub Txt_EmpID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_EmpID.TextChanged
        Try

       
            With Employee_Info1
                .Viewmoreform_Name = "Employee_InfoSheet_Frm"
                .MDIform_Name = Me.MdiParent
                .Employee_ID = Txt_EmpID.Text.Trim
            End With
            With Imageviewer1
                .CUST_TYPE = Customer_Type.Employee
                .CUST_ID = Txt_EmpID.Text.Trim
            End With


            If Txt_EmpID.Text.Trim = "" Then
                Call Clear_Form()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Find1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find1.Click
        Try
            If Txt_EmpID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "200|200|50|"
                Sql = "SELECT Name, Address,[Family Name], Phone, Mobile, Email, Status, [Admit Date], [Deactivate Date], Emp_ID From Emp_Details_Vw"
                Call ShowSearchengine(Txt_EmpID, Sql, 9, "Name", Colwidth, , 0)
            End If

            'Validating Mandatory fields for locating
            If Txt_EmpID.Text.Trim = "" Then
                'MessageBox.Show("Invalid Employee ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_EmpID.Focus() : Exit Sub
            End If

            If Not Is_Emp_Account_Reg(Txt_EmpID.Text.Trim, Txt_AccountNo.Text) Then
                MessageBox.Show("Account already Registered for this Employee", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Btn_Find_Click(sender, e)
            End If
          
            Btn_Save.Focus()
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub DoctorMaster_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then Call SendKeyTab()
    End Sub

    Private Sub DoctorMaster_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try

            'Validating Data controls
            If Not Validate_Fields() Then Exit Sub

            Emp_Acc_Reg_BL = New Emp_Account_Reg_BL_Cls
            Emp_Acc_Reg_BL.Acc_No = Txt_AccountNo.Text.Trim
            Emp_Acc_Reg_BL.Acc_Code = ""
            Emp_Acc_Reg_BL.Emp_ID = Txt_EmpID.Text.Trim
            Emp_Acc_Reg_BL.Reg_Date = Tran_Date
            Emp_Acc_Reg_BL.Active = Strings.Left(Cmb_status.Text, 1).ToUpper
            Emp_Acc_Reg_BL.Deativate_Date = Tran_Date
            Emp_Acc_Reg_BL.Last_TrDate = Tran_Date

            If Emp_Acc_Reg_BL.Save_Emp_Account_Reg(Dtbl, Val(Txt_EmpID.Text.Trim), Tr_Mode) Then
                If Dtbl.Rows(0).Item(0).ToString = "0" Then
                    MessageBox.Show("Employee Account Master Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Exit Sub
                End If
                Txt_AccountNo.Text = Dtbl.Rows(0).Item("Acc_No").ToString
                Tr_Mode = Tran_Mode.Edit_Mode
                MessageBox.Show("Employee Account Master Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Btn_Clear.Focus()
                Dtbl = Nothing
                If Emp_Acc_Reg_BL.Get_Emp_Account_Reg_All(Dtbl, Branch_Code) Then
                    Dgvw_Emp_AccountMaster.DataSource = Dtbl
                    Dgvw_Emp_AccountMaster.Refresh()
                End If
            Else
                MessageBox.Show("Employee Account Master Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Exit Sub
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try
            If Txt_AccountNo.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "200|200|50|"
                Sql = "Select * from  Emp_Account_Reg_Vw Where Br_Code = " & Branch_Code & ""
                Call ShowSearchengine(Txt_AccountNo, Sql, 1, "Name", Colwidth, , 0)
            End If

            'Validating Mandatory fields for locating
            If Txt_AccountNo.Text.Trim = "" Then
                'MessageBox.Show("Invalid Employee ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_AccountNo.Focus() : Exit Sub
            End If


            If Locate_Values() Then
                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Delete.Enabled = True
            Else
                MessageBox.Show("Account Number does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
   
    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Call Clear_Form()
        Txt_AccountNo.Focus()
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

    Private Sub Dgvw_Emp_AccountMaster_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Dgvw_Emp_AccountMaster.DoubleClick
        Try

            With Dgvw_Emp_AccountMaster
                If .CurrentRow Is Nothing Then Exit Sub
                Txt_AccountNo.Text = .Item(1, .CurrentCell.RowIndex).Value.ToString.Trim
                Call Btn_Find_Click(sender, e)
            End With

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click
        Try

            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If

            'Validating Mandatory fields for Deleting
            If Tr_Mode = Tran_Mode.New_Mode Then
                MessageBox.Show("You have to locate details before deleting the record", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            If Txt_AccountNo.Text.Trim = "" Then
                MessageBox.Show("Invalid Account Number,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_AccountNo.Focus() : Exit Sub
            End If

            'Confirm before delete the record
            If MessageBox.Show("Are you sure wan't to delete the selected Account", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = Windows.Forms.DialogResult.No Then
                Exit Sub
            End If

            Dim dtbl As DataTable = Nothing
            Emp_Acc_Reg_BL = New Emp_Account_Reg_BL_Cls
            If Emp_Acc_Reg_BL.Delete_Emp_Acc_Master(dtbl, Txt_AccountNo.Text.Trim, Branch_Code) Then
                If dtbl.Rows(0).Item(0).ToString = "0" Then
                    MessageBox.Show("You cannot delete this employee Account Master details" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
                MessageBox.Show("Employee Account Master Deleted", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Call Btn_Clear_Click(sender, e)
                dtbl = Nothing
                If Emp_Acc_Reg_BL.Get_Emp_Account_Reg_All(dtbl, Branch_Code) Then
                    Dgvw_Emp_AccountMaster.DataSource = dtbl
                    Dgvw_Emp_AccountMaster.Refresh()
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_AccountNo_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_AccountNo.KeyDown
        If e.KeyCode = Keys.F2 Then Btn_Find_Click(sender, e)
    End Sub

End Class
