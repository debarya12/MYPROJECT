﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Accountsreport_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Accountsreport_Frm))
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.Pnl_Commonbuttons = New System.Windows.Forms.Panel
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Show = New System.Windows.Forms.Button
        Me.Pnl_Selreport = New System.Windows.Forms.Panel
        Me.Lbl_Heading = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Pnl_Daybook = New System.Windows.Forms.Panel
        Me.Pnl_Emplist = New System.Windows.Forms.Panel
        Me.Txt_Emp_Add = New System.Windows.Forms.TextBox
        Me.CheckBox1 = New System.Windows.Forms.CheckBox
        Me.Btn_Find = New System.Windows.Forms.Button
        Me.Txt_Emp_Name = New System.Windows.Forms.TextBox
        Me.Pnl_Dtp_1 = New System.Windows.Forms.Panel
        Me.Dtp_1 = New System.Windows.Forms.DateTimePicker
        Me.Lbl_Date1 = New System.Windows.Forms.Label
        Me.Pnl_Dtp_2 = New System.Windows.Forms.Panel
        Me.Dtp_2 = New System.Windows.Forms.DateTimePicker
        Me.Lbl_Date2 = New System.Windows.Forms.Label
        Me.Dgvw_Reportoptions = New REAL_CLINIC.Hms_DGridview(Me.components)
        Me.Reportname = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.ReportID = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Reportfile = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Pnl_Header.SuspendLayout()
        Me.Pnl_Commonbuttons.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.Pnl_Selreport.SuspendLayout()
        Me.Pnl_Daybook.SuspendLayout()
        Me.Pnl_Emplist.SuspendLayout()
        Me.Pnl_Dtp_1.SuspendLayout()
        Me.Pnl_Dtp_2.SuspendLayout()
        CType(Me.Dgvw_Reportoptions, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Menu_Bkg
        Me.Pnl_Header.Controls.Add(Me.Label1)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(802, 24)
        Me.Pnl_Header.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(8, 1)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(227, 18)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "A C C O U N T S   R E P O R T S"
        '
        'Pnl_Commonbuttons
        '
        Me.Pnl_Commonbuttons.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Commonbuttons.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Commonbuttons.Controls.Add(Me.Pnl_Common_Btn)
        Me.Pnl_Commonbuttons.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Pnl_Commonbuttons.Location = New System.Drawing.Point(350, 528)
        Me.Pnl_Commonbuttons.Name = "Pnl_Commonbuttons"
        Me.Pnl_Commonbuttons.Padding = New System.Windows.Forms.Padding(10, 9, 5, 9)
        Me.Pnl_Commonbuttons.Size = New System.Drawing.Size(452, 53)
        Me.Pnl_Commonbuttons.TabIndex = 6
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Show)
        Me.Pnl_Common_Btn.Dock = System.Windows.Forms.DockStyle.Right
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(188, 9)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(257, 33)
        Me.Pnl_Common_Btn.TabIndex = 202
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(86, 2)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(84, 28)
        Me.Btn_Clear.TabIndex = 6
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(170, 2)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(84, 28)
        Me.Btn_Close.TabIndex = 7
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Show
        '
        Me.Btn_Show.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Show.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Show.ForeColor = System.Drawing.Color.White
        Me.Btn_Show.Location = New System.Drawing.Point(2, 2)
        Me.Btn_Show.Name = "Btn_Show"
        Me.Btn_Show.Size = New System.Drawing.Size(84, 28)
        Me.Btn_Show.TabIndex = 5
        Me.Btn_Show.Text = "&Show"
        Me.Btn_Show.UseVisualStyleBackColor = False
        '
        'Pnl_Selreport
        '
        Me.Pnl_Selreport.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Selreport.Controls.Add(Me.Lbl_Heading)
        Me.Pnl_Selreport.Controls.Add(Me.Label2)
        Me.Pnl_Selreport.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Selreport.Location = New System.Drawing.Point(350, 24)
        Me.Pnl_Selreport.Name = "Pnl_Selreport"
        Me.Pnl_Selreport.Size = New System.Drawing.Size(452, 37)
        Me.Pnl_Selreport.TabIndex = 7
        '
        'Lbl_Heading
        '
        Me.Lbl_Heading.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Heading.Dock = System.Windows.Forms.DockStyle.Right
        Me.Lbl_Heading.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Lbl_Heading.Location = New System.Drawing.Point(106, 0)
        Me.Lbl_Heading.Name = "Lbl_Heading"
        Me.Lbl_Heading.Size = New System.Drawing.Size(346, 37)
        Me.Lbl_Heading.TabIndex = 36
        Me.Lbl_Heading.Text = "REPORT NAME"
        Me.Lbl_Heading.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Blue
        Me.Label2.Location = New System.Drawing.Point(3, 12)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(106, 13)
        Me.Label2.TabIndex = 35
        Me.Label2.Text = "SELECTED REPORT :"
        '
        'Pnl_Daybook
        '
        Me.Pnl_Daybook.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Daybook.Controls.Add(Me.Pnl_Emplist)
        Me.Pnl_Daybook.Controls.Add(Me.Pnl_Dtp_1)
        Me.Pnl_Daybook.Controls.Add(Me.Pnl_Dtp_2)
        Me.Pnl_Daybook.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Pnl_Daybook.Location = New System.Drawing.Point(350, 61)
        Me.Pnl_Daybook.Name = "Pnl_Daybook"
        Me.Pnl_Daybook.Size = New System.Drawing.Size(452, 467)
        Me.Pnl_Daybook.TabIndex = 8
        '
        'Pnl_Emplist
        '
        Me.Pnl_Emplist.Controls.Add(Me.Txt_Emp_Add)
        Me.Pnl_Emplist.Controls.Add(Me.CheckBox1)
        Me.Pnl_Emplist.Controls.Add(Me.Btn_Find)
        Me.Pnl_Emplist.Controls.Add(Me.Txt_Emp_Name)
        Me.Pnl_Emplist.Location = New System.Drawing.Point(3, 319)
        Me.Pnl_Emplist.Name = "Pnl_Emplist"
        Me.Pnl_Emplist.Size = New System.Drawing.Size(446, 100)
        Me.Pnl_Emplist.TabIndex = 212
        '
        'Txt_Emp_Add
        '
        Me.Txt_Emp_Add.BackColor = System.Drawing.Color.White
        Me.Txt_Emp_Add.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Emp_Add.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Emp_Add.Location = New System.Drawing.Point(117, 28)
        Me.Txt_Emp_Add.Multiline = True
        Me.Txt_Emp_Add.Name = "Txt_Emp_Add"
        Me.Txt_Emp_Add.ReadOnly = True
        Me.Txt_Emp_Add.Size = New System.Drawing.Size(328, 68)
        Me.Txt_Emp_Add.TabIndex = 213
        Me.Txt_Emp_Add.TabStop = False
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.CheckBox1.ForeColor = System.Drawing.Color.Navy
        Me.CheckBox1.Location = New System.Drawing.Point(1, 7)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(109, 17)
        Me.CheckBox1.TabIndex = 212
        Me.CheckBox1.Text = "Employee Wise"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'Btn_Find
        '
        Me.Btn_Find.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find.BackgroundImage = CType(resources.GetObject("Btn_Find.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find.ForeColor = System.Drawing.Color.White
        Me.Btn_Find.Location = New System.Drawing.Point(417, 4)
        Me.Btn_Find.Name = "Btn_Find"
        Me.Btn_Find.Size = New System.Drawing.Size(28, 21)
        Me.Btn_Find.TabIndex = 211
        Me.Btn_Find.TabStop = False
        Me.Btn_Find.Text = "F2"
        Me.Btn_Find.UseVisualStyleBackColor = False
        '
        'Txt_Emp_Name
        '
        Me.Txt_Emp_Name.BackColor = System.Drawing.Color.White
        Me.Txt_Emp_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Emp_Name.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Emp_Name.Location = New System.Drawing.Point(117, 4)
        Me.Txt_Emp_Name.Name = "Txt_Emp_Name"
        Me.Txt_Emp_Name.Size = New System.Drawing.Size(299, 21)
        Me.Txt_Emp_Name.TabIndex = 210
        '
        'Pnl_Dtp_1
        '
        Me.Pnl_Dtp_1.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Dtp_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Dtp_1.Controls.Add(Me.Dtp_1)
        Me.Pnl_Dtp_1.Controls.Add(Me.Lbl_Date1)
        Me.Pnl_Dtp_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Pnl_Dtp_1.Location = New System.Drawing.Point(132, 129)
        Me.Pnl_Dtp_1.Name = "Pnl_Dtp_1"
        Me.Pnl_Dtp_1.Size = New System.Drawing.Size(188, 27)
        Me.Pnl_Dtp_1.TabIndex = 211
        '
        'Dtp_1
        '
        Me.Dtp_1.CustomFormat = " dd/MM/yyyy"
        Me.Dtp_1.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_1.Location = New System.Drawing.Point(70, 2)
        Me.Dtp_1.Name = "Dtp_1"
        Me.Dtp_1.Size = New System.Drawing.Size(114, 21)
        Me.Dtp_1.TabIndex = 9
        '
        'Lbl_Date1
        '
        Me.Lbl_Date1.AutoSize = True
        Me.Lbl_Date1.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Date1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Lbl_Date1.Location = New System.Drawing.Point(23, 8)
        Me.Lbl_Date1.Name = "Lbl_Date1"
        Me.Lbl_Date1.Size = New System.Drawing.Size(36, 13)
        Me.Lbl_Date1.TabIndex = 23
        Me.Lbl_Date1.Text = "From"
        '
        'Pnl_Dtp_2
        '
        Me.Pnl_Dtp_2.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Dtp_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Dtp_2.Controls.Add(Me.Dtp_2)
        Me.Pnl_Dtp_2.Controls.Add(Me.Lbl_Date2)
        Me.Pnl_Dtp_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Pnl_Dtp_2.Location = New System.Drawing.Point(132, 179)
        Me.Pnl_Dtp_2.Name = "Pnl_Dtp_2"
        Me.Pnl_Dtp_2.Size = New System.Drawing.Size(188, 26)
        Me.Pnl_Dtp_2.TabIndex = 210
        '
        'Dtp_2
        '
        Me.Dtp_2.CustomFormat = " dd/MM/yyyy"
        Me.Dtp_2.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_2.Location = New System.Drawing.Point(70, 2)
        Me.Dtp_2.Name = "Dtp_2"
        Me.Dtp_2.Size = New System.Drawing.Size(114, 21)
        Me.Dtp_2.TabIndex = 9
        '
        'Lbl_Date2
        '
        Me.Lbl_Date2.AutoSize = True
        Me.Lbl_Date2.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Date2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Lbl_Date2.Location = New System.Drawing.Point(38, 8)
        Me.Lbl_Date2.Name = "Lbl_Date2"
        Me.Lbl_Date2.Size = New System.Drawing.Size(21, 13)
        Me.Lbl_Date2.TabIndex = 23
        Me.Lbl_Date2.Text = "To"
        '
        'Dgvw_Reportoptions
        '
        Me.Dgvw_Reportoptions.AllowUserToAddRows = False
        Me.Dgvw_Reportoptions.AllowUserToDeleteRows = False
        Me.Dgvw_Reportoptions.AllowUserToResizeColumns = False
        Me.Dgvw_Reportoptions.AllowUserToResizeRows = False
        Me.Dgvw_Reportoptions.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(118, Byte), Integer), CType(CType(155, Byte), Integer), CType(CType(197, Byte), Integer))
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(87, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(162, Byte), Integer))
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.AliceBlue
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgvw_Reportoptions.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.Dgvw_Reportoptions.ColumnHeadersHeight = 25
        Me.Dgvw_Reportoptions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.Dgvw_Reportoptions.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Reportname, Me.ReportID, Me.Reportfile})
        Me.Dgvw_Reportoptions.Dock = System.Windows.Forms.DockStyle.Left
        Me.Dgvw_Reportoptions.Location = New System.Drawing.Point(0, 24)
        Me.Dgvw_Reportoptions.Name = "Dgvw_Reportoptions"
        Me.Dgvw_Reportoptions.RowHeadersVisible = False
        Me.Dgvw_Reportoptions.Size = New System.Drawing.Size(350, 557)
        Me.Dgvw_Reportoptions.TabIndex = 5
        '
        'Reportname
        '
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(248, Byte), Integer))
        Me.Reportname.DefaultCellStyle = DataGridViewCellStyle4
        Me.Reportname.Frozen = True
        Me.Reportname.HeaderText = "R E P O R T S"
        Me.Reportname.Name = "Reportname"
        Me.Reportname.ReadOnly = True
        Me.Reportname.Width = 347
        '
        'ReportID
        '
        Me.ReportID.HeaderText = "ReportID"
        Me.ReportID.Name = "ReportID"
        Me.ReportID.Visible = False
        '
        'Reportfile
        '
        Me.Reportfile.HeaderText = ""
        Me.Reportfile.Name = "Reportfile"
        Me.Reportfile.ReadOnly = True
        Me.Reportfile.Visible = False
        '
        'Accountsreport_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.LeftGradiant
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(802, 581)
        Me.Controls.Add(Me.Pnl_Daybook)
        Me.Controls.Add(Me.Pnl_Selreport)
        Me.Controls.Add(Me.Pnl_Commonbuttons)
        Me.Controls.Add(Me.Dgvw_Reportoptions)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Accountsreport_Frm"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Pnl_Commonbuttons.ResumeLayout(False)
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.Pnl_Selreport.ResumeLayout(False)
        Me.Pnl_Selreport.PerformLayout()
        Me.Pnl_Daybook.ResumeLayout(False)
        Me.Pnl_Emplist.ResumeLayout(False)
        Me.Pnl_Emplist.PerformLayout()
        Me.Pnl_Dtp_1.ResumeLayout(False)
        Me.Pnl_Dtp_1.PerformLayout()
        Me.Pnl_Dtp_2.ResumeLayout(False)
        Me.Pnl_Dtp_2.PerformLayout()
        CType(Me.Dgvw_Reportoptions, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Dgvw_Reportoptions As REAL_CLINIC.Hms_DGridview
    Friend WithEvents Pnl_Commonbuttons As System.Windows.Forms.Panel
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Show As System.Windows.Forms.Button
    Friend WithEvents Pnl_Selreport As System.Windows.Forms.Panel
    Friend WithEvents Pnl_Daybook As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Heading As System.Windows.Forms.Label
    Friend WithEvents Reportname As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ReportID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Reportfile As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Pnl_Dtp_1 As System.Windows.Forms.Panel
    Friend WithEvents Dtp_1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Lbl_Date1 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Dtp_2 As System.Windows.Forms.Panel
    Friend WithEvents Dtp_2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Lbl_Date2 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Emplist As System.Windows.Forms.Panel
    Friend WithEvents Txt_Emp_Add As System.Windows.Forms.TextBox
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents Btn_Find As System.Windows.Forms.Button
    Friend WithEvents Txt_Emp_Name As System.Windows.Forms.TextBox
End Class
