﻿
Option Explicit On
Imports System.IO
Imports HMS_BL
Imports HMS_Common.Common_Cls
Public Class Patient_Deposit_Reg_Frm

    Private mTr_Mode As Tran_Mode
    Private hms_helper As HMS_Helper = Nothing
    Private Patient_Deposit_BL As Patient_Deposit_Details_BL_Cls
    Private Gen_Tran_BL As Gen_Transaction_BL_Cls
    Private Patient_Tran_BL As Patient_Transaction_BL_Cls

    Private mRpt_Vwr As ReportViewer_Cls
    Private Rpt_BL As HMS_BL.Reports_BL_Cls

    'Transaction Mode checking Property
    Public Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_TranID.BackColor = Color.White
                    Me.Txt_OutPatientID.ReadOnly = False
                    Me.Txt_PatientID.ReadOnly = False
                    Me.Txt_TranID.ReadOnly = False
                    Me.Btn_Save.Enabled = True


                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_TranID.BackColor = Color.Silver
                    Me.Txt_OutPatientID.ReadOnly = True
                    Me.Txt_PatientID.ReadOnly = True
                    Me.Txt_TranID.ReadOnly = True
                    Me.Btn_Save.Enabled = True

            End Select
        End Set
    End Property

  

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing

    Private Sub Reports_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub Reports_Frm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            hms_helper = New Hms_Helperimpliments
            If Tr_Mode = Tran_Mode.New_Mode Then hms_helper.Fill_GenData(Cmb_Payment_Mode, Gendatatype.Payment_Mode, "< Select >")

            Txt_TranID.Focus()

            Dtp_Trandate.Value = Tran_Date
        Catch ex As Exception

        End Try
    End Sub

#Region "Methods"


    Private Sub Clear_Form()
        Try
            Clear_Values()
            Txt_PMRID.Text = ""
            Txt_PatientID.Text = ""
            Txt_OutPatientID.Text = ""
            Txt_DepositBalance.Text = ""

            Patient_Info2.Patient_ID = -1
            Btn_Utility.CUST_ID = ""

            Tr_Mode = Tran_Mode.New_Mode
            Btn_Cancel.Enabled = False
            Dgv_Patient_Dep.DataSource = Nothing
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Clear_Values()
        Try

            Txt_TranID.Text = ""
            Txt_Amount.Text = ""
            Txt_Narration.Text = ""
            Txt_DepositBalance.Text = ""
            If Cmb_Payment_Mode.Items.Count > 0 Then Cmb_Payment_Mode.SelectedIndex = 0
        Catch ex As Exception

        End Try

    End Sub

    Private Function Locate_Patient(ByVal Patient_ID As String) As Boolean
        Try

            hms_helper = New Hms_Helperimpliments
            If hms_helper.Get_OutPatient_Info_Latest(Dtbl, Txt_PatientID.Text.Trim, Tran_Date, Branch_Code) Then
                Txt_OutPatientID.Text = Dtbl.Rows(0).Item("OPD_ID").ToString
                Call Locate_Outpatient(Txt_OutPatientID.Text.Trim)
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Locate_Outpatient(ByVal OP_ID As String) As Boolean
        Try
            Dim dtbl As DataTable = Nothing
            REM locating patient information
            hms_helper = New Hms_Helperimpliments

            If hms_helper.Get_OutPatient_Doctor(dtbl, OP_ID, Branch_Code) Then

            End If

            dtbl = Nothing
            If hms_helper.Get_OP_Details(dtbl, Txt_OutPatientID.Text.Trim) Then

                Txt_PatientID.Text = dtbl.Rows(0).Item("Patient ID").ToString


                'Call Populate_Grid(Txt_PatientID.Text, Txt_OutPatientID.Text)

                With Patient_Info2
                    .Viewmoreform_Name = "Patient_InfoSheet_Frm"
                    .MDIform_Name = Me.MdiParent
                    .Patient_ID = Txt_PatientID.Text.Trim
                End With

                With Btn_Utility
                    .CUST_ID = Txt_PatientID.Text.Trim
                    .CUST_TYPE = Customer_Type.Patient
                End With
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function Assigncontrols(ByVal dtbl As DataTable) As Boolean
        Try

            REM locating patient information
            hms_helper = New Hms_Helperimpliments
            Dim dtbl1 As DataTable = Nothing

            With dtbl
                Txt_TranID.Text = .Rows(0).Item("Tran_ID").ToString.Trim
                Txt_PatientID.Text = .Rows(0).Item("Patient_ID").ToString.Trim
                If hms_helper.Get_OutPatient_ID_Latest(dtbl1, Txt_PatientID.Text, Tran_Date, Branch_Code) Then
                    Txt_OutPatientID.Text = dtbl1.Rows(0).Item(0).ToString
                End If

                Cmb_Payment_Mode.SelectedValue = .Rows(0).Item("Transaction_Mode").ToString.Trim

                Txt_Amount.Text = .Rows(0).Item("Tr_Amount").ToString.Trim
                Txt_Narration.Text = .Rows(0).Item("Narration").ToString.Trim
            End With

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function Locate_Values(ByVal Tran_ID As String) As Boolean
        Try
            hms_helper = New Hms_Helperimpliments

            Patient_Deposit_BL = New Patient_Deposit_Details_BL_Cls

            Dim dtbl As DataTable = Nothing


            If Patient_Deposit_BL.Get_Patient_Deposit(dtbl, Tran_ID, Branch_Code) Then

                Txt_PatientID.Text = dtbl.Rows(0).Item("Patient ID").ToString.Trim

                Txt_OutPatientID.Text = dtbl.Rows(0).Item("OP ID").ToString.Trim


                Cmb_Payment_Mode.SelectedValue = dtbl.Rows(0).Item("Transaction_Mode").ToString.Trim

                Txt_Amount.Text = dtbl.Rows(0).Item("Amount").ToString.Trim
                Txt_Narration.Text = dtbl.Rows(0).Item("Narration").ToString.Trim
                With Patient_Info2
                    .Viewmoreform_Name = "Patient_InfoSheet_Frm"
                    .MDIform_Name = Me.MdiParent
                    .Patient_ID = Txt_PatientID.Text.Trim
                End With

                With Btn_Utility
                    .CUST_ID = Txt_PatientID.Text.Trim
                    .CUST_TYPE = Customer_Type.Patient
                End With
            Else
                Return False
            End If
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Validate_Fields() As Boolean
        Try
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If


            If Tr_Mode <> Tran_Mode.New_Mode Then
                If Txt_TranID.Text.Trim = "" Then MessageBox.Show("Invalid Tran ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_TranID.Focus() : Return False
            End If
            'validating all mandatory fields
            If Txt_OutPatientID.Text.Trim = "" Then MessageBox.Show("Invalid Patient ID, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_OutPatientID.Focus() : Return False
            If Txt_PatientID.Text.Trim = "" Then MessageBox.Show("Invalid Patient ID, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_PatientID.Focus() : Return False
            If Txt_Amount.Text.Trim = "" Then MessageBox.Show("Invalid Deposit Amount, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Amount.Focus() : Return False
            If Cmb_Payment_Mode.SelectedIndex = 0 Then MessageBox.Show("Invalid Pament Mode, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_Payment_Mode.Focus() : Return False

            Return True

        Catch ex As Exception

        End Try

    End Function

#End Region

    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try
            If Txt_OutPatientID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "10|50|50|50|50|200"
                Sql = "SELECT   *  FROM    OPD_Master_Vw where Active='Y' and Br_Code='" & Branch_Code & "'"
                Call ShowSearchengine(Txt_OutPatientID, Sql, 0, "Patient Name", Colwidth, , 0)
            End If

            If Txt_OutPatientID.Text.Trim = "" Then
                Txt_OutPatientID.Focus() : Exit Sub
            End If

            If Locate_Outpatient(Txt_OutPatientID.Text.Trim) Then

            Else
                MessageBox.Show("Outpatient ID not found, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Txt_OutPatientID.Focus()
            End If


        Catch ex As Exception

        End Try
    End Sub


    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Try
            Me.Close()
        Catch ex As Exception

        End Try

    End Sub


    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try
            Dim Dtbl As DataTable = Nothing
            Dim Tran_BatchID As String = ""
            Patient_Deposit_BL = New Patient_Deposit_Details_BL_Cls

            If Not Validate_Fields() Then Exit Sub

            Patient_Deposit_BL.Tran_ID = Val(Txt_TranID.Text.Trim)
            hms_helper = New Hms_Helperimpliments

            Patient_Deposit_BL.ACC_ID = Txt_PMRID.Text
            Patient_Deposit_BL.Acc_Code = "10"
            Patient_Deposit_BL.Patient_ID = Txt_PatientID.Text.Trim
            Patient_Deposit_BL.Tr_Date = Tran_Date
            Patient_Deposit_BL.Tr_Amount = Txt_Amount.Text.Trim
            Patient_Deposit_BL.Narration = Txt_Narration.Text.Trim
            Patient_Deposit_BL.Transaction_Mode = Cmb_Payment_Mode.SelectedValue
            Patient_Deposit_BL.tran_Type = "R"


            If Tr_Mode = Tran_Mode.New_Mode Then
                If Not Save_General_Transaction(Tran_BatchID) Then _
                MessageBox.Show("Transaction Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error) : Exit Sub
                Patient_Deposit_BL.Tran_BatchID = Tran_BatchID

            Else
                Patient_Deposit_BL.Tran_BatchID = Txt_Tran_BatchID.Text
                Gen_Tran_BL = New Gen_Transaction_BL_Cls
                If Gen_Tran_BL.Cancell_General_Transaction(Dtbl, Txt_Tran_BatchID.Text, Txt_Narration.Text, _
                                                            Tran_Date, Tran_Date, Branch_Code) Then
                    If Dtbl.Rows(0).Item(0).ToString = 0 Then
                        MessageBox.Show("Cancellation Failed , Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If

                End If

            End If

            Dtbl = Nothing
            If Patient_Deposit_BL.Save_Patient_Deposit(Dtbl, Tr_Mode, Val(Txt_TranID.Text.Trim)) Then
                MessageBox.Show("Patient Transaction  Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Populate_Grid(Txt_PMRID.Text)
                Get_Patient_CreditPosition(Txt_PatientID.Text, Txt_OutPatientID.Text)
            Else
                MessageBox.Show("Patient Transaction  Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)

            End If
            Call Clear_Values()
        Catch ex As Exception

        End Try
    End Sub

    Public Function Save_General_Transaction(ByRef Tran_BatchID As String) As Boolean
        Try
            Dim dtbl As DataTable = Nothing
            Gen_Tran_BL = New Gen_Transaction_BL_Cls
            With Gen_Tran_BL

                If Gen_Tran_BL.Get_Maxmimum_BatchNo_GenTran(dtbl) Then
                    Dr = dtbl.CreateDataReader
                    Dr.Read()
                    Gen_Tran_BL.Tran_BatchID = Dr.GetValue(0).ToString.Trim
                    If Gen_Tran_BL.Tran_BatchID = "" Then Gen_Tran_BL.Tran_BatchID = "0000000001"
                End If
                If Tr_Mode = Tran_Mode.Edit_Mode Then Gen_Tran_BL.Tran_BatchID = Tran_BatchID

                Tran_BatchID = Gen_Tran_BL.Tran_BatchID
                .Tr_RefNo = Txt_TranID.Text
                .Tr_Date = Tran_Date
                .Tr_Narration = Txt_Narration.Text
                .Tr_Pay_Mode = Cmb_Payment_Mode.SelectedValue
                .Tr_Type = "R"
                .Acc_Code = "10"
                .Tr_Remarks = Txt_PatientID.Text
                .Tr_Amount = Txt_Amount.Text

                dtbl = Nothing

                If Gen_Tran_BL.Save_Gen_Transaction(dtbl, Tr_Mode, Gen_Tran_BL.Tran_BatchID) Then
                    If dtbl.Rows(0).Item(0).ToString = "0" Then
                        MessageBox.Show("General Transaction Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                        Return False
                    End If
                Else
                    MessageBox.Show("General Transaction Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
                Return True

            End With
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try
            Call Clear_Form()
            Txt_OutPatientID.Focus()
        Catch ex As Exception

        End Try
    End Sub

    Public Sub Btn_FindBatch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try
            If Tr_Mode = Tran_Mode.New_Mode Then
                If Txt_TranID.Text.Trim = "" Then
                    Call Clear_Form()
                    Dim Sql As String
                    Dim Colwidth As String = ""
                    Colwidth = "10|50|50|50|50"
                    Sql = "SELECT *  FROM dbo.Patient_Deposit_Vw where [Tran Date] ='" & Format(Tran_Date, "MM/dd/yyyy") & "' and Br_Code = " & Branch_Code & " "
                    Call ShowSearchengine(Txt_TranID, Sql, 0, "Name", Colwidth, , 0)
                End If
            End If

            If Txt_TranID.Text.Trim = "" Then
                Txt_TranID.Focus() : Exit Sub
            End If

            If Locate_Values(Txt_TranID.Text.Trim) Then
                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Cancel.Enabled = True

            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Cancel.Click
        Try
            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If

            If Not Cancel_Verification() Then Exit Sub
            Dim dtbl As DataTable = Nothing
            Patient_Deposit_BL = New Patient_Deposit_Details_BL_Cls
            If MessageBox.Show("Cancel the entry ..(Y/N) ?", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                Gen_Tran_BL = New Gen_Transaction_BL_Cls
                If Gen_Tran_BL.Cancell_General_Transaction(Dtbl, Txt_Tran_BatchID.Text, Txt_Narration.Text, _
                                                            Tran_Date, Tran_Date, Branch_Code) Then
                    If dtbl.Rows(0).Item(0).ToString = "0" Then
                        MessageBox.Show("Cancellation Failed , Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If

                End If


                If Patient_Deposit_BL.Cancel_Patient_Deposit(Txt_TranID.Text.Trim, Txt_PatientID.Text, Branch_Code) Then
                    MessageBox.Show("Patient Deposit Cancelled", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
            Else
                Btn_Clear.Focus()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Function Cancel_Verification() As Boolean
        Try

            If DateDiff(DateInterval.Day, Tran_Date, Dtp_Trandate.Value) <> 0 Then _
              MessageBox.Show("Cancellation possible only on current date", _
              Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Warning) : Return False

            If Val(Txt_Amount.Text) > Val(Txt_DepositBalance.Text) Then _
              MessageBox.Show("Amount is greater than deposit balance, Please check", _
              Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Warning) : Return False

            If Val(Txt_Amount.Text) <= 0 Then _
             MessageBox.Show("Already Cancelled Transaction, Please check", _
             Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Warning) : Return False


            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Txt_BatchID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_TranID.KeyDown
        If e.KeyCode = Keys.Enter Then Txt_OutPatientID.Focus()
        If e.KeyCode = Keys.F2 Then Btn_FindBatch_Click(sender, e)
    End Sub

    Private Sub Btn_FindPatientID_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try

            If Txt_PatientID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "10|200|50|"
                Sql = "SELECT     [Patient ID], [Patient Name], Doctor, Service, OPD_ID FROM   OPD_Master_Vw"
                Call ShowSearchengine(Txt_OutPatientID, Sql, 4, "Name", Colwidth, , 0)

                If Txt_OutPatientID.Text.Trim = "" Then
                    Txt_PatientID.Focus() : Exit Sub
                End If

                If Locate_Outpatient(Txt_OutPatientID.Text.Trim) Then

                Else
                    MessageBox.Show("Patient ID not found, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Txt_PatientID.Focus()
                End If


            Else

                Dim dtbl As DataTable = Nothing

                hms_helper = New Hms_Helperimpliments
                If hms_helper.Get_OutPatient_Info_Latest(dtbl, Txt_PatientID.Text.Trim, Tran_Date, Branch_Code) Then
                    Txt_OutPatientID.Text = dtbl.Rows(0).Item("OPD_ID").ToString
                    If Locate_Outpatient(Txt_OutPatientID.Text.Trim) Then

                    Else
                        MessageBox.Show("Patient ID not found, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                        Txt_PatientID.Focus()
                    End If
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Uttility_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try
            Show_ChildForm("Patient_Transaction_Uttility_Frm", Me.MdiParent, Me.Tag)
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Txt_Amount_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Amount.KeyDown
        If e.KeyCode = Keys.Enter Then Cmb_Payment_Mode.Focus()
    End Sub

    Private Sub Txt_Amount_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Amount.TextChanged
        Try
            Lbl_Words.Text = Towords(Val(Txt_Amount.Text))
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Cmb_Payment_Mode_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Cmb_Payment_Mode.KeyDown
        If e.KeyCode = Keys.Enter Then Txt_Narration.Focus()
    End Sub


    Private Sub Txt_Narration_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Narration.KeyDown
        If e.KeyCode = Keys.Enter Then Btn_Save.Focus()
    End Sub


    Private Sub Btn_Report_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Report.Click
        Try
            Call Show_Reciept(Txt_PatientID.Text.Trim, Txt_OutPatientID.Text.Trim)
        Catch ex As Exception

        End Try
    End Sub
    Public Function Show_Reciept(ByVal PatientID As String, ByVal OPD_ID As String) As Boolean
        Try
            If PatientID = "" Then MessageBox.Show("Invalid  Patient ID .. Please enter valid Patient Id", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_PatientID.Focus() : Exit Function
            If OPD_ID = "" Then MessageBox.Show("Invalid  OP ID .. Please enter valid Outpatient Id", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_OutPatientID.Focus() : Exit Function
            Dim Rpt_Ds As DataSet = Nothing
            Dim Rpt_Formulafields As String = "Company| " & Company_Name & "|Branch|" & Branch_Name
            Dim Rpt_Filename As String = ""
            Dim mReport_ID As String = ""
            Dim Report_Heading As String = ""
            Dim Add_Query As String = ""

            mRpt_Vwr = New ReportViewer_Cls

            Add_Query = ""
            Add_Query = "Where [Patient ID] = " & PatientID & " and [OP ID] = " & OPD_ID & " and Br_Code=" & Branch_Code & ""
            Rpt_Filename = File_Path & "\Patient_Deposits_Details.rpt"
            Patient_Deposit_BL = New Patient_Deposit_Details_BL_Cls
            If Patient_Deposit_BL.Get_Patients_Deposit_Det(Rpt_Ds, Add_Query) Then
                Report_Heading = "|Heading| Patient Deposit Details|Footer3|Authorised Signatory"
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading & ")"
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "")
            Else
                MessageBox.Show("Invalid Patient ID/OP ID .. Please enter valid Patient/OP ID", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Txt_PatientID.Focus()
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function
    Public Function Populate_Grid(ByVal Account_ID As String) As Boolean
        Try

            Patient_Deposit_BL = New Patient_Deposit_Details_BL_Cls
            Dgv_Patient_Dep.DataSource = Nothing
            If Patient_Deposit_BL.Get_Pat_Deposit_Det(Dtbl, Account_ID) Then
                Dgv_Patient_Dep.DataSource = Dtbl
            End If

        Catch ex As Exception

        End Try
    End Function

    Private Sub Cmb_TranType_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs)
        If e.KeyCode = Keys.Enter Then Cmb_Payment_Mode.Focus()
    End Sub

    Private Sub Btn_PMRFind_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_PMRFind.Click
        Try
            If Txt_PMRID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "200|50|300|70|"
                Sql = "SELECT [Patient Name], [S.S.No], ([Family Name] + Address + City) as Address, ACC_ID AS [PMR-ID]"
                Sql += "FROM Patient_Account_Vw WHERE ([Account Status] = 'Active') and Br_Code ='" & Branch_Code & "'"

                Call ShowSearchengine(Txt_PMRID, Sql, 3, "[Patient Name]", Colwidth, , 0)
            End If

            'Validating Mandatory fields for locating
            If Txt_PMRID.Text.Trim = "" Then
                'MessageBox.Show("Invalid Appointment ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_PMRID.Focus() : Exit Sub
            End If

            If Locate_PMR_info(Txt_PMRID.Text.Trim, Branch_Code) Then
                Txt_Amount.Focus()
            Else
                MessageBox.Show("Invalid PMR ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Catch ex As Exception

        End Try
    End Sub
    Private Function Locate_PMR_info(ByVal PMR_ID As String, ByVal Br_Code As Integer) As Boolean
        Try

            '-----------------   Clear Medical Record   -----------------------------------

            Call Clear_Form()

            '----------------------------------------------------------------------------

            Dim Dtbl As DataTable = Nothing

            '-----------------  Locate Pateint Medical Record Master info   -------------
            If Not hms_helper.Get_PMR_Masterinfo(Dtbl, PMR_ID, Br_Code) Then Return False


            With Dtbl
                Txt_PMRID.Text = PMR_ID
                Patient_Info2.Patient_ID = .Rows(0).Item("Patient ID").ToString
                Txt_PatientID.Text = .Rows(0).Item("Patient ID").ToString
                Txt_OutPatientID.Text = .Rows(0).Item("OP ID").ToString

            End With


            Btn_Utility.CUST_ID = Txt_PatientID.Text
            Btn_Utility.CUST_TYPE = Customer_Type.Patient

            Call Get_Patient_CreditPosition(Txt_PatientID.Text, Txt_OutPatientID.Text)


            Call Populate_Grid(PMR_ID)

            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Txt_PMRID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_PMRID.KeyDown
        If e.KeyCode = Keys.F2 Then Btn_PMRFind_Click(Nothing, Nothing)
    End Sub

    Private Sub Txt_PMRID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_PMRID.TextChanged
        If Txt_PMRID.Text.Trim = "" Then Call Clear_Form()
    End Sub

    Public Sub Get_Patient_CreditPosition(ByVal Patient_ID As String, ByVal OPD_ID As String)
        Try
            Dim dtbl As DataTable = Nothing
            Patient_Tran_BL = New Patient_Transaction_BL_Cls

            If Patient_Tran_BL.Get_Patient_CreditPosition(dtbl, Txt_PMRID.Text, Tran_Date, Branch_Code) Then
                Txt_DepositBalance.Text = dtbl.Rows(0).Item("Balance").ToString
            End If
            If Val(Txt_DepositBalance.Text) < 0 Then Txt_DepositBalance.Text = 0
            Txt_DepositBalance.Text = CDbl(Txt_DepositBalance.Text).ToString("0.00")
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Btn_Utl_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Utl.Click
        Try
            Show_ChildForm("Patient_Deposit_Uttility_Frm", Me.MdiParent, Me.Tag)
        Catch ex As Exception

        End Try
    End Sub

   
End Class
