﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Userrights_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Userrights_Frm))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.Cmb_Menugroup = New System.Windows.Forms.ComboBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Cmb_Allotmenttype = New System.Windows.Forms.ComboBox
        Me.Pnl_Empdetails = New System.Windows.Forms.Panel
        Me.Txt_Emp_Add = New System.Windows.Forms.TextBox
        Me.Btn_Find = New System.Windows.Forms.Button
        Me.Txt_Emp_Name = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Pnl_Designations = New System.Windows.Forms.Panel
        Me.ChkLst_Designations = New System.Windows.Forms.CheckedListBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Btn_Loaddefault = New System.Windows.Forms.Button
        Me.Dgv_Userrights = New REAL_CLINIC.Hms_DGridview(Me.components)
        Me.Formname = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Viewright = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.Addright = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.Editright = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.Deleteright = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.FormID = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.Pnl_Header.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.Pnl_Empdetails.SuspendLayout()
        Me.Pnl_Designations.SuspendLayout()
        CType(Me.Dgv_Userrights, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Menu_Bkg
        Me.Pnl_Header.Controls.Add(Me.Label1)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(802, 24)
        Me.Pnl_Header.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(7, 1)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(312, 18)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "U S E R    R I G H T S    A S S I G N M E N T"
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(575, 543)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(221, 33)
        Me.Pnl_Common_Btn.TabIndex = 201
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(74, 2)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(72, 28)
        Me.Btn_Clear.TabIndex = 6
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(146, 2)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(72, 28)
        Me.Btn_Close.TabIndex = 7
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(2, 2)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(72, 28)
        Me.Btn_Save.TabIndex = 5
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Cmb_Menugroup
        '
        Me.Cmb_Menugroup.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Menugroup.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Menugroup.FormattingEnabled = True
        Me.Cmb_Menugroup.Location = New System.Drawing.Point(86, 36)
        Me.Cmb_Menugroup.Name = "Cmb_Menugroup"
        Me.Cmb_Menugroup.Size = New System.Drawing.Size(326, 21)
        Me.Cmb_Menugroup.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.Navy
        Me.Label2.Location = New System.Drawing.Point(4, 37)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(75, 13)
        Me.Label2.TabIndex = 203
        Me.Label2.Text = "Menu Group"
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.Navy
        Me.Label3.Location = New System.Drawing.Point(4, 62)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(76, 27)
        Me.Label3.TabIndex = 206
        Me.Label3.Text = "Allotment Type"
        '
        'Cmb_Allotmenttype
        '
        Me.Cmb_Allotmenttype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Allotmenttype.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Allotmenttype.FormattingEnabled = True
        Me.Cmb_Allotmenttype.Location = New System.Drawing.Point(86, 64)
        Me.Cmb_Allotmenttype.Name = "Cmb_Allotmenttype"
        Me.Cmb_Allotmenttype.Size = New System.Drawing.Size(326, 21)
        Me.Cmb_Allotmenttype.TabIndex = 1
        '
        'Pnl_Empdetails
        '
        Me.Pnl_Empdetails.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Empdetails.Controls.Add(Me.Txt_Emp_Add)
        Me.Pnl_Empdetails.Controls.Add(Me.Btn_Find)
        Me.Pnl_Empdetails.Controls.Add(Me.Txt_Emp_Name)
        Me.Pnl_Empdetails.Controls.Add(Me.Label5)
        Me.Pnl_Empdetails.Location = New System.Drawing.Point(419, 44)
        Me.Pnl_Empdetails.Name = "Pnl_Empdetails"
        Me.Pnl_Empdetails.Size = New System.Drawing.Size(380, 117)
        Me.Pnl_Empdetails.TabIndex = 2
        Me.Pnl_Empdetails.TabStop = True
        Me.Pnl_Empdetails.Visible = False
        '
        'Txt_Emp_Add
        '
        Me.Txt_Emp_Add.BackColor = System.Drawing.Color.White
        Me.Txt_Emp_Add.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Emp_Add.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Emp_Add.Location = New System.Drawing.Point(4, 48)
        Me.Txt_Emp_Add.Multiline = True
        Me.Txt_Emp_Add.Name = "Txt_Emp_Add"
        Me.Txt_Emp_Add.ReadOnly = True
        Me.Txt_Emp_Add.Size = New System.Drawing.Size(372, 68)
        Me.Txt_Emp_Add.TabIndex = 4
        Me.Txt_Emp_Add.TabStop = False
        '
        'Btn_Find
        '
        Me.Btn_Find.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find.BackgroundImage = CType(resources.GetObject("Btn_Find.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find.ForeColor = System.Drawing.Color.White
        Me.Btn_Find.Location = New System.Drawing.Point(342, 20)
        Me.Btn_Find.Name = "Btn_Find"
        Me.Btn_Find.Size = New System.Drawing.Size(34, 21)
        Me.Btn_Find.TabIndex = 3
        Me.Btn_Find.TabStop = False
        Me.Btn_Find.Text = "F2"
        Me.Btn_Find.UseVisualStyleBackColor = False
        '
        'Txt_Emp_Name
        '
        Me.Txt_Emp_Name.BackColor = System.Drawing.Color.White
        Me.Txt_Emp_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Emp_Name.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Emp_Name.Location = New System.Drawing.Point(4, 20)
        Me.Txt_Emp_Name.Name = "Txt_Emp_Name"
        Me.Txt_Emp_Name.Size = New System.Drawing.Size(336, 21)
        Me.Txt_Emp_Name.TabIndex = 2
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.Color.Navy
        Me.Label5.Location = New System.Drawing.Point(3, 3)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(83, 13)
        Me.Label5.TabIndex = 205
        Me.Label5.Text = "E m p l o y e e"
        '
        'Pnl_Designations
        '
        Me.Pnl_Designations.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Designations.Controls.Add(Me.ChkLst_Designations)
        Me.Pnl_Designations.Controls.Add(Me.Label4)
        Me.Pnl_Designations.Enabled = False
        Me.Pnl_Designations.Location = New System.Drawing.Point(4, 91)
        Me.Pnl_Designations.Name = "Pnl_Designations"
        Me.Pnl_Designations.Size = New System.Drawing.Size(410, 69)
        Me.Pnl_Designations.TabIndex = 3
        Me.Pnl_Designations.TabStop = True
        '
        'ChkLst_Designations
        '
        Me.ChkLst_Designations.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ChkLst_Designations.CheckOnClick = True
        Me.ChkLst_Designations.FormattingEnabled = True
        Me.ChkLst_Designations.Location = New System.Drawing.Point(82, 2)
        Me.ChkLst_Designations.Name = "ChkLst_Designations"
        Me.ChkLst_Designations.Size = New System.Drawing.Size(326, 66)
        Me.ChkLst_Designations.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.Color.Navy
        Me.Label4.Location = New System.Drawing.Point(0, 3)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(74, 13)
        Me.Label4.TabIndex = 211
        Me.Label4.Text = "Designation"
        '
        'Btn_Loaddefault
        '
        Me.Btn_Loaddefault.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Loaddefault.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Loaddefault.ForeColor = System.Drawing.Color.White
        Me.Btn_Loaddefault.Location = New System.Drawing.Point(87, 545)
        Me.Btn_Loaddefault.Name = "Btn_Loaddefault"
        Me.Btn_Loaddefault.Size = New System.Drawing.Size(145, 28)
        Me.Btn_Loaddefault.TabIndex = 5
        Me.Btn_Loaddefault.Text = "&Load Default Values"
        Me.Btn_Loaddefault.UseVisualStyleBackColor = False
        Me.Btn_Loaddefault.Visible = False
        '
        'Dgv_Userrights
        '
        Me.Dgv_Userrights.AllowUserToAddRows = False
        Me.Dgv_Userrights.AllowUserToDeleteRows = False
        Me.Dgv_Userrights.AllowUserToResizeColumns = False
        Me.Dgv_Userrights.AllowUserToResizeRows = False
        Me.Dgv_Userrights.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(118, Byte), Integer), CType(CType(155, Byte), Integer), CType(CType(197, Byte), Integer))
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(87, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(162, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.AliceBlue
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgv_Userrights.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.Dgv_Userrights.ColumnHeadersHeight = 25
        Me.Dgv_Userrights.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.Dgv_Userrights.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Formname, Me.Viewright, Me.Addright, Me.Editright, Me.Deleteright, Me.FormID})
        Me.Dgv_Userrights.Location = New System.Drawing.Point(87, 165)
        Me.Dgv_Userrights.Name = "Dgv_Userrights"
        Me.Dgv_Userrights.RowHeadersVisible = False
        Me.Dgv_Userrights.Size = New System.Drawing.Size(710, 372)
        Me.Dgv_Userrights.TabIndex = 4
        '
        'Formname
        '
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(248, Byte), Integer))
        Me.Formname.DefaultCellStyle = DataGridViewCellStyle2
        Me.Formname.Frozen = True
        Me.Formname.HeaderText = "Menu Name"
        Me.Formname.Name = "Formname"
        Me.Formname.ReadOnly = True
        Me.Formname.Width = 347
        '
        'Viewright
        '
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(213, Byte), Integer))
        DataGridViewCellStyle3.NullValue = False
        Me.Viewright.DefaultCellStyle = DataGridViewCellStyle3
        Me.Viewright.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Viewright.HeaderText = "View Right"
        Me.Viewright.Name = "Viewright"
        Me.Viewright.Width = 90
        '
        'Addright
        '
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(CType(CType(194, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(224, Byte), Integer))
        DataGridViewCellStyle4.NullValue = False
        Me.Addright.DefaultCellStyle = DataGridViewCellStyle4
        Me.Addright.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Addright.HeaderText = "Add Right"
        Me.Addright.Name = "Addright"
        Me.Addright.Width = 90
        '
        'Editright
        '
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(213, Byte), Integer))
        DataGridViewCellStyle5.NullValue = False
        Me.Editright.DefaultCellStyle = DataGridViewCellStyle5
        Me.Editright.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Editright.HeaderText = "Edit Right"
        Me.Editright.Name = "Editright"
        Me.Editright.Width = 90
        '
        'Deleteright
        '
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(CType(CType(194, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(224, Byte), Integer))
        DataGridViewCellStyle6.NullValue = False
        Me.Deleteright.DefaultCellStyle = DataGridViewCellStyle6
        Me.Deleteright.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Deleteright.HeaderText = "Delete Right"
        Me.Deleteright.Name = "Deleteright"
        Me.Deleteright.Width = 90
        '
        'FormID
        '
        Me.FormID.HeaderText = "FormID"
        Me.FormID.Name = "FormID"
        Me.FormID.Visible = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(1, 165)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(85, 372)
        Me.PictureBox1.TabIndex = 207
        Me.PictureBox1.TabStop = False
        '
        'Userrights_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.LeftGradiant
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(802, 581)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Btn_Loaddefault)
        Me.Controls.Add(Me.Pnl_Designations)
        Me.Controls.Add(Me.Pnl_Empdetails)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Cmb_Allotmenttype)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Cmb_Menugroup)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.Dgv_Userrights)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Userrights_Frm"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.Pnl_Empdetails.ResumeLayout(False)
        Me.Pnl_Empdetails.PerformLayout()
        Me.Pnl_Designations.ResumeLayout(False)
        Me.Pnl_Designations.PerformLayout()
        CType(Me.Dgv_Userrights, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Dgv_Userrights As REAL_CLINIC.Hms_DGridview
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Cmb_Menugroup As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Allotmenttype As System.Windows.Forms.ComboBox
    Friend WithEvents Pnl_Empdetails As System.Windows.Forms.Panel
    Friend WithEvents Txt_Emp_Add As System.Windows.Forms.TextBox
    Friend WithEvents Btn_Find As System.Windows.Forms.Button
    Friend WithEvents Txt_Emp_Name As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Designations As System.Windows.Forms.Panel
    Friend WithEvents ChkLst_Designations As System.Windows.Forms.CheckedListBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Formname As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Viewright As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents Addright As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents Editright As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents Deleteright As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents FormID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Btn_Loaddefault As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
End Class
