﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class OutPatient_Master_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(OutPatient_Master_Frm))
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Delete = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.Btn_Find = New System.Windows.Forms.Button
        Me.Txt_OutPatientID = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Btn_Find1 = New System.Windows.Forms.Button
        Me.Txt_PatientID = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Btn_New = New System.Windows.Forms.Button
        Me.Cmb_Service = New System.Windows.Forms.ComboBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.Cmb_Dept = New System.Windows.Forms.ComboBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Cmb_ArrivalMode = New System.Windows.Forms.ComboBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.Txt_AmbulatoryStatus = New System.Windows.Forms.TextBox
        Me.Cmb_BillingMethod = New System.Windows.Forms.ComboBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.Cmb_PatientType = New System.Windows.Forms.ComboBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.Cmb_Status = New System.Windows.Forms.ComboBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.Cmb_CureStatus = New System.Windows.Forms.ComboBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.Txt_OpDays = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Dtp_TranDate = New System.Windows.Forms.DateTimePicker
        Me.Txt_AccID = New System.Windows.Forms.TextBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.Txt_AppID = New System.Windows.Forms.TextBox
        Me.Label18 = New System.Windows.Forms.Label
        Me.Lbl_OPValidDays = New System.Windows.Forms.Label
        Me.Txt_DrID = New System.Windows.Forms.TextBox
        Me.Btn_FindDr = New System.Windows.Forms.Button
        Me.Lbl_Drname = New System.Windows.Forms.Label
        Me.Btn_NewPatient = New System.Windows.Forms.Button
        Me.Btn_Find_AppID = New System.Windows.Forms.Button
        Me.Imageviewer1 = New TECHNO_CLINIC.Imageviewer
        Me.Trancontrol1 = New Tran_Controls.Trancontrol
        Me.Patient_Info1 = New TECHNO_CLINIC.Patient_Info
        Me.Pnl_Header.SuspendLayout()
        Me.Pnl_Tran_mode.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = CType(resources.GetObject("Pnl_Header.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Header.Controls.Add(Me.Label1)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(809, 24)
        Me.Pnl_Header.TabIndex = 100
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(8, 1)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(286, 18)
        Me.Label1.TabIndex = 121
        Me.Label1.Text = "O u t    P a t i e n t    R e g i s t r a t i o n"
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(562, 28)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(74, 22)
        Me.Pnl_Tran_mode.TabIndex = 48
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(3, 1)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(67, 16)
        Me.Lbl_Tran_Mode.TabIndex = 122
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Delete)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(542, 417)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(94, 141)
        Me.Pnl_Common_Btn.TabIndex = 200
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(6, 73)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(79, 31)
        Me.Btn_Clear.TabIndex = 21
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(6, 108)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(79, 31)
        Me.Btn_Close.TabIndex = 22
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Delete
        '
        Me.Btn_Delete.BackgroundImage = CType(resources.GetObject("Btn_Delete.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Delete.Location = New System.Drawing.Point(6, 38)
        Me.Btn_Delete.Name = "Btn_Delete"
        Me.Btn_Delete.Size = New System.Drawing.Size(79, 31)
        Me.Btn_Delete.TabIndex = 20
        Me.Btn_Delete.Text = "Ca&ncel"
        Me.Btn_Delete.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = CType(resources.GetObject("Btn_Save.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(6, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(79, 31)
        Me.Btn_Save.TabIndex = 19
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Btn_Find
        '
        Me.Btn_Find.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find.BackgroundImage = CType(resources.GetObject("Btn_Find.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find.ForeColor = System.Drawing.Color.White
        Me.Btn_Find.Location = New System.Drawing.Point(240, 32)
        Me.Btn_Find.Name = "Btn_Find"
        Me.Btn_Find.Size = New System.Drawing.Size(29, 21)
        Me.Btn_Find.TabIndex = 1
        Me.Btn_Find.TabStop = False
        Me.Btn_Find.Text = "F2"
        Me.Btn_Find.UseVisualStyleBackColor = False
        '
        'Txt_OutPatientID
        '
        Me.Txt_OutPatientID.BackColor = System.Drawing.Color.White
        Me.Txt_OutPatientID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_OutPatientID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_OutPatientID.Location = New System.Drawing.Point(84, 32)
        Me.Txt_OutPatientID.MaxLength = 10
        Me.Txt_OutPatientID.Name = "Txt_OutPatientID"
        Me.Txt_OutPatientID.Size = New System.Drawing.Size(154, 21)
        Me.Txt_OutPatientID.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(8, 36)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 13)
        Me.Label2.TabIndex = 50
        Me.Label2.Text = "OP ID"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(7, 285)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(44, 13)
        Me.Label11.TabIndex = 68
        Me.Label11.Text = "Status"
        '
        'Btn_Find1
        '
        Me.Btn_Find1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find1.BackgroundImage = CType(resources.GetObject("Btn_Find1.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find1.ForeColor = System.Drawing.Color.White
        Me.Btn_Find1.Location = New System.Drawing.Point(270, 55)
        Me.Btn_Find1.Name = "Btn_Find1"
        Me.Btn_Find1.Size = New System.Drawing.Size(29, 21)
        Me.Btn_Find1.TabIndex = 5
        Me.Btn_Find1.TabStop = False
        Me.Btn_Find1.Text = "F2"
        Me.Btn_Find1.UseVisualStyleBackColor = False
        '
        'Txt_PatientID
        '
        Me.Txt_PatientID.BackColor = System.Drawing.Color.White
        Me.Txt_PatientID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_PatientID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PatientID.Location = New System.Drawing.Point(84, 55)
        Me.Txt_PatientID.MaxLength = 10
        Me.Txt_PatientID.Name = "Txt_PatientID"
        Me.Txt_PatientID.Size = New System.Drawing.Size(184, 21)
        Me.Txt_PatientID.TabIndex = 4
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(8, 57)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(64, 13)
        Me.Label5.TabIndex = 91
        Me.Label5.Text = "Patient ID"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(7, 272)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(74, 13)
        Me.Label6.TabIndex = 93
        Me.Label6.Text = "Ambulatory"
        '
        'Btn_New
        '
        Me.Btn_New.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_New.BackgroundImage = CType(resources.GetObject("Btn_New.BackgroundImage"), System.Drawing.Image)
        Me.Btn_New.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_New.ForeColor = System.Drawing.Color.White
        Me.Btn_New.Location = New System.Drawing.Point(640, 240)
        Me.Btn_New.Name = "Btn_New"
        Me.Btn_New.Size = New System.Drawing.Size(39, 20)
        Me.Btn_New.TabIndex = 8
        Me.Btn_New.TabStop = False
        Me.Btn_New.Text = "NEW"
        Me.Btn_New.UseVisualStyleBackColor = False
        '
        'Cmb_Service
        '
        Me.Cmb_Service.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Service.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Service.FormattingEnabled = True
        Me.Cmb_Service.ItemHeight = 13
        Me.Cmb_Service.Location = New System.Drawing.Point(84, 240)
        Me.Cmb_Service.Name = "Cmb_Service"
        Me.Cmb_Service.Size = New System.Drawing.Size(248, 21)
        Me.Cmb_Service.TabIndex = 9
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.ForeColor = System.Drawing.Color.Black
        Me.Label19.Location = New System.Drawing.Point(7, 244)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(49, 13)
        Me.Label19.TabIndex = 102
        Me.Label19.Text = "Service"
        '
        'Cmb_Dept
        '
        Me.Cmb_Dept.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Dept.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Dept.FormattingEnabled = True
        Me.Cmb_Dept.ItemHeight = 13
        Me.Cmb_Dept.Location = New System.Drawing.Point(434, 240)
        Me.Cmb_Dept.Name = "Cmb_Dept"
        Me.Cmb_Dept.Size = New System.Drawing.Size(204, 21)
        Me.Cmb_Dept.TabIndex = 10
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(354, 244)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(76, 13)
        Me.Label7.TabIndex = 104
        Me.Label7.Text = "Department"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(7, 219)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(61, 13)
        Me.Label8.TabIndex = 106
        Me.Label8.Text = "Doctor ID"
        '
        'Cmb_ArrivalMode
        '
        Me.Cmb_ArrivalMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_ArrivalMode.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_ArrivalMode.FormattingEnabled = True
        Me.Cmb_ArrivalMode.ItemHeight = 13
        Me.Cmb_ArrivalMode.Location = New System.Drawing.Point(434, 265)
        Me.Cmb_ArrivalMode.Name = "Cmb_ArrivalMode"
        Me.Cmb_ArrivalMode.Size = New System.Drawing.Size(204, 21)
        Me.Cmb_ArrivalMode.TabIndex = 12
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(350, 269)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(79, 13)
        Me.Label9.TabIndex = 108
        Me.Label9.Text = "Arrival Mode"
        '
        'Txt_AmbulatoryStatus
        '
        Me.Txt_AmbulatoryStatus.BackColor = System.Drawing.Color.White
        Me.Txt_AmbulatoryStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_AmbulatoryStatus.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_AmbulatoryStatus.Location = New System.Drawing.Point(84, 265)
        Me.Txt_AmbulatoryStatus.MaxLength = 150
        Me.Txt_AmbulatoryStatus.Multiline = True
        Me.Txt_AmbulatoryStatus.Name = "Txt_AmbulatoryStatus"
        Me.Txt_AmbulatoryStatus.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Txt_AmbulatoryStatus.Size = New System.Drawing.Size(247, 121)
        Me.Txt_AmbulatoryStatus.TabIndex = 11
        '
        'Cmb_BillingMethod
        '
        Me.Cmb_BillingMethod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_BillingMethod.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_BillingMethod.FormattingEnabled = True
        Me.Cmb_BillingMethod.ItemHeight = 13
        Me.Cmb_BillingMethod.Location = New System.Drawing.Point(434, 290)
        Me.Cmb_BillingMethod.Name = "Cmb_BillingMethod"
        Me.Cmb_BillingMethod.Size = New System.Drawing.Size(204, 21)
        Me.Cmb_BillingMethod.TabIndex = 13
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(343, 293)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(86, 13)
        Me.Label10.TabIndex = 111
        Me.Label10.Text = "Billing Method"
        '
        'Cmb_PatientType
        '
        Me.Cmb_PatientType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_PatientType.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_PatientType.FormattingEnabled = True
        Me.Cmb_PatientType.ItemHeight = 13
        Me.Cmb_PatientType.Location = New System.Drawing.Point(434, 315)
        Me.Cmb_PatientType.Name = "Cmb_PatientType"
        Me.Cmb_PatientType.Size = New System.Drawing.Size(204, 21)
        Me.Cmb_PatientType.TabIndex = 14
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.ForeColor = System.Drawing.Color.Black
        Me.Label12.Location = New System.Drawing.Point(350, 317)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(79, 13)
        Me.Label12.TabIndex = 113
        Me.Label12.Text = "Patient Type"
        '
        'Cmb_Status
        '
        Me.Cmb_Status.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Status.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Status.FormattingEnabled = True
        Me.Cmb_Status.ItemHeight = 13
        Me.Cmb_Status.Location = New System.Drawing.Point(434, 365)
        Me.Cmb_Status.Name = "Cmb_Status"
        Me.Cmb_Status.Size = New System.Drawing.Size(204, 21)
        Me.Cmb_Status.TabIndex = 16
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.ForeColor = System.Drawing.Color.Black
        Me.Label13.Location = New System.Drawing.Point(338, 365)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(90, 13)
        Me.Label13.TabIndex = 115
        Me.Label13.Text = "Current Status"
        '
        'Cmb_CureStatus
        '
        Me.Cmb_CureStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_CureStatus.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_CureStatus.FormattingEnabled = True
        Me.Cmb_CureStatus.ItemHeight = 13
        Me.Cmb_CureStatus.Location = New System.Drawing.Point(434, 340)
        Me.Cmb_CureStatus.Name = "Cmb_CureStatus"
        Me.Cmb_CureStatus.Size = New System.Drawing.Size(204, 21)
        Me.Cmb_CureStatus.TabIndex = 15
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.ForeColor = System.Drawing.Color.Black
        Me.Label14.Location = New System.Drawing.Point(356, 343)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(73, 13)
        Me.Label14.TabIndex = 117
        Me.Label14.Text = "Cure Status"
        '
        'Txt_OpDays
        '
        Me.Txt_OpDays.BackColor = System.Drawing.Color.White
        Me.Txt_OpDays.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_OpDays.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_OpDays.Location = New System.Drawing.Point(434, 389)
        Me.Txt_OpDays.MaxLength = 4
        Me.Txt_OpDays.Name = "Txt_OpDays"
        Me.Txt_OpDays.Size = New System.Drawing.Size(94, 21)
        Me.Txt_OpDays.TabIndex = 17
        Me.Txt_OpDays.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.ForeColor = System.Drawing.Color.Black
        Me.Label15.Location = New System.Drawing.Point(346, 392)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(83, 13)
        Me.Label15.TabIndex = 119
        Me.Label15.Text = "OP Valid Days"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label16.Location = New System.Drawing.Point(383, 57)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(34, 13)
        Me.Label16.TabIndex = 121
        Me.Label16.Text = "Date"
        '
        'Dtp_TranDate
        '
        Me.Dtp_TranDate.CustomFormat = "dd/MM/yyyy"
        Me.Dtp_TranDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_TranDate.Location = New System.Drawing.Point(432, 53)
        Me.Dtp_TranDate.Name = "Dtp_TranDate"
        Me.Dtp_TranDate.Size = New System.Drawing.Size(98, 21)
        Me.Dtp_TranDate.TabIndex = 6
        '
        'Txt_AccID
        '
        Me.Txt_AccID.BackColor = System.Drawing.Color.White
        Me.Txt_AccID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_AccID.Enabled = False
        Me.Txt_AccID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_AccID.Location = New System.Drawing.Point(84, 390)
        Me.Txt_AccID.Name = "Txt_AccID"
        Me.Txt_AccID.ReadOnly = True
        Me.Txt_AccID.Size = New System.Drawing.Size(247, 21)
        Me.Txt_AccID.TabIndex = 200
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.ForeColor = System.Drawing.Color.Black
        Me.Label17.Location = New System.Drawing.Point(8, 394)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(69, 13)
        Me.Label17.TabIndex = 123
        Me.Label17.Text = "Account ID"
        '
        'Txt_AppID
        '
        Me.Txt_AppID.BackColor = System.Drawing.Color.White
        Me.Txt_AppID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_AppID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_AppID.Location = New System.Drawing.Point(432, 29)
        Me.Txt_AppID.Name = "Txt_AppID"
        Me.Txt_AppID.Size = New System.Drawing.Size(96, 21)
        Me.Txt_AppID.TabIndex = 2
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.Transparent
        Me.Label18.ForeColor = System.Drawing.Color.Black
        Me.Label18.Location = New System.Drawing.Point(320, 33)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(97, 13)
        Me.Label18.TabIndex = 202
        Me.Label18.Text = "Appiontment ID"
        '
        'Lbl_OPValidDays
        '
        Me.Lbl_OPValidDays.BackColor = System.Drawing.Color.Blue
        Me.Lbl_OPValidDays.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Lbl_OPValidDays.Location = New System.Drawing.Point(533, 389)
        Me.Lbl_OPValidDays.Name = "Lbl_OPValidDays"
        Me.Lbl_OPValidDays.Size = New System.Drawing.Size(105, 21)
        Me.Lbl_OPValidDays.TabIndex = 205
        '
        'Txt_DrID
        '
        Me.Txt_DrID.BackColor = System.Drawing.Color.White
        Me.Txt_DrID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_DrID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_DrID.Location = New System.Drawing.Point(84, 215)
        Me.Txt_DrID.MaxLength = 5
        Me.Txt_DrID.Name = "Txt_DrID"
        Me.Txt_DrID.Size = New System.Drawing.Size(155, 21)
        Me.Txt_DrID.TabIndex = 7
        '
        'Btn_FindDr
        '
        Me.Btn_FindDr.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_FindDr.BackgroundImage = CType(resources.GetObject("Btn_FindDr.BackgroundImage"), System.Drawing.Image)
        Me.Btn_FindDr.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_FindDr.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_FindDr.ForeColor = System.Drawing.Color.White
        Me.Btn_FindDr.Location = New System.Drawing.Point(240, 215)
        Me.Btn_FindDr.Name = "Btn_FindDr"
        Me.Btn_FindDr.Size = New System.Drawing.Size(29, 21)
        Me.Btn_FindDr.TabIndex = 8
        Me.Btn_FindDr.Text = "F2"
        Me.Btn_FindDr.UseVisualStyleBackColor = False
        '
        'Lbl_Drname
        '
        Me.Lbl_Drname.BackColor = System.Drawing.Color.Blue
        Me.Lbl_Drname.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Lbl_Drname.Location = New System.Drawing.Point(272, 215)
        Me.Lbl_Drname.Name = "Lbl_Drname"
        Me.Lbl_Drname.Size = New System.Drawing.Size(364, 21)
        Me.Lbl_Drname.TabIndex = 208
        '
        'Btn_NewPatient
        '
        Me.Btn_NewPatient.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_NewPatient.BackgroundImage = CType(resources.GetObject("Btn_NewPatient.BackgroundImage"), System.Drawing.Image)
        Me.Btn_NewPatient.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_NewPatient.ForeColor = System.Drawing.Color.White
        Me.Btn_NewPatient.Location = New System.Drawing.Point(301, 55)
        Me.Btn_NewPatient.Name = "Btn_NewPatient"
        Me.Btn_NewPatient.Size = New System.Drawing.Size(39, 21)
        Me.Btn_NewPatient.TabIndex = 209
        Me.Btn_NewPatient.TabStop = False
        Me.Btn_NewPatient.Text = "NEW"
        Me.Btn_NewPatient.UseVisualStyleBackColor = False
        '
        'Btn_Find_AppID
        '
        Me.Btn_Find_AppID.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find_AppID.BackgroundImage = CType(resources.GetObject("Btn_Find_AppID.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find_AppID.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find_AppID.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find_AppID.ForeColor = System.Drawing.Color.White
        Me.Btn_Find_AppID.Location = New System.Drawing.Point(530, 29)
        Me.Btn_Find_AppID.Name = "Btn_Find_AppID"
        Me.Btn_Find_AppID.Size = New System.Drawing.Size(29, 21)
        Me.Btn_Find_AppID.TabIndex = 3
        Me.Btn_Find_AppID.TabStop = False
        Me.Btn_Find_AppID.Text = "F2"
        Me.Btn_Find_AppID.UseVisualStyleBackColor = False
        Me.Btn_Find_AppID.Visible = False
        '
        'Imageviewer1
        '
        Me.Imageviewer1.CUST_ID = ""
        Me.Imageviewer1.CUST_TYPE = HMS_Common.Common_Cls.Customer_Type.Employee
        Me.Imageviewer1.Location = New System.Drawing.Point(643, 28)
        Me.Imageviewer1.Name = "Imageviewer1"
        Me.Imageviewer1.Scan_Enabled = True
        Me.Imageviewer1.Size = New System.Drawing.Size(161, 184)
        Me.Imageviewer1.TabIndex = 204
        '
        'Trancontrol1
        '
        Me.Trancontrol1.BackColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(123, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Trancontrol1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Trancontrol1.Location = New System.Drawing.Point(85, 415)
        Me.Trancontrol1.Name = "Trancontrol1"
        Me.Trancontrol1.Padding = New System.Windows.Forms.Padding(3)
        Me.Trancontrol1.Size = New System.Drawing.Size(452, 143)
        Me.Trancontrol1.TabIndex = 18
        '
        'Patient_Info1
        '
        Me.Patient_Info1.BackColor = System.Drawing.Color.AliceBlue
        Me.Patient_Info1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Patient_Info1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Patient_Info1.ForeColor = System.Drawing.Color.DarkBlue
        Me.Patient_Info1.Location = New System.Drawing.Point(84, 78)
        Me.Patient_Info1.Name = "Patient_Info1"
        Me.Patient_Info1.Padding = New System.Windows.Forms.Padding(2)
        Me.Patient_Info1.Size = New System.Drawing.Size(552, 134)
        Me.Patient_Info1.TabIndex = 203
        '
        'OutPatient_Master_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(809, 561)
        Me.Controls.Add(Me.Btn_Find_AppID)
        Me.Controls.Add(Me.Btn_NewPatient)
        Me.Controls.Add(Me.Lbl_Drname)
        Me.Controls.Add(Me.Btn_FindDr)
        Me.Controls.Add(Me.Txt_DrID)
        Me.Controls.Add(Me.Lbl_OPValidDays)
        Me.Controls.Add(Me.Imageviewer1)
        Me.Controls.Add(Me.Trancontrol1)
        Me.Controls.Add(Me.Patient_Info1)
        Me.Controls.Add(Me.Txt_AppID)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Txt_AccID)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Dtp_TranDate)
        Me.Controls.Add(Me.Txt_OpDays)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Cmb_CureStatus)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Cmb_Status)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Cmb_PatientType)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Cmb_BillingMethod)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Txt_AmbulatoryStatus)
        Me.Controls.Add(Me.Cmb_ArrivalMode)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Cmb_Dept)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Btn_New)
        Me.Controls.Add(Me.Cmb_Service)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Txt_PatientID)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Btn_Find1)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Txt_OutPatientID)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Pnl_Tran_mode)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.Btn_Find)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "OutPatient_Master_Frm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Pnl_Tran_mode.ResumeLayout(False)
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Delete As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Btn_Find As System.Windows.Forms.Button
    Friend WithEvents Txt_OutPatientID As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Btn_Find1 As System.Windows.Forms.Button
    Friend WithEvents Txt_PatientID As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Btn_New As System.Windows.Forms.Button
    Friend WithEvents Cmb_Service As System.Windows.Forms.ComboBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Dept As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Cmb_ArrivalMode As System.Windows.Forms.ComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Txt_AmbulatoryStatus As System.Windows.Forms.TextBox
    Friend WithEvents Cmb_BillingMethod As System.Windows.Forms.ComboBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Cmb_PatientType As System.Windows.Forms.ComboBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Status As System.Windows.Forms.ComboBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Cmb_CureStatus As System.Windows.Forms.ComboBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Txt_OpDays As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Dtp_TranDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Txt_AccID As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Txt_AppID As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Patient_Info1 As TECHNO_CLINIC.Patient_Info
    Friend WithEvents Trancontrol1 As Tran_Controls.Trancontrol
    Friend WithEvents Imageviewer1 As TECHNO_CLINIC.Imageviewer
    Friend WithEvents Lbl_OPValidDays As System.Windows.Forms.Label
    Friend WithEvents Txt_DrID As System.Windows.Forms.TextBox
    Friend WithEvents Btn_FindDr As System.Windows.Forms.Button
    Friend WithEvents Lbl_Drname As System.Windows.Forms.Label
    Friend WithEvents Btn_NewPatient As System.Windows.Forms.Button
    Friend WithEvents Btn_Find_AppID As System.Windows.Forms.Button
End Class
