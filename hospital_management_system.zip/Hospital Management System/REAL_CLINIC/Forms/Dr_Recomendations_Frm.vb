﻿

Option Explicit On
Imports System.IO
Imports HMS_BL
Imports HMS_Common.Common_Cls
Public Class Dr_Recomendations_Frm

    Private mTr_Mode As Tran_Mode
    Private hms_helper As HMS_Helper = Nothing
    Private Patient_CaseRec_BL As Patient_CaseRecord_BL_Cls

    Private mRpt_Vwr As ReportViewer_Cls
    Private Rpt_BL As HMS_BL.Reports_BL_Cls

    Private ValueExist As Boolean

    'Transaction Mode checking Property
    Public Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_BatchID.BackColor = Color.White
                    Txt_PMRID.BackColor = Color.White
                    Me.Txt_PMRID.ReadOnly = False
                    Me.Txt_PatientID.ReadOnly = False
                    Me.Txt_BatchID.ReadOnly = False
                    Me.Btn_Save.Enabled = True
                    Btn_Add.Enabled = True

                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_BatchID.BackColor = Color.Silver
                    Txt_PMRID.BackColor = Color.Silver
                    Me.Txt_PMRID.ReadOnly = True
                    Me.Txt_PatientID.ReadOnly = True
                    Me.Txt_BatchID.ReadOnly = True
                    Me.Btn_Save.Enabled = False
                    Btn_Add.Enabled = False


            End Select
        End Set
    End Property
    Dim tvRoot As TreeNode
    Dim tvNode As TreeNode
    Dim tvNode1 As TreeNode


    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing

    Private Sub Patient_CaseRecords_Frm_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
        Try
            If Tr_Mode = Tran_Mode.Edit_Mode Then
                Btn_Cancel.Enabled = True
                Btn_Cancel.Focus()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Patient_CaseRecords_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then SendKeyTab()
        If e.KeyCode = Keys.Escape Then Btn_Save.Focus()
    End Sub

    Private Sub Reports_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub Reports_Frm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try

            If Not Tr_Mode = Tran_Mode.Edit_Mode Then

                Txt_BatchID.Focus()
            End If

            hms_helper = New Hms_Helperimpliments
            Btn_Cancel.Enabled = False
        Catch ex As Exception

        End Try
    End Sub

#Region "Methods"
    Private Sub Clear_Form()
        Try
            Clear_Values()
            Tr_Mode = Tran_Mode.New_Mode
            Btn_Cancel.Enabled = False
            Txt_BatchID.Tag = ""
            Txt_BatchID.Text = ""


        Catch ex As Exception

        End Try
    End Sub

    Private Sub Clear_Values()
        Try

            Txt_PatientID.Text = ""
            Txt_PMRID.Text = ""
            Txt_OPID.Text = ""
            Txt_DocID.Text = ""
            Txt_PMRID.Tag = ""
            Txt_DocID.Tag = ""

            Txt_Heading.Text = ""
            Txt_Heading.Tag = ""
            Txt_Details.Text = ""
            Txt_Footer.Text = ""

            Patient_Info2.Patient_ID = -1
            Dgv_CaseRecord.RowCount = 0
            Imageviewer1.CUST_ID = ""
            Dgv_CaseRecord.DataSource = Nothing

        Catch ex As Exception

        End Try

    End Sub



    Private Function Locate_PMR_info(ByVal PMR_ID As String, ByVal Br_Code As Integer) As Boolean
        Try

            '-----------------   Clear Form   -----------------------------------

            Call Clear_Values()

            '----------------------------------------------------------------------------

            Dim Dtbl As DataTable = Nothing

            '-----------------  Locate Pateint Medical Record Master info   -------------
            If Not hms_helper.Get_PMR_Masterinfo(Dtbl, PMR_ID, Br_Code) Then Return False

            Txt_PMRID.Text = PMR_ID
            Txt_PMRID.Tag = PMR_ID

            With Dtbl
                Txt_PatientID.Text = .Rows(0).Item("Patient ID").ToString
                Txt_OPID.Text = .Rows(0).Item("OP ID").ToString
                Txt_DocID.Text = .Rows(0).Item("Doc_ID").ToString
                Txt_DocID.Tag = Txt_DocID.Text
                Txt_DocDetails.Text = .Rows(0).Item("DoctorDetails").ToString
            End With

            With Patient_Info2
                .MDIform_Name = Me.MdiParent
                .Patient_ID = Txt_PatientID.Text.Trim
                .Patient_ID = Txt_PatientID.Text.Trim
            End With

            With Imageviewer1
                .CUST_ID = Txt_PatientID.Text.Trim
                .CUST_TYPE = Customer_Type.Patient
            End With

           

            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function


    Private Function Save_Patient_Tran(ByRef Tran_BatchID As String) As Boolean
        Try

            hms_helper = New Hms_Helperimpliments
            Dim dtbl As DataTable = Nothing
            Dim item_Trmode As Tran_Mode = Me.Tr_Mode

            Patient_CaseRec_BL = New Patient_CaseRecord_BL_Cls

            Patient_CaseRec_BL.CaseRec_BatchID = Tran_BatchID
            Patient_CaseRec_BL.Reg_Date = Tran_Date
            Patient_CaseRec_BL.Patient_ID = Txt_PatientID.Text.Trim
            Patient_CaseRec_BL.OPD_ID = Txt_OPID.Text.Trim
            Patient_CaseRec_BL.ACC_ID = Txt_PMRID.Text.Trim

            Patient_CaseRec_BL.Recoment_Doc_ID = Txt_DocID.Text.Trim


            With Dgv_CaseRecord

                For i = 0 To .Rows.Count - 1

                    item_Trmode = IIf(.Rows(i).Cells("Rec_ID").Value.ToString = "", Tran_Mode.New_Mode, Tran_Mode.Edit_Mode)


                    Patient_CaseRec_BL.Cr_Header = .Rows(i).Cells(1).Value.ToString.Trim
                    Patient_CaseRec_BL.Cr_Body = .Rows(i).Cells(2).Value.ToString.Trim
                    Patient_CaseRec_BL.Cr_Footer = .Rows(i).Cells(3).Value.ToString.Trim

                    If Not Patient_CaseRec_BL.Save_Patient_CaseRecords(dtbl, item_Trmode, Val(.Rows(i).Cells("Rec_ID").Value.ToString)) Then
                        Return False
                    End If

                Next

            End With
            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function Locate_Values(ByVal Tran_BatchID As String) As Boolean
        Try

            Patient_CaseRec_BL = New Patient_CaseRecord_BL_Cls

            Dim dtbl As DataTable = Nothing
            Dgv_CaseRecord.RowCount = 0

            If Patient_CaseRec_BL.Get_Patient_CaseRecord(dtbl, Tran_BatchID, Branch_Code) Then

                Txt_BatchID.Text = dtbl.Rows(0).Item("CaseRec_BatchID").ToString.Trim
                Txt_PMRID.Text = dtbl.Rows(0).Item("ACC_ID").ToString.Trim

                Call Btn_Find_Click(Nothing, Nothing)

                Dgv_CaseRecord.RowCount = 0
                For i = 0 To dtbl.Rows.Count - 1
                    With Dgv_CaseRecord
                        .Rows.Add()
                        .Rows(i).Cells(0).Value = i + 1
                        .Rows(i).Cells(1).Value = dtbl.Rows(i).Item("Cr_Header").ToString.Trim
                        .Rows(i).Cells(2).Value = dtbl.Rows(i).Item("Cr_Body").ToString.Trim
                        .Rows(i).Cells(3).Value = dtbl.Rows(i).Item("Cr_Footer").ToString.Trim
                        .Rows(i).Cells(5).Value = dtbl.Rows(i).Item("CaseRec_ID").ToString.Trim
                    End With
                Next

                dtbl = Nothing

                '--------------------------------------------------------
                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Cancel.Enabled = True
                '--------------------------------------------------------

            Else
                Return False
            End If

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Validate_Fields() As Boolean
        Try

            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If

            If Tr_Mode <> Tran_Mode.New_Mode Then
                If Txt_BatchID.Text.Trim = "" Then MessageBox.Show("Invalid Batch ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_BatchID.Focus() : Return False
            End If
            'validating all mandatory fields

            If Txt_PMRID.Text.Trim = "" Then MessageBox.Show("Invalid PMR-ID, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_PMRID.Focus() : Return False

            If Txt_DocID.Text.Trim = "" Then MessageBox.Show("Invalid Doctor ID, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_DocID.Focus() : Return False

            If Dgv_CaseRecord.Rows.Count = 0 Then MessageBox.Show("No Case Record Added, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Heading.Focus() : Return False

            Return True

        Catch ex As Exception
            Return False
        End Try

    End Function

    Public Function Show_Reciept(ByVal PatientID As String) As Boolean
        Try
            If PatientID = "" Then MessageBox.Show("Invalid  Patient ID .. Please enter valid Outpatient Id", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Exit Function
            Dim Rpt_Ds As DataSet = Nothing
            Dim Rpt_Formulafields As String = "Company| " & Company_Name & "|Branch|" & Branch_Name
            Dim Rpt_Filename As String = ""
            Dim mReport_ID As String = ""
            Dim Report_Heading As String = ""
            Dim Add_Query As String = ""

            mRpt_Vwr = New ReportViewer_Cls

            Add_Query = ""
            Add_Query = "Where [Patient_ID] = " & PatientID & " and Br_Code=" & Branch_Code & ""
            Rpt_Filename = File_Path & "\Patient_Case_Record.rpt"
            Patient_CaseRec_BL = New Patient_CaseRecord_BL_Cls
            If Patient_CaseRec_BL.Get_Patient_CaseRecordAll(Rpt_Ds, Add_Query) Then
                Report_Heading = "|Heading| Patient Case Records|Footer3|Authorised Signatory"
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading & ")"
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "")
            Else
                MessageBox.Show("Invalid Patient ID .. Please enter valid Patient ID", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function

    Private Function Validate_Grid(ByVal StrHeading As String, ByVal StrDetails As String) As Boolean
        Try

            If Txt_Heading.Text.Trim = "" And Txt_Details.Text.Trim = "" And Txt_Footer.Text.Trim = "" Then
                MessageBox.Show("Invalid Comments, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Txt_Heading.Focus()
                Return False
            End If

            If Txt_Heading.Tag = "" Then
                With Dgv_CaseRecord
                    For i = 0 To .Rows.Count - 1
                        If .Rows(i).Cells("Heading").Value.ToString.Trim = StrHeading.Trim Then
                            MessageBox.Show("Heading already entered, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                            Return False
                        End If

                        If .Rows(i).Cells("Details").Value.ToString.Trim = StrDetails.Trim Then
                            MessageBox.Show("Details already entered, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                            Return False
                        End If
                    Next
                End With
            End If

            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Delete_GridRow(ByVal rowindex As Integer)
        Try
            Dgv_CaseRecord.Rows.RemoveAt(rowindex)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Reorder_GridValues()
        Try
            With Dgv_CaseRecord
                For i = 0 To .Rows.Count - 1
                    .Rows(i).Cells("slno").Value = i + 1
                Next

            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Function Populate_ParticularsGrid(ByVal dtbl As DataTable) As Boolean
        Try

            With Dgw_HeadingHistory
                .DataSource = dtbl
                .Columns(1).Visible = False
                .Columns(0).Width = 370
                .Refresh()
                .Visible = True
            End With
            dtbl = Nothing
        Catch ex As Exception

        End Try
    End Function

    Private Function Locate_Gridvalues(ByVal Row_no As Long) As Boolean
        Try
            Txt_Heading.Text = ""
            Txt_Heading.Tag = ""
            Txt_Details.Text = ""
            Txt_Footer.Text = ""

            With Dgv_CaseRecord
                Txt_Heading.Text = .Rows(Row_no).Cells("Heading").Value.ToString
                Txt_Heading.Tag = Row_no
                Txt_Details.Text = .Rows(Row_no).Cells("Details").Value.ToString
                Txt_Footer.Text = .Rows(Row_no).Cells("Footer").Value.ToString

            End With

            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

#End Region


    Public Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try
            If Txt_PMRID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "200|50|300|70|"
                Sql = "SELECT [Patient Name], [S.S.No], ([Family Name] + Address + City) as Address, ACC_ID AS [PMR-ID]"
                Sql += "FROM Patient_Account_Vw WHERE ([Account Status] = 'Active')"

                Call ShowSearchengine(Txt_PMRID, Sql, 3, "[Patient Name]", Colwidth, , 0)
            End If

            'Validating Mandatory fields for locating
            If Txt_PMRID.Text.Trim = "" Then
                'MessageBox.Show("Invalid Appointment ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_PMRID.Focus() : Exit Sub
            End If

            If Locate_PMR_info(Txt_PMRID.Text.Trim, Branch_Code) Then
                Txt_Heading.Focus()
            Else
                MessageBox.Show("Invalid PMR-ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Btn_Add_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Add.Click
        Try

            If Not Validate_Grid(Txt_Heading.Text.Trim, Txt_Details.Text.Trim) Then Exit Sub

            With Dgv_CaseRecord
                If Txt_Heading.Tag = "" Then

                    .Rows.Add()
                    .Rows(.Rows.Count - 1).Cells("Slno").Value = .Rows.Count

                    .Rows(.Rows.Count - 1).Cells("Heading").Value = Txt_Heading.Text.Trim

                    .Rows(.Rows.Count - 1).Cells("Details").Value = Txt_Details.Text.Trim

                    .Rows(.Rows.Count - 1).Cells("Footer").Value = Txt_Footer.Text.Trim

                    .Rows(.Rows.Count - 1).Cells("Rec_ID").Value = ""
                Else
                    .Rows(Val(Txt_Heading.Tag)).Cells("Heading").Value = Txt_Heading.Text.Trim

                    .Rows(Val(Txt_Heading.Tag)).Cells("Details").Value = Txt_Details.Text.Trim

                    .Rows(Val(Txt_Heading.Tag)).Cells("Footer").Value = Txt_Footer.Text.Trim

                End If

            End With
            Txt_Heading.Text = ""
            Txt_Heading.Tag = ""
            Txt_Details.Text = ""
            Txt_Footer.Text = ""
            Txt_Heading.Focus()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Try
            Me.Close()
        Catch ex As Exception
        End Try

    End Sub

    Private Sub Txt_PMRID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_PMRID.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then Btn_Find_Click(sender, e)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_PMRID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_PMRID.TextChanged
        Try
            If Txt_PMRID.Text.Trim = "" Then Call Clear_Values()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try
            Patient_CaseRec_BL = New Patient_CaseRecord_BL_Cls
            Dim dtbl As DataTable = Nothing
            If Not Validate_Fields() Then Exit Sub

            Dim Tran_BatchID As String = ""
            If Tr_Mode = Tran_Mode.New_Mode Then
                If Patient_CaseRec_BL.Get_PatientRecord_MaxBatchNO(dtbl, Branch_Code) Then
                    Txt_BatchID.Text = dtbl.Rows(0).Item(0).ToString.Trim
                End If
            End If

            If Save_Patient_Tran(Txt_BatchID.Text.Trim) Then
                MessageBox.Show("Patient Transaction  Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Call Clear_Form()
                Txt_PMRID.Focus()
            Else
                If Tran_BatchID <> "" Then
                    '  Patient_CaseRec_BL.Del_Patient_Transaction(Tran_BatchID, Tran_Date, Txt_PatientID.Text.Trim, Branch_Code)
                End If
                MessageBox.Show("Patient Transaction  Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try
            Call Clear_Form()
            Txt_PMRID.Focus()

        Catch ex As Exception

        End Try
    End Sub

    Public Sub Btn_FindBatch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_FindBatch.Click
        Try
            If Tr_Mode = Tran_Mode.New_Mode Then
                If Txt_BatchID.Text.Trim = "" Then
                    Call Clear_Form()
                    Dim Sql As String
                    Dim Colwidth As String = ""
                    Colwidth = "10|50|50|50|50"
                    'Sql = "SELECT *  FROM         Get_Latest_PatientCase_Rec_Vw  where Tr_Date ='" & Format(Tran_Date, "MM/dd/yyyy") & "' and Br_Code = " & Branch_Code & " "
                    Sql = "SELECT *  FROM         Get_Latest_PatientCase_Rec_Vw where Br_Code =" & Branch_Code & ""
                    Call ShowSearchengine(Txt_BatchID, Sql, 0, "Name", Colwidth, , 0)
                End If
            End If

            If Txt_BatchID.Text.Trim = "" Then
                Txt_BatchID.Focus() : Exit Sub
            End If

            If Locate_Values(Txt_BatchID.Text.Trim) Then
                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Cancel.Enabled = True
                Btn_Add.Enabled = False
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Cancel.Click
        Try
            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If

            If MessageBox.Show("Are you sure wan't to Delete the entry", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                ''If Patient_CaseRec_BL.Del_Patient_Transaction(Txt_BatchID.Text.Trim, Tran_Date, Txt_PatientID.Text.Trim, Branch_Code) Then
                ''    MessageBox.Show("Patient Transaction  Cancelled", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                ''End If
                Call Clear_Form()
            Else
                Btn_Clear.Focus()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_BatchID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_BatchID.KeyDown
        If e.KeyCode = Keys.F2 Then Btn_FindBatch_Click(sender, e)
    End Sub

    'Private Sub Btn_FindPatientID_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    Try

    '        If Txt_PatientID.Text.Trim = "" Then
    '            Dim Sql As String
    '            Dim Colwidth As String = ""
    '            Colwidth = "10|200|50|"
    '            Sql = "SELECT     [Patient ID], [Patient Name], Doctor, Service, Department ,OPD_ID FROM   OPD_Master_Vw"
    '            Call ShowSearchengine(Txt_PMRID, Sql, 5, "Name", Colwidth, , 0)

    '            If Txt_PMRID.Text.Trim = "" Then
    '                Txt_PatientID.Focus() : Exit Sub
    '            End If

    '            If Locate_Outpatient(Txt_PMRID.Text.Trim) Then

    '            Else
    '                MessageBox.Show("Invalid Patient, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
    '                Txt_PatientID.Focus()
    '            End If
    '        Else

    '            Dim dtbl As DataTable = Nothing

    '            hms_helper = New Hms_Helperimpliments
    '            If hms_helper.Get_OutPatient_Info_Latest(dtbl, Txt_PatientID.Text.Trim, Tran_Date, Branch_Code) Then
    '                Txt_PMRID.Text = dtbl.Rows(0).Item("OPD_ID").ToString
    '                If Locate_Outpatient(Txt_PMRID.Text.Trim) Then

    '                Else
    '                    MessageBox.Show("Patient ID not found, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
    '                    Txt_PatientID.Focus()
    '                End If
    '            End If
    '        End If
    '    Catch ex As Exception

    '    End Try
    'End Sub

    Private Sub Btn_Uttility_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Uttility.Click
        Try
            Show_ChildForm("Patient_Transaction_Uttility_Frm", Me.MdiParent, Me.Tag)
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Btn_Report_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Report.Click
        Try
            If Txt_PMRID.Text.Trim <> "" Then
                Call Show_Reciept(Txt_PatientID.Text.Trim)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Details_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Txt_Details.GotFocus
        Me.KeyPreview = False
    End Sub

    Private Sub Txt_Details_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Txt_Details.LostFocus
        Me.KeyPreview = True
    End Sub

    Private Sub Btn_FindDoc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_FindDoc.Click
        Try

            If Txt_DocID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "100|200|100|"
                Sql = "SELECT  Name, Address, Qualification, DoctorID,EmpID,SS_Number as [SS Number]  FROM    Doctormaster_Vw"
                Call ShowSearchengine(Txt_DocID, Sql, 3, "Name", Colwidth, , 0)
            End If

            If Txt_DocID.Text.Trim = "" Then
                Txt_DocID.Focus()
                Exit Sub
            End If

            Dim Dtbl As DataTable = Nothing

            If hms_helper.Get_Doctordetails(Dtbl, Txt_DocID.Text.Trim) Then
                Txt_DocDetails.Text = Dtbl.Rows(0).Item("Name").ToString + vbCrLf
                Txt_DocDetails.Text += Dtbl.Rows(0).Item("Qualification").ToString
            End If

            Txt_Heading.Focus()

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Doctor_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_DocID.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then Btn_FindDoc_Click(sender, e)
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Btn_Deletegridrow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Deletegridrow.Click
        Try
            If Txt_Heading.Tag = "" Then
                MessageBox.Show("Please Locate Grid Row to Modify/Delete", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Return
            End If

            Call Delete_GridRow(Dgv_CaseRecord.CurrentRow.Index)
            Call Reorder_GridValues()
            Txt_Heading.Focus()

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgv_CaseRecord_CellDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgv_CaseRecord.CellDoubleClick
        Try
            If e.RowIndex = -1 Then Exit Sub


            If Locate_Gridvalues(e.RowIndex) Then
                Txt_Heading.Focus()
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgv_CaseRecord_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Dgv_CaseRecord.KeyDown
        Try
            If Not e.KeyCode = Keys.Enter Then Return
            With Dgv_CaseRecord
                If .CurrentRow Is Nothing Then Exit Sub
                If .CurrentCell Is Nothing Then Exit Sub

                If Locate_Gridvalues(.CurrentRow.Index) Then
                    Txt_Heading.Focus()
                End If
            End With



        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgv_CaseRecord_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Dgv_CaseRecord.SelectionChanged
        Try
            Dgv_CaseRecord.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Btn_AddHeading_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_AddHeading.Click
        Try

            Patient_CaseRec_BL = New Patient_CaseRecord_BL_Cls
            If Txt_Heading.Text.Trim <> "" Then
                If hms_helper.Check_Duplicatedataexists("Caserecord_Particulars_Tbl", "Cr_Particulars", Data_Type.General_Type, Txt_Heading.Text.Trim, Branch_Code) Then Exit Sub
                Patient_CaseRec_BL.Cr_Particulars = Txt_Heading.Text.Trim

                If Patient_CaseRec_BL.Save_CaseRec_Particulars(Dtbl, Tr_Mode, 0) Then
                    MessageBox.Show("Case Record Particulars Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Else
                    MessageBox.Show("Case Record Particulars Failed to Save, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgw_HeadingHistory_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgw_HeadingHistory.CellContentClick
        Try
            Dgw_HeadingHistory.Visible = False
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Txt_Heading_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Heading.KeyDown

        Try
            If e.KeyCode = Keys.Enter Then
                Dgw_HeadingHistory.Visible = False
                Return
            End If


            Patient_CaseRec_BL = New Patient_CaseRecord_BL_Cls

            If Len(Txt_Heading.Text.Trim) >= 1 Then
                If Patient_CaseRec_BL.Get_Patient_CaseRecord_List(Dtbl, Txt_Heading.Text.Trim, Branch_Code) Then
                    If Dtbl.Rows.Count > 0 Then ValueExist = True
                    Call Populate_ParticularsGrid(Dtbl)
                End If
            Else
                Dgw_HeadingHistory.Visible = False
            End If

        Catch ex As Exception

        End Try

    End Sub

    Private Sub Dgw_HeadingHistory_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Dgw_HeadingHistory.Click
        Try
            With Dgw_HeadingHistory
                Txt_Heading.Text = .CurrentRow.Cells(0).Value.ToString.Trim
                .Visible = False
                Txt_Details.Focus()
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_PMRID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_PMRID.Validating
        Try
            If Me.Txt_PMRID.Text.Trim <> "" And Me.Txt_PMRID.Text <> Me.Txt_PMRID.Tag Then
                If Not Locate_PMR_info(Txt_PMRID.Text.Trim, Branch_Code) Then
                    MessageBox.Show("Invalid PMR-ID ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Txt_PMRID.Focus()
                    e.Cancel = True
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_Doctor_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_DocID.KeyPress
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_DocID.Text, Data_Type.Integer_Type, 12))
    End Sub
    Private Sub Txt_Doctor_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_DocID.Validating
        Try
            If Me.Txt_DocID.Text.Trim <> "" And Me.Txt_DocID.Text.Trim <> Me.Txt_DocID.Tag Then
                Dim Dtbl As DataTable = Nothing

                If hms_helper.Get_Doctordetails(Dtbl, Txt_DocID.Text.Trim) Then
                    Txt_DocDetails.Text = Dtbl.Rows(0).Item("Name").ToString + vbCrLf
                    Txt_DocDetails.Text += Dtbl.Rows(0).Item("Qualification").ToString
                Else
                    MessageBox.Show("Invalid Doctor ID", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Txt_DocID.Text = ""
                    e.Cancel = True
                End If
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_PatientID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_PatientID.TextChanged
        Try
            Dim dtbl As DataTable = Nothing
            Patient_CaseRec_BL = New Patient_CaseRecord_BL_Cls
            If Patient_CaseRec_BL.Get_PatientID_CaseRecords(dtbl, Txt_PatientID.Text, Branch_Code) Then
                Txt_PMRID.Text = dtbl.Rows(0).Item("OPD_ID").ToString
                Dgv_CaseRecord.RowCount = dtbl.Rows.Count
                For i = 0 To dtbl.Rows.Count - 1
                    With Dgv_CaseRecord
                        .Rows(i).Cells("Slno").Value = i + 1
                        .Rows(i).Cells("Heading").Value = dtbl.Rows(i).Item("Cr_Header").ToString
                        .Rows(i).Cells("Details").Value = dtbl.Rows(i).Item("Cr_Body").ToString
                        .Rows(i).Cells("Footer").Value = dtbl.Rows(i).Item("Cr_Footer").ToString

                    End With
                Next
            End If

            With Patient_Info2
                .Viewmoreform_Name = "Patient_InfoSheet_Frm"
                .MDIform_Name = Me.MdiParent
                .Patient_ID = Txt_PatientID.Text.Trim
            End With

            With Imageviewer1
                .CUST_ID = Txt_PatientID.Text.Trim
                .CUST_TYPE = Customer_Type.Patient
            End With

        Catch ex As Exception

        End Try
    End Sub


    Private Sub Txt_DocID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_DocID.TextChanged
        Try
            If Txt_DocID.Text.Trim = "" Then Txt_DocDetails.Text = ""
        Catch ex As Exception

        End Try
    End Sub

   
    Private Sub Btn_Clearentry_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clearentry.Click
        Try
            Txt_Heading.Text = ""
            Txt_Heading.Tag = ""
            Txt_Details.Text = ""
            Txt_Footer.Text = ""
        Catch ex As Exception

        End Try
    End Sub

End Class