﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Bank_Accounts_Tran_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Bank_Accounts_Tran_Frm))
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Pnl_Header = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel()
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label()
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel()
        Me.Btn_Ledger = New System.Windows.Forms.Button()
        Me.Btn_Clear = New System.Windows.Forms.Button()
        Me.Btn_Close = New System.Windows.Forms.Button()
        Me.Btn_Delete = New System.Windows.Forms.Button()
        Me.Btn_Save = New System.Windows.Forms.Button()
        Me.Btn_Find = New System.Windows.Forms.Button()
        Me.Txt_TranID = New System.Windows.Forms.TextBox()
        Me.Lbl_DocID = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Lbl_GridName = New System.Windows.Forms.Label()
        Me.Dgvw_Bank_Account_Master = New System.Windows.Forms.DataGridView()
        Me.Txt_BankAddress = New System.Windows.Forms.TextBox()
        Me.Cmb_Bank_Name = New System.Windows.Forms.ComboBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Cmb_AccNo = New System.Windows.Forms.ComboBox()
        Me.Cmb_Account_Type = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Lbl_Words = New System.Windows.Forms.Label()
        Me.Pnl_Transaction = New System.Windows.Forms.Panel()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Txt_TransactionBalance = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Txt_Balance = New System.Windows.Forms.TextBox()
        Me.Cmb_TranType = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Cmb_Payment_Mode = New System.Windows.Forms.ComboBox()
        Me.Txt_Amount = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Txt_Remarks = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Pnl_Header.SuspendLayout()
        Me.Pnl_Tran_mode.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        CType(Me.Dgvw_Bank_Account_Master, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Pnl_Transaction.SuspendLayout()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.Controls.Add(Me.Label1)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(674, 24)
        Me.Pnl_Header.TabIndex = 100
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(2, 1)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(305, 18)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "B a n k   A c c o u n t s   T r a n s a c t i o n"
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(298, 30)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(74, 22)
        Me.Pnl_Tran_mode.TabIndex = 48
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(1, 1)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(68, 16)
        Me.Lbl_Tran_Mode.TabIndex = 0
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Ledger)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Delete)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(189, 317)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(289, 35)
        Me.Pnl_Common_Btn.TabIndex = 6
        '
        'Btn_Ledger
        '
        Me.Btn_Ledger.BackgroundImage = CType(resources.GetObject("Btn_Ledger.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Ledger.CausesValidation = False
        Me.Btn_Ledger.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Ledger.Location = New System.Drawing.Point(171, 3)
        Me.Btn_Ledger.Name = "Btn_Ledger"
        Me.Btn_Ledger.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Ledger.TabIndex = 5
        Me.Btn_Ledger.Text = "&Ledger"
        Me.Btn_Ledger.UseVisualStyleBackColor = True
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(115, 3)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear.TabIndex = 3
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(227, 3)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 4
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Delete
        '
        Me.Btn_Delete.BackgroundImage = CType(resources.GetObject("Btn_Delete.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Delete.Location = New System.Drawing.Point(59, 3)
        Me.Btn_Delete.Name = "Btn_Delete"
        Me.Btn_Delete.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Delete.TabIndex = 2
        Me.Btn_Delete.Text = "Cancel"
        Me.Btn_Delete.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(3, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save.TabIndex = 1
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Btn_Find
        '
        Me.Btn_Find.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find.BackgroundImage = CType(resources.GetObject("Btn_Find.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find.ForeColor = System.Drawing.Color.White
        Me.Btn_Find.Location = New System.Drawing.Point(243, 30)
        Me.Btn_Find.Name = "Btn_Find"
        Me.Btn_Find.Size = New System.Drawing.Size(29, 21)
        Me.Btn_Find.TabIndex = 1
        Me.Btn_Find.TabStop = False
        Me.Btn_Find.Text = "F2"
        Me.Btn_Find.UseVisualStyleBackColor = False
        '
        'Txt_TranID
        '
        Me.Txt_TranID.BackColor = System.Drawing.Color.White
        Me.Txt_TranID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_TranID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_TranID.Location = New System.Drawing.Point(114, 30)
        Me.Txt_TranID.Name = "Txt_TranID"
        Me.Txt_TranID.Size = New System.Drawing.Size(128, 21)
        Me.Txt_TranID.TabIndex = 0
        '
        'Lbl_DocID
        '
        Me.Lbl_DocID.AutoSize = True
        Me.Lbl_DocID.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_DocID.ForeColor = System.Drawing.Color.White
        Me.Lbl_DocID.Location = New System.Drawing.Point(6, 34)
        Me.Lbl_DocID.Name = "Lbl_DocID"
        Me.Lbl_DocID.Size = New System.Drawing.Size(55, 13)
        Me.Lbl_DocID.TabIndex = 50
        Me.Lbl_DocID.Text = "Trans ID"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(6, 61)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(70, 13)
        Me.Label5.TabIndex = 91
        Me.Label5.Text = "Bank Name"
        '
        'Lbl_GridName
        '
        Me.Lbl_GridName.BackColor = System.Drawing.Color.FromArgb(CType(CType(19, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(153, Byte), Integer))
        Me.Lbl_GridName.ForeColor = System.Drawing.Color.White
        Me.Lbl_GridName.Location = New System.Drawing.Point(6, 364)
        Me.Lbl_GridName.Name = "Lbl_GridName"
        Me.Lbl_GridName.Size = New System.Drawing.Size(655, 18)
        Me.Lbl_GridName.TabIndex = 142
        Me.Lbl_GridName.Text = "B a n k   A c c o u n t   M a s t e r"
        Me.Lbl_GridName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Dgvw_Bank_Account_Master
        '
        Me.Dgvw_Bank_Account_Master.AllowUserToAddRows = False
        Me.Dgvw_Bank_Account_Master.AllowUserToDeleteRows = False
        Me.Dgvw_Bank_Account_Master.AllowUserToResizeColumns = False
        Me.Dgvw_Bank_Account_Master.AllowUserToResizeRows = False
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(248, Byte), Integer))
        DataGridViewCellStyle5.ForeColor = System.Drawing.Color.DarkBlue
        Me.Dgvw_Bank_Account_Master.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle5
        Me.Dgvw_Bank_Account_Master.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(236, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Dgvw_Bank_Account_Master.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(CType(CType(75, Byte), Integer), CType(CType(116, Byte), Integer), CType(CType(165, Byte), Integer))
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgvw_Bank_Account_Master.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.Dgvw_Bank_Account_Master.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Dgvw_Bank_Account_Master.Location = New System.Drawing.Point(6, 385)
        Me.Dgvw_Bank_Account_Master.Name = "Dgvw_Bank_Account_Master"
        Me.Dgvw_Bank_Account_Master.ReadOnly = True
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(179, Byte), Integer))
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgvw_Bank_Account_Master.RowHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.Dgvw_Bank_Account_Master.RowHeadersVisible = False
        DataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(CType(CType(219, Byte), Integer), CType(CType(227, Byte), Integer), CType(CType(249, Byte), Integer))
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.Color.DarkBlue
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.DeepSkyBlue
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.Black
        Me.Dgvw_Bank_Account_Master.RowsDefaultCellStyle = DataGridViewCellStyle8
        Me.Dgvw_Bank_Account_Master.Size = New System.Drawing.Size(655, 117)
        Me.Dgvw_Bank_Account_Master.TabIndex = 141
        '
        'Txt_BankAddress
        '
        Me.Txt_BankAddress.BackColor = System.Drawing.Color.White
        Me.Txt_BankAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_BankAddress.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_BankAddress.Location = New System.Drawing.Point(399, 70)
        Me.Txt_BankAddress.Multiline = True
        Me.Txt_BankAddress.Name = "Txt_BankAddress"
        Me.Txt_BankAddress.ReadOnly = True
        Me.Txt_BankAddress.Size = New System.Drawing.Size(262, 68)
        Me.Txt_BankAddress.TabIndex = 9
        Me.Txt_BankAddress.TabStop = False
        '
        'Cmb_Bank_Name
        '
        Me.Cmb_Bank_Name.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Bank_Name.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Bank_Name.FormattingEnabled = True
        Me.Cmb_Bank_Name.Location = New System.Drawing.Point(114, 57)
        Me.Cmb_Bank_Name.Name = "Cmb_Bank_Name"
        Me.Cmb_Bank_Name.Size = New System.Drawing.Size(257, 21)
        Me.Cmb_Bank_Name.TabIndex = 2
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.FromArgb(CType(CType(19, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(153, Byte), Integer))
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(399, 50)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(262, 18)
        Me.Label10.TabIndex = 159
        Me.Label10.Text = "B a n k   I n f o r m a t i o n"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(6, 115)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 13)
        Me.Label3.TabIndex = 163
        Me.Label3.Text = "A/c No"
        '
        'Cmb_AccNo
        '
        Me.Cmb_AccNo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_AccNo.Enabled = False
        Me.Cmb_AccNo.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_AccNo.FormattingEnabled = True
        Me.Cmb_AccNo.Location = New System.Drawing.Point(114, 111)
        Me.Cmb_AccNo.Name = "Cmb_AccNo"
        Me.Cmb_AccNo.Size = New System.Drawing.Size(258, 21)
        Me.Cmb_AccNo.TabIndex = 4
        '
        'Cmb_Account_Type
        '
        Me.Cmb_Account_Type.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.Cmb_Account_Type.CausesValidation = False
        Me.Cmb_Account_Type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Account_Type.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Account_Type.FormattingEnabled = True
        Me.Cmb_Account_Type.ItemHeight = 13
        Me.Cmb_Account_Type.Location = New System.Drawing.Point(114, 84)
        Me.Cmb_Account_Type.Name = "Cmb_Account_Type"
        Me.Cmb_Account_Type.Size = New System.Drawing.Size(258, 21)
        Me.Cmb_Account_Type.TabIndex = 3
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(6, 87)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(84, 13)
        Me.Label7.TabIndex = 10019
        Me.Label7.Text = "Account Type"
        '
        'Lbl_Words
        '
        Me.Lbl_Words.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Words.ForeColor = System.Drawing.Color.Maroon
        Me.Lbl_Words.Location = New System.Drawing.Point(7, 298)
        Me.Lbl_Words.Name = "Lbl_Words"
        Me.Lbl_Words.Size = New System.Drawing.Size(653, 17)
        Me.Lbl_Words.TabIndex = 10020
        Me.Lbl_Words.Text = "Words"
        Me.Lbl_Words.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Pnl_Transaction
        '
        Me.Pnl_Transaction.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Transaction.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Transaction.Controls.Add(Me.Label12)
        Me.Pnl_Transaction.Controls.Add(Me.Txt_TransactionBalance)
        Me.Pnl_Transaction.Controls.Add(Me.Label11)
        Me.Pnl_Transaction.Controls.Add(Me.Txt_Balance)
        Me.Pnl_Transaction.Controls.Add(Me.Cmb_TranType)
        Me.Pnl_Transaction.Controls.Add(Me.Label9)
        Me.Pnl_Transaction.Controls.Add(Me.Label4)
        Me.Pnl_Transaction.Controls.Add(Me.Label2)
        Me.Pnl_Transaction.Controls.Add(Me.Cmb_Payment_Mode)
        Me.Pnl_Transaction.Controls.Add(Me.Txt_Amount)
        Me.Pnl_Transaction.Controls.Add(Me.Label6)
        Me.Pnl_Transaction.Controls.Add(Me.Txt_Remarks)
        Me.Pnl_Transaction.Controls.Add(Me.Label8)
        Me.Pnl_Transaction.Location = New System.Drawing.Point(7, 141)
        Me.Pnl_Transaction.Name = "Pnl_Transaction"
        Me.Pnl_Transaction.Size = New System.Drawing.Size(654, 149)
        Me.Pnl_Transaction.TabIndex = 5
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.ForeColor = System.Drawing.Color.White
        Me.Label12.Location = New System.Drawing.Point(226, 93)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(121, 13)
        Me.Label12.TabIndex = 10029
        Me.Label12.Text = "Transaction Balance"
        '
        'Txt_TransactionBalance
        '
        Me.Txt_TransactionBalance.BackColor = System.Drawing.Color.White
        Me.Txt_TransactionBalance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_TransactionBalance.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_TransactionBalance.Location = New System.Drawing.Point(356, 88)
        Me.Txt_TransactionBalance.Name = "Txt_TransactionBalance"
        Me.Txt_TransactionBalance.ReadOnly = True
        Me.Txt_TransactionBalance.Size = New System.Drawing.Size(168, 24)
        Me.Txt_TransactionBalance.TabIndex = 10028
        Me.Txt_TransactionBalance.TabStop = False
        Me.Txt_TransactionBalance.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(254, 35)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(93, 13)
        Me.Label11.TabIndex = 10027
        Me.Label11.Text = "Ledger Balance"
        '
        'Txt_Balance
        '
        Me.Txt_Balance.BackColor = System.Drawing.Color.White
        Me.Txt_Balance.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Balance.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Balance.Location = New System.Drawing.Point(356, 30)
        Me.Txt_Balance.Name = "Txt_Balance"
        Me.Txt_Balance.ReadOnly = True
        Me.Txt_Balance.Size = New System.Drawing.Size(168, 24)
        Me.Txt_Balance.TabIndex = 10022
        Me.Txt_Balance.TabStop = False
        Me.Txt_Balance.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Cmb_TranType
        '
        Me.Cmb_TranType.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.Cmb_TranType.CausesValidation = False
        Me.Cmb_TranType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_TranType.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_TranType.FormattingEnabled = True
        Me.Cmb_TranType.ItemHeight = 16
        Me.Cmb_TranType.Location = New System.Drawing.Point(108, 30)
        Me.Cmb_TranType.Name = "Cmb_TranType"
        Me.Cmb_TranType.Size = New System.Drawing.Size(126, 24)
        Me.Cmb_TranType.TabIndex = 10019
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.FromArgb(CType(CType(19, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(153, Byte), Integer))
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(0, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(652, 18)
        Me.Label9.TabIndex = 10026
        Me.Label9.Text = "T r a n s a c t i o n   D e t a i l s"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(1, 35)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(105, 13)
        Me.Label4.TabIndex = 10025
        Me.Label4.Text = "Transaction Type"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(1, 63)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(92, 13)
        Me.Label2.TabIndex = 10024
        Me.Label2.Text = "Payment Mode"
        '
        'Cmb_Payment_Mode
        '
        Me.Cmb_Payment_Mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(240, Byte), Integer))
        Me.Cmb_Payment_Mode.CausesValidation = False
        Me.Cmb_Payment_Mode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Payment_Mode.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Payment_Mode.FormattingEnabled = True
        Me.Cmb_Payment_Mode.ItemHeight = 16
        Me.Cmb_Payment_Mode.Location = New System.Drawing.Point(108, 59)
        Me.Cmb_Payment_Mode.Name = "Cmb_Payment_Mode"
        Me.Cmb_Payment_Mode.Size = New System.Drawing.Size(126, 24)
        Me.Cmb_Payment_Mode.TabIndex = 10020
        '
        'Txt_Amount
        '
        Me.Txt_Amount.BackColor = System.Drawing.Color.White
        Me.Txt_Amount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Amount.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Amount.Location = New System.Drawing.Point(356, 59)
        Me.Txt_Amount.Name = "Txt_Amount"
        Me.Txt_Amount.Size = New System.Drawing.Size(168, 24)
        Me.Txt_Amount.TabIndex = 10021
        Me.Txt_Amount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(295, 63)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(52, 13)
        Me.Label6.TabIndex = 10023
        Me.Label6.Text = "Amount"
        '
        'Txt_Remarks
        '
        Me.Txt_Remarks.BackColor = System.Drawing.Color.White
        Me.Txt_Remarks.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Remarks.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Remarks.Location = New System.Drawing.Point(108, 118)
        Me.Txt_Remarks.Name = "Txt_Remarks"
        Me.Txt_Remarks.Size = New System.Drawing.Size(416, 21)
        Me.Txt_Remarks.TabIndex = 10022
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(1, 121)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(60, 13)
        Me.Label8.TabIndex = 10018
        Me.Label8.Text = "Narration"
        '
        'Bank_Accounts_Tran_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Highlight
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(674, 505)
        Me.Controls.Add(Me.Pnl_Transaction)
        Me.Controls.Add(Me.Lbl_Words)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Cmb_Account_Type)
        Me.Controls.Add(Me.Cmb_AccNo)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Cmb_Bank_Name)
        Me.Controls.Add(Me.Txt_BankAddress)
        Me.Controls.Add(Me.Lbl_GridName)
        Me.Controls.Add(Me.Dgvw_Bank_Account_Master)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Txt_TranID)
        Me.Controls.Add(Me.Lbl_DocID)
        Me.Controls.Add(Me.Pnl_Tran_mode)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.Btn_Find)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Bank_Accounts_Tran_Frm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "   "
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Pnl_Tran_mode.ResumeLayout(False)
        Me.Pnl_Common_Btn.ResumeLayout(False)
        CType(Me.Dgvw_Bank_Account_Master, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Pnl_Transaction.ResumeLayout(False)
        Me.Pnl_Transaction.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Delete As System.Windows.Forms.Button
    Friend WithEvents Btn_Find As System.Windows.Forms.Button
    Friend WithEvents Txt_TranID As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_DocID As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Lbl_GridName As System.Windows.Forms.Label
    Friend WithEvents Dgvw_Bank_Account_Master As System.Windows.Forms.DataGridView
    Friend WithEvents Txt_BankAddress As System.Windows.Forms.TextBox
    Friend WithEvents Cmb_Bank_Name As System.Windows.Forms.ComboBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Cmb_AccNo As System.Windows.Forms.ComboBox
    Friend WithEvents Cmb_Account_Type As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Words As System.Windows.Forms.Label
    Friend WithEvents Pnl_Transaction As System.Windows.Forms.Panel
    Friend WithEvents Cmb_TranType As System.Windows.Forms.ComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Payment_Mode As System.Windows.Forms.ComboBox
    Friend WithEvents Txt_Amount As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Txt_Remarks As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Txt_Balance As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Txt_TransactionBalance As System.Windows.Forms.TextBox
    Friend WithEvents Btn_Ledger As System.Windows.Forms.Button
End Class
