﻿

Option Explicit On
Imports HMS_Common.Common_Cls
Imports HMS_BL

Public Class LoginForm

    Private Com_BL As HMS_Common_BL_Cls

  

    

    Private Sub LoginForm_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
        
    End Sub

    Private Sub LoginForm_FormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        End
    End Sub

    Private Sub LoginForm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub LoginForm_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyUp
        Try
            If e.KeyCode = Keys.F8 Then
                UsernameTextBox.Text = System.Configuration.ConfigurationManager.AppSettings("Admin_Uname")
                PasswordTextBox.Text = System.Configuration.ConfigurationManager.AppSettings("Admin_Pwd")
                Call OK_Click(sender, e)
            End If


        Catch ex As Exception

        End Try
    End Sub

    Private Sub LoginForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Call Set_Systemdateformat("dd-MM-yyyy", "dddd, dd MMMM yyyy")

        Catch ex As Exception

        End Try
    End Sub

    Private Sub LoginForm_VisibleChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.VisibleChanged
        Try

            Call Set_Systemdateformat("dd-MM-yyyy", "dddd, dd MMMM yyyy")

        Catch ex As Exception

        End Try
    End Sub

  
    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.Click
        Try

            Com_BL = New HMS_Common_BL_Cls

            Dim msgstr As String = ""

            Call Get_SystemInfo()


            User_Name = UsernameTextBox.Text
            User_Password = PasswordTextBox.Text


            If Com_BL.Is_ValidUser(msgstr) Then
                'Setting Company profile
                Call Com_BL.Set_CompanyProfile()
                'Setting File \ Report path
                Call Com_BL.Get_Resorcevalue()



                With HMS_MDIMain_Frm
                    .Lbl_Company.Text = Company_Name.ToUpper.Trim
                    .Lbl_Branch.Text = Branch_Name.ToUpper.Trim + " BRANCH"
                    .Lbl_Branch.Text += "  - Ph: " + Branch_Phone1.Trim
                    .DCMGT_Statusbar.Text = "Log User : " & User_Custname & "    Designation : " & User_Designation & "    Date : " & System.DateTime.Now.Date
                    .Show()
                End With

                Me.Hide()
            Else
                MessageBox.Show(msgstr, "Invalid User", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

        Catch ex As Exception

        End Try

    End Sub

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        End
    End Sub
End Class
