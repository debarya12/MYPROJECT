﻿'Developed by   : PRAMODBHASKER
'Date           : 01-10-2010
'Purpose        : Act as  Transaction Grid

Option Explicit On
Public Class Tran_Grid
    Inherits DataGridView

    Protected Overloads Overrides Function ProcessDialogKey(ByVal keyData As Keys) As Boolean
        Try


            If keyData = Keys.Enter Then
                Dim row As Integer = Me.CurrentCell.RowIndex

                If row < Me.RowCount Then
                    If row = Me.RowCount - 1 Then
                        'Call SendKeyTab()
                        Return False
                    Else
                        MyBase.OnKeyDown(New KeyEventArgs(keyData))
                        Return True
                    End If


                End If

            End If
            Return MyBase.ProcessDialogKey(keyData)
        Catch ex As Exception
            Return MyBase.ProcessDialogKey(keyData)
        End Try
    End Function

    Protected Overloads Overrides Sub OnKeyDown(ByVal e As KeyEventArgs)
        Try
            If e.KeyData = Keys.Enter Then
                'Dim row As Integer = Me.CurrentCell.RowIndex
                'If row < Me.RowCount Then
                '    Me.CurrentCell = Me(2, row)
                'End If
            Else
                MyBase.OnKeyDown(e)
            End If


        Catch ex As Exception

        End Try
    End Sub

    Protected Overloads Overrides Sub OnKeyUp(ByVal e As KeyEventArgs)
        Try
            If e.KeyData = Keys.Enter Then

                Dim row As Integer = Me.CurrentCell.RowIndex

                If row < Me.RowCount Then
                    Me.CurrentCell = Me(2, row)
                Else
                    Call SendKeyTab()
                    Return
                End If


            Else
                MyBase.OnKeyUp(e)
            End If


        Catch ex As Exception

        End Try
    End Sub

End Class