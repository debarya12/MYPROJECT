﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Insuarance_Master_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Insuarance_Master_Frm))
        Me.Pnl_Header = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Txt_InsComp_ID = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Txt_Company_Name = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel()
        Me.Btn_Clear = New System.Windows.Forms.Button()
        Me.Btn_Close = New System.Windows.Forms.Button()
        Me.Btn_Delete = New System.Windows.Forms.Button()
        Me.Btn_Save = New System.Windows.Forms.Button()
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel()
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label()
        Me.Btn_FindID = New System.Windows.Forms.Button()
        Me.Dtp_Company_RegDt = New System.Windows.Forms.DateTimePicker()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Txt_Zip = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Txt_Company_Email = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Txt_Company_Mob = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Txt_Company_Phone = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.cmb_State = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Txt_City = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Cmb_Country = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Txt_Company_Address = New System.Windows.Forms.TextBox()
        Me.Btn_Tab2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Txt_Contact_Person_Email = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Txt_Contact_Person_Mobile = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Txt_Contact_Person_Phone = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Txt_Contact_Person_Address = New System.Windows.Forms.TextBox()
        Me.Txt_Contact_Person_Name = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Cmb_Active = New System.Windows.Forms.ComboBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Txt_Company_Web = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Txt_Contact_Person_Fax = New System.Windows.Forms.TextBox()
        Me.Txt_Company_Fax = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Txt_Remarks = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Btn_New = New System.Windows.Forms.Button()
        Me.Pnl_Header.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.Pnl_Tran_mode.SuspendLayout()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.Controls.Add(Me.Label3)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(576, 24)
        Me.Pnl_Header.TabIndex = 10000
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(-3, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(199, 18)
        Me.Label3.TabIndex = 10000
        Me.Label3.Text = "I n s u r a n c e   M a s t e r"
        '
        'Txt_InsComp_ID
        '
        Me.Txt_InsComp_ID.BackColor = System.Drawing.Color.White
        Me.Txt_InsComp_ID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_InsComp_ID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_InsComp_ID.ForeColor = System.Drawing.Color.Black
        Me.Txt_InsComp_ID.Location = New System.Drawing.Point(121, 60)
        Me.Txt_InsComp_ID.MaxLength = 10
        Me.Txt_InsComp_ID.Name = "Txt_InsComp_ID"
        Me.Txt_InsComp_ID.Size = New System.Drawing.Size(116, 21)
        Me.Txt_InsComp_ID.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(14, 62)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(20, 13)
        Me.Label2.TabIndex = 115
        Me.Label2.Text = "ID"
        '
        'Txt_Company_Name
        '
        Me.Txt_Company_Name.BackColor = System.Drawing.Color.White
        Me.Txt_Company_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Company_Name.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Company_Name.Location = New System.Drawing.Point(121, 87)
        Me.Txt_Company_Name.MaxLength = 250
        Me.Txt_Company_Name.Name = "Txt_Company_Name"
        Me.Txt_Company_Name.Size = New System.Drawing.Size(440, 21)
        Me.Txt_Company_Name.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(14, 90)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(95, 13)
        Me.Label1.TabIndex = 117
        Me.Label1.Text = "Company Name"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Delete)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(121, 481)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(230, 37)
        Me.Pnl_Common_Btn.TabIndex = 20
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(113, 3)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear.TabIndex = 2
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(169, 3)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 3
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Delete
        '
        Me.Btn_Delete.BackgroundImage = CType(resources.GetObject("Btn_Delete.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Delete.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Delete.Location = New System.Drawing.Point(58, 3)
        Me.Btn_Delete.Name = "Btn_Delete"
        Me.Btn_Delete.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Delete.TabIndex = 1
        Me.Btn_Delete.Text = "Delete"
        Me.Btn_Delete.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = CType(resources.GetObject("Btn_Save.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(2, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save.TabIndex = 0
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(487, 60)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(74, 21)
        Me.Pnl_Tran_mode.TabIndex = 30000
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(1, 1)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(68, 16)
        Me.Lbl_Tran_Mode.TabIndex = 126
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Btn_FindID
        '
        Me.Btn_FindID.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_FindID.BackgroundImage = CType(resources.GetObject("Btn_FindID.BackgroundImage"), System.Drawing.Image)
        Me.Btn_FindID.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_FindID.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_FindID.ForeColor = System.Drawing.Color.White
        Me.Btn_FindID.Location = New System.Drawing.Point(238, 60)
        Me.Btn_FindID.Name = "Btn_FindID"
        Me.Btn_FindID.Size = New System.Drawing.Size(29, 21)
        Me.Btn_FindID.TabIndex = 100000
        Me.Btn_FindID.TabStop = False
        Me.Btn_FindID.Text = "F2"
        Me.Btn_FindID.UseVisualStyleBackColor = False
        '
        'Dtp_Company_RegDt
        '
        Me.Dtp_Company_RegDt.Cursor = System.Windows.Forms.Cursors.Default
        Me.Dtp_Company_RegDt.CustomFormat = "dd/MM/yyyy"
        Me.Dtp_Company_RegDt.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_Company_RegDt.Location = New System.Drawing.Point(384, 60)
        Me.Dtp_Company_RegDt.Name = "Dtp_Company_RegDt"
        Me.Dtp_Company_RegDt.Size = New System.Drawing.Size(97, 21)
        Me.Dtp_Company_RegDt.TabIndex = 11
        Me.Dtp_Company_RegDt.TabStop = False
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.Color.Transparent
        Me.Label20.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label20.Location = New System.Drawing.Point(343, 62)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(34, 13)
        Me.Label20.TabIndex = 100020
        Me.Label20.Text = "Date"
        '
        'Txt_Zip
        '
        Me.Txt_Zip.BackColor = System.Drawing.Color.White
        Me.Txt_Zip.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Zip.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Zip.Location = New System.Drawing.Point(121, 277)
        Me.Txt_Zip.MaxLength = 50
        Me.Txt_Zip.Name = "Txt_Zip"
        Me.Txt_Zip.Size = New System.Drawing.Size(216, 21)
        Me.Txt_Zip.TabIndex = 6
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.ForeColor = System.Drawing.Color.White
        Me.Label14.Location = New System.Drawing.Point(14, 278)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(55, 13)
        Me.Label14.TabIndex = 100016
        Me.Label14.Text = "Zip Code"
        '
        'Txt_Company_Email
        '
        Me.Txt_Company_Email.BackColor = System.Drawing.Color.White
        Me.Txt_Company_Email.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Company_Email.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Company_Email.Location = New System.Drawing.Point(402, 250)
        Me.Txt_Company_Email.MaxLength = 100
        Me.Txt_Company_Email.Name = "Txt_Company_Email"
        Me.Txt_Company_Email.Size = New System.Drawing.Size(159, 21)
        Me.Txt_Company_Email.TabIndex = 9
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.ForeColor = System.Drawing.Color.White
        Me.Label12.Location = New System.Drawing.Point(343, 257)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(37, 13)
        Me.Label12.TabIndex = 100015
        Me.Label12.Text = "Email"
        '
        'Txt_Company_Mob
        '
        Me.Txt_Company_Mob.BackColor = System.Drawing.Color.White
        Me.Txt_Company_Mob.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Company_Mob.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Company_Mob.Location = New System.Drawing.Point(402, 223)
        Me.Txt_Company_Mob.MaxLength = 10
        Me.Txt_Company_Mob.Name = "Txt_Company_Mob"
        Me.Txt_Company_Mob.Size = New System.Drawing.Size(159, 21)
        Me.Txt_Company_Mob.TabIndex = 8
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(343, 228)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(44, 13)
        Me.Label11.TabIndex = 100014
        Me.Label11.Text = "Mobile"
        '
        'Txt_Company_Phone
        '
        Me.Txt_Company_Phone.BackColor = System.Drawing.Color.White
        Me.Txt_Company_Phone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Company_Phone.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Company_Phone.Location = New System.Drawing.Point(402, 196)
        Me.Txt_Company_Phone.MaxLength = 11
        Me.Txt_Company_Phone.Name = "Txt_Company_Phone"
        Me.Txt_Company_Phone.Size = New System.Drawing.Size(159, 21)
        Me.Txt_Company_Phone.TabIndex = 7
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(343, 200)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(42, 13)
        Me.Label8.TabIndex = 100013
        Me.Label8.Text = "Phone"
        '
        'cmb_State
        '
        Me.cmb_State.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_State.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_State.FormattingEnabled = True
        Me.cmb_State.Location = New System.Drawing.Point(121, 250)
        Me.cmb_State.Name = "cmb_State"
        Me.cmb_State.Size = New System.Drawing.Size(187, 21)
        Me.cmb_State.TabIndex = 5
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(14, 252)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(38, 13)
        Me.Label7.TabIndex = 100012
        Me.Label7.Text = "State"
        '
        'Txt_City
        '
        Me.Txt_City.BackColor = System.Drawing.Color.White
        Me.Txt_City.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_City.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_City.Location = New System.Drawing.Point(121, 196)
        Me.Txt_City.MaxLength = 50
        Me.Txt_City.Name = "Txt_City"
        Me.Txt_City.Size = New System.Drawing.Size(216, 21)
        Me.Txt_City.TabIndex = 3
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(14, 200)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(32, 13)
        Me.Label6.TabIndex = 100011
        Me.Label6.Text = "City "
        '
        'Cmb_Country
        '
        Me.Cmb_Country.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Country.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Country.FormattingEnabled = True
        Me.Cmb_Country.Location = New System.Drawing.Point(121, 223)
        Me.Cmb_Country.Name = "Cmb_Country"
        Me.Cmb_Country.Size = New System.Drawing.Size(187, 21)
        Me.Cmb_Country.TabIndex = 4
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(14, 226)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(52, 13)
        Me.Label5.TabIndex = 100010
        Me.Label5.Text = "Country"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(14, 116)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(53, 13)
        Me.Label4.TabIndex = 100009
        Me.Label4.Text = "Address"
        '
        'Txt_Company_Address
        '
        Me.Txt_Company_Address.BackColor = System.Drawing.Color.White
        Me.Txt_Company_Address.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Company_Address.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Company_Address.Location = New System.Drawing.Point(121, 114)
        Me.Txt_Company_Address.MaxLength = 500
        Me.Txt_Company_Address.Multiline = True
        Me.Txt_Company_Address.Name = "Txt_Company_Address"
        Me.Txt_Company_Address.Size = New System.Drawing.Size(439, 76)
        Me.Txt_Company_Address.TabIndex = 2
        '
        'Btn_Tab2
        '
        Me.Btn_Tab2.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Tab2.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Tab2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Tab2.ForeColor = System.Drawing.Color.White
        Me.Btn_Tab2.Location = New System.Drawing.Point(121, 40)
        Me.Btn_Tab2.Name = "Btn_Tab2"
        Me.Btn_Tab2.Size = New System.Drawing.Size(441, 10)
        Me.Btn_Tab2.TabIndex = 100021
        Me.Btn_Tab2.TabStop = False
        Me.Btn_Tab2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Button1.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(121, 357)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(441, 10)
        Me.Button1.TabIndex = 24
        Me.Button1.TabStop = False
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label9.Location = New System.Drawing.Point(12, 36)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(121, 16)
        Me.Label9.TabIndex = 100023
        Me.Label9.Text = "Basic Information"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label10.Location = New System.Drawing.Point(14, 354)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(108, 16)
        Me.Label10.TabIndex = 100024
        Me.Label10.Text = "Contact Person"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Txt_Contact_Person_Email
        '
        Me.Txt_Contact_Person_Email.BackColor = System.Drawing.Color.White
        Me.Txt_Contact_Person_Email.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Contact_Person_Email.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Contact_Person_Email.Location = New System.Drawing.Point(402, 399)
        Me.Txt_Contact_Person_Email.MaxLength = 100
        Me.Txt_Contact_Person_Email.Name = "Txt_Contact_Person_Email"
        Me.Txt_Contact_Person_Email.Size = New System.Drawing.Size(159, 21)
        Me.Txt_Contact_Person_Email.TabIndex = 17
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label13.Location = New System.Drawing.Point(343, 404)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(39, 13)
        Me.Label13.TabIndex = 100036
        Me.Label13.Text = "E Mail"
        '
        'Txt_Contact_Person_Mobile
        '
        Me.Txt_Contact_Person_Mobile.BackColor = System.Drawing.Color.White
        Me.Txt_Contact_Person_Mobile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Contact_Person_Mobile.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Contact_Person_Mobile.Location = New System.Drawing.Point(402, 372)
        Me.Txt_Contact_Person_Mobile.MaxLength = 11
        Me.Txt_Contact_Person_Mobile.Name = "Txt_Contact_Person_Mobile"
        Me.Txt_Contact_Person_Mobile.Size = New System.Drawing.Size(159, 21)
        Me.Txt_Contact_Person_Mobile.TabIndex = 16
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label15.Location = New System.Drawing.Point(343, 378)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(44, 13)
        Me.Label15.TabIndex = 100035
        Me.Label15.Text = "Mobile"
        '
        'Txt_Contact_Person_Phone
        '
        Me.Txt_Contact_Person_Phone.BackColor = System.Drawing.Color.White
        Me.Txt_Contact_Person_Phone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Contact_Person_Phone.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Contact_Person_Phone.Location = New System.Drawing.Point(402, 426)
        Me.Txt_Contact_Person_Phone.MaxLength = 12
        Me.Txt_Contact_Person_Phone.Name = "Txt_Contact_Person_Phone"
        Me.Txt_Contact_Person_Phone.Size = New System.Drawing.Size(159, 21)
        Me.Txt_Contact_Person_Phone.TabIndex = 18
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label16.Location = New System.Drawing.Point(343, 430)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(42, 13)
        Me.Label16.TabIndex = 100034
        Me.Label16.Text = "Phone"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label17.Location = New System.Drawing.Point(343, 456)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(27, 13)
        Me.Label17.TabIndex = 100033
        Me.Label17.Text = "Fax"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.Transparent
        Me.Label18.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label18.Location = New System.Drawing.Point(14, 408)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(53, 13)
        Me.Label18.TabIndex = 100032
        Me.Label18.Text = "Address"
        '
        'Txt_Contact_Person_Address
        '
        Me.Txt_Contact_Person_Address.BackColor = System.Drawing.Color.White
        Me.Txt_Contact_Person_Address.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Contact_Person_Address.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Contact_Person_Address.Location = New System.Drawing.Point(121, 400)
        Me.Txt_Contact_Person_Address.MaxLength = 500
        Me.Txt_Contact_Person_Address.Multiline = True
        Me.Txt_Contact_Person_Address.Name = "Txt_Contact_Person_Address"
        Me.Txt_Contact_Person_Address.Size = New System.Drawing.Size(216, 75)
        Me.Txt_Contact_Person_Address.TabIndex = 15
        '
        'Txt_Contact_Person_Name
        '
        Me.Txt_Contact_Person_Name.BackColor = System.Drawing.Color.White
        Me.Txt_Contact_Person_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Contact_Person_Name.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Contact_Person_Name.Location = New System.Drawing.Point(121, 373)
        Me.Txt_Contact_Person_Name.MaxLength = 250
        Me.Txt_Contact_Person_Name.Name = "Txt_Contact_Person_Name"
        Me.Txt_Contact_Person_Name.Size = New System.Drawing.Size(216, 21)
        Me.Txt_Contact_Person_Name.TabIndex = 14
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label19.Location = New System.Drawing.Point(14, 376)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(39, 13)
        Me.Label19.TabIndex = 100026
        Me.Label19.Text = "Name"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Cmb_Active
        '
        Me.Cmb_Active.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Active.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Active.FormattingEnabled = True
        Me.Cmb_Active.Location = New System.Drawing.Point(121, 304)
        Me.Cmb_Active.Name = "Cmb_Active"
        Me.Cmb_Active.Size = New System.Drawing.Size(66, 21)
        Me.Cmb_Active.TabIndex = 11
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.Color.Transparent
        Me.Label21.ForeColor = System.Drawing.Color.White
        Me.Label21.Location = New System.Drawing.Point(14, 304)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(43, 13)
        Me.Label21.TabIndex = 100038
        Me.Label21.Text = "Active"
        '
        'Txt_Company_Web
        '
        Me.Txt_Company_Web.BackColor = System.Drawing.Color.White
        Me.Txt_Company_Web.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Company_Web.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Company_Web.Location = New System.Drawing.Point(231, 304)
        Me.Txt_Company_Web.MaxLength = 100
        Me.Txt_Company_Web.Name = "Txt_Company_Web"
        Me.Txt_Company_Web.Size = New System.Drawing.Size(329, 21)
        Me.Txt_Company_Web.TabIndex = 12
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.BackColor = System.Drawing.Color.Transparent
        Me.Label22.ForeColor = System.Drawing.Color.White
        Me.Label22.Location = New System.Drawing.Point(193, 307)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(32, 13)
        Me.Label22.TabIndex = 100040
        Me.Label22.Text = "Web"
        '
        'Txt_Contact_Person_Fax
        '
        Me.Txt_Contact_Person_Fax.BackColor = System.Drawing.Color.White
        Me.Txt_Contact_Person_Fax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Contact_Person_Fax.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Contact_Person_Fax.Location = New System.Drawing.Point(402, 454)
        Me.Txt_Contact_Person_Fax.MaxLength = 50
        Me.Txt_Contact_Person_Fax.Name = "Txt_Contact_Person_Fax"
        Me.Txt_Contact_Person_Fax.Size = New System.Drawing.Size(159, 21)
        Me.Txt_Contact_Person_Fax.TabIndex = 19
        '
        'Txt_Company_Fax
        '
        Me.Txt_Company_Fax.BackColor = System.Drawing.Color.White
        Me.Txt_Company_Fax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Company_Fax.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Company_Fax.Location = New System.Drawing.Point(402, 277)
        Me.Txt_Company_Fax.MaxLength = 100
        Me.Txt_Company_Fax.Name = "Txt_Company_Fax"
        Me.Txt_Company_Fax.Size = New System.Drawing.Size(159, 21)
        Me.Txt_Company_Fax.TabIndex = 10
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.BackColor = System.Drawing.Color.Transparent
        Me.Label23.ForeColor = System.Drawing.Color.White
        Me.Label23.Location = New System.Drawing.Point(343, 284)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(27, 13)
        Me.Label23.TabIndex = 100042
        Me.Label23.Text = "Fax"
        '
        'Txt_Remarks
        '
        Me.Txt_Remarks.BackColor = System.Drawing.Color.White
        Me.Txt_Remarks.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Remarks.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Remarks.Location = New System.Drawing.Point(121, 331)
        Me.Txt_Remarks.MaxLength = 200
        Me.Txt_Remarks.Name = "Txt_Remarks"
        Me.Txt_Remarks.Size = New System.Drawing.Size(283, 21)
        Me.Txt_Remarks.TabIndex = 13
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.BackColor = System.Drawing.Color.Transparent
        Me.Label24.ForeColor = System.Drawing.Color.White
        Me.Label24.Location = New System.Drawing.Point(14, 330)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(58, 13)
        Me.Label24.TabIndex = 100044
        Me.Label24.Text = "Remarks"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.BackColor = System.Drawing.Color.Transparent
        Me.Label32.ForeColor = System.Drawing.Color.Red
        Me.Label32.Location = New System.Drawing.Point(101, 82)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(14, 13)
        Me.Label32.TabIndex = 100045
        Me.Label32.Text = "*"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.BackColor = System.Drawing.Color.Transparent
        Me.Label25.ForeColor = System.Drawing.Color.Red
        Me.Label25.Location = New System.Drawing.Point(101, 116)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(14, 13)
        Me.Label25.TabIndex = 100046
        Me.Label25.Text = "*"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.BackColor = System.Drawing.Color.Transparent
        Me.Label26.ForeColor = System.Drawing.Color.Red
        Me.Label26.Location = New System.Drawing.Point(382, 198)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(14, 13)
        Me.Label26.TabIndex = 100047
        Me.Label26.Text = "*"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.BackColor = System.Drawing.Color.Transparent
        Me.Label27.ForeColor = System.Drawing.Color.Red
        Me.Label27.Location = New System.Drawing.Point(382, 223)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(14, 13)
        Me.Label27.TabIndex = 100048
        Me.Label27.Text = "*"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.BackColor = System.Drawing.Color.Transparent
        Me.Label28.ForeColor = System.Drawing.Color.Red
        Me.Label28.Location = New System.Drawing.Point(382, 252)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(14, 13)
        Me.Label28.TabIndex = 100049
        Me.Label28.Text = "*"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.BackColor = System.Drawing.Color.Transparent
        Me.Label29.ForeColor = System.Drawing.Color.Red
        Me.Label29.Location = New System.Drawing.Point(382, 277)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(14, 13)
        Me.Label29.TabIndex = 100050
        Me.Label29.Text = "*"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.BackColor = System.Drawing.Color.Transparent
        Me.Label30.ForeColor = System.Drawing.Color.Red
        Me.Label30.Location = New System.Drawing.Point(382, 374)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(14, 13)
        Me.Label30.TabIndex = 100051
        Me.Label30.Text = "*"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.BackColor = System.Drawing.Color.Transparent
        Me.Label31.ForeColor = System.Drawing.Color.Red
        Me.Label31.Location = New System.Drawing.Point(382, 399)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(14, 13)
        Me.Label31.TabIndex = 100052
        Me.Label31.Text = "*"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.BackColor = System.Drawing.Color.Transparent
        Me.Label33.ForeColor = System.Drawing.Color.Red
        Me.Label33.Location = New System.Drawing.Point(101, 376)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(14, 13)
        Me.Label33.TabIndex = 100053
        Me.Label33.Text = "*"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.BackColor = System.Drawing.Color.Transparent
        Me.Label34.ForeColor = System.Drawing.Color.Red
        Me.Label34.Location = New System.Drawing.Point(101, 400)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(14, 13)
        Me.Label34.TabIndex = 100054
        Me.Label34.Text = "*"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.BackColor = System.Drawing.Color.Transparent
        Me.Label35.ForeColor = System.Drawing.Color.Red
        Me.Label35.Location = New System.Drawing.Point(101, 223)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(14, 13)
        Me.Label35.TabIndex = 100055
        Me.Label35.Text = "*"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.BackColor = System.Drawing.Color.Transparent
        Me.Label36.ForeColor = System.Drawing.Color.Red
        Me.Label36.Location = New System.Drawing.Point(101, 250)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(14, 13)
        Me.Label36.TabIndex = 100056
        Me.Label36.Text = "*"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.BackColor = System.Drawing.Color.Transparent
        Me.Label37.ForeColor = System.Drawing.Color.Red
        Me.Label37.Location = New System.Drawing.Point(101, 277)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(14, 13)
        Me.Label37.TabIndex = 100057
        Me.Label37.Text = "*"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.BackColor = System.Drawing.Color.Transparent
        Me.Label38.ForeColor = System.Drawing.Color.Red
        Me.Label38.Location = New System.Drawing.Point(101, 196)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(14, 13)
        Me.Label38.TabIndex = 100058
        Me.Label38.Text = "*"
        '
        'Btn_New
        '
        Me.Btn_New.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_New.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Add_3
        Me.Btn_New.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_New.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_New.ForeColor = System.Drawing.Color.White
        Me.Btn_New.Location = New System.Drawing.Point(310, 223)
        Me.Btn_New.Name = "Btn_New"
        Me.Btn_New.Size = New System.Drawing.Size(27, 21)
        Me.Btn_New.TabIndex = 100059
        Me.Btn_New.TabStop = False
        Me.Btn_New.UseVisualStyleBackColor = False
        Me.Btn_New.Visible = False
        '
        'Insuarance_Master_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Highlight
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(576, 520)
        Me.Controls.Add(Me.Btn_New)
        Me.Controls.Add(Me.Label38)
        Me.Controls.Add(Me.Label37)
        Me.Controls.Add(Me.Label36)
        Me.Controls.Add(Me.Label35)
        Me.Controls.Add(Me.Label34)
        Me.Controls.Add(Me.Label33)
        Me.Controls.Add(Me.Label31)
        Me.Controls.Add(Me.Label30)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label32)
        Me.Controls.Add(Me.Txt_Remarks)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Txt_Company_Fax)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Txt_Contact_Person_Fax)
        Me.Controls.Add(Me.Txt_Company_Web)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Cmb_Active)
        Me.Controls.Add(Me.Txt_Contact_Person_Email)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Txt_Contact_Person_Mobile)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Txt_Contact_Person_Phone)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Txt_Contact_Person_Address)
        Me.Controls.Add(Me.Txt_Contact_Person_Name)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Btn_Tab2)
        Me.Controls.Add(Me.Dtp_Company_RegDt)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Txt_Zip)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Txt_Company_Email)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Txt_Company_Mob)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Txt_Company_Phone)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.cmb_State)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Txt_City)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Cmb_Country)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Txt_Company_Address)
        Me.Controls.Add(Me.Pnl_Tran_mode)
        Me.Controls.Add(Me.Btn_FindID)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.Txt_Company_Name)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Txt_InsComp_ID)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Insuarance_Master_Frm"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.Pnl_Tran_mode.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Txt_InsComp_ID As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Txt_Company_Name As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Delete As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Btn_FindID As System.Windows.Forms.Button
    Friend WithEvents Dtp_Company_RegDt As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Txt_Zip As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Txt_Company_Email As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Txt_Company_Mob As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Txt_Company_Phone As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents cmb_State As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Txt_City As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Country As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Txt_Company_Address As System.Windows.Forms.TextBox
    Friend WithEvents Btn_Tab2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Txt_Contact_Person_Email As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Txt_Contact_Person_Mobile As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Txt_Contact_Person_Phone As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Txt_Contact_Person_Address As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Contact_Person_Name As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label


    Friend WithEvents Cmb_Active As System.Windows.Forms.ComboBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Txt_Company_Web As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Txt_Contact_Person_Fax As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Company_Fax As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Txt_Remarks As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Btn_New As System.Windows.Forms.Button
End Class
