﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Generaldata_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Generaldata_Frm))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Pnl_Header = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.DGvw_Gendatacategory = New System.Windows.Forms.DataGridView()
        Me.DGvw_Gendata = New System.Windows.Forms.DataGridView()
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel()
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label()
        Me.Txt_Datadescription = New System.Windows.Forms.TextBox()
        Me.Txt_DataID = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel()
        Me.Btn_Clear = New System.Windows.Forms.Button()
        Me.Btn_Close = New System.Windows.Forms.Button()
        Me.Btn_Save = New System.Windows.Forms.Button()
        Me.Cmb_Parentdata = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Cmb_Status = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Cmb_Locked = New System.Windows.Forms.ComboBox()
        Me.Btn_Movedown = New System.Windows.Forms.Button()
        Me.Btn_Moveup = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Lbl_Seldatacategory = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Lst_Gendata = New System.Windows.Forms.ListBox()
        Me.Btn_Removeitem = New System.Windows.Forms.Button()
        Me.Btn_Saveorder = New System.Windows.Forms.Button()
        Me.Pnl_Header.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DGvw_Gendatacategory, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DGvw_Gendata, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Pnl_Tran_mode.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.Controls.Add(Me.Label1)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(805, 24)
        Me.Pnl_Header.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(7, 1)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(254, 18)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "G e n e r a l    D a t a   S e t t i n g s"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Left
        Me.PictureBox1.Location = New System.Drawing.Point(0, 24)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(72, 523)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox1.TabIndex = 45
        Me.PictureBox1.TabStop = False
        '
        'DGvw_Gendatacategory
        '
        Me.DGvw_Gendatacategory.AllowUserToAddRows = False
        Me.DGvw_Gendatacategory.AllowUserToDeleteRows = False
        Me.DGvw_Gendatacategory.AllowUserToOrderColumns = True
        Me.DGvw_Gendatacategory.AllowUserToResizeColumns = False
        Me.DGvw_Gendatacategory.AllowUserToResizeRows = False
        Me.DGvw_Gendatacategory.BackgroundColor = System.Drawing.Color.SteelBlue
        Me.DGvw_Gendatacategory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGvw_Gendatacategory.ColumnHeadersVisible = False
        Me.DGvw_Gendatacategory.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.DGvw_Gendatacategory.GridColor = System.Drawing.Color.Silver
        Me.DGvw_Gendatacategory.Location = New System.Drawing.Point(75, 51)
        Me.DGvw_Gendatacategory.MultiSelect = False
        Me.DGvw_Gendatacategory.Name = "DGvw_Gendatacategory"
        Me.DGvw_Gendatacategory.RowHeadersVisible = False
        Me.DGvw_Gendatacategory.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.DGvw_Gendatacategory.RowsDefaultCellStyle = DataGridViewCellStyle1
        Me.DGvw_Gendatacategory.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.DGvw_Gendatacategory.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DGvw_Gendatacategory.Size = New System.Drawing.Size(265, 476)
        Me.DGvw_Gendatacategory.StandardTab = True
        Me.DGvw_Gendatacategory.TabIndex = 0
        '
        'DGvw_Gendata
        '
        Me.DGvw_Gendata.BackgroundColor = System.Drawing.Color.SlateGray
        Me.DGvw_Gendata.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGvw_Gendata.Location = New System.Drawing.Point(374, 76)
        Me.DGvw_Gendata.Name = "DGvw_Gendata"
        Me.DGvw_Gendata.Size = New System.Drawing.Size(334, 219)
        Me.DGvw_Gendata.TabIndex = 47
        Me.DGvw_Gendata.TabStop = False
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(685, 344)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(86, 22)
        Me.Pnl_Tran_mode.TabIndex = 49
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(2, 1)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(79, 16)
        Me.Lbl_Tran_Mode.TabIndex = 0
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Txt_Datadescription
        '
        Me.Txt_Datadescription.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Datadescription.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Datadescription.Location = New System.Drawing.Point(419, 373)
        Me.Txt_Datadescription.Name = "Txt_Datadescription"
        Me.Txt_Datadescription.Size = New System.Drawing.Size(353, 21)
        Me.Txt_Datadescription.TabIndex = 7
        '
        'Txt_DataID
        '
        Me.Txt_DataID.BackColor = System.Drawing.Color.White
        Me.Txt_DataID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_DataID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_DataID.Location = New System.Drawing.Point(420, 345)
        Me.Txt_DataID.Name = "Txt_DataID"
        Me.Txt_DataID.Size = New System.Drawing.Size(177, 21)
        Me.Txt_DataID.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.Navy
        Me.Label3.Location = New System.Drawing.Point(344, 376)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(71, 13)
        Me.Label3.TabIndex = 53
        Me.Label3.Text = "Description"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.Color.Navy
        Me.Label4.Location = New System.Drawing.Point(344, 347)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(50, 13)
        Me.Label4.TabIndex = 51
        Me.Label4.Text = "Data ID"
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(420, 491)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(177, 36)
        Me.Pnl_Common_Btn.TabIndex = 54
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(59, 3)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear.TabIndex = 12
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(116, 3)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 13
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(3, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save.TabIndex = 11
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Cmb_Parentdata
        '
        Me.Cmb_Parentdata.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Parentdata.FormattingEnabled = True
        Me.Cmb_Parentdata.Location = New System.Drawing.Point(420, 401)
        Me.Cmb_Parentdata.Name = "Cmb_Parentdata"
        Me.Cmb_Parentdata.Size = New System.Drawing.Size(355, 21)
        Me.Cmb_Parentdata.TabIndex = 8
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.Color.Navy
        Me.Label5.Location = New System.Drawing.Point(345, 405)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(75, 13)
        Me.Label5.TabIndex = 56
        Me.Label5.Text = "Parent Data"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.Color.Navy
        Me.Label6.Location = New System.Drawing.Point(345, 434)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(44, 13)
        Me.Label6.TabIndex = 58
        Me.Label6.Text = "Status"
        '
        'Cmb_Status
        '
        Me.Cmb_Status.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Status.FormattingEnabled = True
        Me.Cmb_Status.Location = New System.Drawing.Point(420, 429)
        Me.Cmb_Status.Name = "Cmb_Status"
        Me.Cmb_Status.Size = New System.Drawing.Size(177, 21)
        Me.Cmb_Status.TabIndex = 9
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.ForeColor = System.Drawing.Color.Navy
        Me.Label7.Location = New System.Drawing.Point(345, 463)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(47, 13)
        Me.Label7.TabIndex = 60
        Me.Label7.Text = "Locked"
        '
        'Cmb_Locked
        '
        Me.Cmb_Locked.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Locked.FormattingEnabled = True
        Me.Cmb_Locked.Location = New System.Drawing.Point(420, 457)
        Me.Cmb_Locked.Name = "Cmb_Locked"
        Me.Cmb_Locked.Size = New System.Drawing.Size(177, 21)
        Me.Cmb_Locked.TabIndex = 10
        '
        'Btn_Movedown
        '
        Me.Btn_Movedown.BackColor = System.Drawing.Color.Transparent
        Me.Btn_Movedown.BackgroundImage = CType(resources.GetObject("Btn_Movedown.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Movedown.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Movedown.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Btn_Movedown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Movedown.Location = New System.Drawing.Point(773, 92)
        Me.Btn_Movedown.Name = "Btn_Movedown"
        Me.Btn_Movedown.Size = New System.Drawing.Size(29, 39)
        Me.Btn_Movedown.TabIndex = 2
        Me.Btn_Movedown.UseVisualStyleBackColor = False
        '
        'Btn_Moveup
        '
        Me.Btn_Moveup.BackColor = System.Drawing.Color.Transparent
        Me.Btn_Moveup.BackgroundImage = CType(resources.GetObject("Btn_Moveup.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Moveup.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Moveup.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Btn_Moveup.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Moveup.Location = New System.Drawing.Point(773, 145)
        Me.Btn_Moveup.Name = "Btn_Moveup"
        Me.Btn_Moveup.Size = New System.Drawing.Size(29, 39)
        Me.Btn_Moveup.TabIndex = 3
        Me.Btn_Moveup.UseVisualStyleBackColor = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Navy
        Me.Label8.Location = New System.Drawing.Point(75, 34)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(144, 14)
        Me.Label8.TabIndex = 63
        Me.Label8.Text = "D a t a   C a t e g o r y"
        '
        'Lbl_Seldatacategory
        '
        Me.Lbl_Seldatacategory.AutoSize = True
        Me.Lbl_Seldatacategory.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Seldatacategory.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Seldatacategory.ForeColor = System.Drawing.Color.Navy
        Me.Lbl_Seldatacategory.Location = New System.Drawing.Point(344, 34)
        Me.Lbl_Seldatacategory.Name = "Lbl_Seldatacategory"
        Me.Lbl_Seldatacategory.Size = New System.Drawing.Size(236, 14)
        Me.Lbl_Seldatacategory.TabIndex = 64
        Me.Lbl_Seldatacategory.Text = "S e l e c t e d   D a t a   C a t e g o r y"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.SlateGray
        Me.Panel1.Controls.Add(Me.Lst_Gendata)
        Me.Panel1.Location = New System.Drawing.Point(346, 51)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(425, 282)
        Me.Panel1.TabIndex = 1
        '
        'Lst_Gendata
        '
        Me.Lst_Gendata.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Lst_Gendata.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lst_Gendata.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Lst_Gendata.FormattingEnabled = True
        Me.Lst_Gendata.ItemHeight = 16
        Me.Lst_Gendata.Location = New System.Drawing.Point(4, 4)
        Me.Lst_Gendata.Name = "Lst_Gendata"
        Me.Lst_Gendata.Size = New System.Drawing.Size(417, 274)
        Me.Lst_Gendata.TabIndex = 1
        '
        'Btn_Removeitem
        '
        Me.Btn_Removeitem.BackColor = System.Drawing.Color.Transparent
        Me.Btn_Removeitem.BackgroundImage = CType(resources.GetObject("Btn_Removeitem.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Removeitem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Removeitem.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Btn_Removeitem.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Removeitem.Location = New System.Drawing.Point(774, 244)
        Me.Btn_Removeitem.Name = "Btn_Removeitem"
        Me.Btn_Removeitem.Size = New System.Drawing.Size(30, 39)
        Me.Btn_Removeitem.TabIndex = 5
        Me.Btn_Removeitem.UseVisualStyleBackColor = False
        '
        'Btn_Saveorder
        '
        Me.Btn_Saveorder.BackColor = System.Drawing.Color.Transparent
        Me.Btn_Saveorder.BackgroundImage = CType(resources.GetObject("Btn_Saveorder.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Saveorder.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Saveorder.FlatAppearance.BorderColor = System.Drawing.Color.White
        Me.Btn_Saveorder.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Saveorder.Location = New System.Drawing.Point(772, 195)
        Me.Btn_Saveorder.Name = "Btn_Saveorder"
        Me.Btn_Saveorder.Size = New System.Drawing.Size(31, 35)
        Me.Btn_Saveorder.TabIndex = 4
        Me.Btn_Saveorder.UseVisualStyleBackColor = False
        '
        'Generaldata_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Highlight
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(805, 547)
        Me.Controls.Add(Me.Btn_Saveorder)
        Me.Controls.Add(Me.Btn_Removeitem)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Lbl_Seldatacategory)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Btn_Moveup)
        Me.Controls.Add(Me.Btn_Movedown)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Cmb_Locked)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Cmb_Status)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Cmb_Parentdata)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.Txt_Datadescription)
        Me.Controls.Add(Me.Txt_DataID)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Pnl_Tran_mode)
        Me.Controls.Add(Me.DGvw_Gendata)
        Me.Controls.Add(Me.DGvw_Gendatacategory)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Generaldata_Frm"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DGvw_Gendatacategory, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DGvw_Gendata, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Pnl_Tran_mode.ResumeLayout(False)
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents DGvw_Gendatacategory As System.Windows.Forms.DataGridView
    Friend WithEvents DGvw_Gendata As System.Windows.Forms.DataGridView
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Txt_Datadescription As System.Windows.Forms.TextBox
    Friend WithEvents Txt_DataID As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Cmb_Parentdata As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Status As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Locked As System.Windows.Forms.ComboBox
    Friend WithEvents Btn_Movedown As System.Windows.Forms.Button
    Friend WithEvents Btn_Moveup As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Seldatacategory As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Lst_Gendata As System.Windows.Forms.ListBox
    Friend WithEvents Btn_Removeitem As System.Windows.Forms.Button
    Friend WithEvents Btn_Saveorder As System.Windows.Forms.Button

End Class
