﻿Imports HMS_BL
Imports HMS_Common.Common_Cls

Public Class Patient_Discharge_Frm

#Region "Declarations"
    'Object of Patient Details Bussiness Layer
    ' Private Doctor_BL As OutPatient_BL_Cls

    Private hms_helper As HMS_Helper = Nothing
    Private mReq_Ctrl As Object = Nothing
    Private mTr_Mode As Long
    Private Com_BL As HMS_Common_BL_Cls
    Private Pat_Discharge_BL As Pateint_Discharge_BL_Cls


    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing

    Dim IntRow As Integer
    Dim IntSelectRow As Integer

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"

                    Me.Txt_PMRID.BackColor = Color.White
                    Me.Txt_PMRID.ReadOnly = False
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_PMRID.ReadOnly = True
                    Me.Txt_PMRID.BackColor = Color.Silver
            End Select
        End Set
    End Property
#End Region

#Region "Method"

    Private Function Locate_PMR_info(ByVal PMR_ID As String, ByVal Br_Code As Integer) As Boolean
        Try


            Dim Dtbl As DataTable = Nothing
            hms_helper = New Hms_Helperimpliments

            '-----------------  Locate Pateint Medical Record Master info   -------------
            If Not hms_helper.Get_PMR_Masterinfo(Dtbl, PMR_ID, Br_Code) Then Return False

            With Dtbl
                Txt_Patient_ID.Text = .Rows(0).Item("Patient ID").ToString
                'Txt_DocID.Text = .Rows(0).Item("Doc_ID").ToString
                'Txt_DocDetails.Text = .Rows(0).Item("DoctorDetails").ToString
            End With

            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Show_Patient_Bills()
        Try
            Com_BL = New HMS_Common_BL_Cls
            Dim Sr_Dtbl As DataTable = Nothing
            'Dim StrQry As String = ""
            'StrQry = "Select PatientTran_BatchID as [Bill No],Tr_Date as [Date],Exp_Name as [Particulars],Tr_Amount as [Amount] from Get_Patient_Transaction_Vw where ACC_ID = '" & Txt_PMRID.Text & "'"

            'If Com_BL.Get_Data(StrQry, Sr_Dtbl) Then
            '    With Dgrd_Patient_Bills
            '        .DataSource = Nothing
            '        .DataSource = Sr_Dtbl

            '        .Refresh()
            '        .Columns(0).AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells
            '        .Columns(1).AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells
            '        .Columns(2).MinimumWidth = 170
            '        .Columns(3).AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells
            '        .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
            '        '.Columns(4).AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells
            '        '.Columns(5).AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells

            '    End With
            'End If


            Pat_Discharge_BL = New Pateint_Discharge_BL_Cls
            If Pat_Discharge_BL.Get_Patient_Tran_Bills(Dtbl, Txt_PMRID.Text, Tran_Date, Branch_Code) > 0 Then
                With Dtbl
                    Dgrd_Patient_Bills.RowCount = .Rows.Count
                    For i = 0 To .Rows.Count - 1
                        Dgrd_Patient_Bills.Rows(i).Cells("Bill_No").Value = .Rows(i).Item("PatientTran_BatchID").ToString
                        Dgrd_Patient_Bills.Rows(i).Cells("Tr_Date").Value = Format(.Rows(i).Item("Tr_Date"), "dd/MM/yyyy")
                        Dgrd_Patient_Bills.Rows(i).Cells("Tran_Amount").Value = .Rows(i).Item("BillAmt").ToString
                    Next
                End With
            End If
            Dim BillAmt As Single
            With Dgrd_Patient_Bills
                For i = 0 To .Rows.Count - 1
                    BillAmt = BillAmt + .Rows(i).Cells("Tran_Amount").Value.ToString.Trim
                Next
            End With
            Lbl_Bill_Amt.Text = Format(BillAmt, "0.00")

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try
    End Sub

    Private Sub Show_Patient_Payments()
        Try
            Com_BL = New HMS_Common_BL_Cls
            Dim Sr_Dtbl As DataTable = Nothing
            Pat_Discharge_BL = New Pateint_Discharge_BL_Cls
            If Pat_Discharge_BL.Get_Patient_Payments(Dtbl, Txt_PMRID.Text, Tran_Date, Branch_Code) > 0 Then
                With Dtbl
                    Dgrd_Patient_Payments.RowCount = .Rows.Count
                    For i = 0 To .Rows.Count - 1
                        Dgrd_Patient_Payments.Rows(i).Cells("V_No").Value = .Rows(i).Item("Voucher_No").ToString
                        Dgrd_Patient_Payments.Rows(i).Cells("Paid_Date").Value = Format(.Rows(i).Item("Voucher_Date"), "dd/MM/yyyy")
                        Dgrd_Patient_Payments.Rows(i).Cells("Pay_Type").Value = .Rows(i).Item("Particulars").ToString
                        Dgrd_Patient_Payments.Rows(i).Cells("Paid_Amount").Value = .Rows(i).Item("Paid_Amt").ToString
                    Next
                End With
            End If
            Dim PaidAmt As Single
            With Dgrd_Patient_Payments
                For i = 0 To .Rows.Count - 1
                    PaidAmt = PaidAmt + .Rows(i).Cells("Paid_Amount").Value.ToString.Trim
                Next
            End With
            Lbl_Paid_Amt.Text = Format(PaidAmt, "0.00")

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try
    End Sub

#End Region

    Private Function Assigntocontrols(ByVal D_Table As DataTable) As Boolean
        Try
            Dr = D_Table.CreateDataReader()
            Dr.Read()
            With Dr
                Txt_Discharge_ID.Text = .Item("Dischg_ID")
            End With
            Tr_Mode = Tran_Mode.Edit_Mode
            Btn_Cancel.Enabled = True
            Btn_Save.Enabled = False
        Catch ex As Exception

        End Try
    End Function
    Private Function Validate_Fields() As Boolean
        Try
            If Txt_PMRID.Text.Trim = "" Then MessageBox.Show("Invalid PMR ID ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_PMRID.Focus() : Exit Function
            Return True
        Catch ex As Exception

        End Try
    End Function


    Private Sub Patient_Discharge_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then Call SendKeyTab()
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Btn_PMRFind_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_PMRFind.Click
        Try
            If Txt_PMRID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "200|50|300|70|"

                Sql = "SELECT [Patient Name], [S.S.No], ([Family Name] + Address + City) as Address, ACC_ID AS [PMR-ID]"
                Sql += "FROM Patient_Account_Vw WHERE ([Account Status] = 'Active')"

                Call ShowSearchengine(Txt_PMRID, Sql, 3, "[Patient Name]", Colwidth, , 0)
            End If
            'Validating Mandatory fields for locating
            If Txt_PMRID.Text.Trim = "" Then
                'MessageBox.Show("Invalid Appointment ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_PMRID.Focus() : Exit Sub
            End If

            If Locate_PMR_info(Txt_PMRID.Text.Trim, Branch_Code) Then
                Call Show_Patient_Bills()
                Call Show_Patient_Payments()
                Lbl_BalText.Visible = True
                Lbl_Balance.Visible = True

                'If Val(Lbl_Bill_Amt.Text) <> Val(Lbl_Paid_Amt.Text) Then
                '    Pnl_Common_Btn.Enabled = False
                'Else
                '    Pnl_Common_Btn.Enabled = True
                'End If

                If Val(Lbl_Bill_Amt.Text) > Val(Lbl_Paid_Amt.Text) Then
                    Lbl_BalText.Text = "Balance Receivable :"
                    Lbl_BalText.Left = 512
                    Lbl_BalText.Top = 466
                    Lbl_Balance.Left = 654
                    Lbl_Balance.Top = 466
                    Lbl_Balance.Text = Format(Val(Lbl_Bill_Amt.Text) - Val(Lbl_Paid_Amt.Text), "0.00")
                Else
                    Lbl_BalText.Text = "Balance Payable :"
                    Lbl_BalText.Left = 146
                    Lbl_BalText.Top = 466
                    Lbl_Balance.Left = 265
                    Lbl_Balance.Top = 466
                    Lbl_Balance.Text = Format(Val(Lbl_Paid_Amt.Text) - Val(Lbl_Bill_Amt.Text), "0.00")
                End If
                'Txt_DocID.Focus() 
            Else
                MessageBox.Show("Invalid PMR ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_PMRID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_PMRID.KeyDown
        If e.KeyCode = Keys.F2 Then
            Call Btn_PMRFind_Click(sender, e)
        End If
    End Sub
    Private Sub Txt_PMRID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_PMRID.Validating
        Try
            If Txt_PMRID.Text.Trim <> "" And Txt_PMRID.Tag <> Txt_PMRID.Text.Trim Then
                If Locate_PMR_info(Txt_PMRID.Text.Trim, Branch_Code) Then
                    e.Cancel = False
                    'Txt_Doctor_ID.Focus()
                Else
                    MessageBox.Show("Invalid Account id", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    e.Cancel = True
                End If
            End If
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Txt_Patient_ID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Patient_ID.TextChanged
        Try
            With Patient_Info1
                .Viewmoreform_Name = "Patient_InfoSheet_Frm"
                .MDIform_Name = Me.MdiParent
                If Txt_Patient_ID.Text.Trim <> "" Then .Patient_ID = Txt_Patient_ID.Text.Trim
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Discharge_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Discharge_Find.Click
        Try
            If Txt_Discharge_ID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "50|50|125|250"

                Sql = "Select Dischg_ID,Date,Name,([Family Name] + Address + City) as Address, ACC_ID AS [PMR-ID] from Discharge_Details_Vw where Cancelled = 'N'"

                Call ShowSearchengine(Txt_Discharge_ID, Sql, 0, "Name", Colwidth, , 0)
            End If
            If Txt_Discharge_ID.Text.Trim = "" Then
                Txt_Discharge_ID.Focus() : Exit Sub
            End If

            If Txt_Discharge_ID.Text.Trim <> "" Then
                If Locate_Discharge_Details(Txt_Discharge_ID.Text.Trim) Then
                    Tr_Mode = Tran_Mode.Edit_Mode
                    Btn_Cancel.Enabled = True
                    Btn_Save.Enabled = False
                    Call Show_Patient_Bills()
                    Call Show_Patient_Payments()

                    If Val(Lbl_Bill_Amt.Text) > Val(Lbl_Paid_Amt.Text) Then
                        Lbl_BalText.Text = "Balance Receivable :"
                        Lbl_BalText.Left = 512
                        Lbl_BalText.Top = 466
                        Lbl_Balance.Left = 654
                        Lbl_Balance.Top = 466
                        Lbl_Balance.Text = Format(Val(Lbl_Bill_Amt.Text) - Val(Lbl_Paid_Amt.Text), "0.00")
                    Else
                        Lbl_BalText.Text = "Balance Payable :"
                        Lbl_BalText.Left = 146
                        Lbl_BalText.Top = 466
                        Lbl_Balance.Left = 265
                        Lbl_Balance.Top = 466
                        Lbl_Balance.Text = Format(Val(Lbl_Paid_Amt.Text) - Val(Lbl_Bill_Amt.Text), "0.00")
                    End If

                Else
                    MessageBox.Show("Invalid or Cancelled Discharge Id", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Btn_Cancel.Enabled = False
                    Tr_Mode = Tran_Mode.New_Mode
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Function Locate_Discharge_Details(ByVal Discharge_ID As Long) As Boolean
        Try
            Pat_Discharge_BL = New Pateint_Discharge_BL_Cls
            Dim Dtbl As DataTable = Nothing
            If Pat_Discharge_BL.Get_Patient_Discharge(Dtbl, Discharge_ID) Then
                With Dtbl
                    Txt_Discharge_ID.Tag = .Rows(0).Item("ACC_ID").ToString
                    Txt_PMRID.Text = .Rows(0).Item("ACC_ID").ToString
                    Txt_Patient_ID.Text = .Rows(0).Item("Patient_ID").ToString

                    Call Show_Patient_Bills()
                    Call Show_Patient_Payments()
                    Return True
                End With
            Else
                Return False
            End If
        Catch ex As Exception

        End Try
    End Function

    Private Sub Clear_Form()
        Try
            Txt_Discharge_ID.Text = ""
            Txt_Discharge_ID.Tag = ""
            Txt_Patient_ID.Text = ""
            Txt_PMRID.Text = ""
            Grid_Bill_Dt.RowCount = 0
            Dgrd_Patient_Bills.RowCount = 0
            Dgrd_Patient_Payments.RowCount = 0
            Txt_Discharge_ID.Focus()

            Lbl_Bill_Amt.Text = "0.00"
            Lbl_Paid_Amt.Text = "0.00"
            Lbl_Balance.Text = "0.00"
            Btn_Save.Enabled = True
            Btn_Cancel.Enabled = False
            Tr_Mode = Tran_Mode.New_Mode
        Catch ex As Exception

        End Try
    End Sub
    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try
            If Not Validate_Fields() Then Exit Sub

            Pat_Discharge_BL = New Pateint_Discharge_BL_Cls
            With Pat_Discharge_BL
                .Dischg_ID = IIf(Tr_Mode <> Tran_Mode.New_Mode, Txt_Discharge_ID.Text.Trim, 0)
                .Dischg_Date = Tran_Date
                .Patient_ID = Trim(Txt_Patient_ID.Text)
                .ACC_ID = Trim(Txt_PMRID.Text)
                .Dischg_Status = 84

                Dtbl = Nothing
                If Pat_Discharge_BL.Save_Patient_Discharge(Dtbl, Tr_Mode, IIf(Tr_Mode <> Tran_Mode.New_Mode, Txt_PMRID.Text.Trim, 0)) Then
                    MessageBox.Show("Patient Discharged Sucessfully", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    ' Call Clear_Form()                    '
                    If Assigntocontrols(Dtbl) Then

                    End If

                    Txt_Discharge_ID.Focus()
                Else
                    MessageBox.Show(" Patient Discharge Failed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If

            End With
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Dgrd_Patient_Bills_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Dgrd_Patient_Bills.DoubleClick
        Try

            Com_BL = New HMS_Common_BL_Cls
            Dim Bill_Dtbl As DataTable = Nothing
            Dim Str_Batch As String
            Str_Batch = Dgrd_Patient_Bills.Rows(Dgrd_Patient_Bills.CurrentRow.Index).Cells("Bill_No").Value.ToString.Trim
            Dim StrQry As String = ""
            StrQry = "Select PatientTran_BatchID as [Bill No],Tr_Date as [Date],Exp_Name as [Particulars],Tr_Amount as [Amount] from Get_Patient_Transaction_Vw where ACC_ID = '" & Txt_PMRID.Text & "' and PatientTran_BatchID = '" & Str_Batch & "'"

            If Com_BL.Get_Data(StrQry, Bill_Dtbl) Then
                With Grid_Bill_Dt
                    .DataSource = Nothing
                    .DataSource = Bill_Dtbl

                    .Refresh()
                    .Columns(0).AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells
                    .Columns(1).AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells
                    .Columns(2).MinimumWidth = 170
                    .Columns(3).AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells
                    .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                    '.Columns(4).AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells
                    '.Columns(5).AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells
                    Pnl_Bill_Dt.Visible = True
                End With
            End If

        Catch ex As Exception

        End Try

    End Sub

    Private Sub Grid_Bill_Dt_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Grid_Bill_Dt.Click
        Pnl_Bill_Dt.Visible = False
    End Sub


    Private Sub Btn_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Cancel.Click
        Try
            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If

            If Txt_Discharge_ID.Text.Trim = "" Then
                MessageBox.Show("Invalid Discharge ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_Discharge_ID.Focus() : Exit Sub
            End If

            'Confirm before delete the record
            'If MessageBox.Show("Are you sure wan't to cancel the discharge", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = Windows.Forms.DialogResult.No Then
            '    Exit Sub
            'End If

            Pat_Discharge_BL = New Pateint_Discharge_BL_Cls
            If MessageBox.Show("Are you sure wan't to Cancel the selected Discharged Details", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                If Pat_Discharge_BL.Cancell_Discharge_Register(Dtbl, Txt_Discharge_ID.Text.Trim, Tran_Date, Format(Now, "MM/dd/yyyy hh:mm:ss tt"), Branch_Code) Then
                    MessageBox.Show("Discharge Details Cancelled successfully", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Call Clear_Form()
                Else
                    MessageBox.Show("You Cannot Cancell this discharge details" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            End If

        Catch ex As Exception
        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Call Clear_Form()
    End Sub
    Private Sub Txt_Discharge_ID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Discharge_ID.KeyDown
        If e.KeyCode = Keys.F2 Then
            Call Btn_Discharge_Find_Click(sender, e)
        End If
    End Sub

    Private Sub Txt_Discharge_ID_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Discharge_ID.KeyPress
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Discharge_ID.Text, Data_Type.Integer_Type, 12))
    End Sub

    Private Sub Txt_Discharge_ID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Discharge_ID.TextChanged

    End Sub

    Private Sub Txt_Discharge_ID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_Discharge_ID.Validating
        Try
            If Txt_Discharge_ID.Text.Trim <> "" And Me.Txt_Discharge_ID.Text.Trim <> Me.Txt_Discharge_ID.Tag Then
                If Locate_Discharge_Details(Txt_Discharge_ID.Text.Trim) Then
                    Btn_Cancel.Enabled = True
                    Txt_PMRID.Focus()
                Else
                    MessageBox.Show("Invalid or Cancelled Discharge Id", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Btn_Cancel.Enabled = False
                    Tr_Mode = Tran_Mode.New_Mode
                    e.Cancel = True
                End If

               
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_PMRID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_PMRID.TextChanged

    End Sub

    Private Sub Txt_PMRID_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_PMRID.KeyPress
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_PMRID.Text, Data_Type.Integer_Type, 12))
    End Sub
End Class