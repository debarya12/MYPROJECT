﻿Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls

Public Class PatientInfo_Short_Frm

#Region "Declarations"
    'Object of Employee Details Bussiness Layer


    Private Patient_BL As PatientInformation_BL_Cls
    Private hms_helper As HMS_Helper = Nothing

    Private mTr_Mode As Tran_Mode

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing
    Private Ctrl_Point As Point
    Private mReq_Ctrl As Object = Nothing

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_Pat_ID.BackColor = Color.White
                    Me.Txt_Pat_Soc_SecNo.BackColor = Color.White
                    Me.Txt_Pat_ID.ReadOnly = False
                    Me.Txt_Pat_Soc_SecNo.ReadOnly = False
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_Pat_ID.BackColor = Color.Silver
                    Me.Txt_Pat_Soc_SecNo.BackColor = Color.Silver
                    Me.Txt_Pat_ID.ReadOnly = True
                    Me.Txt_Pat_Soc_SecNo.ReadOnly = True
            End Select
        End Set
    End Property


#End Region

#Region "Methods"
    'clear controls
    Public Sub Clear_Form()
        Try
            If Cmb_Pat_Country.Items.Count > 0 Then Cmb_Pat_Country.SelectedIndex = 0
            If Cmb_Pat_Gender.Items.Count > 0 Then Cmb_Pat_Gender.SelectedIndex = 0


            Txt_Pat_Soc_SecNo.Text = ""
            Txt_Pat_Add.Text = ""
            Txt_Pat_Age.Text = ""
            Txt_Pat_ID.Text = ""
            Txt_Pat_Mobile1.Text = ""
            Txt_Pat_Name.Text = ""
            Txt_FamilyName.Text = ""
            Txt_Pat_Phone1.Text = ""

            Dtp_LastAdmitDate.Value = Tran_Date
            Dtp_Pat_RegDt.Value = Tran_Date

            Tr_Mode = Tran_Mode.New_Mode
            Btn_Save.Enabled = True
            Btn_Delete.Enabled = False

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    'assigning values to controls
    Private Sub AssignToControl(ByVal dtbl As DataTable)
        Try

            Dim dr As DataTableReader = Nothing
            dr = dtbl.CreateDataReader()
            dr.Read()

            With dr
                Txt_Pat_ID.Text = .Item("Patient_ID").ToString
                Txt_Pat_Name.Text = .Item("Patient_Name").ToString
                Txt_FamilyName.Text = .Item("Patient_FamilyName").ToString
                Txt_Pat_Add.Text = .Item("Patient_Addr").ToString
                Txt_Pat_Soc_SecNo.Text = .Item("Patient_SS_No").ToString
                Txt_Pat_Phone1.Text = .Item("Patient_Phone1").ToString
                Txt_Pat_Mobile1.Text = .Item("Patient_Mobile1").ToString
                Txt_Pat_Age.Text = .Item("Patient_Age").ToString
                Cmb_Pat_Country.SelectedValue = .Item("Patient_Country").ToString
                Cmb_Pat_Gender.Text = IIf(.Item("Patient_Gender").ToString.Trim = "M", "Male", "Female")

                Dtp_LastAdmitDate.Value = .Item("Patient_LastAdmitdate").ToString
                Dtp_Pat_RegDt.Value = .Item("Patient_Regdate").ToString


                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Save.Enabled = True
                Btn_Delete.Enabled = True


            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    'validating fields 
    Private Function Validate_Fields() As Boolean
        Try
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If

            If Tr_Mode <> Tran_Mode.New_Mode Then
                If Txt_Pat_ID.Text.Trim = "" Then MessageBox.Show("Invalid Patient ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Pat_ID.Focus() : Return False
            End If
            'validating all mandatory fields
            If Is_SSnumberneeded And Txt_Pat_Soc_SecNo.Text.Trim = "" Then MessageBox.Show("Invalid Soc Security Number, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Pat_Soc_SecNo.Focus() : Exit Function
            If Txt_Pat_Name.Text.Trim = "" Then MessageBox.Show("Invalid Patient Name, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Pat_Name.Focus() : Exit Function
            If Txt_Pat_Add.Text.Trim = "" Then MessageBox.Show("Invalid Patient Address, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Pat_Add.Focus() : Exit Function
            If Cmb_Pat_Gender.SelectedIndex = 0 Then MessageBox.Show("Invalid Gender selection, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_Pat_Gender.Focus() : Exit Function
            If Txt_Pat_Age.Text.Trim = "" Then MessageBox.Show("Invalid Patient Age, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Pat_Age.Focus() : Exit Function
            If Cmb_Pat_Country.SelectedIndex = 0 Then MessageBox.Show("Invalid Country Selected, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_Pat_Country.Focus() : Exit Function

            If Txt_Pat_Phone1.Text.Trim = "" And Txt_Pat_Mobile1.Text.Trim = "" Then
                MessageBox.Show("Enter Phone Number or Mob number, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Pat_Phone1.Focus() : Exit Function
            End If

            'Checking entered valid phone/mobile/email/age
            If Val(Txt_Pat_Age.Text.Trim) > 250 Then MessageBox.Show("Invalid Patient Age, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Pat_Age.Focus() : Exit Function

            If Txt_Pat_Phone1.Text.Trim <> "" Then
                If Not Phone_Validation(Txt_Pat_Phone1.Text.Trim, True) Then Txt_Pat_Phone1.Focus() : Exit Function
            End If

            If Txt_Pat_Mobile1.Text.Trim <> "" Then
                If Not Mobile_Validation(Txt_Pat_Mobile1.Text.Trim, True) Then Txt_Pat_Mobile1.Focus() : Exit Function
            End If
          
            

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    'Locate values from BL
    Public Function Locate_Values(ByVal Patient_ID As String) As Boolean
        Patient_BL = New PatientInformation_BL_Cls
        Dim dtbl As DataTable = Nothing
        Try
            If Patient_BL.Get_Patient_Info(dtbl, Patient_ID) Then
                Call AssignToControl(dtbl)
                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Delete.Enabled = True
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Function

#End Region
    Public WriteOnly Property Req_Ctrl() As Object
        Set(ByVal Value As Object)
            mReq_Ctrl = Value
        End Set
    End Property
    Private Sub PatientInformation_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then SendKeyTab()
    End Sub

    Private Sub PatientInformation_Frm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        hms_helper = New Hms_Helperimpliments
        Call hms_helper.Fill_GenData(Cmb_Pat_Country, Gendatatype.Country)

        With Cmb_Pat_Gender
            .Items.Add("Select")
            .Items.Add("Male")
            .Items.Add("Female")
        End With

        Dtp_LastAdmitDate.Value = Tran_Date
        Dtp_Pat_RegDt.Value = Tran_Date
        Btn_Delete.Enabled = False

        Txt_Pat_ID.Focus()

        Cmb_Pat_Gender.SelectedIndex = 0
    End Sub

   
    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try


            Patient_BL = New PatientInformation_BL_Cls
            If Not Validate_Fields() Then Exit Sub

            Patient_BL.Patient_ID = Val(Txt_Pat_ID.Text.Trim)
            Patient_BL.Patient_Name = Txt_Pat_Name.Text.Trim
            Patient_BL.Patient_FamilyName = Txt_FamilyName.Text.Trim
            Patient_BL.Patient_Addr = Txt_Pat_Add.Text.Trim
            Patient_BL.Patient_SS_No = Txt_Pat_Soc_SecNo.Text.Trim
            Patient_BL.Patient_Country = Cmb_Pat_Country.SelectedValue
            Patient_BL.Patient_Gender = Strings.Left(Cmb_Pat_Gender.Text.Trim, 1)
            Patient_BL.Patient_Phone1 = Txt_Pat_Phone1.Text.Trim
            Patient_BL.Patient_Mobile1 = Txt_Pat_Mobile1.Text.Trim
            Patient_BL.Patient_Age = Txt_Pat_Age.Text.Trim
            Patient_BL.Patient_Regdate = Dtp_Pat_RegDt.Value
            Patient_BL.Patient_LastAdmitdate = Dtp_LastAdmitDate.Value
           


            If Patient_BL.Save_PatientInfo_Short(Dtbl, Tr_Mode, Val(Txt_Pat_ID.Text.Trim)) Then
                MessageBox.Show("Patient Transaction Details Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Call Clear_Form()
                Call AssignToControl(Dtbl)
                If TypeOf mReq_Ctrl Is TextBox And Txt_Pat_ID.Text.Trim <> "" Then
                    mReq_Ctrl.text = Txt_Pat_ID.Text
                    If mReq_Ctrl.Visible Then mReq_Ctrl.focus()
                    Me.Close()
                End If
                Txt_Pat_Soc_SecNo.Focus()
            Else
                MessageBox.Show("Patient Information Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Call Clear_Form()
        Txt_Pat_ID.Focus()
    End Sub

    Private Sub Txt_Pat_ID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Pat_ID.KeyDown
        If e.KeyCode = Keys.F2 Then Btn_FindID_Click(sender, e)
    End Sub

    Private Sub Txt_Pat_ID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_Pat_ID.Validating
        Try

            If Txt_Pat_ID.Text.Trim <> "" Then
                If Not Locate_Values(Txt_Pat_ID.Text.Trim) Then
                    MessageBox.Show("Invalid Patient ID, Please Check ", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Txt_Pat_ID.Focus()
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub
  
    Private Sub Btn_FindID_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_FindID.Click
        Try
            If Txt_Pat_ID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "10|200|50|"
                Sql = "SELECT    *  FROM    Patient_Info_Short_Vw"
                Call ShowSearchengine(Txt_Pat_ID, Sql, 0, "Name", Colwidth, , 0)
            End If

            If Txt_Pat_ID.Text.Trim = "" Then
                Txt_Pat_ID.Focus() : Exit Sub
            End If

            'Locate Employee details 
            If Not Locate_Values(Txt_Pat_ID.Text.Trim) Then
                MessageBox.Show("Invalid Patient ID, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Txt_Pat_ID.Focus() : Exit Sub
            Else
                Txt_Pat_Name.Focus()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Pat_Phone1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Pat_Phone1.Text, Data_Type.Integer_Type, 12))
    End Sub

    Private Sub Txt_Pat_Mobile1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Pat_Mobile1.Text, Data_Type.Integer_Type, 12))
    End Sub

    Private Sub Txt_Pat_Age_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Pat_Age.Text, Data_Type.Integer_Type, 12))
    End Sub

    Private Sub Txt_Pat_Add_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs)
        If e.KeyCode = Keys.Enter Then Txt_Pat_Add.Select(Len(Txt_Pat_Add.Text), 0)
        If Len(Txt_Pat_Add.Text) > 150 Then Txt_Pat_Add.ScrollBars = ScrollBars.Both Else Txt_Pat_Add.ScrollBars = ScrollBars.None
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

    Private Sub Txt_Pat_Add_KeyDown1(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Pat_Add.KeyDown
        If e.KeyCode = Keys.Enter Then Txt_Pat_Add.Select(Len(Txt_Pat_Add.Text), 0)
        If Len(Txt_Pat_Add.Text) > 150 Then Txt_Pat_Add.ScrollBars = ScrollBars.Both Else Txt_Pat_Add.ScrollBars = ScrollBars.None
    End Sub

    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click
        Try
            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If

            Patient_BL = New PatientInformation_BL_Cls
            Dim dtbl As DataTable = Nothing
            Dim dr As DataTableReader = Nothing
            If Patient_BL.Del_Patient_Info(dtbl, Txt_Pat_ID.Text.Trim) Then
                dr = dtbl.CreateDataReader()
                dr.Read()
                If dr.Item("DelStatus").ToString = True Then
                    MessageBox.Show("Patient Information Deleted", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Call Clear_Form()
                    Txt_Pat_ID.Focus()
                Else
                    MessageBox.Show("You cannot delete this Patient Information" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            Else
                MessageBox.Show("You cannot delete this Patient Information" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Catch ex As Exception

        End Try
    End Sub



    Private Sub Btn_Find2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find2.Click
        Try
            If Txt_Pat_Soc_SecNo.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "10|200|50|"
                Sql = "SELECT     Patient_SS_No, Patient_ID, Name, Address, City, State, Gender, Phone1, Mobile1  FROM         Patient_Info_Short_Vw"
                Call ShowSearchengine(Txt_Pat_Soc_SecNo, Sql, 0, "Name", Colwidth, , 0)
            End If

            If Txt_Pat_Soc_SecNo.Text.Trim = "" Then
                Txt_Pat_Soc_SecNo.Focus() : Exit Sub
            End If

            'Locate Employee details 
            If Not Locate_Values_SSNO(Txt_Pat_Soc_SecNo.Text.Trim) Then
                MessageBox.Show("Invalid Patient Social Seccurity Number, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Txt_Pat_Soc_SecNo.Focus() : Exit Sub
            Else
                Txt_Pat_Name.Focus()
            End If
        Catch ex As Exception

        End Try
    End Sub
    'Locate values from BL
    Public Function Locate_Values_SSNO(ByVal Patient_SS_No As String) As Boolean
        Patient_BL = New PatientInformation_BL_Cls
        Dim dtbl As DataTable = Nothing
        Try
            If Patient_BL.Get_Patient_Info_SSNo(dtbl, Patient_SS_No) Then
                Call AssignToControl(dtbl)
                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Delete.Enabled = True
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Function

    Private Sub Txt_Pat_Soc_SecNo_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Pat_Soc_SecNo.KeyDown
        If e.KeyCode = Keys.F2 Then Btn_Find2_Click(sender, e)
    End Sub

   
    
    Private Sub Txt_Pat_Name_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Pat_Name.TextChanged

    End Sub
End Class