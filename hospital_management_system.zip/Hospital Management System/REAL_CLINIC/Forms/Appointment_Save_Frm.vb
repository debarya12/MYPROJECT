﻿'Developed by   : PRAMODBHASKER
'Date           : 27-10-2010
'Purpose        : Register Appointment

Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls
Public Class Appointment_Save_Frm

#Region "Declarations"
    Private hms_helper As HMS_Helper = Nothing
#End Region

#Region "Methods"

    Public Sub Populate_Visitortype(ByVal Dtbl As DataTable)
        Try
            With Cmb_Visitortype
                .DataSource = Nothing
                .DataSource = Dtbl
                .DisplayMember = "Data_Description"
                .ValueMember = "Data_ID"
                .Refresh()
                If .Items.Count > 0 Then .SelectedIndex = 0
            End With

        Catch ex As Exception

        End Try
    End Sub

    Public Sub Populate_Bookingtype(ByVal Dtbl As DataTable)
        Try
            With Cmb_Apointtype
                .DataSource = Nothing
                .DataSource = Dtbl
                .DisplayMember = "Data_Description"
                .ValueMember = "Data_ID"
                .Refresh()
                If .Items.Count > 0 Then .SelectedIndex = 0
            End With

        Catch ex As Exception

        End Try
    End Sub

    Public Sub Populate_Bookingmode(ByVal Dtbl As DataTable)
        Try
            With Cmb_Bookmode
                .DataSource = Nothing
                .DataSource = Dtbl
                .DisplayMember = "Data_Description"
                .ValueMember = "Data_ID"
                .Refresh()
                If .Items.Count > 0 Then .SelectedIndex = 0
            End With

        Catch ex As Exception

        End Try
    End Sub

    Public Sub Populate_Doctor(ByRef Dtbl As DataTable)
        Try
            With Cmb_Doctor
                .DataSource = Nothing
                .DataSource = Dtbl
                .DisplayMember = "Name"
                .ValueMember = "DoctorID"
                .Refresh()
                If .Items.Count > 0 Then .SelectedIndex = 0
            End With
        Catch ex As Exception

        End Try
    End Sub

    Public Sub Populate_Service(ByVal Dtbl As DataTable)
        Try
            With Cmb_Service
                .DataSource = Nothing
                .DataSource = Dtbl
                .DisplayMember = "Service Name"
                .ValueMember = "Service_ID"
                .Refresh()
                If .Items.Count > 0 Then .SelectedIndex = 0

            End With
        Catch ex As Exception

        End Try
    End Sub

    Public Sub Populate_Nationality(ByVal Dtbl As DataTable)
        Try
            With Cmb_Visitor_nationality
                .DataSource = Nothing
                .DataSource = Dtbl
                .DisplayMember = "Data_Description"
                .ValueMember = "Data_ID"
                .Refresh()
                If .Items.Count > 0 Then .SelectedIndex = 0

            End With
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Populate_Gender()
        Try
            With Cmb_visitor_Gender
                .Items.Add("Male")
                .Items.Add("Female")

                If .Items.Count > 0 Then .SelectedIndex = 0

            End With
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Clear_Empdetails()
        Try
            Txt_EmpID.Text = ""
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Clear_Patientdetails()
        Try
            Txt_PatientID.Text = ""
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Clear_Othervisitordetails()
        Try
            Me.Txt_Visitor_SSNO.Text = ""
            Me.Txt_Visitor_Name.Text = ""
            Me.Txt_Visitor_Addr.Text = ""
            Me.Txt_Visitor_Familyname.Text = ""
            Me.Txt_Visitor_Age.Text = ""
            Me.Txt_Visitor_Phone.Text = ""
            Me.Txt_Visitor_Mobile.Text = ""

        Catch ex As Exception

        End Try
    End Sub

#End Region


    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Try
            Me.Close()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Appointment_Save_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then SendKeyTab()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Appointment_Save_Frm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try

            Call Populate_Gender()

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Cmb_Custtype_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_Visitortype.SelectedIndexChanged
        Try
            'To DO //
            Pnl_Patientdetails.Visible = False
            Pnl_Othersdetails.Visible = False
            Pnl_Empdetails.Visible = False

            Select Case Cmb_Visitortype.SelectedIndex
                Case 1, 2
                    Pnl_Patientdetails.Visible = True
                Case 4, 5, 6
                    Pnl_Empdetails.Visible = True
                Case Else
                    Pnl_Othersdetails.Visible = True
            End Select
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_EmpID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_EmpID.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then
                Call Btn_EmpF2_Click(Nothing, Nothing)
            End If
        Catch ex As Exception

        End Try
    End Sub

    
    Private Sub Txt_EmpID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_EmpID.TextChanged
        Try
            With Employee_Info1
                .Employee_ID = Txt_EmpID.Text.Trim
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_PatientID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_PatientID.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then
                Call Btn_PatientF2_Click(Nothing, Nothing)
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_PatientID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_PatientID.TextChanged
        Try
            With Patient_Info1
                .Patient_ID = Txt_PatientID.Text.Trim
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_EmpID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_EmpID.Validating
        Try
            If Not Employee_Info1.Visible Then Return
            If Not Employee_Info1.Is_Valid Then
                MessageBox.Show("Invalid Employee ID ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_EmpID.Focus()
                e.Cancel = True
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_PatientID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_PatientID.Validating
        Try
            If Not Patient_Info1.Visible Then Return
            If Not Patient_Info1.Is_Valid Then
                MessageBox.Show("Invalid Patient ID ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_PatientID.Focus()
                e.Cancel = True
            End If
        Catch ex As Exception

        End Try
    End Sub


    Private Sub Btn_PatientF2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Btn_PatientF2.Click
        Try
            If Txt_PatientID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "10|200|50|"
                Sql = "SELECT    *  FROM    Patient_Info_Vw"
                Call ShowSearchengine(Txt_PatientID, Sql, 0, "Name", Colwidth, , 0)
            End If

            If Txt_PatientID.Text.Trim = "" Then
                Txt_PatientID.Focus() : Exit Sub
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_EmpF2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_EmpF2.Click
        Try
            If Txt_EmpID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "200|200|50|"
                Sql = "SELECT Name, Address, Phone, Mobile, Email, Status, [Admit Date], [Deactivate Date], Emp_ID From Emp_Details_Vw"
                Call ShowSearchengine(Txt_EmpID, Sql, 8, "Name", Colwidth, , 0)
            End If

            'Validating Mandatory fields for locating
            If Txt_EmpID.Text.Trim = "" Then
                'MessageBox.Show("Invalid Employee ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_EmpID.Focus() : Exit Sub
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Pnl_Patientdetails_VisibleChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Pnl_Patientdetails.VisibleChanged
        Try
            Call Clear_Patientdetails()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Pnl_Empdetails_VisibleChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Pnl_Empdetails.VisibleChanged
        Try
            Call Clear_Empdetails()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Pnl_Othersdetails_VisibleChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Pnl_Othersdetails.VisibleChanged
        Try
            Call Clear_Othervisitordetails()

        Catch ex As Exception

        End Try
    End Sub
End Class