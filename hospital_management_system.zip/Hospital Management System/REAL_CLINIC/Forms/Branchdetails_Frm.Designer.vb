﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Branchdetails_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Branchdetails_Frm))
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel()
        Me.Btn_Clear = New System.Windows.Forms.Button()
        Me.Btn_Close = New System.Windows.Forms.Button()
        Me.Btn_Delete = New System.Windows.Forms.Button()
        Me.Btn_Save = New System.Windows.Forms.Button()
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label()
        Me.Txt_Branchcode = New System.Windows.Forms.TextBox()
        Me.Btn_Find = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel()
        Me.Txt_Fax = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Txt_Branch_Email = New System.Windows.Forms.TextBox()
        Me.Txt_Branch_Phone2 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Txt_Branch_Phone1 = New System.Windows.Forms.TextBox()
        Me.Txt_Branch_Addr = New System.Windows.Forms.TextBox()
        Me.Txt_Branch_Name = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Pnl_Header = New System.Windows.Forms.Panel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Btn_New = New System.Windows.Forms.Button()
        Me.Cmb_Country = New System.Windows.Forms.ComboBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Txt_Defbrcode = New System.Windows.Forms.TextBox()
        Me.Btn_DefbrF2 = New System.Windows.Forms.Button()
        Me.Txt_Defbranch = New System.Windows.Forms.TextBox()
        Me.Lbl_Loaded = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Txt_BrAcchead = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Btn_BrAccheadF2 = New System.Windows.Forms.Button()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.Pnl_Tran_mode.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Pnl_Header.SuspendLayout()
        Me.SuspendLayout()
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Delete)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(381, 422)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(230, 36)
        Me.Pnl_Common_Btn.TabIndex = 14
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(114, 3)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear.TabIndex = 3
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(170, 3)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 4
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Delete
        '
        Me.Btn_Delete.BackgroundImage = CType(resources.GetObject("Btn_Delete.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Delete.Location = New System.Drawing.Point(58, 3)
        Me.Btn_Delete.Name = "Btn_Delete"
        Me.Btn_Delete.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Delete.TabIndex = 2
        Me.Btn_Delete.Text = "Delete"
        Me.Btn_Delete.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(2, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save.TabIndex = 1
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(2, 1)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(68, 16)
        Me.Lbl_Tran_Mode.TabIndex = 0
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Txt_Branchcode
        '
        Me.Txt_Branchcode.BackColor = System.Drawing.Color.White
        Me.Txt_Branchcode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Branchcode.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Branchcode.Location = New System.Drawing.Point(210, 33)
        Me.Txt_Branchcode.Name = "Txt_Branchcode"
        Me.Txt_Branchcode.Size = New System.Drawing.Size(86, 21)
        Me.Txt_Branchcode.TabIndex = 0
        '
        'Btn_Find
        '
        Me.Btn_Find.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find.BackgroundImage = CType(resources.GetObject("Btn_Find.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find.ForeColor = System.Drawing.Color.White
        Me.Btn_Find.Location = New System.Drawing.Point(297, 33)
        Me.Btn_Find.Name = "Btn_Find"
        Me.Btn_Find.Size = New System.Drawing.Size(29, 21)
        Me.Btn_Find.TabIndex = 1
        Me.Btn_Find.TabStop = False
        Me.Btn_Find.Text = "F2"
        Me.Btn_Find.UseVisualStyleBackColor = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(116, 38)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(77, 13)
        Me.Label9.TabIndex = 61
        Me.Label9.Text = "Branch Code"
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(537, 31)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(74, 22)
        Me.Pnl_Tran_mode.TabIndex = 62
        '
        'Txt_Fax
        '
        Me.Txt_Fax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Fax.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Fax.Location = New System.Drawing.Point(210, 218)
        Me.Txt_Fax.Name = "Txt_Fax"
        Me.Txt_Fax.Size = New System.Drawing.Size(194, 21)
        Me.Txt_Fax.TabIndex = 7
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(116, 221)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(27, 13)
        Me.Label2.TabIndex = 56
        Me.Label2.Text = "Fax"
        '
        'Txt_Branch_Email
        '
        Me.Txt_Branch_Email.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Branch_Email.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Branch_Email.Location = New System.Drawing.Point(210, 244)
        Me.Txt_Branch_Email.Name = "Txt_Branch_Email"
        Me.Txt_Branch_Email.Size = New System.Drawing.Size(352, 21)
        Me.Txt_Branch_Email.TabIndex = 8
        '
        'Txt_Branch_Phone2
        '
        Me.Txt_Branch_Phone2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Branch_Phone2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Branch_Phone2.Location = New System.Drawing.Point(210, 192)
        Me.Txt_Branch_Phone2.Name = "Txt_Branch_Phone2"
        Me.Txt_Branch_Phone2.Size = New System.Drawing.Size(194, 21)
        Me.Txt_Branch_Phone2.TabIndex = 6
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(7, 1)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(167, 19)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "B r a n c h  P r o f i l e"
        '
        'Txt_Branch_Phone1
        '
        Me.Txt_Branch_Phone1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Branch_Phone1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Branch_Phone1.Location = New System.Drawing.Point(210, 166)
        Me.Txt_Branch_Phone1.Name = "Txt_Branch_Phone1"
        Me.Txt_Branch_Phone1.Size = New System.Drawing.Size(195, 21)
        Me.Txt_Branch_Phone1.TabIndex = 5
        '
        'Txt_Branch_Addr
        '
        Me.Txt_Branch_Addr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Branch_Addr.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Branch_Addr.HideSelection = False
        Me.Txt_Branch_Addr.Location = New System.Drawing.Point(210, 85)
        Me.Txt_Branch_Addr.Multiline = True
        Me.Txt_Branch_Addr.Name = "Txt_Branch_Addr"
        Me.Txt_Branch_Addr.Size = New System.Drawing.Size(401, 52)
        Me.Txt_Branch_Addr.TabIndex = 3
        '
        'Txt_Branch_Name
        '
        Me.Txt_Branch_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Branch_Name.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Branch_Name.Location = New System.Drawing.Point(210, 59)
        Me.Txt_Branch_Name.Name = "Txt_Branch_Name"
        Me.Txt_Branch_Name.Size = New System.Drawing.Size(401, 21)
        Me.Txt_Branch_Name.TabIndex = 2
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(116, 247)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(37, 13)
        Me.Label7.TabIndex = 54
        Me.Label7.Text = "Email"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(116, 195)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(52, 13)
        Me.Label6.TabIndex = 53
        Me.Label6.Text = "Phone 2"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(116, 169)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(52, 13)
        Me.Label5.TabIndex = 52
        Me.Label5.Text = "Phone 1"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(116, 88)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(53, 13)
        Me.Label4.TabIndex = 51
        Me.Label4.Text = "Address"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(116, 63)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(81, 13)
        Me.Label3.TabIndex = 48
        Me.Label3.Text = "Branch Name"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Left
        Me.PictureBox1.Location = New System.Drawing.Point(0, 24)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(113, 438)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox1.TabIndex = 44
        Me.PictureBox1.TabStop = False
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.Controls.Add(Me.Label1)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(615, 24)
        Me.Pnl_Header.TabIndex = 43
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(117, 143)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(52, 13)
        Me.Label8.TabIndex = 67
        Me.Label8.Text = "Country"
        '
        'Btn_New
        '
        Me.Btn_New.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_New.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Add_3
        Me.Btn_New.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_New.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_New.ForeColor = System.Drawing.Color.White
        Me.Btn_New.Location = New System.Drawing.Point(563, 140)
        Me.Btn_New.Name = "Btn_New"
        Me.Btn_New.Size = New System.Drawing.Size(27, 21)
        Me.Btn_New.TabIndex = 149
        Me.Btn_New.TabStop = False
        Me.Btn_New.UseVisualStyleBackColor = False
        Me.Btn_New.Visible = False
        '
        'Cmb_Country
        '
        Me.Cmb_Country.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Country.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Country.FormattingEnabled = True
        Me.Cmb_Country.Location = New System.Drawing.Point(210, 141)
        Me.Cmb_Country.Name = "Cmb_Country"
        Me.Cmb_Country.Size = New System.Drawing.Size(352, 21)
        Me.Cmb_Country.TabIndex = 148
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.SteelBlue
        Me.Label10.Location = New System.Drawing.Point(211, 271)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(401, 4)
        Me.Label10.TabIndex = 150
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Navy
        Me.Label11.Location = New System.Drawing.Point(209, 328)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(172, 16)
        Me.Label11.TabIndex = 151
        Me.Label11.Text = "Load Default Branch Settings"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.ForeColor = System.Drawing.Color.Black
        Me.Label12.Location = New System.Drawing.Point(117, 353)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(90, 13)
        Me.Label12.TabIndex = 152
        Me.Label12.Text = "Default Branch"
        '
        'Txt_Defbrcode
        '
        Me.Txt_Defbrcode.BackColor = System.Drawing.Color.White
        Me.Txt_Defbrcode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Defbrcode.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Defbrcode.Location = New System.Drawing.Point(210, 348)
        Me.Txt_Defbrcode.Name = "Txt_Defbrcode"
        Me.Txt_Defbrcode.Size = New System.Drawing.Size(86, 21)
        Me.Txt_Defbrcode.TabIndex = 11
        '
        'Btn_DefbrF2
        '
        Me.Btn_DefbrF2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_DefbrF2.BackgroundImage = CType(resources.GetObject("Btn_DefbrF2.BackgroundImage"), System.Drawing.Image)
        Me.Btn_DefbrF2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_DefbrF2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_DefbrF2.ForeColor = System.Drawing.Color.White
        Me.Btn_DefbrF2.Location = New System.Drawing.Point(297, 348)
        Me.Btn_DefbrF2.Name = "Btn_DefbrF2"
        Me.Btn_DefbrF2.Size = New System.Drawing.Size(29, 21)
        Me.Btn_DefbrF2.TabIndex = 12
        Me.Btn_DefbrF2.TabStop = False
        Me.Btn_DefbrF2.Text = "F2"
        Me.Btn_DefbrF2.UseVisualStyleBackColor = False
        '
        'Txt_Defbranch
        '
        Me.Txt_Defbranch.BackColor = System.Drawing.Color.White
        Me.Txt_Defbranch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Defbranch.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Defbranch.HideSelection = False
        Me.Txt_Defbranch.Location = New System.Drawing.Point(210, 371)
        Me.Txt_Defbranch.Multiline = True
        Me.Txt_Defbranch.Name = "Txt_Defbranch"
        Me.Txt_Defbranch.ReadOnly = True
        Me.Txt_Defbranch.Size = New System.Drawing.Size(401, 46)
        Me.Txt_Defbranch.TabIndex = 13
        Me.Txt_Defbranch.TabStop = False
        '
        'Lbl_Loaded
        '
        Me.Lbl_Loaded.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Loaded.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Lbl_Loaded.ForeColor = System.Drawing.Color.Maroon
        Me.Lbl_Loaded.Location = New System.Drawing.Point(440, 349)
        Me.Lbl_Loaded.Name = "Lbl_Loaded"
        Me.Lbl_Loaded.Size = New System.Drawing.Size(123, 19)
        Me.Lbl_Loaded.TabIndex = 153
        Me.Lbl_Loaded.Text = "L   O    A   D   E   D"
        Me.Lbl_Loaded.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Lbl_Loaded.Visible = False
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.Navy
        Me.Label13.Location = New System.Drawing.Point(211, 276)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(129, 16)
        Me.Label13.TabIndex = 154
        Me.Label13.Text = "Branch Account Head"
        '
        'Txt_BrAcchead
        '
        Me.Txt_BrAcchead.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_BrAcchead.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_BrAcchead.Location = New System.Drawing.Point(210, 295)
        Me.Txt_BrAcchead.Name = "Txt_BrAcchead"
        Me.Txt_BrAcchead.Size = New System.Drawing.Size(353, 21)
        Me.Txt_BrAcchead.TabIndex = 9
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.ForeColor = System.Drawing.Color.Black
        Me.Label14.Location = New System.Drawing.Point(116, 299)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(85, 13)
        Me.Label14.TabIndex = 156
        Me.Label14.Text = "Account Head"
        '
        'Label15
        '
        Me.Label15.BackColor = System.Drawing.Color.SteelBlue
        Me.Label15.Location = New System.Drawing.Point(211, 322)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(401, 4)
        Me.Label15.TabIndex = 157
        '
        'Btn_BrAccheadF2
        '
        Me.Btn_BrAccheadF2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_BrAccheadF2.BackgroundImage = CType(resources.GetObject("Btn_BrAccheadF2.BackgroundImage"), System.Drawing.Image)
        Me.Btn_BrAccheadF2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_BrAccheadF2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_BrAccheadF2.ForeColor = System.Drawing.Color.White
        Me.Btn_BrAccheadF2.Location = New System.Drawing.Point(564, 295)
        Me.Btn_BrAccheadF2.Name = "Btn_BrAccheadF2"
        Me.Btn_BrAccheadF2.Size = New System.Drawing.Size(29, 21)
        Me.Btn_BrAccheadF2.TabIndex = 10
        Me.Btn_BrAccheadF2.TabStop = False
        Me.Btn_BrAccheadF2.Text = "F2"
        Me.Btn_BrAccheadF2.UseVisualStyleBackColor = False
        '
        'Branchdetails_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Highlight
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(615, 462)
        Me.Controls.Add(Me.Btn_BrAccheadF2)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Txt_BrAcchead)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Lbl_Loaded)
        Me.Controls.Add(Me.Txt_Defbrcode)
        Me.Controls.Add(Me.Btn_DefbrF2)
        Me.Controls.Add(Me.Txt_Defbranch)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Btn_New)
        Me.Controls.Add(Me.Cmb_Country)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.Txt_Branchcode)
        Me.Controls.Add(Me.Btn_Find)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Pnl_Tran_mode)
        Me.Controls.Add(Me.Txt_Fax)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Txt_Branch_Email)
        Me.Controls.Add(Me.Txt_Branch_Phone2)
        Me.Controls.Add(Me.Txt_Branch_Phone1)
        Me.Controls.Add(Me.Txt_Branch_Addr)
        Me.Controls.Add(Me.Txt_Branch_Name)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Branchdetails_Frm"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.Pnl_Tran_mode.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Delete As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Txt_Branchcode As System.Windows.Forms.TextBox
    Friend WithEvents Btn_Find As System.Windows.Forms.Button
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Txt_Fax As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Txt_Branch_Email As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Branch_Phone2 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Txt_Branch_Phone1 As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Branch_Addr As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Branch_Name As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Btn_New As System.Windows.Forms.Button
    Friend WithEvents Cmb_Country As System.Windows.Forms.ComboBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Txt_Defbrcode As System.Windows.Forms.TextBox
    Friend WithEvents Btn_DefbrF2 As System.Windows.Forms.Button
    Friend WithEvents Txt_Defbranch As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_Loaded As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Txt_BrAcchead As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Btn_BrAccheadF2 As System.Windows.Forms.Button
End Class
