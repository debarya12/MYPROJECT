﻿Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls

Public Class Patient_Uttility_Frm

#Region "Declarations"
    'Object of Employee Details Bussiness Layer


    Private Patient_BL As PatientInformation_BL_Cls
    Private Pat_caserec_BL As Patient_CaseRecord_BL_Cls
    Private Pat_Diagno_BL As Patient_Diagnosis_BL_Cls
    Private Pat_MedicalRecord_BL As Patient_MedicalRecord_BL_Cls

    Private hms_helper As HMS_Helper = Nothing

    Private mTr_Mode As Tran_Mode

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing
   

#End Region

#Region "Methods"

    Private Function Fill_PatientInfo(ByVal PMR_ID As String) As Boolean
        Try
            Return Locate_Patient(PMR_ID)

        Catch ex As Exception

        End Try

    End Function

    Private Function Fill_History(ByVal Patient_ID As String) As Boolean
        Try

        Catch ex As Exception

        End Try

    End Function

    Private Function Fill_CaseRecords(ByVal Patient_ID As String) As Boolean
        Try

            Pat_caserec_BL = New Patient_CaseRecord_BL_Cls
            If Pat_caserec_BL.Get_Patient_Latest_CaseRecord(Dtbl, Txt_PMRID.Text, Branch_Code) Then
                Txt_DcotorName.Text = "Doctor : " + Dtbl.Rows(0).Item("Doctor").ToString
                Txt_Heading.Text = Dtbl.Rows(0).Item("Cr_Header").ToString
                Txt_Bodytext.Text = Dtbl.Rows(0).Item("Cr_Body").ToString
                Txt_FooterText.Text = Dtbl.Rows(0).Item("Cr_Footer").ToString
                Btn_CRvw.Enabled = True
                Return True
            Else
                Btn_CRvw.Enabled = False
                Return False
            End If

        Catch ex As Exception
            Btn_CRvw.Enabled = False
            Return False
        End Try

    End Function

    Private Function Fill_Insurance(ByVal Patient_ID As String) As Boolean
        Try



        Catch ex As Exception

        End Try

    End Function

    Private Function Fill_CurrentStatus(ByVal Patient_ID As String) As Boolean
        Try



        Catch ex As Exception

        End Try

    End Function

    Private Function Fill_Diagnosis(ByVal PMR_ID As String) As Boolean
        Try


        Catch ex As Exception

        End Try

    End Function

    Private Function Fill_Patient_Diagnosis(ByVal Acc_Id As String) As Boolean
        Try
            Pat_Diagno_BL = New Patient_Diagnosis_BL_Cls
            'If Pat_Diagno_BL.Get_Patient_Diagnosis_Detail(Dtbl, Acc_Id, Branch_Code) > 0 Then
            Txt_Diagnosis.Text = ""
            Txt_Diag_Comment.Text = ""
            Txt_Diag_Status.Text = ""
            If Pat_Diagno_BL.Get_Patient_Latest_Diagnosis(Dtbl, Acc_Id, Tran_Date, Branch_Code) > 0 Then
                With Dtbl
                    
                    If IsDBNull(.Rows(0).Item("Diagnosis").ToString) = False Then Txt_Diagnosis.Text = .Rows(0).Item("Diagnosis").ToString
                    If IsDBNull(.Rows(0).Item("Comments").ToString) = False Then Txt_Diag_Comment.Text = .Rows(0).Item("Comments").ToString
                    If IsDBNull(.Rows(0).Item("Status").ToString) = False Then Txt_Diag_Status.Text = .Rows(0).Item("Status").ToString
                    Btn_DiagnoVw.Enabled = True
                    Return True
                End With
            Else
                Btn_DiagnoVw.Enabled = False
                Return False
            End If
        Catch ex As Exception
            Btn_DiagnoVw.Enabled = False
        End Try
    End Function

    Private Function Fill_Patient_MedicalRecord(ByVal Acc_Id As String) As Boolean
        Try
            Pat_MedicalRecord_BL = New Patient_MedicalRecord_BL_Cls
            'If Pat_Diagno_BL.Get_Patient_Diagnosis_Detail(Dtbl, Acc_Id, Branch_Code) > 0 Then
            Txt_Weight.Text = ""
            Txt_Temprature.Text = ""
            Txt_Height.Text = ""
            Txt_Respiration.Text = ""
            Txt_BPDiastolic.Text = ""
            Txt_BPSystolic.Text = ""

            If Pat_MedicalRecord_BL.Get_Patient_Latest_MedicalRecord(Dtbl, Acc_Id, Tran_Date, Branch_Code) > 0 Then
                With Dtbl

                    Txt_Weight.Text = .Rows(0).Item("P_Weight").ToString() + "-" + .Rows(0).Item("P_Weightin").ToString()
                    Txt_Height.Text = .Rows(0).Item("P_Height").ToString() + "-" + .Rows(0).Item("P_Heightin").ToString()
                    Txt_Temprature.Text = .Rows(0).Item("P_Temperature").ToString() + "-" + .Rows(0).Item("P_Temperaturein").ToString()
                    Txt_Respiration.Text = .Rows(0).Item("P_Respiration").ToString()
                    Txt_BPDiastolic.Text = .Rows(0).Item("P_BP_Diastolic").ToString()
                    Txt_BPSystolic.Text = .Rows(0).Item("P_BP_Systolic").ToString()
                    Txt_Pulse.Text = .Rows(0).Item("P_Respiration").ToString()
                    Txt_Complaints.Text = .Rows(0).Item("P_Complaints").ToString()
                    Txt_Testconducted.Text = .Rows(0).Item("P_Testconducted").ToString()
                    Txt_Respiration.Text = .Rows(0).Item("P_Respiration").ToString()
                    Txt_Results.Text = .Rows(0).Item("P_Results").ToString()
                    Btn_MRvw.Enabled = True
                    Return True
                End With
            Else
                Btn_DiagnoVw.Enabled = False
                Return False
            End If
        Catch ex As Exception
            Btn_DiagnoVw.Enabled = False
        End Try
    End Function

    Private Function Fill_Accounts(ByVal Patient_ID As String) As Boolean
        Try


            hms_helper = New Hms_Helperimpliments
            Dim dtbl As DataTable = Nothing

            If hms_helper.Get_Patient_CreditPosition(dtbl, Txt_PMRID.Text, _
                                                      Tran_Date, _
                                                     Branch_Code) Then

                Txt_AdvanceDeposit.Text = dtbl.Rows(0).Item("Deposit").ToString
                Txt_Dedeucted_Amount.Text = dtbl.Rows(0).Item("Paid_Bills").ToString
                Txt_Bill_Due.Text = dtbl.Rows(0).Item("UnPaid_Bills").ToString
                Txt_Balance_Deposit.Text = dtbl.Rows(0).Item("Balance").ToString
                Txt_AdvanceDeposit.Text = dtbl.Rows(0).Item("Deposit").ToString

                Txt_Cash_Transaction.Text = dtbl.Rows(0).Item("Cash_Transaction").ToString
                Txt_Transfer.Text = dtbl.Rows(0).Item("Transffer_Transaction").ToString

                dtbl = Nothing

                Return True
            Else
                Return False
            End If



        Catch ex As Exception

        End Try

    End Function

    Public Function Locate_Patient(ByVal PMR_ID As String) As Boolean
        Try
            Dim dtbl As DataTable = Nothing
            Dim dr As DataTableReader = Nothing
            hms_helper = New Hms_Helperimpliments
            Txt_PMRID.Tag = ""
            If hms_helper.Get_Patient_Account_Details(dtbl, PMR_ID) Then
                'If hms_helper.Get_Patient_Info(dtbl, Patient_ID) Then
                dr = dtbl.CreateDataReader
                dr.Read()
                With dr
                    Txt_Visitor_SSNO.Text = dr.Item("S.S.No").ToString
                    Txt_Visitor_Name.Text = dr.Item("Patient Name").ToString
                    Txt_Visitor_Addr.Text = dr.Item("Address").ToString
                    Txt_Visitor_Familyname.Text = dr.Item("Family Name").ToString
                    Txt_Gender.Text = dr.Item("Gender").ToString
                    Txt_Visitor_Age.Text = dr.Item("Age").ToString
                    Txt_Visitor_Phone.Text = dr.Item("Phone1").ToString
                    Txt_Visitor_Mobile.Text = dr.Item("Mobile1").ToString
                    Txt_Nationality.Text = dr.Item("Country Name").ToString

                End With
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function

#End Region

    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try


            If Txt_PMRID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "10|200|50|"

                Sql = "SELECT  [Patient Name],ACC_ID,[Reg Date],[S.S.No],[Family Name],[Address],[City] from Patient_Account_Vw "
                Sql = Sql + "Where Active = 'Y' and Cancelled = 'N' and Br_Code = '" & Branch_Code & "'"
                'Sql = Sql + "Where Active = 'Y' or Active = 'N' and Cancelled = 'N' and (Deactivate_Date >= '" & Format(Tran_Date, "MM/dd/yyyy") & "') and Br_Code = '" & Branch_Code & "'"
                Call ShowSearchengine(Txt_PMRID, Sql, 1, "Patient Name", Colwidth, , 0)

            End If

            If Txt_PMRID.Text.Trim = "" Then
                Txt_PMRID.Focus() : Exit Sub
            End If

            'Locate Patient details 
            If Not Fill_PatientInfo(Txt_PMRID.Text.Trim) Then
                Exit Sub
            End If

            hms_helper = New Hms_Helperimpliments
            Dim dtbl As DataTable = Nothing
            If hms_helper.Get_OutPatient_ID_Latest(dtbl, Txt_PMRID.Text, Tran_Date, Branch_Code) Then
                Txt_OPD_ID.Text = dtbl.Rows(0).Item(0).ToString
            End If

            dtbl = Nothing

            Fill_CaseRecords(Txt_PMRID.Text)
            Fill_Accounts(Txt_PMRID.Text)
            Fill_Patient_Diagnosis(Txt_PMRID.Text)
            Fill_Patient_MedicalRecord(Trim(Txt_PMRID.Text))
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_viewmore_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_viewmore.Click
        Try
            With PatientInformation_Frm
                .Txt_Pat_Soc_SecNo.Text = Txt_Visitor_SSNO.Text
                .Btn_Find2_Click(sender, e)
                .MdiParent = Me.MdiParent
                .Show()
            End With
        Catch ex As Exception

        End Try

    End Sub

    Private Sub TextBox5_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Cash_Transaction.TextChanged
        Try
            Txt_Total.Text = Val(Txt_Transfer.Text) + Val(Txt_Cash_Transaction.Text)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Transfer_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Transfer.TextChanged
        Try
            Txt_Total.Text = Val(Txt_Transfer.Text) + Val(Txt_Cash_Transaction.Text)
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Patient_Uttility_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.F2 Then
            Call Btn_Find_Click(sender, e)
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try
            With MedicalRecord_Frm
                .Txt_PMRID.Text = Trim(Txt_PMRID.Text)
                .MdiParent = Me.MdiParent
                .Btn_PMRFind_Click(Nothing, Nothing)
                .Show()
            End With
        Catch ex As Exception

        End Try
    End Sub
   
    Private Sub Btn_MRvw_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_MRvw.Click
        Try
            With MedicalRecord_Frm
                .Txt_PMRID.Text = Txt_PMRID.Text
                .Btn_PMRFind_Click(Nothing, Nothing)
                .Show()
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_DiagnoVw_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_DiagnoVw.Click
        Try
            With Patient_Diagnosis_Frm
                .TXT_Acc_ID.Text = Txt_PMRID.Text
                .MdiParent = Me.MdiParent
                .Btn_Find_Account_Click(Nothing, Nothing)
                .Show()
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_CRvw_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_CRvw.Click
        Try
            With Dr_Recomendations_Frm
                .Txt_PatientID.Text = Txt_PMRID.Text
                .MdiParent = Me.MdiParent
                .Show()
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try

            Txt_AdvanceDeposit.Text = ""
            Txt_Balance_Deposit.Text = ""
            Txt_Visitor_Name.Text = ""
            Txt_Bill_Due.Text = ""
            Txt_Bloodclass.Text = ""
            Txt_Bodytext.Text = ""
            Txt_BPDiastolic.Text = ""
            Txt_BPSystolic.Text = ""
            Txt_Cash_Transaction.Text = ""
            Txt_Complaints.Text = ""
            Txt_DcotorName.Text = ""
            Txt_Dedeucted_Amount.Text = ""
            Txt_Diag_Comment.Text = ""
            Txt_Diag_Status.Text = ""
            Txt_Diagnosis.Text = ""
            Txt_FooterText.Text = ""
            Txt_Gender.Text = ""
            Txt_Height.Text = ""
            Txt_Nationality.Text = ""
            Txt_OPD_ID.Text = ""
            Txt_PMRID.Text = ""
            Txt_Pulse.Text = ""
            Txt_Respiration.Text = ""
            Txt_Results.Text = ""
            Txt_Temprature.Text = ""
            Txt_Testconducted.Text = ""
            Txt_Total.Text = ""
            Txt_Transfer.Text = ""
            Txt_Visitor_Addr.Text = ""
            Txt_Visitor_Age.Text = ""
            Txt_Visitor_Familyname.Text = ""
            Txt_Visitor_Mobile.Text = ""
            Txt_Visitor_Phone.Text = ""
            Txt_Visitor_SSNO.Text = ""
            Txt_Weight.Text = ""
            Txt_PMRID.Focus()
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub
End Class

