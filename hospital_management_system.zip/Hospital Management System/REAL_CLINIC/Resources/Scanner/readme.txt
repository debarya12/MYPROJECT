Kodak Image Scan Installer for Windows XP

To Install and register Kodak Image Scanning please click the 'install.bat' file