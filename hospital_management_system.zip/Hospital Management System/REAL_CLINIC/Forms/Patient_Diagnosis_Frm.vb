﻿Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls
Public Class Patient_Diagnosis_Frm

#Region "Declarations"
    'Object of Patient Details Bussiness Layer
    ' Private Doctor_BL As OutPatient_BL_Cls

    Private hms_helper As HMS_Helper = Nothing
    Private Pat_Presc_BL As Patient_Prescription_BL_Cls
    Private prec_Template As Prescription_Template_BL_Cls
    Private Pat_Diagno_BL As Patient_Diagnosis_BL_Cls
    Private mReq_Ctrl As Object = Nothing
    Private mTr_Mode As Long
    Private Form_Closing As Boolean


    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing

    Dim IntRow As Integer
    Dim IntSelectRow As Integer

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"

                    Me.TXT_Acc_ID.BackColor = Color.White
                    Me.TXT_Acc_ID.ReadOnly = False
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.TXT_Acc_ID.ReadOnly = True
                    Me.TXT_Acc_ID.BackColor = Color.Silver
            End Select
        End Set
    End Property
#End Region

#Region "Methods"

    Private Function Get_Doctordetails(ByVal Doc_ID As String) As Boolean
        Try
            Lbl_Doctordetails.Text = String.Empty

            Dim Dtbl As New DataTable
            If hms_helper.Get_Doctordetails(Dtbl, Doc_ID) Then
                Txt_Doctor_ID.Tag = Doc_ID
                Lbl_Doctordetails.Text = Dtbl.Rows(0).Item("Name").ToString.ToUpper
                Lbl_Doctordetails.Text += vbCrLf + Dtbl.Rows(0).Item("Qualification").ToString
                Return True
            Else
                Return False
            End If
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Clear_Form()
        Try

            TXT_Acc_ID.Text = ""
            TXT_Acc_ID.Tag = ""
            Txt_Doctor_ID.Tag = ""
            Txt_Doctor_ID.Text = ""
            TXT_OP_ID.Text = ""
            Txt_Patient_ID.Text = ""
            Txt_Comments.Text = ""
            Txt_Current_Stat.Text = ""
            Btn_Add.Tag = "A"
            Tr_Mode = Tran_Mode.New_Mode
            Dgv_Diagnosis.RowCount = 0
            Btn_Delete.Enabled = False


        Catch ex As Exception

        End Try
    End Sub

    Private Function Validate_Fields() As Boolean
        Try
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If


            If TXT_Acc_ID.Text.Trim = "" Then MessageBox.Show("Invalid PMR ID ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : TXT_Acc_ID.Focus() : Exit Function
            If Txt_Patient_ID.Text.Trim = "" Then MessageBox.Show("Invalid Patient ID ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Patient_ID.Focus() : Exit Function
            If TXT_OP_ID.Text.Trim = "" Then MessageBox.Show("Invalid OP ID ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : TXT_OP_ID.Focus() : Exit Function
            If Cmb_Diagnose.SelectedIndex <= 0 Then MessageBox.Show("Invalid Diagnosis Selection  ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_Diagnose.Focus() : Exit Function
            If Txt_Doctor_ID.Text = "" Then MessageBox.Show("Invalid Doctor  ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Doctor_ID.Focus() : Exit Function
            Return True
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function

    Private Function Fill_Patient_Diagnosis(ByVal Acc_Id As String) As Boolean
        Try
            Pat_Diagno_BL = New Patient_Diagnosis_BL_Cls
            If Pat_Diagno_BL.Get_Patient_Diagnosis_Detail(Dtbl, Acc_Id, Branch_Code) > 0 Then

                Dr = Dtbl.CreateDataReader()
                Dr.Read()

                Cmb_Diagnose.SelectedValue = Dtbl.Rows(0).Item("Dig_ID").ToString
                Txt_Doctor_ID.Text = Dtbl.Rows(0).Item("Dig_Doc_ID").ToString
                'Exit Function
                With Dtbl
                    Dgv_Diagnosis.RowCount = .Rows.Count
                    For i = 0 To .Rows.Count - 1
                        Dgv_Diagnosis.Rows(i).Cells("Diagnosis").Value = .Rows(i).Item("Diagnosis").ToString
                        Dgv_Diagnosis.Rows(i).Cells("DiagnosisID").Value = .Rows(i).Item("Dig_ID").ToString
                        Dgv_Diagnosis.Rows(i).Cells("Comments").Value = .Rows(i).Item("Comments").ToString
                        Dgv_Diagnosis.Rows(i).Cells("Status").Value = .Rows(i).Item("Status").ToString
                        Dgv_Diagnosis.Rows(i).Cells("DoctorID").Value = .Rows(i).Item("Dig_Doc_ID").ToString
                        Dgv_Diagnosis.Rows(i).Cells("Doctor").Value = .Rows(i).Item("Doctor").ToString
                        Dgv_Diagnosis.Rows(i).Cells("TR_DT").Value = Format(.Rows(i).Item("Tr_Date"), "dd/MM/yyyy")
                        Dgv_Diagnosis.Rows(i).Cells("DiagID").Value = .Rows(i).Item("Dig_Number").ToString

                        If .Rows(i).Item("Active").ToString = "Y" Then
                            Dgv_Diagnosis.Rows(i).Cells("Active").Value = 1
                        Else
                            Dgv_Diagnosis.Rows(i).Cells("Active").Value = 0
                            Dgv_Diagnosis.Rows(i).Cells("De_Active_Date").Value = Format(.Rows(i).Item("De_Active_Date"), "dd/MM/yyyy")
                        End If
                    Next
                    Btn_Delete.Enabled = True
                End With
                Tr_Mode = Tran_Mode.Edit_Mode
                Return True
            Else
                Tr_Mode = Tran_Mode.New_Mode
                Dgv_Diagnosis.RowCount = 0
                Return False
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function

    Public Function Fill_Acc_Details(ByVal Acc_ID As String) As Boolean
        Try
            Dim dtbl As DataTable = Nothing
            Dim dr As DataTableReader = Nothing

            hms_helper = New Hms_Helperimpliments
            Txt_Patient_ID.Tag = ""
            If hms_helper.Get_Patient_Account_Details(dtbl, Acc_ID) Then
                dr = dtbl.CreateDataReader
                dr.Read()
                With dr
                    Txt_Patient_ID.Text = dr.Item("Patient ID").ToString
                    TXT_OP_ID.Text = dr.Item("OP ID").ToString


                    If hms_helper.Get_OP_Details(dtbl, TXT_OP_ID.Text.Trim) Then
                        dr = dtbl.CreateDataReader
                        dr.Read()
                        With dr
                            Txt_Doctor_ID.Text = dr.Item("Doc_ID").ToString
                        End With

                    End If
                End With
                If Fill_Patient_Diagnosis(Acc_ID) Then

                End If
                Return True

            Else
                Dgv_Diagnosis.RowCount = 0
                Return False
            End If

        Catch ex As Exception
            Return False
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Function

    Private Sub Clear_Prescription_Details()
        Try
            Txt_Comments.Text = ""
            Txt_Current_Stat.Text = ""
            Btn_Add.Text = "Add"
            Btn_Add.Tag = "A" 'Add
            IntSelectRow = -1
            Dgv_Diagnosis.ClearSelection()
            Cmb_Active.SelectedIndex = 0
            Cmb_Diagnose.Focus()
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Function Validate_Grid() As Boolean
        Try
            If TXT_Acc_ID.Text.Trim = "" Then
                MessageBox.Show("Invalid PMR_ID ,Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : TXT_Acc_ID.Focus() : Return False : Exit Function
            End If
            With Dgv_Diagnosis
                For i = 0 To .Rows.Count - 1
                    'If .Rows(i).Cells("TempId").Value.ToString.Trim = "" Then
                    If Btn_Add.Tag = "A" Then
                        If Txt_Comments.Text.Trim = .Rows(i).Cells("Comments").Value.ToString.Trim Then
                            MessageBox.Show("Comments Already Enterd, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Comments.Focus() : Return False : Exit Function
                        End If
                    End If
                Next
            End With
            If Cmb_Diagnose.SelectedIndex <= 0 Then MessageBox.Show("Invalid Diagnosis Selection , Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_Diagnose.Focus() : Return False : Exit Function
            If Txt_Doctor_ID.Text = "" Then MessageBox.Show("Invalid Doctor , Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Doctor_ID.Focus() : Return False : Exit Function
            If Txt_Comments.Text.Trim = "" Then MessageBox.Show("Invalid Comments , Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Comments.Focus() : Return False : Exit Function
            If Txt_Current_Stat.Text.Trim = "" Then MessageBox.Show("Enter Current Status, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Current_Stat.Focus() : Return False : Exit Function

            Return True
        Catch ex As Exception
        End Try
    End Function

    Private Sub Mark_RightHorizontal(ByVal Markrowindex As Integer, ByVal Mark As Boolean)
        Try
            With Dgv_Diagnosis
                .Rows(Markrowindex).Cells("Active").Value = Mark
            End With
        Catch ex As Exception

        End Try
    End Sub

#End Region

    Public WriteOnly Property Req_Ctrl() As Object
        Set(ByVal Value As Object)
            mReq_Ctrl = Value
        End Set
    End Property

    Private Sub Patient_Diagnosis_Frm_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Try
            If Dgv_Diagnosis.Rows.Count <> 0 Then
                If Form_Closing = False Then
                    MessageBox.Show("Please, Save the records before closing", Product_Name, MessageBoxButtons.OK)
                    e.Cancel = True
                End If
            End If
            If TypeOf mReq_Ctrl Is TextBox And TXT_Acc_ID.Text.Trim <> "" Then
                mReq_Ctrl.text = TXT_Acc_ID.Text
                If mReq_Ctrl.Visible Then mReq_Ctrl.focus()
                Me.Close()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Patient_Prescription_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then Call SendKeyTab()
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Patient_Prescription_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        Try
            If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Patient_Diagnosis_Frm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            hms_helper = New Hms_Helperimpliments
            'hms_helper.Fill_Doctors(Cmb_Doctor)
            'Fill Diagnose
            hms_helper.Fill_Diagnosis(Cmb_Diagnose, " <  S E L E C T  > ")
            Cmb_Active.SelectedIndex = 0
            Dtp_TranDate.Value = Tran_Date
            Btn_Add.Tag = "A"
            Btn_Delete.Enabled = False
            Form_Closing = True
        Catch ex As Exception
        End Try
       
    End Sub

    Private Sub Txt_Patient_ID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Patient_ID.TextChanged
        Try
            With Patient_Info1
                .Viewmoreform_Name = "Patient_InfoSheet_Frm"
                .MDIform_Name = Me.MdiParent
                If Txt_Patient_ID.Text.Trim <> "" Then .Patient_ID = Txt_Patient_ID.Text.Trim
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Add_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Add.Click
        Try

            If Not Validate_Grid() Then Exit Sub
            Form_Closing = False
            If Btn_Add.Tag = "A" Then
                With Dgv_Diagnosis
                    .Rows.Add()
                    .Rows(.Rows.Count - 1).Cells("Comments").Value = Txt_Comments.Text.Trim
                    .Rows(.Rows.Count - 1).Cells("Status").Value = Txt_Current_Stat.Text.Trim
                    .Rows(.Rows.Count - 1).Cells("DiagID").Value = "x"
                    .Rows(.Rows.Count - 1).Cells("DiagnosisID").Value = Cmb_Diagnose.SelectedValue
                    .Rows(.Rows.Count - 1).Cells("Diagnosis").Value = Cmb_Diagnose.Text
                    .Rows(.Rows.Count - 1).Cells("Doctor").Value = Lbl_Doctordetails.Text
                    .Rows(.Rows.Count - 1).Cells("DoctorID").Value = Txt_Doctor_ID.Text
                    .Rows(.Rows.Count - 1).Cells("TR_DT").Value = Dtp_TranDate.Value
                    If Cmb_Active.SelectedIndex = 0 Then
                        .Rows(.Rows.Count - 1).Cells("Active").Value = 1
                        .Rows(.Rows.Count - 1).Cells("De_Active_Date").Value = ""
                    Else
                        .Rows(.Rows.Count - 1).Cells("Active").Value = 0
                        .Rows(.Rows.Count - 1).Cells("De_Active_Date").Value = Format(Dtp_TranDate.Value, "dd/MM/yyyy")
                    End If


                    Call Clear_Prescription_Details()
                End With
            ElseIf Btn_Add.Tag = "M" Then
                With Dgv_Diagnosis
                    If IntSelectRow >= 0 Then
                        .Rows(IntSelectRow).Cells("Comments").Value = Txt_Comments.Text.Trim
                        .Rows(IntSelectRow).Cells("Status").Value = Txt_Current_Stat.Text.Trim
                        .Rows(IntSelectRow).Cells("Diagnosis").Value = Cmb_Diagnose.Text
                        .Rows(IntSelectRow).Cells("Doctor").Value = Lbl_Doctordetails.Text
                        .Rows(IntSelectRow).Cells("DoctorID").Value = Txt_Doctor_ID.Text
                        .Rows(IntSelectRow).Cells("DiagnosisID").Value = Cmb_Diagnose.SelectedValue
                        If Cmb_Active.SelectedIndex = 0 Then
                            .Rows(IntSelectRow).Cells("Active").Value = 1
                            .Rows(IntSelectRow).Cells("De_Active_Date").Value = ""
                        Else
                            .Rows(IntSelectRow).Cells("Active").Value = 0
                            .Rows(IntSelectRow).Cells("De_Active_Date").Value = Format(Dtp_TranDate.Value, "dd/MM/yyyy")
                        End If
                    Else
                        .Rows.Add()
                        .Rows(.Rows.Count - 1).Cells("Comments").Value = Txt_Comments.Text.Trim
                        .Rows(.Rows.Count - 1).Cells("Status").Value = Txt_Current_Stat.Text.Trim
                        .Rows(.Rows.Count - 1).Cells("DiagID").Value = "x"
                        .Rows(.Rows.Count - 1).Cells("DiagnosisID").Value = Cmb_Diagnose.SelectedValue
                        .Rows(.Rows.Count - 1).Cells("Diagnosis").Value = Cmb_Diagnose.Text
                        .Rows(.Rows.Count - 1).Cells("Doctor").Value = Lbl_Doctordetails.Text
                        .Rows(.Rows.Count - 1).Cells("DoctorID").Value = Txt_Doctor_ID.Text
                        .Rows(.Rows.Count - 1).Cells("TR_DT").Value = Dtp_TranDate.Value
                        If Cmb_Active.SelectedIndex = 0 Then
                            .Rows(.Rows.Count - 1).Cells("Active").Value = 1
                            .Rows(.Rows.Count - 1).Cells("De_Active_Date").Value = ""
                        Else
                            .Rows(.Rows.Count - 1).Cells("Active").Value = 0
                            .Rows(.Rows.Count - 1).Cells("De_Active_Date").Value = Format(Dtp_TranDate.Value, "dd/MM/yyyy")
                        End If

                    End If
                End With
                Call Clear_Prescription_Details()
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try
    End Sub

    Private Sub Btn_Remove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Remove.Click
        Try
            If Dgv_Diagnosis.RowCount > 0 Then
                If MessageBox.Show("Are you sure wan't to remove the selected record ", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                    Dgv_Diagnosis.Rows.RemoveAt(Dgv_Diagnosis.CurrentRow.Index)
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try

            If Not Validate_Fields() Then Exit Sub


            If Dgv_Diagnosis.RowCount = 0 Then
                MessageBox.Show("Please Enter Diagnosis Details", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Txt_Comments.Focus()
                Exit Sub
            End If
            Call Pat_Diagno_BL.Delete_Patient_Diagnosis(TXT_Acc_ID.Text.Trim, Branch_Code)

            Dim Dtbl As DataTable = Nothing
            Pat_Diagno_BL = New Patient_Diagnosis_BL_Cls
            Dim Int_Diagnosis_ID As Long

            With Dgv_Diagnosis
                For i = 0 To .Rows.Count - 1
                    Pat_Diagno_BL.ACC_ID = TXT_Acc_ID.Text.Trim
                    Pat_Diagno_BL.Tr_Date = .Rows(i).Cells("TR_DT").Value.ToString.Trim
                    Pat_Diagno_BL.Patient_ID = Txt_Patient_ID.Text.Trim
                    Pat_Diagno_BL.OPD_ID = TXT_OP_ID.Text.Trim
                    Pat_Diagno_BL.Dig_ID = .Rows(i).Cells("DiagnosisID").Value.ToString.Trim()
                    Pat_Diagno_BL.Dig_Doc_ID = .Rows(i).Cells("DoctorID").Value.ToString.Trim()
                    Pat_Diagno_BL.Dig_Comments = .Rows(i).Cells("Comments").Value.ToString.Trim()
                    Pat_Diagno_BL.Dig_Currentstatus = .Rows(i).Cells("Status").Value.ToString.Trim()

                    'If Format(Dtp_TranDate.Value, "dd-MM-yyyy") = .Rows(i).Cells("TR_DT").Value Then

                    If .Rows(i).Cells("Active").Value = 1 Then
                        Pat_Diagno_BL.Active = "Y"
                        'Pat_Diagno_BL.Deactivate_Date = ""
                    Else
                        Pat_Diagno_BL.Active = "N"
                        Pat_Diagno_BL.Deactivate_Date = Format(Dtp_TranDate.Value, "dd/MM/yyyy")
                    End If

                    'If .Rows(i).Cells("DiagID").Value.ToString.Trim() = "x" Then
                    '    Int_Diagnosis_ID = 0
                    '    Tr_Mode = Tran_Mode.New_Mode
                    'Else
                    '    Int_Diagnosis_ID = (.Rows(i).Cells("DiagID").Value.ToString.Trim())
                    '    Tr_Mode = Tran_Mode.Edit_Mode
                    'End If
                    Tr_Mode = Tran_Mode.New_Mode

                    Pat_Diagno_BL.Save_Patient_Diagnosis(Dtbl, Int_Diagnosis_ID, Tr_Mode)

                Next
            End With
            Dtbl = Nothing
            Form_Closing = True
            MessageBox.Show("Patient diagnosis Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Btn_Clear_Click(sender, e)

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Call Clear_Form()
        TXT_Acc_ID.Focus()
    End Sub

    Private Sub Btn_FindDr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_FindDr.Click
        Try
            If Txt_Doctor_ID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "150|75|75|100|125|"
                Sql = "SELECT  Name,Qualification,Category,Designation,Address,[Email-ID],[Phone 1],[Phone 2],[Mobile 1],[Mobile 2],DoctorID FROM Doctormaster_Vw where  Br_Code = '" & Branch_Code & "'"
                Call ShowSearchengine(Txt_Doctor_ID, Sql, 10, "Name", Colwidth, , 0)
            End If

            If Txt_Doctor_ID.Text.Trim = "" Then
                Txt_Doctor_ID.Focus() : Exit Sub
            End If
            If Get_Doctordetails(Txt_Doctor_ID.Text.Trim) Then
                Cmb_Diagnose.Focus()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click
        Try
            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If


            If MessageBox.Show("Are you sure wan't to delete the patient diagnosis details", Product_Name, MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                If Pat_Diagno_BL.Delete_Patient_Diagnosis(TXT_Acc_ID.Text.Trim, Branch_Code) Then 'Delete_OutPatient(Txt_OutPatientID.Text.Trim) Then
                    MessageBox.Show("Deleted patient diagnosis successfully", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Call Clear_Form()
                Else
                    MessageBox.Show("You cannot delete patient diagnosis" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Dgv_Diagnosis_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles Dgv_Diagnosis.CellMouseClick
        Try
            If e.RowIndex = -1 Then Exit Sub
            If e.ColumnIndex <> 3 Then Exit Sub

            Call Mark_RightHorizontal(e.RowIndex, Not Dgv_Diagnosis.Rows(e.RowIndex).Cells("Active").Value)

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Dgv_Diagnosis_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Dgv_Diagnosis.DoubleClick
        Try
            With Dgv_Diagnosis
                If .Rows.Count > 0 Then
                    IntSelectRow = .CurrentRow.Index
                    Txt_Comments.Text = .Rows(.CurrentRow.Index).Cells("Comments").Value.ToString.Trim
                    Txt_Current_Stat.Text = .Rows(.CurrentRow.Index).Cells("Status").Value.ToString.Trim
                    Cmb_Diagnose.SelectedValue = .Rows(.CurrentRow.Index).Cells("DiagnosisID").Value '.ToString.Trim
                    Txt_Doctor_ID.Text = .Rows(.CurrentRow.Index).Cells("DoctorID").Value.ToString.Trim
                    Btn_Add.Text = "Save"
                    Btn_Add.Tag = "M"
                    Cmb_Diagnose.Focus()
                    Dgv_Diagnosis.ClearSelection()
                End If
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_Comments_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Txt_Comments.GotFocus
        Txt_Comments.SelectionStart = Len(Txt_Comments.Text)
    End Sub

    Private Sub TXT_OP_ID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TXT_OP_ID.KeyDown
        If e.KeyCode = Keys.Enter Then
            SendKeyTab()
            Exit Sub
        End If
    End Sub

    Private Sub Txt_Current_Stat_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Txt_Current_Stat.GotFocus
        Txt_Current_Stat.SelectionStart = Len(Txt_Current_Stat.Text)
    End Sub

    Private Sub TXT_Acc_ID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TXT_Acc_ID.KeyDown
        If e.KeyCode = Keys.F2 Then
            Call Btn_Find_Account_Click(sender, e)
        End If
    End Sub

    Private Sub TXT_Acc_ID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles TXT_Acc_ID.Validating
        Try

            If TXT_Acc_ID.Text.Trim <> "" And TXT_Acc_ID.Tag <> TXT_Acc_ID.Text.Trim Then
                If Fill_Acc_Details(TXT_Acc_ID.Text.Trim) Then
                    e.Cancel = False
                    Txt_Doctor_ID.Focus()
                Else
                    MessageBox.Show("Invalid PMR-ID", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    e.Cancel = True
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Public Sub Btn_Find_Account_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find_Account.Click
        Try
            If TXT_Acc_ID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "150|125|300|50"

                Sql = "SELECT [Patient Name], [S.S.No], ([Family Name] + Address + City) as Address, ACC_ID AS [PMR-ID]"
                Sql += "FROM Patient_Account_Vw WHERE ([Account Status] = 'Active')And Br_Code='" & Branch_Code & "'"

                'Sql = Sql + "Where Active = 'Y' or Active='N' and Cancelled = 'N' and (Deactivate_Date >= '" & Format(Tran_Date, "MM/dd/yyyy") & "')and Br_Code = '" & Branch_Code & "'"
                Call ShowSearchengine(TXT_Acc_ID, Sql, 3, "[Patient Name]", Colwidth, , 0)
            End If

            If TXT_Acc_ID.Text.Trim = "" Then
                TXT_Acc_ID.Focus() : Exit Sub
            End If

            'Locate patient details 
            If Fill_Acc_Details(TXT_Acc_ID.Text.Trim) Then
                If Tr_Mode = Tran_Mode.New_Mode Then
                    Txt_Doctor_ID.Focus()
                    Exit Sub
                Else
                    TXT_Acc_ID.Focus()
                    Exit Sub
                End If
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try
            If TXT_Acc_ID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "150|125|30|50|100|150"

                Sql = "SELECT  Name, ACC_ID, [Patient ID], [S.S.No], Family, Address FROM Distinct_Patient_Diagnosis_Vw WHERE Acc_Status = 54"

                Call ShowSearchengine(TXT_Acc_ID, Sql, 1, "Name", Colwidth, , 0)
            End If

            'If TXT_Acc_ID.Text.Trim = "" Then
            '    TXT_Acc_ID.Focus() : Exit Sub
            'End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_Doctor_ID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Doctor_ID.KeyDown
        If e.KeyCode = Keys.F2 Then
            Call Btn_FindDr_Click(sender, e)
        End If
    End Sub

    Private Sub Txt_Doctor_ID_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Doctor_ID.KeyPress
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Doctor_ID.Text, Data_Type.Integer_Type, 12))
    End Sub

    Private Sub Txt_Doctor_ID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Doctor_ID.TextChanged
        Try
            Txt_Doctor_ID.Tag = ""
            If Txt_Doctor_ID.Text.Trim = "" Then
                Lbl_Doctordetails.Text = ""
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_Doctor_ID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_Doctor_ID.Validating
        Try
            If Txt_Doctor_ID.Text.Trim <> "" And Txt_Doctor_ID.Tag <> Txt_Doctor_ID.Text.Trim Then
                If Get_Doctordetails(Txt_Doctor_ID.Text.Trim) Then
                    e.Cancel = False
                    Txt_Doctor_ID.Focus()
                Else
                    MessageBox.Show("Invalid Doctor id", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    e.Cancel = True
                End If
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    
    Private Sub Dgv_Diagnosis_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgv_Diagnosis.CellContentClick

    End Sub
End Class