﻿Imports HMS_Common.Common_Cls
Imports CrystalDecisions.Shared
Imports CrystalDecisions.CrystalReports.Engine

Public Class Reportviewer_Frm

    Public MDI_Form As Form

    Private _Show_Mode As Report_Showmode = Report_Showmode.Fulloption
    Public Property Show_Mode() As Report_Showmode
        Get
            Return _Show_Mode
        End Get
        Set(ByVal value As Report_Showmode)
            _Show_Mode = value
        End Set
    End Property

    Private _RptFrm_Width As Long = 1024
    Public Property RptFrm_Width() As Long
        Get
            Return _RptFrm_Width
        End Get
        Set(ByVal value As Long)
            _RptFrm_Width = value
        End Set
    End Property

    Private _RptFrm_Height As Long = 764
    Public Property RptFrm_Height() As Long
        Get
            Return _RptFrm_Height
        End Get
        Set(ByVal value As Long)
            _RptFrm_Height = value
        End Set
    End Property


    Public Sub Set_Showmode()
        Try
            If Me.Show_Mode = Report_Showmode.Condensedmode Then
                With Me
                    With .CrystalReportViewer1
                        .DisplayBackgroundEdge = False
                        .DisplayGroupTree = False
                        .DisplayStatusBar = False
                        .DisplayToolbar = False

                    End With
                    .WindowState = FormWindowState.Normal
                    .Pnl_Print.Visible = True

                End With
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Reportviewer_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Try
            If Me.Pnl_Print.Visible And e.KeyCode = Keys.F5 Then
                Call Btn_Print_Click(Nothing, Nothing)
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Reportviewer_Frm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            Call Set_Showmode()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Print_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Print.Click
        Try
            ' You can change more print options via PrintOptions property of ReportDocument
            Dim report As New ReportDocument()
            report = Me.CrystalReportViewer1.ReportSource
            report.PrintToPrinter(1, True, 0, 0)
            report.Close()



        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class