﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Appointment_Save_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Appointment_Save_Frm))
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.Cmb_Visitortype = New System.Windows.Forms.ComboBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.Pnl_Othersdetails = New System.Windows.Forms.Panel
        Me.Txt_Visitor_Familyname = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Txt_Visitor_SSNO = New System.Windows.Forms.TextBox
        Me.Label35 = New System.Windows.Forms.Label
        Me.Cmb_Visitor_nationality = New System.Windows.Forms.ComboBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Txt_Visitor_Age = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Cmb_visitor_Gender = New System.Windows.Forms.ComboBox
        Me.Txt_Visitor_Mobile = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.Txt_Visitor_Phone = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Txt_Visitor_Addr = New System.Windows.Forms.TextBox
        Me.Txt_Visitor_Name = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Pnl_Patientdetails = New System.Windows.Forms.Panel
        Me.Btn_PatientF2 = New System.Windows.Forms.Button
        Me.Txt_PatientID = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.Pnl_Empdetails = New System.Windows.Forms.Panel
        Me.Btn_EmpF2 = New System.Windows.Forms.Button
        Me.Txt_EmpID = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.Pnl_Booking = New System.Windows.Forms.Panel
        Me.Cmb_Bookmode = New System.Windows.Forms.ComboBox
        Me.Cmb_Service = New System.Windows.Forms.ComboBox
        Me.Label22 = New System.Windows.Forms.Label
        Me.Cmb_Apointtype = New System.Windows.Forms.ComboBox
        Me.Label21 = New System.Windows.Forms.Label
        Me.Cmb_Doctor = New System.Windows.Forms.ComboBox
        Me.Label18 = New System.Windows.Forms.Label
        Me.Dtp_Apointdate = New System.Windows.Forms.DateTimePicker
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Cmb_Timeto = New System.Windows.Forms.ComboBox
        Me.Cmb_Timefrom = New System.Windows.Forms.ComboBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Patient_Info1 = New TECHNO_CLINIC.Patient_Info
        Me.Employee_Info1 = New TECHNO_CLINIC.Employee_Info
        Me.Pnl_Header.SuspendLayout()
        Me.Pnl_Othersdetails.SuspendLayout()
        Me.Pnl_Patientdetails.SuspendLayout()
        Me.Pnl_Empdetails.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.Pnl_Booking.SuspendLayout()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = Global.TECHNO_CLINIC.My.Resources.Resources.Menu_Bkg
        Me.Pnl_Header.Controls.Add(Me.Label1)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(455, 24)
        Me.Pnl_Header.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(7, 1)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(173, 18)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "A P P O I N T M E N T S"
        '
        'Cmb_Visitortype
        '
        Me.Cmb_Visitortype.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.Cmb_Visitortype.CausesValidation = False
        Me.Cmb_Visitortype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Visitortype.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_Visitortype.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Visitortype.FormattingEnabled = True
        Me.Cmb_Visitortype.ItemHeight = 13
        Me.Cmb_Visitortype.Location = New System.Drawing.Point(99, 30)
        Me.Cmb_Visitortype.Name = "Cmb_Visitortype"
        Me.Cmb_Visitortype.Size = New System.Drawing.Size(318, 21)
        Me.Cmb_Visitortype.TabIndex = 0
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.ForeColor = System.Drawing.Color.Black
        Me.Label19.Location = New System.Drawing.Point(4, 33)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(62, 13)
        Me.Label19.TabIndex = 104
        Me.Label19.Text = "Visitor Type"
        '
        'Pnl_Othersdetails
        '
        Me.Pnl_Othersdetails.BackColor = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(233, Byte), Integer), CType(CType(243, Byte), Integer))
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_Familyname)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label6)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_SSNO)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label35)
        Me.Pnl_Othersdetails.Controls.Add(Me.Cmb_Visitor_nationality)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label5)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_Age)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label15)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label13)
        Me.Pnl_Othersdetails.Controls.Add(Me.Cmb_visitor_Gender)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_Mobile)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label11)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_Phone)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label8)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label4)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_Addr)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_Name)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label2)
        Me.Pnl_Othersdetails.Location = New System.Drawing.Point(0, 63)
        Me.Pnl_Othersdetails.Name = "Pnl_Othersdetails"
        Me.Pnl_Othersdetails.Size = New System.Drawing.Size(456, 232)
        Me.Pnl_Othersdetails.TabIndex = 1
        Me.Pnl_Othersdetails.Visible = False
        '
        'Txt_Visitor_Familyname
        '
        Me.Txt_Visitor_Familyname.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.Txt_Visitor_Familyname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Familyname.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Familyname.Location = New System.Drawing.Point(99, 130)
        Me.Txt_Visitor_Familyname.MaxLength = 250
        Me.Txt_Visitor_Familyname.Name = "Txt_Visitor_Familyname"
        Me.Txt_Visitor_Familyname.Size = New System.Drawing.Size(353, 21)
        Me.Txt_Visitor_Familyname.TabIndex = 4
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(2, 134)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(67, 13)
        Me.Label6.TabIndex = 100044
        Me.Label6.Text = "Family Name"
        '
        'Txt_Visitor_SSNO
        '
        Me.Txt_Visitor_SSNO.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.Txt_Visitor_SSNO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_SSNO.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_SSNO.Location = New System.Drawing.Point(99, 4)
        Me.Txt_Visitor_SSNO.MaxLength = 50
        Me.Txt_Visitor_SSNO.Name = "Txt_Visitor_SSNO"
        Me.Txt_Visitor_SSNO.Size = New System.Drawing.Size(153, 21)
        Me.Txt_Visitor_SSNO.TabIndex = 1
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.BackColor = System.Drawing.Color.Transparent
        Me.Label35.ForeColor = System.Drawing.Color.Black
        Me.Label35.Location = New System.Drawing.Point(2, 6)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(65, 13)
        Me.Label35.TabIndex = 100042
        Me.Label35.Text = "Soc Sec No"
        '
        'Cmb_Visitor_nationality
        '
        Me.Cmb_Visitor_nationality.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.Cmb_Visitor_nationality.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Visitor_nationality.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_Visitor_nationality.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Visitor_nationality.FormattingEnabled = True
        Me.Cmb_Visitor_nationality.Location = New System.Drawing.Point(99, 204)
        Me.Cmb_Visitor_nationality.Name = "Cmb_Visitor_nationality"
        Me.Cmb_Visitor_nationality.Size = New System.Drawing.Size(353, 21)
        Me.Cmb_Visitor_nationality.TabIndex = 9
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label5.Location = New System.Drawing.Point(2, 208)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(58, 13)
        Me.Label5.TabIndex = 100041
        Me.Label5.Text = "Nationality"
        '
        'Txt_Visitor_Age
        '
        Me.Txt_Visitor_Age.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.Txt_Visitor_Age.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Age.Cursor = System.Windows.Forms.Cursors.Default
        Me.Txt_Visitor_Age.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Age.Location = New System.Drawing.Point(297, 155)
        Me.Txt_Visitor_Age.MaxLength = 3
        Me.Txt_Visitor_Age.Name = "Txt_Visitor_Age"
        Me.Txt_Visitor_Age.Size = New System.Drawing.Size(64, 21)
        Me.Txt_Visitor_Age.TabIndex = 6
        Me.Txt_Visitor_Age.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label15.Location = New System.Drawing.Point(258, 158)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(26, 13)
        Me.Label15.TabIndex = 100040
        Me.Label15.Text = "Age"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.ForeColor = System.Drawing.Color.Black
        Me.Label13.Location = New System.Drawing.Point(2, 159)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(42, 13)
        Me.Label13.TabIndex = 100039
        Me.Label13.Text = "Gender"
        '
        'Cmb_visitor_Gender
        '
        Me.Cmb_visitor_Gender.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.Cmb_visitor_Gender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_visitor_Gender.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_visitor_Gender.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_visitor_Gender.FormattingEnabled = True
        Me.Cmb_visitor_Gender.ItemHeight = 13
        Me.Cmb_visitor_Gender.Location = New System.Drawing.Point(99, 155)
        Me.Cmb_visitor_Gender.Name = "Cmb_visitor_Gender"
        Me.Cmb_visitor_Gender.Size = New System.Drawing.Size(153, 21)
        Me.Cmb_visitor_Gender.TabIndex = 5
        '
        'Txt_Visitor_Mobile
        '
        Me.Txt_Visitor_Mobile.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.Txt_Visitor_Mobile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Mobile.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Mobile.Location = New System.Drawing.Point(297, 179)
        Me.Txt_Visitor_Mobile.MaxLength = 10
        Me.Txt_Visitor_Mobile.Name = "Txt_Visitor_Mobile"
        Me.Txt_Visitor_Mobile.Size = New System.Drawing.Size(153, 21)
        Me.Txt_Visitor_Mobile.TabIndex = 8
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(253, 182)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(38, 13)
        Me.Label11.TabIndex = 100038
        Me.Label11.Text = "Mobile"
        '
        'Txt_Visitor_Phone
        '
        Me.Txt_Visitor_Phone.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.Txt_Visitor_Phone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Phone.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Phone.Location = New System.Drawing.Point(99, 179)
        Me.Txt_Visitor_Phone.MaxLength = 11
        Me.Txt_Visitor_Phone.Name = "Txt_Visitor_Phone"
        Me.Txt_Visitor_Phone.Size = New System.Drawing.Size(153, 21)
        Me.Txt_Visitor_Phone.TabIndex = 7
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(2, 182)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(38, 13)
        Me.Label8.TabIndex = 100037
        Me.Label8.Text = "Phone"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(1, 63)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(76, 13)
        Me.Label4.TabIndex = 100036
        Me.Label4.Text = "Visitor Address"
        '
        'Txt_Visitor_Addr
        '
        Me.Txt_Visitor_Addr.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.Txt_Visitor_Addr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Addr.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Addr.Location = New System.Drawing.Point(99, 56)
        Me.Txt_Visitor_Addr.MaxLength = 500
        Me.Txt_Visitor_Addr.Multiline = True
        Me.Txt_Visitor_Addr.Name = "Txt_Visitor_Addr"
        Me.Txt_Visitor_Addr.Size = New System.Drawing.Size(353, 70)
        Me.Txt_Visitor_Addr.TabIndex = 3
        '
        'Txt_Visitor_Name
        '
        Me.Txt_Visitor_Name.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.Txt_Visitor_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Name.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Name.Location = New System.Drawing.Point(99, 30)
        Me.Txt_Visitor_Name.MaxLength = 250
        Me.Txt_Visitor_Name.Name = "Txt_Visitor_Name"
        Me.Txt_Visitor_Name.Size = New System.Drawing.Size(353, 21)
        Me.Txt_Visitor_Name.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(1, 36)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(66, 13)
        Me.Label2.TabIndex = 100035
        Me.Label2.Text = "Visitor Name"
        '
        'Pnl_Patientdetails
        '
        Me.Pnl_Patientdetails.BackColor = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(233, Byte), Integer), CType(CType(243, Byte), Integer))
        Me.Pnl_Patientdetails.Controls.Add(Me.Patient_Info1)
        Me.Pnl_Patientdetails.Controls.Add(Me.Btn_PatientF2)
        Me.Pnl_Patientdetails.Controls.Add(Me.Txt_PatientID)
        Me.Pnl_Patientdetails.Controls.Add(Me.Label9)
        Me.Pnl_Patientdetails.Location = New System.Drawing.Point(0, 63)
        Me.Pnl_Patientdetails.Name = "Pnl_Patientdetails"
        Me.Pnl_Patientdetails.Size = New System.Drawing.Size(456, 232)
        Me.Pnl_Patientdetails.TabIndex = 1
        Me.Pnl_Patientdetails.Visible = False
        '
        'Btn_PatientF2
        '
        Me.Btn_PatientF2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_PatientF2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_PatientF2.CausesValidation = False
        Me.Btn_PatientF2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_PatientF2.ForeColor = System.Drawing.Color.White
        Me.Btn_PatientF2.Location = New System.Drawing.Point(228, 4)
        Me.Btn_PatientF2.Name = "Btn_PatientF2"
        Me.Btn_PatientF2.Size = New System.Drawing.Size(29, 21)
        Me.Btn_PatientF2.TabIndex = 2
        Me.Btn_PatientF2.TabStop = False
        Me.Btn_PatientF2.Text = "F2"
        Me.Btn_PatientF2.UseVisualStyleBackColor = False
        '
        'Txt_PatientID
        '
        Me.Txt_PatientID.BackColor = System.Drawing.Color.White
        Me.Txt_PatientID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_PatientID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PatientID.Location = New System.Drawing.Point(98, 4)
        Me.Txt_PatientID.MaxLength = 50
        Me.Txt_PatientID.Name = "Txt_PatientID"
        Me.Txt_PatientID.Size = New System.Drawing.Size(128, 21)
        Me.Txt_PatientID.TabIndex = 1
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(2, 4)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(54, 13)
        Me.Label9.TabIndex = 100042
        Me.Label9.Text = "Patient ID"
        '
        'Pnl_Empdetails
        '
        Me.Pnl_Empdetails.BackColor = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(233, Byte), Integer), CType(CType(243, Byte), Integer))
        Me.Pnl_Empdetails.Controls.Add(Me.Employee_Info1)
        Me.Pnl_Empdetails.Controls.Add(Me.Btn_EmpF2)
        Me.Pnl_Empdetails.Controls.Add(Me.Txt_EmpID)
        Me.Pnl_Empdetails.Controls.Add(Me.Label7)
        Me.Pnl_Empdetails.Location = New System.Drawing.Point(0, 63)
        Me.Pnl_Empdetails.Name = "Pnl_Empdetails"
        Me.Pnl_Empdetails.Size = New System.Drawing.Size(456, 232)
        Me.Pnl_Empdetails.TabIndex = 1
        Me.Pnl_Empdetails.Visible = False
        '
        'Btn_EmpF2
        '
        Me.Btn_EmpF2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_EmpF2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_EmpF2.CausesValidation = False
        Me.Btn_EmpF2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_EmpF2.ForeColor = System.Drawing.Color.White
        Me.Btn_EmpF2.Location = New System.Drawing.Point(227, 4)
        Me.Btn_EmpF2.Name = "Btn_EmpF2"
        Me.Btn_EmpF2.Size = New System.Drawing.Size(29, 21)
        Me.Btn_EmpF2.TabIndex = 2
        Me.Btn_EmpF2.TabStop = False
        Me.Btn_EmpF2.Text = "F2"
        Me.Btn_EmpF2.UseVisualStyleBackColor = False
        '
        'Txt_EmpID
        '
        Me.Txt_EmpID.BackColor = System.Drawing.Color.White
        Me.Txt_EmpID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_EmpID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_EmpID.Location = New System.Drawing.Point(97, 4)
        Me.Txt_EmpID.MaxLength = 50
        Me.Txt_EmpID.Name = "Txt_EmpID"
        Me.Txt_EmpID.Size = New System.Drawing.Size(128, 21)
        Me.Txt_EmpID.TabIndex = 1
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(2, 6)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(67, 13)
        Me.Label7.TabIndex = 100042
        Me.Label7.Text = "Employee ID"
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(242, 436)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(174, 34)
        Me.Pnl_Common_Btn.TabIndex = 100030
        '
        'Btn_Close
        '
        Me.Btn_Close.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Close.BackgroundImage = Global.TECHNO_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Close.ForeColor = System.Drawing.Color.White
        Me.Btn_Close.Location = New System.Drawing.Point(114, 2)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 10
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = False
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(58, 2)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear.TabIndex = 9
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = CType(resources.GetObject("Btn_Save.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(2, 2)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save.TabIndex = 8
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Pnl_Booking
        '
        Me.Pnl_Booking.BackColor = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(233, Byte), Integer), CType(CType(243, Byte), Integer))
        Me.Pnl_Booking.Controls.Add(Me.Cmb_Bookmode)
        Me.Pnl_Booking.Controls.Add(Me.Cmb_Service)
        Me.Pnl_Booking.Controls.Add(Me.Label22)
        Me.Pnl_Booking.Controls.Add(Me.Cmb_Apointtype)
        Me.Pnl_Booking.Controls.Add(Me.Label21)
        Me.Pnl_Booking.Controls.Add(Me.Cmb_Doctor)
        Me.Pnl_Booking.Controls.Add(Me.Label18)
        Me.Pnl_Booking.Controls.Add(Me.Dtp_Apointdate)
        Me.Pnl_Booking.Controls.Add(Me.Label14)
        Me.Pnl_Booking.Controls.Add(Me.Label12)
        Me.Pnl_Booking.Controls.Add(Me.Cmb_Timeto)
        Me.Pnl_Booking.Controls.Add(Me.Cmb_Timefrom)
        Me.Pnl_Booking.Controls.Add(Me.Label3)
        Me.Pnl_Booking.Controls.Add(Me.Label23)
        Me.Pnl_Booking.Location = New System.Drawing.Point(0, 302)
        Me.Pnl_Booking.Name = "Pnl_Booking"
        Me.Pnl_Booking.Size = New System.Drawing.Size(456, 132)
        Me.Pnl_Booking.TabIndex = 2
        '
        'Cmb_Bookmode
        '
        Me.Cmb_Bookmode.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.Cmb_Bookmode.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_Bookmode.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Bookmode.FormattingEnabled = True
        Me.Cmb_Bookmode.ItemHeight = 13
        Me.Cmb_Bookmode.Location = New System.Drawing.Point(303, 54)
        Me.Cmb_Bookmode.Name = "Cmb_Bookmode"
        Me.Cmb_Bookmode.Size = New System.Drawing.Size(114, 21)
        Me.Cmb_Bookmode.TabIndex = 4
        '
        'Cmb_Service
        '
        Me.Cmb_Service.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.Cmb_Service.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_Service.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Service.FormattingEnabled = True
        Me.Cmb_Service.ItemHeight = 13
        Me.Cmb_Service.Location = New System.Drawing.Point(99, 2)
        Me.Cmb_Service.Name = "Cmb_Service"
        Me.Cmb_Service.Size = New System.Drawing.Size(318, 21)
        Me.Cmb_Service.TabIndex = 1
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.BackColor = System.Drawing.Color.Transparent
        Me.Label22.ForeColor = System.Drawing.Color.Black
        Me.Label22.Location = New System.Drawing.Point(3, 8)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(43, 13)
        Me.Label22.TabIndex = 100043
        Me.Label22.Text = "Service"
        '
        'Cmb_Apointtype
        '
        Me.Cmb_Apointtype.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.Cmb_Apointtype.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_Apointtype.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Apointtype.FormattingEnabled = True
        Me.Cmb_Apointtype.ItemHeight = 13
        Me.Cmb_Apointtype.Location = New System.Drawing.Point(99, 54)
        Me.Cmb_Apointtype.Name = "Cmb_Apointtype"
        Me.Cmb_Apointtype.Size = New System.Drawing.Size(128, 21)
        Me.Cmb_Apointtype.TabIndex = 3
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.Color.Transparent
        Me.Label21.ForeColor = System.Drawing.Color.Black
        Me.Label21.Location = New System.Drawing.Point(2, 59)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(93, 13)
        Me.Label21.TabIndex = 100041
        Me.Label21.Text = "Appointment Type"
        '
        'Cmb_Doctor
        '
        Me.Cmb_Doctor.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.Cmb_Doctor.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_Doctor.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Doctor.FormattingEnabled = True
        Me.Cmb_Doctor.ItemHeight = 13
        Me.Cmb_Doctor.Location = New System.Drawing.Point(99, 28)
        Me.Cmb_Doctor.Name = "Cmb_Doctor"
        Me.Cmb_Doctor.Size = New System.Drawing.Size(318, 21)
        Me.Cmb_Doctor.TabIndex = 2
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.Transparent
        Me.Label18.ForeColor = System.Drawing.Color.Black
        Me.Label18.Location = New System.Drawing.Point(4, 31)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(39, 13)
        Me.Label18.TabIndex = 100040
        Me.Label18.Text = "Doctor"
        '
        'Dtp_Apointdate
        '
        Me.Dtp_Apointdate.CalendarMonthBackground = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.Dtp_Apointdate.CalendarTitleForeColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.Dtp_Apointdate.CustomFormat = "dd/MM/yyyy"
        Me.Dtp_Apointdate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_Apointdate.Location = New System.Drawing.Point(99, 81)
        Me.Dtp_Apointdate.Name = "Dtp_Apointdate"
        Me.Dtp_Apointdate.Size = New System.Drawing.Size(128, 20)
        Me.Dtp_Apointdate.TabIndex = 5
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.Black
        Me.Label14.Location = New System.Drawing.Point(6, 83)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(33, 14)
        Me.Label14.TabIndex = 100039
        Me.Label14.Text = "Date"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.ForeColor = System.Drawing.Color.Black
        Me.Label12.Location = New System.Drawing.Point(264, 109)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(20, 13)
        Me.Label12.TabIndex = 100032
        Me.Label12.Text = "To"
        '
        'Cmb_Timeto
        '
        Me.Cmb_Timeto.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.Cmb_Timeto.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_Timeto.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Timeto.FormattingEnabled = True
        Me.Cmb_Timeto.ItemHeight = 13
        Me.Cmb_Timeto.Location = New System.Drawing.Point(289, 106)
        Me.Cmb_Timeto.Name = "Cmb_Timeto"
        Me.Cmb_Timeto.Size = New System.Drawing.Size(128, 21)
        Me.Cmb_Timeto.TabIndex = 7
        '
        'Cmb_Timefrom
        '
        Me.Cmb_Timefrom.BackColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.Cmb_Timefrom.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_Timefrom.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Timefrom.FormattingEnabled = True
        Me.Cmb_Timefrom.ItemHeight = 13
        Me.Cmb_Timefrom.Location = New System.Drawing.Point(99, 106)
        Me.Cmb_Timefrom.Name = "Cmb_Timefrom"
        Me.Cmb_Timefrom.Size = New System.Drawing.Size(128, 21)
        Me.Cmb_Timefrom.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(3, 110)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(86, 13)
        Me.Label3.TabIndex = 100038
        Me.Label3.Text = "ApproxTime from"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.BackColor = System.Drawing.Color.Transparent
        Me.Label23.ForeColor = System.Drawing.Color.Black
        Me.Label23.Location = New System.Drawing.Point(228, 58)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(76, 13)
        Me.Label23.TabIndex = 100045
        Me.Label23.Text = "Booking Mode"
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.FromArgb(CType(CType(193, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.Label10.Location = New System.Drawing.Point(-4, 55)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(466, 5)
        Me.Label10.TabIndex = 100031
        '
        'Label16
        '
        Me.Label16.BackColor = System.Drawing.Color.FromArgb(CType(CType(193, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.Label16.Location = New System.Drawing.Point(-4, 296)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(465, 5)
        Me.Label16.TabIndex = 100032
        '
        'Patient_Info1
        '
        Me.Patient_Info1.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(175, Byte), Integer))
        Me.Patient_Info1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Patient_Info1.Location = New System.Drawing.Point(4, 29)
        Me.Patient_Info1.Name = "Patient_Info1"
        Me.Patient_Info1.Padding = New System.Windows.Forms.Padding(2)
        Me.Patient_Info1.Size = New System.Drawing.Size(445, 200)
        Me.Patient_Info1.TabIndex = 3
        Me.Patient_Info1.TabStop = False
        '
        'Employee_Info1
        '
        Me.Employee_Info1.BackColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(99, Byte), Integer), CType(CType(175, Byte), Integer))
        Me.Employee_Info1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Employee_Info1.Location = New System.Drawing.Point(4, 29)
        Me.Employee_Info1.Name = "Employee_Info1"
        Me.Employee_Info1.Padding = New System.Windows.Forms.Padding(2)
        Me.Employee_Info1.Size = New System.Drawing.Size(445, 199)
        Me.Employee_Info1.TabIndex = 3
        Me.Employee_Info1.TabStop = False
        '
        'Appointment_Save_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(233, Byte), Integer), CType(CType(243, Byte), Integer))
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(455, 474)
        Me.ControlBox = False
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Pnl_Booking)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.Cmb_Visitortype)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Controls.Add(Me.Pnl_Othersdetails)
        Me.Controls.Add(Me.Pnl_Patientdetails)
        Me.Controls.Add(Me.Pnl_Empdetails)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.Name = "Appointment_Save_Frm"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Pnl_Othersdetails.ResumeLayout(False)
        Me.Pnl_Othersdetails.PerformLayout()
        Me.Pnl_Patientdetails.ResumeLayout(False)
        Me.Pnl_Patientdetails.PerformLayout()
        Me.Pnl_Empdetails.ResumeLayout(False)
        Me.Pnl_Empdetails.PerformLayout()
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.Pnl_Booking.ResumeLayout(False)
        Me.Pnl_Booking.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Visitortype As System.Windows.Forms.ComboBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Othersdetails As System.Windows.Forms.Panel
    Friend WithEvents Txt_Visitor_Familyname As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_SSNO As System.Windows.Forms.TextBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Visitor_nationality As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_Age As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Cmb_visitor_Gender As System.Windows.Forms.ComboBox
    Friend WithEvents Txt_Visitor_Mobile As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_Phone As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_Addr As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Visitor_Name As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Patientdetails As System.Windows.Forms.Panel
    Friend WithEvents Patient_Info1 As TECHNO_CLINIC.Patient_Info
    Friend WithEvents Btn_PatientF2 As System.Windows.Forms.Button
    Friend WithEvents Txt_PatientID As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Empdetails As System.Windows.Forms.Panel
    Friend WithEvents Employee_Info1 As TECHNO_CLINIC.Employee_Info
    Friend WithEvents Btn_EmpF2 As System.Windows.Forms.Button
    Friend WithEvents Txt_EmpID As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Pnl_Booking As System.Windows.Forms.Panel
    Friend WithEvents Cmb_Service As System.Windows.Forms.ComboBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Apointtype As System.Windows.Forms.ComboBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Doctor As System.Windows.Forms.ComboBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Dtp_Apointdate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Timeto As System.Windows.Forms.ComboBox
    Friend WithEvents Cmb_Timefrom As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Bookmode As System.Windows.Forms.ComboBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
End Class
