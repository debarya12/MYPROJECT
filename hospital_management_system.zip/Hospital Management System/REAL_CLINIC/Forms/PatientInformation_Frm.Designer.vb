﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PatientInformation_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PatientInformation_Frm))
        Me.Pnl_Header = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Txt_Pat_ID = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Txt_Pat_Name = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Dtp_Pat_DOB = New System.Windows.Forms.MaskedTextBox()
        Me.Txt_FamilyName = New System.Windows.Forms.TextBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Dtp_LastAdmitDate = New System.Windows.Forms.DateTimePicker()
        Me.Cmb_Pat_Insure = New System.Windows.Forms.ComboBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Dtp_Pat_RegDt = New System.Windows.Forms.DateTimePicker()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Btn_New = New System.Windows.Forms.Button()
        Me.Txt_Pat_Occupation = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Cmb_Pat_Martial = New System.Windows.Forms.ComboBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.cmb_Pat_Religion = New System.Windows.Forms.ComboBox()
        Me.Txt_Pat_Age = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Txt_Pat_Pin = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Cmb_Pat_Gender = New System.Windows.Forms.ComboBox()
        Me.Txt_Pat_Email = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Txt_Pat_Mobile2 = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Txt_Pat_Mobile1 = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Txt_Pat_Phone2 = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Txt_Pat_Phone1 = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.cmb_Pat_State = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Txt_Pat_City = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Cmb_Pat_Country = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Txt_Pat_Add = New System.Windows.Forms.TextBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Btn_New1 = New System.Windows.Forms.Button()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Txt_Pat_Identity = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Cmb_Pat_Income = New System.Windows.Forms.ComboBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Cmb_Pat_Social = New System.Windows.Forms.ComboBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.cmb_Pat_Status = New System.Windows.Forms.ComboBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Txt_Pat_Remarks = New System.Windows.Forms.TextBox()
        Me.Txt_Pat_FamilyDr = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Txt_Nominee_Relate = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Txt_Pat_Nominee = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Txt_Pat_Employer = New System.Windows.Forms.TextBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Pnl_Insurance_Det = New System.Windows.Forms.Panel()
        Me.Txt_Company_Mob = New System.Windows.Forms.TextBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Txt_Company_Phone = New System.Windows.Forms.TextBox()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Btn_FindIns = New System.Windows.Forms.Button()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Cmb_Insurance_Company = New System.Windows.Forms.ComboBox()
        Me.Txt_Contact_Person_Fax = New System.Windows.Forms.TextBox()
        Me.Txt_Contact_Person_Email = New System.Windows.Forms.TextBox()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Txt_Contact_Person_Mobile = New System.Windows.Forms.TextBox()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Txt_Contact_Person_Phone = New System.Windows.Forms.TextBox()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Txt_Contact_Person_Address = New System.Windows.Forms.TextBox()
        Me.Txt_Contact_Person_Name = New System.Windows.Forms.TextBox()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Txt_Company_Address = New System.Windows.Forms.TextBox()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel()
        Me.Btn_Clear = New System.Windows.Forms.Button()
        Me.Btn_Close = New System.Windows.Forms.Button()
        Me.Btn_Delete = New System.Windows.Forms.Button()
        Me.Btn_Save = New System.Windows.Forms.Button()
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel()
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label()
        Me.Btn_FindID = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Btn_Tab2 = New System.Windows.Forms.Button()
        Me.Btn_Tab1 = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Txt_Pat_Soc_SecNo = New System.Windows.Forms.TextBox()
        Me.Btn_Find2 = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Imageviewer1 = New REAL_CLINIC.Imageviewer()
        Me.Pnl_Header.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.Pnl_Insurance_Det.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.Pnl_Tran_mode.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.Controls.Add(Me.Label3)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(687, 24)
        Me.Pnl_Header.TabIndex = 10000
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(3, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(155, 18)
        Me.Label3.TabIndex = 10000
        Me.Label3.Text = "Patient Information"
        '
        'Txt_Pat_ID
        '
        Me.Txt_Pat_ID.BackColor = System.Drawing.Color.White
        Me.Txt_Pat_ID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Pat_ID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Pat_ID.ForeColor = System.Drawing.Color.Black
        Me.Txt_Pat_ID.Location = New System.Drawing.Point(116, 23)
        Me.Txt_Pat_ID.MaxLength = 10
        Me.Txt_Pat_ID.Name = "Txt_Pat_ID"
        Me.Txt_Pat_ID.Size = New System.Drawing.Size(203, 21)
        Me.Txt_Pat_ID.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(12, 27)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 13)
        Me.Label2.TabIndex = 115
        Me.Label2.Text = "Patient ID"
        '
        'Txt_Pat_Name
        '
        Me.Txt_Pat_Name.BackColor = System.Drawing.Color.White
        Me.Txt_Pat_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Pat_Name.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Pat_Name.Location = New System.Drawing.Point(116, 48)
        Me.Txt_Pat_Name.MaxLength = 250
        Me.Txt_Pat_Name.Name = "Txt_Pat_Name"
        Me.Txt_Pat_Name.Size = New System.Drawing.Size(440, 21)
        Me.Txt_Pat_Name.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(12, 51)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(83, 13)
        Me.Label1.TabIndex = 117
        Me.Label1.Text = "Patient Name"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Location = New System.Drawing.Point(4, 74)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(677, 419)
        Me.TabControl1.TabIndex = 3
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.TabPage1.BackgroundImage = CType(resources.GetObject("TabPage1.BackgroundImage"), System.Drawing.Image)
        Me.TabPage1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TabPage1.Controls.Add(Me.Dtp_Pat_DOB)
        Me.TabPage1.Controls.Add(Me.Txt_FamilyName)
        Me.TabPage1.Controls.Add(Me.Label36)
        Me.TabPage1.Controls.Add(Me.Panel3)
        Me.TabPage1.Controls.Add(Me.Label33)
        Me.TabPage1.Controls.Add(Me.Label32)
        Me.TabPage1.Controls.Add(Me.Dtp_LastAdmitDate)
        Me.TabPage1.Controls.Add(Me.Cmb_Pat_Insure)
        Me.TabPage1.Controls.Add(Me.Label22)
        Me.TabPage1.Controls.Add(Me.Label21)
        Me.TabPage1.Controls.Add(Me.Dtp_Pat_RegDt)
        Me.TabPage1.Controls.Add(Me.Label20)
        Me.TabPage1.Controls.Add(Me.Btn_New)
        Me.TabPage1.Controls.Add(Me.Txt_Pat_Occupation)
        Me.TabPage1.Controls.Add(Me.Label19)
        Me.TabPage1.Controls.Add(Me.Label18)
        Me.TabPage1.Controls.Add(Me.Cmb_Pat_Martial)
        Me.TabPage1.Controls.Add(Me.Label17)
        Me.TabPage1.Controls.Add(Me.cmb_Pat_Religion)
        Me.TabPage1.Controls.Add(Me.Txt_Pat_Age)
        Me.TabPage1.Controls.Add(Me.Label15)
        Me.TabPage1.Controls.Add(Me.Label16)
        Me.TabPage1.Controls.Add(Me.Txt_Pat_Pin)
        Me.TabPage1.Controls.Add(Me.Label14)
        Me.TabPage1.Controls.Add(Me.Label13)
        Me.TabPage1.Controls.Add(Me.Cmb_Pat_Gender)
        Me.TabPage1.Controls.Add(Me.Txt_Pat_Email)
        Me.TabPage1.Controls.Add(Me.Label12)
        Me.TabPage1.Controls.Add(Me.Txt_Pat_Mobile2)
        Me.TabPage1.Controls.Add(Me.Label10)
        Me.TabPage1.Controls.Add(Me.Txt_Pat_Mobile1)
        Me.TabPage1.Controls.Add(Me.Label11)
        Me.TabPage1.Controls.Add(Me.Txt_Pat_Phone2)
        Me.TabPage1.Controls.Add(Me.Label9)
        Me.TabPage1.Controls.Add(Me.Txt_Pat_Phone1)
        Me.TabPage1.Controls.Add(Me.Label8)
        Me.TabPage1.Controls.Add(Me.cmb_Pat_State)
        Me.TabPage1.Controls.Add(Me.Label7)
        Me.TabPage1.Controls.Add(Me.Txt_Pat_City)
        Me.TabPage1.Controls.Add(Me.Label6)
        Me.TabPage1.Controls.Add(Me.Cmb_Pat_Country)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.Txt_Pat_Add)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(669, 393)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Personal Details             "
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Dtp_Pat_DOB
        '
        Me.Dtp_Pat_DOB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Dtp_Pat_DOB.Location = New System.Drawing.Point(105, 315)
        Me.Dtp_Pat_DOB.Mask = "##/##/####"
        Me.Dtp_Pat_DOB.Name = "Dtp_Pat_DOB"
        Me.Dtp_Pat_DOB.Size = New System.Drawing.Size(99, 21)
        Me.Dtp_Pat_DOB.TabIndex = 164
        '
        'Txt_FamilyName
        '
        Me.Txt_FamilyName.BackColor = System.Drawing.Color.White
        Me.Txt_FamilyName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_FamilyName.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_FamilyName.Location = New System.Drawing.Point(105, 26)
        Me.Txt_FamilyName.MaxLength = 250
        Me.Txt_FamilyName.Name = "Txt_FamilyName"
        Me.Txt_FamilyName.Size = New System.Drawing.Size(306, 21)
        Me.Txt_FamilyName.TabIndex = 4
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.BackColor = System.Drawing.Color.Transparent
        Me.Label36.ForeColor = System.Drawing.Color.Black
        Me.Label36.Location = New System.Drawing.Point(19, 28)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(82, 13)
        Me.Label36.TabIndex = 163
        Me.Label36.Text = "Family  Name"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.BackColor = System.Drawing.Color.Transparent
        Me.Label33.ForeColor = System.Drawing.Color.Red
        Me.Label33.Location = New System.Drawing.Point(69, 243)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(14, 13)
        Me.Label33.TabIndex = 160
        Me.Label33.Text = "*"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.BackColor = System.Drawing.Color.Transparent
        Me.Label32.ForeColor = System.Drawing.Color.Red
        Me.Label32.Location = New System.Drawing.Point(73, 55)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(14, 13)
        Me.Label32.TabIndex = 159
        Me.Label32.Text = "*"
        '
        'Dtp_LastAdmitDate
        '
        Me.Dtp_LastAdmitDate.Cursor = System.Windows.Forms.Cursors.Default
        Me.Dtp_LastAdmitDate.CustomFormat = "dd/MM/yyyy"
        Me.Dtp_LastAdmitDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_LastAdmitDate.Location = New System.Drawing.Point(549, 186)
        Me.Dtp_LastAdmitDate.Name = "Dtp_LastAdmitDate"
        Me.Dtp_LastAdmitDate.Size = New System.Drawing.Size(98, 21)
        Me.Dtp_LastAdmitDate.TabIndex = 155
        Me.Dtp_LastAdmitDate.TabStop = False
        '
        'Cmb_Pat_Insure
        '
        Me.Cmb_Pat_Insure.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Pat_Insure.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Pat_Insure.FormattingEnabled = True
        Me.Cmb_Pat_Insure.Location = New System.Drawing.Point(437, 342)
        Me.Cmb_Pat_Insure.Name = "Cmb_Pat_Insure"
        Me.Cmb_Pat_Insure.Size = New System.Drawing.Size(96, 21)
        Me.Cmb_Pat_Insure.TabIndex = 21
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.BackColor = System.Drawing.Color.Transparent
        Me.Label22.ForeColor = System.Drawing.Color.Black
        Me.Label22.Location = New System.Drawing.Point(349, 345)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(51, 13)
        Me.Label22.TabIndex = 158
        Me.Label22.Text = "Insured"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.Color.Transparent
        Me.Label21.ForeColor = System.Drawing.Color.Black
        Me.Label21.Location = New System.Drawing.Point(552, 168)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(88, 13)
        Me.Label21.TabIndex = 154
        Me.Label21.Text = "Last Visit Date"
        '
        'Dtp_Pat_RegDt
        '
        Me.Dtp_Pat_RegDt.Cursor = System.Windows.Forms.Cursors.Default
        Me.Dtp_Pat_RegDt.CustomFormat = "dd/MM/yyyy"
        Me.Dtp_Pat_RegDt.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_Pat_RegDt.Location = New System.Drawing.Point(437, 186)
        Me.Dtp_Pat_RegDt.Name = "Dtp_Pat_RegDt"
        Me.Dtp_Pat_RegDt.Size = New System.Drawing.Size(98, 21)
        Me.Dtp_Pat_RegDt.TabIndex = 153
        Me.Dtp_Pat_RegDt.TabStop = False
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.Color.Transparent
        Me.Label20.ForeColor = System.Drawing.Color.Black
        Me.Label20.Location = New System.Drawing.Point(440, 168)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(85, 13)
        Me.Label20.TabIndex = 157
        Me.Label20.Text = "Register Date"
        '
        'Btn_New
        '
        Me.Btn_New.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_New.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Add_3
        Me.Btn_New.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_New.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_New.ForeColor = System.Drawing.Color.White
        Me.Btn_New.Location = New System.Drawing.Point(321, 160)
        Me.Btn_New.Name = "Btn_New"
        Me.Btn_New.Size = New System.Drawing.Size(27, 21)
        Me.Btn_New.TabIndex = 147
        Me.Btn_New.TabStop = False
        Me.Btn_New.UseVisualStyleBackColor = False
        Me.Btn_New.Visible = False
        '
        'Txt_Pat_Occupation
        '
        Me.Txt_Pat_Occupation.BackColor = System.Drawing.Color.White
        Me.Txt_Pat_Occupation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Pat_Occupation.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Pat_Occupation.Location = New System.Drawing.Point(105, 342)
        Me.Txt_Pat_Occupation.MaxLength = 100
        Me.Txt_Pat_Occupation.Name = "Txt_Pat_Occupation"
        Me.Txt_Pat_Occupation.Size = New System.Drawing.Size(215, 21)
        Me.Txt_Pat_Occupation.TabIndex = 20
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.ForeColor = System.Drawing.Color.Black
        Me.Label19.Location = New System.Drawing.Point(19, 348)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(70, 13)
        Me.Label19.TabIndex = 146
        Me.Label19.Text = "Occupation"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.Transparent
        Me.Label18.ForeColor = System.Drawing.Color.Black
        Me.Label18.Location = New System.Drawing.Point(349, 320)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(86, 13)
        Me.Label18.TabIndex = 144
        Me.Label18.Text = "Marital status"
        '
        'Cmb_Pat_Martial
        '
        Me.Cmb_Pat_Martial.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Pat_Martial.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Pat_Martial.FormattingEnabled = True
        Me.Cmb_Pat_Martial.Location = New System.Drawing.Point(437, 316)
        Me.Cmb_Pat_Martial.Name = "Cmb_Pat_Martial"
        Me.Cmb_Pat_Martial.Size = New System.Drawing.Size(163, 21)
        Me.Cmb_Pat_Martial.TabIndex = 19
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.ForeColor = System.Drawing.Color.Black
        Me.Label17.Location = New System.Drawing.Point(349, 294)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(52, 13)
        Me.Label17.TabIndex = 142
        Me.Label17.Text = "Religion"
        '
        'cmb_Pat_Religion
        '
        Me.cmb_Pat_Religion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_Pat_Religion.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_Pat_Religion.FormattingEnabled = True
        Me.cmb_Pat_Religion.Location = New System.Drawing.Point(437, 290)
        Me.cmb_Pat_Religion.Name = "cmb_Pat_Religion"
        Me.cmb_Pat_Religion.Size = New System.Drawing.Size(163, 21)
        Me.cmb_Pat_Religion.TabIndex = 16
        '
        'Txt_Pat_Age
        '
        Me.Txt_Pat_Age.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Pat_Age.Cursor = System.Windows.Forms.Cursors.Default
        Me.Txt_Pat_Age.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Pat_Age.Location = New System.Drawing.Point(245, 316)
        Me.Txt_Pat_Age.MaxLength = 3
        Me.Txt_Pat_Age.Name = "Txt_Pat_Age"
        Me.Txt_Pat_Age.Size = New System.Drawing.Size(74, 21)
        Me.Txt_Pat_Age.TabIndex = 18
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label15.Location = New System.Drawing.Point(202, 323)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(29, 13)
        Me.Label15.TabIndex = 140
        Me.Label15.Text = "Age"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label16.Location = New System.Drawing.Point(19, 323)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(30, 13)
        Me.Label16.TabIndex = 139
        Me.Label16.Text = "DOB"
        '
        'Txt_Pat_Pin
        '
        Me.Txt_Pat_Pin.BackColor = System.Drawing.Color.White
        Me.Txt_Pat_Pin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Pat_Pin.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Pat_Pin.Location = New System.Drawing.Point(105, 290)
        Me.Txt_Pat_Pin.MaxLength = 50
        Me.Txt_Pat_Pin.Name = "Txt_Pat_Pin"
        Me.Txt_Pat_Pin.Size = New System.Drawing.Size(215, 21)
        Me.Txt_Pat_Pin.TabIndex = 15
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.ForeColor = System.Drawing.Color.Black
        Me.Label14.Location = New System.Drawing.Point(19, 297)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(55, 13)
        Me.Label14.TabIndex = 136
        Me.Label14.Text = "Zip Code"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.ForeColor = System.Drawing.Color.Black
        Me.Label13.Location = New System.Drawing.Point(349, 268)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(48, 13)
        Me.Label13.TabIndex = 134
        Me.Label13.Text = "Gender"
        '
        'Cmb_Pat_Gender
        '
        Me.Cmb_Pat_Gender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Pat_Gender.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Pat_Gender.FormattingEnabled = True
        Me.Cmb_Pat_Gender.ItemHeight = 13
        Me.Cmb_Pat_Gender.Location = New System.Drawing.Point(437, 264)
        Me.Cmb_Pat_Gender.Name = "Cmb_Pat_Gender"
        Me.Cmb_Pat_Gender.Size = New System.Drawing.Size(96, 21)
        Me.Cmb_Pat_Gender.TabIndex = 14
        '
        'Txt_Pat_Email
        '
        Me.Txt_Pat_Email.BackColor = System.Drawing.Color.White
        Me.Txt_Pat_Email.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Pat_Email.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Pat_Email.Location = New System.Drawing.Point(105, 264)
        Me.Txt_Pat_Email.MaxLength = 100
        Me.Txt_Pat_Email.Name = "Txt_Pat_Email"
        Me.Txt_Pat_Email.Size = New System.Drawing.Size(215, 21)
        Me.Txt_Pat_Email.TabIndex = 13
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.ForeColor = System.Drawing.Color.Black
        Me.Label12.Location = New System.Drawing.Point(19, 271)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(37, 13)
        Me.Label12.TabIndex = 132
        Me.Label12.Text = "Email"
        '
        'Txt_Pat_Mobile2
        '
        Me.Txt_Pat_Mobile2.BackColor = System.Drawing.Color.White
        Me.Txt_Pat_Mobile2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Pat_Mobile2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Pat_Mobile2.Location = New System.Drawing.Point(437, 238)
        Me.Txt_Pat_Mobile2.MaxLength = 10
        Me.Txt_Pat_Mobile2.Name = "Txt_Pat_Mobile2"
        Me.Txt_Pat_Mobile2.Size = New System.Drawing.Size(210, 21)
        Me.Txt_Pat_Mobile2.TabIndex = 12
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(349, 242)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(54, 13)
        Me.Label10.TabIndex = 130
        Me.Label10.Text = "Mobile 2"
        '
        'Txt_Pat_Mobile1
        '
        Me.Txt_Pat_Mobile1.BackColor = System.Drawing.Color.White
        Me.Txt_Pat_Mobile1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Pat_Mobile1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Pat_Mobile1.Location = New System.Drawing.Point(105, 238)
        Me.Txt_Pat_Mobile1.MaxLength = 10
        Me.Txt_Pat_Mobile1.Name = "Txt_Pat_Mobile1"
        Me.Txt_Pat_Mobile1.Size = New System.Drawing.Size(215, 21)
        Me.Txt_Pat_Mobile1.TabIndex = 11
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(19, 245)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(54, 13)
        Me.Label11.TabIndex = 128
        Me.Label11.Text = "Mobile 1"
        '
        'Txt_Pat_Phone2
        '
        Me.Txt_Pat_Phone2.BackColor = System.Drawing.Color.White
        Me.Txt_Pat_Phone2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Pat_Phone2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Pat_Phone2.Location = New System.Drawing.Point(437, 212)
        Me.Txt_Pat_Phone2.MaxLength = 11
        Me.Txt_Pat_Phone2.Name = "Txt_Pat_Phone2"
        Me.Txt_Pat_Phone2.Size = New System.Drawing.Size(210, 21)
        Me.Txt_Pat_Phone2.TabIndex = 10
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(349, 216)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(52, 13)
        Me.Label9.TabIndex = 126
        Me.Label9.Text = "Phone 2"
        '
        'Txt_Pat_Phone1
        '
        Me.Txt_Pat_Phone1.BackColor = System.Drawing.Color.White
        Me.Txt_Pat_Phone1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Pat_Phone1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Pat_Phone1.Location = New System.Drawing.Point(105, 212)
        Me.Txt_Pat_Phone1.MaxLength = 11
        Me.Txt_Pat_Phone1.Name = "Txt_Pat_Phone1"
        Me.Txt_Pat_Phone1.Size = New System.Drawing.Size(215, 21)
        Me.Txt_Pat_Phone1.TabIndex = 9
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(19, 219)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(52, 13)
        Me.Label8.TabIndex = 124
        Me.Label8.Text = "Phone 1"
        '
        'cmb_Pat_State
        '
        Me.cmb_Pat_State.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_Pat_State.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_Pat_State.FormattingEnabled = True
        Me.cmb_Pat_State.Location = New System.Drawing.Point(105, 186)
        Me.cmb_Pat_State.Name = "cmb_Pat_State"
        Me.cmb_Pat_State.Size = New System.Drawing.Size(215, 21)
        Me.cmb_Pat_State.TabIndex = 8
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label7.Location = New System.Drawing.Point(19, 194)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(38, 13)
        Me.Label7.TabIndex = 122
        Me.Label7.Text = "State"
        '
        'Txt_Pat_City
        '
        Me.Txt_Pat_City.BackColor = System.Drawing.Color.White
        Me.Txt_Pat_City.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Pat_City.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Pat_City.Location = New System.Drawing.Point(105, 134)
        Me.Txt_Pat_City.MaxLength = 50
        Me.Txt_Pat_City.Name = "Txt_Pat_City"
        Me.Txt_Pat_City.Size = New System.Drawing.Size(306, 21)
        Me.Txt_Pat_City.TabIndex = 6
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(19, 136)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(32, 13)
        Me.Label6.TabIndex = 120
        Me.Label6.Text = "City "
        '
        'Cmb_Pat_Country
        '
        Me.Cmb_Pat_Country.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Pat_Country.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Pat_Country.FormattingEnabled = True
        Me.Cmb_Pat_Country.Location = New System.Drawing.Point(105, 160)
        Me.Cmb_Pat_Country.Name = "Cmb_Pat_Country"
        Me.Cmb_Pat_Country.Size = New System.Drawing.Size(215, 21)
        Me.Cmb_Pat_Country.TabIndex = 7
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label5.Location = New System.Drawing.Point(19, 168)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(52, 13)
        Me.Label5.TabIndex = 118
        Me.Label5.Text = "Country"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(19, 57)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(53, 13)
        Me.Label4.TabIndex = 116
        Me.Label4.Text = "Address"
        '
        'Txt_Pat_Add
        '
        Me.Txt_Pat_Add.BackColor = System.Drawing.Color.White
        Me.Txt_Pat_Add.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Pat_Add.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Pat_Add.Location = New System.Drawing.Point(105, 53)
        Me.Txt_Pat_Add.MaxLength = 500
        Me.Txt_Pat_Add.Multiline = True
        Me.Txt_Pat_Add.Name = "Txt_Pat_Add"
        Me.Txt_Pat_Add.Size = New System.Drawing.Size(306, 76)
        Me.Txt_Pat_Add.TabIndex = 5
        '
        'TabPage2
        '
        Me.TabPage2.BackgroundImage = CType(resources.GetObject("TabPage2.BackgroundImage"), System.Drawing.Image)
        Me.TabPage2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TabPage2.Controls.Add(Me.Panel4)
        Me.TabPage2.Controls.Add(Me.Btn_New1)
        Me.TabPage2.Controls.Add(Me.Label31)
        Me.TabPage2.Controls.Add(Me.Txt_Pat_Identity)
        Me.TabPage2.Controls.Add(Me.Label30)
        Me.TabPage2.Controls.Add(Me.Cmb_Pat_Income)
        Me.TabPage2.Controls.Add(Me.Label29)
        Me.TabPage2.Controls.Add(Me.Cmb_Pat_Social)
        Me.TabPage2.Controls.Add(Me.Label28)
        Me.TabPage2.Controls.Add(Me.cmb_Pat_Status)
        Me.TabPage2.Controls.Add(Me.Label27)
        Me.TabPage2.Controls.Add(Me.Txt_Pat_Remarks)
        Me.TabPage2.Controls.Add(Me.Txt_Pat_FamilyDr)
        Me.TabPage2.Controls.Add(Me.Label26)
        Me.TabPage2.Controls.Add(Me.Txt_Nominee_Relate)
        Me.TabPage2.Controls.Add(Me.Label25)
        Me.TabPage2.Controls.Add(Me.Label24)
        Me.TabPage2.Controls.Add(Me.Txt_Pat_Nominee)
        Me.TabPage2.Controls.Add(Me.Label23)
        Me.TabPage2.Controls.Add(Me.Txt_Pat_Employer)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(669, 393)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "6"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Panel4.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.MainMenu_Bkg
        Me.Panel4.Location = New System.Drawing.Point(163, -1)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(163, 18)
        Me.Panel4.TabIndex = 174
        '
        'Btn_New1
        '
        Me.Btn_New1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_New1.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Add_3
        Me.Btn_New1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_New1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_New1.ForeColor = System.Drawing.Color.White
        Me.Btn_New1.Location = New System.Drawing.Point(343, 265)
        Me.Btn_New1.Name = "Btn_New1"
        Me.Btn_New1.Size = New System.Drawing.Size(27, 21)
        Me.Btn_New1.TabIndex = 173
        Me.Btn_New1.TabStop = False
        Me.Btn_New1.UseVisualStyleBackColor = False
        Me.Btn_New1.Visible = False
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.BackColor = System.Drawing.Color.Transparent
        Me.Label31.ForeColor = System.Drawing.Color.Black
        Me.Label31.Location = New System.Drawing.Point(4, 347)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(95, 13)
        Me.Label31.TabIndex = 172
        Me.Label31.Text = "Identity Details"
        '
        'Txt_Pat_Identity
        '
        Me.Txt_Pat_Identity.BackColor = System.Drawing.Color.White
        Me.Txt_Pat_Identity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Pat_Identity.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Pat_Identity.Location = New System.Drawing.Point(108, 340)
        Me.Txt_Pat_Identity.MaxLength = 250
        Me.Txt_Pat_Identity.Multiline = True
        Me.Txt_Pat_Identity.Name = "Txt_Pat_Identity"
        Me.Txt_Pat_Identity.Size = New System.Drawing.Size(413, 46)
        Me.Txt_Pat_Identity.TabIndex = 8
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.BackColor = System.Drawing.Color.Transparent
        Me.Label30.ForeColor = System.Drawing.Color.Black
        Me.Label30.Location = New System.Drawing.Point(4, 323)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(92, 13)
        Me.Label30.TabIndex = 171
        Me.Label30.Text = "Annual Income"
        '
        'Cmb_Pat_Income
        '
        Me.Cmb_Pat_Income.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Pat_Income.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Pat_Income.FormattingEnabled = True
        Me.Cmb_Pat_Income.Location = New System.Drawing.Point(108, 315)
        Me.Cmb_Pat_Income.Name = "Cmb_Pat_Income"
        Me.Cmb_Pat_Income.Size = New System.Drawing.Size(230, 21)
        Me.Cmb_Pat_Income.TabIndex = 7
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.BackColor = System.Drawing.Color.Transparent
        Me.Label29.ForeColor = System.Drawing.Color.Black
        Me.Label29.Location = New System.Drawing.Point(4, 296)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(80, 13)
        Me.Label29.TabIndex = 170
        Me.Label29.Text = "Social Status"
        '
        'Cmb_Pat_Social
        '
        Me.Cmb_Pat_Social.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Pat_Social.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Pat_Social.FormattingEnabled = True
        Me.Cmb_Pat_Social.Location = New System.Drawing.Point(108, 290)
        Me.Cmb_Pat_Social.Name = "Cmb_Pat_Social"
        Me.Cmb_Pat_Social.Size = New System.Drawing.Size(230, 21)
        Me.Cmb_Pat_Social.TabIndex = 6
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.BackColor = System.Drawing.Color.Transparent
        Me.Label28.ForeColor = System.Drawing.Color.Black
        Me.Label28.Location = New System.Drawing.Point(4, 265)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(44, 13)
        Me.Label28.TabIndex = 169
        Me.Label28.Text = "Status"
        '
        'cmb_Pat_Status
        '
        Me.cmb_Pat_Status.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_Pat_Status.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmb_Pat_Status.FormattingEnabled = True
        Me.cmb_Pat_Status.Location = New System.Drawing.Point(108, 265)
        Me.cmb_Pat_Status.Name = "cmb_Pat_Status"
        Me.cmb_Pat_Status.Size = New System.Drawing.Size(230, 21)
        Me.cmb_Pat_Status.TabIndex = 5
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.BackColor = System.Drawing.Color.Transparent
        Me.Label27.ForeColor = System.Drawing.Color.Black
        Me.Label27.Location = New System.Drawing.Point(4, 208)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(58, 13)
        Me.Label27.TabIndex = 164
        Me.Label27.Text = "Remarks"
        '
        'Txt_Pat_Remarks
        '
        Me.Txt_Pat_Remarks.BackColor = System.Drawing.Color.White
        Me.Txt_Pat_Remarks.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Pat_Remarks.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Pat_Remarks.Location = New System.Drawing.Point(108, 203)
        Me.Txt_Pat_Remarks.MaxLength = 150
        Me.Txt_Pat_Remarks.Multiline = True
        Me.Txt_Pat_Remarks.Name = "Txt_Pat_Remarks"
        Me.Txt_Pat_Remarks.Size = New System.Drawing.Size(413, 58)
        Me.Txt_Pat_Remarks.TabIndex = 4
        '
        'Txt_Pat_FamilyDr
        '
        Me.Txt_Pat_FamilyDr.BackColor = System.Drawing.Color.White
        Me.Txt_Pat_FamilyDr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Pat_FamilyDr.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Pat_FamilyDr.Location = New System.Drawing.Point(108, 141)
        Me.Txt_Pat_FamilyDr.MaxLength = 250
        Me.Txt_Pat_FamilyDr.Multiline = True
        Me.Txt_Pat_FamilyDr.Name = "Txt_Pat_FamilyDr"
        Me.Txt_Pat_FamilyDr.Size = New System.Drawing.Size(413, 58)
        Me.Txt_Pat_FamilyDr.TabIndex = 3
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.BackColor = System.Drawing.Color.Transparent
        Me.Label26.ForeColor = System.Drawing.Color.Black
        Me.Label26.Location = New System.Drawing.Point(4, 153)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(85, 13)
        Me.Label26.TabIndex = 161
        Me.Label26.Text = "Family Doctor"
        '
        'Txt_Nominee_Relate
        '
        Me.Txt_Nominee_Relate.BackColor = System.Drawing.Color.White
        Me.Txt_Nominee_Relate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Nominee_Relate.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Nominee_Relate.Location = New System.Drawing.Point(108, 116)
        Me.Txt_Nominee_Relate.MaxLength = 50
        Me.Txt_Nominee_Relate.Name = "Txt_Nominee_Relate"
        Me.Txt_Nominee_Relate.Size = New System.Drawing.Size(229, 21)
        Me.Txt_Nominee_Relate.TabIndex = 2
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.BackColor = System.Drawing.Color.Transparent
        Me.Label25.ForeColor = System.Drawing.Color.Black
        Me.Label25.Location = New System.Drawing.Point(4, 119)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(106, 13)
        Me.Label25.TabIndex = 159
        Me.Label25.Text = "Nominee Relation"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.BackColor = System.Drawing.Color.Transparent
        Me.Label24.ForeColor = System.Drawing.Color.Black
        Me.Label24.Location = New System.Drawing.Point(4, 99)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(56, 13)
        Me.Label24.TabIndex = 157
        Me.Label24.Text = "Nominee"
        '
        'Txt_Pat_Nominee
        '
        Me.Txt_Pat_Nominee.BackColor = System.Drawing.Color.White
        Me.Txt_Pat_Nominee.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Pat_Nominee.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Pat_Nominee.Location = New System.Drawing.Point(108, 91)
        Me.Txt_Pat_Nominee.MaxLength = 250
        Me.Txt_Pat_Nominee.Name = "Txt_Pat_Nominee"
        Me.Txt_Pat_Nominee.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Txt_Pat_Nominee.Size = New System.Drawing.Size(413, 21)
        Me.Txt_Pat_Nominee.TabIndex = 1
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.BackColor = System.Drawing.Color.Transparent
        Me.Label23.ForeColor = System.Drawing.Color.Black
        Me.Label23.Location = New System.Drawing.Point(4, 34)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(102, 13)
        Me.Label23.TabIndex = 155
        Me.Label23.Text = "Employer Details"
        '
        'Txt_Pat_Employer
        '
        Me.Txt_Pat_Employer.BackColor = System.Drawing.Color.White
        Me.Txt_Pat_Employer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Pat_Employer.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Pat_Employer.Location = New System.Drawing.Point(108, 25)
        Me.Txt_Pat_Employer.MaxLength = 500
        Me.Txt_Pat_Employer.Multiline = True
        Me.Txt_Pat_Employer.Name = "Txt_Pat_Employer"
        Me.Txt_Pat_Employer.Size = New System.Drawing.Size(413, 62)
        Me.Txt_Pat_Employer.TabIndex = 0
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.Transparent
        Me.TabPage3.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.LeftGradiant
        Me.TabPage3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TabPage3.Controls.Add(Me.Panel6)
        Me.TabPage3.Controls.Add(Me.Pnl_Insurance_Det)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(669, 393)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "TabPage3"
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Panel6.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.MainMenu_Bkg
        Me.Panel6.Location = New System.Drawing.Point(326, 0)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(181, 21)
        Me.Panel6.TabIndex = 162
        '
        'Pnl_Insurance_Det
        '
        Me.Pnl_Insurance_Det.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Pnl_Insurance_Det.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Insurance_Det.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Insurance_Det.Controls.Add(Me.Txt_Company_Mob)
        Me.Pnl_Insurance_Det.Controls.Add(Me.Label39)
        Me.Pnl_Insurance_Det.Controls.Add(Me.Txt_Company_Phone)
        Me.Pnl_Insurance_Det.Controls.Add(Me.Label40)
        Me.Pnl_Insurance_Det.Controls.Add(Me.Btn_FindIns)
        Me.Pnl_Insurance_Det.Controls.Add(Me.Label37)
        Me.Pnl_Insurance_Det.Controls.Add(Me.Cmb_Insurance_Company)
        Me.Pnl_Insurance_Det.Controls.Add(Me.Txt_Contact_Person_Fax)
        Me.Pnl_Insurance_Det.Controls.Add(Me.Txt_Contact_Person_Email)
        Me.Pnl_Insurance_Det.Controls.Add(Me.Label43)
        Me.Pnl_Insurance_Det.Controls.Add(Me.Txt_Contact_Person_Mobile)
        Me.Pnl_Insurance_Det.Controls.Add(Me.Label44)
        Me.Pnl_Insurance_Det.Controls.Add(Me.Txt_Contact_Person_Phone)
        Me.Pnl_Insurance_Det.Controls.Add(Me.Label45)
        Me.Pnl_Insurance_Det.Controls.Add(Me.Label46)
        Me.Pnl_Insurance_Det.Controls.Add(Me.Label47)
        Me.Pnl_Insurance_Det.Controls.Add(Me.Txt_Contact_Person_Address)
        Me.Pnl_Insurance_Det.Controls.Add(Me.Txt_Contact_Person_Name)
        Me.Pnl_Insurance_Det.Controls.Add(Me.Label48)
        Me.Pnl_Insurance_Det.Controls.Add(Me.Label49)
        Me.Pnl_Insurance_Det.Controls.Add(Me.Button2)
        Me.Pnl_Insurance_Det.Controls.Add(Me.Label38)
        Me.Pnl_Insurance_Det.Controls.Add(Me.Txt_Company_Address)
        Me.Pnl_Insurance_Det.Enabled = False
        Me.Pnl_Insurance_Det.Location = New System.Drawing.Point(10, 27)
        Me.Pnl_Insurance_Det.Name = "Pnl_Insurance_Det"
        Me.Pnl_Insurance_Det.Size = New System.Drawing.Size(562, 240)
        Me.Pnl_Insurance_Det.TabIndex = 6
        '
        'Txt_Company_Mob
        '
        Me.Txt_Company_Mob.BackColor = System.Drawing.Color.White
        Me.Txt_Company_Mob.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Company_Mob.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Company_Mob.Location = New System.Drawing.Point(387, 71)
        Me.Txt_Company_Mob.MaxLength = 10
        Me.Txt_Company_Mob.Name = "Txt_Company_Mob"
        Me.Txt_Company_Mob.ReadOnly = True
        Me.Txt_Company_Mob.Size = New System.Drawing.Size(159, 21)
        Me.Txt_Company_Mob.TabIndex = 4
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.BackColor = System.Drawing.Color.Transparent
        Me.Label39.ForeColor = System.Drawing.Color.White
        Me.Label39.Location = New System.Drawing.Point(328, 75)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(44, 13)
        Me.Label39.TabIndex = 100078
        Me.Label39.Text = "Mobile"
        '
        'Txt_Company_Phone
        '
        Me.Txt_Company_Phone.BackColor = System.Drawing.Color.White
        Me.Txt_Company_Phone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Company_Phone.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Company_Phone.Location = New System.Drawing.Point(106, 71)
        Me.Txt_Company_Phone.MaxLength = 11
        Me.Txt_Company_Phone.Name = "Txt_Company_Phone"
        Me.Txt_Company_Phone.ReadOnly = True
        Me.Txt_Company_Phone.Size = New System.Drawing.Size(216, 21)
        Me.Txt_Company_Phone.TabIndex = 3
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.BackColor = System.Drawing.Color.Transparent
        Me.Label40.ForeColor = System.Drawing.Color.White
        Me.Label40.Location = New System.Drawing.Point(1, 71)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(42, 13)
        Me.Label40.TabIndex = 100077
        Me.Label40.Text = "Phone"
        '
        'Btn_FindIns
        '
        Me.Btn_FindIns.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_FindIns.BackgroundImage = CType(resources.GetObject("Btn_FindIns.BackgroundImage"), System.Drawing.Image)
        Me.Btn_FindIns.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_FindIns.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_FindIns.ForeColor = System.Drawing.Color.White
        Me.Btn_FindIns.Location = New System.Drawing.Point(394, 19)
        Me.Btn_FindIns.Name = "Btn_FindIns"
        Me.Btn_FindIns.Size = New System.Drawing.Size(29, 21)
        Me.Btn_FindIns.TabIndex = 100074
        Me.Btn_FindIns.TabStop = False
        Me.Btn_FindIns.Text = "F2"
        Me.Btn_FindIns.UseVisualStyleBackColor = False
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.BackColor = System.Drawing.Color.Transparent
        Me.Label37.ForeColor = System.Drawing.Color.White
        Me.Label37.Location = New System.Drawing.Point(103, 3)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(120, 13)
        Me.Label37.TabIndex = 0
        Me.Label37.Text = "Insurance Company"
        '
        'Cmb_Insurance_Company
        '
        Me.Cmb_Insurance_Company.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Insurance_Company.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Insurance_Company.FormattingEnabled = True
        Me.Cmb_Insurance_Company.Location = New System.Drawing.Point(106, 19)
        Me.Cmb_Insurance_Company.Name = "Cmb_Insurance_Company"
        Me.Cmb_Insurance_Company.Size = New System.Drawing.Size(286, 21)
        Me.Cmb_Insurance_Company.TabIndex = 1
        '
        'Txt_Contact_Person_Fax
        '
        Me.Txt_Contact_Person_Fax.BackColor = System.Drawing.Color.White
        Me.Txt_Contact_Person_Fax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Contact_Person_Fax.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Contact_Person_Fax.Location = New System.Drawing.Point(387, 208)
        Me.Txt_Contact_Person_Fax.MaxLength = 50
        Me.Txt_Contact_Person_Fax.Name = "Txt_Contact_Person_Fax"
        Me.Txt_Contact_Person_Fax.ReadOnly = True
        Me.Txt_Contact_Person_Fax.Size = New System.Drawing.Size(159, 21)
        Me.Txt_Contact_Person_Fax.TabIndex = 100061
        '
        'Txt_Contact_Person_Email
        '
        Me.Txt_Contact_Person_Email.BackColor = System.Drawing.Color.White
        Me.Txt_Contact_Person_Email.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Contact_Person_Email.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Contact_Person_Email.Location = New System.Drawing.Point(387, 153)
        Me.Txt_Contact_Person_Email.MaxLength = 100
        Me.Txt_Contact_Person_Email.Name = "Txt_Contact_Person_Email"
        Me.Txt_Contact_Person_Email.ReadOnly = True
        Me.Txt_Contact_Person_Email.Size = New System.Drawing.Size(159, 21)
        Me.Txt_Contact_Person_Email.TabIndex = 100059
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.BackColor = System.Drawing.Color.Transparent
        Me.Label43.ForeColor = System.Drawing.Color.Black
        Me.Label43.Location = New System.Drawing.Point(328, 158)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(39, 13)
        Me.Label43.TabIndex = 100069
        Me.Label43.Text = "E Mail"
        '
        'Txt_Contact_Person_Mobile
        '
        Me.Txt_Contact_Person_Mobile.BackColor = System.Drawing.Color.White
        Me.Txt_Contact_Person_Mobile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Contact_Person_Mobile.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Contact_Person_Mobile.Location = New System.Drawing.Point(387, 126)
        Me.Txt_Contact_Person_Mobile.MaxLength = 11
        Me.Txt_Contact_Person_Mobile.Name = "Txt_Contact_Person_Mobile"
        Me.Txt_Contact_Person_Mobile.ReadOnly = True
        Me.Txt_Contact_Person_Mobile.Size = New System.Drawing.Size(159, 21)
        Me.Txt_Contact_Person_Mobile.TabIndex = 100058
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.BackColor = System.Drawing.Color.Transparent
        Me.Label44.ForeColor = System.Drawing.Color.Black
        Me.Label44.Location = New System.Drawing.Point(328, 132)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(44, 13)
        Me.Label44.TabIndex = 100068
        Me.Label44.Text = "Mobile"
        '
        'Txt_Contact_Person_Phone
        '
        Me.Txt_Contact_Person_Phone.BackColor = System.Drawing.Color.White
        Me.Txt_Contact_Person_Phone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Contact_Person_Phone.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Contact_Person_Phone.Location = New System.Drawing.Point(387, 180)
        Me.Txt_Contact_Person_Phone.MaxLength = 12
        Me.Txt_Contact_Person_Phone.Name = "Txt_Contact_Person_Phone"
        Me.Txt_Contact_Person_Phone.ReadOnly = True
        Me.Txt_Contact_Person_Phone.Size = New System.Drawing.Size(159, 21)
        Me.Txt_Contact_Person_Phone.TabIndex = 100060
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.BackColor = System.Drawing.Color.Transparent
        Me.Label45.ForeColor = System.Drawing.Color.Black
        Me.Label45.Location = New System.Drawing.Point(328, 184)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(42, 13)
        Me.Label45.TabIndex = 100067
        Me.Label45.Text = "Phone"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.BackColor = System.Drawing.Color.Transparent
        Me.Label46.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.ForeColor = System.Drawing.Color.Black
        Me.Label46.Location = New System.Drawing.Point(328, 210)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(27, 13)
        Me.Label46.TabIndex = 100066
        Me.Label46.Text = "Fax"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.BackColor = System.Drawing.Color.Transparent
        Me.Label47.ForeColor = System.Drawing.Color.Black
        Me.Label47.Location = New System.Drawing.Point(1, 161)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(53, 13)
        Me.Label47.TabIndex = 100065
        Me.Label47.Text = "Address"
        '
        'Txt_Contact_Person_Address
        '
        Me.Txt_Contact_Person_Address.BackColor = System.Drawing.Color.White
        Me.Txt_Contact_Person_Address.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Contact_Person_Address.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Contact_Person_Address.Location = New System.Drawing.Point(106, 154)
        Me.Txt_Contact_Person_Address.MaxLength = 500
        Me.Txt_Contact_Person_Address.Multiline = True
        Me.Txt_Contact_Person_Address.Name = "Txt_Contact_Person_Address"
        Me.Txt_Contact_Person_Address.ReadOnly = True
        Me.Txt_Contact_Person_Address.Size = New System.Drawing.Size(216, 75)
        Me.Txt_Contact_Person_Address.TabIndex = 100057
        '
        'Txt_Contact_Person_Name
        '
        Me.Txt_Contact_Person_Name.BackColor = System.Drawing.Color.White
        Me.Txt_Contact_Person_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Contact_Person_Name.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Contact_Person_Name.Location = New System.Drawing.Point(106, 127)
        Me.Txt_Contact_Person_Name.MaxLength = 250
        Me.Txt_Contact_Person_Name.Name = "Txt_Contact_Person_Name"
        Me.Txt_Contact_Person_Name.ReadOnly = True
        Me.Txt_Contact_Person_Name.Size = New System.Drawing.Size(216, 21)
        Me.Txt_Contact_Person_Name.TabIndex = 100056
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.BackColor = System.Drawing.Color.Transparent
        Me.Label48.ForeColor = System.Drawing.Color.Black
        Me.Label48.Location = New System.Drawing.Point(1, 130)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(39, 13)
        Me.Label48.TabIndex = 100064
        Me.Label48.Text = "Name"
        Me.Label48.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.BackColor = System.Drawing.Color.Transparent
        Me.Label49.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.ForeColor = System.Drawing.Color.White
        Me.Label49.Location = New System.Drawing.Point(1, 108)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(108, 16)
        Me.Label49.TabIndex = 100063
        Me.Label49.Text = "Contact Person"
        Me.Label49.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Button2.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Button2.ForeColor = System.Drawing.Color.White
        Me.Button2.Location = New System.Drawing.Point(106, 111)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(440, 13)
        Me.Button2.TabIndex = 100062
        Me.Button2.TabStop = False
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.BackColor = System.Drawing.Color.Transparent
        Me.Label38.ForeColor = System.Drawing.Color.White
        Me.Label38.Location = New System.Drawing.Point(1, 46)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(53, 13)
        Me.Label38.TabIndex = 100002
        Me.Label38.Text = "Address"
        '
        'Txt_Company_Address
        '
        Me.Txt_Company_Address.BackColor = System.Drawing.Color.White
        Me.Txt_Company_Address.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Company_Address.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Company_Address.Location = New System.Drawing.Point(106, 46)
        Me.Txt_Company_Address.MaxLength = 500
        Me.Txt_Company_Address.Name = "Txt_Company_Address"
        Me.Txt_Company_Address.ReadOnly = True
        Me.Txt_Company_Address.Size = New System.Drawing.Size(440, 21)
        Me.Txt_Company_Address.TabIndex = 2
        '
        'TabPage4
        '
        Me.TabPage4.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.TabPage4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TabPage4.Controls.Add(Me.Panel7)
        Me.TabPage4.Controls.Add(Me.Imageviewer1)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(669, 393)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "TabPage4"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Panel7.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.MainMenu_Bkg
        Me.Panel7.Location = New System.Drawing.Point(508, 0)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(160, 17)
        Me.Panel7.TabIndex = 162
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Delete)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(450, 497)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(230, 37)
        Me.Pnl_Common_Btn.TabIndex = 119
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(113, 3)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear.TabIndex = 31
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(169, 3)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 32
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Delete
        '
        Me.Btn_Delete.BackgroundImage = CType(resources.GetObject("Btn_Delete.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Delete.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Delete.Location = New System.Drawing.Point(58, 3)
        Me.Btn_Delete.Name = "Btn_Delete"
        Me.Btn_Delete.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Delete.TabIndex = 30
        Me.Btn_Delete.Text = "Delete"
        Me.Btn_Delete.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = CType(resources.GetObject("Btn_Save.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(2, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save.TabIndex = 29
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(606, 23)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(74, 21)
        Me.Pnl_Tran_mode.TabIndex = 30000
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(1, 1)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(68, 16)
        Me.Lbl_Tran_Mode.TabIndex = 126
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Btn_FindID
        '
        Me.Btn_FindID.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_FindID.BackgroundImage = CType(resources.GetObject("Btn_FindID.BackgroundImage"), System.Drawing.Image)
        Me.Btn_FindID.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_FindID.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_FindID.ForeColor = System.Drawing.Color.White
        Me.Btn_FindID.Location = New System.Drawing.Point(325, 23)
        Me.Btn_FindID.Name = "Btn_FindID"
        Me.Btn_FindID.Size = New System.Drawing.Size(29, 21)
        Me.Btn_FindID.TabIndex = 100000
        Me.Btn_FindID.TabStop = False
        Me.Btn_FindID.Text = "F2"
        Me.Btn_FindID.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Panel1.Controls.Add(Me.Button3)
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.Btn_Tab2)
        Me.Panel1.Controls.Add(Me.Btn_Tab1)
        Me.Panel1.Location = New System.Drawing.Point(8, 74)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(673, 22)
        Me.Panel1.TabIndex = 122
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Button3.BackgroundImage = CType(resources.GetObject("Button3.BackgroundImage"), System.Drawing.Image)
        Me.Button3.ForeColor = System.Drawing.Color.White
        Me.Button3.Location = New System.Drawing.Point(508, -1)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(163, 28)
        Me.Button3.TabIndex = 34
        Me.Button3.TabStop = False
        Me.Button3.Text = "Photo"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Button1.BackgroundImage = CType(resources.GetObject("Button1.BackgroundImage"), System.Drawing.Image)
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(326, 0)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(181, 28)
        Me.Button1.TabIndex = 33
        Me.Button1.TabStop = False
        Me.Button1.Text = "Insurance Details"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Btn_Tab2
        '
        Me.Btn_Tab2.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Tab2.BackgroundImage = CType(resources.GetObject("Btn_Tab2.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Tab2.ForeColor = System.Drawing.Color.White
        Me.Btn_Tab2.Location = New System.Drawing.Point(163, 0)
        Me.Btn_Tab2.Name = "Btn_Tab2"
        Me.Btn_Tab2.Size = New System.Drawing.Size(163, 28)
        Me.Btn_Tab2.TabIndex = 32
        Me.Btn_Tab2.TabStop = False
        Me.Btn_Tab2.Text = "Other Informations"
        Me.Btn_Tab2.UseVisualStyleBackColor = False
        '
        'Btn_Tab1
        '
        Me.Btn_Tab1.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Tab1.BackgroundImage = CType(resources.GetObject("Btn_Tab1.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Tab1.ForeColor = System.Drawing.Color.White
        Me.Btn_Tab1.Location = New System.Drawing.Point(0, 0)
        Me.Btn_Tab1.Name = "Btn_Tab1"
        Me.Btn_Tab1.Size = New System.Drawing.Size(163, 28)
        Me.Btn_Tab1.TabIndex = 31
        Me.Btn_Tab1.TabStop = False
        Me.Btn_Tab1.Text = "Personal Details"
        Me.Btn_Tab1.UseVisualStyleBackColor = False
        '
        'Panel2
        '
        Me.Panel2.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.LeftGradiant
        Me.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel2.Location = New System.Drawing.Point(2, 74)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(10, 419)
        Me.Panel2.TabIndex = 123
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.BackColor = System.Drawing.Color.Transparent
        Me.Label34.ForeColor = System.Drawing.Color.Red
        Me.Label34.Location = New System.Drawing.Point(95, 46)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(14, 13)
        Me.Label34.TabIndex = 161
        Me.Label34.Text = "*"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.BackColor = System.Drawing.Color.Transparent
        Me.Label35.ForeColor = System.Drawing.Color.Black
        Me.Label35.Location = New System.Drawing.Point(359, 29)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(41, 13)
        Me.Label35.TabIndex = 178
        Me.Label35.Text = "S S No"
        '
        'Txt_Pat_Soc_SecNo
        '
        Me.Txt_Pat_Soc_SecNo.BackColor = System.Drawing.Color.White
        Me.Txt_Pat_Soc_SecNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Pat_Soc_SecNo.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Pat_Soc_SecNo.Location = New System.Drawing.Point(406, 23)
        Me.Txt_Pat_Soc_SecNo.MaxLength = 50
        Me.Txt_Pat_Soc_SecNo.Name = "Txt_Pat_Soc_SecNo"
        Me.Txt_Pat_Soc_SecNo.Size = New System.Drawing.Size(150, 21)
        Me.Txt_Pat_Soc_SecNo.TabIndex = 1
        '
        'Btn_Find2
        '
        Me.Btn_Find2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find2.BackgroundImage = CType(resources.GetObject("Btn_Find2.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find2.ForeColor = System.Drawing.Color.White
        Me.Btn_Find2.Location = New System.Drawing.Point(562, 23)
        Me.Btn_Find2.Name = "Btn_Find2"
        Me.Btn_Find2.Size = New System.Drawing.Size(29, 21)
        Me.Btn_Find2.TabIndex = 10001
        Me.Btn_Find2.TabStop = False
        Me.Btn_Find2.Text = "F2"
        Me.Btn_Find2.UseVisualStyleBackColor = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Panel3.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.MainMenu_Bkg
        Me.Panel3.Location = New System.Drawing.Point(3, -1)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(160, 17)
        Me.Panel3.TabIndex = 161
        '
        'Imageviewer1
        '
        Me.Imageviewer1.CUST_ID = ""
        Me.Imageviewer1.CUST_TYPE = HMS_Common.Common_Cls.Customer_Type.Employee
        Me.Imageviewer1.Location = New System.Drawing.Point(214, 71)
        Me.Imageviewer1.Name = "Imageviewer1"
        Me.Imageviewer1.Scan_Enabled = True
        Me.Imageviewer1.Size = New System.Drawing.Size(230, 263)
        Me.Imageviewer1.TabIndex = 1
        '
        'PatientInformation_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Highlight
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(687, 547)
        Me.Controls.Add(Me.Btn_Find2)
        Me.Controls.Add(Me.Label34)
        Me.Controls.Add(Me.Txt_Pat_Soc_SecNo)
        Me.Controls.Add(Me.Label35)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Pnl_Tran_mode)
        Me.Controls.Add(Me.Btn_FindID)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.Txt_Pat_Name)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Txt_Pat_ID)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "PatientInformation_Frm"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.Pnl_Insurance_Det.ResumeLayout(False)
        Me.Pnl_Insurance_Det.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.Pnl_Tran_mode.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Txt_Pat_ID As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Txt_Pat_Name As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Txt_Pat_Add As System.Windows.Forms.TextBox
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Delete As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Txt_Pat_City As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Pat_Country As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents cmb_Pat_State As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Txt_Pat_Phone2 As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Txt_Pat_Phone1 As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Txt_Pat_Email As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Txt_Pat_Mobile2 As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Txt_Pat_Mobile1 As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Txt_Pat_Pin As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Pat_Gender As System.Windows.Forms.ComboBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents cmb_Pat_Religion As System.Windows.Forms.ComboBox
    Friend WithEvents Txt_Pat_Age As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Txt_Pat_Occupation As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Pat_Martial As System.Windows.Forms.ComboBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Txt_Pat_Employer As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Nominee_Relate As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Txt_Pat_Nominee As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Pat_Remarks As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Pat_FamilyDr As System.Windows.Forms.TextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Btn_FindID As System.Windows.Forms.Button
    Friend WithEvents Btn_New As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Btn_Tab2 As System.Windows.Forms.Button
    Friend WithEvents Btn_Tab1 As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Dtp_LastAdmitDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Cmb_Pat_Insure As System.Windows.Forms.ComboBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Dtp_Pat_RegDt As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Txt_Pat_Identity As System.Windows.Forms.TextBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Pat_Income As System.Windows.Forms.ComboBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Pat_Social As System.Windows.Forms.ComboBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents cmb_Pat_Status As System.Windows.Forms.ComboBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Btn_New1 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Txt_Pat_Soc_SecNo As System.Windows.Forms.TextBox
    Friend WithEvents Btn_Find2 As System.Windows.Forms.Button
    Friend WithEvents Txt_FamilyName As System.Windows.Forms.TextBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents Dtp_Pat_DOB As System.Windows.Forms.MaskedTextBox
    Friend WithEvents Pnl_Insurance_Det As System.Windows.Forms.Panel
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Txt_Company_Address As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Contact_Person_Fax As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Contact_Person_Email As System.Windows.Forms.TextBox
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Txt_Contact_Person_Mobile As System.Windows.Forms.TextBox
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Txt_Contact_Person_Phone As System.Windows.Forms.TextBox
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Txt_Contact_Person_Address As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Contact_Person_Name As System.Windows.Forms.TextBox
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Btn_FindIns As System.Windows.Forms.Button
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Insurance_Company As System.Windows.Forms.ComboBox
    Friend WithEvents Txt_Company_Mob As System.Windows.Forms.TextBox
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Txt_Company_Phone As System.Windows.Forms.TextBox
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents Imageviewer1 As REAL_CLINIC.Imageviewer
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
End Class
