﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DoctorMaster_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(DoctorMaster_Frm))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Delete = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.Btn_Find = New System.Windows.Forms.Button
        Me.Txt_DoctorID = New System.Windows.Forms.TextBox
        Me.Lbl_DocID = New System.Windows.Forms.Label
        Me.Btn_Find1 = New System.Windows.Forms.Button
        Me.Txt_EmpID = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Pnl_CardMas = New System.Windows.Forms.Panel
        Me.Cmb_CommType = New System.Windows.Forms.ComboBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.chk_Doctor_Splization = New System.Windows.Forms.CheckedListBox
        Me.Dgvw_Services = New System.Windows.Forms.DataGridView
        Me.Txt_DoctorFee = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.Cmb_FeeCalcMethod = New System.Windows.Forms.ComboBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.Cmb_DocCategory = New System.Windows.Forms.ComboBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.Btn_New = New System.Windows.Forms.Button
        Me.Dgv_Doc_Achivements = New System.Windows.Forms.DataGridView
        Me.Sl_No = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Achivements = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Txt_Achivements = New System.Windows.Forms.TextBox
        Me.Btn_Add = New System.Windows.Forms.Button
        Me.Label6 = New System.Windows.Forms.Label
        Me.Cmb_status = New System.Windows.Forms.ComboBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Imageviewer1 = New REAL_CLINIC.Imageviewer
        Me.Employee_Info1 = New REAL_CLINIC.Employee_Info
        Me.Pnl_Header.SuspendLayout()
        Me.Pnl_Tran_mode.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.Pnl_CardMas.SuspendLayout()
        CType(Me.Dgvw_Services, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Dgv_Doc_Achivements, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Menu_Bkg
        Me.Pnl_Header.Controls.Add(Me.Label1)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(809, 24)
        Me.Pnl_Header.TabIndex = 100
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(8, 1)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(161, 18)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "D o c t o r   M a s t e r"
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(733, 27)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(74, 22)
        Me.Pnl_Tran_mode.TabIndex = 48
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(1, 1)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(68, 16)
        Me.Lbl_Tran_Mode.TabIndex = 0
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Delete)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(392, 484)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(231, 35)
        Me.Pnl_Common_Btn.TabIndex = 10
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(115, 3)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear.TabIndex = 13
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(171, 3)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 14
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Delete
        '
        Me.Btn_Delete.BackgroundImage = CType(resources.GetObject("Btn_Delete.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Delete.Location = New System.Drawing.Point(59, 3)
        Me.Btn_Delete.Name = "Btn_Delete"
        Me.Btn_Delete.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Delete.TabIndex = 12
        Me.Btn_Delete.Text = "Delete"
        Me.Btn_Delete.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(3, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save.TabIndex = 11
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Btn_Find
        '
        Me.Btn_Find.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find.BackgroundImage = CType(resources.GetObject("Btn_Find.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find.ForeColor = System.Drawing.Color.White
        Me.Btn_Find.Location = New System.Drawing.Point(237, 28)
        Me.Btn_Find.Name = "Btn_Find"
        Me.Btn_Find.Size = New System.Drawing.Size(29, 21)
        Me.Btn_Find.TabIndex = 1
        Me.Btn_Find.TabStop = False
        Me.Btn_Find.Text = "F2"
        Me.Btn_Find.UseVisualStyleBackColor = False
        '
        'Txt_DoctorID
        '
        Me.Txt_DoctorID.BackColor = System.Drawing.Color.White
        Me.Txt_DoctorID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_DoctorID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_DoctorID.Location = New System.Drawing.Point(65, 28)
        Me.Txt_DoctorID.Name = "Txt_DoctorID"
        Me.Txt_DoctorID.Size = New System.Drawing.Size(165, 21)
        Me.Txt_DoctorID.TabIndex = 0
        '
        'Lbl_DocID
        '
        Me.Lbl_DocID.AutoSize = True
        Me.Lbl_DocID.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_DocID.ForeColor = System.Drawing.Color.White
        Me.Lbl_DocID.Location = New System.Drawing.Point(2, 33)
        Me.Lbl_DocID.Name = "Lbl_DocID"
        Me.Lbl_DocID.Size = New System.Drawing.Size(61, 13)
        Me.Lbl_DocID.TabIndex = 50
        Me.Lbl_DocID.Text = "Doctor ID"
        '
        'Btn_Find1
        '
        Me.Btn_Find1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find1.BackgroundImage = CType(resources.GetObject("Btn_Find1.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find1.ForeColor = System.Drawing.Color.White
        Me.Btn_Find1.Location = New System.Drawing.Point(237, 52)
        Me.Btn_Find1.Name = "Btn_Find1"
        Me.Btn_Find1.Size = New System.Drawing.Size(29, 21)
        Me.Btn_Find1.TabIndex = 3
        Me.Btn_Find1.TabStop = False
        Me.Btn_Find1.Text = "F2"
        Me.Btn_Find1.UseVisualStyleBackColor = False
        '
        'Txt_EmpID
        '
        Me.Txt_EmpID.BackColor = System.Drawing.Color.White
        Me.Txt_EmpID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_EmpID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_EmpID.Location = New System.Drawing.Point(65, 52)
        Me.Txt_EmpID.Name = "Txt_EmpID"
        Me.Txt_EmpID.Size = New System.Drawing.Size(165, 21)
        Me.Txt_EmpID.TabIndex = 2
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(3, 55)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(47, 13)
        Me.Label5.TabIndex = 91
        Me.Label5.Text = "Emp ID"
        '
        'Pnl_CardMas
        '
        Me.Pnl_CardMas.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_CardMas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_CardMas.Controls.Add(Me.Cmb_CommType)
        Me.Pnl_CardMas.Controls.Add(Me.Label7)
        Me.Pnl_CardMas.Controls.Add(Me.Label8)
        Me.Pnl_CardMas.Controls.Add(Me.chk_Doctor_Splization)
        Me.Pnl_CardMas.Controls.Add(Me.Dgvw_Services)
        Me.Pnl_CardMas.Controls.Add(Me.Txt_DoctorFee)
        Me.Pnl_CardMas.Controls.Add(Me.Label10)
        Me.Pnl_CardMas.Controls.Add(Me.Cmb_FeeCalcMethod)
        Me.Pnl_CardMas.Controls.Add(Me.Label9)
        Me.Pnl_CardMas.Controls.Add(Me.Cmb_DocCategory)
        Me.Pnl_CardMas.Controls.Add(Me.Label19)
        Me.Pnl_CardMas.Controls.Add(Me.Btn_New)
        Me.Pnl_CardMas.ForeColor = System.Drawing.Color.White
        Me.Pnl_CardMas.Location = New System.Drawing.Point(3, 231)
        Me.Pnl_CardMas.Name = "Pnl_CardMas"
        Me.Pnl_CardMas.Size = New System.Drawing.Size(620, 247)
        Me.Pnl_CardMas.TabIndex = 6
        '
        'Cmb_CommType
        '
        Me.Cmb_CommType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_CommType.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_CommType.FormattingEnabled = True
        Me.Cmb_CommType.ItemHeight = 13
        Me.Cmb_CommType.Location = New System.Drawing.Point(526, 2)
        Me.Cmb_CommType.Name = "Cmb_CommType"
        Me.Cmb_CommType.Size = New System.Drawing.Size(89, 21)
        Me.Cmb_CommType.TabIndex = 2
        Me.Cmb_CommType.Visible = False
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.FromArgb(CType(CType(19, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(153, Byte), Integer))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(232, 55)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(382, 18)
        Me.Label7.TabIndex = 135
        Me.Label7.Text = "S e r v i c e s"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.FromArgb(CType(CType(19, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(153, Byte), Integer))
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(2, 55)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(225, 18)
        Me.Label8.TabIndex = 134
        Me.Label8.Text = "S p e c i a l i z a t i o n s  "
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'chk_Doctor_Splization
        '
        Me.chk_Doctor_Splization.BackColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(236, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.chk_Doctor_Splization.CheckOnClick = True
        Me.chk_Doctor_Splization.FormattingEnabled = True
        Me.chk_Doctor_Splization.Location = New System.Drawing.Point(2, 76)
        Me.chk_Doctor_Splization.Name = "chk_Doctor_Splization"
        Me.chk_Doctor_Splization.Size = New System.Drawing.Size(225, 164)
        Me.chk_Doctor_Splization.TabIndex = 10
        '
        'Dgvw_Services
        '
        Me.Dgvw_Services.AllowUserToAddRows = False
        Me.Dgvw_Services.AllowUserToDeleteRows = False
        Me.Dgvw_Services.AllowUserToResizeColumns = False
        Me.Dgvw_Services.AllowUserToResizeRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(248, Byte), Integer))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.DarkBlue
        Me.Dgvw_Services.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.Dgvw_Services.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(236, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Dgvw_Services.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(75, Byte), Integer), CType(CType(116, Byte), Integer), CType(CType(165, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgvw_Services.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.Dgvw_Services.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Dgvw_Services.Location = New System.Drawing.Point(232, 76)
        Me.Dgvw_Services.Name = "Dgvw_Services"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(179, Byte), Integer))
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgvw_Services.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.Dgvw_Services.RowHeadersVisible = False
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(CType(CType(219, Byte), Integer), CType(CType(227, Byte), Integer), CType(CType(249, Byte), Integer))
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.Color.DarkBlue
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.DeepSkyBlue
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black
        Me.Dgvw_Services.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.Dgvw_Services.Size = New System.Drawing.Size(382, 165)
        Me.Dgvw_Services.TabIndex = 11
        '
        'Txt_DoctorFee
        '
        Me.Txt_DoctorFee.BackColor = System.Drawing.Color.White
        Me.Txt_DoctorFee.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_DoctorFee.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_DoctorFee.Location = New System.Drawing.Point(337, 27)
        Me.Txt_DoctorFee.MaxLength = 15
        Me.Txt_DoctorFee.Name = "Txt_DoctorFee"
        Me.Txt_DoctorFee.Size = New System.Drawing.Size(119, 21)
        Me.Txt_DoctorFee.TabIndex = 4
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(307, 31)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(27, 13)
        Me.Label10.TabIndex = 131
        Me.Label10.Text = "Fee"
        '
        'Cmb_FeeCalcMethod
        '
        Me.Cmb_FeeCalcMethod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_FeeCalcMethod.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_FeeCalcMethod.FormattingEnabled = True
        Me.Cmb_FeeCalcMethod.ItemHeight = 13
        Me.Cmb_FeeCalcMethod.Location = New System.Drawing.Point(144, 25)
        Me.Cmb_FeeCalcMethod.Name = "Cmb_FeeCalcMethod"
        Me.Cmb_FeeCalcMethod.Size = New System.Drawing.Size(121, 21)
        Me.Cmb_FeeCalcMethod.TabIndex = 3
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(1, 28)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(160, 16)
        Me.Label9.TabIndex = 129
        Me.Label9.Text = "Fee Calculation Method"
        '
        'Cmb_DocCategory
        '
        Me.Cmb_DocCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_DocCategory.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_DocCategory.FormattingEnabled = True
        Me.Cmb_DocCategory.ItemHeight = 13
        Me.Cmb_DocCategory.Location = New System.Drawing.Point(144, 2)
        Me.Cmb_DocCategory.Name = "Cmb_DocCategory"
        Me.Cmb_DocCategory.Size = New System.Drawing.Size(313, 21)
        Me.Cmb_DocCategory.TabIndex = 1
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.ForeColor = System.Drawing.Color.White
        Me.Label19.Location = New System.Drawing.Point(1, 5)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(59, 13)
        Me.Label19.TabIndex = 105
        Me.Label19.Text = "Category"
        '
        'Btn_New
        '
        Me.Btn_New.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_New.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Add_3
        Me.Btn_New.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_New.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_New.ForeColor = System.Drawing.Color.White
        Me.Btn_New.Location = New System.Drawing.Point(458, 2)
        Me.Btn_New.Name = "Btn_New"
        Me.Btn_New.Size = New System.Drawing.Size(27, 21)
        Me.Btn_New.TabIndex = 7
        Me.Btn_New.TabStop = False
        Me.Btn_New.UseVisualStyleBackColor = False
        Me.Btn_New.Visible = False
        '
        'Dgv_Doc_Achivements
        '
        Me.Dgv_Doc_Achivements.AllowUserToAddRows = False
        Me.Dgv_Doc_Achivements.AllowUserToDeleteRows = False
        Me.Dgv_Doc_Achivements.AllowUserToResizeColumns = False
        Me.Dgv_Doc_Achivements.AllowUserToResizeRows = False
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(248, Byte), Integer))
        DataGridViewCellStyle5.ForeColor = System.Drawing.Color.DarkBlue
        Me.Dgv_Doc_Achivements.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle5
        Me.Dgv_Doc_Achivements.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(236, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Dgv_Doc_Achivements.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(CType(CType(75, Byte), Integer), CType(CType(116, Byte), Integer), CType(CType(165, Byte), Integer))
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgv_Doc_Achivements.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.Dgv_Doc_Achivements.ColumnHeadersHeight = 20
        Me.Dgv_Doc_Achivements.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Sl_No, Me.Achivements})
        Me.Dgv_Doc_Achivements.Location = New System.Drawing.Point(462, 101)
        Me.Dgv_Doc_Achivements.Name = "Dgv_Doc_Achivements"
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(179, Byte), Integer))
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgv_Doc_Achivements.RowHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.Dgv_Doc_Achivements.RowHeadersVisible = False
        DataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(CType(CType(219, Byte), Integer), CType(CType(227, Byte), Integer), CType(CType(249, Byte), Integer))
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.Color.DarkBlue
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.DeepSkyBlue
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.Black
        Me.Dgv_Doc_Achivements.RowsDefaultCellStyle = DataGridViewCellStyle8
        Me.Dgv_Doc_Achivements.Size = New System.Drawing.Size(344, 119)
        Me.Dgv_Doc_Achivements.TabIndex = 133
        Me.Dgv_Doc_Achivements.TabStop = False
        '
        'Sl_No
        '
        Me.Sl_No.HeaderText = "No"
        Me.Sl_No.Name = "Sl_No"
        Me.Sl_No.ReadOnly = True
        Me.Sl_No.Width = 40
        '
        'Achivements
        '
        Me.Achivements.HeaderText = "Achivements"
        Me.Achivements.Name = "Achivements"
        Me.Achivements.Width = 300
        '
        'Txt_Achivements
        '
        Me.Txt_Achivements.BackColor = System.Drawing.Color.White
        Me.Txt_Achivements.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Achivements.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Achivements.Location = New System.Drawing.Point(462, 77)
        Me.Txt_Achivements.MaxLength = 300
        Me.Txt_Achivements.Name = "Txt_Achivements"
        Me.Txt_Achivements.Size = New System.Drawing.Size(306, 21)
        Me.Txt_Achivements.TabIndex = 4
        '
        'Btn_Add
        '
        Me.Btn_Add.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Add.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Add.ForeColor = System.Drawing.Color.White
        Me.Btn_Add.Location = New System.Drawing.Point(769, 76)
        Me.Btn_Add.Name = "Btn_Add"
        Me.Btn_Add.Size = New System.Drawing.Size(37, 22)
        Me.Btn_Add.TabIndex = 5
        Me.Btn_Add.TabStop = False
        Me.Btn_Add.Text = "&Add"
        Me.Btn_Add.UseVisualStyleBackColor = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(465, 59)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(81, 13)
        Me.Label6.TabIndex = 136
        Me.Label6.Text = "Achivements"
        '
        'Cmb_status
        '
        Me.Cmb_status.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_status.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_status.FormattingEnabled = True
        Me.Cmb_status.Location = New System.Drawing.Point(147, 206)
        Me.Cmb_status.Name = "Cmb_status"
        Me.Cmb_status.Size = New System.Drawing.Size(71, 21)
        Me.Cmb_status.TabIndex = 139
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(5, 209)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(43, 13)
        Me.Label3.TabIndex = 140
        Me.Label3.Text = "Active"
        '
        'Imageviewer1
        '
        Me.Imageviewer1.CUST_ID = ""
        Me.Imageviewer1.CUST_TYPE = HMS_Common.Common_Cls.Customer_Type.Employee
        Me.Imageviewer1.Location = New System.Drawing.Point(627, 231)
        Me.Imageviewer1.Name = "Imageviewer1"
        Me.Imageviewer1.Scan_Enabled = True
        Me.Imageviewer1.Size = New System.Drawing.Size(178, 247)
        Me.Imageviewer1.TabIndex = 138
        '
        'Employee_Info1
        '
        Me.Employee_Info1.BackColor = System.Drawing.Color.AliceBlue
        Me.Employee_Info1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Employee_Info1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Employee_Info1.ForeColor = System.Drawing.Color.DarkBlue
        Me.Employee_Info1.Location = New System.Drawing.Point(65, 76)
        Me.Employee_Info1.Name = "Employee_Info1"
        Me.Employee_Info1.Padding = New System.Windows.Forms.Padding(2)
        Me.Employee_Info1.Size = New System.Drawing.Size(395, 124)
        Me.Employee_Info1.TabIndex = 137
        '
        'DoctorMaster_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(809, 525)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Cmb_status)
        Me.Controls.Add(Me.Imageviewer1)
        Me.Controls.Add(Me.Employee_Info1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Btn_Add)
        Me.Controls.Add(Me.Txt_Achivements)
        Me.Controls.Add(Me.Dgv_Doc_Achivements)
        Me.Controls.Add(Me.Pnl_CardMas)
        Me.Controls.Add(Me.Txt_EmpID)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Btn_Find1)
        Me.Controls.Add(Me.Txt_DoctorID)
        Me.Controls.Add(Me.Lbl_DocID)
        Me.Controls.Add(Me.Pnl_Tran_mode)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.Btn_Find)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "DoctorMaster_Frm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Pnl_Tran_mode.ResumeLayout(False)
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.Pnl_CardMas.ResumeLayout(False)
        Me.Pnl_CardMas.PerformLayout()
        CType(Me.Dgvw_Services, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Dgv_Doc_Achivements, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Delete As System.Windows.Forms.Button
    Friend WithEvents Btn_Find As System.Windows.Forms.Button
    Friend WithEvents Txt_DoctorID As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_DocID As System.Windows.Forms.Label
    Friend WithEvents Btn_Find1 As System.Windows.Forms.Button
    Friend WithEvents Txt_EmpID As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Pnl_CardMas As System.Windows.Forms.Panel
    Friend WithEvents Txt_DoctorFee As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Cmb_FeeCalcMethod As System.Windows.Forms.ComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Cmb_DocCategory As System.Windows.Forms.ComboBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Btn_New As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents chk_Doctor_Splization As System.Windows.Forms.CheckedListBox
    Friend WithEvents Dgvw_Services As System.Windows.Forms.DataGridView
    Friend WithEvents Cmb_CommType As System.Windows.Forms.ComboBox
    Friend WithEvents Dgv_Doc_Achivements As System.Windows.Forms.DataGridView
    Friend WithEvents Txt_Achivements As System.Windows.Forms.TextBox
    Friend WithEvents Btn_Add As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Employee_Info1 As REAL_CLINIC.Employee_Info
    Friend WithEvents Sl_No As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Achivements As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Imageviewer1 As REAL_CLINIC.Imageviewer
    Friend WithEvents Cmb_status As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
End Class
