﻿Imports HMS_BL
Imports HMS_Common.Common_Cls

Public Class Discharge_Frm

#Region "Declarations"
    'Object of Patient Details Bussiness Layer
    ' Private Doctor_BL As OutPatient_BL_Cls

    Private hms_helper As HMS_Helper = Nothing
    Private mReq_Ctrl As Object = Nothing
    Private mTr_Mode As Long
    Private Com_BL As HMS_Common_BL_Cls
    Private Pat_Discharge_BL As Pateint_Discharge_BL_Cls

    Private Patient_Tran_BL As Patient_Transaction_BL_Cls
    Private Patient_Tran_Bill_BL As Patient_Transaction_Bill_BL_Cls

    Private mRpt_Vwr As ReportViewer_Cls
    Private Rpt_BL As HMS_BL.Reports_BL_Cls

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing

    Dim IntRow As Integer
    Dim IntSelectRow As Integer

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"

                    Me.Txt_PMRID.BackColor = Color.White
                    Me.Txt_PMRID.ReadOnly = False
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_PMRID.ReadOnly = True
                    Me.Txt_PMRID.BackColor = Color.Silver
            End Select
        End Set
    End Property
#End Region

#Region "Method"

    Private Function Locate_PMR_info(ByVal PMR_ID As String, ByVal Br_Code As Integer) As Boolean
        Try


            Dim Dtbl As DataTable = Nothing
            hms_helper = New Hms_Helperimpliments

            '-----------------  Locate Pateint Medical Record Master info   -------------
            If Not hms_helper.Get_PMR_Masterinfo(Dtbl, PMR_ID, Br_Code) Then Return False

            With Dtbl
                Txt_Patient_ID.Text = .Rows(0).Item("Patient ID").ToString
                If UCase(.Rows(0).Item("Account Status").ToString()) = "INACTIVE" Then
                    ChkClose.Checked = True
                Else
                    ChkClose.Checked = False
                End If
            End With

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Show_Patient_Bills(ByVal PMR_ID As String)
        Try
            Com_BL = New HMS_Common_BL_Cls
            Dim Sr_Dtbl As DataTable = Nothing
            Pat_Discharge_BL = New Pateint_Discharge_BL_Cls
            If Pat_Discharge_BL.Get_Patient_Tran_Bills(Dtbl, PMR_ID, Tran_Date, Branch_Code) > 0 Then
                With Dtbl
                    Dgrd_Patient_Bills.RowCount = .Rows.Count
                    For i = 0 To .Rows.Count - 1
                        Dgrd_Patient_Bills.Rows(i).Cells("Bill_No").Value = .Rows(i).Item("PatientTran_BatchID").ToString
                        Dgrd_Patient_Bills.Rows(i).Cells("Tr_Date").Value = Format(.Rows(i).Item("Tr_Date"), "dd/MM/yyyy")
                        Dgrd_Patient_Bills.Rows(i).Cells("Tran_Amount").Value = .Rows(i).Item("BillAmt").ToString
                    Next
                End With
            End If
            Dim BillAmt As Single
            With Dgrd_Patient_Bills
                For i = 0 To .Rows.Count - 1
                    BillAmt = BillAmt + .Rows(i).Cells("Tran_Amount").Value.ToString.Trim
                Next
            End With
            Lbl_Bill_Amt.Text = Format(BillAmt, "0.00")

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try
    End Sub

    Private Sub Show_Patient_Payments(ByVal PMR_ID As String)
        Try
            Com_BL = New HMS_Common_BL_Cls
            Dim Sr_Dtbl As DataTable = Nothing
            Pat_Discharge_BL = New Pateint_Discharge_BL_Cls
            If Pat_Discharge_BL.Get_Patient_Payments(Dtbl, Txt_PMRID.Text, Tran_Date, Branch_Code) > 0 Then
                With Dtbl
                    Dgrd_Patient_Payments.RowCount = .Rows.Count
                    For i = 0 To .Rows.Count - 1
                        Dgrd_Patient_Payments.Rows(i).Cells("V_No").Value = .Rows(i).Item("Voucher_No").ToString
                        Dgrd_Patient_Payments.Rows(i).Cells("Paid_Date").Value = Format(.Rows(i).Item("Voucher_Date"), "dd/MM/yyyy")
                        Dgrd_Patient_Payments.Rows(i).Cells("Pay_Type").Value = .Rows(i).Item("Particulars").ToString
                        Dgrd_Patient_Payments.Rows(i).Cells("Paid_Amount").Value = .Rows(i).Item("Paid_Amt").ToString
                    Next
                End With
            End If
            Dim PaidAmt As Single
            With Dgrd_Patient_Payments
                For i = 0 To .Rows.Count - 1
                    PaidAmt = PaidAmt + .Rows(i).Cells("Paid_Amount").Value.ToString.Trim
                Next
            End With
            Lbl_Paid_Amt.Text = Format(PaidAmt, "0.00")

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try
    End Sub

    Private Sub Show_Deposit_Balance(ByVal PMR_ID As String)
        Try
            Com_BL = New HMS_Common_BL_Cls
            Dim Sr_Dtbl As DataTable = Nothing
            Dim Deposit_Bal As Single
            Pat_Discharge_BL = New Pateint_Discharge_BL_Cls
            If Pat_Discharge_BL.Get_Deposit_Balance(Dtbl, Txt_PMRID.Text, Tran_Date, Branch_Code) > 0 Then
                Deposit_Bal = (Dtbl.Rows(0).Item("Paid_Amt").ToString)
                Lbl_Deposit_Bal.Text = Format(Deposit_Bal, "0.00")
            End If

            'Lbl_Deposit_Bal.Text = Format(Lbl_Deposit_Bal.Text, "0.00")

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try
    End Sub

    Private Sub Show_Patient_Deposits(ByVal PMR_ID As String)
        Try
            Com_BL = New HMS_Common_BL_Cls
            Dim Sr_Dtbl As DataTable = Nothing
            Pat_Discharge_BL = New Pateint_Discharge_BL_Cls
            If Pat_Discharge_BL.Get_Patient_Deposits(Dtbl, Txt_PMRID.Text, Tran_Date, Branch_Code) > 0 Then
                With Dtbl
                    Dgrd_Patient_Deposit.RowCount = .Rows.Count
                    For i = 0 To .Rows.Count - 1
                        Dgrd_Patient_Deposit.Rows(i).Cells("Inv_No").Value = .Rows(i).Item("Voucher_No").ToString
                        Dgrd_Patient_Deposit.Rows(i).Cells("Deposit_DT").Value = Format(.Rows(i).Item("Voucher_Date"), "dd/MM/yyyy")
                        Dgrd_Patient_Deposit.Rows(i).Cells("Deposit_Type").Value = .Rows(i).Item("Particulars").ToString
                        Dgrd_Patient_Deposit.Rows(i).Cells("Deposit_Amount").Value = .Rows(i).Item("Paid_Amt").ToString
                    Next
                End With
            End If
            Dim PaidAmt As Single
            With Dgrd_Patient_Payments
                For i = 0 To .Rows.Count - 1
                    PaidAmt = PaidAmt + .Rows(i).Cells("Paid_Amount").Value.ToString.Trim
                Next
            End With
            Lbl_Paid_Amt.Text = Format(PaidAmt, "0.00")

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try
    End Sub

    Private Function Assigntocontrols(ByVal D_Table As DataTable) As Boolean
        Try
            Dr = D_Table.CreateDataReader()
            Dr.Read()
            With Dr
                Txt_Discharge_ID.Text = .Item("Dischg_ID")
            End With
            Tr_Mode = Tran_Mode.Edit_Mode
            Btn_Cancel.Enabled = True
            Btn_Save.Enabled = False
        Catch ex As Exception

        End Try
    End Function

    Private Function Validate_Fields() As Boolean
        Try
            If Txt_PMRID.Text.Trim = "" Then MessageBox.Show("Invalid PMR ID ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_PMRID.Focus() : Exit Function
            Return True
        Catch ex As Exception

        End Try
    End Function

    Private Function Locate_Discharge_Details(ByVal Discharge_ID As Long) As Boolean
        Try
            Pat_Discharge_BL = New Pateint_Discharge_BL_Cls
            Dim Dtbl As DataTable = Nothing
            If Pat_Discharge_BL.Get_Patient_Discharge(Dtbl, Discharge_ID) Then
                With Dtbl
                    Txt_Discharge_ID.Tag = .Rows(0).Item("ACC_ID").ToString
                    Txt_PMRID.Text = .Rows(0).Item("ACC_ID").ToString
                    Txt_Patient_ID.Text = .Rows(0).Item("Patient_ID").ToString
                    If Locate_PMR_info(Txt_PMRID.Text.Trim, Branch_Code) Then

                    End If
                    Call Show_Bill_Details(Txt_PMRID.Text.Trim)
                    Return True
                End With
            Else
                Return False
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try
    End Function

    Private Sub Clear_Form()
        Try
            Txt_Discharge_ID.Text = ""
            Txt_Discharge_ID.Tag = ""
            Txt_Patient_ID.Text = ""
            Txt_PMRID.Text = ""
            Grid_Bill_Dt.RowCount = 0
            Dgrd_Patient_Bills.RowCount = 0
            Dgrd_Patient_Payments.RowCount = 0
            Dgrd_Patient_Deposit.RowCount = 0

            Lbl_Bill_Amt.Text = "0.00"
            Lbl_Paid_Amt.Text = "0.00"
            Lbl_Balance.Text = "0.00"
            Lbl_Less_Pay.Text = "0.00"
            Lbl_Deposit_Bal.Text = "0.00"

            Btn_Save.Enabled = True
            Btn_Cancel.Enabled = False
            Tr_Mode = Tran_Mode.New_Mode
            ChkClose.Checked = False
        Catch ex As Exception

        End Try
    End Sub

#End Region

    Private Sub Txt_PMRID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_PMRID.Validating
        Try
            If Txt_PMRID.Text.Trim <> "" And Txt_PMRID.Tag <> Txt_PMRID.Text.Trim Then
                If Locate_PMR_info(Txt_PMRID.Text.Trim, Branch_Code) Then
                    e.Cancel = False
                    'Txt_Doctor_ID.Focus()
                Else
                    MessageBox.Show("Invalid Account id", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    e.Cancel = True
                End If
            End If
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Discharge_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then Call SendKeyTab()
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Btn_PMRFind_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_PMRFind.Click
        Try
            If Txt_PMRID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "200|50|275|70|"

                Sql = "SELECT [Patient Name], [S.S.No], ([Family Name] +' , ' + Address +' , '+ City) as Address, ACC_ID AS [PMR-ID]"
                Sql += "FROM Patient_Account_Vw WHERE ([Account Status] = 'Active') And Br_Code='" & Branch_Code & "'"

                Call ShowSearchengine(Txt_PMRID, Sql, 3, "[Patient Name]", Colwidth, , 0)
            End If
            'Validating Mandatory fields for locating
            If Txt_PMRID.Text.Trim = "" Then
                'MessageBox.Show("Invalid Appointment ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_PMRID.Focus() : Exit Sub
            End If

            If Locate_PMR_info(Txt_PMRID.Text.Trim, Branch_Code) Then
                Call Show_Bill_Details(Txt_PMRID.Text.Trim)
            Else
                MessageBox.Show("Invalid PMR ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Show_Bill_Details(ByVal PatAccId As String)
        Try


            Call Show_Patient_Bills(PatAccId)
            Call Show_Patient_Deposits(PatAccId)
            Call Show_Patient_Payments(PatAccId)
            Call Show_Deposit_Balance(PatAccId)

            Lbl_BalText.Visible = True
            Lbl_Balance.Visible = True
            Pnl_Common_Btn.Enabled = True
            'If Val(Lbl_Bill_Amt.Text) <> Val(Lbl_Paid_Amt.Text) Then
            '    Pnl_Common_Btn.Enabled = False
            'Else
            '    Pnl_Common_Btn.Enabled = True
            'End If

            If Val(Lbl_Bill_Amt.Text) > (Val(Lbl_Paid_Amt.Text) + Val(Lbl_Deposit_Bal.Text)) Then
                Lbl_BalText.Text = "Balance Receivable :"
                Lbl_Balance.Text = Format(Val(Lbl_Bill_Amt.Text) - (Val(Lbl_Paid_Amt.Text) + Val(Lbl_Deposit_Bal.Text)), "0.00")
            Else
                Lbl_BalText.Text = "Balance Payable :"
                Lbl_Balance.Text = Format((Val(Lbl_Paid_Amt.Text) + Val(Lbl_Deposit_Bal.Text)) - Val(Lbl_Bill_Amt.Text), "0.00")
            End If

            Lbl_BalText.Left = 114
            Lbl_BalText.Top = 528
            Lbl_Balance.Left = 271
            Lbl_Balance.Top = 528

            Lbl_Less_Pay.Text = Lbl_Paid_Amt.Text
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_PMRID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_PMRID.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then
                Call Btn_PMRFind_Click(sender, e)
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Patient_ID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Patient_ID.TextChanged
        Try
            With Patient_Info1
                .Viewmoreform_Name = "Patient_InfoSheet_Frm"
                .MDIform_Name = Me.MdiParent
                If Txt_Patient_ID.Text.Trim <> "" Then .Patient_ID = Txt_Patient_ID.Text.Trim
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Discharge_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Discharge_Find.Click
        Try
            If Txt_Discharge_ID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "150|75|225|75"

                Sql = "Select Name,ACC_ID AS [PMR-ID],([Family Name] +' , ' + Address +' , '+ City) as Address, Dischg_ID,Date from Discharge_Details_Vw where Cancelled = 'N' and Br_Code=" & Branch_Code & " "

                Call ShowSearchengine(Txt_Discharge_ID, Sql, 3, "Name", Colwidth, , 0)
            End If
            If Txt_Discharge_ID.Text.Trim = "" Then
                Txt_Discharge_ID.Focus() : Exit Sub
            End If

            If Txt_Discharge_ID.Text.Trim <> "" Then
                If Locate_Discharge_Details(Txt_Discharge_ID.Text.Trim) Then
                    Tr_Mode = Tran_Mode.Edit_Mode
                    Btn_Cancel.Enabled = True
                    'Btn_Save.Enabled = False                  
                Else
                    MessageBox.Show("Invalid or Cancelled Discharge Id", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Btn_Cancel.Enabled = False
                    Tr_Mode = Tran_Mode.New_Mode
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try
            If Not Validate_Fields() Then Exit Sub
            Dim Is_Close As String
            If ChkClose.Checked = True Then
                Is_Close = "Y"
            Else
                Is_Close = "N"
            End If

            Pat_Discharge_BL = New Pateint_Discharge_BL_Cls
            With Pat_Discharge_BL
                .Dischg_ID = IIf(Tr_Mode <> Tran_Mode.New_Mode, Txt_Discharge_ID.Text.Trim, 0)
                .Dischg_Date = Tran_Date
                .Patient_ID = Trim(Txt_Patient_ID.Text)
                .ACC_ID = Trim(Txt_PMRID.Text)
                .Dischg_Status = 84

                Dtbl = Nothing
                If Pat_Discharge_BL.Save_Patient_Discharge(Dtbl, Tr_Mode, IIf(Tr_Mode <> Tran_Mode.New_Mode, Txt_PMRID.Text.Trim, 0), Is_Close) Then
                    MessageBox.Show("Patient Discharged Sucessfully", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    ' Call Clear_Form()                    '
                    If Assigntocontrols(Dtbl) Then

                    End If

                    Txt_Discharge_ID.Focus()
                Else
                    MessageBox.Show(" Patient Discharge Failed", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If

            End With
        Catch ex As Exception
        End Try
    End Sub

    Private Sub Dgrd_Patient_Bills_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Dgrd_Patient_Bills.DoubleClick
        Try

            Com_BL = New HMS_Common_BL_Cls
            Dim Bill_Dtbl As DataTable = Nothing
            Dim Str_Batch As String
            Str_Batch = Dgrd_Patient_Bills.Rows(Dgrd_Patient_Bills.CurrentRow.Index).Cells("Bill_No").Value.ToString.Trim
            Dim StrQry As String = ""
            StrQry = "Select PatientTran_BatchID as [Bill No],Tr_Date as [Date],Exp_Name as [Particulars],Tr_Amount as [Amount] from Get_Patient_Transaction_Vw where ACC_ID = '" & Txt_PMRID.Text & "' and PatientTran_BatchID = '" & Str_Batch & "'"

            If Com_BL.Get_Data(StrQry, Bill_Dtbl) Then
                With Grid_Bill_Dt
                    .DataSource = Nothing
                    .DataSource = Bill_Dtbl

                    .Refresh()
                    .Columns(0).AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells
                    .Columns(1).AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells
                    .Columns(2).MinimumWidth = 125
                    .Columns(3).MinimumWidth = 20
                    .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight
                    Pnl_Bill_Dt.Visible = True
                End With
            End If

        Catch ex As Exception

        End Try

    End Sub

    Private Sub Grid_Bill_Dt_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Pnl_Bill_Dt.Visible = False
    End Sub

    Private Sub Btn_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Cancel.Click
        Try
            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If

            If Txt_Discharge_ID.Text.Trim = "" Then
                MessageBox.Show("Invalid Discharge ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_Discharge_ID.Focus() : Exit Sub
            End If

            'Confirm before delete the record
            'If MessageBox.Show("Are you sure wan't to cancel the discharge", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = Windows.Forms.DialogResult.No Then
            '    Exit Sub
            'End If

            Pat_Discharge_BL = New Pateint_Discharge_BL_Cls
            If MessageBox.Show("Are you sure wan't to Cancel the selected Discharged Details", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                If Pat_Discharge_BL.Cancell_Discharge_Register(Dtbl, Txt_Discharge_ID.Text.Trim, Tran_Date, Branch_Code) Then
                    MessageBox.Show("Discharge Details Cancelled successfully", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Call Clear_Form()
                Else
                    MessageBox.Show("You Cannot Cancell this discharge details" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            End If

        Catch ex As Exception
        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Call Clear_Form()
        Txt_Discharge_ID.Focus()
    End Sub

    Private Sub Txt_Discharge_ID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Discharge_ID.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then
                Call Btn_Discharge_Find_Click(sender, e)
            End If
        Catch ex As Exception

        End Try
        
    End Sub

    Private Sub Txt_Discharge_ID_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Discharge_ID.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Discharge_ID.Text, Data_Type.Integer_Type, 12))
        Catch ex As Exception

        End Try

    End Sub
   
    Private Sub Txt_Discharge_ID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_Discharge_ID.Validating
        Try
            If Txt_Discharge_ID.Text.Trim <> "" And Me.Txt_Discharge_ID.Text.Trim <> Me.Txt_Discharge_ID.Tag Then
                If Locate_Discharge_Details(Txt_Discharge_ID.Text.Trim) Then
                    Btn_Cancel.Enabled = True
                    Txt_PMRID.Focus()
                Else
                    MessageBox.Show("Invalid or Cancelled Discharge Id", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Btn_Cancel.Enabled = False
                    Tr_Mode = Tran_Mode.New_Mode
                    e.Cancel = True
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_PMRID_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_PMRID.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_PMRID.Text, Data_Type.Integer_Type, 12))
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Discharge_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub Discharge_Frm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            With Dgrd_Patient_Payments
                .Columns("Paid_Amount").HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight
            End With
            With Dgrd_Patient_Bills
                .Columns("Tran_Amount").HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight
            End With

            With Dgrd_Patient_Deposit
                .Columns("Deposit_Amount").HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight
            End With
            Btn_Cancel.Enabled = False
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Discharge_Sum_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Discharge_Sum.Click
        Try

            Pat_Discharge_BL = New Pateint_Discharge_BL_Cls
            'If Txt_PatientID.Text = "" Then MessageBox.Show("Invalid  Patient  ID .. Please enter valid Tran Id", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Exit Sub

            Dim Rpt_Ds As DataSet = Nothing
            Dim Rpt_Formulafields As String = "Company| " & Company_Name & "|Branch|" & Branch_Name
            Dim Rpt_Filename As String = ""
            Dim mReport_ID As String = ""
            Dim Report_Heading As String = ""
            Dim Add_Query As String = ""
            Dim Amt As Double


            mRpt_Vwr = New ReportViewer_Cls

            Add_Query = ""
            Rpt_Filename = File_Path & "\Patient_Discharge_SumDet.rpt"
            Rpt_BL = New HMS_BL.Reports_BL_Cls


            If Pat_Discharge_BL.Get_Patient_Discharge_Bill(Rpt_Ds, Txt_PMRID.Text, Tran_Date, Branch_Code) Then
                Report_Heading = "|Heading|Patient Discharge Details As on " & Tran_Date & " |Footer3|Authorised Signatory"
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading & "|words|" & Towords(Amt)
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "", "", Nothing)

            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Grid_Bill_Dt_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Grid_Bill_Dt.CellContentClick
        Pnl_Bill_Dt.Visible = False
    End Sub

    Private Sub Dgrd_Patient_Payments_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgrd_Patient_Payments.CellContentClick

    End Sub
End Class