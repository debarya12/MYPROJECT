﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Patient_Diagnosis_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Patient_Diagnosis_Frm))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Label3 = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Btn_Find_Account = New System.Windows.Forms.Button
        Me.Btn_Find = New System.Windows.Forms.Button
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Dtp_TranDate = New System.Windows.Forms.DateTimePicker
        Me.TXT_Acc_ID = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.TXT_OP_ID = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Txt_Patient_ID = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Panel4 = New System.Windows.Forms.Panel
        Me.Lbl_Doctordetails = New System.Windows.Forms.Label
        Me.Cmb_Active = New System.Windows.Forms.ComboBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.Btn_FindDr = New System.Windows.Forms.Button
        Me.Txt_Doctor_ID = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.Cmb_Diagnose = New System.Windows.Forms.ComboBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Btn_Remove = New System.Windows.Forms.Button
        Me.Btn_Add = New System.Windows.Forms.Button
        Me.Label9 = New System.Windows.Forms.Label
        Me.Txt_Current_Stat = New System.Windows.Forms.TextBox
        Me.Txt_Comments = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Panel5 = New System.Windows.Forms.Panel
        Me.Btn_Delete = New System.Windows.Forms.Button
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.Dgv_Diagnosis = New REAL_CLINIC.Hms_DGridview(Me.components)
        Me.Diagnosis = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Comments = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Status = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Active = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.DiagID = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.TR_DT = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Doctor = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.De_Active_Date = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DiagnosisID = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DoctorID = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Patient_Info1 = New REAL_CLINIC.Patient_Info
        Me.Pnl_Header.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Pnl_Tran_mode.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        CType(Me.Dgv_Diagnosis, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = CType(resources.GetObject("Pnl_Header.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Header.Controls.Add(Me.Label3)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(700, 24)
        Me.Pnl_Header.TabIndex = 101
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(8, 1)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(202, 18)
        Me.Label3.TabIndex = 121
        Me.Label3.Text = "P a t i e n t    D i a g n o s i s"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Btn_Find_Account)
        Me.Panel1.Controls.Add(Me.Btn_Find)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Controls.Add(Me.Dtp_TranDate)
        Me.Panel1.Controls.Add(Me.TXT_Acc_ID)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 24)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(700, 34)
        Me.Panel1.TabIndex = 1072
        '
        'Btn_Find_Account
        '
        Me.Btn_Find_Account.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find_Account.BackgroundImage = CType(resources.GetObject("Btn_Find_Account.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find_Account.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find_Account.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find_Account.ForeColor = System.Drawing.Color.White
        Me.Btn_Find_Account.Location = New System.Drawing.Point(229, 6)
        Me.Btn_Find_Account.Name = "Btn_Find_Account"
        Me.Btn_Find_Account.Size = New System.Drawing.Size(28, 21)
        Me.Btn_Find_Account.TabIndex = 1
        Me.Btn_Find_Account.TabStop = False
        Me.Btn_Find_Account.Text = "F2"
        Me.Btn_Find_Account.UseVisualStyleBackColor = False
        '
        'Btn_Find
        '
        Me.Btn_Find.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find.BackgroundImage = CType(resources.GetObject("Btn_Find.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find.ForeColor = System.Drawing.Color.White
        Me.Btn_Find.Location = New System.Drawing.Point(153, -21)
        Me.Btn_Find.Name = "Btn_Find"
        Me.Btn_Find.Size = New System.Drawing.Size(28, 21)
        Me.Btn_Find.TabIndex = 1
        Me.Btn_Find.TabStop = False
        Me.Btn_Find.Text = "F2"
        Me.Btn_Find.UseVisualStyleBackColor = False
        Me.Btn_Find.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(2, -16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(77, 13)
        Me.Label2.TabIndex = 1082
        Me.Label2.Text = "Diagnosis ID"
        Me.Label2.Visible = False
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(291, 9)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(34, 13)
        Me.Label16.TabIndex = 1078
        Me.Label16.Text = "Date"
        '
        'Dtp_TranDate
        '
        Me.Dtp_TranDate.CustomFormat = " dd/MM/yyyy"
        Me.Dtp_TranDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_TranDate.Location = New System.Drawing.Point(327, 5)
        Me.Dtp_TranDate.Name = "Dtp_TranDate"
        Me.Dtp_TranDate.Size = New System.Drawing.Size(95, 21)
        Me.Dtp_TranDate.TabIndex = 2
        '
        'TXT_Acc_ID
        '
        Me.TXT_Acc_ID.BackColor = System.Drawing.Color.White
        Me.TXT_Acc_ID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TXT_Acc_ID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXT_Acc_ID.Location = New System.Drawing.Point(81, 6)
        Me.TXT_Acc_ID.MaxLength = 15
        Me.TXT_Acc_ID.Name = "TXT_Acc_ID"
        Me.TXT_Acc_ID.Size = New System.Drawing.Size(147, 21)
        Me.TXT_Acc_ID.TabIndex = 0
        Me.TXT_Acc_ID.Tag = ""
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(1, 10)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 13)
        Me.Label1.TabIndex = 1076
        Me.Label1.Text = "PMR - ID"
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(546, 34)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(75, 22)
        Me.Pnl_Tran_mode.TabIndex = 1083
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(1, 1)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(68, 16)
        Me.Lbl_Tran_Mode.TabIndex = 126
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Transparent
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.Patient_Info1)
        Me.Panel2.Controls.Add(Me.TXT_OP_ID)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.Txt_Patient_ID)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 58)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(700, 124)
        Me.Panel2.TabIndex = 1080
        '
        'TXT_OP_ID
        '
        Me.TXT_OP_ID.BackColor = System.Drawing.Color.White
        Me.TXT_OP_ID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TXT_OP_ID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXT_OP_ID.Location = New System.Drawing.Point(81, 41)
        Me.TXT_OP_ID.MaxLength = 10
        Me.TXT_OP_ID.Name = "TXT_OP_ID"
        Me.TXT_OP_ID.ReadOnly = True
        Me.TXT_OP_ID.Size = New System.Drawing.Size(176, 21)
        Me.TXT_OP_ID.TabIndex = 4
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(2, 43)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(38, 13)
        Me.Label5.TabIndex = 1083
        Me.Label5.Text = "OP.ID"
        '
        'Txt_Patient_ID
        '
        Me.Txt_Patient_ID.BackColor = System.Drawing.Color.White
        Me.Txt_Patient_ID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Patient_ID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Patient_ID.Location = New System.Drawing.Point(81, 6)
        Me.Txt_Patient_ID.MaxLength = 10
        Me.Txt_Patient_ID.Name = "Txt_Patient_ID"
        Me.Txt_Patient_ID.ReadOnly = True
        Me.Txt_Patient_ID.Size = New System.Drawing.Size(176, 21)
        Me.Txt_Patient_ID.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(2, 8)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(64, 13)
        Me.Label4.TabIndex = 1081
        Me.Label4.Text = "Patient ID"
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.Transparent
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Controls.Add(Me.Lbl_Doctordetails)
        Me.Panel4.Controls.Add(Me.Cmb_Active)
        Me.Panel4.Controls.Add(Me.Pnl_Tran_mode)
        Me.Panel4.Controls.Add(Me.Label13)
        Me.Panel4.Controls.Add(Me.Btn_FindDr)
        Me.Panel4.Controls.Add(Me.Txt_Doctor_ID)
        Me.Panel4.Controls.Add(Me.Label8)
        Me.Panel4.Controls.Add(Me.Cmb_Diagnose)
        Me.Panel4.Controls.Add(Me.Label6)
        Me.Panel4.Controls.Add(Me.Btn_Remove)
        Me.Panel4.Controls.Add(Me.Btn_Add)
        Me.Panel4.Controls.Add(Me.Label9)
        Me.Panel4.Controls.Add(Me.Txt_Current_Stat)
        Me.Panel4.Controls.Add(Me.Txt_Comments)
        Me.Panel4.Controls.Add(Me.Label7)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel4.Location = New System.Drawing.Point(0, 182)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(700, 191)
        Me.Panel4.TabIndex = 1141
        '
        'Lbl_Doctordetails
        '
        Me.Lbl_Doctordetails.BackColor = System.Drawing.Color.FromArgb(CType(CType(58, Byte), Integer), CType(CType(109, Byte), Integer), CType(CType(139, Byte), Integer))
        Me.Lbl_Doctordetails.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Lbl_Doctordetails.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Doctordetails.ForeColor = System.Drawing.Color.AliceBlue
        Me.Lbl_Doctordetails.Location = New System.Drawing.Point(81, 27)
        Me.Lbl_Doctordetails.Name = "Lbl_Doctordetails"
        Me.Lbl_Doctordetails.Padding = New System.Windows.Forms.Padding(5, 0, 0, 0)
        Me.Lbl_Doctordetails.Size = New System.Drawing.Size(438, 32)
        Me.Lbl_Doctordetails.TabIndex = 100075
        Me.Lbl_Doctordetails.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Cmb_Active
        '
        Me.Cmb_Active.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Active.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Cmb_Active.FormattingEnabled = True
        Me.Cmb_Active.Items.AddRange(New Object() {"Yes", "No"})
        Me.Cmb_Active.Location = New System.Drawing.Point(82, 163)
        Me.Cmb_Active.Name = "Cmb_Active"
        Me.Cmb_Active.Size = New System.Drawing.Size(102, 21)
        Me.Cmb_Active.TabIndex = 10
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label13.Location = New System.Drawing.Point(5, 167)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(43, 13)
        Me.Label13.TabIndex = 1154
        Me.Label13.Text = "Active"
        '
        'Btn_FindDr
        '
        Me.Btn_FindDr.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_FindDr.BackgroundImage = CType(resources.GetObject("Btn_FindDr.BackgroundImage"), System.Drawing.Image)
        Me.Btn_FindDr.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_FindDr.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_FindDr.ForeColor = System.Drawing.Color.White
        Me.Btn_FindDr.Location = New System.Drawing.Point(227, 3)
        Me.Btn_FindDr.Name = "Btn_FindDr"
        Me.Btn_FindDr.Size = New System.Drawing.Size(28, 21)
        Me.Btn_FindDr.TabIndex = 6
        Me.Btn_FindDr.TabStop = False
        Me.Btn_FindDr.Text = "F2"
        Me.Btn_FindDr.UseVisualStyleBackColor = False
        '
        'Txt_Doctor_ID
        '
        Me.Txt_Doctor_ID.BackColor = System.Drawing.Color.White
        Me.Txt_Doctor_ID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Doctor_ID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Doctor_ID.Location = New System.Drawing.Point(81, 3)
        Me.Txt_Doctor_ID.MaxLength = 9
        Me.Txt_Doctor_ID.Name = "Txt_Doctor_ID"
        Me.Txt_Doctor_ID.Size = New System.Drawing.Size(144, 21)
        Me.Txt_Doctor_ID.TabIndex = 5
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label8.Location = New System.Drawing.Point(5, 7)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(61, 13)
        Me.Label8.TabIndex = 1151
        Me.Label8.Text = "Doctor ID"
        '
        'Cmb_Diagnose
        '
        Me.Cmb_Diagnose.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Diagnose.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Cmb_Diagnose.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Diagnose.FormattingEnabled = True
        Me.Cmb_Diagnose.ItemHeight = 13
        Me.Cmb_Diagnose.Location = New System.Drawing.Point(81, 63)
        Me.Cmb_Diagnose.Name = "Cmb_Diagnose"
        Me.Cmb_Diagnose.Size = New System.Drawing.Size(541, 21)
        Me.Cmb_Diagnose.TabIndex = 7
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label6.Location = New System.Drawing.Point(4, 64)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(61, 13)
        Me.Label6.TabIndex = 1102
        Me.Label6.Text = "Diagnosis"
        '
        'Btn_Remove
        '
        Me.Btn_Remove.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Remove.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Remove.CausesValidation = False
        Me.Btn_Remove.ForeColor = System.Drawing.Color.Lavender
        Me.Btn_Remove.Location = New System.Drawing.Point(250, 163)
        Me.Btn_Remove.Name = "Btn_Remove"
        Me.Btn_Remove.Size = New System.Drawing.Size(62, 23)
        Me.Btn_Remove.TabIndex = 12
        Me.Btn_Remove.Text = "&Remove"
        Me.Btn_Remove.UseVisualStyleBackColor = False
        '
        'Btn_Add
        '
        Me.Btn_Add.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Add.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Add.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Add.ForeColor = System.Drawing.Color.White
        Me.Btn_Add.Location = New System.Drawing.Point(187, 163)
        Me.Btn_Add.Name = "Btn_Add"
        Me.Btn_Add.Size = New System.Drawing.Size(62, 23)
        Me.Btn_Add.TabIndex = 11
        Me.Btn_Add.Text = "&Add"
        Me.Btn_Add.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btn_Add.UseVisualStyleBackColor = False
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label9.Location = New System.Drawing.Point(4, 135)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(60, 31)
        Me.Label9.TabIndex = 1099
        Me.Label9.Text = "Current Status"
        '
        'Txt_Current_Stat
        '
        Me.Txt_Current_Stat.BackColor = System.Drawing.Color.White
        Me.Txt_Current_Stat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Current_Stat.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Current_Stat.Location = New System.Drawing.Point(81, 137)
        Me.Txt_Current_Stat.MaxLength = 100
        Me.Txt_Current_Stat.Name = "Txt_Current_Stat"
        Me.Txt_Current_Stat.Size = New System.Drawing.Size(540, 21)
        Me.Txt_Current_Stat.TabIndex = 9
        '
        'Txt_Comments
        '
        Me.Txt_Comments.BackColor = System.Drawing.Color.White
        Me.Txt_Comments.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Txt_Comments.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Comments.Location = New System.Drawing.Point(81, 91)
        Me.Txt_Comments.MaxLength = 500
        Me.Txt_Comments.Multiline = True
        Me.Txt_Comments.Name = "Txt_Comments"
        Me.Txt_Comments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Txt_Comments.Size = New System.Drawing.Size(540, 40)
        Me.Txt_Comments.TabIndex = 8
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label7.Location = New System.Drawing.Point(4, 90)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(68, 13)
        Me.Label7.TabIndex = 1096
        Me.Label7.Text = "Comments"
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel5.Controls.Add(Me.Btn_Delete)
        Me.Panel5.Controls.Add(Me.Btn_Clear)
        Me.Panel5.Controls.Add(Me.Btn_Close)
        Me.Panel5.Controls.Add(Me.Btn_Save)
        Me.Panel5.Location = New System.Drawing.Point(443, 525)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(255, 36)
        Me.Panel5.TabIndex = 1143
        '
        'Btn_Delete
        '
        Me.Btn_Delete.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Delete.BackgroundImage = CType(resources.GetObject("Btn_Delete.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Delete.CausesValidation = False
        Me.Btn_Delete.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Btn_Delete.Location = New System.Drawing.Point(126, 3)
        Me.Btn_Delete.Name = "Btn_Delete"
        Me.Btn_Delete.Size = New System.Drawing.Size(62, 28)
        Me.Btn_Delete.TabIndex = 15
        Me.Btn_Delete.Text = "&Delete"
        Me.Btn_Delete.UseVisualStyleBackColor = False
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Clear.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Btn_Clear.Location = New System.Drawing.Point(65, 3)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(62, 28)
        Me.Btn_Clear.TabIndex = 14
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = False
        '
        'Btn_Close
        '
        Me.Btn_Close.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Btn_Close.Location = New System.Drawing.Point(188, 3)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(62, 28)
        Me.Btn_Close.TabIndex = 16
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = False
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(3, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(62, 28)
        Me.Btn_Save.TabIndex = 13
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Dgv_Diagnosis
        '
        Me.Dgv_Diagnosis.AllowUserToAddRows = False
        Me.Dgv_Diagnosis.AllowUserToDeleteRows = False
        Me.Dgv_Diagnosis.AllowUserToResizeColumns = False
        Me.Dgv_Diagnosis.AllowUserToResizeRows = False
        Me.Dgv_Diagnosis.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(118, Byte), Integer), CType(CType(155, Byte), Integer), CType(CType(197, Byte), Integer))
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(87, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(162, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.AliceBlue
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgv_Diagnosis.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.Dgv_Diagnosis.ColumnHeadersHeight = 20
        Me.Dgv_Diagnosis.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.Dgv_Diagnosis.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Diagnosis, Me.Comments, Me.Status, Me.Active, Me.DiagID, Me.TR_DT, Me.Doctor, Me.De_Active_Date, Me.DiagnosisID, Me.DoctorID})
        Me.Dgv_Diagnosis.Location = New System.Drawing.Point(0, 375)
        Me.Dgv_Diagnosis.Name = "Dgv_Diagnosis"
        Me.Dgv_Diagnosis.ReadOnly = True
        Me.Dgv_Diagnosis.RowHeadersVisible = False
        Me.Dgv_Diagnosis.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.Dgv_Diagnosis.Size = New System.Drawing.Size(700, 146)
        Me.Dgv_Diagnosis.TabIndex = 1140
        Me.Dgv_Diagnosis.TabStop = False
        '
        'Diagnosis
        '
        Me.Diagnosis.HeaderText = "Diagnosis"
        Me.Diagnosis.MinimumWidth = 150
        Me.Diagnosis.Name = "Diagnosis"
        Me.Diagnosis.ReadOnly = True
        Me.Diagnosis.Width = 150
        '
        'Comments
        '
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(194, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Comments.DefaultCellStyle = DataGridViewCellStyle2
        Me.Comments.HeaderText = "Comments"
        Me.Comments.Name = "Comments"
        Me.Comments.ReadOnly = True
        Me.Comments.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Comments.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Comments.Width = 150
        '
        'Status
        '
        Me.Status.HeaderText = "Status"
        Me.Status.MinimumWidth = 100
        Me.Status.Name = "Status"
        Me.Status.ReadOnly = True
        '
        'Active
        '
        Me.Active.HeaderText = "Active"
        Me.Active.MinimumWidth = 50
        Me.Active.Name = "Active"
        Me.Active.ReadOnly = True
        Me.Active.Width = 50
        '
        'DiagID
        '
        Me.DiagID.HeaderText = "DiagID"
        Me.DiagID.Name = "DiagID"
        Me.DiagID.ReadOnly = True
        Me.DiagID.Visible = False
        Me.DiagID.Width = 40
        '
        'TR_DT
        '
        Me.TR_DT.HeaderText = "Date"
        Me.TR_DT.MinimumWidth = 70
        Me.TR_DT.Name = "TR_DT"
        Me.TR_DT.ReadOnly = True
        Me.TR_DT.Width = 70
        '
        'Doctor
        '
        Me.Doctor.HeaderText = "Doctor"
        Me.Doctor.MinimumWidth = 100
        Me.Doctor.Name = "Doctor"
        Me.Doctor.ReadOnly = True
        '
        'De_Active_Date
        '
        Me.De_Active_Date.HeaderText = "DeActivate Date"
        Me.De_Active_Date.Name = "De_Active_Date"
        Me.De_Active_Date.ReadOnly = True
        Me.De_Active_Date.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.De_Active_Date.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'DiagnosisID
        '
        Me.DiagnosisID.HeaderText = "DiagnosisID"
        Me.DiagnosisID.Name = "DiagnosisID"
        Me.DiagnosisID.ReadOnly = True
        Me.DiagnosisID.Visible = False
        '
        'DoctorID
        '
        Me.DoctorID.HeaderText = "DoctorID"
        Me.DoctorID.Name = "DoctorID"
        Me.DoctorID.ReadOnly = True
        Me.DoctorID.Visible = False
        '
        'Patient_Info1
        '
        Me.Patient_Info1.BackColor = System.Drawing.Color.AliceBlue
        Me.Patient_Info1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Patient_Info1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Patient_Info1.Location = New System.Drawing.Point(289, 3)
        Me.Patient_Info1.Name = "Patient_Info1"
        Me.Patient_Info1.Padding = New System.Windows.Forms.Padding(2)
        Me.Patient_Info1.Size = New System.Drawing.Size(408, 117)
        Me.Patient_Info1.TabIndex = 1084
        '
        'Patient_Diagnosis_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(700, 563)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Dgv_Diagnosis)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Patient_Diagnosis_Frm"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Pnl_Tran_mode.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        CType(Me.Dgv_Diagnosis, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Dtp_TranDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents TXT_Acc_ID As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Patient_Info1 As REAL_CLINIC.Patient_Info
    Friend WithEvents TXT_OP_ID As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Txt_Patient_ID As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Dgv_Diagnosis As REAL_CLINIC.Hms_DGridview
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Txt_Current_Stat As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Comments As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Btn_Remove As System.Windows.Forms.Button
    Friend WithEvents Btn_Add As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Btn_Delete As System.Windows.Forms.Button
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Cmb_Diagnose As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Btn_Find_Account As System.Windows.Forms.Button
    Friend WithEvents Btn_Find As System.Windows.Forms.Button
    Friend WithEvents Btn_FindDr As System.Windows.Forms.Button
    Friend WithEvents Txt_Doctor_ID As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Active As System.Windows.Forms.ComboBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Diagnosis As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Comments As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Status As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Active As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents DiagID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TR_DT As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Doctor As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents De_Active_Date As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DiagnosisID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DoctorID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Lbl_Doctordetails As System.Windows.Forms.Label
End Class
