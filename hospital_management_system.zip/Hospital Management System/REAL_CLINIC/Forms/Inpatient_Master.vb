﻿Public Class Inpatient_Master

End Class