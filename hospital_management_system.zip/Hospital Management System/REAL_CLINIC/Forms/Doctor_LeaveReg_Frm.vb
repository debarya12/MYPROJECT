﻿
Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls

Public Class Doctor_LeaveReg_Frm

#Region "Declarations"
    'Object of Employee Details Bussiness Layer


    Private hms_helper As HMS_Helper = Nothing
    Private Dr_Leave_BL As Doctors_LeaveRegister_BL_Cls
    Private mTr_Mode As Tran_Mode
    Private TimeReqCtr As Object


    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                   
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    
            End Select
        End Set
    End Property

#End Region

#Region "Methods"

    Private Sub AssignToControl(ByVal dtbl As DataTable)
        Try

            Dim dr As DataTableReader = Nothing
            dr = dtbl.CreateDataReader()
            dr.Read()

            With dr
               

            End With
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Clear_Form()
        Try
            ListView1.Items.Clear()

            MonthCalendar1.SelectionStart = Tran_Date
            Employee_Info1.Employee_ID = ""


            Tr_Mode = Tran_Mode.New_Mode
            Btn_Save.Enabled = True
            Btn_Delete.Enabled = False
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Clear_ListBox(ByVal ListCntrol As CheckedListBox)
        Try
            Dim CNT As Integer
            For CNT = 0 To ListCntrol.Items.Count - 1
                ListCntrol.SetItemChecked(CNT, False)
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try

    End Sub

    Private Function Validate_Fields() As Boolean
        Try
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If

            If ListView1.CheckedItems.Count = 0 Then MessageBox.Show("No Leave Selected, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Return False

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function Locate_Employee(ByVal Employee_ID As Integer) As Boolean
        Try
            Employee_Info1.Employee_ID = Employee_ID
            If Not Employee_Info1.Is_Valid Then Return False
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function Locate_Values(ByVal Doc_ID As Integer) As Boolean
        Try
            Dim dtbl As DataTable = Nothing
            Dim dr As DataTableReader = Nothing
            Dim strgs As String
            Dim str(3) As String
            Dim itm As ListViewItem
            Dr_Leave_BL = New Doctors_LeaveRegister_BL_Cls
            ListView1.Items.Clear()
            If Dr_Leave_BL.Get_DoctorLeave_Reg(dtbl, Doc_ID, Tran_Date) Then
                dr = dtbl.CreateDataReader()
                While dr.Read
                    str(0) = Strings.Left(dr.Item("Leave_Date").ToString, 10)
                    strgs = dr.Item("Leave_Timings").ToString
                    strgs = strgs.Replace("|", "-")
                    str(1) = strgs
                    Cmb_LeaveType.SelectedValue = dr.Item("Leave_Type").ToString
                    str(2) = Cmb_LeaveType.Text
                    itm = New ListViewItem(str)
                    ListView1.Items.Add(itm)
                    ListView1.Items(ListView1.Items.Count - 1).Checked = True
                End While
                Return True
            End If
            Return False

        Catch ex As Exception
            Return False
        End Try
    End Function

    Public Function Is_CorrectTimeRange(ByVal FrmTime As Date, ByVal Totime As Date) As Boolean
        Try
            If DateDiff(DateInterval.Minute, FrmTime, Totime) >= 0 Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception

        End Try
    End Function

    Private Function RemoveDuplicates(ByVal lstView As ListView) As Boolean
        Try

            Dim itemI As ListViewItem
            Dim itemJ As ListViewItem

            Dim progress As Integer


            Dim count As Integer


            Dim ProgressDupCounter As Integer = lstView.Items.Count


            For i As Integer = lstView.Items.Count - 1 To 0 Step -1


                itemI = lstView.Items(i)


                progress = progress + 1


                ' start one after hence +1


                For z As Integer = i + 1 To lstView.Items.Count - 1 Step 1


                    itemJ = lstView.Items(z)


                    If itemI.Text = itemJ.Text Then


                        'duplicate found, now delete duplicate


                        lstView.Items.Remove(itemJ)


                        count = count + 1


                        Exit For


                    End If


                Next z


            Next (i)



        Catch ex As Exception

        End Try

    End Function

    Private Function Fill_TimePicker(ByVal LstBoxCtrl As ListBox, ByVal TimerangeFrm As Date, ByVal TimerangeTo As Date, ByVal Minitintervel As Integer) As Boolean
        Try
            Dim timesstring As String
            Dim cnt As Integer = 0
            Dim intervel As Long
            cnt = 0
            intervel = DateDiff(DateInterval.Minute, TimerangeFrm, TimerangeTo) / Minitintervel
            For i = 0 To Int(intervel)
                timesstring = DateAdd(DateInterval.Minute, cnt, TimerangeFrm)
                timesstring = Strings.Right("00000000000" + timesstring, 11)
                LstBoxCtrl.Items.Add(timesstring)
                cnt = cnt + Minitintervel
            Next
        Catch ex As Exception

        End Try
    End Function

#End Region

    Private Sub DoctorMaster_Frm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            hms_helper = New Hms_Helperimpliments
            hms_helper.Fill_Doctors(Cmb_Doctor, "")
            hms_helper.Fill_GenData(Cmb_LeaveType, Gendatatype.Leave_Type)

            MonthCalendar1.SelectionStart = Tran_Date

            ListView1.Columns.Add("Date", 100, HorizontalAlignment.Left)
            ListView1.Columns.Add("Time", 170, HorizontalAlignment.Left)
            ListView1.Columns.Add("Type", 100, HorizontalAlignment.Left)

            Dim frmdate As Date
            Dim todate As Date

            frmdate = "08:00:00 AM"
            todate = "08:00:00 PM"

            Txt_FromTime.Text = "12:00:00 AM"
            Txt_Totime.Text = "12:00:00 PM"
            Fill_TimePicker(ListBox1, frmdate, todate, 60)
            Btn_Delete.Enabled = False
        Catch ex As Exception


        End Try
    End Sub

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try
            Dim Dr As DataTableReader = Nothing
            Dim Dtbl As DataTable = Nothing
            Dim SaveFlg As Integer = 0

            Dr_Leave_BL = New Doctors_LeaveRegister_BL_Cls
            'Validating Data controls
            If Not Validate_Fields() Then Exit Sub

            Call RemoveDuplicates(ListView1)

            Call Dr_Leave_BL.Del_Doctor_LeaveReg(Dtbl, Cmb_Doctor.SelectedValue, Tran_Date)
            Dtbl = Nothing
            Dim strgs As String = ""



            With ListView1
                For Each CheckedItem As ListViewItem In .CheckedItems
                    Dr_Leave_BL.Leave_ID = 0
                    Dr_Leave_BL.Leave_Date = CheckedItem.Text
                    strgs = CheckedItem.SubItems(1).Text.Trim
                    strgs = strgs.Replace("-", "|")
                    Dr_Leave_BL.Leave_Timings = strgs
                    Dr_Leave_BL.Leave_Type = Cmb_LeaveType.SelectedValue
                    Dr_Leave_BL.Doc_ID = Cmb_Doctor.SelectedValue
                    Dr_Leave_BL.Reg_Date = Tran_Date

                    Dtbl = Nothing
                    If Dr_Leave_BL.Save_LeaveRegister(Dtbl, Tr_Mode, IIf(Tr_Mode <> Tran_Mode.New_Mode, 1, Cmb_Doctor.SelectedValue)) Then
                        SaveFlg = 1
                    Else
                        SaveFlg = 0
                    End If

                Next
            End With

            If SaveFlg = 1 Then
                MessageBox.Show("Doctor Leave Details Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Call Locate_Values(Cmb_Doctor.SelectedValue)
            Else
                MessageBox.Show("Doctor Leave Details not Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If


        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Call Clear_Form()

    End Sub

    Private Sub DoctorMaster_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then Call SendKeyTab()
    End Sub

    Private Sub DoctorMaster_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

    Private Sub DoctorMaster_Frm_LocationChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.LocationChanged
        Call KeepRightofme(Me, ImageViewer_Frm)
    End Sub

    Private Sub MonthCalendar1_DateChanged(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DateRangeEventArgs) Handles MonthCalendar1.DateChanged
        Dim obj As New DateTime()
        Dim str(3) As String
        Dim itm As ListViewItem
        obj = MonthCalendar1.SelectionStart
        str(0) = Strings.Left(obj.ToString, 10)
        str(1) = Txt_FromTime.Text + "-" + Txt_Totime.Text
        str(2) = Cmb_LeaveType.Text
        If obj < Tran_Date Then Exit Sub
        itm = New ListViewItem(str)
        ListView1.Items.Add(itm)
        ListView1.Items(ListView1.Items.Count - 1).Checked = True
    End Sub

    Private Sub Cmb_Doctor_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_Doctor.SelectedIndexChanged
        Try
            Dim dtbl As DataTable = Nothing
            Dim dr As DataTableReader = Nothing

            hms_helper = New Hms_Helperimpliments
            If hms_helper.GetEmpDetailsFromDoctorID(dtbl, Cmb_Doctor.SelectedValue) > 0 Then
                Call Locate_Employee(dtbl.Rows(0).Item("Empid").ToString)
            End If
            REM Locating Last updated Leave for selected Doctor(Max Reg Date)
            Call Locate_Values(Cmb_Doctor.SelectedValue)


        Catch ex As Exception

        End Try
    End Sub

    Private Sub Panel1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Panel1.Click
        TimeReqCtr = Txt_FromTime
        Pnl_TimePicker.Visible = True
        Pnl_TimePicker.Left = 165
        Pnl_TimePicker.Top = 173
    End Sub

    Private Sub Lvw_time2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Pnl_TimePicker.Visible = False
    End Sub

    Private Sub Lvw_time3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Pnl_TimePicker.Visible = False
    End Sub

    Private Sub Panel3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Panel3.Click
        Try
            TimeReqCtr = Txt_Totime
            Pnl_TimePicker.Visible = True
            Pnl_TimePicker.Left = 275
        Catch ex As Exception

        End Try
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged
        Try

            TimeReqCtr.text = ListBox1.SelectedItem
            Pnl_TimePicker.Visible = False
            If Not Is_CorrectTimeRange(Txt_FromTime.Text.Trim, Txt_Totime.Text.Trim) Then
                MessageBox.Show("Invalid time, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Pnl_TimePicker.Visible = True
            End If

        Catch ex As Exception

        End Try
    End Sub
  
    Private Sub Cmb_LeaveType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cmb_LeaveType.SelectedIndexChanged
        Try
            If Cmb_LeaveType.SelectedIndex <> 0 Then
                Pnl_Time.Visible = True
            Else
                Pnl_Time.Visible = False
            End If
        Catch ex As Exception

        End Try
    End Sub
   
   
    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click

    End Sub

    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click

    End Sub
End Class