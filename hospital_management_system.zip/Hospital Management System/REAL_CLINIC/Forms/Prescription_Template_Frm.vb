﻿Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls
Public Class Prescription_Template_Frm
#Region "Declarations"
    'Object of Patient Details Bussiness Layer
    Private Presc_Temp_Master_BL As Prescription_Template_BL_Cls

    Private hms_helper As HMS_Helper = Nothing
    Private mReq_Ctrl As Object = Nothing
    Private mTr_Mode As Long
    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing

    Private Form_Closing As Boolean
    Dim IntRow As Integer
    Dim IntSelectRow As Integer

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
            End Select
        End Set
    End Property

#End Region

#Region "Methods"
    Private Sub Clear_Prescription_Details()
        Try
            Txt_Medicine.Text = ""
            Txt_Dose.Text = ""
            cmb_Frequency.SelectedIndex = 0
            Cmb_Route.SelectedIndex = 0
            Txt_Qty.Text = ""
            Txt_Refils.Text = ""
            Txt_Days.Text = ""
            Txt_Medicine.Focus()
            Btn_Add.Text = "Add"
            Btn_Add.Tag = "A" 'Add
            IntSelectRow = -1
            Cmb_Pres_Templates.Tag = ""
            Dgv_Prescription.ClearSelection()
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Function Locate_Values(ByVal Diagnos_Id As Integer, ByVal Reg_Date As Date, ByVal Br_Code As Integer) As Boolean
        Try
            Dim dtbl As DataTable = Nothing
            'Initialising BL Object
            Presc_Temp_Master_BL = New Prescription_Template_BL_Cls

            dtbl = Nothing

            'Retreiving Patient Prescription Details
            If Presc_Temp_Master_BL.Get_Prescription_Details(dtbl, Diagnos_Id, Reg_Date, Br_Code) Then
                'Return Assigntocontrols(dtbl)
                'Cmb_Pres_Templates.DataSource = Nothing
                'Cmb_Pres_Templates.Tag = "False"
                Call Clear_Prescription_Details()

                With dtbl
                    Dgv_Prescription.RowCount = .Rows.Count
                    For i = 0 To .Rows.Count - 1
                        Dgv_Prescription.Rows(i).Cells("Medicine").Value = .Rows(i).Item("Pres_Medicine_Name").ToString
                        Dgv_Prescription.Rows(i).Cells("Dose").Value = .Rows(i).Item("Pres_Dose").ToString
                        Dgv_Prescription.Rows(i).Cells("Freequency").Value = .Rows(i).Item("Pres_Frequency").ToString
                        Dgv_Prescription.Rows(i).Cells("Route").Value = .Rows(i).Item("Pres_Route").ToString
                        Dgv_Prescription.Rows(i).Cells("Qty").Value = .Rows(i).Item("Pres_Quantity").ToString
                        Dgv_Prescription.Rows(i).Cells("Refils").Value = .Rows(i).Item("Pres_Refills").ToString
                        Dgv_Prescription.Rows(i).Cells("Days").Value = .Rows(i).Item("Pres_NoofDays").ToString
                        Dgv_Prescription.Rows(i).Cells("TempID").Value = .Rows(i).Item("Template_ID").ToString
                        Dgv_Prescription.Rows(i).Cells("TR_DT").Value = Format(.Rows(i).Item("Reg_Date"), "dd/MM/yyyy")

                    Next
                End With
                Cmb_Pres_Templates.Tag = Cmb_Pres_Templates.SelectedValue
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        Finally
            Dr = Nothing
            Dtbl = Nothing
            Presc_Temp_Master_BL = Nothing
        End Try
    End Function

    Private Function Validate_Fields() As Boolean
        Try
            With Dgv_Prescription
                For i = 0 To .Rows.Count - 1
                    'If .Rows(i).Cells("TempId").Value.ToString.Trim = "" Then
                    If Btn_Add.Tag = "A" Then
                        If Txt_Medicine.Text.Trim = .Rows(i).Cells("Medicine").Value.ToString.Trim And Txt_Dose.Text.Trim = .Rows(i).Cells("Dose").Value.ToString.Trim Then
                            MessageBox.Show("Medicine Already Enterd, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_Medicine.Focus() : Return False : Exit Function
                        End If
                    End If
                Next
            End With
            If Txt_Medicine.Text.Trim = "" Then MessageBox.Show("Invalid Medicine Name, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_Medicine.Focus() : Return False : Exit Function
            If Txt_Dose.Text.Trim = "" Then MessageBox.Show("Invalid Medicine Dose, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_Dose.Focus() : Return False : Exit Function
            If cmb_Frequency.Text = "" Then MessageBox.Show("Invalid Freequency, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : cmb_Frequency.Focus() : Return False : Exit Function
            If Cmb_Route.Text = "" Then MessageBox.Show("Invalid Medicine Route, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Cmb_Route.Focus() : Return False : Exit Function
            If Val(Txt_Qty.Text) = 0 Then MessageBox.Show("Invalid Quantity, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_Qty.Focus() : Return False : Exit Function
            If Val(Txt_Refils.Text) = 0 Then MessageBox.Show("Invalid Refils, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_Refils.Focus() : Return False : Exit Function
            If Val(Txt_Days.Text) = 0 Then MessageBox.Show("Invalid Days, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_Days.Focus() : Return False : Exit Function
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function
#End Region

    Private Sub Prescription_Template_Frm_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If Dgv_Prescription.Rows.Count <> 0 Then
            If Form_Closing = False Then
                MessageBox.Show("Please, Save the records before closing", Product_Name, MessageBoxButtons.OK)
                e.Cancel = True
            End If
        End If
    End Sub

    Private Sub Prescription_Template_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then Call SendKeyTab()
    End Sub

    Private Sub Prescription_Template_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub Prescription_Template_Frm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try


            hms_helper = New Hms_Helperimpliments
            hms_helper.Fill_Diagnosis(Cmb_Pres_Templates)
            Cmb_Pres_Templates.Focus()
            cmb_Frequency.SelectedIndex = 0
            Cmb_Route.SelectedIndex = 0
            Btn_Cancel.Enabled = False
            Btn_Add.Tag = "A"
            Dtp_Tran_Date.Value = Tran_Date
            Form_Closing = True
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Add_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Add.Click
        Try
            If Not Validate_Fields() Then Exit Sub
            If Btn_Add.Tag = "A" Then
                With Dgv_Prescription
                    .Rows.Add()
                    .Rows(.Rows.Count - 1).Cells("Medicine").Value = Txt_Medicine.Text.Trim
                    .Rows(.Rows.Count - 1).Cells("Dose").Value = Txt_Dose.Text.Trim
                    .Rows(.Rows.Count - 1).Cells("Freequency").Value = cmb_Frequency.Text
                    .Rows(.Rows.Count - 1).Cells("Route").Value = Cmb_Route.Text
                    .Rows(.Rows.Count - 1).Cells("Qty").Value = Txt_Qty.Text.Trim
                    .Rows(.Rows.Count - 1).Cells("Refils").Value = Txt_Refils.Text.Trim
                    .Rows(.Rows.Count - 1).Cells("Days").Value = Txt_Days.Text.Trim
                    .Rows(.Rows.Count - 1).Cells("TempID").Value = "x"

                    Call Clear_Prescription_Details()
                End With
            ElseIf Btn_Add.Tag = "M" Then
                With Dgv_Prescription
                    If IntSelectRow >= 0 Then
                        .Rows(IntSelectRow).Cells("Medicine").Value = Txt_Medicine.Text.Trim
                        .Rows(IntSelectRow).Cells("Dose").Value = Txt_Dose.Text.Trim
                        .Rows(IntSelectRow).Cells("Freequency").Value = cmb_Frequency.Text
                        .Rows(IntSelectRow).Cells("Route").Value = Cmb_Route.Text
                        .Rows(IntSelectRow).Cells("Qty").Value = Txt_Qty.Text.Trim
                        .Rows(IntSelectRow).Cells("Refils").Value = Txt_Refils.Text.Trim
                        .Rows(IntSelectRow).Cells("Days").Value = Txt_Days.Text.Trim
                        '.Rows(IntSelectRow).Cells("TR_DT").Value = Txt_Days.Text.Trim
                    Else
                        .Rows.Add()
                        .Rows(.Rows.Count - 1).Cells("Medicine").Value = Txt_Medicine.Text.Trim
                        .Rows(.Rows.Count - 1).Cells("Dose").Value = Txt_Dose.Text.Trim
                        .Rows(.Rows.Count - 1).Cells("Freequency").Value = cmb_Frequency.Text
                        .Rows(.Rows.Count - 1).Cells("Route").Value = Cmb_Route.Text
                        .Rows(.Rows.Count - 1).Cells("Qty").Value = Txt_Qty.Text.Trim
                        .Rows(.Rows.Count - 1).Cells("Refils").Value = Txt_Refils.Text.Trim
                        .Rows(.Rows.Count - 1).Cells("Days").Value = Txt_Days.Text.Trim
                        .Rows(.Rows.Count - 1).Cells("TempID").Value = "x"
                    End If
                End With
                Form_Closing = False
                Call Clear_Prescription_Details()
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try
    End Sub

    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try

            If Tr_Mode = Tran_Mode.New_Mode Then
                If Cmb_Pres_Templates.Text.Trim <> "" Then
                    Dim Sql As String
                    Dim Colwidth As String = ""
                    Colwidth = "175|125|100|50|125"
                    'Sql = "SELECT [Patient Name],ACC_ID,[Reg Date],[Family Name],Address,City,[Patient_ID]  FROM Patient_Account_Vw where ACC_ID IN(Select Acc_ID from Patient_Presc_Vw) Order by [Reg Date] Desc"
                    Sql = "SELECT * FROM Prescription_Temp_Vw"
                    Call ShowSearchengine(Cmb_Pres_Templates, Sql, 0, "Diagnos_Id", Colwidth, , 0)
                End If

                If Cmb_Pres_Templates.Text.Trim = "" Then
                    Cmb_Pres_Templates.Focus() : Exit Sub
                End If

                'Locate Prescription Details
                If Locate_Values(Cmb_Pres_Templates.SelectedValue, Dtp_Tran_Date.Value, Branch_Code) Then
                    Tr_Mode = Tran_Mode.Edit_Mode
                    'Btn_Delete.Enabled = True
                    Cmb_Pres_Templates.Focus()
                Else
                    MessageBox.Show("Prescription details not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
            Else
                Cmb_Pres_Templates.Focus()
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try
            'If Not Validate_GridValues() Then Exit Sub
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If

            If Dgv_Prescription.RowCount = 0 Then
                MessageBox.Show("Please Enter Prescription Details", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_Medicine.Focus()
                Exit Sub
            End If
            Tr_Mode = Tran_Mode.New_Mode
            Dim Int_Template_ID As Long

            Presc_Temp_Master_BL = New Prescription_Template_BL_Cls
            Dim dtbl As DataTable = Nothing
            Dim PresDtbl As DataTable = Nothing
            'Dim MaxTempId As Long

            Call Presc_Temp_Master_BL.Delete_Prescription_Template(Cmb_Pres_Templates.SelectedValue, Branch_Code)

            With Dgv_Prescription
                For i = 0 To .Rows.Count - 1
                    'If Presc_Temp_Master_BL.Get_Max_Presc_TemplateID(dtbl) Then
                    '    Dr = dtbl.CreateDataReader
                    '    Dr.Read()
                    '    Presc_Temp_Master_BL.Template_ID = Dr.GetValue(0).ToString.Trim
                    '    If Presc_Temp_Master_BL.Template_ID = 0 Then Presc_Temp_Master_BL.Template_ID = 1
                    '    MaxTempId = Presc_Temp_Master_BL.Template_ID
                    'End If

                    Presc_Temp_Master_BL.Pres_Date = Dtp_Tran_Date.Value
                    Presc_Temp_Master_BL.Pres_Medicine_Name = .Rows(i).Cells("Medicine").Value.ToString.Trim
                    Presc_Temp_Master_BL.Pres_Dose = .Rows(i).Cells("Dose").Value.ToString.Trim
                    Presc_Temp_Master_BL.Pres_Frequency = .Rows(i).Cells("Freequency").Value.ToString.Trim
                    Presc_Temp_Master_BL.Pres_Route = .Rows(i).Cells("Route").Value.ToString.Trim
                    Presc_Temp_Master_BL.Pres_Quantity = .Rows(i).Cells("Qty").Value.ToString.Trim
                    Presc_Temp_Master_BL.Pres_Refills = .Rows(i).Cells("Refils").Value.ToString.Trim
                    Presc_Temp_Master_BL.Pres_NoofDays = .Rows(i).Cells("Days").Value.ToString.Trim
                    Presc_Temp_Master_BL.Active = "Y"
                    'MsgBox(Dgv_Prescription.Rows(i).Cells("TR_DT").Value)
                    'MsgBox(Format(Dtp_Tran_Date.Value, "dd-MM-yyyy"))

                    'If Format(Dtp_Tran_Date.Value, "dd-MM-yyyy") = .Rows(i).Cells("TR_DT").Value Then
                    '    If .Rows(i).Cells("TempID").Value.ToString.Trim() = "x" Then
                    '        Int_Template_ID = 0
                    '        Tr_Mode = Tran_Mode.New_Mode
                    '    Else
                    '        Int_Template_ID = (.Rows(i).Cells("TempID").Value.ToString.Trim())
                    '        Tr_Mode = Tran_Mode.Edit_Mode
                    '    End If
                    'Else
                    '    Int_Template_ID = 0
                    '    Tr_Mode = Tran_Mode.New_Mode
                    'End If

                    Tr_Mode = Tran_Mode.New_Mode
                    Presc_Temp_Master_BL.Save_Prescription_Template(PresDtbl, Int_Template_ID, Cmb_Pres_Templates.SelectedValue, Tr_Mode)
                Next
            End With
            dtbl = Nothing
            PresDtbl = Nothing
            MessageBox.Show("Prescription Templates Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Form_Closing = True
            Btn_Clear_Click(sender, e)
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try
            Call Clear_Prescription_Details()
            Dgv_Prescription.RowCount = 0
            Btn_Add.Text = "Add"
            Btn_Add.Tag = "A"
            Cmb_Pres_Templates.Focus()
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try
    End Sub

    Private Sub Dgv_Prescription_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Dgv_Prescription.DoubleClick
        Try
            'If Tr_Mode = Tran_Mode.Edit_Mode Then
            With Dgv_Prescription
                If .Rows.Count > 0 Then
                    IntSelectRow = .CurrentRow.Index
                    Txt_Medicine.Text = .Rows(.CurrentRow.Index).Cells("Medicine").Value.ToString.Trim
                    Txt_Dose.Text = .Rows(.CurrentRow.Index).Cells("Dose").Value.ToString.Trim
                    cmb_Frequency.SelectedValue = .Rows(.CurrentRow.Index).Cells("Freequency").Value.ToString.Trim
                    Cmb_Route.SelectedValue = .Rows(.CurrentRow.Index).Cells("Route").Value.ToString.Trim
                    Txt_Qty.Text = .Rows(.CurrentRow.Index).Cells("Qty").Value.ToString.Trim
                    Txt_Refils.Text = .Rows(.CurrentRow.Index).Cells("Refils").Value.ToString.Trim
                    Txt_Days.Text = .Rows(.CurrentRow.Index).Cells("Days").Value.ToString.Trim

                    Btn_Add.Text = "Save"
                    Btn_Add.Tag = "M"
                    Txt_Medicine.Focus()
                    Dgv_Prescription.ClearSelection()
                End If
            End With
            'End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Cmb_Pres_Templates_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Cmb_Pres_Templates.Validating
        Try
            'If Cmb_Pres_Templates.SelectedValue <> Cmb_Pres_Templates.Tag Then
            If Locate_Values(Cmb_Pres_Templates.SelectedValue, Dtp_Tran_Date.Value, Branch_Code) Then
                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Cancel.Enabled = True
                Dtp_Tran_Date.Focus()
            Else
                Dgv_Prescription.RowCount = 0
                Tr_Mode = Tran_Mode.New_Mode
                'MessageBox.Show("Prescription details not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Btn_Cancel.Enabled = False
                Exit Sub
            End If
            'End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try
    End Sub

    Private Sub Dtp_Tran_Date_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Dtp_Tran_Date.ValueChanged
        If Dtp_Tran_Date.Value < Tran_Date Then Dtp_Tran_Date.Value = Tran_Date
    End Sub

    Private Sub Btn_Remove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Remove.Click
        Try
            Btn_Add.Tag = "A"
            Btn_Add.Text = "Add"
            If Dgv_Prescription.RowCount > 0 Then
                If MessageBox.Show("Are you sure wan't to remove the selected record ", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                    Dgv_Prescription.Rows.RemoveAt(Dgv_Prescription.CurrentRow.Index)
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

    Private Sub Txt_Qty_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Qty.KeyPress
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Qty.Text, Data_Type.Integer_Type, 12))
    End Sub

    Private Sub Txt_Refils_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Refils.KeyPress
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Refils.Text, Data_Type.Integer_Type, 12))
    End Sub

    Private Sub Txt_Days_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Days.KeyPress
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Days.Text, Data_Type.Integer_Type, 12))
    End Sub

    Private Sub Btn_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Cancel.Click
        Try
            'If Tr_Mode = Tran_Mode.New_Mode Then
            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If
            If Dgv_Prescription.Rows.Count = 0 Then
                MessageBox.Show("You have to locate details before deleting the record", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If


            'Confirm before delete the record
            If MessageBox.Show("Are you sure wan't to delete the Prescription Details", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = Windows.Forms.DialogResult.No Then
                Exit Sub
            End If
            Presc_Temp_Master_BL = New Prescription_Template_BL_Cls

            If Presc_Temp_Master_BL.Delete_Prescription_Template(Cmb_Pres_Templates.SelectedValue, Branch_Code) Then
                MessageBox.Show("Template master sucessfully deleted", Product_Name, MessageBoxButtons.OK)
                Call Btn_Clear_Click(sender, e)
            Else
                MessageBox.Show("You cannot delete Prescription Details" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception

        End Try
    End Sub

End Class