﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Patient_Prescription_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Patient_Prescription_Frm))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Delete = New System.Windows.Forms.Button
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.Txt_op_Id = New System.Windows.Forms.TextBox
        Me.Cmb_Doctor = New System.Windows.Forms.ComboBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.Btn_FindAccID = New System.Windows.Forms.Button
        Me.Lbl_Drname = New System.Windows.Forms.Label
        Me.Btn_Physician = New System.Windows.Forms.Button
        Me.Txt_Physician = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Dtp_TranDate = New System.Windows.Forms.DateTimePicker
        Me.Txt_Acc_Id = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Txt_Patient_Id = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Panel4 = New System.Windows.Forms.Panel
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Btn_Load_Prescription = New System.Windows.Forms.Button
        Me.Cmb_Pres_Templates = New System.Windows.Forms.ComboBox
        Me.Btn_Remove = New System.Windows.Forms.Button
        Me.Btn_Add = New System.Windows.Forms.Button
        Me.Cmb_Stat = New System.Windows.Forms.ComboBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.Cmb_Route = New System.Windows.Forms.ComboBox
        Me.cmb_Frequency = New System.Windows.Forms.ComboBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.DTP_Dis = New System.Windows.Forms.DateTimePicker
        Me.Cmb_Continue = New System.Windows.Forms.ComboBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.Txt_Days = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.Txt_Refils = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.Txt_Qty = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Txt_Dose = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Txt_Medicine = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Btn_Template_Save = New System.Windows.Forms.Button
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Btn_SaveTemplate = New System.Windows.Forms.Button
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Label2 = New System.Windows.Forms.Label
        Me.Dgv_Prescription = New REAL_CLINIC.Hms_DGridview(Me.components)
        Me.Medicine = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Dose = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Freequency = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Route = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Qty = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Refils = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Days = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Pres_Continue = New System.Windows.Forms.DataGridViewCheckBoxColumn
        Me.Dis_Dt = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Status = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Presc_ID = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Tr_Dt = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Doctor = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.PhyID = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Diagnos_Id = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Patient_Info1 = New REAL_CLINIC.Patient_Info
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.Pnl_Tran_mode.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Pnl_Header.SuspendLayout()
        CType(Me.Dgv_Prescription, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Delete)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(443, 529)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(262, 36)
        Me.Pnl_Common_Btn.TabIndex = 1082
        '
        'Btn_Delete
        '
        Me.Btn_Delete.BackgroundImage = CType(resources.GetObject("Btn_Delete.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Delete.CausesValidation = False
        Me.Btn_Delete.Location = New System.Drawing.Point(131, 3)
        Me.Btn_Delete.Name = "Btn_Delete"
        Me.Btn_Delete.Size = New System.Drawing.Size(62, 28)
        Me.Btn_Delete.TabIndex = 23
        Me.Btn_Delete.Text = "&Delete"
        Me.Btn_Delete.UseVisualStyleBackColor = True
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(67, 3)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(62, 28)
        Me.Btn_Clear.TabIndex = 22
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(195, 3)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(62, 28)
        Me.Btn_Close.TabIndex = 24
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(3, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(62, 28)
        Me.Btn_Save.TabIndex = 21
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.SystemColors.ControlDark
        Me.GroupBox3.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.GroupBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GroupBox3.Controls.Add(Me.Txt_op_Id)
        Me.GroupBox3.Controls.Add(Me.Cmb_Doctor)
        Me.GroupBox3.Controls.Add(Me.Label8)
        Me.GroupBox3.Controls.Add(Me.Btn_FindAccID)
        Me.GroupBox3.Controls.Add(Me.Lbl_Drname)
        Me.GroupBox3.Controls.Add(Me.Btn_Physician)
        Me.GroupBox3.Controls.Add(Me.Txt_Physician)
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Controls.Add(Me.Label16)
        Me.GroupBox3.Controls.Add(Me.Dtp_TranDate)
        Me.GroupBox3.Controls.Add(Me.Patient_Info1)
        Me.GroupBox3.Controls.Add(Me.Txt_Acc_Id)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.Txt_Patient_Id)
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.Pnl_Tran_mode)
        Me.GroupBox3.Location = New System.Drawing.Point(3, 15)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(712, 161)
        Me.GroupBox3.TabIndex = 1083
        Me.GroupBox3.TabStop = False
        '
        'Txt_op_Id
        '
        Me.Txt_op_Id.BackColor = System.Drawing.Color.White
        Me.Txt_op_Id.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_op_Id.Location = New System.Drawing.Point(537, -19)
        Me.Txt_op_Id.Name = "Txt_op_Id"
        Me.Txt_op_Id.ReadOnly = True
        Me.Txt_op_Id.Size = New System.Drawing.Size(138, 21)
        Me.Txt_op_Id.TabIndex = 1078
        Me.Txt_op_Id.TabStop = False
        Me.Txt_op_Id.Visible = False
        '
        'Cmb_Doctor
        '
        Me.Cmb_Doctor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Doctor.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Doctor.FormattingEnabled = True
        Me.Cmb_Doctor.ItemHeight = 13
        Me.Cmb_Doctor.Location = New System.Drawing.Point(98, 62)
        Me.Cmb_Doctor.Name = "Cmb_Doctor"
        Me.Cmb_Doctor.Size = New System.Drawing.Size(217, 21)
        Me.Cmb_Doctor.TabIndex = 5
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(14, 66)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(45, 13)
        Me.Label8.TabIndex = 1077
        Me.Label8.Text = "Doctor"
        '
        'Btn_FindAccID
        '
        Me.Btn_FindAccID.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_FindAccID.BackgroundImage = CType(resources.GetObject("Btn_FindAccID.BackgroundImage"), System.Drawing.Image)
        Me.Btn_FindAccID.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_FindAccID.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_FindAccID.ForeColor = System.Drawing.Color.White
        Me.Btn_FindAccID.Location = New System.Drawing.Point(236, 14)
        Me.Btn_FindAccID.Name = "Btn_FindAccID"
        Me.Btn_FindAccID.Size = New System.Drawing.Size(29, 21)
        Me.Btn_FindAccID.TabIndex = 1
        Me.Btn_FindAccID.TabStop = False
        Me.Btn_FindAccID.Text = "F2"
        Me.Btn_FindAccID.UseVisualStyleBackColor = False
        '
        'Lbl_Drname
        '
        Me.Lbl_Drname.BackColor = System.Drawing.Color.GhostWhite
        Me.Lbl_Drname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Lbl_Drname.ForeColor = System.Drawing.Color.DarkBlue
        Me.Lbl_Drname.Location = New System.Drawing.Point(99, 109)
        Me.Lbl_Drname.Name = "Lbl_Drname"
        Me.Lbl_Drname.Size = New System.Drawing.Size(216, 49)
        Me.Lbl_Drname.TabIndex = 1075
        '
        'Btn_Physician
        '
        Me.Btn_Physician.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Physician.BackgroundImage = CType(resources.GetObject("Btn_Physician.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Physician.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Physician.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Physician.ForeColor = System.Drawing.Color.White
        Me.Btn_Physician.Location = New System.Drawing.Point(237, 86)
        Me.Btn_Physician.Name = "Btn_Physician"
        Me.Btn_Physician.Size = New System.Drawing.Size(29, 21)
        Me.Btn_Physician.TabIndex = 7
        Me.Btn_Physician.TabStop = False
        Me.Btn_Physician.Text = "F2"
        Me.Btn_Physician.UseVisualStyleBackColor = False
        '
        'Txt_Physician
        '
        Me.Txt_Physician.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Physician.Location = New System.Drawing.Point(99, 86)
        Me.Txt_Physician.Name = "Txt_Physician"
        Me.Txt_Physician.Size = New System.Drawing.Size(137, 21)
        Me.Txt_Physician.TabIndex = 6
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.ForeColor = System.Drawing.Color.White
        Me.Label15.Location = New System.Drawing.Point(14, 91)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(76, 13)
        Me.Label15.TabIndex = 1072
        Me.Label15.Text = "Physician ID"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(14, 41)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(34, 13)
        Me.Label16.TabIndex = 1069
        Me.Label16.Text = "Date"
        '
        'Dtp_TranDate
        '
        Me.Dtp_TranDate.CustomFormat = "dd/MM/yyyy"
        Me.Dtp_TranDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_TranDate.Location = New System.Drawing.Point(98, 38)
        Me.Dtp_TranDate.Name = "Dtp_TranDate"
        Me.Dtp_TranDate.Size = New System.Drawing.Size(98, 21)
        Me.Dtp_TranDate.TabIndex = 4
        '
        'Txt_Acc_Id
        '
        Me.Txt_Acc_Id.BackColor = System.Drawing.Color.White
        Me.Txt_Acc_Id.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Acc_Id.Location = New System.Drawing.Point(98, 14)
        Me.Txt_Acc_Id.Name = "Txt_Acc_Id"
        Me.Txt_Acc_Id.Size = New System.Drawing.Size(137, 21)
        Me.Txt_Acc_Id.TabIndex = 0
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(13, 18)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 13)
        Me.Label3.TabIndex = 1064
        Me.Label3.Text = "PMR ID"
        '
        'Txt_Patient_Id
        '
        Me.Txt_Patient_Id.BackColor = System.Drawing.Color.White
        Me.Txt_Patient_Id.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Patient_Id.Location = New System.Drawing.Point(402, 14)
        Me.Txt_Patient_Id.Name = "Txt_Patient_Id"
        Me.Txt_Patient_Id.ReadOnly = True
        Me.Txt_Patient_Id.Size = New System.Drawing.Size(138, 21)
        Me.Txt_Patient_Id.TabIndex = 3
        Me.Txt_Patient_Id.TabStop = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(320, 18)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(64, 13)
        Me.Label4.TabIndex = 1062
        Me.Label4.Text = "Patient ID"
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(633, 13)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(70, 22)
        Me.Pnl_Tran_mode.TabIndex = 1057
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(3, 2)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(67, 16)
        Me.Lbl_Tran_Mode.TabIndex = 126
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox1
        '
        Me.GroupBox1.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.LeftGradiant
        Me.GroupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.GroupBox1.Controls.Add(Me.Panel4)
        Me.GroupBox1.Controls.Add(Me.Panel3)
        Me.GroupBox1.Controls.Add(Me.Panel2)
        Me.GroupBox1.Controls.Add(Me.Btn_Template_Save)
        Me.GroupBox1.Controls.Add(Me.Dgv_Prescription)
        Me.GroupBox1.Controls.Add(Me.Panel1)
        Me.GroupBox1.ForeColor = System.Drawing.Color.Black
        Me.GroupBox1.Location = New System.Drawing.Point(3, 179)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(712, 345)
        Me.GroupBox1.TabIndex = 1084
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Diagnosis"
        '
        'Panel4
        '
        Me.Panel4.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel4.Location = New System.Drawing.Point(6, 14)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(698, 8)
        Me.Panel4.TabIndex = 1093
        '
        'Panel3
        '
        Me.Panel3.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel3.Location = New System.Drawing.Point(5, 145)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(702, 8)
        Me.Panel3.TabIndex = 1092
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(43, Byte), Integer), CType(CType(139, Byte), Integer), CType(CType(227, Byte), Integer))
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.Btn_Load_Prescription)
        Me.Panel2.Controls.Add(Me.Cmb_Pres_Templates)
        Me.Panel2.Controls.Add(Me.Btn_Remove)
        Me.Panel2.Controls.Add(Me.Btn_Add)
        Me.Panel2.Controls.Add(Me.Cmb_Stat)
        Me.Panel2.Controls.Add(Me.Label17)
        Me.Panel2.Controls.Add(Me.Cmb_Route)
        Me.Panel2.Controls.Add(Me.cmb_Frequency)
        Me.Panel2.Controls.Add(Me.Label14)
        Me.Panel2.Controls.Add(Me.DTP_Dis)
        Me.Panel2.Controls.Add(Me.Cmb_Continue)
        Me.Panel2.Controls.Add(Me.Label13)
        Me.Panel2.Controls.Add(Me.Txt_Days)
        Me.Panel2.Controls.Add(Me.Label12)
        Me.Panel2.Controls.Add(Me.Txt_Refils)
        Me.Panel2.Controls.Add(Me.Label11)
        Me.Panel2.Controls.Add(Me.Txt_Qty)
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Controls.Add(Me.Txt_Dose)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.Txt_Medicine)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Location = New System.Drawing.Point(6, 17)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(698, 120)
        Me.Panel2.TabIndex = 1091
        '
        'Btn_Load_Prescription
        '
        Me.Btn_Load_Prescription.BackgroundImage = CType(resources.GetObject("Btn_Load_Prescription.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Load_Prescription.CausesValidation = False
        Me.Btn_Load_Prescription.ForeColor = System.Drawing.Color.Lavender
        Me.Btn_Load_Prescription.Location = New System.Drawing.Point(316, 7)
        Me.Btn_Load_Prescription.Name = "Btn_Load_Prescription"
        Me.Btn_Load_Prescription.Size = New System.Drawing.Size(223, 21)
        Me.Btn_Load_Prescription.TabIndex = 1088
        Me.Btn_Load_Prescription.Text = "&Load Diagnosis Template"
        Me.Btn_Load_Prescription.UseVisualStyleBackColor = True
        '
        'Cmb_Pres_Templates
        '
        Me.Cmb_Pres_Templates.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Pres_Templates.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Pres_Templates.FormattingEnabled = True
        Me.Cmb_Pres_Templates.ItemHeight = 13
        Me.Cmb_Pres_Templates.Location = New System.Drawing.Point(6, 7)
        Me.Cmb_Pres_Templates.Name = "Cmb_Pres_Templates"
        Me.Cmb_Pres_Templates.Size = New System.Drawing.Size(302, 21)
        Me.Cmb_Pres_Templates.TabIndex = 8
        '
        'Btn_Remove
        '
        Me.Btn_Remove.BackgroundImage = CType(resources.GetObject("Btn_Remove.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Remove.CausesValidation = False
        Me.Btn_Remove.ForeColor = System.Drawing.Color.Lavender
        Me.Btn_Remove.Location = New System.Drawing.Point(626, 88)
        Me.Btn_Remove.Name = "Btn_Remove"
        Me.Btn_Remove.Size = New System.Drawing.Size(62, 22)
        Me.Btn_Remove.TabIndex = 20
        Me.Btn_Remove.Text = "&Remove"
        Me.Btn_Remove.UseVisualStyleBackColor = True
        '
        'Btn_Add
        '
        Me.Btn_Add.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Add.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Add.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Add.ForeColor = System.Drawing.Color.White
        Me.Btn_Add.Location = New System.Drawing.Point(548, 88)
        Me.Btn_Add.Name = "Btn_Add"
        Me.Btn_Add.Size = New System.Drawing.Size(62, 22)
        Me.Btn_Add.TabIndex = 19
        Me.Btn_Add.Text = "&Add"
        Me.Btn_Add.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btn_Add.UseVisualStyleBackColor = False
        '
        'Cmb_Stat
        '
        Me.Cmb_Stat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Stat.FormattingEnabled = True
        Me.Cmb_Stat.Items.AddRange(New Object() {"Yes", "No"})
        Me.Cmb_Stat.Location = New System.Drawing.Point(432, 89)
        Me.Cmb_Stat.Name = "Cmb_Stat"
        Me.Cmb_Stat.Size = New System.Drawing.Size(109, 21)
        Me.Cmb_Stat.TabIndex = 18
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label17.Location = New System.Drawing.Point(432, 73)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(44, 13)
        Me.Label17.TabIndex = 1077
        Me.Label17.Text = "Status"
        '
        'Cmb_Route
        '
        Me.Cmb_Route.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Route.FormattingEnabled = True
        Me.Cmb_Route.Items.AddRange(New Object() {"Before Food", "After Food", "Early Morning"})
        Me.Cmb_Route.Location = New System.Drawing.Point(547, 49)
        Me.Cmb_Route.Name = "Cmb_Route"
        Me.Cmb_Route.Size = New System.Drawing.Size(141, 21)
        Me.Cmb_Route.TabIndex = 12
        '
        'cmb_Frequency
        '
        Me.cmb_Frequency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmb_Frequency.FormattingEnabled = True
        Me.cmb_Frequency.Items.AddRange(New Object() {"Morning", "Morning,After Noon", "Morning,After Noon,Night", "Morning,Night", "Night"})
        Me.cmb_Frequency.Location = New System.Drawing.Point(316, 49)
        Me.cmb_Frequency.Name = "cmb_Frequency"
        Me.cmb_Frequency.Size = New System.Drawing.Size(223, 21)
        Me.cmb_Frequency.TabIndex = 11
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label14.Location = New System.Drawing.Point(316, 73)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(91, 13)
        Me.Label14.TabIndex = 1074
        Me.Label14.Text = "Discontinue DT"
        '
        'DTP_Dis
        '
        Me.DTP_Dis.CustomFormat = "dd/MM/yyyy"
        Me.DTP_Dis.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTP_Dis.Location = New System.Drawing.Point(316, 89)
        Me.DTP_Dis.Name = "DTP_Dis"
        Me.DTP_Dis.Size = New System.Drawing.Size(105, 21)
        Me.DTP_Dis.TabIndex = 17
        '
        'Cmb_Continue
        '
        Me.Cmb_Continue.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Continue.FormattingEnabled = True
        Me.Cmb_Continue.Items.AddRange(New Object() {"Yes", "No"})
        Me.Cmb_Continue.Location = New System.Drawing.Point(213, 89)
        Me.Cmb_Continue.Name = "Cmb_Continue"
        Me.Cmb_Continue.Size = New System.Drawing.Size(95, 21)
        Me.Cmb_Continue.TabIndex = 16
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label13.Location = New System.Drawing.Point(213, 73)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(57, 13)
        Me.Label13.TabIndex = 1071
        Me.Label13.Text = "Continue"
        '
        'Txt_Days
        '
        Me.Txt_Days.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Days.Location = New System.Drawing.Point(137, 89)
        Me.Txt_Days.MaxLength = 5
        Me.Txt_Days.Name = "Txt_Days"
        Me.Txt_Days.Size = New System.Drawing.Size(70, 21)
        Me.Txt_Days.TabIndex = 15
        Me.Txt_Days.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label12.Location = New System.Drawing.Point(137, 73)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(35, 13)
        Me.Label12.TabIndex = 1069
        Me.Label12.Text = "Days"
        '
        'Txt_Refils
        '
        Me.Txt_Refils.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Refils.Location = New System.Drawing.Point(68, 89)
        Me.Txt_Refils.MaxLength = 5
        Me.Txt_Refils.Name = "Txt_Refils"
        Me.Txt_Refils.Size = New System.Drawing.Size(63, 21)
        Me.Txt_Refils.TabIndex = 14
        Me.Txt_Refils.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label11.Location = New System.Drawing.Point(65, 73)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(38, 13)
        Me.Label11.TabIndex = 1067
        Me.Label11.Text = "Refils"
        '
        'Txt_Qty
        '
        Me.Txt_Qty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Qty.Location = New System.Drawing.Point(6, 89)
        Me.Txt_Qty.MaxLength = 5
        Me.Txt_Qty.Name = "Txt_Qty"
        Me.Txt_Qty.Size = New System.Drawing.Size(53, 21)
        Me.Txt_Qty.TabIndex = 13
        Me.Txt_Qty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label10.Location = New System.Drawing.Point(4, 73)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(56, 13)
        Me.Label10.TabIndex = 1065
        Me.Label10.Text = "Quantity"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label9.Location = New System.Drawing.Point(545, 33)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(41, 13)
        Me.Label9.TabIndex = 1064
        Me.Label9.Text = "Route"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label7.Location = New System.Drawing.Point(316, 33)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(66, 13)
        Me.Label7.TabIndex = 1063
        Me.Label7.Text = "Frequency"
        '
        'Txt_Dose
        '
        Me.Txt_Dose.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Dose.Location = New System.Drawing.Point(213, 49)
        Me.Txt_Dose.MaxLength = 15
        Me.Txt_Dose.Name = "Txt_Dose"
        Me.Txt_Dose.Size = New System.Drawing.Size(95, 21)
        Me.Txt_Dose.TabIndex = 10
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label6.Location = New System.Drawing.Point(210, 33)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(35, 13)
        Me.Label6.TabIndex = 1061
        Me.Label6.Text = "Dose"
        '
        'Txt_Medicine
        '
        Me.Txt_Medicine.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Medicine.Location = New System.Drawing.Point(6, 49)
        Me.Txt_Medicine.MaxLength = 100
        Me.Txt_Medicine.Name = "Txt_Medicine"
        Me.Txt_Medicine.Size = New System.Drawing.Size(200, 21)
        Me.Txt_Medicine.TabIndex = 9
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label5.Location = New System.Drawing.Point(3, 33)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(57, 13)
        Me.Label5.TabIndex = 1059
        Me.Label5.Text = "Medicine"
        '
        'Btn_Template_Save
        '
        Me.Btn_Template_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Template_Save.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Template_Save.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Template_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Template_Save.Location = New System.Drawing.Point(718, 16)
        Me.Btn_Template_Save.Name = "Btn_Template_Save"
        Me.Btn_Template_Save.Size = New System.Drawing.Size(137, 21)
        Me.Btn_Template_Save.TabIndex = 1089
        Me.Btn_Template_Save.Text = "Create &Template"
        Me.Btn_Template_Save.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btn_Template_Save.UseVisualStyleBackColor = False
        Me.Btn_Template_Save.Visible = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(28, Byte), Integer), CType(CType(111, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.Panel1.Location = New System.Drawing.Point(4, 146)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(703, 194)
        Me.Panel1.TabIndex = 1090
        '
        'Btn_SaveTemplate
        '
        Me.Btn_SaveTemplate.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_SaveTemplate.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_SaveTemplate.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_SaveTemplate.ForeColor = System.Drawing.Color.White
        Me.Btn_SaveTemplate.Location = New System.Drawing.Point(12, 533)
        Me.Btn_SaveTemplate.Name = "Btn_SaveTemplate"
        Me.Btn_SaveTemplate.Size = New System.Drawing.Size(147, 32)
        Me.Btn_SaveTemplate.TabIndex = 1091
        Me.Btn_SaveTemplate.Text = "Sa&ve Template"
        Me.Btn_SaveTemplate.UseVisualStyleBackColor = False
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = CType(resources.GetObject("Pnl_Header.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Header.Controls.Add(Me.Label2)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(719, 24)
        Me.Pnl_Header.TabIndex = 1092
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(8, 1)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(230, 18)
        Me.Label2.TabIndex = 121
        Me.Label2.Text = "P a t i e n t    P r e s c r i pt i o n "
        '
        'Dgv_Prescription
        '
        Me.Dgv_Prescription.AllowUserToAddRows = False
        Me.Dgv_Prescription.AllowUserToDeleteRows = False
        Me.Dgv_Prescription.AllowUserToResizeColumns = False
        Me.Dgv_Prescription.AllowUserToResizeRows = False
        Me.Dgv_Prescription.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(118, Byte), Integer), CType(CType(155, Byte), Integer), CType(CType(197, Byte), Integer))
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(87, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(162, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.AliceBlue
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgv_Prescription.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.Dgv_Prescription.ColumnHeadersHeight = 20
        Me.Dgv_Prescription.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.Dgv_Prescription.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Medicine, Me.Dose, Me.Freequency, Me.Route, Me.Qty, Me.Refils, Me.Days, Me.Pres_Continue, Me.Dis_Dt, Me.Status, Me.Presc_ID, Me.Tr_Dt, Me.Doctor, Me.PhyID, Me.Diagnos_Id})
        Me.Dgv_Prescription.Location = New System.Drawing.Point(9, 153)
        Me.Dgv_Prescription.Name = "Dgv_Prescription"
        Me.Dgv_Prescription.ReadOnly = True
        Me.Dgv_Prescription.RowHeadersVisible = False
        Me.Dgv_Prescription.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.Dgv_Prescription.Size = New System.Drawing.Size(693, 180)
        Me.Dgv_Prescription.TabIndex = 1082
        Me.Dgv_Prescription.TabStop = False
        '
        'Medicine
        '
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(194, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Medicine.DefaultCellStyle = DataGridViewCellStyle2
        Me.Medicine.HeaderText = "Medicine"
        Me.Medicine.Name = "Medicine"
        Me.Medicine.ReadOnly = True
        Me.Medicine.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Medicine.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Medicine.Width = 200
        '
        'Dose
        '
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(239, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(248, Byte), Integer))
        Me.Dose.DefaultCellStyle = DataGridViewCellStyle3
        Me.Dose.HeaderText = "Dose"
        Me.Dose.Name = "Dose"
        Me.Dose.ReadOnly = True
        Me.Dose.Width = 125
        '
        'Freequency
        '
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(213, Byte), Integer))
        Me.Freequency.DefaultCellStyle = DataGridViewCellStyle4
        Me.Freequency.HeaderText = "Freequency"
        Me.Freequency.Name = "Freequency"
        Me.Freequency.ReadOnly = True
        Me.Freequency.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Freequency.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Freequency.Width = 125
        '
        'Route
        '
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(CType(CType(194, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Route.DefaultCellStyle = DataGridViewCellStyle5
        Me.Route.HeaderText = "Route"
        Me.Route.Name = "Route"
        Me.Route.ReadOnly = True
        Me.Route.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Route.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Route.Width = 125
        '
        'Qty
        '
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(CType(CType(174, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(213, Byte), Integer))
        Me.Qty.DefaultCellStyle = DataGridViewCellStyle6
        Me.Qty.HeaderText = "Quantity"
        Me.Qty.Name = "Qty"
        Me.Qty.ReadOnly = True
        Me.Qty.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Qty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Qty.Width = 50
        '
        'Refils
        '
        Me.Refils.HeaderText = "Refils"
        Me.Refils.Name = "Refils"
        Me.Refils.ReadOnly = True
        Me.Refils.Visible = False
        Me.Refils.Width = 50
        '
        'Days
        '
        Me.Days.HeaderText = "Days"
        Me.Days.Name = "Days"
        Me.Days.ReadOnly = True
        Me.Days.Visible = False
        Me.Days.Width = 50
        '
        'Pres_Continue
        '
        Me.Pres_Continue.HeaderText = "Continue"
        Me.Pres_Continue.Name = "Pres_Continue"
        Me.Pres_Continue.ReadOnly = True
        Me.Pres_Continue.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Pres_Continue.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.Pres_Continue.Width = 50
        '
        'Dis_Dt
        '
        Me.Dis_Dt.HeaderText = "Discontinue Dt"
        Me.Dis_Dt.Name = "Dis_Dt"
        Me.Dis_Dt.ReadOnly = True
        '
        'Status
        '
        Me.Status.HeaderText = "Status"
        Me.Status.Name = "Status"
        Me.Status.ReadOnly = True
        '
        'Presc_ID
        '
        Me.Presc_ID.HeaderText = "Presc_ID"
        Me.Presc_ID.Name = "Presc_ID"
        Me.Presc_ID.ReadOnly = True
        Me.Presc_ID.Visible = False
        '
        'Tr_Dt
        '
        Me.Tr_Dt.HeaderText = "Tr_Dt"
        Me.Tr_Dt.Name = "Tr_Dt"
        Me.Tr_Dt.ReadOnly = True
        Me.Tr_Dt.Visible = False
        '
        'Doctor
        '
        Me.Doctor.HeaderText = "Doctror"
        Me.Doctor.Name = "Doctor"
        Me.Doctor.ReadOnly = True
        Me.Doctor.Visible = False
        '
        'PhyID
        '
        Me.PhyID.HeaderText = "PhyID"
        Me.PhyID.Name = "PhyID"
        Me.PhyID.ReadOnly = True
        Me.PhyID.Visible = False
        '
        'Diagnos_Id
        '
        Me.Diagnos_Id.HeaderText = "Diagnosis"
        Me.Diagnos_Id.Name = "Diagnos_Id"
        Me.Diagnos_Id.ReadOnly = True
        '
        'Patient_Info1
        '
        Me.Patient_Info1.BackColor = System.Drawing.Color.AliceBlue
        Me.Patient_Info1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Patient_Info1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Patient_Info1.Location = New System.Drawing.Point(323, 41)
        Me.Patient_Info1.Name = "Patient_Info1"
        Me.Patient_Info1.Padding = New System.Windows.Forms.Padding(2)
        Me.Patient_Info1.Size = New System.Drawing.Size(379, 117)
        Me.Patient_Info1.TabIndex = 1067
        '
        'Patient_Prescription_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.LeftGradiant
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(719, 568)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Controls.Add(Me.Btn_SaveTemplate)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Patient_Prescription_Frm"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.Pnl_Tran_mode.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        CType(Me.Dgv_Prescription, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Lbl_Drname As System.Windows.Forms.Label
    Friend WithEvents Btn_Physician As System.Windows.Forms.Button
    Friend WithEvents Txt_Physician As System.Windows.Forms.TextBox
    Friend WithEvents Dtp_TranDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Patient_Info1 As REAL_CLINIC.Patient_Info
    Friend WithEvents Txt_Acc_Id As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Patient_Id As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Dgv_Prescription As REAL_CLINIC.Hms_DGridview
    Friend WithEvents Btn_Add As System.Windows.Forms.Button
    Friend WithEvents Cmb_Stat As System.Windows.Forms.ComboBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Route As System.Windows.Forms.ComboBox
    Friend WithEvents cmb_Frequency As System.Windows.Forms.ComboBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents DTP_Dis As System.Windows.Forms.DateTimePicker
    Friend WithEvents Cmb_Continue As System.Windows.Forms.ComboBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Txt_Days As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Txt_Refils As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Txt_Qty As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Txt_Dose As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Txt_Medicine As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Btn_FindAccID As System.Windows.Forms.Button
    Friend WithEvents Btn_Delete As System.Windows.Forms.Button
    Friend WithEvents Btn_Remove As System.Windows.Forms.Button
    Friend WithEvents Btn_Load_Prescription As System.Windows.Forms.Button
    Friend WithEvents Cmb_Pres_Templates As System.Windows.Forms.ComboBox
    Friend WithEvents Btn_Template_Save As System.Windows.Forms.Button
    Friend WithEvents Cmb_Doctor As System.Windows.Forms.ComboBox
    Friend WithEvents Btn_SaveTemplate As System.Windows.Forms.Button
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Txt_op_Id As System.Windows.Forms.TextBox
    Friend WithEvents Medicine As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Dose As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Freequency As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Route As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Qty As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Refils As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Days As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Pres_Continue As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents Dis_Dt As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Status As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Presc_ID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Tr_Dt As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Doctor As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PhyID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Diagnos_Id As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Private WithEvents GroupBox3 As System.Windows.Forms.GroupBox
End Class
