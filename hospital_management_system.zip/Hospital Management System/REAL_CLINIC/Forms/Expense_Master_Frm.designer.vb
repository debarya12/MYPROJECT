﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Expense_Master_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Expense_Master_Frm))
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.Tab_AccountHead = New System.Windows.Forms.TabControl
        Me.Tab_AccGrp = New System.Windows.Forms.TabPage
        Me.Grid_Searchhelper1 = New REAL_CLINIC.Grid_Searchhelper
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Cmb_GroupActive = New System.Windows.Forms.ComboBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.Cmb_ExpParrantGroup = New System.Windows.Forms.ComboBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.Dgrd_History = New System.Windows.Forms.DataGridView
        Me.Panel4 = New System.Windows.Forms.Panel
        Me.Lbl_Tran_Mode1 = New System.Windows.Forms.Label
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Delete = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.Txt_ExpGroup_Order = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Txt_ExpGroupName = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Btn_Find = New System.Windows.Forms.Button
        Me.Txt_ExpGroupID = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Tab_AccHead = New System.Windows.Forms.TabPage
        Me.Grid_Searchhelper2 = New REAL_CLINIC.Grid_Searchhelper
        Me.Label16 = New System.Windows.Forms.Label
        Me.Cmb_DiscAllowed = New System.Windows.Forms.ComboBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Cmb_GrpName = New System.Windows.Forms.ComboBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.Cmb_ParrentExpID = New System.Windows.Forms.ComboBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.Dgrd_History1 = New System.Windows.Forms.DataGridView
        Me.Tran_mode_Pnl = New System.Windows.Forms.Panel
        Me.Lbl_Tran_Mode2 = New System.Windows.Forms.Label
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.Btn_Clear1 = New System.Windows.Forms.Button
        Me.Btn_Close1 = New System.Windows.Forms.Button
        Me.Btn_Delete1 = New System.Windows.Forms.Button
        Me.Btn_Save1 = New System.Windows.Forms.Button
        Me.Label8 = New System.Windows.Forms.Label
        Me.Cmb_ExpActive = New System.Windows.Forms.ComboBox
        Me.Txt_ExpOrder = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Txt_ExpName = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Btn_Find1 = New System.Windows.Forms.Button
        Me.Txt_ExpID = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.Panel5 = New System.Windows.Forms.Panel
        Me.Btn_ExpMaster = New System.Windows.Forms.Button
        Me.Btn_ExpGroup = New System.Windows.Forms.Button
        Me.Panel6 = New System.Windows.Forms.Panel
        Me.Panel1.SuspendLayout()
        Me.Tab_AccountHead.SuspendLayout()
        Me.Tab_AccGrp.SuspendLayout()
        CType(Me.Dgrd_History, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Tab_AccHead.SuspendLayout()
        CType(Me.Dgrd_History1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Tran_mode_Pnl.SuspendLayout()
        Me.Panel3.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel5.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Panel1.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Menu_Bkg
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(90, 0)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(630, 20)
        Me.Panel1.TabIndex = 5
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(3, 4)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(165, 16)
        Me.Label1.TabIndex = 1000
        Me.Label1.Text = "E x p e n s e   D e t a i l s"
        '
        'Tab_AccountHead
        '
        Me.Tab_AccountHead.Controls.Add(Me.Tab_AccGrp)
        Me.Tab_AccountHead.Controls.Add(Me.Tab_AccHead)
        Me.Tab_AccountHead.Location = New System.Drawing.Point(100, 25)
        Me.Tab_AccountHead.Name = "Tab_AccountHead"
        Me.Tab_AccountHead.SelectedIndex = 0
        Me.Tab_AccountHead.Size = New System.Drawing.Size(618, 387)
        Me.Tab_AccountHead.TabIndex = 0
        '
        'Tab_AccGrp
        '
        Me.Tab_AccGrp.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.LeftGradiant
        Me.Tab_AccGrp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Tab_AccGrp.Controls.Add(Me.Grid_Searchhelper1)
        Me.Tab_AccGrp.Controls.Add(Me.Label14)
        Me.Tab_AccGrp.Controls.Add(Me.Label13)
        Me.Tab_AccGrp.Controls.Add(Me.Cmb_GroupActive)
        Me.Tab_AccGrp.Controls.Add(Me.Label12)
        Me.Tab_AccGrp.Controls.Add(Me.Cmb_ExpParrantGroup)
        Me.Tab_AccGrp.Controls.Add(Me.Label17)
        Me.Tab_AccGrp.Controls.Add(Me.Dgrd_History)
        Me.Tab_AccGrp.Controls.Add(Me.Panel4)
        Me.Tab_AccGrp.Controls.Add(Me.Panel2)
        Me.Tab_AccGrp.Controls.Add(Me.Txt_ExpGroup_Order)
        Me.Tab_AccGrp.Controls.Add(Me.Label4)
        Me.Tab_AccGrp.Controls.Add(Me.Txt_ExpGroupName)
        Me.Tab_AccGrp.Controls.Add(Me.Label3)
        Me.Tab_AccGrp.Controls.Add(Me.Btn_Find)
        Me.Tab_AccGrp.Controls.Add(Me.Txt_ExpGroupID)
        Me.Tab_AccGrp.Controls.Add(Me.Label2)
        Me.Tab_AccGrp.Location = New System.Drawing.Point(4, 22)
        Me.Tab_AccGrp.Name = "Tab_AccGrp"
        Me.Tab_AccGrp.Padding = New System.Windows.Forms.Padding(3)
        Me.Tab_AccGrp.Size = New System.Drawing.Size(610, 361)
        Me.Tab_AccGrp.TabIndex = 0
        Me.Tab_AccGrp.Text = "Expense Group Settings"
        Me.Tab_AccGrp.UseVisualStyleBackColor = True
        '
        'Grid_Searchhelper1
        '
        Me.Grid_Searchhelper1.BackColor = System.Drawing.Color.RoyalBlue
        Me.Grid_Searchhelper1.CausesValidation = False
        Me.Grid_Searchhelper1.Location = New System.Drawing.Point(244, 136)
        Me.Grid_Searchhelper1.Name = "Grid_Searchhelper1"
        Me.Grid_Searchhelper1.Padding = New System.Windows.Forms.Padding(1)
        Me.Grid_Searchhelper1.Search_Query = ""
        Me.Grid_Searchhelper1.Size = New System.Drawing.Size(272, 46)
        Me.Grid_Searchhelper1.TabIndex = 133
        Me.Grid_Searchhelper1.TabStop = False
        Me.Grid_Searchhelper1.Visible = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(105, 25)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(117, 17)
        Me.Label14.TabIndex = 102
        Me.Label14.Text = "Expense Group "
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Location = New System.Drawing.Point(11, 169)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(80, 13)
        Me.Label13.TabIndex = 101
        Me.Label13.Text = "Group Active"
        '
        'Cmb_GroupActive
        '
        Me.Cmb_GroupActive.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_GroupActive.FormattingEnabled = True
        Me.Cmb_GroupActive.Location = New System.Drawing.Point(108, 164)
        Me.Cmb_GroupActive.Name = "Cmb_GroupActive"
        Me.Cmb_GroupActive.Size = New System.Drawing.Size(68, 21)
        Me.Cmb_GroupActive.TabIndex = 5
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Location = New System.Drawing.Point(10, 141)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(87, 13)
        Me.Label12.TabIndex = 99
        Me.Label12.Text = "Parrant Group"
        '
        'Cmb_ExpParrantGroup
        '
        Me.Cmb_ExpParrantGroup.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_ExpParrantGroup.FormattingEnabled = True
        Me.Cmb_ExpParrantGroup.Location = New System.Drawing.Point(108, 137)
        Me.Cmb_ExpParrantGroup.Name = "Cmb_ExpParrantGroup"
        Me.Cmb_ExpParrantGroup.Size = New System.Drawing.Size(220, 21)
        Me.Cmb_ExpParrantGroup.TabIndex = 4
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.ForeColor = System.Drawing.Color.OrangeRed
        Me.Label17.Location = New System.Drawing.Point(83, 83)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(14, 13)
        Me.Label17.TabIndex = 97
        Me.Label17.Text = "*"
        '
        'Dgrd_History
        '
        Me.Dgrd_History.AllowUserToAddRows = False
        Me.Dgrd_History.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(252, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.Navy
        Me.Dgrd_History.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.Dgrd_History.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Dgrd_History.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(87, Byte), Integer), CType(CType(157, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgrd_History.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.Dgrd_History.ColumnHeadersHeight = 20
        Me.Dgrd_History.Location = New System.Drawing.Point(6, 222)
        Me.Dgrd_History.MultiSelect = False
        Me.Dgrd_History.Name = "Dgrd_History"
        Me.Dgrd_History.ReadOnly = True
        Me.Dgrd_History.RowHeadersVisible = False
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(254, Byte), Integer))
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.Navy
        Me.Dgrd_History.RowsDefaultCellStyle = DataGridViewCellStyle3
        Me.Dgrd_History.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.Dgrd_History.Size = New System.Drawing.Size(599, 133)
        Me.Dgrd_History.TabIndex = 62
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Panel4.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.F2_Button
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Controls.Add(Me.Lbl_Tran_Mode1)
        Me.Panel4.ForeColor = System.Drawing.Color.White
        Me.Panel4.Location = New System.Drawing.Point(455, 56)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(74, 21)
        Me.Panel4.TabIndex = 61
        '
        'Lbl_Tran_Mode1
        '
        Me.Lbl_Tran_Mode1.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode1.Location = New System.Drawing.Point(2, 1)
        Me.Lbl_Tran_Mode1.Name = "Lbl_Tran_Mode1"
        Me.Lbl_Tran_Mode1.Size = New System.Drawing.Size(68, 16)
        Me.Lbl_Tran_Mode1.TabIndex = 0
        Me.Lbl_Tran_Mode1.Text = "NEW MODE"
        Me.Lbl_Tran_Mode1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Panel2.Controls.Add(Me.Btn_Clear)
        Me.Panel2.Controls.Add(Me.Btn_Close)
        Me.Panel2.Controls.Add(Me.Btn_Delete)
        Me.Panel2.Controls.Add(Me.Btn_Save)
        Me.Panel2.ForeColor = System.Drawing.Color.White
        Me.Panel2.Location = New System.Drawing.Point(543, 90)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(62, 126)
        Me.Panel2.TabIndex = 60
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(3, 64)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear.TabIndex = 8
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(3, 95)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 9
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Delete
        '
        Me.Btn_Delete.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Delete.Location = New System.Drawing.Point(3, 34)
        Me.Btn_Delete.Name = "Btn_Delete"
        Me.Btn_Delete.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Delete.TabIndex = 7
        Me.Btn_Delete.Text = "&Delete"
        Me.Btn_Delete.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(3, 4)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save.TabIndex = 6
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Txt_ExpGroup_Order
        '
        Me.Txt_ExpGroup_Order.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_ExpGroup_Order.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_ExpGroup_Order.Location = New System.Drawing.Point(108, 110)
        Me.Txt_ExpGroup_Order.MaxLength = 50
        Me.Txt_ExpGroup_Order.Name = "Txt_ExpGroup_Order"
        Me.Txt_ExpGroup_Order.Size = New System.Drawing.Size(68, 21)
        Me.Txt_ExpGroup_Order.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Location = New System.Drawing.Point(10, 114)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(76, 13)
        Me.Label4.TabIndex = 38
        Me.Label4.Text = "Group Order"
        '
        'Txt_ExpGroupName
        '
        Me.Txt_ExpGroupName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_ExpGroupName.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_ExpGroupName.Location = New System.Drawing.Point(108, 83)
        Me.Txt_ExpGroupName.MaxLength = 50
        Me.Txt_ExpGroupName.Name = "Txt_ExpGroupName"
        Me.Txt_ExpGroupName.Size = New System.Drawing.Size(421, 21)
        Me.Txt_ExpGroupName.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Location = New System.Drawing.Point(10, 87)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(76, 17)
        Me.Label3.TabIndex = 36
        Me.Label3.Text = "Group Name"
        '
        'Btn_Find
        '
        Me.Btn_Find.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.F2_Button
        Me.Btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find.ForeColor = System.Drawing.Color.White
        Me.Btn_Find.Location = New System.Drawing.Point(217, 56)
        Me.Btn_Find.Name = "Btn_Find"
        Me.Btn_Find.Size = New System.Drawing.Size(29, 21)
        Me.Btn_Find.TabIndex = 1
        Me.Btn_Find.TabStop = False
        Me.Btn_Find.Text = "F2"
        Me.Btn_Find.UseVisualStyleBackColor = False
        '
        'Txt_ExpGroupID
        '
        Me.Txt_ExpGroupID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_ExpGroupID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_ExpGroupID.Location = New System.Drawing.Point(108, 56)
        Me.Txt_ExpGroupID.MaxLength = 50
        Me.Txt_ExpGroupID.Name = "Txt_ExpGroupID"
        Me.Txt_ExpGroupID.Size = New System.Drawing.Size(105, 21)
        Me.Txt_ExpGroupID.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Location = New System.Drawing.Point(10, 60)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(57, 13)
        Me.Label2.TabIndex = 33
        Me.Label2.Text = "Group ID"
        '
        'Tab_AccHead
        '
        Me.Tab_AccHead.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.LeftGradiant
        Me.Tab_AccHead.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Tab_AccHead.Controls.Add(Me.Grid_Searchhelper2)
        Me.Tab_AccHead.Controls.Add(Me.Label16)
        Me.Tab_AccHead.Controls.Add(Me.Cmb_DiscAllowed)
        Me.Tab_AccHead.Controls.Add(Me.Label15)
        Me.Tab_AccHead.Controls.Add(Me.Label11)
        Me.Tab_AccHead.Controls.Add(Me.Cmb_GrpName)
        Me.Tab_AccHead.Controls.Add(Me.Label10)
        Me.Tab_AccHead.Controls.Add(Me.Cmb_ParrentExpID)
        Me.Tab_AccHead.Controls.Add(Me.Label9)
        Me.Tab_AccHead.Controls.Add(Me.Dgrd_History1)
        Me.Tab_AccHead.Controls.Add(Me.Tran_mode_Pnl)
        Me.Tab_AccHead.Controls.Add(Me.Panel3)
        Me.Tab_AccHead.Controls.Add(Me.Label8)
        Me.Tab_AccHead.Controls.Add(Me.Cmb_ExpActive)
        Me.Tab_AccHead.Controls.Add(Me.Txt_ExpOrder)
        Me.Tab_AccHead.Controls.Add(Me.Label5)
        Me.Tab_AccHead.Controls.Add(Me.Txt_ExpName)
        Me.Tab_AccHead.Controls.Add(Me.Label6)
        Me.Tab_AccHead.Controls.Add(Me.Btn_Find1)
        Me.Tab_AccHead.Controls.Add(Me.Txt_ExpID)
        Me.Tab_AccHead.Controls.Add(Me.Label7)
        Me.Tab_AccHead.Location = New System.Drawing.Point(4, 22)
        Me.Tab_AccHead.Name = "Tab_AccHead"
        Me.Tab_AccHead.Padding = New System.Windows.Forms.Padding(3)
        Me.Tab_AccHead.Size = New System.Drawing.Size(610, 361)
        Me.Tab_AccHead.TabIndex = 1
        Me.Tab_AccHead.Text = "Expense Master Settings"
        Me.Tab_AccHead.UseVisualStyleBackColor = True
        '
        'Grid_Searchhelper2
        '
        Me.Grid_Searchhelper2.BackColor = System.Drawing.Color.RoyalBlue
        Me.Grid_Searchhelper2.CausesValidation = False
        Me.Grid_Searchhelper2.Location = New System.Drawing.Point(217, 105)
        Me.Grid_Searchhelper2.Name = "Grid_Searchhelper2"
        Me.Grid_Searchhelper2.Padding = New System.Windows.Forms.Padding(1)
        Me.Grid_Searchhelper2.Search_Query = ""
        Me.Grid_Searchhelper2.Size = New System.Drawing.Size(312, 26)
        Me.Grid_Searchhelper2.TabIndex = 134
        Me.Grid_Searchhelper2.TabStop = False
        Me.Grid_Searchhelper2.Visible = False
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Location = New System.Drawing.Point(9, 189)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(77, 13)
        Me.Label16.TabIndex = 105
        Me.Label16.Text = "Disc Allowed"
        '
        'Cmb_DiscAllowed
        '
        Me.Cmb_DiscAllowed.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_DiscAllowed.FormattingEnabled = True
        Me.Cmb_DiscAllowed.Location = New System.Drawing.Point(108, 191)
        Me.Cmb_DiscAllowed.Name = "Cmb_DiscAllowed"
        Me.Cmb_DiscAllowed.Size = New System.Drawing.Size(68, 21)
        Me.Cmb_DiscAllowed.TabIndex = 14
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(105, 25)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(117, 17)
        Me.Label15.TabIndex = 103
        Me.Label15.Text = "Expense Master"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Location = New System.Drawing.Point(9, 164)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(76, 13)
        Me.Label11.TabIndex = 101
        Me.Label11.Text = "Group Name"
        '
        'Cmb_GrpName
        '
        Me.Cmb_GrpName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_GrpName.FormattingEnabled = True
        Me.Cmb_GrpName.Location = New System.Drawing.Point(108, 164)
        Me.Cmb_GrpName.Name = "Cmb_GrpName"
        Me.Cmb_GrpName.Size = New System.Drawing.Size(220, 21)
        Me.Cmb_GrpName.TabIndex = 13
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Location = New System.Drawing.Point(9, 138)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(66, 13)
        Me.Label10.TabIndex = 99
        Me.Label10.Text = "Parrent ID"
        '
        'Cmb_ParrentExpID
        '
        Me.Cmb_ParrentExpID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_ParrentExpID.FormattingEnabled = True
        Me.Cmb_ParrentExpID.Location = New System.Drawing.Point(108, 137)
        Me.Cmb_ParrentExpID.Name = "Cmb_ParrentExpID"
        Me.Cmb_ParrentExpID.Size = New System.Drawing.Size(220, 21)
        Me.Cmb_ParrentExpID.TabIndex = 12
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.ForeColor = System.Drawing.Color.OrangeRed
        Me.Label9.Location = New System.Drawing.Point(85, 77)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(14, 13)
        Me.Label9.TabIndex = 97
        Me.Label9.Text = "*"
        '
        'Dgrd_History1
        '
        Me.Dgrd_History1.AllowUserToAddRows = False
        Me.Dgrd_History1.AllowUserToDeleteRows = False
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(252, Byte), Integer))
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.Color.Navy
        Me.Dgrd_History1.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle4
        Me.Dgrd_History1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Dgrd_History1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(87, Byte), Integer), CType(CType(157, Byte), Integer))
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgrd_History1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle5
        Me.Dgrd_History1.ColumnHeadersHeight = 20
        Me.Dgrd_History1.Location = New System.Drawing.Point(6, 247)
        Me.Dgrd_History1.MultiSelect = False
        Me.Dgrd_History1.Name = "Dgrd_History1"
        Me.Dgrd_History1.ReadOnly = True
        Me.Dgrd_History1.RowHeadersVisible = False
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(254, Byte), Integer))
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.Color.Navy
        Me.Dgrd_History1.RowsDefaultCellStyle = DataGridViewCellStyle6
        Me.Dgrd_History1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.Dgrd_History1.Size = New System.Drawing.Size(599, 108)
        Me.Dgrd_History1.TabIndex = 63
        '
        'Tran_mode_Pnl
        '
        Me.Tran_mode_Pnl.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Tran_mode_Pnl.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.F2_Button
        Me.Tran_mode_Pnl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Tran_mode_Pnl.Controls.Add(Me.Lbl_Tran_Mode2)
        Me.Tran_mode_Pnl.ForeColor = System.Drawing.Color.White
        Me.Tran_mode_Pnl.Location = New System.Drawing.Point(455, 56)
        Me.Tran_mode_Pnl.Name = "Tran_mode_Pnl"
        Me.Tran_mode_Pnl.Size = New System.Drawing.Size(74, 21)
        Me.Tran_mode_Pnl.TabIndex = 62
        '
        'Lbl_Tran_Mode2
        '
        Me.Lbl_Tran_Mode2.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode2.Location = New System.Drawing.Point(2, 1)
        Me.Lbl_Tran_Mode2.Name = "Lbl_Tran_Mode2"
        Me.Lbl_Tran_Mode2.Size = New System.Drawing.Size(68, 16)
        Me.Lbl_Tran_Mode2.TabIndex = 0
        Me.Lbl_Tran_Mode2.Text = "NEW MODE"
        Me.Lbl_Tran_Mode2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Panel3.Controls.Add(Me.Btn_Clear1)
        Me.Panel3.Controls.Add(Me.Btn_Close1)
        Me.Panel3.Controls.Add(Me.Btn_Delete1)
        Me.Panel3.Controls.Add(Me.Btn_Save1)
        Me.Panel3.ForeColor = System.Drawing.Color.White
        Me.Panel3.Location = New System.Drawing.Point(543, 90)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(62, 126)
        Me.Panel3.TabIndex = 61
        '
        'Btn_Clear1
        '
        Me.Btn_Clear1.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Clear1.CausesValidation = False
        Me.Btn_Clear1.Location = New System.Drawing.Point(3, 64)
        Me.Btn_Clear1.Name = "Btn_Clear1"
        Me.Btn_Clear1.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear1.TabIndex = 18
        Me.Btn_Clear1.Text = "C&lear"
        Me.Btn_Clear1.UseVisualStyleBackColor = True
        '
        'Btn_Close1
        '
        Me.Btn_Close1.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Close1.CausesValidation = False
        Me.Btn_Close1.Location = New System.Drawing.Point(3, 95)
        Me.Btn_Close1.Name = "Btn_Close1"
        Me.Btn_Close1.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close1.TabIndex = 19
        Me.Btn_Close1.Text = "&Close"
        Me.Btn_Close1.UseVisualStyleBackColor = True
        '
        'Btn_Delete1
        '
        Me.Btn_Delete1.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Delete1.Location = New System.Drawing.Point(3, 34)
        Me.Btn_Delete1.Name = "Btn_Delete1"
        Me.Btn_Delete1.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Delete1.TabIndex = 17
        Me.Btn_Delete1.Text = "D&elete"
        Me.Btn_Delete1.UseVisualStyleBackColor = True
        '
        'Btn_Save1
        '
        Me.Btn_Save1.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save1.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Save1.ForeColor = System.Drawing.Color.White
        Me.Btn_Save1.Location = New System.Drawing.Point(3, 4)
        Me.Btn_Save1.Name = "Btn_Save1"
        Me.Btn_Save1.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save1.TabIndex = 16
        Me.Btn_Save1.Text = "&Save"
        Me.Btn_Save1.UseVisualStyleBackColor = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Location = New System.Drawing.Point(9, 219)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(43, 13)
        Me.Label8.TabIndex = 56
        Me.Label8.Text = "Active"
        '
        'Cmb_ExpActive
        '
        Me.Cmb_ExpActive.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_ExpActive.FormattingEnabled = True
        Me.Cmb_ExpActive.Location = New System.Drawing.Point(108, 218)
        Me.Cmb_ExpActive.Name = "Cmb_ExpActive"
        Me.Cmb_ExpActive.Size = New System.Drawing.Size(68, 21)
        Me.Cmb_ExpActive.TabIndex = 15
        '
        'Txt_ExpOrder
        '
        Me.Txt_ExpOrder.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_ExpOrder.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_ExpOrder.Location = New System.Drawing.Point(108, 110)
        Me.Txt_ExpOrder.MaxLength = 50
        Me.Txt_ExpOrder.Name = "Txt_ExpOrder"
        Me.Txt_ExpOrder.Size = New System.Drawing.Size(68, 21)
        Me.Txt_ExpOrder.TabIndex = 11
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Location = New System.Drawing.Point(9, 112)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(39, 13)
        Me.Label5.TabIndex = 45
        Me.Label5.Text = "Order"
        '
        'Txt_ExpName
        '
        Me.Txt_ExpName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_ExpName.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_ExpName.Location = New System.Drawing.Point(108, 83)
        Me.Txt_ExpName.MaxLength = 50
        Me.Txt_ExpName.Name = "Txt_ExpName"
        Me.Txt_ExpName.Size = New System.Drawing.Size(421, 21)
        Me.Txt_ExpName.TabIndex = 10
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Location = New System.Drawing.Point(9, 86)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(89, 13)
        Me.Label6.TabIndex = 43
        Me.Label6.Text = "Expense Name"
        '
        'Btn_Find1
        '
        Me.Btn_Find1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find1.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.F2_Button
        Me.Btn_Find1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find1.ForeColor = System.Drawing.Color.White
        Me.Btn_Find1.Location = New System.Drawing.Point(217, 56)
        Me.Btn_Find1.Name = "Btn_Find1"
        Me.Btn_Find1.Size = New System.Drawing.Size(29, 21)
        Me.Btn_Find1.TabIndex = 41
        Me.Btn_Find1.TabStop = False
        Me.Btn_Find1.Text = "F2"
        Me.Btn_Find1.UseVisualStyleBackColor = False
        '
        'Txt_ExpID
        '
        Me.Txt_ExpID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_ExpID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_ExpID.Location = New System.Drawing.Point(108, 56)
        Me.Txt_ExpID.MaxLength = 50
        Me.Txt_ExpID.Name = "Txt_ExpID"
        Me.Txt_ExpID.Size = New System.Drawing.Size(105, 21)
        Me.Txt_ExpID.TabIndex = 9
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Location = New System.Drawing.Point(9, 60)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(70, 13)
        Me.Label7.TabIndex = 40
        Me.Label7.Text = "Expense ID"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Left
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(90, 412)
        Me.PictureBox1.TabIndex = 24
        Me.PictureBox1.TabStop = False
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.Btn_ExpMaster)
        Me.Panel5.Controls.Add(Me.Btn_ExpGroup)
        Me.Panel5.Location = New System.Drawing.Point(108, 24)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(610, 23)
        Me.Panel5.TabIndex = 25
        '
        'Btn_ExpMaster
        '
        Me.Btn_ExpMaster.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_ExpMaster.BackgroundImage = CType(resources.GetObject("Btn_ExpMaster.BackgroundImage"), System.Drawing.Image)
        Me.Btn_ExpMaster.ForeColor = System.Drawing.Color.White
        Me.Btn_ExpMaster.Location = New System.Drawing.Point(292, -1)
        Me.Btn_ExpMaster.Name = "Btn_ExpMaster"
        Me.Btn_ExpMaster.Size = New System.Drawing.Size(318, 28)
        Me.Btn_ExpMaster.TabIndex = 101
        Me.Btn_ExpMaster.TabStop = False
        Me.Btn_ExpMaster.Text = "E x p e n s e   M a s t e r"
        Me.Btn_ExpMaster.UseVisualStyleBackColor = False
        '
        'Btn_ExpGroup
        '
        Me.Btn_ExpGroup.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_ExpGroup.BackgroundImage = CType(resources.GetObject("Btn_ExpGroup.BackgroundImage"), System.Drawing.Image)
        Me.Btn_ExpGroup.ForeColor = System.Drawing.Color.White
        Me.Btn_ExpGroup.Location = New System.Drawing.Point(-8, -1)
        Me.Btn_ExpGroup.Name = "Btn_ExpGroup"
        Me.Btn_ExpGroup.Size = New System.Drawing.Size(303, 28)
        Me.Btn_ExpGroup.TabIndex = 100
        Me.Btn_ExpGroup.TabStop = False
        Me.Btn_ExpGroup.Text = "E x p e n s e   G r o u p"
        Me.Btn_ExpGroup.UseVisualStyleBackColor = False
        '
        'Panel6
        '
        Me.Panel6.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Panel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel6.Location = New System.Drawing.Point(96, 24)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(13, 385)
        Me.Panel6.TabIndex = 26
        '
        'Expense_Master_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.LeftGradiant
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(720, 412)
        Me.Controls.Add(Me.Panel6)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Tab_AccountHead)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Expense_Master_Frm"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Tab_AccountHead.ResumeLayout(False)
        Me.Tab_AccGrp.ResumeLayout(False)
        Me.Tab_AccGrp.PerformLayout()
        CType(Me.Dgrd_History, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Tab_AccHead.ResumeLayout(False)
        Me.Tab_AccHead.PerformLayout()
        CType(Me.Dgrd_History1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Tran_mode_Pnl.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel5.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Tab_AccountHead As System.Windows.Forms.TabControl
    Friend WithEvents Tab_AccGrp As System.Windows.Forms.TabPage
    Friend WithEvents Tab_AccHead As System.Windows.Forms.TabPage
    Friend WithEvents Txt_ExpGroupID As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Btn_Find As System.Windows.Forms.Button
    Friend WithEvents Txt_ExpGroup_Order As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Txt_ExpGroupName As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Delete As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Txt_ExpOrder As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Txt_ExpName As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Btn_Find1 As System.Windows.Forms.Button
    Friend WithEvents Txt_ExpID As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear1 As System.Windows.Forms.Button
    Friend WithEvents Btn_Close1 As System.Windows.Forms.Button
    Friend WithEvents Btn_Delete1 As System.Windows.Forms.Button
    Friend WithEvents Btn_Save1 As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Cmb_ExpActive As System.Windows.Forms.ComboBox
    Friend WithEvents Tran_mode_Pnl As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode2 As System.Windows.Forms.Label
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode1 As System.Windows.Forms.Label
    Friend WithEvents Dgrd_History As System.Windows.Forms.DataGridView
    Friend WithEvents Dgrd_History1 As System.Windows.Forms.DataGridView
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Cmb_ParrentExpID As System.Windows.Forms.ComboBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Cmb_GroupActive As System.Windows.Forms.ComboBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Cmb_ExpParrantGroup As System.Windows.Forms.ComboBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Cmb_GrpName As System.Windows.Forms.ComboBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Btn_ExpMaster As System.Windows.Forms.Button
    Friend WithEvents Btn_ExpGroup As System.Windows.Forms.Button
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Cmb_DiscAllowed As System.Windows.Forms.ComboBox
    Friend WithEvents Grid_Searchhelper1 As REAL_CLINIC.Grid_Searchhelper
    Friend WithEvents Grid_Searchhelper2 As REAL_CLINIC.Grid_Searchhelper
End Class
