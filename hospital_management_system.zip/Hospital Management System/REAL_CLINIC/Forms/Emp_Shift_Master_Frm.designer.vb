﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Emp_Shift_Master_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Emp_Shift_Master_Frm))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.Txt_ShiftID = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Delete = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.Btn_Find = New System.Windows.Forms.Button
        Me.Label7 = New System.Windows.Forms.Label
        Me.Dgvw_Shift_Master = New System.Windows.Forms.DataGridView
        Me.Txt_Totime = New System.Windows.Forms.DateTimePicker
        Me.Label2 = New System.Windows.Forms.Label
        Me.Txt_FromTime = New System.Windows.Forms.DateTimePicker
        Me.Pnl_Header.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Pnl_Tran_mode.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        CType(Me.Dgvw_Shift_Master, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Menu_Bkg
        Me.Pnl_Header.Controls.Add(Me.Label1)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(559, 24)
        Me.Pnl_Header.TabIndex = 100000
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(7, 1)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(176, 18)
        Me.Label1.TabIndex = 1000
        Me.Label1.Text = "Employee Shift Master"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Left
        Me.PictureBox1.Location = New System.Drawing.Point(0, 24)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(113, 327)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox1.TabIndex = 20
        Me.PictureBox1.TabStop = False
        '
        'Txt_ShiftID
        '
        Me.Txt_ShiftID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_ShiftID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_ShiftID.Location = New System.Drawing.Point(211, 61)
        Me.Txt_ShiftID.Name = "Txt_ShiftID"
        Me.Txt_ShiftID.Size = New System.Drawing.Size(119, 21)
        Me.Txt_ShiftID.TabIndex = 0
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.Transparent
        Me.Label3.Location = New System.Drawing.Point(119, 61)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(49, 13)
        Me.Label3.TabIndex = 24
        Me.Label3.Text = "Shift ID"
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(401, 61)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(74, 22)
        Me.Pnl_Tran_mode.TabIndex = 38
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(2, 1)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(68, 16)
        Me.Lbl_Tran_Mode.TabIndex = 0
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.ForeColor = System.Drawing.Color.Transparent
        Me.Label9.Location = New System.Drawing.Point(119, 100)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(65, 13)
        Me.Label9.TabIndex = 37
        Me.Label9.Text = "Shift From"
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Delete)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(493, 61)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(62, 126)
        Me.Pnl_Common_Btn.TabIndex = 4
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(2, 63)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear.TabIndex = 2
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(2, 94)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 3
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Delete
        '
        Me.Btn_Delete.BackgroundImage = CType(resources.GetObject("Btn_Delete.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Delete.Location = New System.Drawing.Point(2, 33)
        Me.Btn_Delete.Name = "Btn_Delete"
        Me.Btn_Delete.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Delete.TabIndex = 1
        Me.Btn_Delete.Text = "Delete"
        Me.Btn_Delete.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(2, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save.TabIndex = 0
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Btn_Find
        '
        Me.Btn_Find.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find.BackgroundImage = CType(resources.GetObject("Btn_Find.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find.ForeColor = System.Drawing.Color.White
        Me.Btn_Find.Location = New System.Drawing.Point(331, 61)
        Me.Btn_Find.Name = "Btn_Find"
        Me.Btn_Find.Size = New System.Drawing.Size(29, 21)
        Me.Btn_Find.TabIndex = 1
        Me.Btn_Find.TabStop = False
        Me.Btn_Find.Text = "F2"
        Me.Btn_Find.UseVisualStyleBackColor = False
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.FromArgb(CType(CType(19, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(153, Byte), Integer))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(119, 198)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(436, 18)
        Me.Label7.TabIndex = 144
        Me.Label7.Text = "Shift Details"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Dgvw_Shift_Master
        '
        Me.Dgvw_Shift_Master.AllowUserToAddRows = False
        Me.Dgvw_Shift_Master.AllowUserToDeleteRows = False
        Me.Dgvw_Shift_Master.AllowUserToResizeColumns = False
        Me.Dgvw_Shift_Master.AllowUserToResizeRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(248, Byte), Integer))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.DarkBlue
        Me.Dgvw_Shift_Master.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.Dgvw_Shift_Master.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(236, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Dgvw_Shift_Master.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(75, Byte), Integer), CType(CType(116, Byte), Integer), CType(CType(165, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgvw_Shift_Master.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.Dgvw_Shift_Master.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Dgvw_Shift_Master.Location = New System.Drawing.Point(119, 219)
        Me.Dgvw_Shift_Master.Name = "Dgvw_Shift_Master"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(179, Byte), Integer))
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgvw_Shift_Master.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.Dgvw_Shift_Master.RowHeadersVisible = False
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(CType(CType(219, Byte), Integer), CType(CType(227, Byte), Integer), CType(CType(249, Byte), Integer))
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.Color.DarkBlue
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.DeepSkyBlue
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black
        Me.Dgvw_Shift_Master.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.Dgvw_Shift_Master.Size = New System.Drawing.Size(436, 125)
        Me.Dgvw_Shift_Master.TabIndex = 143
        '
        'Txt_Totime
        '
        Me.Txt_Totime.CustomFormat = "hh : mm tt"
        Me.Txt_Totime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Txt_Totime.Location = New System.Drawing.Point(211, 129)
        Me.Txt_Totime.Name = "Txt_Totime"
        Me.Txt_Totime.ShowUpDown = True
        Me.Txt_Totime.Size = New System.Drawing.Size(119, 21)
        Me.Txt_Totime.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.Transparent
        Me.Label2.Location = New System.Drawing.Point(119, 133)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(50, 13)
        Me.Label2.TabIndex = 100003
        Me.Label2.Text = "Shift To"
        '
        'Txt_FromTime
        '
        Me.Txt_FromTime.CustomFormat = "hh : mm tt"
        Me.Txt_FromTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Txt_FromTime.Location = New System.Drawing.Point(211, 92)
        Me.Txt_FromTime.Name = "Txt_FromTime"
        Me.Txt_FromTime.ShowUpDown = True
        Me.Txt_FromTime.Size = New System.Drawing.Size(119, 21)
        Me.Txt_FromTime.TabIndex = 2
        '
        'Emp_Shift_Master_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(559, 351)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Txt_Totime)
        Me.Controls.Add(Me.Txt_FromTime)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Dgvw_Shift_Master)
        Me.Controls.Add(Me.Btn_Find)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.Pnl_Tran_mode)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Txt_ShiftID)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Emp_Shift_Master_Frm"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Pnl_Tran_mode.ResumeLayout(False)
        Me.Pnl_Common_Btn.ResumeLayout(False)
        CType(Me.Dgvw_Shift_Master, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Txt_ShiftID As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Delete As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Btn_Find As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Dgvw_Shift_Master As System.Windows.Forms.DataGridView
    Friend WithEvents Txt_Totime As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Txt_FromTime As System.Windows.Forms.DateTimePicker
End Class
