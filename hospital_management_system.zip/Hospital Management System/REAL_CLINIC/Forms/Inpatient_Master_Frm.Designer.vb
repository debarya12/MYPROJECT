﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Inpatient_Master_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Inpatient_Master_Frm))
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Label3 = New System.Windows.Forms.Label
        Me.Txt_IP_ID = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Txt_OP_ID = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Dtp_TranDate = New System.Windows.Forms.DateTimePicker
        Me.Txt_PatientID = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Cmb_Service = New System.Windows.Forms.ComboBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.Cmb_Dept = New System.Windows.Forms.ComboBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Cmb_Doctor = New System.Windows.Forms.ComboBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.Cmb_AdmitType = New System.Windows.Forms.ComboBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Cmb_Diagnose = New System.Windows.Forms.ComboBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Txt_AdmitReason = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Txt_AmbulatoryStatus = New System.Windows.Forms.TextBox
        Me.Cmb_DR_InCharge = New System.Windows.Forms.ComboBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.Txt_StayDays = New System.Windows.Forms.TextBox
        Me.Txt_AccID = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Delete = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.Btn_NewOP = New System.Windows.Forms.Button
        Me.Btn_Find1 = New System.Windows.Forms.Button
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label
        Me.Cmb_ArrivalMode = New System.Windows.Forms.ComboBox
        Me.Cmb_Status = New System.Windows.Forms.ComboBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.DTP_ServiceDay = New System.Windows.Forms.DateTimePicker
        Me.Btn_Find = New System.Windows.Forms.Button
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.PictureBox2 = New System.Windows.Forms.PictureBox
        Me.Btn_New = New System.Windows.Forms.Button
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Patient_Info1 = New REAL_CLINIC.Patient_Info
        Me.Pnl_Header.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.Pnl_Tran_mode.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = CType(resources.GetObject("Pnl_Header.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Header.Controls.Add(Me.Label3)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(797, 24)
        Me.Pnl_Header.TabIndex = 112
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(3, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(174, 18)
        Me.Label3.TabIndex = 125
        Me.Label3.Text = "Inpatient Registration"
        '
        'Txt_IP_ID
        '
        Me.Txt_IP_ID.BackColor = System.Drawing.Color.White
        Me.Txt_IP_ID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_IP_ID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_IP_ID.Location = New System.Drawing.Point(109, 30)
        Me.Txt_IP_ID.MaxLength = 10
        Me.Txt_IP_ID.Name = "Txt_IP_ID"
        Me.Txt_IP_ID.Size = New System.Drawing.Size(187, 21)
        Me.Txt_IP_ID.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(3, 34)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(35, 13)
        Me.Label2.TabIndex = 114
        Me.Label2.Text = "IP ID"
        '
        'Txt_OP_ID
        '
        Me.Txt_OP_ID.BackColor = System.Drawing.Color.White
        Me.Txt_OP_ID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_OP_ID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_OP_ID.Location = New System.Drawing.Point(439, 30)
        Me.Txt_OP_ID.MaxLength = 10
        Me.Txt_OP_ID.Name = "Txt_OP_ID"
        Me.Txt_OP_ID.Size = New System.Drawing.Size(184, 21)
        Me.Txt_OP_ID.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(344, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 13)
        Me.Label1.TabIndex = 116
        Me.Label1.Text = "OP ID"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label16.Location = New System.Drawing.Point(3, 57)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(34, 13)
        Me.Label16.TabIndex = 123
        Me.Label16.Text = "Date"
        '
        'Dtp_TranDate
        '
        Me.Dtp_TranDate.CustomFormat = "dd/MM/yyyy hh:mm tt"
        Me.Dtp_TranDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_TranDate.Location = New System.Drawing.Point(109, 53)
        Me.Dtp_TranDate.Name = "Dtp_TranDate"
        Me.Dtp_TranDate.Size = New System.Drawing.Size(186, 21)
        Me.Dtp_TranDate.TabIndex = 3
        '
        'Txt_PatientID
        '
        Me.Txt_PatientID.BackColor = System.Drawing.Color.White
        Me.Txt_PatientID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_PatientID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PatientID.Location = New System.Drawing.Point(439, 53)
        Me.Txt_PatientID.Name = "Txt_PatientID"
        Me.Txt_PatientID.ReadOnly = True
        Me.Txt_PatientID.Size = New System.Drawing.Size(184, 21)
        Me.Txt_PatientID.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(344, 57)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(64, 13)
        Me.Label4.TabIndex = 125
        Me.Label4.Text = "Patient ID"
        '
        'Cmb_Service
        '
        Me.Cmb_Service.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Service.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Service.FormattingEnabled = True
        Me.Cmb_Service.ItemHeight = 13
        Me.Cmb_Service.Location = New System.Drawing.Point(109, 239)
        Me.Cmb_Service.Name = "Cmb_Service"
        Me.Cmb_Service.Size = New System.Drawing.Size(187, 21)
        Me.Cmb_Service.TabIndex = 7
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.ForeColor = System.Drawing.Color.Black
        Me.Label19.Location = New System.Drawing.Point(3, 243)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(49, 13)
        Me.Label19.TabIndex = 128
        Me.Label19.Text = "Service"
        '
        'Cmb_Dept
        '
        Me.Cmb_Dept.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Dept.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Dept.FormattingEnabled = True
        Me.Cmb_Dept.ItemHeight = 13
        Me.Cmb_Dept.Location = New System.Drawing.Point(439, 216)
        Me.Cmb_Dept.Name = "Cmb_Dept"
        Me.Cmb_Dept.Size = New System.Drawing.Size(187, 21)
        Me.Cmb_Dept.TabIndex = 6
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(340, 220)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(76, 13)
        Me.Label7.TabIndex = 130
        Me.Label7.Text = "Department"
        '
        'Cmb_Doctor
        '
        Me.Cmb_Doctor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Doctor.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Doctor.FormattingEnabled = True
        Me.Cmb_Doctor.ItemHeight = 13
        Me.Cmb_Doctor.Location = New System.Drawing.Point(109, 216)
        Me.Cmb_Doctor.Name = "Cmb_Doctor"
        Me.Cmb_Doctor.Size = New System.Drawing.Size(187, 21)
        Me.Cmb_Doctor.TabIndex = 5
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(3, 220)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(45, 13)
        Me.Label8.TabIndex = 132
        Me.Label8.Text = "Doctor"
        '
        'Cmb_AdmitType
        '
        Me.Cmb_AdmitType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_AdmitType.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_AdmitType.FormattingEnabled = True
        Me.Cmb_AdmitType.ItemHeight = 13
        Me.Cmb_AdmitType.Location = New System.Drawing.Point(439, 262)
        Me.Cmb_AdmitType.Name = "Cmb_AdmitType"
        Me.Cmb_AdmitType.Size = New System.Drawing.Size(187, 21)
        Me.Cmb_AdmitType.TabIndex = 10
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(340, 266)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(72, 13)
        Me.Label5.TabIndex = 134
        Me.Label5.Text = "Admit Type"
        '
        'Cmb_Diagnose
        '
        Me.Cmb_Diagnose.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Diagnose.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Diagnose.FormattingEnabled = True
        Me.Cmb_Diagnose.ItemHeight = 13
        Me.Cmb_Diagnose.Location = New System.Drawing.Point(439, 239)
        Me.Cmb_Diagnose.Name = "Cmb_Diagnose"
        Me.Cmb_Diagnose.Size = New System.Drawing.Size(187, 21)
        Me.Cmb_Diagnose.TabIndex = 8
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(340, 243)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(95, 13)
        Me.Label6.TabIndex = 136
        Me.Label6.Text = "Diagnose Detail"
        '
        'Txt_AdmitReason
        '
        Me.Txt_AdmitReason.BackColor = System.Drawing.Color.White
        Me.Txt_AdmitReason.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_AdmitReason.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_AdmitReason.Location = New System.Drawing.Point(109, 285)
        Me.Txt_AdmitReason.MaxLength = 250
        Me.Txt_AdmitReason.Multiline = True
        Me.Txt_AdmitReason.Name = "Txt_AdmitReason"
        Me.Txt_AdmitReason.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Txt_AdmitReason.Size = New System.Drawing.Size(516, 41)
        Me.Txt_AdmitReason.TabIndex = 11
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(3, 298)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(86, 13)
        Me.Label9.TabIndex = 138
        Me.Label9.Text = "Admit Reason"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(3, 266)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(79, 13)
        Me.Label10.TabIndex = 140
        Me.Label10.Text = "Arrival Mode"
        '
        'Txt_AmbulatoryStatus
        '
        Me.Txt_AmbulatoryStatus.BackColor = System.Drawing.Color.White
        Me.Txt_AmbulatoryStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_AmbulatoryStatus.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_AmbulatoryStatus.Location = New System.Drawing.Point(109, 328)
        Me.Txt_AmbulatoryStatus.MaxLength = 150
        Me.Txt_AmbulatoryStatus.Multiline = True
        Me.Txt_AmbulatoryStatus.Name = "Txt_AmbulatoryStatus"
        Me.Txt_AmbulatoryStatus.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Txt_AmbulatoryStatus.Size = New System.Drawing.Size(516, 41)
        Me.Txt_AmbulatoryStatus.TabIndex = 12
        '
        'Cmb_DR_InCharge
        '
        Me.Cmb_DR_InCharge.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_DR_InCharge.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_DR_InCharge.FormattingEnabled = True
        Me.Cmb_DR_InCharge.ItemHeight = 13
        Me.Cmb_DR_InCharge.Location = New System.Drawing.Point(444, 371)
        Me.Cmb_DR_InCharge.Name = "Cmb_DR_InCharge"
        Me.Cmb_DR_InCharge.Size = New System.Drawing.Size(183, 21)
        Me.Cmb_DR_InCharge.TabIndex = 14
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(340, 375)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(105, 13)
        Me.Label11.TabIndex = 143
        Me.Label11.Text = "Doctor In-Charge"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label12.Location = New System.Drawing.Point(3, 398)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(108, 13)
        Me.Label12.TabIndex = 145
        Me.Label12.Text = "Exp. Service  Date"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label14.Location = New System.Drawing.Point(340, 398)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(90, 13)
        Me.Label14.TabIndex = 148
        Me.Label14.Text = "Exp. Stay Days"
        '
        'Txt_StayDays
        '
        Me.Txt_StayDays.BackColor = System.Drawing.Color.White
        Me.Txt_StayDays.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_StayDays.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_StayDays.Location = New System.Drawing.Point(444, 394)
        Me.Txt_StayDays.MaxLength = 2
        Me.Txt_StayDays.Name = "Txt_StayDays"
        Me.Txt_StayDays.Size = New System.Drawing.Size(182, 21)
        Me.Txt_StayDays.TabIndex = 17
        Me.Txt_StayDays.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Txt_AccID
        '
        Me.Txt_AccID.BackColor = System.Drawing.Color.Silver
        Me.Txt_AccID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_AccID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_AccID.Location = New System.Drawing.Point(109, 417)
        Me.Txt_AccID.Name = "Txt_AccID"
        Me.Txt_AccID.ReadOnly = True
        Me.Txt_AccID.Size = New System.Drawing.Size(517, 21)
        Me.Txt_AccID.TabIndex = 18
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.ForeColor = System.Drawing.Color.Black
        Me.Label15.Location = New System.Drawing.Point(3, 421)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(69, 13)
        Me.Label15.TabIndex = 151
        Me.Label15.Text = "Account ID"
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Delete)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(196, 446)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(344, 34)
        Me.Pnl_Common_Btn.TabIndex = 201
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(256, 3)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(83, 28)
        Me.Btn_Close.TabIndex = 22
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(172, 3)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(83, 28)
        Me.Btn_Clear.TabIndex = 21
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Delete
        '
        Me.Btn_Delete.BackgroundImage = CType(resources.GetObject("Btn_Delete.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Delete.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Delete.Location = New System.Drawing.Point(87, 3)
        Me.Btn_Delete.Name = "Btn_Delete"
        Me.Btn_Delete.Size = New System.Drawing.Size(83, 28)
        Me.Btn_Delete.TabIndex = 20
        Me.Btn_Delete.Text = "&Delete"
        Me.Btn_Delete.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(2, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(83, 28)
        Me.Btn_Save.TabIndex = 19
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Btn_NewOP
        '
        Me.Btn_NewOP.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_NewOP.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_NewOP.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_NewOP.ForeColor = System.Drawing.Color.White
        Me.Btn_NewOP.Location = New System.Drawing.Point(659, 30)
        Me.Btn_NewOP.Name = "Btn_NewOP"
        Me.Btn_NewOP.Size = New System.Drawing.Size(41, 20)
        Me.Btn_NewOP.TabIndex = 202
        Me.Btn_NewOP.TabStop = False
        Me.Btn_NewOP.Text = "NEW"
        Me.Btn_NewOP.UseVisualStyleBackColor = False
        '
        'Btn_Find1
        '
        Me.Btn_Find1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find1.ForeColor = System.Drawing.Color.White
        Me.Btn_Find1.Location = New System.Drawing.Point(625, 30)
        Me.Btn_Find1.Name = "Btn_Find1"
        Me.Btn_Find1.Size = New System.Drawing.Size(29, 20)
        Me.Btn_Find1.TabIndex = 2
        Me.Btn_Find1.TabStop = False
        Me.Btn_Find1.Text = "F2"
        Me.Btn_Find1.UseVisualStyleBackColor = False
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(719, 30)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(74, 20)
        Me.Pnl_Tran_mode.TabIndex = 203
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(2, 1)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(68, 16)
        Me.Lbl_Tran_Mode.TabIndex = 122
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Cmb_ArrivalMode
        '
        Me.Cmb_ArrivalMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_ArrivalMode.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_ArrivalMode.FormattingEnabled = True
        Me.Cmb_ArrivalMode.ItemHeight = 13
        Me.Cmb_ArrivalMode.Location = New System.Drawing.Point(108, 262)
        Me.Cmb_ArrivalMode.Name = "Cmb_ArrivalMode"
        Me.Cmb_ArrivalMode.Size = New System.Drawing.Size(187, 21)
        Me.Cmb_ArrivalMode.TabIndex = 9
        '
        'Cmb_Status
        '
        Me.Cmb_Status.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Status.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Status.FormattingEnabled = True
        Me.Cmb_Status.ItemHeight = 13
        Me.Cmb_Status.Location = New System.Drawing.Point(109, 371)
        Me.Cmb_Status.Name = "Cmb_Status"
        Me.Cmb_Status.Size = New System.Drawing.Size(187, 21)
        Me.Cmb_Status.TabIndex = 13
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.ForeColor = System.Drawing.Color.Black
        Me.Label17.Location = New System.Drawing.Point(3, 376)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(90, 13)
        Me.Label17.TabIndex = 205
        Me.Label17.Text = "Current Status"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.Transparent
        Me.Label18.ForeColor = System.Drawing.Color.Black
        Me.Label18.Location = New System.Drawing.Point(3, 336)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(74, 13)
        Me.Label18.TabIndex = 207
        Me.Label18.Text = "Ambulatory"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.Color.Transparent
        Me.Label20.ForeColor = System.Drawing.Color.Black
        Me.Label20.Location = New System.Drawing.Point(3, 349)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(44, 13)
        Me.Label20.TabIndex = 206
        Me.Label20.Text = "Status"
        '
        'DTP_ServiceDay
        '
        Me.DTP_ServiceDay.CustomFormat = "dd/MM/yyyy hh:mm tt"
        Me.DTP_ServiceDay.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DTP_ServiceDay.Location = New System.Drawing.Point(109, 394)
        Me.DTP_ServiceDay.Name = "DTP_ServiceDay"
        Me.DTP_ServiceDay.Size = New System.Drawing.Size(186, 21)
        Me.DTP_ServiceDay.TabIndex = 15
        Me.DTP_ServiceDay.Value = New Date(2010, 9, 29, 0, 0, 0, 0)
        '
        'Btn_Find
        '
        Me.Btn_Find.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find.ForeColor = System.Drawing.Color.White
        Me.Btn_Find.Location = New System.Drawing.Point(298, 30)
        Me.Btn_Find.Name = "Btn_Find"
        Me.Btn_Find.Size = New System.Drawing.Size(29, 20)
        Me.Btn_Find.TabIndex = 209
        Me.Btn_Find.TabStop = False
        Me.Btn_Find.Text = "F2"
        Me.Btn_Find.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Location = New System.Drawing.Point(665, 76)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(136, 294)
        Me.Panel1.TabIndex = 210
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.ErrorImage = CType(resources.GetObject("PictureBox1.ErrorImage"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(140, 294)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.White
        Me.Panel2.BackgroundImage = CType(resources.GetObject("Panel2.BackgroundImage"), System.Drawing.Image)
        Me.Panel2.Controls.Add(Me.PictureBox2)
        Me.Panel2.Location = New System.Drawing.Point(670, 392)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(131, 44)
        Me.Panel2.TabIndex = 211
        '
        'PictureBox2
        '
        Me.PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox2.Location = New System.Drawing.Point(-1, 7)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(132, 43)
        Me.PictureBox2.TabIndex = 0
        Me.PictureBox2.TabStop = False
        '
        'Btn_New
        '
        Me.Btn_New.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_New.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Add_3
        Me.Btn_New.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_New.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_New.Font = New System.Drawing.Font("Tahoma", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_New.ForeColor = System.Drawing.Color.White
        Me.Btn_New.Location = New System.Drawing.Point(627, 216)
        Me.Btn_New.Name = "Btn_New"
        Me.Btn_New.Size = New System.Drawing.Size(27, 21)
        Me.Btn_New.TabIndex = 127
        Me.Btn_New.TabStop = False
        Me.Btn_New.UseVisualStyleBackColor = False
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1000
        '
        'Patient_Info1
        '
        Me.Patient_Info1.BackColor = System.Drawing.Color.White
        Me.Patient_Info1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Patient_Info1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Patient_Info1.Location = New System.Drawing.Point(109, 75)
        Me.Patient_Info1.Name = "Patient_Info1"
        Me.Patient_Info1.Padding = New System.Windows.Forms.Padding(2)
        Me.Patient_Info1.Size = New System.Drawing.Size(514, 139)
        Me.Patient_Info1.TabIndex = 213
        '
        'Inpatient_Master_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.LeftGradiant
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(797, 500)
        Me.Controls.Add(Me.Patient_Info1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Btn_Find)
        Me.Controls.Add(Me.DTP_ServiceDay)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Cmb_Status)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Cmb_ArrivalMode)
        Me.Controls.Add(Me.Pnl_Tran_mode)
        Me.Controls.Add(Me.Btn_Find1)
        Me.Controls.Add(Me.Btn_NewOP)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Txt_AccID)
        Me.Controls.Add(Me.Txt_StayDays)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Cmb_DR_InCharge)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Txt_AmbulatoryStatus)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Txt_AdmitReason)
        Me.Controls.Add(Me.Cmb_Diagnose)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Cmb_AdmitType)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Cmb_Doctor)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Cmb_Dept)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Btn_New)
        Me.Controls.Add(Me.Cmb_Service)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Txt_PatientID)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Dtp_TranDate)
        Me.Controls.Add(Me.Txt_OP_ID)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Txt_IP_ID)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Inpatient_Master_Frm"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.Pnl_Tran_mode.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Txt_IP_ID As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Txt_OP_ID As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Dtp_TranDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Txt_PatientID As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Service As System.Windows.Forms.ComboBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Dept As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Doctor As System.Windows.Forms.ComboBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Cmb_AdmitType As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Diagnose As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Txt_AdmitReason As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Txt_AmbulatoryStatus As System.Windows.Forms.TextBox
    Friend WithEvents Cmb_DR_InCharge As System.Windows.Forms.ComboBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Txt_StayDays As System.Windows.Forms.TextBox
    Friend WithEvents Txt_AccID As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Delete As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Btn_NewOP As System.Windows.Forms.Button
    Friend WithEvents Btn_Find1 As System.Windows.Forms.Button
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Cmb_ArrivalMode As System.Windows.Forms.ComboBox
    Friend WithEvents Cmb_Status As System.Windows.Forms.ComboBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents DTP_ServiceDay As System.Windows.Forms.DateTimePicker
    Friend WithEvents Btn_Find As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Btn_New As System.Windows.Forms.Button
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Patient_Info1 As REAL_CLINIC.Patient_Info
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
End Class
