﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Grid_Searchhelper
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Grid_List = New System.Windows.Forms.DataGridView
        CType(Me.Grid_List, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Grid_List
        '

        Me.Grid_List.AllowUserToAddRows = False
        Me.Grid_List.AllowUserToDeleteRows = False
        Me.Grid_List.AllowUserToResizeColumns = False
        Me.Grid_List.AllowUserToResizeRows = False
        Me.Grid_List.BackgroundColor = System.Drawing.Color.White
        Me.Grid_List.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Grid_List.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Grid_List.ColumnHeadersVisible = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Grid_List.DefaultCellStyle = DataGridViewCellStyle1
        Me.Grid_List.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Grid_List.GridColor = System.Drawing.Color.FromArgb(CType(CType(227, Byte), Integer), CType(CType(233, Byte), Integer), CType(CType(218, Byte), Integer))
        Me.Grid_List.Location = New System.Drawing.Point(1, 1)
        Me.Grid_List.MultiSelect = False
        Me.Grid_List.Name = "Grid_List"
        Me.Grid_List.ReadOnly = True
        Me.Grid_List.RowHeadersVisible = False
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.White
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black
        Me.Grid_List.RowsDefaultCellStyle = DataGridViewCellStyle2
        Me.Grid_List.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black
        Me.Grid_List.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.Grid_List.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.Grid_List.Size = New System.Drawing.Size(382, 148)
        Me.Grid_List.TabIndex = 0
        '
        'Grid_Searchhelper
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.RoyalBlue
        Me.Controls.Add(Me.Grid_List)
        Me.Name = "Grid_Searchhelper"
        Me.Padding = New System.Windows.Forms.Padding(1)
        Me.Size = New System.Drawing.Size(384, 150)
        CType(Me.Grid_List, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Grid_List As System.Windows.Forms.DataGridView

End Class
