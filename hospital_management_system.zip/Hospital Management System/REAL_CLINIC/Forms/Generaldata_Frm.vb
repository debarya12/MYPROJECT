﻿

Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls
Public Class Generaldata_Frm

#Region " D e c l a r a t i o n s "
    'Object of Gendata Bussiness Layer
    Private Gendata_BL As HMS_Common_BL_Cls

    Private mTr_Mode As Tran_Mode

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing

#End Region

#Region " P r o p e r t i e s "

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_DataID.BackColor = Color.White
                    Me.Txt_DataID.ReadOnly = False
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_DataID.BackColor = Color.Silver
                    Me.Txt_DataID.ReadOnly = True
            End Select
        End Set
    End Property


#End Region

#Region " M e t h o d s "

    'Populating General Data category
    Private Sub Fill_Gendatacategory()
        Gendata_BL = New HMS_Common_BL_Cls
        Gendata_BL.Fill_Gendatacategory(DGvw_Gendatacategory)
        With DGvw_Gendatacategory
            If .Rows.Count > 0 Then
                If .Columns.Count > 0 Then
                    .Columns(0).MinimumWidth = 500
                    For i_Ctr = 1 To .Columns.Count - 1
                        .Columns(i_Ctr).Width = 0
                    Next

                End If
            End If
        End With
    End Sub

    Private Sub Fill_Gendata() Handles DGvw_Gendatacategory.Click, DGvw_Gendatacategory.KeyUp, DGvw_Gendatacategory.DoubleClick
        Try
            With DGvw_Gendatacategory

                '---------------------------------------------------------------------
                DGvw_Gendata.DataSource = Nothing
                Lst_Gendata.Items.Clear()
                Call Clear_Datadetails()
                '---------------------------------------------------------------------

                If .Rows.Count = 0 Then Exit Sub
                If .CurrentRow Is Nothing Then Exit Sub
                'If Lbl_Seldatacategory.Tag <> .Item(1, .CurrentCell.RowIndex).Value.ToString.Trim Then
                Lbl_Seldatacategory.Text = .Item(0, .CurrentCell.RowIndex).Value.ToString.Trim
                Lbl_Seldatacategory.Tag = .Item(1, .CurrentCell.RowIndex).Value.ToString.Trim
                Gendata_BL = New HMS_Common_BL_Cls
                Gendata_BL.Fill_Gendata(DGvw_Gendata, CInt(Val(Lbl_Seldatacategory.Tag)))
                Call Fill_GendataEditlist()
                'End If

                If Lst_Gendata.Items.Count > 0 Then
                    Btn_Movedown.Enabled = True
                    Btn_Moveup.Enabled = True
                    Btn_Removeitem.Enabled = True
                    Btn_Saveorder.Enabled = True
                Else
                    Btn_Movedown.Enabled = False
                    Btn_Moveup.Enabled = False
                    Btn_Removeitem.Enabled = False
                    Btn_Saveorder.Enabled = False
                End If

            End With

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Function Fill_GendataEditlist() As Boolean
        Try
            Dim Datadesc As String = ""
            Dim Datavalue As String = ""

            '------------------------------------------------------------------
            Cmb_Parentdata.Items.Clear()
            Call Addlist_Item_Value(Cmb_Parentdata, "Not Applicable", "0")
            '------------------------------------------------------------------

            With DGvw_Gendata
                Lst_Gendata.Items.Clear()
                For i_Ctr = 0 To .Rows.Count - 1
                    If Not .Item(2, i_Ctr).Value Is Nothing Then
                        Datadesc = .Item(2, i_Ctr).Value.ToString.Trim
                        Datavalue = .Item(0, i_Ctr).Value.ToString.Trim
                        If Datadesc.Trim <> "" Then
                            Call Addlist_Item_Value(Lst_Gendata, Datadesc, Datavalue)
                            Call Addlist_Item_Value(Cmb_Parentdata, Datadesc, Datavalue)
                        End If
                    End If
                Next
            End With
            If Cmb_Parentdata.Items.Count > 0 Then Cmb_Parentdata.SelectedIndex = 0
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Is_Itemlocked(ByVal Itemvalue As String) As Boolean
        Try
            With DGvw_Gendata
                For i_ctr = 0 To .Rows.Count - 1
                    If Itemvalue.ToString.Trim = .Item(0, i_ctr).Value.ToString.Trim Then
                        If .Item(5, i_ctr).Value.ToString.Trim = "Y" Then
                            Return True
                        Else
                            Return False
                        End If
                    End If
                Next
            End With
            Return False
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Save_Dataitems() As Boolean
        Try
            With DGvw_Gendata

                For i_Ctr = 0 To .Rows.Count - 1
                    Gendata_BL = New HMS_Common_BL_Cls
                    If Gendata_BL.Save_Gendata(Dtbl, Tr_Mode, .Item(0, i_Ctr).Value.ToString.Trim) Then


                    End If
                Next
            End With

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Save_Dataorder() As Boolean
        Try
            Dim Sel_Text As String = ""
            Dim Sel_Value As String = ""

            Gendata_BL = New HMS_Common_BL_Cls
            With Lst_Gendata
                For i_Ctr = 0 To .Items.Count - 1
                    .SelectedIndex = i_Ctr
                    If Not Selectlist_Item_Value(Lst_Gendata, Sel_Text, Sel_Value) Then Exit Function
                    Gendata_BL.Update_Gendataorder(Sel_Value, i_Ctr + 1)
                Next
            End With
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Sub Clear_Datadetails()
        Try
            Txt_DataID.Text = ""
            Txt_DataID.Tag = ""
            Txt_Datadescription.Text = ""
            Txt_Datadescription.Tag = ""
            Cmb_Parentdata.SelectedIndex = 0
            Cmb_Locked.SelectedIndex = 0
            Cmb_Status.SelectedIndex = 0

            Tr_Mode = Tran_Mode.New_Mode

        Catch ex As Exception

        End Try
    End Sub

    Private Function Validate_Fields() As Boolean
        Try
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If

            If Tr_Mode <> Tran_Mode.New_Mode Then
                If Txt_DataID.Text.Trim = "" Then MessageBox.Show("Invalid Data ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_DataID.Focus() : Exit Function
            End If
            If Txt_Datadescription.Text.Trim = "" Then MessageBox.Show("Invalid Data Description,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Datadescription.Focus() : Exit Function

            If Cmb_Parentdata.SelectedIndex < 0 Then MessageBox.Show("Please Select Parent Data", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_Parentdata.Focus() : Exit Function





            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Locate_Values(ByVal Data_ID As Integer) As Boolean
        Try
            Call Clear_Datadetails()
            With DGvw_Gendata
                For i_ctr = 0 To .Rows.Count - 1
                    If Data_ID.ToString = .Item(0, i_ctr).Value.ToString.Trim Then
                        Txt_DataID.Text = Data_ID
                        Txt_Datadescription.Text = .Item(2, i_ctr).Value.ToString.Trim
                        Txt_Datadescription.Tag = Txt_Datadescription.Text.Trim
                        Cmb_Status.SelectedIndex = 1
                        Cmb_Parentdata.SelectedValue = .Item(4, i_ctr).Value
                        Cmb_Parentdata.Refresh()
                        Cmb_Status.SelectedIndex = IIf(.Item(6, i_ctr).Value.ToString.Trim = "Y", 0, 1)
                        Cmb_Locked.SelectedIndex = IIf(.Item(5, i_ctr).Value.ToString.Trim = "Y", 0, 1)
                        Return True
                    End If
                Next
            End With
            Return False
        Catch ex As Exception
            Return False
        End Try
    End Function


#End Region

    Private Sub Close_Btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

    Private Sub Generaldata_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then Call SendKeyTab()
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Generaldata_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub Generaldata_Frm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            Call Fill_Gendatacategory()
            Call Fill_Gendata()
            With Cmb_Locked
                .Items.Add("Locked")
                .Items.Add("Unlocked")
                .SelectedIndex = 0
            End With
            With Cmb_Status
                .Items.Add("Active")
                .Items.Add("InActive")
                .SelectedIndex = 0
            End With
            DGvw_Gendatacategory.Focus()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Movedown_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Movedown.Click
        Try
            Call MoveListItem(Lst_Gendata, Move_Position.Movedown)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Moveup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Moveup.Click
        Try
            Call MoveListItem(Lst_Gendata, Move_Position.Moveup)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Removeitem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Removeitem.Click
        Try

            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If

            Dim item As Object = Lst_Gendata.SelectedItem
            If item Is Nothing Then Exit Sub

            Dim Sel_Text As String = ""
            Dim Sel_Value As String = ""

            If Not Selectlist_Item_Value(Lst_Gendata, Sel_Text, Sel_Value) Then Exit Sub

            If Is_Itemlocked(Sel_Value) Then
                MessageBox.Show("Selected Item is Locked,Can't Delete", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            'Confirm before delete the record
            If MessageBox.Show("Are you sure want to delete the selected Item", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = Windows.Forms.DialogResult.No Then
                Exit Sub
            End If

            Gendata_BL = New HMS_Common_BL_Cls
            If Gendata_BL.Del_Gendata(CInt(Sel_Value)) Then
                Lbl_Seldatacategory.Tag = ""
                If Save_Dataorder() Then
                    Call Fill_Gendata()
                End If
            Else
                MessageBox.Show("You cannot delete the selected Item" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Btn_Saveorder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Saveorder.Click
        Try
            'Confirm before delete the record
            If MessageBox.Show("Are you sure want to Save the selected Item Order", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = Windows.Forms.DialogResult.No Then
                Exit Sub
            End If

            If Save_Dataorder() Then
                Call Fill_Gendata()
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try
            Call Clear_Datadetails()
            Txt_DataID.Focus()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try

            'Validating Data
            If Not Validate_Fields() Then Exit Sub

            Gendata_BL = New HMS_Common_BL_Cls

            With Gendata_BL
                .Data_ID = Val(Txt_DataID.Text)
                .Data_CatID = Lbl_Seldatacategory.Tag
                .Data_Description = Txt_Datadescription.Text.Trim
                .Data_ParentID = Getlist_Item_Value(Cmb_Parentdata, Cmb_Parentdata.SelectedIndex)
                .Data_Locked = IIf(Cmb_Locked.SelectedIndex = 0, "Y", "N")
                .Data_Active = IIf(Cmb_Status.SelectedIndex = 0, "Y", "N")
                .Data_Order = Val(Txt_DataID.Tag)
                If .Save_Gendata(Dtbl, Tr_Mode, Val(Txt_DataID.Text.Trim)) Then
                    Call Clear_Datadetails()
                    Call Fill_Gendata()
                    Txt_DataID.Focus()
                End If
            End With

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Lst_Gendata_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Lst_Gendata.DoubleClick
        Try

            Dim Sel_Value As String = ""
            Dim Sel_Text As String = ""
            If Not Selectlist_Item_Value(Lst_Gendata, Sel_Text, Sel_Value) Then Exit Sub

            If Not Locate_Values(Sel_Value) Then
                Call Clear_Datadetails()
            Else
                Tr_Mode = Tran_Mode.Edit_Mode
                Txt_DataID.Focus()
            End If


        Catch ex As Exception

        End Try
    End Sub

    Private Sub Lst_Gendata_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Lst_Gendata.KeyDown
        If e.KeyCode = Keys.Enter Then
            Call Lst_Gendata_DoubleClick(sender, e)
        End If
    End Sub

    Private Sub Txt_DataID_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Txt_DataID.TextChanged
        If Txt_DataID.Text.Trim = "" Then
            Call Clear_Datadetails()
        End If
    End Sub

    Private Sub Txt_DataID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_DataID.Validating
        Try
            If Me.Txt_DataID.Text.Trim <> "" And Me.Txt_DataID.Text <> Me.Txt_DataID.Tag Then
                If Locate_Values(Val(Txt_DataID.Text.Trim)) Then
                    Tr_Mode = Tran_Mode.Edit_Mode
                Else
                    MessageBox.Show("Invalid Data ID ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Txt_DataID.Focus()
                    e.Cancel = True
                End If

            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_Datadescription_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_Datadescription.Validating
        Try
            If Txt_Datadescription.Text.Trim <> "" And Cmb_Parentdata.Items.Count > 0 Then
                If (Tr_Mode = Tran_Mode.New_Mode) Or (Txt_Datadescription.Tag <> Txt_Datadescription.Text.Trim) Then
                    If Isexistsinlist(Cmb_Parentdata, Txt_Datadescription.Text.Trim) Then
                        MessageBox.Show("Data Description Already Exists ,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Txt_Datadescription.Focus()
                        e.Cancel = True
                    End If
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

End Class