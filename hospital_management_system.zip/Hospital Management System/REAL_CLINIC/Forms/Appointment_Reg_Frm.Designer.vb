﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Appointment_Reg_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Appointment_Reg_Frm))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Lbl_Heading = New System.Windows.Forms.Label
        Me.Cmb_Visitortype = New System.Windows.Forms.ComboBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.Pnl_Othersdetails = New System.Windows.Forms.Panel
        Me.Txt_Visitor_Familyname = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Txt_Visitor_SSNO = New System.Windows.Forms.TextBox
        Me.Label35 = New System.Windows.Forms.Label
        Me.Cmb_Visitor_nationality = New System.Windows.Forms.ComboBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Txt_Visitor_Age = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Cmb_visitor_Gender = New System.Windows.Forms.ComboBox
        Me.Txt_Visitor_Mobile = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.Txt_Visitor_Phone = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Txt_Visitor_Addr = New System.Windows.Forms.TextBox
        Me.Txt_Visitor_Name = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Pnl_Patientdetails = New System.Windows.Forms.Panel
        Me.Patient_Info1 = New REAL_CLINIC.Patient_Info
        Me.Btn_PatientF2 = New System.Windows.Forms.Button
        Me.Txt_PatientID = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.Pnl_Empdetails = New System.Windows.Forms.Panel
        Me.Btn_EmpF2 = New System.Windows.Forms.Button
        Me.Txt_EmpID = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Employee_Info1 = New REAL_CLINIC.Employee_Info
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.Pnl_Booking = New System.Windows.Forms.Panel
        Me.Pnl_PMRID = New System.Windows.Forms.Panel
        Me.Btn_FindPMRID = New System.Windows.Forms.Button
        Me.Txt_PMRID = New System.Windows.Forms.TextBox
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Lbl_Doctordetails = New System.Windows.Forms.Label
        Me.Pnl_Doctors = New System.Windows.Forms.Panel
        Me.TlStrp_Doctors = New System.Windows.Forms.ToolStrip
        Me.Pnl_Time = New System.Windows.Forms.Panel
        Me.Lbl_Confirm = New System.Windows.Forms.Label
        Me.Lbl_Totime = New System.Windows.Forms.Label
        Me.Lbl_Fromtime = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Cmb_Timeto = New System.Windows.Forms.ComboBox
        Me.Cmb_Timefrom = New System.Windows.Forms.ComboBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Cmb_Visittype = New System.Windows.Forms.ComboBox
        Me.Lbl_Seldayname = New System.Windows.Forms.Label
        Me.Cmb_Bookmode = New System.Windows.Forms.ComboBox
        Me.Cmb_Service = New System.Windows.Forms.ComboBox
        Me.Label22 = New System.Windows.Forms.Label
        Me.Cmb_Bookingtype = New System.Windows.Forms.ComboBox
        Me.Label21 = New System.Windows.Forms.Label
        Me.Dtp_Apointdate = New System.Windows.Forms.DateTimePicker
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.Txt_ApointID = New System.Windows.Forms.TextBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.Btn_Find = New System.Windows.Forms.Button
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label
        Me.Pnl_Message = New System.Windows.Forms.Panel
        Me.Lbl_Bookingtype = New System.Windows.Forms.Label
        Me.Label30 = New System.Windows.Forms.Label
        Me.Lbl_Doctor = New System.Windows.Forms.Label
        Me.Label33 = New System.Windows.Forms.Label
        Me.Lbl_Visitype = New System.Windows.Forms.Label
        Me.Label31 = New System.Windows.Forms.Label
        Me.Label27 = New System.Windows.Forms.Label
        Me.Lbl_Service = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Lbl_ApStatus = New System.Windows.Forms.Label
        Me.Label29 = New System.Windows.Forms.Label
        Me.Lbl_Status = New System.Windows.Forms.Label
        Me.Lbl_MesageDate = New System.Windows.Forms.Label
        Me.Label28 = New System.Windows.Forms.Label
        Me.Lbl_Mesageaproxtime = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.Lbl_MesageTokenno = New System.Windows.Forms.Label
        Me.Label24 = New System.Windows.Forms.Label
        Me.Cmb_Status = New System.Windows.Forms.ComboBox
        Me.Label26 = New System.Windows.Forms.Label
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Dgrd_Appointment = New System.Windows.Forms.DataGridView
        Me.Time = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Token = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Pnl_Header.SuspendLayout()
        Me.Pnl_Othersdetails.SuspendLayout()
        Me.Pnl_Patientdetails.SuspendLayout()
        Me.Pnl_Empdetails.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.Pnl_Booking.SuspendLayout()
        Me.Pnl_PMRID.SuspendLayout()
        Me.Pnl_Doctors.SuspendLayout()
        Me.Pnl_Time.SuspendLayout()
        Me.Pnl_Tran_mode.SuspendLayout()
        Me.Pnl_Message.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.Dgrd_Appointment, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Pnl_Header.Controls.Add(Me.Lbl_Heading)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(687, 21)
        Me.Pnl_Header.TabIndex = 0
        '
        'Lbl_Heading
        '
        Me.Lbl_Heading.AutoSize = True
        Me.Lbl_Heading.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Heading.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Heading.ForeColor = System.Drawing.Color.White
        Me.Lbl_Heading.Location = New System.Drawing.Point(7, 1)
        Me.Lbl_Heading.Name = "Lbl_Heading"
        Me.Lbl_Heading.Size = New System.Drawing.Size(284, 16)
        Me.Lbl_Heading.TabIndex = 0
        Me.Lbl_Heading.Text = "A P P O I N T M E N T    R E G  I S T R A T I O N"
        '
        'Cmb_Visitortype
        '
        Me.Cmb_Visitortype.BackColor = System.Drawing.Color.White
        Me.Cmb_Visitortype.CausesValidation = False
        Me.Cmb_Visitortype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Visitortype.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_Visitortype.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Visitortype.FormattingEnabled = True
        Me.Cmb_Visitortype.ItemHeight = 13
        Me.Cmb_Visitortype.Location = New System.Drawing.Point(103, 4)
        Me.Cmb_Visitortype.Name = "Cmb_Visitortype"
        Me.Cmb_Visitortype.Size = New System.Drawing.Size(181, 21)
        Me.Cmb_Visitortype.TabIndex = 1
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.Navy
        Me.Label19.Location = New System.Drawing.Point(-1, 7)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(74, 14)
        Me.Label19.TabIndex = 104
        Me.Label19.Text = "Visitor Type"
        '
        'Pnl_Othersdetails
        '
        Me.Pnl_Othersdetails.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_Familyname)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label6)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_SSNO)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label35)
        Me.Pnl_Othersdetails.Controls.Add(Me.Cmb_Visitor_nationality)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label5)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_Age)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label15)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label13)
        Me.Pnl_Othersdetails.Controls.Add(Me.Cmb_visitor_Gender)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_Mobile)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label11)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_Phone)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label8)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label4)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_Addr)
        Me.Pnl_Othersdetails.Controls.Add(Me.Txt_Visitor_Name)
        Me.Pnl_Othersdetails.Controls.Add(Me.Label2)
        Me.Pnl_Othersdetails.Enabled = False
        Me.Pnl_Othersdetails.Location = New System.Drawing.Point(1, 30)
        Me.Pnl_Othersdetails.Name = "Pnl_Othersdetails"
        Me.Pnl_Othersdetails.Size = New System.Drawing.Size(463, 211)
        Me.Pnl_Othersdetails.TabIndex = 2
        '
        'Txt_Visitor_Familyname
        '
        Me.Txt_Visitor_Familyname.BackColor = System.Drawing.Color.White
        Me.Txt_Visitor_Familyname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Familyname.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Familyname.Location = New System.Drawing.Point(101, 112)
        Me.Txt_Visitor_Familyname.MaxLength = 250
        Me.Txt_Visitor_Familyname.Name = "Txt_Visitor_Familyname"
        Me.Txt_Visitor_Familyname.Size = New System.Drawing.Size(358, 21)
        Me.Txt_Visitor_Familyname.TabIndex = 4
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Navy
        Me.Label6.Location = New System.Drawing.Point(1, 114)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(76, 14)
        Me.Label6.TabIndex = 100044
        Me.Label6.Text = "Family Name"
        '
        'Txt_Visitor_SSNO
        '
        Me.Txt_Visitor_SSNO.BackColor = System.Drawing.Color.White
        Me.Txt_Visitor_SSNO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_SSNO.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_SSNO.Location = New System.Drawing.Point(101, 4)
        Me.Txt_Visitor_SSNO.MaxLength = 50
        Me.Txt_Visitor_SSNO.Name = "Txt_Visitor_SSNO"
        Me.Txt_Visitor_SSNO.Size = New System.Drawing.Size(183, 21)
        Me.Txt_Visitor_SSNO.TabIndex = 1
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.BackColor = System.Drawing.Color.Transparent
        Me.Label35.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.ForeColor = System.Drawing.Color.Navy
        Me.Label35.Location = New System.Drawing.Point(1, 6)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(67, 14)
        Me.Label35.TabIndex = 100042
        Me.Label35.Text = "Soc Sec No"
        '
        'Cmb_Visitor_nationality
        '
        Me.Cmb_Visitor_nationality.BackColor = System.Drawing.Color.White
        Me.Cmb_Visitor_nationality.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Visitor_nationality.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_Visitor_nationality.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Visitor_nationality.FormattingEnabled = True
        Me.Cmb_Visitor_nationality.Location = New System.Drawing.Point(102, 186)
        Me.Cmb_Visitor_nationality.Name = "Cmb_Visitor_nationality"
        Me.Cmb_Visitor_nationality.Size = New System.Drawing.Size(358, 21)
        Me.Cmb_Visitor_nationality.TabIndex = 9
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Navy
        Me.Label5.Location = New System.Drawing.Point(1, 190)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(63, 14)
        Me.Label5.TabIndex = 100041
        Me.Label5.Text = "Nationality"
        '
        'Txt_Visitor_Age
        '
        Me.Txt_Visitor_Age.BackColor = System.Drawing.Color.White
        Me.Txt_Visitor_Age.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Age.Cursor = System.Windows.Forms.Cursors.Default
        Me.Txt_Visitor_Age.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Age.Location = New System.Drawing.Point(304, 137)
        Me.Txt_Visitor_Age.MaxLength = 3
        Me.Txt_Visitor_Age.Name = "Txt_Visitor_Age"
        Me.Txt_Visitor_Age.Size = New System.Drawing.Size(64, 21)
        Me.Txt_Visitor_Age.TabIndex = 6
        Me.Txt_Visitor_Age.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.Navy
        Me.Label15.Location = New System.Drawing.Point(265, 140)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(29, 14)
        Me.Label15.TabIndex = 100040
        Me.Label15.Text = "Age"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.Navy
        Me.Label13.Location = New System.Drawing.Point(1, 141)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(48, 14)
        Me.Label13.TabIndex = 100039
        Me.Label13.Text = "Gender"
        '
        'Cmb_visitor_Gender
        '
        Me.Cmb_visitor_Gender.BackColor = System.Drawing.Color.White
        Me.Cmb_visitor_Gender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_visitor_Gender.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_visitor_Gender.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_visitor_Gender.FormattingEnabled = True
        Me.Cmb_visitor_Gender.ItemHeight = 13
        Me.Cmb_visitor_Gender.Location = New System.Drawing.Point(102, 136)
        Me.Cmb_visitor_Gender.Name = "Cmb_visitor_Gender"
        Me.Cmb_visitor_Gender.Size = New System.Drawing.Size(152, 21)
        Me.Cmb_visitor_Gender.TabIndex = 5
        '
        'Txt_Visitor_Mobile
        '
        Me.Txt_Visitor_Mobile.BackColor = System.Drawing.Color.White
        Me.Txt_Visitor_Mobile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Mobile.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Mobile.Location = New System.Drawing.Point(304, 161)
        Me.Txt_Visitor_Mobile.MaxLength = 10
        Me.Txt_Visitor_Mobile.Name = "Txt_Visitor_Mobile"
        Me.Txt_Visitor_Mobile.Size = New System.Drawing.Size(153, 21)
        Me.Txt_Visitor_Mobile.TabIndex = 8
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Navy
        Me.Label11.Location = New System.Drawing.Point(260, 164)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(44, 14)
        Me.Label11.TabIndex = 100038
        Me.Label11.Text = "Mobile"
        '
        'Txt_Visitor_Phone
        '
        Me.Txt_Visitor_Phone.BackColor = System.Drawing.Color.White
        Me.Txt_Visitor_Phone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Phone.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Phone.Location = New System.Drawing.Point(101, 161)
        Me.Txt_Visitor_Phone.MaxLength = 11
        Me.Txt_Visitor_Phone.Name = "Txt_Visitor_Phone"
        Me.Txt_Visitor_Phone.Size = New System.Drawing.Size(153, 21)
        Me.Txt_Visitor_Phone.TabIndex = 7
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Navy
        Me.Label8.Location = New System.Drawing.Point(1, 164)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(42, 14)
        Me.Label8.TabIndex = 100037
        Me.Label8.Text = "Phone"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Navy
        Me.Label4.Location = New System.Drawing.Point(1, 58)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(95, 14)
        Me.Label4.TabIndex = 100036
        Me.Label4.Text = "Visitor Address"
        '
        'Txt_Visitor_Addr
        '
        Me.Txt_Visitor_Addr.BackColor = System.Drawing.Color.White
        Me.Txt_Visitor_Addr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Addr.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Addr.Location = New System.Drawing.Point(101, 55)
        Me.Txt_Visitor_Addr.MaxLength = 500
        Me.Txt_Visitor_Addr.Multiline = True
        Me.Txt_Visitor_Addr.Name = "Txt_Visitor_Addr"
        Me.Txt_Visitor_Addr.Size = New System.Drawing.Size(358, 53)
        Me.Txt_Visitor_Addr.TabIndex = 3
        '
        'Txt_Visitor_Name
        '
        Me.Txt_Visitor_Name.BackColor = System.Drawing.Color.White
        Me.Txt_Visitor_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Visitor_Name.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.Txt_Visitor_Name.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Visitor_Name.Location = New System.Drawing.Point(101, 28)
        Me.Txt_Visitor_Name.MaxLength = 250
        Me.Txt_Visitor_Name.Name = "Txt_Visitor_Name"
        Me.Txt_Visitor_Name.Size = New System.Drawing.Size(358, 23)
        Me.Txt_Visitor_Name.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Navy
        Me.Label2.Location = New System.Drawing.Point(1, 31)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(78, 14)
        Me.Label2.TabIndex = 100035
        Me.Label2.Text = "Visitor Name"
        '
        'Pnl_Patientdetails
        '
        Me.Pnl_Patientdetails.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Patientdetails.CausesValidation = False
        Me.Pnl_Patientdetails.Controls.Add(Me.Patient_Info1)
        Me.Pnl_Patientdetails.Controls.Add(Me.Btn_PatientF2)
        Me.Pnl_Patientdetails.Controls.Add(Me.Txt_PatientID)
        Me.Pnl_Patientdetails.Controls.Add(Me.Label9)
        Me.Pnl_Patientdetails.Enabled = False
        Me.Pnl_Patientdetails.Location = New System.Drawing.Point(1, 29)
        Me.Pnl_Patientdetails.Name = "Pnl_Patientdetails"
        Me.Pnl_Patientdetails.Size = New System.Drawing.Size(463, 211)
        Me.Pnl_Patientdetails.TabIndex = 4
        '
        'Patient_Info1
        '
        Me.Patient_Info1.BackColor = System.Drawing.Color.AliceBlue
        Me.Patient_Info1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Patient_Info1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Patient_Info1.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Patient_Info1.Location = New System.Drawing.Point(10, 29)
        Me.Patient_Info1.Name = "Patient_Info1"
        Me.Patient_Info1.Padding = New System.Windows.Forms.Padding(2)
        Me.Patient_Info1.Size = New System.Drawing.Size(445, 177)
        Me.Patient_Info1.TabIndex = 3
        Me.Patient_Info1.TabStop = False
        '
        'Btn_PatientF2
        '
        Me.Btn_PatientF2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_PatientF2.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.F2_Button
        Me.Btn_PatientF2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Btn_PatientF2.CausesValidation = False
        Me.Btn_PatientF2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_PatientF2.ForeColor = System.Drawing.Color.White
        Me.Btn_PatientF2.Location = New System.Drawing.Point(256, 4)
        Me.Btn_PatientF2.Name = "Btn_PatientF2"
        Me.Btn_PatientF2.Size = New System.Drawing.Size(29, 21)
        Me.Btn_PatientF2.TabIndex = 2
        Me.Btn_PatientF2.TabStop = False
        Me.Btn_PatientF2.Text = "F2"
        Me.Btn_PatientF2.UseVisualStyleBackColor = False
        '
        'Txt_PatientID
        '
        Me.Txt_PatientID.BackColor = System.Drawing.Color.White
        Me.Txt_PatientID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_PatientID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PatientID.Location = New System.Drawing.Point(101, 4)
        Me.Txt_PatientID.MaxLength = 50
        Me.Txt_PatientID.Name = "Txt_PatientID"
        Me.Txt_PatientID.Size = New System.Drawing.Size(153, 21)
        Me.Txt_PatientID.TabIndex = 1
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label9.Location = New System.Drawing.Point(3, 6)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(64, 13)
        Me.Label9.TabIndex = 100042
        Me.Label9.Text = "Patient ID"
        '
        'Pnl_Empdetails
        '
        Me.Pnl_Empdetails.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Empdetails.Controls.Add(Me.Btn_EmpF2)
        Me.Pnl_Empdetails.Controls.Add(Me.Txt_EmpID)
        Me.Pnl_Empdetails.Controls.Add(Me.Label7)
        Me.Pnl_Empdetails.Controls.Add(Me.Employee_Info1)
        Me.Pnl_Empdetails.Enabled = False
        Me.Pnl_Empdetails.Location = New System.Drawing.Point(1, 29)
        Me.Pnl_Empdetails.Name = "Pnl_Empdetails"
        Me.Pnl_Empdetails.Size = New System.Drawing.Size(463, 211)
        Me.Pnl_Empdetails.TabIndex = 4
        '
        'Btn_EmpF2
        '
        Me.Btn_EmpF2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_EmpF2.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.F2_Button
        Me.Btn_EmpF2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Btn_EmpF2.CausesValidation = False
        Me.Btn_EmpF2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_EmpF2.ForeColor = System.Drawing.Color.White
        Me.Btn_EmpF2.Location = New System.Drawing.Point(256, 4)
        Me.Btn_EmpF2.Name = "Btn_EmpF2"
        Me.Btn_EmpF2.Size = New System.Drawing.Size(29, 21)
        Me.Btn_EmpF2.TabIndex = 2
        Me.Btn_EmpF2.TabStop = False
        Me.Btn_EmpF2.Text = "F2"
        Me.Btn_EmpF2.UseVisualStyleBackColor = False
        '
        'Txt_EmpID
        '
        Me.Txt_EmpID.BackColor = System.Drawing.Color.White
        Me.Txt_EmpID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_EmpID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_EmpID.Location = New System.Drawing.Point(101, 4)
        Me.Txt_EmpID.MaxLength = 50
        Me.Txt_EmpID.Name = "Txt_EmpID"
        Me.Txt_EmpID.Size = New System.Drawing.Size(153, 21)
        Me.Txt_EmpID.TabIndex = 1
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label7.Location = New System.Drawing.Point(2, 8)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(78, 13)
        Me.Label7.TabIndex = 100042
        Me.Label7.Text = "Employee ID"
        '
        'Employee_Info1
        '
        Me.Employee_Info1.BackColor = System.Drawing.Color.AliceBlue
        Me.Employee_Info1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Employee_Info1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Employee_Info1.Location = New System.Drawing.Point(10, 29)
        Me.Employee_Info1.Name = "Employee_Info1"
        Me.Employee_Info1.Padding = New System.Windows.Forms.Padding(2)
        Me.Employee_Info1.Size = New System.Drawing.Size(445, 177)
        Me.Employee_Info1.TabIndex = 3
        Me.Employee_Info1.TabStop = False
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(291, 521)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(174, 34)
        Me.Pnl_Common_Btn.TabIndex = 4
        '
        'Btn_Close
        '
        Me.Btn_Close.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Close.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Close.ForeColor = System.Drawing.Color.White
        Me.Btn_Close.Location = New System.Drawing.Point(114, 2)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 3
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = False
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(58, 2)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear.TabIndex = 2
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = CType(resources.GetObject("Btn_Save.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(2, 2)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save.TabIndex = 1
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Pnl_Booking
        '
        Me.Pnl_Booking.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Booking.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Booking.Controls.Add(Me.Pnl_PMRID)
        Me.Pnl_Booking.Controls.Add(Me.Label1)
        Me.Pnl_Booking.Controls.Add(Me.Lbl_Doctordetails)
        Me.Pnl_Booking.Controls.Add(Me.Pnl_Doctors)
        Me.Pnl_Booking.Controls.Add(Me.Pnl_Time)
        Me.Pnl_Booking.Controls.Add(Me.Cmb_Visittype)
        Me.Pnl_Booking.Controls.Add(Me.Lbl_Seldayname)
        Me.Pnl_Booking.Controls.Add(Me.Cmb_Bookmode)
        Me.Pnl_Booking.Controls.Add(Me.Cmb_Service)
        Me.Pnl_Booking.Controls.Add(Me.Label22)
        Me.Pnl_Booking.Controls.Add(Me.Cmb_Bookingtype)
        Me.Pnl_Booking.Controls.Add(Me.Label21)
        Me.Pnl_Booking.Controls.Add(Me.Dtp_Apointdate)
        Me.Pnl_Booking.Controls.Add(Me.Label14)
        Me.Pnl_Booking.Controls.Add(Me.Label23)
        Me.Pnl_Booking.Controls.Add(Me.Label20)
        Me.Pnl_Booking.Location = New System.Drawing.Point(1, 48)
        Me.Pnl_Booking.Name = "Pnl_Booking"
        Me.Pnl_Booking.Size = New System.Drawing.Size(468, 226)
        Me.Pnl_Booking.TabIndex = 1
        '
        'Pnl_PMRID
        '
        Me.Pnl_PMRID.Controls.Add(Me.Btn_FindPMRID)
        Me.Pnl_PMRID.Controls.Add(Me.Txt_PMRID)
        Me.Pnl_PMRID.Controls.Add(Me.Label16)
        Me.Pnl_PMRID.Location = New System.Drawing.Point(243, 1)
        Me.Pnl_PMRID.Name = "Pnl_PMRID"
        Me.Pnl_PMRID.Size = New System.Drawing.Size(223, 25)
        Me.Pnl_PMRID.TabIndex = 3
        '
        'Btn_FindPMRID
        '
        Me.Btn_FindPMRID.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_FindPMRID.BackgroundImage = CType(resources.GetObject("Btn_FindPMRID.BackgroundImage"), System.Drawing.Image)
        Me.Btn_FindPMRID.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_FindPMRID.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_FindPMRID.ForeColor = System.Drawing.Color.White
        Me.Btn_FindPMRID.Location = New System.Drawing.Point(193, 2)
        Me.Btn_FindPMRID.Name = "Btn_FindPMRID"
        Me.Btn_FindPMRID.Size = New System.Drawing.Size(27, 21)
        Me.Btn_FindPMRID.TabIndex = 2
        Me.Btn_FindPMRID.TabStop = False
        Me.Btn_FindPMRID.Text = "F2"
        Me.Btn_FindPMRID.UseVisualStyleBackColor = False
        '
        'Txt_PMRID
        '
        Me.Txt_PMRID.BackColor = System.Drawing.Color.White
        Me.Txt_PMRID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_PMRID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PMRID.Location = New System.Drawing.Point(49, 2)
        Me.Txt_PMRID.MaxLength = 50
        Me.Txt_PMRID.Name = "Txt_PMRID"
        Me.Txt_PMRID.Size = New System.Drawing.Size(143, 21)
        Me.Txt_PMRID.TabIndex = 1
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.Navy
        Me.Label16.Location = New System.Drawing.Point(4, 6)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(45, 14)
        Me.Label16.TabIndex = 2
        Me.Label16.Text = "PMR-ID"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Navy
        Me.Label1.Location = New System.Drawing.Point(3, 101)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(43, 14)
        Me.Label1.TabIndex = 100071
        Me.Label1.Text = "Doctor"
        '
        'Lbl_Doctordetails
        '
        Me.Lbl_Doctordetails.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(113, Byte), Integer), CType(CType(193, Byte), Integer))
        Me.Lbl_Doctordetails.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Lbl_Doctordetails.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Doctordetails.ForeColor = System.Drawing.Color.AliceBlue
        Me.Lbl_Doctordetails.Location = New System.Drawing.Point(101, 96)
        Me.Lbl_Doctordetails.Name = "Lbl_Doctordetails"
        Me.Lbl_Doctordetails.Size = New System.Drawing.Size(363, 34)
        Me.Lbl_Doctordetails.TabIndex = 100070
        Me.Lbl_Doctordetails.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Pnl_Doctors
        '
        Me.Pnl_Doctors.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Doctors.Controls.Add(Me.TlStrp_Doctors)
        Me.Pnl_Doctors.Location = New System.Drawing.Point(0, 51)
        Me.Pnl_Doctors.Margin = New System.Windows.Forms.Padding(0)
        Me.Pnl_Doctors.Name = "Pnl_Doctors"
        Me.Pnl_Doctors.Padding = New System.Windows.Forms.Padding(2, 2, 2, 0)
        Me.Pnl_Doctors.Size = New System.Drawing.Size(466, 45)
        Me.Pnl_Doctors.TabIndex = 4
        '
        'TlStrp_Doctors
        '
        Me.TlStrp_Doctors.BackColor = System.Drawing.Color.White
        Me.TlStrp_Doctors.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TlStrp_Doctors.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TlStrp_Doctors.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TlStrp_Doctors.Location = New System.Drawing.Point(2, 2)
        Me.TlStrp_Doctors.Name = "TlStrp_Doctors"
        Me.TlStrp_Doctors.Size = New System.Drawing.Size(462, 43)
        Me.TlStrp_Doctors.TabIndex = 3
        '
        'Pnl_Time
        '
        Me.Pnl_Time.Controls.Add(Me.Lbl_Confirm)
        Me.Pnl_Time.Controls.Add(Me.Lbl_Totime)
        Me.Pnl_Time.Controls.Add(Me.Lbl_Fromtime)
        Me.Pnl_Time.Controls.Add(Me.Label12)
        Me.Pnl_Time.Controls.Add(Me.Cmb_Timeto)
        Me.Pnl_Time.Controls.Add(Me.Cmb_Timefrom)
        Me.Pnl_Time.Controls.Add(Me.Label3)
        Me.Pnl_Time.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Pnl_Time.Location = New System.Drawing.Point(0, 189)
        Me.Pnl_Time.Name = "Pnl_Time"
        Me.Pnl_Time.Size = New System.Drawing.Size(466, 35)
        Me.Pnl_Time.TabIndex = 8
        '
        'Lbl_Confirm
        '
        Me.Lbl_Confirm.AutoSize = True
        Me.Lbl_Confirm.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Confirm.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Confirm.ForeColor = System.Drawing.Color.Maroon
        Me.Lbl_Confirm.Location = New System.Drawing.Point(384, 12)
        Me.Lbl_Confirm.Name = "Lbl_Confirm"
        Me.Lbl_Confirm.Size = New System.Drawing.Size(81, 14)
        Me.Lbl_Confirm.TabIndex = 100047
        Me.Lbl_Confirm.Text = "Not Confirm"
        '
        'Lbl_Totime
        '
        Me.Lbl_Totime.BackColor = System.Drawing.Color.White
        Me.Lbl_Totime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Lbl_Totime.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Totime.ForeColor = System.Drawing.Color.Navy
        Me.Lbl_Totime.Location = New System.Drawing.Point(255, 7)
        Me.Lbl_Totime.Name = "Lbl_Totime"
        Me.Lbl_Totime.Size = New System.Drawing.Size(128, 23)
        Me.Lbl_Totime.TabIndex = 100044
        Me.Lbl_Totime.Text = "ApproxTime from"
        Me.Lbl_Totime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Lbl_Totime.Visible = False
        '
        'Lbl_Fromtime
        '
        Me.Lbl_Fromtime.BackColor = System.Drawing.Color.White
        Me.Lbl_Fromtime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Lbl_Fromtime.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Fromtime.ForeColor = System.Drawing.Color.Navy
        Me.Lbl_Fromtime.Location = New System.Drawing.Point(101, 7)
        Me.Lbl_Fromtime.Name = "Lbl_Fromtime"
        Me.Lbl_Fromtime.Size = New System.Drawing.Size(128, 23)
        Me.Lbl_Fromtime.TabIndex = 100043
        Me.Lbl_Fromtime.Text = "ApproxTime from"
        Me.Lbl_Fromtime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Lbl_Fromtime.Visible = False
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.Navy
        Me.Label12.Location = New System.Drawing.Point(230, 12)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(21, 14)
        Me.Label12.TabIndex = 100041
        Me.Label12.Text = "To"
        '
        'Cmb_Timeto
        '
        Me.Cmb_Timeto.BackColor = System.Drawing.Color.White
        Me.Cmb_Timeto.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_Timeto.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Timeto.FormattingEnabled = True
        Me.Cmb_Timeto.ItemHeight = 13
        Me.Cmb_Timeto.Location = New System.Drawing.Point(255, 8)
        Me.Cmb_Timeto.Name = "Cmb_Timeto"
        Me.Cmb_Timeto.Size = New System.Drawing.Size(128, 21)
        Me.Cmb_Timeto.TabIndex = 2
        '
        'Cmb_Timefrom
        '
        Me.Cmb_Timefrom.BackColor = System.Drawing.Color.White
        Me.Cmb_Timefrom.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_Timefrom.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Timefrom.FormattingEnabled = True
        Me.Cmb_Timefrom.ItemHeight = 13
        Me.Cmb_Timefrom.Location = New System.Drawing.Point(101, 8)
        Me.Cmb_Timefrom.Name = "Cmb_Timefrom"
        Me.Cmb_Timefrom.Size = New System.Drawing.Size(128, 21)
        Me.Cmb_Timefrom.TabIndex = 1
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Navy
        Me.Label3.Location = New System.Drawing.Point(0, 12)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(105, 14)
        Me.Label3.TabIndex = 100042
        Me.Label3.Text = "ApproxTime from"
        '
        'Cmb_Visittype
        '
        Me.Cmb_Visittype.BackColor = System.Drawing.Color.White
        Me.Cmb_Visittype.CausesValidation = False
        Me.Cmb_Visittype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Visittype.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_Visittype.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Visittype.FormattingEnabled = True
        Me.Cmb_Visittype.ItemHeight = 13
        Me.Cmb_Visittype.Location = New System.Drawing.Point(101, 3)
        Me.Cmb_Visittype.Name = "Cmb_Visittype"
        Me.Cmb_Visittype.Size = New System.Drawing.Size(141, 21)
        Me.Cmb_Visittype.TabIndex = 2
        '
        'Lbl_Seldayname
        '
        Me.Lbl_Seldayname.AutoSize = True
        Me.Lbl_Seldayname.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Seldayname.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Seldayname.ForeColor = System.Drawing.Color.Maroon
        Me.Lbl_Seldayname.Location = New System.Drawing.Point(229, 170)
        Me.Lbl_Seldayname.Name = "Lbl_Seldayname"
        Me.Lbl_Seldayname.Size = New System.Drawing.Size(30, 14)
        Me.Lbl_Seldayname.TabIndex = 100046
        Me.Lbl_Seldayname.Text = "Day"
        '
        'Cmb_Bookmode
        '
        Me.Cmb_Bookmode.BackColor = System.Drawing.Color.White
        Me.Cmb_Bookmode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Bookmode.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_Bookmode.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Bookmode.FormattingEnabled = True
        Me.Cmb_Bookmode.ItemHeight = 13
        Me.Cmb_Bookmode.Location = New System.Drawing.Point(349, 141)
        Me.Cmb_Bookmode.Name = "Cmb_Bookmode"
        Me.Cmb_Bookmode.Size = New System.Drawing.Size(114, 21)
        Me.Cmb_Bookmode.TabIndex = 6
        '
        'Cmb_Service
        '
        Me.Cmb_Service.BackColor = System.Drawing.Color.White
        Me.Cmb_Service.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Service.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_Service.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Service.FormattingEnabled = True
        Me.Cmb_Service.ItemHeight = 13
        Me.Cmb_Service.Location = New System.Drawing.Point(101, 28)
        Me.Cmb_Service.Name = "Cmb_Service"
        Me.Cmb_Service.Size = New System.Drawing.Size(183, 21)
        Me.Cmb_Service.TabIndex = 3
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.BackColor = System.Drawing.Color.Transparent
        Me.Label22.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.Navy
        Me.Label22.Location = New System.Drawing.Point(1, 32)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(48, 14)
        Me.Label22.TabIndex = 100043
        Me.Label22.Text = "Service"
        '
        'Cmb_Bookingtype
        '
        Me.Cmb_Bookingtype.BackColor = System.Drawing.Color.White
        Me.Cmb_Bookingtype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Bookingtype.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Cmb_Bookingtype.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Bookingtype.FormattingEnabled = True
        Me.Cmb_Bookingtype.ItemHeight = 13
        Me.Cmb_Bookingtype.Location = New System.Drawing.Point(101, 141)
        Me.Cmb_Bookingtype.Name = "Cmb_Bookingtype"
        Me.Cmb_Bookingtype.Size = New System.Drawing.Size(128, 21)
        Me.Cmb_Bookingtype.TabIndex = 5
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.Color.Transparent
        Me.Label21.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.Navy
        Me.Label21.Location = New System.Drawing.Point(1, 146)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(82, 14)
        Me.Label21.TabIndex = 100041
        Me.Label21.Text = "Booking Type"
        '
        'Dtp_Apointdate
        '
        Me.Dtp_Apointdate.CalendarMonthBackground = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.Dtp_Apointdate.CalendarTitleForeColor = System.Drawing.Color.FromArgb(CType(CType(185, Byte), Integer), CType(CType(205, Byte), Integer), CType(CType(223, Byte), Integer))
        Me.Dtp_Apointdate.CustomFormat = " dd/MM/yyyy"
        Me.Dtp_Apointdate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dtp_Apointdate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_Apointdate.Location = New System.Drawing.Point(101, 167)
        Me.Dtp_Apointdate.Name = "Dtp_Apointdate"
        Me.Dtp_Apointdate.Size = New System.Drawing.Size(128, 20)
        Me.Dtp_Apointdate.TabIndex = 7
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.Navy
        Me.Label14.Location = New System.Drawing.Point(1, 169)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(31, 14)
        Me.Label14.TabIndex = 100039
        Me.Label14.Text = "Date"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.BackColor = System.Drawing.Color.Transparent
        Me.Label23.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.Navy
        Me.Label23.Location = New System.Drawing.Point(253, 144)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(86, 14)
        Me.Label23.TabIndex = 100045
        Me.Label23.Text = "Booking Mode"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.Color.Transparent
        Me.Label20.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.Navy
        Me.Label20.Location = New System.Drawing.Point(2, 6)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(62, 14)
        Me.Label20.TabIndex = 100048
        Me.Label20.Text = "Visit Type"
        '
        'Txt_ApointID
        '
        Me.Txt_ApointID.BackColor = System.Drawing.Color.White
        Me.Txt_ApointID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_ApointID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_ApointID.Location = New System.Drawing.Point(102, 25)
        Me.Txt_ApointID.MaxLength = 50
        Me.Txt_ApointID.Name = "Txt_ApointID"
        Me.Txt_ApointID.Size = New System.Drawing.Size(154, 21)
        Me.Txt_ApointID.TabIndex = 0
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.Navy
        Me.Label17.Location = New System.Drawing.Point(1, 27)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(92, 14)
        Me.Label17.TabIndex = 0
        Me.Label17.Text = "Appointment ID"
        '
        'Btn_Find
        '
        Me.Btn_Find.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find.BackgroundImage = CType(resources.GetObject("Btn_Find.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find.ForeColor = System.Drawing.Color.White
        Me.Btn_Find.Location = New System.Drawing.Point(257, 25)
        Me.Btn_Find.Name = "Btn_Find"
        Me.Btn_Find.Size = New System.Drawing.Size(27, 21)
        Me.Btn_Find.TabIndex = 1
        Me.Btn_Find.TabStop = False
        Me.Btn_Find.Text = "F2"
        Me.Btn_Find.UseVisualStyleBackColor = False
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(393, 24)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(74, 22)
        Me.Pnl_Tran_mode.TabIndex = 100034
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(2, 1)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(68, 16)
        Me.Lbl_Tran_Mode.TabIndex = 0
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Pnl_Message
        '
        Me.Pnl_Message.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(113, Byte), Integer), CType(CType(193, Byte), Integer))
        Me.Pnl_Message.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Message.Controls.Add(Me.Lbl_Bookingtype)
        Me.Pnl_Message.Controls.Add(Me.Label30)
        Me.Pnl_Message.Controls.Add(Me.Lbl_Doctor)
        Me.Pnl_Message.Controls.Add(Me.Label33)
        Me.Pnl_Message.Controls.Add(Me.Lbl_Visitype)
        Me.Pnl_Message.Controls.Add(Me.Label31)
        Me.Pnl_Message.Controls.Add(Me.Label27)
        Me.Pnl_Message.Controls.Add(Me.Lbl_Service)
        Me.Pnl_Message.Controls.Add(Me.Label10)
        Me.Pnl_Message.Controls.Add(Me.Lbl_ApStatus)
        Me.Pnl_Message.Controls.Add(Me.Label29)
        Me.Pnl_Message.Controls.Add(Me.Lbl_Status)
        Me.Pnl_Message.Controls.Add(Me.Lbl_MesageDate)
        Me.Pnl_Message.Controls.Add(Me.Label28)
        Me.Pnl_Message.Controls.Add(Me.Lbl_Mesageaproxtime)
        Me.Pnl_Message.Controls.Add(Me.Label25)
        Me.Pnl_Message.Controls.Add(Me.Lbl_MesageTokenno)
        Me.Pnl_Message.Controls.Add(Me.Label24)
        Me.Pnl_Message.Location = New System.Drawing.Point(0, 48)
        Me.Pnl_Message.Name = "Pnl_Message"
        Me.Pnl_Message.Size = New System.Drawing.Size(469, 226)
        Me.Pnl_Message.TabIndex = 100037
        Me.Pnl_Message.Visible = False
        '
        'Lbl_Bookingtype
        '
        Me.Lbl_Bookingtype.AutoSize = True
        Me.Lbl_Bookingtype.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Bookingtype.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Bookingtype.ForeColor = System.Drawing.Color.AliceBlue
        Me.Lbl_Bookingtype.Location = New System.Drawing.Point(305, 115)
        Me.Lbl_Bookingtype.Name = "Lbl_Bookingtype"
        Me.Lbl_Bookingtype.Size = New System.Drawing.Size(14, 13)
        Me.Lbl_Bookingtype.TabIndex = 100061
        Me.Lbl_Bookingtype.Text = "*"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.BackColor = System.Drawing.Color.Transparent
        Me.Label30.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label30.Location = New System.Drawing.Point(216, 115)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(89, 13)
        Me.Label30.TabIndex = 100060
        Me.Label30.Text = "Booking Type :"
        '
        'Lbl_Doctor
        '
        Me.Lbl_Doctor.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Doctor.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Doctor.ForeColor = System.Drawing.Color.AliceBlue
        Me.Lbl_Doctor.Location = New System.Drawing.Point(285, 85)
        Me.Lbl_Doctor.Name = "Lbl_Doctor"
        Me.Lbl_Doctor.Size = New System.Drawing.Size(178, 26)
        Me.Lbl_Doctor.TabIndex = 100059
        Me.Lbl_Doctor.Text = "*"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.BackColor = System.Drawing.Color.Transparent
        Me.Label33.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label33.Location = New System.Drawing.Point(216, 84)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(69, 13)
        Me.Label33.TabIndex = 100058
        Me.Label33.Text = "Doctor       :"
        '
        'Lbl_Visitype
        '
        Me.Lbl_Visitype.AutoSize = True
        Me.Lbl_Visitype.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Visitype.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Visitype.ForeColor = System.Drawing.Color.AliceBlue
        Me.Lbl_Visitype.Location = New System.Drawing.Point(285, 55)
        Me.Lbl_Visitype.Name = "Lbl_Visitype"
        Me.Lbl_Visitype.Size = New System.Drawing.Size(14, 13)
        Me.Lbl_Visitype.TabIndex = 100057
        Me.Lbl_Visitype.Text = "*"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.BackColor = System.Drawing.Color.Transparent
        Me.Label31.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label31.Location = New System.Drawing.Point(216, 54)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(68, 13)
        Me.Label31.TabIndex = 100056
        Me.Label31.Text = "Visit Type :"
        '
        'Label27
        '
        Me.Label27.BackColor = System.Drawing.Color.PowderBlue
        Me.Label27.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label27.Location = New System.Drawing.Point(214, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(1, 224)
        Me.Label27.TabIndex = 100055
        '
        'Lbl_Service
        '
        Me.Lbl_Service.AutoSize = True
        Me.Lbl_Service.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Service.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Service.ForeColor = System.Drawing.Color.AliceBlue
        Me.Lbl_Service.Location = New System.Drawing.Point(285, 24)
        Me.Lbl_Service.Name = "Lbl_Service"
        Me.Lbl_Service.Size = New System.Drawing.Size(14, 13)
        Me.Lbl_Service.TabIndex = 100054
        Me.Lbl_Service.Text = "*"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label10.Location = New System.Drawing.Point(216, 23)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(67, 13)
        Me.Label10.TabIndex = 100053
        Me.Label10.Text = "Service     :"
        '
        'Lbl_ApStatus
        '
        Me.Lbl_ApStatus.AutoSize = True
        Me.Lbl_ApStatus.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_ApStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_ApStatus.ForeColor = System.Drawing.Color.GhostWhite
        Me.Lbl_ApStatus.Location = New System.Drawing.Point(91, 184)
        Me.Lbl_ApStatus.Name = "Lbl_ApStatus"
        Me.Lbl_ApStatus.Size = New System.Drawing.Size(18, 24)
        Me.Lbl_ApStatus.TabIndex = 100051
        Me.Lbl_ApStatus.Text = "*"
        Me.Lbl_ApStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.BackColor = System.Drawing.Color.Transparent
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label29.Location = New System.Drawing.Point(30, 184)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(55, 15)
        Me.Label29.TabIndex = 100050
        Me.Label29.Text = "Status :"
        '
        'Lbl_Status
        '
        Me.Lbl_Status.AutoSize = True
        Me.Lbl_Status.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Status.Font = New System.Drawing.Font("Tahoma", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Status.ForeColor = System.Drawing.Color.SandyBrown
        Me.Lbl_Status.Location = New System.Drawing.Point(247, 157)
        Me.Lbl_Status.Name = "Lbl_Status"
        Me.Lbl_Status.Size = New System.Drawing.Size(187, 35)
        Me.Lbl_Status.TabIndex = 100049
        Me.Lbl_Status.Text = "CANCELLED"
        Me.Lbl_Status.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Lbl_MesageDate
        '
        Me.Lbl_MesageDate.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_MesageDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_MesageDate.ForeColor = System.Drawing.Color.GhostWhite
        Me.Lbl_MesageDate.Location = New System.Drawing.Point(88, 80)
        Me.Lbl_MesageDate.Name = "Lbl_MesageDate"
        Me.Lbl_MesageDate.Size = New System.Drawing.Size(119, 28)
        Me.Lbl_MesageDate.TabIndex = 100048
        Me.Lbl_MesageDate.Text = "01:01:01"
        Me.Lbl_MesageDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.BackColor = System.Drawing.Color.Transparent
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label28.Location = New System.Drawing.Point(40, 86)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(45, 15)
        Me.Label28.TabIndex = 100047
        Me.Label28.Text = "Date :"
        '
        'Lbl_Mesageaproxtime
        '
        Me.Lbl_Mesageaproxtime.AutoSize = True
        Me.Lbl_Mesageaproxtime.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Mesageaproxtime.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Mesageaproxtime.ForeColor = System.Drawing.Color.GhostWhite
        Me.Lbl_Mesageaproxtime.Location = New System.Drawing.Point(86, 133)
        Me.Lbl_Mesageaproxtime.Name = "Lbl_Mesageaproxtime"
        Me.Lbl_Mesageaproxtime.Size = New System.Drawing.Size(120, 29)
        Me.Lbl_Mesageaproxtime.TabIndex = 100046
        Me.Lbl_Mesageaproxtime.Text = "12:00 AM"
        Me.Lbl_Mesageaproxtime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.BackColor = System.Drawing.Color.Transparent
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label25.Location = New System.Drawing.Point(2, 138)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(83, 15)
        Me.Label25.TabIndex = 100045
        Me.Label25.Text = "AproxTime :"
        '
        'Lbl_MesageTokenno
        '
        Me.Lbl_MesageTokenno.AutoSize = True
        Me.Lbl_MesageTokenno.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_MesageTokenno.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_MesageTokenno.ForeColor = System.Drawing.Color.GhostWhite
        Me.Lbl_MesageTokenno.Location = New System.Drawing.Point(89, 14)
        Me.Lbl_MesageTokenno.Name = "Lbl_MesageTokenno"
        Me.Lbl_MesageTokenno.Size = New System.Drawing.Size(108, 55)
        Me.Lbl_MesageTokenno.TabIndex = 100044
        Me.Lbl_MesageTokenno.Text = "123"
        Me.Lbl_MesageTokenno.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.BackColor = System.Drawing.Color.Transparent
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label24.Location = New System.Drawing.Point(9, 36)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(76, 15)
        Me.Label24.TabIndex = 100043
        Me.Label24.Text = "Token No :"
        '
        'Cmb_Status
        '
        Me.Cmb_Status.BackColor = System.Drawing.Color.White
        Me.Cmb_Status.CausesValidation = False
        Me.Cmb_Status.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_Status.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_Status.FormattingEnabled = True
        Me.Cmb_Status.ItemHeight = 13
        Me.Cmb_Status.Location = New System.Drawing.Point(105, 523)
        Me.Cmb_Status.Name = "Cmb_Status"
        Me.Cmb_Status.Size = New System.Drawing.Size(153, 21)
        Me.Cmb_Status.TabIndex = 3
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.BackColor = System.Drawing.Color.Transparent
        Me.Label26.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.ForeColor = System.Drawing.Color.Navy
        Me.Label26.Location = New System.Drawing.Point(4, 528)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(44, 15)
        Me.Label26.TabIndex = 100050
        Me.Label26.Text = "Status"
        '
        'Timer1
        '
        Me.Timer1.Interval = 30000
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Cmb_Visitortype)
        Me.Panel1.Controls.Add(Me.Label19)
        Me.Panel1.Controls.Add(Me.Pnl_Othersdetails)
        Me.Panel1.Controls.Add(Me.Pnl_Empdetails)
        Me.Panel1.Controls.Add(Me.Pnl_Patientdetails)
        Me.Panel1.Location = New System.Drawing.Point(1, 275)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(468, 241)
        Me.Panel1.TabIndex = 2
        '
        'Dgrd_Appointment
        '
        Me.Dgrd_Appointment.AllowUserToAddRows = False
        Me.Dgrd_Appointment.AllowUserToDeleteRows = False
        Me.Dgrd_Appointment.AllowUserToResizeColumns = False
        Me.Dgrd_Appointment.AllowUserToResizeRows = False
        Me.Dgrd_Appointment.BackgroundColor = System.Drawing.Color.LightSteelBlue
        Me.Dgrd_Appointment.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(75, Byte), Integer), CType(CType(103, Byte), Integer), CType(CType(131, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgrd_Appointment.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.Dgrd_Appointment.ColumnHeadersHeight = 20
        Me.Dgrd_Appointment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.Dgrd_Appointment.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Time, Me.Token})
        Me.Dgrd_Appointment.Dock = System.Windows.Forms.DockStyle.Right
        Me.Dgrd_Appointment.Location = New System.Drawing.Point(470, 21)
        Me.Dgrd_Appointment.MultiSelect = False
        Me.Dgrd_Appointment.Name = "Dgrd_Appointment"
        Me.Dgrd_Appointment.ReadOnly = True
        Me.Dgrd_Appointment.RowHeadersVisible = False
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgrd_Appointment.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.Dgrd_Appointment.RowTemplate.Height = 30
        Me.Dgrd_Appointment.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.Dgrd_Appointment.Size = New System.Drawing.Size(217, 539)
        Me.Dgrd_Appointment.TabIndex = 0
        Me.Dgrd_Appointment.TabStop = False
        '
        'Time
        '
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(75, Byte), Integer), CType(CType(103, Byte), Integer), CType(CType(131, Byte), Integer))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        Me.Time.DefaultCellStyle = DataGridViewCellStyle2
        Me.Time.Frozen = True
        Me.Time.HeaderText = "Time"
        Me.Time.MinimumWidth = 70
        Me.Time.Name = "Time"
        Me.Time.ReadOnly = True
        Me.Time.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Time.Width = 70
        '
        'Token
        '
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(162, Byte), Integer), CType(CType(187, Byte), Integer))
        Me.Token.DefaultCellStyle = DataGridViewCellStyle3
        Me.Token.HeaderText = "Token"
        Me.Token.Name = "Token"
        Me.Token.ReadOnly = True
        Me.Token.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Token.Width = 125
        '
        'Appointment_Reg_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSteelBlue
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(687, 560)
        Me.ControlBox = False
        Me.Controls.Add(Me.Dgrd_Appointment)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Cmb_Status)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Pnl_Tran_mode)
        Me.Controls.Add(Me.Btn_Find)
        Me.Controls.Add(Me.Txt_ApointID)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Controls.Add(Me.Pnl_Booking)
        Me.Controls.Add(Me.Pnl_Message)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.Name = "Appointment_Reg_Frm"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Pnl_Othersdetails.ResumeLayout(False)
        Me.Pnl_Othersdetails.PerformLayout()
        Me.Pnl_Patientdetails.ResumeLayout(False)
        Me.Pnl_Patientdetails.PerformLayout()
        Me.Pnl_Empdetails.ResumeLayout(False)
        Me.Pnl_Empdetails.PerformLayout()
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.Pnl_Booking.ResumeLayout(False)
        Me.Pnl_Booking.PerformLayout()
        Me.Pnl_PMRID.ResumeLayout(False)
        Me.Pnl_PMRID.PerformLayout()
        Me.Pnl_Doctors.ResumeLayout(False)
        Me.Pnl_Doctors.PerformLayout()
        Me.Pnl_Time.ResumeLayout(False)
        Me.Pnl_Time.PerformLayout()
        Me.Pnl_Tran_mode.ResumeLayout(False)
        Me.Pnl_Message.ResumeLayout(False)
        Me.Pnl_Message.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.Dgrd_Appointment, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Heading As System.Windows.Forms.Label
    Friend WithEvents Cmb_Visitortype As System.Windows.Forms.ComboBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Othersdetails As System.Windows.Forms.Panel
    Friend WithEvents Txt_Visitor_Familyname As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_SSNO As System.Windows.Forms.TextBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Visitor_nationality As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_Age As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Cmb_visitor_Gender As System.Windows.Forms.ComboBox
    Friend WithEvents Txt_Visitor_Mobile As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_Phone As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Txt_Visitor_Addr As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Visitor_Name As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Patientdetails As System.Windows.Forms.Panel
    Friend WithEvents Patient_Info1 As REAL_CLINIC.Patient_Info
    Friend WithEvents Btn_PatientF2 As System.Windows.Forms.Button
    Friend WithEvents Txt_PatientID As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Empdetails As System.Windows.Forms.Panel
    Friend WithEvents Employee_Info1 As REAL_CLINIC.Employee_Info
    Friend WithEvents Btn_EmpF2 As System.Windows.Forms.Button
    Friend WithEvents Txt_EmpID As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Pnl_Booking As System.Windows.Forms.Panel
    Friend WithEvents Cmb_Service As System.Windows.Forms.ComboBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Bookingtype As System.Windows.Forms.ComboBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Dtp_Apointdate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Bookmode As System.Windows.Forms.ComboBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Seldayname As System.Windows.Forms.Label
    Friend WithEvents Txt_ApointID As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Btn_Find As System.Windows.Forms.Button
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Pnl_Message As System.Windows.Forms.Panel
    Friend WithEvents Lbl_MesageTokenno As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Lbl_MesageDate As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Mesageaproxtime As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Visittype As System.Windows.Forms.ComboBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Status As System.Windows.Forms.ComboBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Time As System.Windows.Forms.Panel
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Cmb_Timeto As System.Windows.Forms.ComboBox
    Friend WithEvents Cmb_Timefrom As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Status As System.Windows.Forms.Label
    Friend WithEvents Lbl_Fromtime As System.Windows.Forms.Label
    Friend WithEvents Lbl_Totime As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Lbl_Confirm As System.Windows.Forms.Label
    Friend WithEvents Lbl_ApStatus As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Dgrd_Appointment As System.Windows.Forms.DataGridView
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Service As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Visitype As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Doctor As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Bookingtype As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Doctors As System.Windows.Forms.Panel
    Friend WithEvents TlStrp_Doctors As System.Windows.Forms.ToolStrip
    Friend WithEvents Time As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Token As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Lbl_Doctordetails As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Pnl_PMRID As System.Windows.Forms.Panel
    Friend WithEvents Btn_FindPMRID As System.Windows.Forms.Button
    Friend WithEvents Txt_PMRID As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
End Class
