﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Patient_Discharge_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Patient_Discharge_Frm))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Label3 = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Txt_Patient_ID = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Dtp_TranDate = New System.Windows.Forms.DateTimePicker
        Me.Btn_Discharge_Find = New System.Windows.Forms.Button
        Me.Txt_Discharge_ID = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Btn_PMRFind = New System.Windows.Forms.Button
        Me.Txt_PMRID = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Pnl_Bill_Dt = New System.Windows.Forms.Panel
        Me.Grid_Bill_Dt = New System.Windows.Forms.DataGridView
        Me.Label6 = New System.Windows.Forms.Label
        Me.Dgrd_Patient_Bills = New System.Windows.Forms.DataGridView
        Me.Bill_No = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Tr_Date = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Tran_Amount = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.Dgrd_Patient_Payments = New System.Windows.Forms.DataGridView
        Me.V_No = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Paid_Date = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Pay_Type = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Paid_Amount = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Label7 = New System.Windows.Forms.Label
        Me.Panel4 = New System.Windows.Forms.Panel
        Me.Lbl_Paid_Amt = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Lbl_Bill_Amt = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Cancel = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.Panel5 = New System.Windows.Forms.Panel
        Me.Lbl_BalText = New System.Windows.Forms.Label
        Me.Lbl_Balance = New System.Windows.Forms.Label
        Me.Panel6 = New System.Windows.Forms.Panel
        Me.Btn_Discharge_Sum = New System.Windows.Forms.Button
        Me.Patient_Info1 = New TECHNO_CLINIC.Patient_Info
        Me.Pnl_Header.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Pnl_Tran_mode.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Pnl_Bill_Dt.SuspendLayout()
        CType(Me.Grid_Bill_Dt, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Dgrd_Patient_Bills, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.Dgrd_Patient_Payments, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = CType(resources.GetObject("Pnl_Header.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Header.Controls.Add(Me.Label3)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(786, 24)
        Me.Pnl_Header.TabIndex = 102
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(8, 1)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(205, 18)
        Me.Label3.TabIndex = 121
        Me.Label3.Text = "P a t i e n t    D i s c h a r g e"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(126, Byte), Integer))
        Me.Panel1.Controls.Add(Me.Txt_Patient_ID)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Patient_Info1)
        Me.Panel1.Controls.Add(Me.Pnl_Tran_mode)
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Controls.Add(Me.Dtp_TranDate)
        Me.Panel1.Controls.Add(Me.Btn_Discharge_Find)
        Me.Panel1.Controls.Add(Me.Txt_Discharge_ID)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Btn_PMRFind)
        Me.Panel1.Controls.Add(Me.Txt_PMRID)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(5, 27)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(777, 125)
        Me.Panel1.TabIndex = 0
        '
        'Txt_Patient_ID
        '
        Me.Txt_Patient_ID.BackColor = System.Drawing.Color.White
        Me.Txt_Patient_ID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Patient_ID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Patient_ID.Location = New System.Drawing.Point(96, 99)
        Me.Txt_Patient_ID.MaxLength = 10
        Me.Txt_Patient_ID.Name = "Txt_Patient_ID"
        Me.Txt_Patient_ID.ReadOnly = True
        Me.Txt_Patient_ID.Size = New System.Drawing.Size(183, 21)
        Me.Txt_Patient_ID.TabIndex = 5
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(7, 103)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(64, 13)
        Me.Label4.TabIndex = 100048
        Me.Label4.Text = "Patient ID"
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(696, 6)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(74, 22)
        Me.Pnl_Tran_mode.TabIndex = 100045
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(2, 1)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(68, 16)
        Me.Lbl_Tran_Mode.TabIndex = 0
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(7, 72)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(34, 13)
        Me.Label16.TabIndex = 100044
        Me.Label16.Text = "Date"
        '
        'Dtp_TranDate
        '
        Me.Dtp_TranDate.CustomFormat = " dd/MM/yyyy"
        Me.Dtp_TranDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_TranDate.Location = New System.Drawing.Point(96, 68)
        Me.Dtp_TranDate.Name = "Dtp_TranDate"
        Me.Dtp_TranDate.Size = New System.Drawing.Size(95, 21)
        Me.Dtp_TranDate.TabIndex = 4
        '
        'Btn_Discharge_Find
        '
        Me.Btn_Discharge_Find.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Discharge_Find.BackgroundImage = CType(resources.GetObject("Btn_Discharge_Find.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Discharge_Find.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Discharge_Find.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Discharge_Find.ForeColor = System.Drawing.Color.White
        Me.Btn_Discharge_Find.Location = New System.Drawing.Point(249, 6)
        Me.Btn_Discharge_Find.Name = "Btn_Discharge_Find"
        Me.Btn_Discharge_Find.Size = New System.Drawing.Size(28, 21)
        Me.Btn_Discharge_Find.TabIndex = 1
        Me.Btn_Discharge_Find.TabStop = False
        Me.Btn_Discharge_Find.Text = "F2"
        Me.Btn_Discharge_Find.UseVisualStyleBackColor = False
        '
        'Txt_Discharge_ID
        '
        Me.Txt_Discharge_ID.BackColor = System.Drawing.Color.White
        Me.Txt_Discharge_ID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Discharge_ID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Discharge_ID.Location = New System.Drawing.Point(96, 6)
        Me.Txt_Discharge_ID.MaxLength = 15
        Me.Txt_Discharge_ID.Name = "Txt_Discharge_ID"
        Me.Txt_Discharge_ID.Size = New System.Drawing.Size(152, 21)
        Me.Txt_Discharge_ID.TabIndex = 0
        Me.Txt_Discharge_ID.Tag = ""
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(6, 10)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(79, 13)
        Me.Label2.TabIndex = 100042
        Me.Label2.Text = "Discharge ID"
        '
        'Btn_PMRFind
        '
        Me.Btn_PMRFind.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_PMRFind.BackgroundImage = CType(resources.GetObject("Btn_PMRFind.BackgroundImage"), System.Drawing.Image)
        Me.Btn_PMRFind.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_PMRFind.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_PMRFind.ForeColor = System.Drawing.Color.White
        Me.Btn_PMRFind.Location = New System.Drawing.Point(249, 37)
        Me.Btn_PMRFind.Name = "Btn_PMRFind"
        Me.Btn_PMRFind.Size = New System.Drawing.Size(28, 21)
        Me.Btn_PMRFind.TabIndex = 3
        Me.Btn_PMRFind.TabStop = False
        Me.Btn_PMRFind.Text = "F2"
        Me.Btn_PMRFind.UseVisualStyleBackColor = False
        '
        'Txt_PMRID
        '
        Me.Txt_PMRID.BackColor = System.Drawing.Color.White
        Me.Txt_PMRID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_PMRID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PMRID.Location = New System.Drawing.Point(96, 37)
        Me.Txt_PMRID.MaxLength = 15
        Me.Txt_PMRID.Name = "Txt_PMRID"
        Me.Txt_PMRID.Size = New System.Drawing.Size(152, 21)
        Me.Txt_PMRID.TabIndex = 2
        Me.Txt_PMRID.Tag = ""
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(7, 41)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(50, 13)
        Me.Label1.TabIndex = 100039
        Me.Label1.Text = "PMR-ID"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(126, Byte), Integer))
        Me.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel2.Controls.Add(Me.Pnl_Bill_Dt)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.Dgrd_Patient_Bills)
        Me.Panel2.Location = New System.Drawing.Point(5, 158)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(386, 282)
        Me.Panel2.TabIndex = 103
        '
        'Pnl_Bill_Dt
        '
        Me.Pnl_Bill_Dt.Controls.Add(Me.Grid_Bill_Dt)
        Me.Pnl_Bill_Dt.Location = New System.Drawing.Point(4, 20)
        Me.Pnl_Bill_Dt.Name = "Pnl_Bill_Dt"
        Me.Pnl_Bill_Dt.Size = New System.Drawing.Size(379, 141)
        Me.Pnl_Bill_Dt.TabIndex = 134
        Me.Pnl_Bill_Dt.Visible = False
        '
        'Grid_Bill_Dt
        '
        Me.Grid_Bill_Dt.AllowUserToAddRows = False
        Me.Grid_Bill_Dt.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(252, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.Navy
        Me.Grid_Bill_Dt.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.Grid_Bill_Dt.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(211, Byte), Integer))
        Me.Grid_Bill_Dt.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(87, Byte), Integer), CType(CType(157, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Grid_Bill_Dt.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.Grid_Bill_Dt.ColumnHeadersHeight = 20
        Me.Grid_Bill_Dt.Location = New System.Drawing.Point(-1, -1)
        Me.Grid_Bill_Dt.MultiSelect = False
        Me.Grid_Bill_Dt.Name = "Grid_Bill_Dt"
        Me.Grid_Bill_Dt.ReadOnly = True
        Me.Grid_Bill_Dt.RowHeadersVisible = False
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(254, Byte), Integer))
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.Navy
        Me.Grid_Bill_Dt.RowsDefaultCellStyle = DataGridViewCellStyle3
        Me.Grid_Bill_Dt.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.Grid_Bill_Dt.Size = New System.Drawing.Size(380, 140)
        Me.Grid_Bill_Dt.TabIndex = 136
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Label6.Location = New System.Drawing.Point(126, 3)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(104, 13)
        Me.Label6.TabIndex = 133
        Me.Label6.Text = "Pateint Bill Deails"
        '
        'Dgrd_Patient_Bills
        '
        Me.Dgrd_Patient_Bills.AllowUserToAddRows = False
        Me.Dgrd_Patient_Bills.AllowUserToDeleteRows = False
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(252, Byte), Integer))
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.Color.Navy
        Me.Dgrd_Patient_Bills.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle4
        Me.Dgrd_Patient_Bills.BackgroundColor = System.Drawing.Color.SteelBlue
        Me.Dgrd_Patient_Bills.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(87, Byte), Integer), CType(CType(157, Byte), Integer))
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgrd_Patient_Bills.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle5
        Me.Dgrd_Patient_Bills.ColumnHeadersHeight = 20
        Me.Dgrd_Patient_Bills.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Bill_No, Me.Tr_Date, Me.Tran_Amount})
        Me.Dgrd_Patient_Bills.Location = New System.Drawing.Point(3, 19)
        Me.Dgrd_Patient_Bills.MultiSelect = False
        Me.Dgrd_Patient_Bills.Name = "Dgrd_Patient_Bills"
        Me.Dgrd_Patient_Bills.ReadOnly = True
        Me.Dgrd_Patient_Bills.RowHeadersVisible = False
        DataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(254, Byte), Integer))
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.Color.Navy
        Me.Dgrd_Patient_Bills.RowsDefaultCellStyle = DataGridViewCellStyle9
        Me.Dgrd_Patient_Bills.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.Dgrd_Patient_Bills.Size = New System.Drawing.Size(380, 260)
        Me.Dgrd_Patient_Bills.TabIndex = 132
        '
        'Bill_No
        '
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bill_No.DefaultCellStyle = DataGridViewCellStyle6
        Me.Bill_No.HeaderText = "Bill No"
        Me.Bill_No.Name = "Bill_No"
        Me.Bill_No.ReadOnly = True
        Me.Bill_No.Width = 150
        '
        'Tr_Date
        '
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tr_Date.DefaultCellStyle = DataGridViewCellStyle7
        Me.Tr_Date.HeaderText = "Date"
        Me.Tr_Date.Name = "Tr_Date"
        Me.Tr_Date.ReadOnly = True
        '
        'Tran_Amount
        '
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.Format = "N2"
        DataGridViewCellStyle8.NullValue = Nothing
        Me.Tran_Amount.DefaultCellStyle = DataGridViewCellStyle8
        Me.Tran_Amount.HeaderText = "Amount"
        Me.Tran_Amount.Name = "Tran_Amount"
        Me.Tran_Amount.ReadOnly = True
        Me.Tran_Amount.Width = 125
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(126, Byte), Integer))
        Me.Panel3.Controls.Add(Me.Dgrd_Patient_Payments)
        Me.Panel3.Controls.Add(Me.Label7)
        Me.Panel3.Location = New System.Drawing.Point(397, 158)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(386, 282)
        Me.Panel3.TabIndex = 104
        '
        'Dgrd_Patient_Payments
        '
        Me.Dgrd_Patient_Payments.AllowUserToAddRows = False
        Me.Dgrd_Patient_Payments.AllowUserToDeleteRows = False
        DataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(CType(CType(220, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(252, Byte), Integer))
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.Color.Navy
        Me.Dgrd_Patient_Payments.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle10
        Me.Dgrd_Patient_Payments.BackgroundColor = System.Drawing.Color.SteelBlue
        Me.Dgrd_Patient_Payments.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(CType(CType(23, Byte), Integer), CType(CType(87, Byte), Integer), CType(CType(157, Byte), Integer))
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgrd_Patient_Payments.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle11
        Me.Dgrd_Patient_Payments.ColumnHeadersHeight = 20
        Me.Dgrd_Patient_Payments.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.V_No, Me.Paid_Date, Me.Pay_Type, Me.Paid_Amount})
        Me.Dgrd_Patient_Payments.Location = New System.Drawing.Point(3, 19)
        Me.Dgrd_Patient_Payments.MultiSelect = False
        Me.Dgrd_Patient_Payments.Name = "Dgrd_Patient_Payments"
        Me.Dgrd_Patient_Payments.ReadOnly = True
        Me.Dgrd_Patient_Payments.RowHeadersVisible = False
        DataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(CType(CType(241, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(254, Byte), Integer))
        DataGridViewCellStyle15.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle15.ForeColor = System.Drawing.Color.Navy
        Me.Dgrd_Patient_Payments.RowsDefaultCellStyle = DataGridViewCellStyle15
        Me.Dgrd_Patient_Payments.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.Dgrd_Patient_Payments.Size = New System.Drawing.Size(380, 260)
        Me.Dgrd_Patient_Payments.TabIndex = 135
        '
        'V_No
        '
        DataGridViewCellStyle12.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.V_No.DefaultCellStyle = DataGridViewCellStyle12
        Me.V_No.HeaderText = "Voucher No"
        Me.V_No.Name = "V_No"
        Me.V_No.ReadOnly = True
        Me.V_No.Width = 75
        '
        'Paid_Date
        '
        DataGridViewCellStyle13.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Paid_Date.DefaultCellStyle = DataGridViewCellStyle13
        Me.Paid_Date.HeaderText = "Date"
        Me.Paid_Date.Name = "Paid_Date"
        Me.Paid_Date.ReadOnly = True
        Me.Paid_Date.Width = 75
        '
        'Pay_Type
        '
        Me.Pay_Type.HeaderText = "Payment Type"
        Me.Pay_Type.Name = "Pay_Type"
        Me.Pay_Type.ReadOnly = True
        Me.Pay_Type.Width = 140
        '
        'Paid_Amount
        '
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle14.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle14.Format = "N2"
        DataGridViewCellStyle14.NullValue = Nothing
        Me.Paid_Amount.DefaultCellStyle = DataGridViewCellStyle14
        Me.Paid_Amount.HeaderText = "Amount"
        Me.Paid_Amount.Name = "Paid_Amount"
        Me.Paid_Amount.ReadOnly = True
        Me.Paid_Amount.Width = 82
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(235, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Label7.Location = New System.Drawing.Point(147, 3)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(100, 13)
        Me.Label7.TabIndex = 134
        Me.Label7.Text = "Payment Details"
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(126, Byte), Integer))
        Me.Panel4.Controls.Add(Me.Lbl_Paid_Amt)
        Me.Panel4.Controls.Add(Me.Label9)
        Me.Panel4.Controls.Add(Me.Lbl_Bill_Amt)
        Me.Panel4.Controls.Add(Me.Label5)
        Me.Panel4.Location = New System.Drawing.Point(5, 443)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(778, 22)
        Me.Panel4.TabIndex = 109
        '
        'Lbl_Paid_Amt
        '
        Me.Lbl_Paid_Amt.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Paid_Amt.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Paid_Amt.ForeColor = System.Drawing.Color.White
        Me.Lbl_Paid_Amt.Location = New System.Drawing.Point(674, 5)
        Me.Lbl_Paid_Amt.Name = "Lbl_Paid_Amt"
        Me.Lbl_Paid_Amt.Size = New System.Drawing.Size(101, 13)
        Me.Lbl_Paid_Amt.TabIndex = 112
        Me.Lbl_Paid_Amt.Text = "0.00"
        Me.Lbl_Paid_Amt.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(514, 2)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(125, 18)
        Me.Label9.TabIndex = 111
        Me.Label9.Text = "Total Payment :"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Lbl_Bill_Amt
        '
        Me.Lbl_Bill_Amt.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Bill_Amt.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Bill_Amt.ForeColor = System.Drawing.Color.White
        Me.Lbl_Bill_Amt.Location = New System.Drawing.Point(285, 5)
        Me.Lbl_Bill_Amt.Name = "Lbl_Bill_Amt"
        Me.Lbl_Bill_Amt.Size = New System.Drawing.Size(101, 13)
        Me.Lbl_Bill_Amt.TabIndex = 110
        Me.Lbl_Bill_Amt.Text = "0.00"
        Me.Lbl_Bill_Amt.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(155, 2)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(109, 18)
        Me.Label5.TabIndex = 109
        Me.Label5.Text = "Total Bill Amount :"
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Cancel)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(490, 489)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(292, 34)
        Me.Pnl_Common_Btn.TabIndex = 1
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Clear.Location = New System.Drawing.Point(145, 3)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(71, 26)
        Me.Btn_Clear.TabIndex = 7
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Close.Location = New System.Drawing.Point(216, 3)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(71, 26)
        Me.Btn_Close.TabIndex = 8
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Cancel
        '
        Me.Btn_Cancel.BackgroundImage = CType(resources.GetObject("Btn_Cancel.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Cancel.Enabled = False
        Me.Btn_Cancel.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Cancel.Location = New System.Drawing.Point(74, 3)
        Me.Btn_Cancel.Name = "Btn_Cancel"
        Me.Btn_Cancel.Size = New System.Drawing.Size(71, 26)
        Me.Btn_Cancel.TabIndex = 6
        Me.Btn_Cancel.Text = "Ca&ncel"
        Me.Btn_Cancel.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = CType(resources.GetObject("Btn_Save.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Save.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(3, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(71, 26)
        Me.Btn_Save.TabIndex = 6
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel5.ForeColor = System.Drawing.Color.Blue
        Me.Panel5.Location = New System.Drawing.Point(-1, 483)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(787, 2)
        Me.Panel5.TabIndex = 116
        '
        'Lbl_BalText
        '
        Me.Lbl_BalText.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_BalText.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_BalText.ForeColor = System.Drawing.Color.Blue
        Me.Lbl_BalText.Location = New System.Drawing.Point(523, 467)
        Me.Lbl_BalText.Name = "Lbl_BalText"
        Me.Lbl_BalText.Size = New System.Drawing.Size(122, 13)
        Me.Lbl_BalText.TabIndex = 117
        Me.Lbl_BalText.Text = "Balance Receivable :"
        Me.Lbl_BalText.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Lbl_Balance
        '
        Me.Lbl_Balance.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Balance.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Balance.ForeColor = System.Drawing.Color.Blue
        Me.Lbl_Balance.Location = New System.Drawing.Point(654, 466)
        Me.Lbl_Balance.Name = "Lbl_Balance"
        Me.Lbl_Balance.Size = New System.Drawing.Size(126, 13)
        Me.Lbl_Balance.TabIndex = 118
        Me.Lbl_Balance.Text = "0.00"
        Me.Lbl_Balance.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel6.Controls.Add(Me.Btn_Discharge_Sum)
        Me.Panel6.ForeColor = System.Drawing.Color.White
        Me.Panel6.Location = New System.Drawing.Point(5, 489)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(479, 34)
        Me.Panel6.TabIndex = 119
        '
        'Btn_Discharge_Sum
        '
        Me.Btn_Discharge_Sum.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Discharge_Sum.BackgroundImage = CType(resources.GetObject("Btn_Discharge_Sum.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Discharge_Sum.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Discharge_Sum.ForeColor = System.Drawing.Color.White
        Me.Btn_Discharge_Sum.Location = New System.Drawing.Point(3, 3)
        Me.Btn_Discharge_Sum.Name = "Btn_Discharge_Sum"
        Me.Btn_Discharge_Sum.Size = New System.Drawing.Size(160, 26)
        Me.Btn_Discharge_Sum.TabIndex = 1
        Me.Btn_Discharge_Sum.Text = "Print Discharge Summary"
        Me.Btn_Discharge_Sum.UseVisualStyleBackColor = False
        '
        'Patient_Info1
        '
        Me.Patient_Info1.BackColor = System.Drawing.Color.AliceBlue
        Me.Patient_Info1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Patient_Info1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Patient_Info1.Location = New System.Drawing.Point(285, 4)
        Me.Patient_Info1.Name = "Patient_Info1"
        Me.Patient_Info1.Padding = New System.Windows.Forms.Padding(2)
        Me.Patient_Info1.Size = New System.Drawing.Size(408, 117)
        Me.Patient_Info1.TabIndex = 100046
        '
        'Patient_Discharge_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.TECHNO_CLINIC.My.Resources.Resources.LeftGradiant
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(786, 527)
        Me.Controls.Add(Me.Panel6)
        Me.Controls.Add(Me.Lbl_Balance)
        Me.Controls.Add(Me.Lbl_BalText)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Patient_Discharge_Frm"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Pnl_Tran_mode.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Pnl_Bill_Dt.ResumeLayout(False)
        CType(Me.Grid_Bill_Dt, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Dgrd_Patient_Bills, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.Dgrd_Patient_Payments, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Dtp_TranDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Btn_Discharge_Find As System.Windows.Forms.Button
    Friend WithEvents Txt_Discharge_ID As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Btn_PMRFind As System.Windows.Forms.Button
    Friend WithEvents Txt_PMRID As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Patient_Info1 As TECHNO_CLINIC.Patient_Info
    Friend WithEvents Txt_Patient_ID As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Dgrd_Patient_Bills As System.Windows.Forms.DataGridView
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Bill_Amt As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Paid_Amt As System.Windows.Forms.Label
    Friend WithEvents Dgrd_Patient_Payments As System.Windows.Forms.DataGridView
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Cancel As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Pnl_Bill_Dt As System.Windows.Forms.Panel
    Friend WithEvents Grid_Bill_Dt As System.Windows.Forms.DataGridView
    Friend WithEvents Bill_No As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Tr_Date As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Tran_Amount As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Lbl_BalText As System.Windows.Forms.Label
    Friend WithEvents Lbl_Balance As System.Windows.Forms.Label
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Btn_Discharge_Sum As System.Windows.Forms.Button
    Friend WithEvents V_No As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Paid_Date As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Pay_Type As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Paid_Amount As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
