﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Gen_Transaction_Uttility
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Gen_Transaction_Uttility))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.Dtp_FromDate = New System.Windows.Forms.DateTimePicker
        Me.Dgvw_SearchGrid = New System.Windows.Forms.DataGridView
        Me.Cmb_TranType = New System.Windows.Forms.ComboBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Panel4 = New System.Windows.Forms.Panel
        Me.Btn_Print = New System.Windows.Forms.Button
        Me.Lbl_Note = New System.Windows.Forms.Label
        Me.Cmb_AccountHead = New System.Windows.Forms.ComboBox
        Me.Cmb_PaymentMode = New System.Windows.Forms.ComboBox
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Uttility = New System.Windows.Forms.Button
        Me.Txt_Remarks = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.Txt_Narration = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Dtp_ToDate = New System.Windows.Forms.DateTimePicker
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.Pnl_Header.SuspendLayout()
        CType(Me.Dgvw_SearchGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = CType(resources.GetObject("Pnl_Header.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Header.Controls.Add(Me.Label1)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(766, 24)
        Me.Pnl_Header.TabIndex = 100
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(-1, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(287, 19)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "G e n e r a l   V o u c h e r   U t  i l i t y"
        '
        'Dtp_FromDate
        '
        Me.Dtp_FromDate.CustomFormat = "dd/MM/yyyy"
        Me.Dtp_FromDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_FromDate.Location = New System.Drawing.Point(210, 32)
        Me.Dtp_FromDate.Name = "Dtp_FromDate"
        Me.Dtp_FromDate.Size = New System.Drawing.Size(109, 21)
        Me.Dtp_FromDate.TabIndex = 1
        '
        'Dgvw_SearchGrid
        '
        Me.Dgvw_SearchGrid.AllowUserToAddRows = False
        Me.Dgvw_SearchGrid.AllowUserToDeleteRows = False
        Me.Dgvw_SearchGrid.AllowUserToResizeColumns = False
        Me.Dgvw_SearchGrid.AllowUserToResizeRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(248, Byte), Integer))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.DarkBlue
        Me.Dgvw_SearchGrid.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.Dgvw_SearchGrid.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(236, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Dgvw_SearchGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(75, Byte), Integer), CType(CType(116, Byte), Integer), CType(CType(165, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgvw_SearchGrid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.Dgvw_SearchGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Dgvw_SearchGrid.Location = New System.Drawing.Point(3, 144)
        Me.Dgvw_SearchGrid.Name = "Dgvw_SearchGrid"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(179, Byte), Integer))
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgvw_SearchGrid.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.Dgvw_SearchGrid.RowHeadersVisible = False
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(CType(CType(206, Byte), Integer), CType(CType(214, Byte), Integer), CType(CType(230, Byte), Integer))
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.Color.DarkBlue
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(63, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(169, Byte), Integer))
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.White
        Me.Dgvw_SearchGrid.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.Dgvw_SearchGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.Dgvw_SearchGrid.Size = New System.Drawing.Size(665, 263)
        Me.Dgvw_SearchGrid.TabIndex = 5
        Me.Dgvw_SearchGrid.TabStop = False
        '
        'Cmb_TranType
        '
        Me.Cmb_TranType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_TranType.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_TranType.FormattingEnabled = True
        Me.Cmb_TranType.ItemHeight = 13
        Me.Cmb_TranType.Location = New System.Drawing.Point(450, 32)
        Me.Cmb_TranType.Name = "Cmb_TranType"
        Me.Cmb_TranType.Size = New System.Drawing.Size(135, 21)
        Me.Cmb_TranType.TabIndex = 3
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(1, 16)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(85, 13)
        Me.Label5.TabIndex = 136
        Me.Label5.Text = "Account Head"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(446, 16)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(105, 13)
        Me.Label6.TabIndex = 138
        Me.Label6.Text = "Transaction Type"
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.Transparent
        Me.Panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Controls.Add(Me.Btn_Print)
        Me.Panel4.Controls.Add(Me.Lbl_Note)
        Me.Panel4.Controls.Add(Me.Cmb_AccountHead)
        Me.Panel4.Controls.Add(Me.Cmb_PaymentMode)
        Me.Panel4.Controls.Add(Me.Pnl_Common_Btn)
        Me.Panel4.Controls.Add(Me.Txt_Remarks)
        Me.Panel4.Controls.Add(Me.Label8)
        Me.Panel4.Controls.Add(Me.Txt_Narration)
        Me.Panel4.Controls.Add(Me.Label7)
        Me.Panel4.Controls.Add(Me.Label4)
        Me.Panel4.Controls.Add(Me.Label3)
        Me.Panel4.Controls.Add(Me.Label2)
        Me.Panel4.Controls.Add(Me.Dtp_ToDate)
        Me.Panel4.Controls.Add(Me.Label6)
        Me.Panel4.Controls.Add(Me.Dtp_FromDate)
        Me.Panel4.Controls.Add(Me.Label5)
        Me.Panel4.Controls.Add(Me.Cmb_TranType)
        Me.Panel4.Controls.Add(Me.Dgvw_SearchGrid)
        Me.Panel4.Location = New System.Drawing.Point(93, 24)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(671, 426)
        Me.Panel4.TabIndex = 4
        '
        'Btn_Print
        '
        Me.Btn_Print.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Print.BackgroundImage = CType(resources.GetObject("Btn_Print.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Print.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Print.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Print.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Print.ForeColor = System.Drawing.Color.White
        Me.Btn_Print.Location = New System.Drawing.Point(587, 102)
        Me.Btn_Print.Name = "Btn_Print"
        Me.Btn_Print.Size = New System.Drawing.Size(81, 36)
        Me.Btn_Print.TabIndex = 154
        Me.Btn_Print.UseVisualStyleBackColor = False
        Me.Btn_Print.Visible = False
        '
        'Lbl_Note
        '
        Me.Lbl_Note.AutoSize = True
        Me.Lbl_Note.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Note.ForeColor = System.Drawing.Color.DarkRed
        Me.Lbl_Note.Location = New System.Drawing.Point(0, 410)
        Me.Lbl_Note.Name = "Lbl_Note"
        Me.Lbl_Note.Size = New System.Drawing.Size(144, 13)
        Me.Lbl_Note.TabIndex = 153
        Me.Lbl_Note.Text = "*Select a record to Print"
        '
        'Cmb_AccountHead
        '
        Me.Cmb_AccountHead.DropDownHeight = 150
        Me.Cmb_AccountHead.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_AccountHead.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_AccountHead.FormattingEnabled = True
        Me.Cmb_AccountHead.IntegralHeight = False
        Me.Cmb_AccountHead.ItemHeight = 13
        Me.Cmb_AccountHead.Location = New System.Drawing.Point(3, 32)
        Me.Cmb_AccountHead.Name = "Cmb_AccountHead"
        Me.Cmb_AccountHead.Size = New System.Drawing.Size(196, 21)
        Me.Cmb_AccountHead.TabIndex = 0
        '
        'Cmb_PaymentMode
        '
        Me.Cmb_PaymentMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_PaymentMode.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_PaymentMode.FormattingEnabled = True
        Me.Cmb_PaymentMode.ItemHeight = 13
        Me.Cmb_PaymentMode.Location = New System.Drawing.Point(450, 75)
        Me.Cmb_PaymentMode.Name = "Cmb_PaymentMode"
        Me.Cmb_PaymentMode.Size = New System.Drawing.Size(136, 21)
        Me.Cmb_PaymentMode.TabIndex = 6
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Uttility)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(409, 102)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(176, 36)
        Me.Pnl_Common_Btn.TabIndex = 152
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Clear.ForeColor = System.Drawing.Color.White
        Me.Btn_Clear.Location = New System.Drawing.Point(59, 3)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear.TabIndex = 8
        Me.Btn_Clear.Text = "&Clear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.ForeColor = System.Drawing.Color.White
        Me.Btn_Close.Location = New System.Drawing.Point(115, 3)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 9
        Me.Btn_Close.Text = "C&lose"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Uttility
        '
        Me.Btn_Uttility.BackgroundImage = CType(resources.GetObject("Btn_Uttility.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Uttility.CausesValidation = False
        Me.Btn_Uttility.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Uttility.ForeColor = System.Drawing.Color.White
        Me.Btn_Uttility.Location = New System.Drawing.Point(3, 3)
        Me.Btn_Uttility.Name = "Btn_Uttility"
        Me.Btn_Uttility.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Uttility.TabIndex = 7
        Me.Btn_Uttility.Text = "&Search"
        Me.Btn_Uttility.UseVisualStyleBackColor = True
        '
        'Txt_Remarks
        '
        Me.Txt_Remarks.BackColor = System.Drawing.Color.White
        Me.Txt_Remarks.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Remarks.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Remarks.Location = New System.Drawing.Point(210, 75)
        Me.Txt_Remarks.MaxLength = 100
        Me.Txt_Remarks.Name = "Txt_Remarks"
        Me.Txt_Remarks.Size = New System.Drawing.Size(227, 21)
        Me.Txt_Remarks.TabIndex = 5
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(210, 59)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(58, 13)
        Me.Label8.TabIndex = 147
        Me.Label8.Text = "Remarks"
        '
        'Txt_Narration
        '
        Me.Txt_Narration.BackColor = System.Drawing.Color.White
        Me.Txt_Narration.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Narration.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Narration.Location = New System.Drawing.Point(3, 75)
        Me.Txt_Narration.MaxLength = 100
        Me.Txt_Narration.Name = "Txt_Narration"
        Me.Txt_Narration.Size = New System.Drawing.Size(196, 21)
        Me.Txt_Narration.TabIndex = 4
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(3, 59)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(60, 13)
        Me.Label7.TabIndex = 145
        Me.Label7.Text = "Narration"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(450, 59)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(92, 13)
        Me.Label4.TabIndex = 144
        Me.Label4.Text = "Payment Mode"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(326, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(51, 13)
        Me.Label3.TabIndex = 142
        Me.Label3.Text = "To Date"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(210, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(66, 13)
        Me.Label2.TabIndex = 141
        Me.Label2.Text = "From Date"
        '
        'Dtp_ToDate
        '
        Me.Dtp_ToDate.CustomFormat = "dd/MM/yyyy"
        Me.Dtp_ToDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_ToDate.Location = New System.Drawing.Point(328, 32)
        Me.Dtp_ToDate.Name = "Dtp_ToDate"
        Me.Dtp_ToDate.Size = New System.Drawing.Size(109, 21)
        Me.Dtp_ToDate.TabIndex = 2
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Left
        Me.PictureBox1.Location = New System.Drawing.Point(0, 24)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(93, 428)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox1.TabIndex = 134
        Me.PictureBox1.TabStop = False
        '
        'Gen_Transaction_Uttility
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Clear
        Me.ClientSize = New System.Drawing.Size(766, 452)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Gen_Transaction_Uttility"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        CType(Me.Dgvw_SearchGrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Pnl_Common_Btn.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Dtp_FromDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Dgvw_SearchGrid As System.Windows.Forms.DataGridView
    Friend WithEvents Cmb_TranType As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Dtp_ToDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Txt_Remarks As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Txt_Narration As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Cmb_PaymentMode As System.Windows.Forms.ComboBox
    Friend WithEvents Cmb_AccountHead As System.Windows.Forms.ComboBox
    Friend WithEvents Btn_Uttility As System.Windows.Forms.Button
    Friend WithEvents Lbl_Note As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Btn_Print As System.Windows.Forms.Button
End Class
