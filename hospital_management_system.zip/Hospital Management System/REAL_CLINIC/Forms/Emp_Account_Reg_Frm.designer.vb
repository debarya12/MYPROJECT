﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Emp_Account_Reg_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Emp_Account_Reg_Frm))
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Delete = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.Btn_Find = New System.Windows.Forms.Button
        Me.Txt_AccountNo = New System.Windows.Forms.TextBox
        Me.Lbl_DocID = New System.Windows.Forms.Label
        Me.Btn_Find1 = New System.Windows.Forms.Button
        Me.Txt_EmpID = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Cmb_status = New System.Windows.Forms.ComboBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Dgvw_Emp_AccountMaster = New System.Windows.Forms.DataGridView
        Me.Imageviewer1 = New REAL_CLINIC.Imageviewer
        Me.Employee_Info1 = New REAL_CLINIC.Employee_Info
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.Pnl_Header.SuspendLayout()
        Me.Pnl_Tran_mode.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        CType(Me.Dgvw_Emp_AccountMaster, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Menu_Bkg
        Me.Pnl_Header.Controls.Add(Me.Label1)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(781, 24)
        Me.Pnl_Header.TabIndex = 100
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(8, 1)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(293, 18)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "E m p l o y e e   A c c o u n t   M a s t e r "
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(494, 33)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(74, 22)
        Me.Pnl_Tran_mode.TabIndex = 48
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(1, 1)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(68, 16)
        Me.Lbl_Tran_Mode.TabIndex = 0
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Delete)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(284, 244)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(231, 35)
        Me.Pnl_Common_Btn.TabIndex = 6
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(115, 3)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear.TabIndex = 3
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(171, 3)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 4
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Delete
        '
        Me.Btn_Delete.BackgroundImage = CType(resources.GetObject("Btn_Delete.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Delete.Location = New System.Drawing.Point(59, 3)
        Me.Btn_Delete.Name = "Btn_Delete"
        Me.Btn_Delete.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Delete.TabIndex = 2
        Me.Btn_Delete.Text = "Delete"
        Me.Btn_Delete.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(3, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save.TabIndex = 1
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Btn_Find
        '
        Me.Btn_Find.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find.BackgroundImage = CType(resources.GetObject("Btn_Find.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find.ForeColor = System.Drawing.Color.White
        Me.Btn_Find.Location = New System.Drawing.Point(344, 33)
        Me.Btn_Find.Name = "Btn_Find"
        Me.Btn_Find.Size = New System.Drawing.Size(29, 21)
        Me.Btn_Find.TabIndex = 1
        Me.Btn_Find.TabStop = False
        Me.Btn_Find.Text = "F2"
        Me.Btn_Find.UseVisualStyleBackColor = False
        '
        'Txt_AccountNo
        '
        Me.Txt_AccountNo.BackColor = System.Drawing.Color.White
        Me.Txt_AccountNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_AccountNo.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_AccountNo.Location = New System.Drawing.Point(173, 33)
        Me.Txt_AccountNo.Name = "Txt_AccountNo"
        Me.Txt_AccountNo.Size = New System.Drawing.Size(165, 21)
        Me.Txt_AccountNo.TabIndex = 0
        '
        'Lbl_DocID
        '
        Me.Lbl_DocID.AutoSize = True
        Me.Lbl_DocID.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_DocID.ForeColor = System.Drawing.Color.White
        Me.Lbl_DocID.Location = New System.Drawing.Point(101, 38)
        Me.Lbl_DocID.Name = "Lbl_DocID"
        Me.Lbl_DocID.Size = New System.Drawing.Size(70, 13)
        Me.Lbl_DocID.TabIndex = 50
        Me.Lbl_DocID.Text = "Account No"
        '
        'Btn_Find1
        '
        Me.Btn_Find1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find1.BackgroundImage = CType(resources.GetObject("Btn_Find1.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find1.ForeColor = System.Drawing.Color.White
        Me.Btn_Find1.Location = New System.Drawing.Point(344, 57)
        Me.Btn_Find1.Name = "Btn_Find1"
        Me.Btn_Find1.Size = New System.Drawing.Size(29, 21)
        Me.Btn_Find1.TabIndex = 3
        Me.Btn_Find1.TabStop = False
        Me.Btn_Find1.Text = "F2"
        Me.Btn_Find1.UseVisualStyleBackColor = False
        '
        'Txt_EmpID
        '
        Me.Txt_EmpID.BackColor = System.Drawing.Color.White
        Me.Txt_EmpID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_EmpID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_EmpID.Location = New System.Drawing.Point(173, 57)
        Me.Txt_EmpID.Name = "Txt_EmpID"
        Me.Txt_EmpID.Size = New System.Drawing.Size(165, 21)
        Me.Txt_EmpID.TabIndex = 2
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(102, 59)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(47, 13)
        Me.Label5.TabIndex = 91
        Me.Label5.Text = "Emp ID"
        '
        'Cmb_status
        '
        Me.Cmb_status.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_status.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_status.FormattingEnabled = True
        Me.Cmb_status.Location = New System.Drawing.Point(173, 207)
        Me.Cmb_status.Name = "Cmb_status"
        Me.Cmb_status.Size = New System.Drawing.Size(71, 21)
        Me.Cmb_status.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(102, 210)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(43, 13)
        Me.Label3.TabIndex = 140
        Me.Label3.Text = "Active"
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.FromArgb(CType(CType(19, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(153, Byte), Integer))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(109, 303)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(668, 18)
        Me.Label7.TabIndex = 142
        Me.Label7.Text = "E m p l o y e e   A c c o u n t   L i s t "
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Dgvw_Emp_AccountMaster
        '
        Me.Dgvw_Emp_AccountMaster.AllowUserToAddRows = False
        Me.Dgvw_Emp_AccountMaster.AllowUserToDeleteRows = False
        Me.Dgvw_Emp_AccountMaster.AllowUserToResizeColumns = False
        Me.Dgvw_Emp_AccountMaster.AllowUserToResizeRows = False
        DataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(234, Byte), Integer), CType(CType(248, Byte), Integer))
        DataGridViewCellStyle5.ForeColor = System.Drawing.Color.DarkBlue
        Me.Dgvw_Emp_AccountMaster.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle5
        Me.Dgvw_Emp_AccountMaster.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(236, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Dgvw_Emp_AccountMaster.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(CType(CType(75, Byte), Integer), CType(CType(116, Byte), Integer), CType(CType(165, Byte), Integer))
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgvw_Emp_AccountMaster.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.Dgvw_Emp_AccountMaster.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Dgvw_Emp_AccountMaster.Location = New System.Drawing.Point(109, 324)
        Me.Dgvw_Emp_AccountMaster.Name = "Dgvw_Emp_AccountMaster"
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(112, Byte), Integer), CType(CType(179, Byte), Integer))
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgvw_Emp_AccountMaster.RowHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.Dgvw_Emp_AccountMaster.RowHeadersVisible = False
        DataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(CType(CType(219, Byte), Integer), CType(CType(227, Byte), Integer), CType(CType(249, Byte), Integer))
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle8.ForeColor = System.Drawing.Color.DarkBlue
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.DeepSkyBlue
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.Black
        Me.Dgvw_Emp_AccountMaster.RowsDefaultCellStyle = DataGridViewCellStyle8
        Me.Dgvw_Emp_AccountMaster.Size = New System.Drawing.Size(668, 174)
        Me.Dgvw_Emp_AccountMaster.TabIndex = 141
        '
        'Imageviewer1
        '
        Me.Imageviewer1.CUST_ID = ""
        Me.Imageviewer1.CUST_TYPE = HMS_Common.Common_Cls.Customer_Type.Employee
        Me.Imageviewer1.Location = New System.Drawing.Point(594, 29)
        Me.Imageviewer1.Name = "Imageviewer1"
        Me.Imageviewer1.Scan_Enabled = True
        Me.Imageviewer1.Size = New System.Drawing.Size(183, 247)
        Me.Imageviewer1.TabIndex = 138
        '
        'Employee_Info1
        '
        Me.Employee_Info1.BackColor = System.Drawing.Color.AliceBlue
        Me.Employee_Info1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Employee_Info1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Employee_Info1.ForeColor = System.Drawing.Color.DarkBlue
        Me.Employee_Info1.Location = New System.Drawing.Point(173, 81)
        Me.Employee_Info1.Name = "Employee_Info1"
        Me.Employee_Info1.Padding = New System.Windows.Forms.Padding(2)
        Me.Employee_Info1.Size = New System.Drawing.Size(395, 124)
        Me.Employee_Info1.TabIndex = 4
        Me.Employee_Info1.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Left
        Me.PictureBox1.Location = New System.Drawing.Point(0, 24)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(99, 481)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox1.TabIndex = 10023
        Me.PictureBox1.TabStop = False
        '
        'Emp_Account_Reg_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(781, 505)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Dgvw_Emp_AccountMaster)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Cmb_status)
        Me.Controls.Add(Me.Imageviewer1)
        Me.Controls.Add(Me.Employee_Info1)
        Me.Controls.Add(Me.Txt_EmpID)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Btn_Find1)
        Me.Controls.Add(Me.Txt_AccountNo)
        Me.Controls.Add(Me.Lbl_DocID)
        Me.Controls.Add(Me.Pnl_Tran_mode)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.Btn_Find)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Emp_Account_Reg_Frm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Pnl_Tran_mode.ResumeLayout(False)
        Me.Pnl_Common_Btn.ResumeLayout(False)
        CType(Me.Dgvw_Emp_AccountMaster, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Delete As System.Windows.Forms.Button
    Friend WithEvents Btn_Find As System.Windows.Forms.Button
    Friend WithEvents Txt_AccountNo As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_DocID As System.Windows.Forms.Label
    Friend WithEvents Btn_Find1 As System.Windows.Forms.Button
    Friend WithEvents Txt_EmpID As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Employee_Info1 As REAL_CLINIC.Employee_Info
    Friend WithEvents Imageviewer1 As REAL_CLINIC.Imageviewer
    Friend WithEvents Cmb_status As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Dgvw_Emp_AccountMaster As System.Windows.Forms.DataGridView
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
End Class
