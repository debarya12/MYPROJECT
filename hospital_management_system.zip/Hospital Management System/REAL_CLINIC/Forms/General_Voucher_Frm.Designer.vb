﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class General_Voucher_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(General_Voucher_Frm))
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Dgvw_Tran = New REAL_CLINIC.Tran_DGridview(Me.components)
        Me.Sl_No = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Account_Head = New System.Windows.Forms.DataGridViewComboBoxColumn
        Me.Remarks = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Amount = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Tran_ID = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Lbl_Errormsg = New System.Windows.Forms.Label
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Label5 = New System.Windows.Forms.Label
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Utility = New System.Windows.Forms.Button
        Me.Btn_CancelBatch = New System.Windows.Forms.Button
        Me.Btn_Print = New System.Windows.Forms.Button
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Nav_Tranlist = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.Txt_BatchID = New System.Windows.Forms.TextBox
        Me.Dtp_Trandate = New System.Windows.Forms.DateTimePicker
        Me.Btn_Find = New System.Windows.Forms.Button
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.Label8 = New System.Windows.Forms.Label
        Me.Cmb_PaymentMode = New System.Windows.Forms.ComboBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.Cmb_TranType = New System.Windows.Forms.ComboBox
        Me.Lbl_Words = New System.Windows.Forms.Label
        Me.Lbl_TotalAmount = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Txt_Narration = New System.Windows.Forms.TextBox
        Me.BindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.Btn_Showtranlist = New System.Windows.Forms.Button
        Me.Panel1.SuspendLayout()
        CType(Me.Dgvw_Tran, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Pnl_Header.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        CType(Me.Nav_Tranlist, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Nav_Tranlist.SuspendLayout()
        Me.Pnl_Tran_mode.SuspendLayout()
        Me.Panel3.SuspendLayout()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.Dgvw_Tran)
        Me.Panel1.Location = New System.Drawing.Point(12, 96)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Padding = New System.Windows.Forms.Padding(1)
        Me.Panel1.Size = New System.Drawing.Size(617, 268)
        Me.Panel1.TabIndex = 4
        '
        'Dgvw_Tran
        '
        Me.Dgvw_Tran.AllowUserToAddRows = False
        Me.Dgvw_Tran.AllowUserToResizeColumns = False
        Me.Dgvw_Tran.AllowUserToResizeRows = False
        DataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(CType(CType(249, Byte), Integer), CType(CType(245, Byte), Integer), CType(CType(250, Byte), Integer))
        Me.Dgvw_Tran.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle6
        Me.Dgvw_Tran.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(153, Byte), Integer), CType(CType(175, Byte), Integer), CType(CType(202, Byte), Integer))
        DataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(CType(CType(225, Byte), Integer), CType(CType(201, Byte), Integer), CType(CType(226, Byte), Integer))
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.Color.Maroon
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgvw_Tran.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.Dgvw_Tran.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.Dgvw_Tran.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Sl_No, Me.Account_Head, Me.Remarks, Me.Amount, Me.Tran_ID})
        Me.Dgvw_Tran.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Dgvw_Tran.Location = New System.Drawing.Point(1, 1)
        Me.Dgvw_Tran.MultiSelect = False
        Me.Dgvw_Tran.Name = "Dgvw_Tran"
        Me.Dgvw_Tran.RowHeadersVisible = False
        Me.Dgvw_Tran.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dgvw_Tran.RowsDefaultCellStyle = DataGridViewCellStyle10
        Me.Dgvw_Tran.Size = New System.Drawing.Size(611, 262)
        Me.Dgvw_Tran.TabIndex = 1
        '
        'Sl_No
        '
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.Sl_No.DefaultCellStyle = DataGridViewCellStyle8
        Me.Sl_No.Frozen = True
        Me.Sl_No.HeaderText = "SL.No"
        Me.Sl_No.Name = "Sl_No"
        Me.Sl_No.ReadOnly = True
        Me.Sl_No.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Sl_No.Width = 40
        '
        'Account_Head
        '
        Me.Account_Head.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.[Nothing]
        Me.Account_Head.Frozen = True
        Me.Account_Head.HeaderText = "Account Head"
        Me.Account_Head.Name = "Account_Head"
        Me.Account_Head.Width = 250
        '
        'Remarks
        '
        Me.Remarks.Frozen = True
        Me.Remarks.HeaderText = "Remarks"
        Me.Remarks.Name = "Remarks"
        Me.Remarks.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Remarks.Width = 200
        '
        'Amount
        '
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        DataGridViewCellStyle9.Format = "N2"
        DataGridViewCellStyle9.NullValue = Nothing
        Me.Amount.DefaultCellStyle = DataGridViewCellStyle9
        Me.Amount.Frozen = True
        Me.Amount.HeaderText = "Amount"
        Me.Amount.Name = "Amount"
        Me.Amount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'Tran_ID
        '
        Me.Tran_ID.HeaderText = "Tran_ID"
        Me.Tran_ID.Name = "Tran_ID"
        Me.Tran_ID.ReadOnly = True
        Me.Tran_ID.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.LavenderBlush
        Me.Label2.Location = New System.Drawing.Point(79, 79)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(142, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Press  ( F3 )  to add new row"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.ForeColor = System.Drawing.Color.LavenderBlush
        Me.Label1.Location = New System.Drawing.Point(242, 79)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(179, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Press  ( F12 )  to delete selected row"
        '
        'Lbl_Errormsg
        '
        Me.Lbl_Errormsg.AutoSize = True
        Me.Lbl_Errormsg.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Errormsg.ForeColor = System.Drawing.Color.White
        Me.Lbl_Errormsg.Location = New System.Drawing.Point(7, 351)
        Me.Lbl_Errormsg.Name = "Lbl_Errormsg"
        Me.Lbl_Errormsg.Size = New System.Drawing.Size(0, 13)
        Me.Lbl_Errormsg.TabIndex = 4
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.F2_Button
        Me.Pnl_Header.Controls.Add(Me.Label5)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(771, 24)
        Me.Pnl_Header.TabIndex = 154
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(3, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(196, 19)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "G e n e r a l   V o u c h e r"
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.Purple
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Utility)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_CancelBatch)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Print)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(178, 419)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(450, 34)
        Me.Pnl_Common_Btn.TabIndex = 5
        '
        'Btn_Close
        '
        Me.Btn_Close.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Close.Location = New System.Drawing.Point(374, 3)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(71, 26)
        Me.Btn_Close.TabIndex = 6
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = False
        '
        'Btn_Utility
        '
        Me.Btn_Utility.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Btn_Utility.BackgroundImage = CType(resources.GetObject("Btn_Utility.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Utility.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Utility.CausesValidation = False
        Me.Btn_Utility.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Utility.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Utility.Location = New System.Drawing.Point(303, 3)
        Me.Btn_Utility.Name = "Btn_Utility"
        Me.Btn_Utility.Size = New System.Drawing.Size(71, 26)
        Me.Btn_Utility.TabIndex = 5
        Me.Btn_Utility.Text = "&Utility"
        Me.Btn_Utility.UseVisualStyleBackColor = False
        '
        'Btn_CancelBatch
        '
        Me.Btn_CancelBatch.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Btn_CancelBatch.BackgroundImage = CType(resources.GetObject("Btn_CancelBatch.BackgroundImage"), System.Drawing.Image)
        Me.Btn_CancelBatch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_CancelBatch.Enabled = False
        Me.Btn_CancelBatch.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_CancelBatch.Location = New System.Drawing.Point(216, 3)
        Me.Btn_CancelBatch.Name = "Btn_CancelBatch"
        Me.Btn_CancelBatch.Size = New System.Drawing.Size(87, 26)
        Me.Btn_CancelBatch.TabIndex = 4
        Me.Btn_CancelBatch.Text = "Ca&ncel Batch"
        Me.Btn_CancelBatch.UseVisualStyleBackColor = False
        '
        'Btn_Print
        '
        Me.Btn_Print.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Btn_Print.BackgroundImage = CType(resources.GetObject("Btn_Print.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Print.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Print.Enabled = False
        Me.Btn_Print.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Print.ForeColor = System.Drawing.Color.White
        Me.Btn_Print.Location = New System.Drawing.Point(145, 3)
        Me.Btn_Print.Name = "Btn_Print"
        Me.Btn_Print.Size = New System.Drawing.Size(71, 26)
        Me.Btn_Print.TabIndex = 3
        Me.Btn_Print.Text = "&Print"
        Me.Btn_Print.UseVisualStyleBackColor = False
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Clear.Location = New System.Drawing.Point(74, 3)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(71, 26)
        Me.Btn_Clear.TabIndex = 2
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = False
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Btn_Save.BackgroundImage = CType(resources.GetObject("Btn_Save.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Save.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Save.Enabled = False
        Me.Btn_Save.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(3, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(71, 26)
        Me.Btn_Save.TabIndex = 1
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Left
        Me.PictureBox1.Location = New System.Drawing.Point(0, 24)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(131, 502)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox1.TabIndex = 159
        Me.PictureBox1.TabStop = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Transparent
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.Btn_Showtranlist)
        Me.Panel2.Controls.Add(Me.Nav_Tranlist)
        Me.Panel2.Controls.Add(Me.Txt_BatchID)
        Me.Panel2.Controls.Add(Me.Dtp_Trandate)
        Me.Panel2.Controls.Add(Me.Btn_Find)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(131, 24)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(640, 40)
        Me.Panel2.TabIndex = 1
        '
        'Nav_Tranlist
        '
        Me.Nav_Tranlist.AddNewItem = Nothing
        Me.Nav_Tranlist.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.F2_Button
        Me.Nav_Tranlist.CountItem = Me.BindingNavigatorCountItem
        Me.Nav_Tranlist.DeleteItem = Nothing
        Me.Nav_Tranlist.Dock = System.Windows.Forms.DockStyle.None
        Me.Nav_Tranlist.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Nav_Tranlist.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2})
        Me.Nav_Tranlist.Location = New System.Drawing.Point(471, 6)
        Me.Nav_Tranlist.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.Nav_Tranlist.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.Nav_Tranlist.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.Nav_Tranlist.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.Nav_Tranlist.Name = "Nav_Tranlist"
        Me.Nav_Tranlist.PositionItem = Me.BindingNavigatorPositionItem
        Me.Nav_Tranlist.Size = New System.Drawing.Size(172, 25)
        Me.Nav_Tranlist.TabIndex = 153
        Me.Nav_Tranlist.Text = "BindingNavigator1"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(42, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(20, 21)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'Txt_BatchID
        '
        Me.Txt_BatchID.BackColor = System.Drawing.Color.White
        Me.Txt_BatchID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_BatchID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_BatchID.Location = New System.Drawing.Point(80, 8)
        Me.Txt_BatchID.MaxLength = 10
        Me.Txt_BatchID.Name = "Txt_BatchID"
        Me.Txt_BatchID.Size = New System.Drawing.Size(137, 21)
        Me.Txt_BatchID.TabIndex = 1
        '
        'Dtp_Trandate
        '
        Me.Dtp_Trandate.CustomFormat = " dd/MM/yyyy"
        Me.Dtp_Trandate.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dtp_Trandate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_Trandate.Location = New System.Drawing.Point(350, 8)
        Me.Dtp_Trandate.Name = "Dtp_Trandate"
        Me.Dtp_Trandate.Size = New System.Drawing.Size(119, 21)
        Me.Dtp_Trandate.TabIndex = 3
        '
        'Btn_Find
        '
        Me.Btn_Find.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_Find.BackgroundImage = CType(resources.GetObject("Btn_Find.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Find.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Find.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_Find.ForeColor = System.Drawing.Color.White
        Me.Btn_Find.Location = New System.Drawing.Point(218, 8)
        Me.Btn_Find.Name = "Btn_Find"
        Me.Btn_Find.Size = New System.Drawing.Size(29, 21)
        Me.Btn_Find.TabIndex = 2
        Me.Btn_Find.TabStop = False
        Me.Btn_Find.Text = "F2"
        Me.Btn_Find.UseVisualStyleBackColor = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(10, 12)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(60, 13)
        Me.Label4.TabIndex = 151
        Me.Label4.Text = "BATCH ID"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(276, 12)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(69, 13)
        Me.Label3.TabIndex = 152
        Me.Label3.Text = "TRAN DATE"
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(554, 9)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(74, 22)
        Me.Pnl_Tran_mode.TabIndex = 153
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(3, 1)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(68, 16)
        Me.Lbl_Tran_Mode.TabIndex = 0
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.Transparent
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.Label8)
        Me.Panel3.Controls.Add(Me.Cmb_PaymentMode)
        Me.Panel3.Controls.Add(Me.Label9)
        Me.Panel3.Controls.Add(Me.Cmb_TranType)
        Me.Panel3.Controls.Add(Me.Pnl_Tran_mode)
        Me.Panel3.Controls.Add(Me.Lbl_Words)
        Me.Panel3.Controls.Add(Me.Lbl_TotalAmount)
        Me.Panel3.Controls.Add(Me.Label6)
        Me.Panel3.Controls.Add(Me.Label7)
        Me.Panel3.Controls.Add(Me.Txt_Narration)
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Controls.Add(Me.Panel1)
        Me.Panel3.Controls.Add(Me.Label1)
        Me.Panel3.Controls.Add(Me.Pnl_Common_Btn)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(131, 64)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(640, 462)
        Me.Panel3.TabIndex = 2
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(253, 13)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(92, 13)
        Me.Label8.TabIndex = 167
        Me.Label8.Text = "Payment Mode"
        '
        'Cmb_PaymentMode
        '
        Me.Cmb_PaymentMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_PaymentMode.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Cmb_PaymentMode.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_PaymentMode.FormattingEnabled = True
        Me.Cmb_PaymentMode.ItemHeight = 13
        Me.Cmb_PaymentMode.Location = New System.Drawing.Point(350, 9)
        Me.Cmb_PaymentMode.Name = "Cmb_PaymentMode"
        Me.Cmb_PaymentMode.Size = New System.Drawing.Size(120, 21)
        Me.Cmb_PaymentMode.TabIndex = 2
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(8, 14)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(64, 13)
        Me.Label9.TabIndex = 166
        Me.Label9.Text = "Tran Type"
        '
        'Cmb_TranType
        '
        Me.Cmb_TranType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_TranType.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Cmb_TranType.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_TranType.FormattingEnabled = True
        Me.Cmb_TranType.ItemHeight = 13
        Me.Cmb_TranType.Location = New System.Drawing.Point(80, 9)
        Me.Cmb_TranType.Name = "Cmb_TranType"
        Me.Cmb_TranType.Size = New System.Drawing.Size(137, 21)
        Me.Cmb_TranType.TabIndex = 1
        '
        'Lbl_Words
        '
        Me.Lbl_Words.BackColor = System.Drawing.Color.FromArgb(CType(CType(183, Byte), Integer), CType(CType(120, Byte), Integer), CType(CType(186, Byte), Integer))
        Me.Lbl_Words.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Words.ForeColor = System.Drawing.Color.Indigo
        Me.Lbl_Words.Location = New System.Drawing.Point(14, 394)
        Me.Lbl_Words.Name = "Lbl_Words"
        Me.Lbl_Words.Size = New System.Drawing.Size(614, 15)
        Me.Lbl_Words.TabIndex = 163
        Me.Lbl_Words.Text = "*"
        Me.Lbl_Words.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Lbl_TotalAmount
        '
        Me.Lbl_TotalAmount.BackColor = System.Drawing.Color.White
        Me.Lbl_TotalAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Lbl_TotalAmount.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_TotalAmount.ForeColor = System.Drawing.Color.Maroon
        Me.Lbl_TotalAmount.Location = New System.Drawing.Point(465, 368)
        Me.Lbl_TotalAmount.Name = "Lbl_TotalAmount"
        Me.Lbl_TotalAmount.Padding = New System.Windows.Forms.Padding(0, 0, 20, 0)
        Me.Lbl_TotalAmount.Size = New System.Drawing.Size(164, 22)
        Me.Lbl_TotalAmount.TabIndex = 162
        Me.Lbl_TotalAmount.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(407, 371)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(52, 13)
        Me.Label6.TabIndex = 161
        Me.Label6.Text = "TOTAL  :"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(11, 42)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(60, 13)
        Me.Label7.TabIndex = 160
        Me.Label7.Text = "Narration"
        '
        'Txt_Narration
        '
        Me.Txt_Narration.BackColor = System.Drawing.Color.White
        Me.Txt_Narration.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Narration.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Narration.Location = New System.Drawing.Point(80, 38)
        Me.Txt_Narration.MaxLength = 100
        Me.Txt_Narration.Name = "Txt_Narration"
        Me.Txt_Narration.Size = New System.Drawing.Size(548, 21)
        Me.Txt_Narration.TabIndex = 3
        '
        'BindingSource1
        '
        '
        'Btn_Showtranlist
        '
        Me.Btn_Showtranlist.BackColor = System.Drawing.Color.Thistle
        Me.Btn_Showtranlist.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Gendatasave1
        Me.Btn_Showtranlist.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Showtranlist.ForeColor = System.Drawing.Color.White
        Me.Btn_Showtranlist.Location = New System.Drawing.Point(471, 6)
        Me.Btn_Showtranlist.Name = "Btn_Showtranlist"
        Me.Btn_Showtranlist.Size = New System.Drawing.Size(167, 25)
        Me.Btn_Showtranlist.TabIndex = 4
        Me.Btn_Showtranlist.TabStop = False
        Me.Btn_Showtranlist.Text = "Show Tran List"
        Me.Btn_Showtranlist.UseVisualStyleBackColor = False
        '
        'General_Voucher_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Gendatasave1
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(771, 526)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Controls.Add(Me.Lbl_Errormsg)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "General_Voucher_Frm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Panel1.ResumeLayout(False)
        CType(Me.Dgvw_Tran, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Pnl_Common_Btn.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.Nav_Tranlist, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Nav_Tranlist.ResumeLayout(False)
        Me.Nav_Tranlist.PerformLayout()
        Me.Pnl_Tran_mode.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Dgvw_Tran As REAL_CLINIC.Tran_DGridview
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Errormsg As System.Windows.Forms.Label
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Print As System.Windows.Forms.Button
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_CancelBatch As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Txt_BatchID As System.Windows.Forms.TextBox
    Friend WithEvents Dtp_Trandate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Btn_Find As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Txt_Narration As System.Windows.Forms.TextBox
    Friend WithEvents Lbl_TotalAmount As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Words As System.Windows.Forms.Label
    Friend WithEvents Sl_No As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Account_Head As System.Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents Remarks As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Amount As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Tran_ID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Cmb_PaymentMode As System.Windows.Forms.ComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Cmb_TranType As System.Windows.Forms.ComboBox
    Friend WithEvents Nav_Tranlist As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingSource1 As System.Windows.Forms.BindingSource
    Friend WithEvents Btn_Utility As System.Windows.Forms.Button
    Friend WithEvents Btn_Showtranlist As System.Windows.Forms.Button
End Class
