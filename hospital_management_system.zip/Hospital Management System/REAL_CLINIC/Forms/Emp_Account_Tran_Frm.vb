﻿
Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls

Public Class Emp_Account_Tran_Frm

#Region "Declarations"
    'Object of Employee Details Bussiness Layer

    Private hms_helper As HMS_Helper = Nothing
    Private Emp_Acc_Reg_BL As Emp_Account_Reg_BL_Cls
    Private Emp_Acc_Tran_BL As Employee_Account_Tran_BL_Cls
    Private mTr_Mode As Tran_Mode


    Private mRpt_Vwr As ReportViewer_Cls
    Private Rpt_BL As HMS_BL.Reports_BL_Cls

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing
    Private IsHandleAdded As Boolean

    Private CellRowindex As Integer
    Private CellColindex As Integer


    Private GrDtbl As DataTable

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_AccountNo.BackColor = Color.White
                    Me.Txt_AccountNo.ReadOnly = False
                    Me.Cmb_Payment_Mode.Enabled = True
                    Me.Cmb_Tran_Type.Enabled = True
                    Me.Btn_Cancel.Enabled = False
                    Me.Txt_EmpID.BackColor = Color.White
                    Me.Txt_EmpID.ReadOnly = False
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_AccountNo.BackColor = Color.Silver
                    Me.Txt_AccountNo.ReadOnly = True
                    Me.Btn_Cancel.Enabled = True
                    Me.Cmb_Payment_Mode.Enabled = False
                    Me.Cmb_Tran_Type.Enabled = False
                    Me.Txt_EmpID.BackColor = Color.Silver
                    Me.Txt_EmpID.ReadOnly = True
            End Select
        End Set
    End Property

#End Region

#Region "Methods"

    Private Sub Clear_Form()
        Try

            Txt_EmpID.Text = ""
            Txt_AccountNo.Text = ""
            Txt_AccountNo.Tag = ""
            Lbl_AccNo.Tag = ""
            Txt_Amount.Text = ""
            Txt_Narration.Text = ""
            Txt_LedgerBal.Text = ""
            Txt_TransactionBal.Text = ""

            Dgvw_Emp_AccountTran.DataSource = Nothing
            Dgvw_Emp_AccountTran.Refresh()
            If Cmb_Tran_Type.Items.Count > 0 Then Cmb_Tran_Type.SelectedIndex = 0
            If Cmb_Payment_Mode.Items.Count > 0 Then Cmb_Payment_Mode.SelectedIndex = 0

            Tr_Mode = Tran_Mode.New_Mode
            Btn_Save.Enabled = True
            Btn_Cancel.Enabled = False

        Catch ex As Exception

        End Try
    End Sub

    Private Function Locate_Values() As Boolean
        Try
            Dim dtbl As DataTable = Nothing

            Emp_Acc_Reg_BL = New Emp_Account_Reg_BL_Cls
            If Emp_Acc_Reg_BL.Get_Emp_Account_Reg(dtbl, Txt_AccountNo.Text.Trim, Branch_Code) Then
                Txt_EmpID.Text = dtbl.Rows(0).Item("Emp_ID").ToString
                Txt_AccountNo.Tag = dtbl.Rows(0).Item("Acc_Code").ToString
                Cmb_Tran_Type.SelectedIndex = IIf(dtbl.Rows(0).Item("Active").ToString = "Y", 0, 1)
                'LEDGER BALANCE 
                Txt_LedgerBal.Text = Get_LedgerBalance(Txt_AccountNo.Text.Trim)

            Else : Return False : End If
            Call Fill_GridTranGrid(Txt_AccountNo.Text.Trim)
            Return True
        Catch ex As Exception

        End Try
    End Function

    Private Function Validate_Fields() As Boolean
        Try
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If

            If Tr_Mode <> Tran_Mode.New_Mode Then
                If Txt_AccountNo.Text.Trim = "" Then MessageBox.Show("Invalid Employee Account Number,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_AccountNo.Focus() : Return False
            End If
            'Assigning Default values
            If Txt_EmpID.Text.Trim = "" Then MessageBox.Show("Invalid Employee ID, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_EmpID.Focus() : Return False
            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Is_Emp_Account_Reg(ByVal Emp_ID As Integer, ByRef Acc_No As String) As Boolean
        Try
            Dim dtbl As DataTable = Nothing

            Emp_Acc_Reg_BL = New Emp_Account_Reg_BL_Cls
            If Emp_Acc_Reg_BL.Is_Emp_Account_Reg(dtbl, Emp_ID, Branch_Code) Then
                If dtbl.Rows.Count > 0 Then
                    Acc_No = dtbl.Rows(0).Item("Acc_no").ToString
                    Return False
                End If
                Return True
            End If
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Fill_GridTranGrid(ByVal Acc_No As String) As Boolean
        Try


            Emp_Acc_Tran_BL = New Employee_Account_Tran_BL_Cls
            Dtbl = Nothing
            If Emp_Acc_Tran_BL.Get_Emp_Account_Tran_All(Dtbl, Acc_No, Branch_Code) Then
                Dgvw_Emp_AccountTran.DataSource = Dtbl
                Dgvw_Emp_AccountTran.Columns(6).Visible = False
                Dgvw_Emp_AccountTran.Columns(7).Visible = False
                Dgvw_Emp_AccountTran.Columns(8).Visible = False
                Dgvw_Emp_AccountTran.Columns(0).Width = 70
                Dgvw_Emp_AccountTran.Columns(2).Width = 80
                Dgvw_Emp_AccountTran.Columns(3).Width = 80
                Dgvw_Emp_AccountTran.Columns(1).CellTemplate.Style.Alignment = DataGridViewContentAlignment.MiddleRight
                Dgvw_Emp_AccountTran.Refresh()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function

    Public Function Locate_Transaction_Details(ByVal Tran_ID As Integer) As Boolean
        Try

            Emp_Acc_Tran_BL = New Employee_Account_Tran_BL_Cls
            Dtbl = Nothing
            If Emp_Acc_Tran_BL.Get_Emp_Account_Tran(Dtbl, Tran_ID, Branch_Code) Then
                Cmb_Tran_Type.SelectedIndex = IIf(Dtbl.Rows(0).Item("Tr_Type").ToString = "R", 1, 2)
                Cmb_Payment_Mode.SelectedValue = Dtbl.Rows(0).Item("Tr_Pay_Mode").ToString
                Txt_Narration.Text = Dtbl.Rows(0).Item("Tr_Remarks").ToString
                Lbl_AccNo.Tag = Dtbl.Rows(0).Item("Tran_ID").ToString
                Txt_AccountNo.Tag = Dtbl.Rows(0).Item("Acc_Code").ToString
                Txt_Amount.Enabled = True
                Txt_Narration.Enabled = True
                Call Arrive_Transaction_Bal_Anydate(Dtbl.Rows(0).Item("Tr_Balance").ToString, _
                                                  Dtbl.Rows(0).Item("tr_Type").ToString, _
                                                   Dtbl.Rows(0).Item("Tr_Amount").ToString)
                Txt_Amount.Text = Dtbl.Rows(0).Item("Tr_Amount").ToString

              

                If DateDiff(DateInterval.Day, Dtbl.Rows(0).Item("tr_date"), Tran_Date) <> 0 Then
                    Txt_Amount.Enabled = False
                    Txt_Narration.Enabled = False
                End If
                Return True
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function

    Public Function Show_Reciept(ByVal Acc_NO As String) As Boolean
        Try
            If Acc_NO = "" Then MessageBox.Show("Invalid  Patient ID .. Please enter valid Patient Id", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_AccountNo.Focus() : Exit Function

            Dim Rpt_Ds As DataSet = Nothing
            Dim Rpt_Formulafields As String = "Company| " & Company_Name & "|Branch|" & Branch_Name
            Dim Rpt_Filename As String = ""
            Dim mReport_ID As String = ""
            Dim Report_Heading As String = ""
            Dim Add_Query As String = ""

            mRpt_Vwr = New ReportViewer_Cls

            Emp_Acc_Tran_BL = New Employee_Account_Tran_BL_Cls
            Add_Query = ""
            Add_Query = "Where [Acc_No] = '" & Acc_NO & "'  and Br_Code='" & Branch_Code & "'"
            Rpt_Filename = File_Path & "\Employee_Account_Ledger.rpt"

            If Emp_Acc_Tran_BL.Get_Emp_Account_Ledger(Rpt_Ds, Add_Query) Then
                Report_Heading = "|Heading| Employee Account Transaction Ledger|Footer3|Authorised Signatory"
                Rpt_Formulafields = Rpt_Formulafields & Report_Heading & ")"
                mRpt_Vwr.ShowReport(Rpt_Ds, Rpt_Formulafields, Rpt_Filename, "")
            Else
                MessageBox.Show("Invalid Account Number Please enter Account Number", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Txt_AccountNo.Focus()
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function

    Private Function Get_LedgerBalance(ByVal Acc_No As String) As Double
        Try
            Dim dtbl As DataTable = Nothing
            Emp_Acc_Tran_BL = New Employee_Account_Tran_BL_Cls
            If Emp_Acc_Tran_BL.Get_Emp_Account_Balance(dtbl, Acc_No, Branch_Code) Then
                Return dtbl.Rows(0).Item(0).ToString
            Else
                Return 0
            End If

        Catch ex As Exception
            Return 0
        End Try
    End Function

    Private Sub Arrive_Transaction_Bal()
        Try

            If Strings.Left(Cmb_Tran_Type.Text, 1).Trim.ToUpper = "R" Then _
            Txt_TransactionBal.Text = Val(Txt_LedgerBal.Text) + Val(Txt_Amount.Text)

            If Strings.Left(Cmb_Tran_Type.Text, 1).Trim.ToUpper = "P" Then _
           Txt_TransactionBal.Text = Val(Txt_LedgerBal.Text) - Val(Txt_Amount.Text)
            Txt_TransactionBal.Text = Format(Val(Txt_TransactionBal.Text), "00.00")

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Arrive_Transaction_Bal_Anydate(ByVal CurrentBal As Double, _
                                               ByVal Tran_Type As Char, _
                                               ByVal Tran_Amount As Double)
        Try
            CurrentBal = Format(CurrentBal, "00.00")
            Tran_Amount = Format(Tran_Amount, "00.00")

            If Tran_Type.ToString.ToUpper = "R" Then _
            Txt_LedgerBal.Text = CurrentBal - Tran_Amount

            If Tran_Type.ToString.ToUpper = "P" Then _
            Txt_LedgerBal.Text = CurrentBal + Tran_Amount


        Catch ex As Exception

        End Try
    End Sub

#End Region

    Private Sub Emp_Account_Reg_Frm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            hms_helper = New Hms_Helperimpliments
            Dim Dtbl As DataTable = Nothing
            Emp_Acc_Tran_BL = New Employee_Account_Tran_BL_Cls
            'populate Transaction type
            Fill_Transaction_Type(Cmb_Tran_Type, "< Select >")
            Cmb_Tran_Type.SelectedIndex = 0
            'populate Mode of Payment
            hms_helper.Fill_GenData(Cmb_Payment_Mode, Gendatatype.Payment_Mode, "< Select >")
            Cmb_Payment_Mode.SelectedIndex = 0
          
            Txt_AccountNo.Focus()

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_EmpID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_EmpID.TextChanged
        Try


            With Employee_Info1
                .Viewmoreform_Name = "Employee_InfoSheet_Frm"
                .MDIform_Name = Me.MdiParent
                .Employee_ID = Txt_EmpID.Text.Trim
            End With
            With Imageviewer1
                .CUST_TYPE = Customer_Type.Employee
                .CUST_ID = Txt_EmpID.Text.Trim
            End With

            If Txt_EmpID.Text.Trim = "" Then
                Call Clear_Form()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub DoctorMaster_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then Call SendKeyTab()
        Catch ex As Exception

        End Try

    End Sub

    Private Sub DoctorMaster_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        Try
            If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try



            'Validating Data controls
            If Not Validate_Fields() Then Exit Sub
            Emp_Acc_Tran_BL = New Employee_Account_Tran_BL_Cls
            If Emp_Acc_Tran_BL.Get_Emp_Acctran_Batch(Dtbl, Branch_Code) Then
                Emp_Acc_Tran_BL.Tran_BatchID = Dtbl.Rows(0).Item(0).ToString
            Else
                Emp_Acc_Tran_BL.Tran_BatchID = "001"
            End If


            Emp_Acc_Tran_BL.Tran_ID = Val(Lbl_AccNo.Tag)

            Emp_Acc_Tran_BL.Acc_No = Txt_AccountNo.Text.Trim
            Emp_Acc_Tran_BL.Acc_Code = Txt_AccountNo.Tag
            Emp_Acc_Tran_BL.Acc_Category = Txt_AccountNo.Tag
            Emp_Acc_Tran_BL.Tr_Date = Tran_Date
            Emp_Acc_Tran_BL.Tr_Amount = Val(Txt_Amount.Text)
            Emp_Acc_Tran_BL.Tr_Remarks = Txt_Narration.Text
            Emp_Acc_Tran_BL.Tr_RefNo = ""
            Emp_Acc_Tran_BL.Tr_Type = Strings.Left(Cmb_Tran_Type.Text, 1).ToUpper
            Emp_Acc_Tran_BL.Tr_Pay_Mode = Cmb_Payment_Mode.SelectedValue
            Emp_Acc_Tran_BL.Cancelled = "N"
            Emp_Acc_Tran_BL.C_Time = Tran_Date

            If Emp_Acc_Tran_BL.Save_Emp_Account_Tran(Dtbl, Val(Lbl_AccNo.Tag), Tr_Mode) Then
                If Dtbl.Rows(0).Item(0).ToString = "0" Then
                    MessageBox.Show("Employee Account Transaction Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Exit Sub
                End If
                Txt_AccountNo.Tag = Dtbl.Rows(0).Item("Tran_ID").ToString
                Tr_Mode = Tran_Mode.Edit_Mode
                MessageBox.Show("Employee Account Transaction Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Btn_Clear.Focus()
                Call Fill_GridTranGrid(Txt_AccountNo.Text.Trim)
            Else
                MessageBox.Show("Employee Account Transaction Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Exit Sub
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try
            If Txt_AccountNo.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "200|200|50|"
                Sql = "Select * from  Emp_Account_Reg_Vw where Br_Code = " & Branch_Code & ""
                Call ShowSearchengine(Txt_AccountNo, Sql, 1, "Name", Colwidth, , 0)
            End If

            'Validating Mandatory fields for locating
            If Txt_AccountNo.Text.Trim = "" Then
                'MessageBox.Show("Invalid Employee ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_AccountNo.Focus() : Exit Sub
            End If

            If Not Locate_Values() Then
                MessageBox.Show("Account Number does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try
            Call Clear_Form()
            Txt_AccountNo.Focus()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

    Private Sub Dgvw_Emp_AccountMaster_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Dgvw_Emp_AccountTran.DoubleClick
        Try

            With Dgvw_Emp_AccountTran
                If .CurrentRow Is Nothing Then Exit Sub
                Lbl_AccNo.Tag = .Item("Tran ID", .CurrentCell.RowIndex).Value.ToString.Trim
                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Cancel.Enabled = True
                Call Locate_Transaction_Details(Lbl_AccNo.Tag)
            End With

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Cancel.Click
        Try
            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If

            Emp_Acc_Tran_BL = New Employee_Account_Tran_BL_Cls

            'Validating Mandatory fields for Deleting
            If Tr_Mode = Tran_Mode.New_Mode Then
                MessageBox.Show("You have to locate details before deleting the record", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            If Txt_AccountNo.Text.Trim = "" Then
                MessageBox.Show("Invalid Account Number,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_AccountNo.Focus() : Exit Sub
            End If

            'Confirm before delete the record
            If MessageBox.Show("Are you sure wan't to Cancel the Transaction", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = Windows.Forms.DialogResult.No Then
                Exit Sub
            End If

            Emp_Acc_Tran_BL.Cancelled = "Y"
            Emp_Acc_Tran_BL.C_Time = Tran_Date
            Txt_Amount.Text = 0


            Call Btn_Save_Click(sender, e)

            Dim dtbl As DataTable = Nothing
            Emp_Acc_Reg_BL = New Emp_Account_Reg_BL_Cls
            Call Fill_GridTranGrid(Txt_AccountNo.Text)


        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_AccountNo_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_AccountNo.KeyDown
        If e.KeyCode = Keys.F2 Then Btn_Find_Click(sender, e)
    End Sub

    Private Sub Txt_Amount_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Amount.KeyPress
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Amount.Text, Data_Type.Double_Type, 12))
    End Sub

    Private Sub Btn_Ledger_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Ledger.Click
        Try
            Call Show_Reciept(Txt_AccountNo.Text.Trim)
        Catch ex As Exception

        End Try
    End Sub
    
    Private Sub Txt_Amount_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_Amount.TextChanged
        Try
            Txt_TransactionBal.Text = 0
            Lbl_Words.Text = Towords(Val(Txt_Amount.Text))
            Call Arrive_Transaction_Bal()
        Catch ex As Exception

        End Try
    End Sub
   
    
End Class
