﻿
Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls
Public Class Account_Head_Frm

#Region "Declarations"
    'Variable declaration/ object for Business Layer objects


    Private mTr_Mode As Tran_Mode
    Private Account_BL As Accounts_Master_BL_Cls

    Private hms_helper As HMS_Helper = Nothing


    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode2.Text = "NEW MODE"
                    Me.Lbl_Tran_Mode1.Text = "NEW MODE"
                    Me.Txt_GroupID.BackColor = Color.White
                    Me.Txt_HeadID.BackColor = Color.White
                    Me.Txt_GroupID.ReadOnly = False
                    Me.Txt_HeadID.ReadOnly = False
                    Me.Txt_GroupName.ReadOnly = False
                    Me.Txt_GroupName.BackColor = Color.White
                    Me.Txt_AccountHead.BackColor = Color.White
                    Me.Txt_AccountHead.ReadOnly = False
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode2.Text = "EDIT MODE"
                    Me.Lbl_Tran_Mode1.Text = "EDIT MODE"
                    Me.Txt_GroupID.BackColor = Color.Silver
                    Me.Txt_HeadID.BackColor = Color.Silver
                    Me.Txt_GroupID.ReadOnly = True
                    Me.Txt_HeadID.ReadOnly = True

            End Select
        End Set

    End Property


#End Region

#Region "Functions"

    Private Sub Clear_Form()
        Try

            If Tab_AccountHead.SelectedIndex = 0 Then
                Txt_GroupID.Text = ""
                Txt_GroupName.Text = ""
                Txt_Group_Order.Text = ""

                Tr_Mode = Tran_Mode.New_Mode
                Btn_Save.Enabled = True
                Btn_Delete.Enabled = False
                Txt_GroupName.Tag = ""
            Else
                Txt_AccountHead.Text = ""
                Txt_AccountHead.Tag = ""
                Txt_HeadOrder.Text = ""
                Txt_ShortName.Text = ""
                Txt_HeadID.Text = ""
                Txt_AccountHead.Tag = ""
                If Cmb_GroupName.Items.Count > 0 Then Cmb_GroupName.SelectedIndex = 0
                If Cmb_ALEI.Items.Count > 0 Then Cmb_ALEI.SelectedIndex = 0

                Tr_Mode = Tran_Mode.New_Mode
                Btn_Save.Enabled = True
                Btn_Delete1.Enabled = False
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try
    End Sub

    'function for validate fields 
    'return boolean
    Private Function Validate_Fields() As Boolean
        Try
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If

            If Tab_AccountHead.SelectedIndex = 0 Then

                If Tr_Mode <> Tran_Mode.New_Mode Then
                    If Txt_GroupID.Text.Trim = "" Then MessageBox.Show("Invalid Account Group ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_GroupID.Focus() : Return False
                End If
                'Assigning Default values
                'If Cmb_GroupName.SelectedIndex <= 0 Then MessageBox.Show("Invalid Account Group , Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_GroupName.Focus() : Return False : Exit Function
                If Txt_GroupName.Text.Trim = "" Then MessageBox.Show("Invalid Account Group Name, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_GroupName.Focus() : Return False
                If Txt_Group_Order.Text.Trim = "" Then MessageBox.Show("Invalid Account Group Order, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Group_Order.Focus() : Return False
                Return True

            Else
                If Tr_Mode <> Tran_Mode.New_Mode Then
                    If Txt_HeadID.Text.Trim = "" Then MessageBox.Show("Invalid Account Head ID, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_HeadID.Focus() : Return False
                End If
                'Assigning Default values
                If Cmb_GroupName.SelectedIndex <= 0 Then MessageBox.Show("Invalid Account Group, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_GroupName.Focus() : Return False
                If Txt_AccountHead.Text.Trim = "" Then MessageBox.Show("Invalid Account Head Name, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_AccountHead.Focus() : Return False
                If Txt_HeadOrder.Text.Trim = "" Then MessageBox.Show("Invalid Account Head Order, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_HeadOrder.Focus() : Return False
                If Txt_ShortName.Text.Trim = "" Then MessageBox.Show("Invalid Account Short Name, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_ShortName.Focus() : Return False
                If Cmb_ALEI.SelectedIndex = 0 Then MessageBox.Show("Invalid Account Type, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_ALEI.Focus() : Return False

                Return True
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try

    End Function

    'function for fill Group details into grid
    'return boolean
    Public Function Fill_GroupDetails() As Boolean
        Try

            'declaring variable for data reading
            Dim dtbl As DataTable = Nothing
            Dim dr As DataTableReader = Nothing

            'initialising BL Object
            Account_BL = New Accounts_Master_BL_Cls
            'resource name [accountheads|Get_Account_Group_All]
            If Account_BL.Get_AccountGroup(dtbl) Then
                Dgrd_History.DataSource = Nothing
                Dgrd_History.DataSource = dtbl
                SetGrid_Colwidth("10|400", Dgrd_History)

                With Dgrd_History
                    For i = 0 To .Columns.Count - 1
                        .Columns(i).Visible = False
                    Next

                    .Columns(0).Visible = True
                    .Columns(1).Visible = True
                End With


                Dgrd_History.Refresh()
                dr = Nothing
                dtbl = Nothing
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            Return False
        End Try
    End Function
    'Locating Group details
    'return Boolean
    Public Function Locate_Values_Group(ByVal Group_ID As String) As Boolean
        Try


            'dim variable declaration for data retrive
            Dim dr As DataTableReader = Nothing
            Dim dtbl As DataTable = Nothing

            'initialising BL Object
            Account_BL = New Accounts_Master_BL_Cls
            'resource name [accountheads|GetAccountGroupDetails]
            If Account_BL.Get_AccountGroupDetails(dtbl, Group_ID) Then
                dr = dtbl.CreateDataReader
                dr.Read()
                With dr
                    Txt_GroupID.Text = Group_ID
                    Txt_GroupName.Text = .Item("Group Name").ToString
                    Txt_Group_Order.Text = .Item("Group Order").ToString

                End With
                Return True
            Else
                MessageBox.Show("Invalid Group Id ... Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_GroupID.Focus()
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try

    End Function

    Public Function Locate_Values_Group_OtherBranch(ByVal Group_ID As String) As Boolean
        Try


            'dim variable declaration for data retrive
            Dim dr As DataTableReader = Nothing
            Dim dtbl As DataTable = Nothing

            'initialising BL Object
            Account_BL = New Accounts_Master_BL_Cls
            'resource name [accountheads|GetAccountGroupDetails]
            If Account_BL.Get_AccountGroupDetails_OtherBranch(dtbl, Group_ID) Then
                dr = dtbl.CreateDataReader
                dr.Read()
                With dr
                    Txt_GroupID.Text = Group_ID
                    Txt_GroupName.Text = .Item("Group Name").ToString
                    Txt_Group_Order.Text = .Item("Group Order").ToString

                    Txt_GroupID.ReadOnly = True
                    Txt_GroupID.BackColor = Color.Silver
                    Txt_GroupName.BackColor = Color.Silver
                    Txt_GroupName.ReadOnly = True


                End With
                Return True
            Else
                MessageBox.Show("Invalid Group Id ... Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_GroupID.Focus()
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try

    End Function

    'Location Account master Details
    'return boolean
    Public Function Locate_Values_AccountMaster(ByVal Head_ID As String) As Boolean
        Try


            'dim variable declaration for data retrive
            Dim dr As DataTableReader = Nothing
            Dim dtbl As DataTable = Nothing

            'initialising BL Object
            Account_BL = New Accounts_Master_BL_Cls

            If Account_BL.Get_AccountDetailsHeadWise(dtbl, Head_ID) Then
                dr = dtbl.CreateDataReader
                dr.Read()
                With dr
                    Txt_HeadID.Text = .Item("Acc Code").ToString
                    Txt_AccountHead.Text = .Item("Acc Name").ToString
                    Txt_ShortName.Text = .Item("Short Name").ToString
                    Cmb_GroupName.SelectedValue = .Item("Group ID")
                    Txt_HeadOrder.Text = .Item("Acc Order").ToString
                    If .Item("ALIE").ToString = "A" Then
                        Cmb_ALEI.SelectedIndex = 1
                    ElseIf .Item("ALIE").ToString = "L" Then
                        Cmb_ALEI.SelectedIndex = 2
                    ElseIf .Item("ALIE").ToString = "I" Then
                        Cmb_ALEI.SelectedIndex = 3
                    ElseIf .Item("ALIE").ToString = "E" Then
                        Cmb_ALEI.SelectedIndex = 4
                    ElseIf .Item("ALIE").ToString = "AL" Then
                        Cmb_ALEI.SelectedIndex = 5
                    ElseIf .Item("ALIE").ToString = "IE" Then
                        Cmb_ALEI.SelectedIndex = 6
                    End If

                End With
                Return True
            Else
                MessageBox.Show("Invalid Head ID... Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_HeadID.Focus()
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try

    End Function

    Public Function Locate_AccountMaster_OtherBranch(ByVal Head_ID As String) As Boolean
        Try


            'dim variable declaration for data retrive
            Dim dr As DataTableReader = Nothing
            Dim dtbl As DataTable = Nothing

            'initialising BL Object
            Account_BL = New Accounts_Master_BL_Cls

            If Account_BL.Get_AccountMaster_OtherBranch(dtbl, Head_ID) Then
                dr = dtbl.CreateDataReader
                dr.Read()
                With dr
                    Txt_HeadID.Text = .Item("Acc Code").ToString
                    Txt_AccountHead.Text = .Item("Acc Name").ToString
                    Txt_ShortName.Text = .Item("Short Name").ToString

                    If Isexistsinlist(Cmb_GroupName, .Item("Group Name").ToString) Then
                        Cmb_GroupName.SelectedValue = .Item("Group ID")
                    Else
                        Txt_HeadID.Text = ""
                        Txt_AccountHead.Text = ""
                        Txt_ShortName.Text = ""
                        Txt_AccountHead.Tag = ""
                        MessageBox.Show("In Accounts Group " & .Item("Group Name").ToString() & " Account Not Found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Txt_AccountHead.Focus()
                        Exit Function
                    End If
                    Txt_HeadOrder.Text = .Item("Acc Order").ToString
                    If .Item("ALIE").ToString = "A" Then
                        Cmb_ALEI.SelectedIndex = 1
                    ElseIf .Item("ALIE").ToString = "L" Then
                        Cmb_ALEI.SelectedIndex = 2
                    ElseIf .Item("ALIE").ToString = "I" Then
                        Cmb_ALEI.SelectedIndex = 3
                    ElseIf .Item("ALIE").ToString = "E" Then
                        Cmb_ALEI.SelectedIndex = 4
                    ElseIf .Item("ALIE").ToString = "AL" Then
                        Cmb_ALEI.SelectedIndex = 5
                    ElseIf .Item("ALIE").ToString = "IE" Then
                        Cmb_ALEI.SelectedIndex = 6
                    End If

                    Txt_HeadID.ReadOnly = True
                    Txt_AccountHead.ReadOnly = True
                    Txt_HeadID.BackColor = Color.Silver
                    Txt_AccountHead.BackColor = Color.Silver


                End With
                Return True
            Else
                MessageBox.Show("Invalid Head ID... Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_HeadID.Focus()
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try

    End Function

    ''function for fill account master details into grid
    'return boolean
    Public Function Fill_HeadDetails() As Boolean
        Try

            'declaring variable for data reading
            Dim dtbl As DataTable = Nothing
            Dim dr As DataTableReader = Nothing

            'initialising BL Object
            Account_BL = New Accounts_Master_BL_Cls

            If Account_BL.Get_AccountDetails(dtbl) Then
                Dgrd_History1.DataSource = Nothing
                Dgrd_History1.DataSource = dtbl
                SetGrid_Colwidth("10|300|150", Dgrd_History1)

                With Dgrd_History1
                    For i = 0 To .Columns.Count - 1
                        .Columns(i).Visible = False
                    Next

                    .Columns(0).Visible = True
                    .Columns(1).Visible = True
                    .Columns(2).Visible = True
                End With

                Dgrd_History1.Refresh()
                Return True
            Else
                Return False
            End If


            dr = Nothing
            dtbl = Nothing
        Catch ex As Exception
            Return False
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function

    Public Function SetGrid_Colwidth(ByVal Req_Colwidth As String, ByVal Dgrd As Object) As Boolean
        Try

            Dim Col_Width() As String
            Col_Width = Split(Req_Colwidth, "|")
            If Col_Width.Length > 0 Then
                Dim i_Ctr As Short = 0
                With Dgrd
                    For i_Ctr = 0 To Col_Width.Length - 1
                        If .Columns.Count >= i_Ctr And Col_Width(i_Ctr).ToString.Trim <> "" Then
                            .Columns(i_Ctr).MinimumWidth = CInt(Col_Width(i_Ctr).ToString.Trim)
                        End If
                    Next
                End With
            End If
            Return True
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function









#End Region

    Private Sub Account_Head_Frm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try


            REM Account Group Filling  
            Account_BL = New Accounts_Master_BL_Cls
            'resource [accountheads|GetAccountGroup]
            Account_BL.Fill_AccountGroup(Cmb_GroupName, "< Select >")

            'Account_BL.Fill_AccountGroup(Cmb_ALEI, "< Select >")

            REM filling values to grid
            'Call Fill_GroupDetails()
            'Call Fill_HeadDetails()

            'Populating account Type  Combo


            Cmb_ALEI.Items.Clear()
            With Cmb_ALEI
                .Items.Add("< Select >")
                .Items.Add("Asset")
                .Items.Add("Liability")
                .Items.Add("Income")
                .Items.Add("Expenditure")
                .Items.Add("AssetLiability")
                .Items.Add("IncomeExpenditure")
                .SelectedIndex = 0
            End With



            Txt_GroupName.Focus()
            Call Clear_Form()
            Call Fill_GroupDetails()
            Call SendKeyTab()
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try
    End Sub

    'Group
    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Try
            Me.Close()
        Catch ex As Exception

        End Try
    End Sub

    'Master
    Private Sub Btn_Close1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close1.Click
        Try
            Me.Close()
        Catch ex As Exception

        End Try
    End Sub

    'Group
    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try
            Call Clear_Form()
            Txt_GroupID.Focus()
        Catch ex As Exception

        End Try
    End Sub

    'Master
    Private Sub Btn_Clear1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear1.Click
        Try
            Call Clear_Form()
            Txt_HeadID.Focus()
        Catch ex As Exception

        End Try
    End Sub

    'Saving Account Group details
    Private Sub Btn_Save_Click(ByVal sendr As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try

            'Validating Data controls
            If Not Validate_Fields() Then Exit Sub
            ' declaration of variables for data reading 
            Dim dr As DataTableReader = Nothing
            Dim dtbl As DataTable = Nothing

            'Initialising  object for BL
            Account_BL = New Accounts_Master_BL_Cls

            'assigning values to propeties for saving
            Account_BL.Grp_ID = IIf(Tr_Mode <> Tran_Mode.New_Mode, Txt_GroupID.Text, 0)

            Account_BL.Grp_Name = Txt_GroupName.Text
            Account_BL.Grp_Order = Txt_Group_Order.Text

            'Save function from BL
            'resource:accountHeads|[Save_AccountGroup]
            If Account_BL.Save_AccountGroup(dtbl, Tr_Mode, Val(Txt_GroupID.Text)) Then
                MessageBox.Show("Account Group  Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Call AssignToControl(dtbl)
                Call Fill_GroupDetails()
                Btn_Clear.Focus()
            Else
                MessageBox.Show("Account Group Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)

        End Try

    End Sub

    'Saving Account head Details
    Private Sub Btn_Save1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save1.Click
        Try

            'Validating Data controls
            If Not Validate_Fields() Then Exit Sub
            ' declaration of variables for data reading 

            Dim dtbl As DataTable = Nothing

            'creating object for BL
            Account_BL = New Accounts_Master_BL_Cls

            'assigning values to propeties for saving
            Account_BL.GL_Code = Val(Txt_HeadID.Text)
            Account_BL.GL_Name = Txt_AccountHead.Text
            Account_BL.Acc_Shortname = Txt_ShortName.Text
            Account_BL.Grp_ID = Cmb_GroupName.SelectedValue
            Account_BL.Gl_Order = Txt_HeadOrder.Text


            If Cmb_ALEI.Text = "Asset" Then
                Account_BL.ALIE = "A"
            ElseIf Cmb_ALEI.Text = "Liability" Then
                Account_BL.ALIE = "L"
            ElseIf Cmb_ALEI.Text = "Income" Then
                Account_BL.ALIE = "I"
            ElseIf Cmb_ALEI.Text = "Expenditure" Then
                Account_BL.ALIE = "E"
            ElseIf Cmb_ALEI.Text = "AssetLiability" Then
                Account_BL.ALIE = "AL"
            ElseIf Cmb_ALEI.Text = "IncomeExpenditure" Then
                Account_BL.ALIE = "IE"
            End If



            'Save function from BL
            'resource [AccountHeads|Save_AccountHead]
            If Account_BL.Save_AccountHead(dtbl, Tr_Mode, Val(Txt_HeadID.Text)) Then
                MessageBox.Show("Account Head  Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)

                Call AssignToControl(dtbl)
                Call Fill_HeadDetails()
                Btn_Clear1.Focus()
            Else
                MessageBox.Show("Account Head Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Btn_Clear1.Focus()
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub AssignToControl(ByVal dtbl As DataTable)
        Try

            Dim dr As DataTableReader = Nothing
            REM Account Group 
            If Tab_AccountHead.SelectedIndex = 0 Then

                dr = dtbl.CreateDataReader()
                dr.Read()
                With dr
                    Txt_GroupID.Text = .Item("Grp_ID").ToString
                    Txt_GroupName.Text = .Item("Grp_Name").ToString
                    Txt_Group_Order.Text = .Item("Grp_Order").ToString
                End With

            Else
                REM Account heads
                dr = dtbl.CreateDataReader()
                dr.Read()
                With dr

                    Txt_HeadID.Text = .Item("Acc_Code").ToString
                    Txt_AccountHead.Text = .Item("Acc_Name").ToString
                    Txt_ShortName.Text = .Item("Acc_Shortname").ToString
                    Cmb_GroupName.SelectedValue = .Item("Grp_ID").ToString
                    Txt_HeadOrder.Text = .Item("Acc_Order").ToString

                    If .Item("ALIE").ToString = "A" Then
                        Cmb_ALEI.SelectedIndex = 1
                    ElseIf .Item("ALIE").ToString = "L" Then
                        Cmb_ALEI.SelectedIndex = 2
                    ElseIf .Item("ALIE").ToString = "I" Then
                        Cmb_ALEI.SelectedIndex = 3
                    ElseIf .Item("ALIE").ToString = "E" Then
                        Cmb_ALEI.SelectedIndex = 4
                    ElseIf .Item("ALIE").ToString = "AL" Then
                        Cmb_ALEI.SelectedIndex = 5
                    ElseIf .Item("ALIE").ToString = "IE" Then
                        Cmb_ALEI.SelectedIndex = 6
                    End If
                End With


            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    'Group
    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try

            'search engine
            If Txt_GroupID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "50|200|5|5|"
                Sql = "Select * From Account_Group_Vw where [Branch Code]=" & Branch_Code & ""
                Call ShowSearchengine(Txt_GroupID, Sql, 0, "[Group Name]", Colwidth, , 0)
            End If


            'Validating Mandatory fields for locating
            If Txt_GroupID.Text.Trim = "" Then
                'MessageBox.Show("Invalid Group ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_GroupID.Focus() : Exit Sub
            End If

            If Locate_Values_Group(Txt_GroupID.Text) Then
                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Delete.Enabled = True
                Txt_GroupID.Focus()
            Else
                MessageBox.Show("Group ID does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    'Master
    Private Sub Btn_Find1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find1.Click
        Try

            ' search engine
            If Txt_HeadID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "50|200|5|5|"
                Sql = "Select * From Accounts_Master_Vw where  [Branch Code] = " & Branch_Code & ""

                Call ShowSearchengine(Txt_HeadID, Sql, 0, "Acc Name", Colwidth, , 0)
            End If


            'Validating Mandatory fields for locating
            If Txt_HeadID.Text.Trim = "" Then
                ' MessageBox.Show("Invalid Head ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_HeadID.Focus() : Exit Sub
            End If

            If Locate_Values_AccountMaster(Txt_HeadID.Text) Then
                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Delete1.Enabled = True
                Cmb_GroupName.Focus()
            Else
                MessageBox.Show("Head ID does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    'delete account group
    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click
        Try

            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If

            If MessageBox.Show("Are You Sure Delete the Account Group ", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.No Then Exit Sub
            Account_BL = New Accounts_Master_BL_Cls
            If Account_BL.Delete_AccountGroup(Txt_GroupID.Text) Then
                MessageBox.Show("Account Group Deleted Successfully", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Call Fill_GroupDetails()
                Call Clear_Form()
            Else
                MessageBox.Show("You cannot delete this Account Group" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Btn_Clear.Focus()
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try
    End Sub

    'delete account master
    Private Sub Btn_Delete1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete1.Click
        Try

            If MessageBox.Show("Are You Sure Delete the Account Head ", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.No Then Exit Sub
            Account_BL = New Accounts_Master_BL_Cls
            If Account_BL.Delete_AccountHeads(Txt_HeadID.Text) Then
                MessageBox.Show("Account Head Deleted Successfully", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Call Fill_HeadDetails()
                Call Clear_Form()
            Else
                MessageBox.Show("You cannot delete this Account Head" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Btn_Clear1.Focus()

            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try
    End Sub

    Private Sub Txt_GroupName_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_GroupName.KeyUp
        Try

            If Txt_GroupName.Text.Trim = String.Empty Then Return
            If Tr_Mode <> Tran_Mode.New_Mode Then Return
            With Grid_Searchhelper1
                .Search_Query = "Select Distinct Grp_Name,Grp_ID "
                .Search_Query += " from Accounts_Group_Tbl "
                .Search_Query += " Where (Br_Code <> " & Branch_Code & ") and Grp_Name like"
                .Show_Result(Txt_GroupName, Txt_GroupID)
            End With

        Catch ex As Exception

        End Try
    End Sub



    'getting max group order
    Private Sub Txt_GroupName_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_GroupName.Validating
        'Getting Max account group order
        'return true or false
        Try
            If Txt_GroupName.Text.Trim = String.Empty Then Return

            hms_helper = New Hms_Helperimpliments
            If Tr_Mode = Tran_Mode.New_Mode Then
                If hms_helper.Check_Duplicatedataexists("Accounts_Group_Tbl", "Grp_Name", Data_Type.General_Type, Txt_GroupName.Text.Trim, Branch_Code) Then
                    MessageBox.Show("Account Group Already Exist,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_GroupName.Focus()
                    Txt_GroupName.Text = ""
                    Txt_GroupID.Text = ""
                    e.Cancel = True
                    Exit Sub
                End If

                If Txt_GroupName.Tag <> "" Then
                    Locate_Values_Group_OtherBranch(Txt_GroupName.Tag)
                    Exit Sub
                End If


            Else
                If hms_helper.Check_Duplicatedataexists("Accounts_Group_Tbl", "Grp_Name", Data_Type.General_Type, Txt_GroupName.Text.Trim, Branch_Code, , "Grp_ID", Data_Type.Integer_Type, Txt_GroupID.Text.Trim) Then
                    MessageBox.Show("Account Group Already Exist,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_GroupName.Focus()
                    Txt_GroupName.Text = ""
                    e.Cancel = True
                    Exit Sub
                End If
            End If

            If Txt_GroupName.Text <> "" And Tr_Mode = Tran_Mode.New_Mode Then


                'declaring data fetching variable
                Dim dtbl As DataTable = Nothing
                Dim dr As DataTableReader
                'initialising BL Object
                Account_BL = New Accounts_Master_BL_Cls
                If Account_BL.Get_MaxAccountGrporder(dtbl) Then
                    dr = dtbl.CreateDataReader()
                    dr.Read()
                    Txt_Group_Order.Text = dr.Item("Grp_Order").ToString
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, Product_Name)
        End Try
    End Sub

    Private Sub Txt_AccountHead_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_AccountHead.KeyUp
        Try
            If Txt_AccountHead.Text.Trim = String.Empty Then Return
            If Tr_Mode <> Tran_Mode.New_Mode Then Return
            With Grid_Searchhelper2
                .Search_Query = "Select Distinct Acc_Name,Acc_Code"
                .Search_Query += " From Accounts_Master_Tbl"
                .Search_Query += " Where (Br_Code <> " & Branch_Code & " ) and Acc_Name like"
                .Show_Result(Txt_AccountHead, Txt_HeadID)
            End With
        Catch ex As Exception

        End Try

    End Sub

    'getting max Head order
    Private Sub Txt_AccountHead_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_AccountHead.Validating
        Try
            'Getting Max account head order
            'return true or false
            If Txt_AccountHead.Text.Trim = String.Empty Then Return
            hms_helper = New Hms_Helperimpliments
            If Tr_Mode = Tran_Mode.New_Mode Then
                REM duplicate name checking in new mode
                If hms_helper.Check_Duplicatedataexists("Accounts_Master_Tbl", "Acc_Name", Data_Type.General_Type, Txt_AccountHead.Text.Trim, Branch_Code) Then
                    MessageBox.Show("Account Head Already Exist .", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_AccountHead.Focus()
                    Txt_AccountHead.Text = ""
                    Txt_HeadID.Text = ""
                    e.Cancel = True
                    Exit Sub
                End If

                If Txt_AccountHead.Tag <> "" Then
                    Locate_AccountMaster_OtherBranch(Txt_AccountHead.Tag)
                    Exit Sub
                End If

            Else
                REM duplicate name checking in edit mode

                If hms_helper.Check_Duplicatedataexists("Accounts_Master_Tbl", "Acc_Name", Data_Type.General_Type, Txt_AccountHead.Text.Trim, Branch_Code, , "Acc_Code", Data_Type.Integer_Type, Txt_HeadID.Text.Trim) Then
                    MessageBox.Show("Account Head Already Exist .", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information) : Txt_AccountHead.Focus()
                    Txt_AccountHead.Text = ""
                    e.Cancel = True
                End If
            End If

            If Txt_AccountHead.Text <> "" And Tr_Mode = Tran_Mode.New_Mode Then
                'declaring data fetching variable
                Dim dtbl As DataTable = Nothing
                Dim dr As DataTableReader
                'initialising BL Object
                Account_BL = New Accounts_Master_BL_Cls
                If Account_BL.Get_MaxAccountGLorder(dtbl) Then
                    dr = dtbl.CreateDataReader()
                    dr.Read()
                    Txt_HeadOrder.Text = dr.Item("Acc_Order").ToString
                End If
            End If
        Catch ex As Exception

        End Try


    End Sub

    Private Sub Account_Head_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        Try
            If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
        Catch ex As Exception

        End Try
    End Sub


    Private Sub Tab_AccountHead_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tab_AccountHead.SelectedIndexChanged
        Try

            Call Clear_Form()
            If Tab_AccountHead.SelectedIndex = 0 Then
                Txt_GroupID.Focus()
                Call Fill_GroupDetails()

            Else
                Account_BL = New Accounts_Master_BL_Cls
                Account_BL.Fill_AccountGroup(Cmb_GroupName, "< Select >")
                Txt_HeadID.Focus()
                Call Fill_HeadDetails()
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try
    End Sub

    Private Sub Txt_GroupID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_GroupID.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then Btn_Find_Click(sender, e)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_Group_Order_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Group_Order.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Group_Order.Text, Data_Type.Integer_Type, 5))
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_HeadOrder_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_HeadOrder.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_HeadOrder.Text, Data_Type.Integer_Type, 5))
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_GroupID_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_GroupID.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_GroupID.Text, Data_Type.Integer_Type, 5))
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_GroupID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_GroupID.TextChanged
        Try
            If Txt_GroupID.Text = "" Then
                Call Clear_Form()
            End If
        Catch ex As Exception

        End Try


    End Sub

    Private Sub Txt_HeadID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_HeadID.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then Btn_Find1_Click(sender, e)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_HeadID_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_HeadID.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_HeadID.Text, Data_Type.Integer_Type, 5))
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_HeadID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_HeadID.TextChanged
        Try
            If Txt_HeadID.Text = "" Then Call Clear_Form()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Account_Head_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then Call SendKeyTab()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgrd_History_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Dgrd_History.DoubleClick
        Try


            With Dgrd_History
                If .CurrentRow Is Nothing Then Exit Sub
                Txt_GroupID.Text = .Item(0, .CurrentCell.RowIndex).Value.ToString.Trim
                Call Btn_Find_Click(sender, e)
                Txt_GroupID.Focus()
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try
    End Sub

    Private Sub Dgrd_History1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Dgrd_History1.DoubleClick
        Try

            With Dgrd_History1
                If .CurrentRow Is Nothing Then Exit Sub
                Txt_HeadID.Text = .Item(0, .CurrentCell.RowIndex).Value.ToString.Trim
                Call Btn_Find1_Click(sender, e)
                Txt_HeadID.Focus()
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK)
        End Try
    End Sub

    Private Sub Btn_AccountGroup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_AccountGroup.Click
        Try

            Tab_AccountHead.SelectedIndex = 0
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_AccountMaster_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_AccountMaster.Click
        Try
            Tab_AccountHead.SelectedIndex = 1
        Catch ex As Exception

        End Try
    End Sub






    Private Sub Txt_GroupID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_GroupID.Validating
        If Txt_GroupID.Text.Trim <> "" And Txt_GroupID.Text.Trim <> Txt_GroupID.Tag Then
            If Locate_Values_Group(Txt_GroupID.Text.Trim) Then
                Btn_Delete.Enabled = True
                Tr_Mode = Tran_Mode.Edit_Mode
            Else
                'MessageBox.Show("Invalid Account Group-Id", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Btn_Delete.Enabled = False
                Tr_Mode = Tran_Mode.New_Mode
                e.Cancel = True
            End If
        End If
    End Sub


    Private Sub Txt_AccountHead_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_AccountHead.TextChanged

    End Sub

    Private Sub Tab_AccGrp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Txt_GroupName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_GroupName.TextChanged

    End Sub

    Private Sub Grid_Searchhelper2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Grid_Searchhelper2.Load

    End Sub
End Class