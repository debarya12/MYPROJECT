﻿

Option Explicit On
Imports HMS_Common.Common_Cls
Imports HMS_BL
Public Class Companyprofile_Frm

#Region "Declarations"
    'Object of Employee Details Bussiness Layer
    Private Comp_BL As Company_Profile_BL_Cls
    Private mTr_Mode As Tran_Mode

    Private hms_Helper As HMS_Helper

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_Comp_Name.BackColor = Color.White
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_Comp_Name.BackColor = Color.Silver
            End Select
        End Set
    End Property


#End Region

    Private Sub Close_Btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

    Private Sub Clear_Form()
        Try

            Txt_Comp_Name.Text = ""
            Txt_Comp_Add.Text = ""
            Txt_Comp_Phone1.Text = ""
            Txt_Comp_Phone2.Text = ""
            Txt_Comp_Email.Text = ""
            Txt_Fax.Text = ""
            Txt_Website.Text = ""

            Txt_Branchcode.Text = ""
            Txt_Branchcode.Tag = ""
            Txt_Branchname.Text = ""

            Tr_Mode = Tran_Mode.New_Mode


            Btn_Save.Enabled = True
            Btn_Delete.Enabled = False


        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Function Validate_Fields() As Boolean
        Try
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If

            If Not Validate_Transactionright(Tr_Mode, Me.Name) Then
                If Tr_Mode = Tran_Mode.New_Mode Then
                    MessageBox.Show("Save Permission Denied for this User" & vbCrLf & "Please Contact System Administrator ", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                ElseIf Tr_Mode = Tran_Mode.Edit_Mode Then
                    MessageBox.Show("Edit Permission Denied for this User" & vbCrLf & "Please Contact System Administrator ", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End If
            End If


            If Txt_Comp_Name.Text.Trim = "" Then MessageBox.Show("Invalid Company Name,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Comp_Name.Focus() : Exit Function
            If Txt_Comp_Add.Text.Trim = "" Then MessageBox.Show("Invalid Company Address,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Comp_Add.Focus() : Exit Function

            If Txt_Comp_Email.Text.Trim = "" Then
                Txt_Comp_Email.Text = "-"
            Else
                If Not Email_Validation(Txt_Comp_Email.Text.Trim, True) Then Txt_Comp_Email.Focus() : Exit Function
            End If

            If Txt_Branchcode.Text.Trim = "" Then MessageBox.Show("Invalid Branch Code,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Branchcode.Focus() : Exit Function

            'Assigning Default values


            Return True

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try

    End Function

    Private Function Locate_Values() As Boolean

        Try

            'Initialising BL Object
            Comp_BL = New Company_Profile_BL_Cls
            Dtbl = Nothing
            Call Clear_Form()

            'Retreiving Company Details and Assign the values to respective controls
            If Comp_BL.Get_Companyprofile(Dtbl) Then
                Dr = Dtbl.CreateDataReader()
                Dr.Read()
                With Dr
                    Txt_Comp_Name.Text = .Item("Company_Name")
                    Txt_Comp_Add.Text = .Item("Company_Address")
                    Txt_Comp_Phone1.Text = .Item("Ph_num1")
                    Txt_Comp_Phone2.Text = .Item("Ph_num2")
                    Txt_Comp_Email.Text = .Item("Company_Email")
                    Txt_Fax.Text = .Item("Company_Fax")
                    Txt_Website.Text = .Item("Company_Website")

                    Txt_Branchcode.Text = .Item("Br_Code")
                    Txt_Branchcode.Tag = .Item("Br_Code")
                    Txt_Branchname.Text = .Item("Br_Name")
                End With
                Return True
            Else
                Return False
            End If



        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        Finally
            Dr = Nothing
            Dtbl = Nothing
            Comp_BL = Nothing
        End Try

    End Function

    Private Function Locate_Branchdetails(ByVal Br_Code As Integer) As Boolean

        Try

            'Initialising BL Object
            Comp_BL = New Company_Profile_BL_Cls
            Dtbl = Nothing
            Txt_Branchname.Text = ""

            Txt_Branchcode.Text = Br_Code

            'Retreiving Branch Details and Assign the values to respective controls
            If Comp_BL.Get_Branchprofile(Dtbl, Br_Code) Then
                Dr = Dtbl.CreateDataReader()
                Dr.Read()
                With Dr
                    Txt_Branchcode.Text = Br_Code
                    Txt_Branchcode.Tag = Br_Code
                    Txt_Branchname.Text = .Item("Branch name")
                End With
                Return True
            Else
                Return False
            End If



        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        Finally
            Dr = Nothing
            Dtbl = Nothing
            Comp_BL = Nothing
        End Try

    End Function

    Private Sub Companyprofile_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then Btn_Find_Click(sender, e)
            If e.KeyCode = Keys.Enter Then Call SendKeyTab()
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Clear_Btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try
            Call Clear_Form()
            Txt_Branchcode.Focus()
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub Save_Btn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try
            'Initialising BL Object
            Comp_BL = New Company_Profile_BL_Cls

            'Validating Data controls
            If Not Validate_Fields() Then Exit Sub

            'Assigning Values to BL Properties
            With Comp_BL

                .Company_Name = Txt_Comp_Name.Text.Trim
                .Company_Address = Txt_Comp_Add.Text.Trim
                .Company_Phone1 = Txt_Comp_Phone1.Text.Trim
                .Company_Phone2 = Txt_Comp_Phone2.Text.Trim
                .Company_Email = Txt_Comp_Email.Text.Trim
                .Company_Fax = Txt_Fax.Text.Trim
                .Company_Website = Txt_Website.Text.Trim
                .CompBr_Code = Val(Txt_Branchcode.Text)


            End With
            Dtbl = Nothing

            'Saving Company Details using BL method

            If Comp_BL.Save_Companyprofile(Dtbl) Then
                If Dtbl.Rows(0).Item(0).ToString <> "E" Then
                    MessageBox.Show("Company Profile Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Call Clear_Form()
                    Call Locate_Values()
                    Btn_Clear.Focus()
                Else
                    MessageBox.Show("Company Profile not Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            Else
                MessageBox.Show("Company Profile not Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try
            If Txt_Branchcode.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "200|200|50|"
                Sql = "SELECT [Branch name], Address, Country, Phone1, Phone2, Fax, Email,Br_Code FROM Branch_Master_Vw "
                Call ShowSearchengine(Txt_Branchcode, Sql, 7, "Branch name", Colwidth, , 0)
            End If



            'Validating Mandatory fields for locating
            If Txt_Branchcode.Text.Trim = "" Then
                'MessageBox.Show("Invalid Employee ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_Branchcode.Focus() : Exit Sub
            End If

            If Not Locate_Branchdetails(Txt_Branchcode.Text.Trim) Then
                MessageBox.Show("Branch Code does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

            Txt_Branchcode.Focus()

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_Branchcode_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Txt_Branchcode.TextChanged
        If Txt_Branchcode.Text.Trim = "" Then
            Txt_Branchcode.Tag = ""
            Txt_Branchname.Text = ""
        End If
    End Sub

    Private Sub Txt_Branchcode_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_Branchcode.Validating
        Try
            If Me.Txt_Branchcode.Text.Trim <> "" And Me.Txt_Branchcode.Text <> Me.Txt_Branchcode.Tag Then
                If Locate_Branchdetails(Txt_Branchcode.Text.Trim) Then
                    Txt_Branchname.Focus()
                Else
                    MessageBox.Show("Branch Code does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Txt_Branchcode.Focus()
                    e.Cancel = True
                End If

            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_Comp_Phone1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Comp_Phone1.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Comp_Phone1.Text, Data_Type.Integer_Type, 12))
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub Txt_Comp_Phone2_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Comp_Phone2.KeyPress
        Try
            e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Comp_Phone2.Text, Data_Type.Integer_Type, 12))
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Companyprofile_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub Companyprofile_Frm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        hms_Helper = New Hms_Helperimpliments

        If Locate_Values() Then
            Tr_Mode = Tran_Mode.Edit_Mode
        Else
            Tr_Mode = Tran_Mode.New_Mode
        End If
    End Sub

    Private Sub Btn_New_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_New.Click
        With Branchdetails_Frm
            .MdiParent = Me.MdiParent
            .Req_Ctrl = Txt_Branchcode
            .Show()
            'Call Set_Parentform(Me, Emp_Details_Frm)
        End With
    End Sub

    Private Sub Txt_Comp_Add_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_Comp_Add.KeyDown
        If e.KeyCode = Keys.Enter Then Txt_Comp_Add.Select(Len(Txt_Comp_Add.Text), 0)
    End Sub

    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click

    End Sub
End Class