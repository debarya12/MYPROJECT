﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Patient_Transaction_Frm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Patient_Transaction_Frm))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Pnl_Header = New System.Windows.Forms.Panel
        Me.Label1 = New System.Windows.Forms.Label
        Me.Lst_Search = New System.Windows.Forms.ListBox
        Me.Txt_PatientID = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Txt_OutPatientID = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Txt_ExpID = New System.Windows.Forms.TextBox
        Me.Txt_ExpenseMaster = New System.Windows.Forms.TextBox
        Me.Tvw_ExpenseList = New System.Windows.Forms.TreeView
        Me.Btn_FindPatientID = New System.Windows.Forms.Button
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.Lbl_TotalAmount = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Lbl_Words = New System.Windows.Forms.Label
        Me.Pnl_Common_Btn = New System.Windows.Forms.Panel
        Me.Btn_Close = New System.Windows.Forms.Button
        Me.Btn_Clear = New System.Windows.Forms.Button
        Me.Btn_Cancel = New System.Windows.Forms.Button
        Me.Btn_Save = New System.Windows.Forms.Button
        Me.Btn_Add = New System.Windows.Forms.Button
        Me.Pnl_Tran_mode = New System.Windows.Forms.Panel
        Me.Lbl_Tran_Mode = New System.Windows.Forms.Label
        Me.Txt_Remarks = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Txt_BatchID = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Btn_Cleargrid = New System.Windows.Forms.Button
        Me.Pnl_Utility = New System.Windows.Forms.Panel
        Me.Btn_Showtran = New System.Windows.Forms.Button
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.Label7 = New System.Windows.Forms.Label
        Me.Lbl_Doctor = New System.Windows.Forms.Label
        Me.Pnl_History = New System.Windows.Forms.Panel
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Btn_CloseHistory = New System.Windows.Forms.Button
        Me.Btn_ShowHistory = New System.Windows.Forms.Button
        Me.Cmb_PayStatus = New System.Windows.Forms.ComboBox
        Me.Dtp_ToDate = New System.Windows.Forms.DateTimePicker
        Me.Dtp_FrmDate = New System.Windows.Forms.DateTimePicker
        Me.Txt_ExpenseDetails = New System.Windows.Forms.TextBox
        Me.Txt_Charge = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.Pnl_Details = New System.Windows.Forms.Panel
        Me.Pnl_CreditPosition = New System.Windows.Forms.Panel
        Me.Lbl_UnPaid_BillAmt = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Lbl_BalanceAmt = New System.Windows.Forms.Label
        Me.Lbl_Paid_BillAmt = New System.Windows.Forms.Label
        Me.Lbl_DepositAmt = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Pct_UPDown = New System.Windows.Forms.PictureBox
        Me.Txt_Trandate = New System.Windows.Forms.TextBox
        Me.Label18 = New System.Windows.Forms.Label
        Me.Btn_PMRFind = New System.Windows.Forms.Button
        Me.Txt_PMRID = New System.Windows.Forms.TextBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.Trancontrol1 = New Tran_Controls.Trancontrol
        Me.Dgv_PatientBill_Grid = New REAL_CLINIC.Hms_DGridview(Me.components)
        Me.ExpenseName = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Particulars = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Amounts = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Acc_Code = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Exp_Subtype = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Def_TranType = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Editable = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Expense_ID = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Patient_Info2 = New REAL_CLINIC.Patient_Info
        Me.Dgv_ChargesGrid = New REAL_CLINIC.Hms_DGridview(Me.components)
        Me.Expense = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Amount = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Exp_ID = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Pnl_Header.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Pnl_Common_Btn.SuspendLayout()
        Me.Pnl_Tran_mode.SuspendLayout()
        Me.Pnl_Utility.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Pnl_History.SuspendLayout()
        Me.Pnl_Details.SuspendLayout()
        Me.Pnl_CreditPosition.SuspendLayout()
        CType(Me.Pct_UPDown, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Dgv_PatientBill_Grid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Dgv_ChargesGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Pnl_Header
        '
        Me.Pnl_Header.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Header.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Menu_Bkg
        Me.Pnl_Header.Controls.Add(Me.Label1)
        Me.Pnl_Header.Dock = System.Windows.Forms.DockStyle.Top
        Me.Pnl_Header.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pnl_Header.Location = New System.Drawing.Point(0, 0)
        Me.Pnl_Header.Name = "Pnl_Header"
        Me.Pnl_Header.Size = New System.Drawing.Size(809, 24)
        Me.Pnl_Header.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(7, 1)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(234, 19)
        Me.Label1.TabIndex = 100000
        Me.Label1.Text = "P a t i e n t   T r a n s a c t i o n"
        '
        'Lst_Search
        '
        Me.Lst_Search.BackColor = System.Drawing.Color.White
        Me.Lst_Search.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Lst_Search.FormattingEnabled = True
        Me.Lst_Search.Location = New System.Drawing.Point(50, 25)
        Me.Lst_Search.Name = "Lst_Search"
        Me.Lst_Search.Size = New System.Drawing.Size(217, 106)
        Me.Lst_Search.TabIndex = 3
        Me.Lst_Search.Visible = False
        '
        'Txt_PatientID
        '
        Me.Txt_PatientID.BackColor = System.Drawing.Color.White
        Me.Txt_PatientID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_PatientID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PatientID.Location = New System.Drawing.Point(180, 73)
        Me.Txt_PatientID.MaxLength = 10
        Me.Txt_PatientID.Name = "Txt_PatientID"
        Me.Txt_PatientID.Size = New System.Drawing.Size(118, 21)
        Me.Txt_PatientID.TabIndex = 5
        Me.Txt_PatientID.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(118, 77)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(64, 13)
        Me.Label5.TabIndex = 211
        Me.Label5.Text = "Patient ID"
        '
        'Txt_OutPatientID
        '
        Me.Txt_OutPatientID.BackColor = System.Drawing.Color.White
        Me.Txt_OutPatientID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_OutPatientID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_OutPatientID.Location = New System.Drawing.Point(226, 76)
        Me.Txt_OutPatientID.MaxLength = 10
        Me.Txt_OutPatientID.Name = "Txt_OutPatientID"
        Me.Txt_OutPatientID.Size = New System.Drawing.Size(140, 21)
        Me.Txt_OutPatientID.TabIndex = 3
        Me.Txt_OutPatientID.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(186, 80)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 13)
        Me.Label2.TabIndex = 210
        Me.Label2.Text = "OP ID"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.Controls.Add(Me.Txt_ExpID)
        Me.Panel1.Controls.Add(Me.Txt_ExpenseMaster)
        Me.Panel1.Controls.Add(Me.Lst_Search)
        Me.Panel1.Controls.Add(Me.Tvw_ExpenseList)
        Me.Panel1.Location = New System.Drawing.Point(5, 201)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(270, 337)
        Me.Panel1.TabIndex = 2
        '
        'Txt_ExpID
        '
        Me.Txt_ExpID.BackColor = System.Drawing.Color.White
        Me.Txt_ExpID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_ExpID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_ExpID.Location = New System.Drawing.Point(1, 3)
        Me.Txt_ExpID.Name = "Txt_ExpID"
        Me.Txt_ExpID.Size = New System.Drawing.Size(47, 21)
        Me.Txt_ExpID.TabIndex = 1
        '
        'Txt_ExpenseMaster
        '
        Me.Txt_ExpenseMaster.BackColor = System.Drawing.Color.White
        Me.Txt_ExpenseMaster.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_ExpenseMaster.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_ExpenseMaster.Location = New System.Drawing.Point(50, 3)
        Me.Txt_ExpenseMaster.Name = "Txt_ExpenseMaster"
        Me.Txt_ExpenseMaster.Size = New System.Drawing.Size(219, 21)
        Me.Txt_ExpenseMaster.TabIndex = 2
        '
        'Tvw_ExpenseList
        '
        Me.Tvw_ExpenseList.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Tvw_ExpenseList.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Tvw_ExpenseList.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Tvw_ExpenseList.ItemHeight = 22
        Me.Tvw_ExpenseList.Location = New System.Drawing.Point(1, 25)
        Me.Tvw_ExpenseList.Name = "Tvw_ExpenseList"
        Me.Tvw_ExpenseList.Size = New System.Drawing.Size(268, 309)
        Me.Tvw_ExpenseList.TabIndex = 127
        '
        'Btn_FindPatientID
        '
        Me.Btn_FindPatientID.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_FindPatientID.BackgroundImage = CType(resources.GetObject("Btn_FindPatientID.BackgroundImage"), System.Drawing.Image)
        Me.Btn_FindPatientID.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_FindPatientID.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_FindPatientID.ForeColor = System.Drawing.Color.White
        Me.Btn_FindPatientID.Location = New System.Drawing.Point(321, 77)
        Me.Btn_FindPatientID.Name = "Btn_FindPatientID"
        Me.Btn_FindPatientID.Size = New System.Drawing.Size(29, 21)
        Me.Btn_FindPatientID.TabIndex = 6
        Me.Btn_FindPatientID.TabStop = False
        Me.Btn_FindPatientID.Text = "F2"
        Me.Btn_FindPatientID.UseVisualStyleBackColor = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Transparent
        Me.Panel2.Controls.Add(Me.Lbl_TotalAmount)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Location = New System.Drawing.Point(566, 441)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(235, 20)
        Me.Panel2.TabIndex = 216
        '
        'Lbl_TotalAmount
        '
        Me.Lbl_TotalAmount.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_TotalAmount.ForeColor = System.Drawing.Color.DarkBlue
        Me.Lbl_TotalAmount.Location = New System.Drawing.Point(85, 4)
        Me.Lbl_TotalAmount.Name = "Lbl_TotalAmount"
        Me.Lbl_TotalAmount.Size = New System.Drawing.Size(147, 13)
        Me.Lbl_TotalAmount.TabIndex = 212
        Me.Lbl_TotalAmount.Text = "00.00"
        Me.Lbl_TotalAmount.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.DarkBlue
        Me.Label3.Location = New System.Drawing.Point(3, 3)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(42, 13)
        Me.Label3.TabIndex = 211
        Me.Label3.Text = "Total :"
        '
        'Lbl_Words
        '
        Me.Lbl_Words.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Words.ForeColor = System.Drawing.Color.Maroon
        Me.Lbl_Words.Location = New System.Drawing.Point(274, 464)
        Me.Lbl_Words.Name = "Lbl_Words"
        Me.Lbl_Words.Size = New System.Drawing.Size(527, 17)
        Me.Lbl_Words.TabIndex = 217
        Me.Lbl_Words.Text = "Words"
        Me.Lbl_Words.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Pnl_Common_Btn
        '
        Me.Pnl_Common_Btn.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Pnl_Common_Btn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Close)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Clear)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Cancel)
        Me.Pnl_Common_Btn.Controls.Add(Me.Btn_Save)
        Me.Pnl_Common_Btn.ForeColor = System.Drawing.Color.White
        Me.Pnl_Common_Btn.Location = New System.Drawing.Point(461, 511)
        Me.Pnl_Common_Btn.Name = "Pnl_Common_Btn"
        Me.Pnl_Common_Btn.Size = New System.Drawing.Size(230, 35)
        Me.Pnl_Common_Btn.TabIndex = 13
        '
        'Btn_Close
        '
        Me.Btn_Close.BackgroundImage = CType(resources.GetObject("Btn_Close.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Close.CausesValidation = False
        Me.Btn_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Close.Location = New System.Drawing.Point(169, 3)
        Me.Btn_Close.Name = "Btn_Close"
        Me.Btn_Close.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Close.TabIndex = 4
        Me.Btn_Close.Text = "&Close"
        Me.Btn_Close.UseVisualStyleBackColor = True
        '
        'Btn_Clear
        '
        Me.Btn_Clear.BackgroundImage = CType(resources.GetObject("Btn_Clear.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Clear.CausesValidation = False
        Me.Btn_Clear.Location = New System.Drawing.Point(114, 3)
        Me.Btn_Clear.Name = "Btn_Clear"
        Me.Btn_Clear.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Clear.TabIndex = 3
        Me.Btn_Clear.Text = "C&lear"
        Me.Btn_Clear.UseVisualStyleBackColor = True
        '
        'Btn_Cancel
        '
        Me.Btn_Cancel.BackgroundImage = CType(resources.GetObject("Btn_Cancel.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Cancel.Location = New System.Drawing.Point(59, 3)
        Me.Btn_Cancel.Name = "Btn_Cancel"
        Me.Btn_Cancel.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Cancel.TabIndex = 2
        Me.Btn_Cancel.Text = "C&ancel"
        Me.Btn_Cancel.UseVisualStyleBackColor = True
        '
        'Btn_Save
        '
        Me.Btn_Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Save.BackgroundImage = CType(resources.GetObject("Btn_Save.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Save.ForeColor = System.Drawing.Color.White
        Me.Btn_Save.Location = New System.Drawing.Point(4, 3)
        Me.Btn_Save.Name = "Btn_Save"
        Me.Btn_Save.Size = New System.Drawing.Size(56, 28)
        Me.Btn_Save.TabIndex = 1
        Me.Btn_Save.Text = "&Save"
        Me.Btn_Save.UseVisualStyleBackColor = False
        '
        'Btn_Add
        '
        Me.Btn_Add.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Add.BackgroundImage = CType(resources.GetObject("Btn_Add.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Add.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Btn_Add.ForeColor = System.Drawing.Color.White
        Me.Btn_Add.Location = New System.Drawing.Point(692, 203)
        Me.Btn_Add.Name = "Btn_Add"
        Me.Btn_Add.Size = New System.Drawing.Size(53, 23)
        Me.Btn_Add.TabIndex = 10
        Me.Btn_Add.Text = "&Add"
        Me.Btn_Add.UseVisualStyleBackColor = False
        '
        'Pnl_Tran_mode
        '
        Me.Pnl_Tran_mode.BackColor = System.Drawing.Color.FromArgb(CType(CType(188, Byte), Integer), CType(CType(94, Byte), Integer), CType(CType(37, Byte), Integer))
        Me.Pnl_Tran_mode.BackgroundImage = CType(resources.GetObject("Pnl_Tran_mode.BackgroundImage"), System.Drawing.Image)
        Me.Pnl_Tran_mode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Tran_mode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Pnl_Tran_mode.Controls.Add(Me.Lbl_Tran_Mode)
        Me.Pnl_Tran_mode.ForeColor = System.Drawing.Color.White
        Me.Pnl_Tran_mode.Location = New System.Drawing.Point(667, 27)
        Me.Pnl_Tran_mode.Name = "Pnl_Tran_mode"
        Me.Pnl_Tran_mode.Size = New System.Drawing.Size(74, 22)
        Me.Pnl_Tran_mode.TabIndex = 10001
        '
        'Lbl_Tran_Mode
        '
        Me.Lbl_Tran_Mode.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Tran_Mode.Location = New System.Drawing.Point(3, 1)
        Me.Lbl_Tran_Mode.Name = "Lbl_Tran_Mode"
        Me.Lbl_Tran_Mode.Size = New System.Drawing.Size(67, 16)
        Me.Lbl_Tran_Mode.TabIndex = 122
        Me.Lbl_Tran_Mode.Text = "NEW MODE"
        Me.Lbl_Tran_Mode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Txt_Remarks
        '
        Me.Txt_Remarks.BackColor = System.Drawing.Color.White
        Me.Txt_Remarks.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Remarks.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Remarks.Location = New System.Drawing.Point(341, 484)
        Me.Txt_Remarks.MaxLength = 10
        Me.Txt_Remarks.Name = "Txt_Remarks"
        Me.Txt_Remarks.Size = New System.Drawing.Size(459, 21)
        Me.Txt_Remarks.TabIndex = 12
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(281, 486)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(48, 13)
        Me.Label4.TabIndex = 10003
        Me.Label4.Text = "Remarks"
        '
        'Txt_BatchID
        '
        Me.Txt_BatchID.BackColor = System.Drawing.Color.White
        Me.Txt_BatchID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_BatchID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_BatchID.Location = New System.Drawing.Point(62, 76)
        Me.Txt_BatchID.MaxLength = 10
        Me.Txt_BatchID.Name = "Txt_BatchID"
        Me.Txt_BatchID.Size = New System.Drawing.Size(128, 21)
        Me.Txt_BatchID.TabIndex = 1000000
        Me.Txt_BatchID.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(9, 76)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(55, 13)
        Me.Label6.TabIndex = 10006
        Me.Label6.Text = "Batch ID"
        '
        'Btn_Cleargrid
        '
        Me.Btn_Cleargrid.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Cleargrid.BackgroundImage = CType(resources.GetObject("Btn_Cleargrid.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Cleargrid.ForeColor = System.Drawing.Color.White
        Me.Btn_Cleargrid.Location = New System.Drawing.Point(744, 203)
        Me.Btn_Cleargrid.Name = "Btn_Cleargrid"
        Me.Btn_Cleargrid.Size = New System.Drawing.Size(53, 23)
        Me.Btn_Cleargrid.TabIndex = 11
        Me.Btn_Cleargrid.Text = "&Clear"
        Me.Btn_Cleargrid.UseVisualStyleBackColor = False
        '
        'Pnl_Utility
        '
        Me.Pnl_Utility.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Utility.Controls.Add(Me.Btn_Showtran)
        Me.Pnl_Utility.Location = New System.Drawing.Point(400, 131)
        Me.Pnl_Utility.Name = "Pnl_Utility"
        Me.Pnl_Utility.Size = New System.Drawing.Size(191, 44)
        Me.Pnl_Utility.TabIndex = 10009
        '
        'Btn_Showtran
        '
        Me.Btn_Showtran.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_Showtran.BackgroundImage = CType(resources.GetObject("Btn_Showtran.BackgroundImage"), System.Drawing.Image)
        Me.Btn_Showtran.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Showtran.ForeColor = System.Drawing.Color.White
        Me.Btn_Showtran.Location = New System.Drawing.Point(2, 11)
        Me.Btn_Showtran.Name = "Btn_Showtran"
        Me.Btn_Showtran.Size = New System.Drawing.Size(190, 23)
        Me.Btn_Showtran.TabIndex = 10010
        Me.Btn_Showtran.Text = "Show Transaction History"
        Me.Btn_Showtran.UseVisualStyleBackColor = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.Transparent
        Me.Panel3.Controls.Add(Me.Label7)
        Me.Panel3.Controls.Add(Me.Lbl_Doctor)
        Me.Panel3.Location = New System.Drawing.Point(400, 54)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(191, 77)
        Me.Panel3.TabIndex = 10010
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(-1, 2)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(205, 16)
        Me.Label7.TabIndex = 213
        Me.Label7.Text = "C o n s u l t i n g   D o c t o r "
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Lbl_Doctor
        '
        Me.Lbl_Doctor.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Doctor.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lbl_Doctor.ForeColor = System.Drawing.Color.White
        Me.Lbl_Doctor.Location = New System.Drawing.Point(3, 18)
        Me.Lbl_Doctor.Name = "Lbl_Doctor"
        Me.Lbl_Doctor.Size = New System.Drawing.Size(188, 56)
        Me.Lbl_Doctor.TabIndex = 216
        '
        'Pnl_History
        '
        Me.Pnl_History.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.MainMenu_Bkg
        Me.Pnl_History.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_History.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Pnl_History.Controls.Add(Me.Label11)
        Me.Pnl_History.Controls.Add(Me.Label10)
        Me.Pnl_History.Controls.Add(Me.Label9)
        Me.Pnl_History.Controls.Add(Me.Label8)
        Me.Pnl_History.Controls.Add(Me.Btn_CloseHistory)
        Me.Pnl_History.Controls.Add(Me.Btn_ShowHistory)
        Me.Pnl_History.Controls.Add(Me.Cmb_PayStatus)
        Me.Pnl_History.Controls.Add(Me.Dtp_ToDate)
        Me.Pnl_History.Controls.Add(Me.Dtp_FrmDate)
        Me.Pnl_History.Location = New System.Drawing.Point(317, 254)
        Me.Pnl_History.Name = "Pnl_History"
        Me.Pnl_History.Size = New System.Drawing.Size(355, 165)
        Me.Pnl_History.TabIndex = 10011
        Me.Pnl_History.Visible = False
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.Color.Blue
        Me.Label11.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(-2, 1)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(352, 21)
        Me.Label11.TabIndex = 100001
        Me.Label11.Text = "T r a n s a c t i o n   H i s t o r y"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(48, 83)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(44, 13)
        Me.Label10.TabIndex = 10012
        Me.Label10.Text = "Status"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(168, 35)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(21, 13)
        Me.Label9.TabIndex = 10011
        Me.Label9.Text = "To"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(48, 35)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(39, 13)
        Me.Label8.TabIndex = 10010
        Me.Label8.Text = "From "
        '
        'Btn_CloseHistory
        '
        Me.Btn_CloseHistory.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_CloseHistory.BackgroundImage = CType(resources.GetObject("Btn_CloseHistory.BackgroundImage"), System.Drawing.Image)
        Me.Btn_CloseHistory.ForeColor = System.Drawing.Color.White
        Me.Btn_CloseHistory.Location = New System.Drawing.Point(266, 96)
        Me.Btn_CloseHistory.Name = "Btn_CloseHistory"
        Me.Btn_CloseHistory.Size = New System.Drawing.Size(56, 23)
        Me.Btn_CloseHistory.TabIndex = 10009
        Me.Btn_CloseHistory.Text = "&Close"
        Me.Btn_CloseHistory.UseVisualStyleBackColor = False
        '
        'Btn_ShowHistory
        '
        Me.Btn_ShowHistory.BackColor = System.Drawing.Color.FromArgb(CType(CType(46, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(203, Byte), Integer))
        Me.Btn_ShowHistory.BackgroundImage = CType(resources.GetObject("Btn_ShowHistory.BackgroundImage"), System.Drawing.Image)
        Me.Btn_ShowHistory.ForeColor = System.Drawing.Color.White
        Me.Btn_ShowHistory.Location = New System.Drawing.Point(210, 96)
        Me.Btn_ShowHistory.Name = "Btn_ShowHistory"
        Me.Btn_ShowHistory.Size = New System.Drawing.Size(56, 23)
        Me.Btn_ShowHistory.TabIndex = 10008
        Me.Btn_ShowHistory.Text = "&Show"
        Me.Btn_ShowHistory.UseVisualStyleBackColor = False
        '
        'Cmb_PayStatus
        '
        Me.Cmb_PayStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.Cmb_PayStatus.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cmb_PayStatus.FormattingEnabled = True
        Me.Cmb_PayStatus.ItemHeight = 13
        Me.Cmb_PayStatus.Location = New System.Drawing.Point(51, 98)
        Me.Cmb_PayStatus.Name = "Cmb_PayStatus"
        Me.Cmb_PayStatus.Size = New System.Drawing.Size(155, 21)
        Me.Cmb_PayStatus.TabIndex = 15
        '
        'Dtp_ToDate
        '
        Me.Dtp_ToDate.Cursor = System.Windows.Forms.Cursors.Default
        Me.Dtp_ToDate.CustomFormat = "dd/MM/yyyy"
        Me.Dtp_ToDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_ToDate.Location = New System.Drawing.Point(171, 51)
        Me.Dtp_ToDate.Name = "Dtp_ToDate"
        Me.Dtp_ToDate.Size = New System.Drawing.Size(98, 21)
        Me.Dtp_ToDate.TabIndex = 14
        Me.Dtp_ToDate.TabStop = False
        '
        'Dtp_FrmDate
        '
        Me.Dtp_FrmDate.Cursor = System.Windows.Forms.Cursors.Default
        Me.Dtp_FrmDate.CustomFormat = "dd/MM/yyyy"
        Me.Dtp_FrmDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.Dtp_FrmDate.Location = New System.Drawing.Point(51, 51)
        Me.Dtp_FrmDate.Name = "Dtp_FrmDate"
        Me.Dtp_FrmDate.Size = New System.Drawing.Size(98, 21)
        Me.Dtp_FrmDate.TabIndex = 13
        Me.Dtp_FrmDate.TabStop = False
        '
        'Txt_ExpenseDetails
        '
        Me.Txt_ExpenseDetails.BackColor = System.Drawing.Color.White
        Me.Txt_ExpenseDetails.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_ExpenseDetails.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_ExpenseDetails.Location = New System.Drawing.Point(277, 203)
        Me.Txt_ExpenseDetails.Name = "Txt_ExpenseDetails"
        Me.Txt_ExpenseDetails.ReadOnly = True
        Me.Txt_ExpenseDetails.Size = New System.Drawing.Size(222, 21)
        Me.Txt_ExpenseDetails.TabIndex = 8
        '
        'Txt_Charge
        '
        Me.Txt_Charge.BackColor = System.Drawing.Color.White
        Me.Txt_Charge.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Charge.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Charge.Location = New System.Drawing.Point(505, 203)
        Me.Txt_Charge.Name = "Txt_Charge"
        Me.Txt_Charge.ReadOnly = True
        Me.Txt_Charge.Size = New System.Drawing.Size(186, 21)
        Me.Txt_Charge.TabIndex = 9
        Me.Txt_Charge.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label12.ForeColor = System.Drawing.Color.White
        Me.Label12.Location = New System.Drawing.Point(0, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(207, 21)
        Me.Label12.TabIndex = 10015
        Me.Label12.Text = "Credit Position"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Pnl_Details
        '
        Me.Pnl_Details.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_Details.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Pnl_Details.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_Details.Controls.Add(Me.Pnl_CreditPosition)
        Me.Pnl_Details.Controls.Add(Me.Pct_UPDown)
        Me.Pnl_Details.Controls.Add(Me.Label12)
        Me.Pnl_Details.Location = New System.Drawing.Point(594, 52)
        Me.Pnl_Details.Name = "Pnl_Details"
        Me.Pnl_Details.Size = New System.Drawing.Size(207, 20)
        Me.Pnl_Details.TabIndex = 10016
        '
        'Pnl_CreditPosition
        '
        Me.Pnl_CreditPosition.BackColor = System.Drawing.Color.Transparent
        Me.Pnl_CreditPosition.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.Pnl_CreditPosition.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Pnl_CreditPosition.Controls.Add(Me.Lbl_UnPaid_BillAmt)
        Me.Pnl_CreditPosition.Controls.Add(Me.Label17)
        Me.Pnl_CreditPosition.Controls.Add(Me.Label16)
        Me.Pnl_CreditPosition.Controls.Add(Me.Lbl_BalanceAmt)
        Me.Pnl_CreditPosition.Controls.Add(Me.Lbl_Paid_BillAmt)
        Me.Pnl_CreditPosition.Controls.Add(Me.Lbl_DepositAmt)
        Me.Pnl_CreditPosition.Controls.Add(Me.Label15)
        Me.Pnl_CreditPosition.Controls.Add(Me.Label14)
        Me.Pnl_CreditPosition.Controls.Add(Me.Label13)
        Me.Pnl_CreditPosition.Location = New System.Drawing.Point(6, 24)
        Me.Pnl_CreditPosition.Name = "Pnl_CreditPosition"
        Me.Pnl_CreditPosition.Size = New System.Drawing.Size(198, 88)
        Me.Pnl_CreditPosition.TabIndex = 10017
        '
        'Lbl_UnPaid_BillAmt
        '
        Me.Lbl_UnPaid_BillAmt.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_UnPaid_BillAmt.ForeColor = System.Drawing.Color.White
        Me.Lbl_UnPaid_BillAmt.Location = New System.Drawing.Point(110, 40)
        Me.Lbl_UnPaid_BillAmt.Name = "Lbl_UnPaid_BillAmt"
        Me.Lbl_UnPaid_BillAmt.Size = New System.Drawing.Size(81, 19)
        Me.Lbl_UnPaid_BillAmt.TabIndex = 10015
        Me.Lbl_UnPaid_BillAmt.Text = "Bill"
        Me.Lbl_UnPaid_BillAmt.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.ForeColor = System.Drawing.Color.White
        Me.Label17.Location = New System.Drawing.Point(1, 43)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(108, 16)
        Me.Label17.TabIndex = 10014
        Me.Label17.Text = "Unpaid Bills"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(-2, 48)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(245, 13)
        Me.Label16.TabIndex = 10013
        Me.Label16.Text = "__________________________________"
        '
        'Lbl_BalanceAmt
        '
        Me.Lbl_BalanceAmt.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_BalanceAmt.ForeColor = System.Drawing.Color.White
        Me.Lbl_BalanceAmt.Location = New System.Drawing.Point(91, 64)
        Me.Lbl_BalanceAmt.Name = "Lbl_BalanceAmt"
        Me.Lbl_BalanceAmt.Size = New System.Drawing.Size(100, 19)
        Me.Lbl_BalanceAmt.TabIndex = 10012
        Me.Lbl_BalanceAmt.Text = "Balance Amount"
        Me.Lbl_BalanceAmt.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Lbl_Paid_BillAmt
        '
        Me.Lbl_Paid_BillAmt.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_Paid_BillAmt.ForeColor = System.Drawing.Color.White
        Me.Lbl_Paid_BillAmt.Location = New System.Drawing.Point(94, 19)
        Me.Lbl_Paid_BillAmt.Name = "Lbl_Paid_BillAmt"
        Me.Lbl_Paid_BillAmt.Size = New System.Drawing.Size(97, 19)
        Me.Lbl_Paid_BillAmt.TabIndex = 10011
        Me.Lbl_Paid_BillAmt.Text = "Bill"
        Me.Lbl_Paid_BillAmt.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Lbl_DepositAmt
        '
        Me.Lbl_DepositAmt.BackColor = System.Drawing.Color.Transparent
        Me.Lbl_DepositAmt.ForeColor = System.Drawing.Color.White
        Me.Lbl_DepositAmt.Location = New System.Drawing.Point(96, -4)
        Me.Lbl_DepositAmt.Name = "Lbl_DepositAmt"
        Me.Lbl_DepositAmt.Size = New System.Drawing.Size(95, 19)
        Me.Lbl_DepositAmt.TabIndex = 10010
        Me.Lbl_DepositAmt.Text = "Deposits"
        Me.Lbl_DepositAmt.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.ForeColor = System.Drawing.Color.White
        Me.Label15.Location = New System.Drawing.Point(1, 67)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(51, 13)
        Me.Label15.TabIndex = 10009
        Me.Label15.Text = "Balance"
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.ForeColor = System.Drawing.Color.White
        Me.Label14.Location = New System.Drawing.Point(1, 22)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(108, 16)
        Me.Label14.TabIndex = 10008
        Me.Label14.Text = "Paid Bills"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.ForeColor = System.Drawing.Color.White
        Me.Label13.Location = New System.Drawing.Point(1, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(56, 13)
        Me.Label13.TabIndex = 10007
        Me.Label13.Text = "Deposits"
        '
        'Pct_UPDown
        '
        Me.Pct_UPDown.Image = CType(resources.GetObject("Pct_UPDown.Image"), System.Drawing.Image)
        Me.Pct_UPDown.Location = New System.Drawing.Point(183, 0)
        Me.Pct_UPDown.Name = "Pct_UPDown"
        Me.Pct_UPDown.Size = New System.Drawing.Size(24, 21)
        Me.Pct_UPDown.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Pct_UPDown.TabIndex = 10016
        Me.Pct_UPDown.TabStop = False
        '
        'Txt_Trandate
        '
        Me.Txt_Trandate.BackColor = System.Drawing.Color.White
        Me.Txt_Trandate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_Trandate.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_Trandate.Location = New System.Drawing.Point(116, 178)
        Me.Txt_Trandate.MaxLength = 10
        Me.Txt_Trandate.Name = "Txt_Trandate"
        Me.Txt_Trandate.Size = New System.Drawing.Size(104, 21)
        Me.Txt_Trandate.TabIndex = 100008
        Me.Txt_Trandate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.Transparent
        Me.Label18.ForeColor = System.Drawing.Color.White
        Me.Label18.Location = New System.Drawing.Point(3, 180)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(107, 13)
        Me.Label18.TabIndex = 100007
        Me.Label18.Text = "Transaction  Date"
        '
        'Btn_PMRFind
        '
        Me.Btn_PMRFind.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Btn_PMRFind.BackgroundImage = CType(resources.GetObject("Btn_PMRFind.BackgroundImage"), System.Drawing.Image)
        Me.Btn_PMRFind.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_PMRFind.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Btn_PMRFind.ForeColor = System.Drawing.Color.White
        Me.Btn_PMRFind.Location = New System.Drawing.Point(225, 32)
        Me.Btn_PMRFind.Name = "Btn_PMRFind"
        Me.Btn_PMRFind.Size = New System.Drawing.Size(28, 21)
        Me.Btn_PMRFind.TabIndex = 1
        Me.Btn_PMRFind.TabStop = False
        Me.Btn_PMRFind.Text = "F2"
        Me.Btn_PMRFind.UseVisualStyleBackColor = False
        '
        'Txt_PMRID
        '
        Me.Txt_PMRID.BackColor = System.Drawing.Color.White
        Me.Txt_PMRID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Txt_PMRID.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txt_PMRID.Location = New System.Drawing.Point(72, 32)
        Me.Txt_PMRID.MaxLength = 15
        Me.Txt_PMRID.Name = "Txt_PMRID"
        Me.Txt_PMRID.Size = New System.Drawing.Size(152, 21)
        Me.Txt_PMRID.TabIndex = 0
        Me.Txt_PMRID.Tag = ""
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.AliceBlue
        Me.Label19.Location = New System.Drawing.Point(8, 34)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(45, 14)
        Me.Label19.TabIndex = 100011
        Me.Label19.Text = "PMR-ID"
        '
        'Trancontrol1
        '
        Me.Trancontrol1.BackColor = System.Drawing.Color.FromArgb(CType(CType(57, Byte), Integer), CType(CType(123, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.Trancontrol1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Trancontrol1.Location = New System.Drawing.Point(604, 80)
        Me.Trancontrol1.Name = "Trancontrol1"
        Me.Trancontrol1.Padding = New System.Windows.Forms.Padding(3)
        Me.Trancontrol1.Size = New System.Drawing.Size(163, 69)
        Me.Trancontrol1.TabIndex = 123
        Me.Trancontrol1.Visible = False
        '
        'Dgv_PatientBill_Grid
        '
        Me.Dgv_PatientBill_Grid.AllowUserToAddRows = False
        Me.Dgv_PatientBill_Grid.AllowUserToDeleteRows = False
        Me.Dgv_PatientBill_Grid.AllowUserToResizeColumns = False
        Me.Dgv_PatientBill_Grid.AllowUserToResizeRows = False
        Me.Dgv_PatientBill_Grid.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(118, Byte), Integer), CType(CType(155, Byte), Integer), CType(CType(197, Byte), Integer))
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(87, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(162, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.AliceBlue
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgv_PatientBill_Grid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.Dgv_PatientBill_Grid.ColumnHeadersHeight = 25
        Me.Dgv_PatientBill_Grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.Dgv_PatientBill_Grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ExpenseName, Me.Particulars, Me.Amounts, Me.Acc_Code, Me.Exp_Subtype, Me.Def_TranType, Me.Editable, Me.Expense_ID})
        Me.Dgv_PatientBill_Grid.Location = New System.Drawing.Point(662, 155)
        Me.Dgv_PatientBill_Grid.Name = "Dgv_PatientBill_Grid"
        Me.Dgv_PatientBill_Grid.ReadOnly = True
        Me.Dgv_PatientBill_Grid.RowHeadersVisible = False
        Me.Dgv_PatientBill_Grid.Size = New System.Drawing.Size(76, 26)
        Me.Dgv_PatientBill_Grid.TabIndex = 10017
        Me.Dgv_PatientBill_Grid.TabStop = False
        Me.Dgv_PatientBill_Grid.Visible = False
        '
        'ExpenseName
        '
        Me.ExpenseName.HeaderText = "Expense"
        Me.ExpenseName.Name = "ExpenseName"
        Me.ExpenseName.ReadOnly = True
        Me.ExpenseName.Width = 215
        '
        'Particulars
        '
        Me.Particulars.HeaderText = "Particulars"
        Me.Particulars.Name = "Particulars"
        Me.Particulars.ReadOnly = True
        Me.Particulars.Width = 160
        '
        'Amounts
        '
        Me.Amounts.HeaderText = "Amount"
        Me.Amounts.Name = "Amounts"
        Me.Amounts.ReadOnly = True
        Me.Amounts.Width = 140
        '
        'Acc_Code
        '
        Me.Acc_Code.HeaderText = "Acc_Code"
        Me.Acc_Code.Name = "Acc_Code"
        Me.Acc_Code.ReadOnly = True
        Me.Acc_Code.Visible = False
        '
        'Exp_Subtype
        '
        Me.Exp_Subtype.HeaderText = "Exp_Subtype"
        Me.Exp_Subtype.Name = "Exp_Subtype"
        Me.Exp_Subtype.ReadOnly = True
        Me.Exp_Subtype.Visible = False
        '
        'Def_TranType
        '
        Me.Def_TranType.HeaderText = "Def_TranType"
        Me.Def_TranType.Name = "Def_TranType"
        Me.Def_TranType.ReadOnly = True
        Me.Def_TranType.Visible = False
        '
        'Editable
        '
        Me.Editable.HeaderText = "Editable"
        Me.Editable.Name = "Editable"
        Me.Editable.ReadOnly = True
        Me.Editable.Visible = False
        '
        'Expense_ID
        '
        Me.Expense_ID.HeaderText = "Exp_ID"
        Me.Expense_ID.Name = "Expense_ID"
        Me.Expense_ID.ReadOnly = True
        Me.Expense_ID.Visible = False
        '
        'Patient_Info2
        '
        Me.Patient_Info2.BackColor = System.Drawing.Color.AliceBlue
        Me.Patient_Info2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Patient_Info2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Patient_Info2.ForeColor = System.Drawing.Color.DarkBlue
        Me.Patient_Info2.Location = New System.Drawing.Point(3, 56)
        Me.Patient_Info2.Name = "Patient_Info2"
        Me.Patient_Info2.Padding = New System.Windows.Forms.Padding(2)
        Me.Patient_Info2.Size = New System.Drawing.Size(391, 118)
        Me.Patient_Info2.TabIndex = 212
        '
        'Dgv_ChargesGrid
        '
        Me.Dgv_ChargesGrid.AllowUserToAddRows = False
        Me.Dgv_ChargesGrid.AllowUserToDeleteRows = False
        Me.Dgv_ChargesGrid.AllowUserToResizeColumns = False
        Me.Dgv_ChargesGrid.AllowUserToResizeRows = False
        Me.Dgv_ChargesGrid.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(118, Byte), Integer), CType(CType(155, Byte), Integer), CType(CType(197, Byte), Integer))
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(CType(CType(87, Byte), Integer), CType(CType(129, Byte), Integer), CType(CType(162, Byte), Integer))
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.AliceBlue
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Dgv_ChargesGrid.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.Dgv_ChargesGrid.ColumnHeadersHeight = 25
        Me.Dgv_ChargesGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.Dgv_ChargesGrid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Expense, Me.Amount, Me.Exp_ID})
        Me.Dgv_ChargesGrid.Location = New System.Drawing.Point(277, 229)
        Me.Dgv_ChargesGrid.Name = "Dgv_ChargesGrid"
        Me.Dgv_ChargesGrid.ReadOnly = True
        Me.Dgv_ChargesGrid.RowHeadersVisible = False
        Me.Dgv_ChargesGrid.Size = New System.Drawing.Size(524, 206)
        Me.Dgv_ChargesGrid.TabIndex = 127
        Me.Dgv_ChargesGrid.TabStop = False
        '
        'Expense
        '
        Me.Expense.HeaderText = "Expense"
        Me.Expense.Name = "Expense"
        Me.Expense.ReadOnly = True
        Me.Expense.Width = 300
        '
        'Amount
        '
        Me.Amount.HeaderText = "Amount"
        Me.Amount.Name = "Amount"
        Me.Amount.ReadOnly = True
        Me.Amount.Width = 220
        '
        'Exp_ID
        '
        Me.Exp_ID.HeaderText = "Exp_ID"
        Me.Exp_ID.Name = "Exp_ID"
        Me.Exp_ID.ReadOnly = True
        Me.Exp_ID.Visible = False
        '
        'Patient_Transaction_Frm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.REAL_CLINIC.My.Resources.Resources.Button_Bkg
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.CancelButton = Me.Btn_Close
        Me.ClientSize = New System.Drawing.Size(809, 555)
        Me.Controls.Add(Me.Btn_PMRFind)
        Me.Controls.Add(Me.Txt_PMRID)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Pnl_History)
        Me.Controls.Add(Me.Txt_Trandate)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Dgv_PatientBill_Grid)
        Me.Controls.Add(Me.Pnl_Details)
        Me.Controls.Add(Me.Txt_Charge)
        Me.Controls.Add(Me.Txt_ExpenseDetails)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Pnl_Utility)
        Me.Controls.Add(Me.Btn_Cleargrid)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Txt_Remarks)
        Me.Controls.Add(Me.Pnl_Tran_mode)
        Me.Controls.Add(Me.Btn_Add)
        Me.Controls.Add(Me.Pnl_Common_Btn)
        Me.Controls.Add(Me.Lbl_Words)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Patient_Info2)
        Me.Controls.Add(Me.Txt_PatientID)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Txt_OutPatientID)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Dgv_ChargesGrid)
        Me.Controls.Add(Me.Trancontrol1)
        Me.Controls.Add(Me.Pnl_Header)
        Me.Controls.Add(Me.Txt_BatchID)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Btn_FindPatientID)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Patient_Transaction_Frm"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Pnl_Header.ResumeLayout(False)
        Me.Pnl_Header.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Pnl_Common_Btn.ResumeLayout(False)
        Me.Pnl_Tran_mode.ResumeLayout(False)
        Me.Pnl_Utility.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Pnl_History.ResumeLayout(False)
        Me.Pnl_History.PerformLayout()
        Me.Pnl_Details.ResumeLayout(False)
        Me.Pnl_CreditPosition.ResumeLayout(False)
        Me.Pnl_CreditPosition.PerformLayout()
        CType(Me.Pct_UPDown, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Dgv_PatientBill_Grid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Dgv_ChargesGrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Pnl_Header As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Lst_Search As System.Windows.Forms.ListBox
    Friend WithEvents Dgv_ChargesGrid As REAL_CLINIC.Hms_DGridview
    Friend WithEvents Trancontrol1 As Tran_Controls.Trancontrol
    Friend WithEvents Patient_Info2 As REAL_CLINIC.Patient_Info
    Friend WithEvents Txt_PatientID As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Txt_OutPatientID As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Txt_ExpenseMaster As System.Windows.Forms.TextBox
    Friend WithEvents Tvw_ExpenseList As System.Windows.Forms.TreeView
    Friend WithEvents Btn_FindPatientID As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Lbl_TotalAmount As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Words As System.Windows.Forms.Label
    Friend WithEvents Pnl_Common_Btn As System.Windows.Forms.Panel
    Friend WithEvents Btn_Close As System.Windows.Forms.Button
    Friend WithEvents Btn_Clear As System.Windows.Forms.Button
    Friend WithEvents Btn_Cancel As System.Windows.Forms.Button
    Friend WithEvents Btn_Save As System.Windows.Forms.Button
    Friend WithEvents Btn_Add As System.Windows.Forms.Button
    Friend WithEvents Pnl_Tran_mode As System.Windows.Forms.Panel
    Friend WithEvents Lbl_Tran_Mode As System.Windows.Forms.Label
    Friend WithEvents Txt_Remarks As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Txt_BatchID As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Btn_Cleargrid As System.Windows.Forms.Button
    Friend WithEvents Txt_ExpID As System.Windows.Forms.TextBox
    Friend WithEvents Pnl_Utility As System.Windows.Forms.Panel
    Friend WithEvents Btn_Showtran As System.Windows.Forms.Button
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Doctor As System.Windows.Forms.Label
    Friend WithEvents Pnl_History As System.Windows.Forms.Panel
    Friend WithEvents Dtp_ToDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Dtp_FrmDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Btn_CloseHistory As System.Windows.Forms.Button
    Friend WithEvents Btn_ShowHistory As System.Windows.Forms.Button
    Friend WithEvents Cmb_PayStatus As System.Windows.Forms.ComboBox
    Friend WithEvents Txt_ExpenseDetails As System.Windows.Forms.TextBox
    Friend WithEvents Txt_Charge As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Pnl_Details As System.Windows.Forms.Panel
    Friend WithEvents Pct_UPDown As System.Windows.Forms.PictureBox
    Friend WithEvents Pnl_CreditPosition As System.Windows.Forms.Panel
    Friend WithEvents Lbl_UnPaid_BillAmt As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Lbl_BalanceAmt As System.Windows.Forms.Label
    Friend WithEvents Lbl_Paid_BillAmt As System.Windows.Forms.Label
    Friend WithEvents Lbl_DepositAmt As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Expense As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Amount As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Exp_ID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Dgv_PatientBill_Grid As REAL_CLINIC.Hms_DGridview
    Friend WithEvents ExpenseName As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Particulars As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Amounts As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Acc_Code As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Exp_Subtype As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Def_TranType As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Editable As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Expense_ID As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Txt_Trandate As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Btn_PMRFind As System.Windows.Forms.Button
    Friend WithEvents Txt_PMRID As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
End Class
