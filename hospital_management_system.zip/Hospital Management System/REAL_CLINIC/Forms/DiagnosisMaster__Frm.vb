﻿'purushothaman
Imports HMS_BL
Imports HMS_Common.Common_Cls
Public Class DiagnosisMaster__Frm

#Region "Declarations"
    Private mTr_Mode As Tran_Mode
    'Private Com_BL As HMS_BL.HMS_Common_BL_Cls
    Private Diag_BL As DiagnosisMaster_BL_Cls
    Private hms_helper As HMS_Helper = Nothing

    Private DtBl As DataTable = Nothing
    Private Dr As DataTableReader

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Txt_Diagnosis_Id.BackColor = Color.White
                    Txt_Diagnosis_Id.ReadOnly = False
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Txt_Diagnosis_Id.BackColor = Color.Silver
                    Txt_Diagnosis_Id.ReadOnly = True
            End Select
        End Set
    End Property
#End Region

#Region "Methods"
    Private Sub Clear_Form()
        Try
            Txt_Diagnosis_Id.Text = ""
            Txt_Diagnosis_Name.Text = ""
            Diag_BL = New DiagnosisMaster_BL_Cls
            Diag_BL.Fill_Diagnosis(Cmb_Diagnosis_Lid, "    <   NOT APPLICABLE  >   ")
            Txt_Diagnosis_Id.Tag = ""
            Btn_Delete.Enabled = False
            Tr_Mode = Tran_Mode.New_Mode
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Function Validate_Fields() As Boolean
        Try
            If Tr_Mode <> Tran_Mode.New_Mode Then
                If Txt_Diagnosis_Id.Text.Trim = "" Then MessageBox.Show("Invalid Diagnosis ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Diagnosis_Id.Focus() : Exit Function
            End If
            If Txt_Diagnosis_Name.Text.Trim = "" Then MessageBox.Show("Invalid Diagnosis Name,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_Diagnosis_Name.Focus() : Exit Function
            If Txt_Diagnosis_Name.Text = Cmb_Diagnosis_Lid.Text Then MessageBox.Show("Parent Diagnosis and Diagnosis Name can't be same,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Cmb_Diagnosis_Lid.Focus() : Exit Function
            'If Cmb_Dep_Lid.Text.Trim 
            Return True
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function

    Private Function Assigntocontrols(ByVal D_Table As DataTable) As Boolean
        Try

            Dr = D_Table.CreateDataReader()
            Dr.Read()
            With Dr

                Txt_Diagnosis_Id.Text = .Item("Dig_ID")
                Txt_Diagnosis_Id.Tag = .Item("Dig_ID")
                Txt_Diagnosis_Name.Text = .Item("Diagnosis")
                Cmb_Diagnosis_Lid.SelectedValue = .Item("Dig_ParentID")

                Tr_Mode = Tran_Mode.Edit_Mode
            End With

            Return True
        Catch ex As Exception
            Return False
        Finally
            D_Table = Nothing
        End Try
    End Function

    Private Function Locate_Values(ByVal Dig_ID As Integer) As Boolean

        Dim Dr As DataTableReader
        Dim Dtbl As DataTable = Nothing

        Try

            'Initialising BL Object
            Diag_BL = New DiagnosisMaster_BL_Cls
            'Retreiving Trademaster and Assign the values to respective controls

            Dtbl = Nothing
            Call Clear_Form()
            Txt_Diagnosis_Id.Text = Dig_ID

            'Retreiving Diagnosis Details and Assign the values to respective controls
            If Diag_BL.Get_Diagnosisdetails(Dtbl, Dig_ID) Then
                Return Assigntocontrols(Dtbl)
            Else
                Return False
                Tr_Mode = Tran_Mode.New_Mode
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        Finally
            Dr = Nothing
            Dtbl = Nothing
            Diag_BL = Nothing
        End Try

    End Function

    Private Sub ShowIngrid()
        Try
            Dim StrQry As String
            Dim DtBl As DataTable = Nothing
            hms_helper = New Hms_Helperimpliments
            StrQry = "Select Dig_ID,Diagnosis,[Parent Diagnosis] From Diagnosis_Maste_Vw " '"Select Dep_Id,Dep_Name as [Department] from Get_DepartmentDetails_Vw"
            If hms_helper.Get_Data(StrQry, DtBl) Then
                With Dgrd_Diagnosis
                    .DataSource = Nothing
                    .DataSource = DtBl
                    .Refresh()
                    .Columns(1).MinimumWidth = 215
                    .Columns(2).MinimumWidth = 215
                End With
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

#End Region

    Private Sub DiagnosisMaster__KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub DiagnosisMaster__Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call Clear_Form()
        ShowIngrid()
    End Sub

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try
            If Not Validate_Fields() Then Exit Sub
            Diag_BL = New DiagnosisMaster_BL_Cls
            With Diag_BL
                .Dig_ID = IIf(Tr_Mode <> Tran_Mode.New_Mode, Txt_Diagnosis_Id.Text.Trim, 0)
                .Diagnosis = Txt_Diagnosis_Name.Text.Trim
                .Dig_ParentID = Cmb_Diagnosis_Lid.SelectedValue
                If .Save_DiagnosisMaster(DtBl, .Dig_ID, Tr_Mode) Then
                    MessageBox.Show("Diagnosis Details Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Call Clear_Form()
                    If Assigntocontrols(DtBl) Then
                        Tr_Mode = Tran_Mode.Edit_Mode
                        Btn_Delete.Enabled = True
                    End If
                    Call ShowIngrid()
                    Btn_Clear.Focus()
                    Exit Sub
                Else
                    MessageBox.Show("Diagnosis Details not Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If

            End With
            Btn_Clear.Focus()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Call Clear_Form()
        Txt_Diagnosis_Id.Focus()
    End Sub

    Private Sub DiagnosisMaster__KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then SendKeyTab()
        If e.KeyCode = Keys.F2 Then
            Call Btn_Find_Click(sender, e)
        End If
    End Sub

    Private Sub Txt_Diagnosis_Id_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_Diagnosis_Id.Validating
        Try
            If Me.Txt_Diagnosis_Id.Text.Trim <> "" And Txt_Diagnosis_Id.Text.Trim <> Txt_Diagnosis_Id.Tag Then
                If Locate_Values(Txt_Diagnosis_Id.Text.Trim) Then
                    Tr_Mode = Tran_Mode.Edit_Mode
                    Btn_Delete.Enabled = True
                Else
                    MessageBox.Show("Invalid Diagnosis ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Call Clear_Form()
                    e.Cancel = True

                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try
            'Validating Mandatory fields for locating
            If Txt_Diagnosis_Id.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "225|225|25"
                'Sql = "Select Dig_ID,Diagnosis,[Parent Diagnosis],Making_Time, Maker_ID, Checker_ID, Checking_Time, Br_Code,Authorised From Diagnosis_Maste_Vw "
                Sql = "Select Diagnosis,[Parent Diagnosis],Dig_ID From Diagnosis_Maste_Vw "
                'Call ShowSearchengine(Cmb_Dept_Name.SelectedValue, Sql, 1, "Doc_ID", Colwidth, , 0)
                Call ShowSearchengine(Txt_Diagnosis_Id, Sql, 2, "Diagnosis", Colwidth, , 0)
            End If

            If Txt_Diagnosis_Id.Text.Trim = "" Then
                Txt_Diagnosis_Id.Focus()
                Exit Sub
            End If
            If Locate_Values(Txt_Diagnosis_Id.Text.Trim) Then
                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Delete.Enabled = True
                Txt_Diagnosis_Id.Focus()
            Else
                MessageBox.Show("Diagnosis Details does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_Diagnosis_Name_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_Diagnosis_Name.Validating
        Try
            'Duplicate Checking" ============================================================================
            hms_helper = New Hms_Helperimpliments
            If Tr_Mode = Tran_Mode.New_Mode Then
                If hms_helper.Check_Duplicatedataexists("Diagnosis_Master_Tbl", "Diagnosis", Data_Type.General_Type, Txt_Diagnosis_Name.Text.Trim) Then
                    MessageBox.Show("Diagnosis Name already exists , Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    e.Cancel = True
                    Txt_Diagnosis_Name.Text = ""
                End If
            Else
                If hms_helper.Check_Duplicatedataexists("Diagnosis_Master_Tbl", "Diagnosis", Data_Type.General_Type, Txt_Diagnosis_Name.Text.Trim, , "Dig_ID", Data_Type.Integer_Type, Txt_Diagnosis_Id.Text.Trim) Then
                    MessageBox.Show("Diagnosis Name already exists , Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    e.Cancel = True
                    Txt_Diagnosis_Name.Text = ""
                End If
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Txt_Diagnosis_Id_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Txt_Diagnosis_Id.KeyPress
        e.KeyChar = Chr(Validate_KeyAscii(Asc(e.KeyChar), Txt_Diagnosis_Id.Text, Data_Type.Integer_Type, 12))
    End Sub
   
    Private Sub Dgrd_Diagnosis_DoubleClick1(ByVal sender As Object, ByVal e As System.EventArgs) Handles Dgrd_Diagnosis.DoubleClick
        Try
            With Dgrd_Diagnosis
                If .CurrentRow Is Nothing Then Exit Sub
                Txt_Diagnosis_Id.Text = .Item("Dig_ID", .CurrentCell.RowIndex).Value.ToString.Trim
                Call Btn_Find_Click(sender, e)
                Txt_Diagnosis_Id.Focus()
                Exit Sub
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click
        Try
            'Validating Mandatory fields for Deleting
            If Tr_Mode = Tran_Mode.New_Mode Then
                MessageBox.Show("You have to locate details before deleting the record", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_Diagnosis_Id.Focus()
            End If
            If MessageBox.Show("Are you sure want to delete the Diagnosis Details", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.No Then Exit Sub
            If Txt_Diagnosis_Id.Text.Trim = "" Then
                MessageBox.Show("Invalid Diagnosis ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                If Txt_Diagnosis_Id.Enabled = True Then Txt_Diagnosis_Id.Focus() : Exit Sub
            End If

            'Initialising BL Object
            Diag_BL = New HMS_BL.DiagnosisMaster_BL_Cls

            If Diag_BL.Delete_Diagnosis_Details(Txt_Diagnosis_Id.Text.Trim) Then
                MessageBox.Show("Diagnosis Details Deleted", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Call Btn_Clear_Click(sender, e)
                Call ShowIngrid()
            Else
                MessageBox.Show("You cannot delete this Diagnosis Details" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
            Call Clear_Form()
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            Diag_BL = Nothing
        End Try

    End Sub

End Class