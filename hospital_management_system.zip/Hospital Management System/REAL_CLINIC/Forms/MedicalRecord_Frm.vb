﻿

Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls

Public Class MedicalRecord_Frm

#Region " D e c l a r a t i o n s "

    Private hms_helper As HMS_Helper = Nothing
    Private MR_Bl As Patient_MedicalRecord_BL_Cls

#End Region

#Region " P r o p e r t i e s "
    'Transaction Mode checking Property
    Private mTr_Mode As Tran_Mode
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_PMRID.BackColor = Color.White
                    Me.Txt_PMRID.ReadOnly = False
                    Me.MRID = 0
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_PMRID.BackColor = Color.Silver
                    Me.Txt_PMRID.ReadOnly = True
            End Select
        End Set
    End Property

    Private mMRID As Long = 0
    Private Property MRID() As Long
        Get
            Return mMRID
        End Get
        Set(ByVal value As Long)
            mMRID = value
        End Set
    End Property

#End Region

#Region " M e t h o d s "

    Private Sub Clear_PMRinfo()
        Try
            Txt_DocID.Text = ""
            Txt_DocDetails.Text = ""
            Patient_Info1.Patient_ID = ""

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Clear_MedicalRecord()
        Try
            Me.Tr_Mode = Tran_Mode.New_Mode
            Me.MRID = 0
            Txt_Weight.Text = ""
            Txt_Temprature.Text = ""
            Txt_Height.Text = ""
            Txt_BPDiastolic.Text = ""
            Txt_BPSystolic.Text = ""
            Txt_Respiration.Text = ""
            Txt_Pulse.Text = ""
            Txt_Bloodclass.Text = ""
            Txt_Complaints.Text = ""
            Txt_Testconducted.Text = ""
            Txt_Results.Text = ""

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Clear_Grid()
        Try
            With Dgrd_Medicalrecord
                .DataSource = Nothing
                .Refresh()
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Clear_Form()
        Try

            Txt_PMRID.Text = ""
            Txt_PMRID.Tag = ""
            Me.MRID = 0

            Call Clear_PMRinfo()
            Call Clear_MedicalRecord()
            Call Clear_Grid()

            Btn_Cancel.Enabled = False
            Btn_Prescription.Enabled = False
            Btn_Diagnosis.Enabled = False
            Btn_Billdetails.Enabled = False
            Btn_PTransaction.Enabled = False
            Btn_Recomendations.Enabled = False

            Me.Tr_Mode = Tran_Mode.New_Mode

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Set_Grid()
        Try
            With Dgrd_Medicalrecord
                .Columns(0).MinimumWidth = 70
                .Columns(0).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                .Columns(1).MinimumWidth = 50
                .Columns(1).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                .Columns(2).MinimumWidth = 50
                .Columns(2).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                .Columns(3).MinimumWidth = 50
                .Columns(3).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                .Columns(4).MinimumWidth = 70
                .Columns(4).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                .Columns(5).MinimumWidth = 70
                .Columns(5).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                .Columns(6).MinimumWidth = 70
                .Columns(6).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                .Columns(7).MinimumWidth = 50
                .Columns(7).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                .Columns(8).MinimumWidth = 50
                .Columns(8).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                .Columns(9).MinimumWidth = 200
                .Columns(10).MinimumWidth = 200
                .Columns(11).MinimumWidth = 200
                For i_Ctr = 12 To .Columns.Count - 1
                    .Columns(i_Ctr).Visible = False
                Next
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Populate_Grid(ByVal PMR_ID As String, ByVal Br_Code As Integer)
        Try
            Dim MR_Dtbl As DataTable = Nothing

            MR_Bl = New Patient_MedicalRecord_BL_Cls
            If MR_Bl.Get_Medicalrecords(MR_Dtbl, PMR_ID, Br_Code) Then
                With Dgrd_Medicalrecord
                    .DataSource = Nothing
                    .DataSource = MR_Dtbl
                    Call Set_Grid()
                    .Refresh()
                End With
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Function Locate_PMR_info(ByVal PMR_ID As String, ByVal Br_Code As Integer) As Boolean
        Try

            '-----------------   Clear Medical Record   -----------------------------------

            Call Clear_Form()

            '----------------------------------------------------------------------------

            Dim Dtbl As DataTable = Nothing
            hms_helper = New Hms_Helperimpliments

            '-----------------  Locate Pateint Medical Record Master info   -------------
            If Not hms_helper.Get_PMR_Masterinfo(Dtbl, PMR_ID, Br_Code) Then Return False

            With Dtbl

                '------------  V a l i d a t i n g  PMR-ID -------------"

                If Not Validate_PMRID(Dtbl, True) Then Return False

                '-------------------------------------------------------"
                Txt_PMRID.Text = PMR_ID
                Txt_PMRID.Tag = PMR_ID
                Patient_Info1.Patient_ID = .Rows(0).Item("Patient ID").ToString
                Txt_DocID.Text = .Rows(0).Item("Doc_ID").ToString
                Txt_DocDetails.Text = .Rows(0).Item("DoctorDetails").ToString
            End With

            Call Populate_Grid(PMR_ID, Br_Code)

            Btn_Prescription.Enabled = True
            Btn_Diagnosis.Enabled = True
            Btn_Billdetails.Enabled = True
            Btn_PTransaction.Enabled = True
            Btn_Recomendations.Enabled = True

            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Save_MedicalRecord() As Boolean
        Try
            Dim Dtbl As DataTable = Nothing

            MR_Bl = New Patient_MedicalRecord_BL_Cls

            With MR_Bl
                .MR_ID = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, 0, Me.MRID)
                .ACC_ID = Txt_PMRID.Text.Trim
                .Tr_Date = Tran_Date
                .Br_Code = Branch_Code
                .Doc_ID = Txt_DocID.Text.Trim
                .P_Weight = Val(Txt_Weight.Text.Trim)
                .P_Weightin = IIf(Rbtn_W_K.Checked, "K", "P")
                .P_Temperature = Val(Txt_Temprature.Text.Trim)
                .P_Temperaturein = IIf(Rbtn_T_F.Checked, "F", "C")
                .P_Height = Val(Txt_Height.Text.Trim)
                .P_Heightin = IIf(Rbtn_H_Cm.Checked, "Cm", "Pt")
                .P_Respiration = Val(Txt_Respiration.Text.Trim)
                .P_Pulse = Val(Txt_Pulse.Text.Trim)
                .P_BP_Diastolic = Val(Txt_BPDiastolic.Text.Trim)
                .P_BP_Systolic = Val(Txt_BPSystolic.Text.Trim)
                .P_Bloodclass = Txt_Bloodclass.Text.Trim
                .P_Complaints = Txt_Complaints.Text.Trim
                .P_Testconducted = Txt_Testconducted.Text.Trim
                .P_Results = Txt_Results.Text.Trim

                If .Save_MedicalRecord(Dtbl, Me.Tr_Mode) Then
                    If Dtbl.Rows(0).Item(0).ToString <> "0" Then
                        MessageBox.Show("Patient Medical Record Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                        Return True
                    Else
                        MessageBox.Show("Error Occured While Saving Patient Medical Record,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                        Return False
                    End If
                Else
                    MessageBox.Show("Error Occured While Saving Patient Medical Record,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Return False
                End If
            End With



        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Validate_Fields() As Boolean
        Try

            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If


            Dim Result As Boolean = True

            If Val(Txt_Weight.Text.Trim) = 0 Then Result = False
            If Val(Txt_Temprature.Text.Trim) = 0 Then Result = False
            If Val(Txt_Height.Text.Trim) = 0 Then Result = False
            If Val(Txt_Respiration.Text.Trim) = 0 Then Result = False
            If Val(Txt_Pulse.Text.Trim) = 0 Then Result = False

            If Val(Txt_BPDiastolic.Text.Trim) = 0 Then Result = False
            If Val(Txt_BPSystolic.Text.Trim) = 0 Then Result = False
            If Txt_Bloodclass.Text.Trim = "" Then Result = False
            If Txt_Complaints.Text.Trim = "" Then Result = False
            If Txt_Testconducted.Text.Trim = "" Then Result = False
            If Txt_Results.Text.Trim = "" Then Result = False

            If Result = False Then
                MessageBox.Show("Invalid Medical Record Data, Please check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Txt_Weight.Focus()
                Return False
            End If

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Locate_MR(ByVal Rowno As Integer) As Boolean
        Try
            Call Clear_MedicalRecord()

            With Dgrd_Medicalrecord
                '----------------------------------------------------
                Me.MRID = .Rows(Rowno).Cells("MR_ID").Value
                '----------------------------------------------------

                Txt_Weight.Text = IIf(.Rows(Rowno).Cells("P_Weight").Value = 0, "", .Rows(Rowno).Cells("P_Weight").Value)
                Rbtn_W_K.Checked = IIf(.Rows(Rowno).Cells("P_Weightin").Value = "K", True, False)
                Txt_Temprature.Text = IIf(.Rows(Rowno).Cells("P_Temperature").Value = 0, "", .Rows(Rowno).Cells("P_Temperature").Value)
                Rbtn_T_F.Checked = IIf(.Rows(Rowno).Cells("P_Temperaturein").Value = "F", True, False)
                Txt_Height.Text = IIf(.Rows(Rowno).Cells("P_Height").Value = 0, "", .Rows(Rowno).Cells("P_Height").Value)
                Rbtn_H_Cm.Checked = IIf(.Rows(Rowno).Cells("P_Heightin").Value.ToUpper = "CM", True, False)

                Txt_BPDiastolic.Text = IIf(.Rows(Rowno).Cells("BP Diastolic").Value = 0, "", .Rows(Rowno).Cells("BP Diastolic").Value)
                Txt_BPSystolic.Text = IIf(.Rows(Rowno).Cells("BP Systolic").Value = 0, "", .Rows(Rowno).Cells("BP Systolic").Value)
                Txt_Respiration.Text = IIf(.Rows(Rowno).Cells("Respiration").Value = 0, "", .Rows(Rowno).Cells("Respiration").Value)
                Txt_Pulse.Text = IIf(.Rows(Rowno).Cells("Pulse").Value = 0, "", .Rows(Rowno).Cells("Pulse").Value)
                Txt_Bloodclass.Text = .Rows(Rowno).Cells("Bloodclass").Value
                Txt_Complaints.Text = .Rows(Rowno).Cells("Complaints").Value
                Txt_Testconducted.Text = .Rows(Rowno).Cells("Testconducted").Value
                Txt_Results.Text = .Rows(Rowno).Cells("Results").Value


                Btn_Cancel.Enabled = True

                Txt_Weight.Focus()

            End With


            Me.Tr_Mode = Tran_Mode.Edit_Mode

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

#End Region

    Public Sub Btn_PMRFind_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_PMRFind.Click
        Try
            If Txt_PMRID.Text.Trim = String.Empty Then
                Dim Sql As String
                Dim Colwidth As String = String.Empty
                Colwidth = "200|50|300|70|"

                Sql = " SELECT [Patient Name], [SS No], ([Family Name] + Address + City) AS Address, PMR_ID, OPD_ID, Patient_ID"
                Sql += " FROM Pateint_Accountsearch_Vw WHERE (Cancelled = 'N') AND (Authorised = 'Y')"

                Call ShowSearchengine(Txt_PMRID, Sql, 3, "[Patient Name]", Colwidth, , 0)
            End If

            'Validating Mandatory fields for locating
            If Txt_PMRID.Text.Trim = "" Then
                'MessageBox.Show("Invalid Appointment ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_PMRID.Focus() : Exit Sub
            End If

            If Locate_PMR_info(Txt_PMRID.Text.Trim, Branch_Code) Then
                Txt_DocID.Focus()
            Else
                MessageBox.Show("Invalid PMR ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_PMRID.Focus()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_PMRID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_PMRID.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then Btn_PMRFind_Click(Nothing, Nothing)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_PMRID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_PMRID.TextChanged
        Try
            If Txt_PMRID.Text.Trim = "" Then Call Clear_Form()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub MedicalRecord_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        Try

            If e.KeyCode = Keys.Enter Then
                Call SendKeyTab()
            ElseIf e.KeyCode = Keys.F4 Then
                If Btn_Diagnosis.Enabled Then Call Btn_Diagnosis_Click(Nothing, Nothing)
            ElseIf e.KeyCode = Keys.F5 Then
                If Btn_Prescription.Enabled Then Call Btn_Prescription_Click(Nothing, Nothing)
            ElseIf e.KeyCode = Keys.F6 Then
                If Btn_Recomendations.Enabled Then Call Btn_Recomendations_Click(Nothing, Nothing)
            ElseIf e.KeyCode = Keys.F7 Then
                If Btn_PTransaction.Enabled Then Call Btn_PTransaction_Click(Nothing, Nothing)
            ElseIf e.KeyCode = Keys.F8 Then
                If Btn_Billdetails.Enabled Then Call Btn_Billdetails_Click(Nothing, Nothing)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Private Sub MedicalRecord_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub MedicalRecord_Frm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            hms_helper = New Hms_Helperimpliments


            Txt_Height.Text = Strings.Format(100, "{0:f}")

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Save_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try

            If Not Validate_Fields() Then Return

            If Save_MedicalRecord() Then
                Call Populate_Grid(Txt_PMRID.Text.Trim, Branch_Code)
                Call Clear_MedicalRecord()
                Txt_PMRID.Focus()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try
            Call Clear_Form()
            Txt_PMRID.Focus()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Try
            Me.Close()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgrd_Medicalrecord_CellDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgrd_Medicalrecord.CellDoubleClick
        Try
            With Dgrd_Medicalrecord
                If e.RowIndex = -1 Then Exit Sub

                Call Locate_MR(e.RowIndex)

            End With


        Catch ex As Exception

        End Try
    End Sub

    Private Sub Dgrd_Medicalrecord_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Dgrd_Medicalrecord.KeyDown
        Try
            If Not e.KeyCode = Keys.Enter Then Exit Sub

            With Dgrd_Medicalrecord
                If .CurrentRow Is Nothing Then Exit Sub
                If .CurrentCell Is Nothing Then Exit Sub

                Call Locate_MR(.CurrentRow.Index)

            End With
            

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_DocID_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_DocID.KeyDown
        Try
            If e.KeyCode = Keys.F2 Then Call Btn_DocFind_Click(Nothing, Nothing)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_DocID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_DocID.TextChanged
        Try
            If Txt_DocID.Text.Trim = "" Then Txt_DocDetails.Text = ""
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_DocFind_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_DocFind.Click
        Try
            If Txt_DocID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "100|200|100|"
                Sql = "SELECT  Name, Address, Qualification, DoctorID,EmpID,SS_Number as [SS Number]  FROM    Doctormaster_Vw"
                Call ShowSearchengine(Txt_DocID, Sql, 3, "Name", Colwidth, , 0)
            End If

            If Txt_DocID.Text.Trim = "" Then
                Txt_DocID.Focus()
                Exit Sub
            End If

            Dim Dtbl As DataTable = Nothing

            If hms_helper.Get_Doctordetails(Dtbl, Txt_DocID.Text.Trim) Then
                Txt_DocDetails.Text = Dtbl.Rows(0).Item("Name").ToString + vbCrLf
                Txt_DocDetails.Text += Dtbl.Rows(0).Item("Qualification").ToString
            End If


        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Prescription_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Prescription.Click
        Try
            With Patient_Prescription_Frm
                .Txt_Acc_Id.Text = Txt_PMRID.Text.Trim
                .Cmb_Pres_Templates.Tag = "False"
                .Btn_FindAccID_Click(Nothing, Nothing)
                .Show()
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Diagnosis_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Diagnosis.Click
        Try
            With Patient_Diagnosis_Frm
                .Tag = Me.Tag
                .TXT_Acc_ID.Text = Txt_PMRID.Text.Trim
                .Btn_Find_Account_Click(Nothing, Nothing)
                .Show()
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Recomendations_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Recomendations.Click
        Try
            With Dr_Recomendations_Frm
                .Txt_PMRID.Text = Txt_PMRID.Text.Trim
                .Btn_Find_Click(Nothing, Nothing)
                .Show()
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_PTransaction_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_PTransaction.Click
        Try
            With Patient_Transaction_Frm
                .Txt_PMRID.Text = Txt_PMRID.Text.Trim
                .Btn_PMRFind_Click(sender, e)
                .Show()
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Billdetails_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Billdetails.Click
        Try
            With Patient_Transaction_Bill_Frm
                .Txt_OutPatientID.Text = Txt_PMRID.Text.Trim
                .Btn_Find_Click(Nothing, Nothing)
                .Show()
            End With
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Cancel.Click
        Try
            '------------------------------------------------------------------------------------------------------------------
            'Validating Mandatory fields for Deleting
            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If


            Dim Dtbl As DataTable = Nothing
            If Tr_Mode = Tran_Mode.New_Mode Then
                MessageBox.Show("You have to locate details before cancelling the record", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Dgrd_Medicalrecord.Focus() : Exit Sub
            End If
            If Me.MRID = 0 Then
                MessageBox.Show("Invalid Medical Record ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Dgrd_Medicalrecord.Focus() : Exit Sub
            End If
            '------------------------------------------------------------------------------------------------------------------

            MR_Bl = New Patient_MedicalRecord_BL_Cls
            If MessageBox.Show("Are you sure wan't to Cancel the selected Medical Record", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                If MR_Bl.Cancel_MedicalRecord(Dtbl, Me.MRID, Branch_Code) Then
                    MessageBox.Show("Medical Record Cancelled successfully", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Call Clear_MedicalRecord()
                Else
                    MessageBox.Show("You Cannot Cancell this Medical Record" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            End If
            '------------------------------------------------------------------------------------------------------------------

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_PMRID_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles Txt_PMRID.Validating
        Try
            If Me.Txt_PMRID.Text.Trim <> String.Empty And Me.Txt_PMRID.Text <> Me.Txt_PMRID.Tag Then
                If Locate_PMR_info(Txt_PMRID.Text.Trim, Branch_Code) Then
                    Txt_DocID.Focus()
                Else
                    MessageBox.Show("Invalid PMR ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Txt_PMRID.Focus()
                    e.Cancel = True
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub
End Class