﻿
Option Explicit On
Imports HMS_BL
Imports HMS_Common.Common_Cls

Public Class Bank_Master_Reg_Frm

#Region "Declarations"
    'Object of Employee Details Bussiness Layer

    Private hms_helper As HMS_Helper = Nothing
    Private Bank_Master_BL As Bank_Master_BL_Cls
    Private mTr_Mode As Tran_Mode

    Dim Dr As DataTableReader
    Dim Dtbl As DataTable = Nothing
    Private IsHandleAdded As Boolean

    Private CellRowindex As Integer
    Private CellColindex As Integer

    Private ValueExist As Boolean

    Private GrDtbl As DataTable

    'Transaction Mode checking Property
    Private Property Tr_Mode() As Tran_Mode
        Get
            Return mTr_Mode
        End Get
        Set(ByVal value As Tran_Mode)
            mTr_Mode = value
            Select Case mTr_Mode
                Case Tran_Mode.New_Mode
                    Me.Lbl_Tran_Mode.Text = "NEW MODE"
                    Me.Txt_BankID.BackColor = Color.White
                    Me.Txt_BankID.ReadOnly = False
                    Me.Txt_BankName.BackColor = Color.White
                    Me.Txt_BankName.ReadOnly = False
                    Me.Txt_BranchName.ReadOnly = False
                Case Tran_Mode.Edit_Mode
                    Me.Lbl_Tran_Mode.Text = "EDIT MODE"
                    Me.Txt_BankID.BackColor = Color.Silver
                    Me.Txt_BankID.ReadOnly = True
                    Me.Txt_BankName.BackColor = Color.Silver
                    Me.Txt_BankName.ReadOnly = True
                    Me.Txt_BranchName.ReadOnly = True
            End Select
        End Set
    End Property

#End Region

#Region "Methods"

    Public Sub Populate_GridView()
        Try

            Dim Dtbl As DataTable
            Dtbl = Nothing
            Bank_Master_BL = New Bank_Master_BL_Cls
            If Bank_Master_BL.Get_Bank_Master_details(Dtbl) Then
                Dgvw_Bank_Account_Master.DataSource = Dtbl
                Dgvw_Bank_Account_Master.Refresh()
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Clear_Form()
        Try
            Txt_BankID.Text = ""
            Txt_BankName.Text = ""
            Txt_BranchName.Text = ""
            Txt_BankAddress.Text = ""
            Txt_SwiftCode.Text = ""
            Txt_PhoneI.Text = ""
            Txt_PhoneII.Text = ""
            Txt_BankName.Tag = ""
            Txt_ShortName.Text = ""

            Tr_Mode = Tran_Mode.New_Mode
            Btn_Save.Enabled = True
            Btn_Delete.Enabled = False
        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Function Locate_Values() As Boolean
        Try

            Dim dtbl As DataTable = Nothing
            Bank_Master_BL = New Bank_Master_BL_Cls

            If Bank_Master_BL.Get_Bank_Master(dtbl, Txt_BankID.Text.Trim) Then
                Txt_BankName.Text = dtbl.Rows(0).Item("Bank_Name").ToString
                Txt_BranchName.Text = dtbl.Rows(0).Item("Branch_Name").ToString
                Txt_BankAddress.Text = dtbl.Rows(0).Item("Address").ToString
                Txt_SwiftCode.Text = dtbl.Rows(0).Item("Swift_Code").ToString
                Txt_PhoneI.Text = dtbl.Rows(0).Item("Phone1").ToString
                Txt_PhoneII.Text = dtbl.Rows(0).Item("Phone2").ToString
                Txt_BankName.Tag = dtbl.Rows(0).Item("Bank_Code").ToString
                Txt_ShortName.Text = dtbl.Rows(0).Item("Short_Name").ToString
            End If

            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Validate_Fields() As Boolean
        Try
            Dim Accesstype As Access_Type = IIf(Me.Tr_Mode = Tran_Mode.New_Mode, Access_Type.Add, IIf(Me.Tr_Mode = Tran_Mode.Edit_Mode, Access_Type.Edit, Access_Type.Delete))
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return False
            End If

            If Tr_Mode <> Tran_Mode.New_Mode Then
                If Txt_BankID.Text.Trim = "" Then MessageBox.Show("Invalid Employee Account Number,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_BankID.Focus() : Return False
            End If
            'Assigning Default values
            If Txt_BankName.Text.Trim = "" Then MessageBox.Show("Invalid Bank Name, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_BankName.Focus() : Return False
            If Txt_ShortName.Text.Trim = "" Then MessageBox.Show("Invalid Short Name, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_ShortName.Focus() : Return False
            If Txt_BranchName.Text.Trim = "" Then MessageBox.Show("Invalid Branch Name, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_BranchName.Focus() : Return False
            If Txt_BankAddress.Text.Trim = "" Then MessageBox.Show("Invalid Bank Address, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_BankAddress.Focus() : Return False
            If Txt_SwiftCode.Text.Trim = "" Then MessageBox.Show("Invalid Bank Code, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_SwiftCode.Focus() : Return False
            If Txt_PhoneI.Text.Trim = "" Then MessageBox.Show("Invalid Bank Phone Number, Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation) : Txt_PhoneI.Focus() : Return False
            Return True

        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function Populate_ParticularsGrid(ByVal dtbl As DataTable) As Boolean
        Try

            With Dgw_BankName_History
                .DataSource = dtbl
                .Columns(0).Width = 150
                .Columns(1).Visible = False
                .Columns(2).Visible = False
                .Refresh()
                .Visible = True
            End With
            dtbl = Nothing
        Catch ex As Exception

        End Try
    End Function

    Private Sub Get_bankName()
        Try

            With Dgw_BankName_History
                Txt_BankName.Text = .CurrentRow.Cells(0).Value.ToString.Trim
                Txt_BankName.Tag = .CurrentRow.Cells(1).Value.ToString.Trim
                Txt_ShortName.Text = .CurrentRow.Cells(2).Value.ToString.Trim
            End With

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

#End Region

    Private Sub Emp_Account_Reg_Frm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Call Populate_GridView()
            Txt_BankID.Focus()
        Catch ex As Exception

        End Try
    End Sub
  
    Private Sub Txt_EmpID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Try

            If Txt_BankID.Text.Trim = "" Then
                Call Clear_Form()
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub DoctorMaster_Frm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Enter Then Call SendKeyTab()
    End Sub

    Private Sub DoctorMaster_Frm_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles Me.KeyPress
        If Asc(e.KeyChar) = 39 Then e.KeyChar = Chr(96)
    End Sub

    Private Sub Btn_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Save.Click
        Try

            'Validating Data controls
            If Not Validate_Fields() Then Exit Sub

            Bank_Master_BL = New Bank_Master_BL_Cls
            Bank_Master_BL.Bank_ID = Val(Txt_BankID.Text.Trim)
            Bank_Master_BL.Bank_Name = Txt_BankName.Text.Trim
            Bank_Master_BL.Short_Name = Txt_ShortName.Text.Trim
            Bank_Master_BL.Branch_Name = Txt_BranchName.Text.Trim
            Bank_Master_BL.Address = Txt_BankAddress.Text.Trim
            Bank_Master_BL.Swift_Code = Txt_SwiftCode.Text.Trim
            Bank_Master_BL.Bank_Code = Txt_BankName.Tag
            Bank_Master_BL.Phone1 = Txt_PhoneI.Text.Trim
            Bank_Master_BL.Phone2 = Txt_PhoneII.Text.Trim

            If Bank_Master_BL.Save_Bank_Master(Dtbl, Tr_Mode) Then
                If Dtbl.Rows(0).Item(0).ToString = "0" Then
                    MessageBox.Show("Bank Master Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Exit Sub
                End If
                Txt_BankID.Text = Dtbl.Rows(0).Item("Bank_ID").ToString
                Tr_Mode = Tran_Mode.Edit_Mode
                MessageBox.Show("Bank Master Saved", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Call Populate_GridView()
                Btn_Clear.Focus()


            Else
                MessageBox.Show("Bank Master Failed to Save", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Exit Sub
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Btn_Find_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Find.Click
        Try
            If Txt_BankID.Text.Trim = "" Then
                Dim Sql As String
                Dim Colwidth As String = ""
                Colwidth = "200|200|50|"
                Sql = "SELECT     Bank_Name AS Name ,Bank_ID AS [Bank ID], Branch_Name AS branch, Address, Phone1, Phone2, Bank_Code  FROM         Bank_Master_Vw where Br_Code = " & Branch_Code & ""
                Call ShowSearchengine(Txt_BankID, Sql, 1, "Name", Colwidth, , 0)
            End If

            'Validating Mandatory fields for locating
            If Txt_BankID.Text.Trim = "" Then
                'MessageBox.Show("Invalid Employee ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_BankID.Focus() : Exit Sub
            End If


            If Locate_Values() Then
                Tr_Mode = Tran_Mode.Edit_Mode
                Btn_Delete.Enabled = True
            Else
                MessageBox.Show("Account Number does not exists,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
 
    Private Sub Btn_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Clear.Click
        Try
            Call Clear_Form()
            Txt_BankID.Focus()

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Close.Click
        Me.Close()
    End Sub

    Private Sub Dgvw_Emp_AccountMaster_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Dgvw_Bank_Account_Master.DoubleClick
        Try
            Call Clear_Form()
            With Dgvw_Bank_Account_Master
                If .CurrentRow Is Nothing Then Exit Sub
                Txt_BankID.Text = .Item(0, .CurrentCell.RowIndex).Value.ToString.Trim
                Call Btn_Find_Click(sender, e)
            End With

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Btn_Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Btn_Delete.Click
        Try

            Dim Accesstype As Access_Type = Access_Type.Delete
            If Not Check_Userright(CInt(Val(Me.Tag)), Accesstype) Then
                Return
            End If

            'Validating Mandatory fields for Deleting
            If Tr_Mode = Tran_Mode.New_Mode Then
                MessageBox.Show("You have to locate details before deleting the record", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            If Txt_BankID.Text.Trim = "" Then
                MessageBox.Show("Invalid Bank ID,Please Check", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Txt_BankID.Focus() : Exit Sub
            End If

            'Confirm before delete the record
            If MessageBox.Show("Are you sure want to delete the selected Account", Product_Name, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = Windows.Forms.DialogResult.No Then
                Exit Sub
            End If
            Bank_Master_BL = New Bank_Master_BL_Cls
            Dim dtbl As DataTable = Nothing

            If Bank_Master_BL.Delete_Bank_Master(dtbl, Txt_BankID.Text.Trim) Then
                If dtbl.Rows(0).Item(0).ToString = "0" Then
                    MessageBox.Show("You cannot delete this Bank Master details" & vbCrLf & "Dependency found", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
                MessageBox.Show("Bank Master Deleted", Product_Name, MessageBoxButtons.OK, MessageBoxIcon.Information)
                Call Populate_GridView()
                Call Btn_Clear_Click(sender, e)

            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_AccountNo_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_BankID.KeyDown
        If e.KeyCode = Keys.F2 Then Btn_Find_Click(sender, e)
    End Sub

    Private Sub Txt_BankName_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_BankName.KeyDown
        Try

            If e.Shift = Keys.Alt Or e.KeyCode = Keys.ShiftKey Or e.KeyCode = Keys.Tab Or e.KeyCode = Keys.Capital Then
                Exit Sub
            End If

            With Dgw_BankName_History

                If e.KeyCode = Keys.Escape Then
                    Txt_BankName.Text = ""
                    .DataSource = Nothing
                    .Hide()
                    Exit Sub
                End If

                If .Rows.Count = 0 Then Exit Sub

                If e.KeyCode = Keys.Up Then
                    If .CurrentRow.Index > 0 Then
                        .CurrentCell = .Item(0, .CurrentRow.Index - 1)
                    End If
                    If .CurrentRow.Displayed = False Then .FirstDisplayedScrollingRowIndex = .CurrentRow.Index
                    Exit Sub
                ElseIf e.KeyCode = Keys.Down Then
                    If .CurrentRow.Index < .Rows.Count Then
                        .CurrentCell = .Item(0, .CurrentRow.Index + 1)
                    End If
                    If .CurrentRow.Displayed = False Then .FirstDisplayedScrollingRowIndex = .CurrentRow.Index
                    Exit Sub
                ElseIf e.KeyCode = Keys.Return Then
                    Call Get_bankName()
                    .DataSource = Nothing
                    .Hide()
                    Exit Sub
                End If

            End With

        Catch ex As Exception

        End Try


    End Sub

    Private Sub Dgw_BankName_History_CellContentClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Dgw_BankName_History.CellContentClick
        Try
            Dgw_BankName_History.Visible = False
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Txt_BankName_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Txt_BankName.KeyUp
        Try

            With Dgw_BankName_History

                If Txt_BankName.Text.Trim = "" Then
                    .DataSource = Nothing
                    .Hide()
                    Exit Sub
                End If

                If e.KeyCode = Keys.Up Or e.KeyCode = Keys.Down Or e.KeyCode = Keys.Return Then
                    Exit Sub
                End If

                'Executing and Get data
                Bank_Master_BL = New Bank_Master_BL_Cls
                Dim Dtbl As DataTable = Nothing
                If Bank_Master_BL.Get_Bank_Name_List(Dtbl, Txt_BankName.Text.Trim) Then

                    Call Populate_ParticularsGrid(Dtbl)

                    If .Rows.Count > 0 Then
                        If Not .Visible Then
                            Txt_BankName.Tag = Txt_BankName.SelectionStart
                            Txt_BankName.Focus()
                            Txt_BankName.SelectionStart = Txt_BankName.Tag
                        End If
                        If .Columns.Count > 0 Then
                            .Columns(0).MinimumWidth = 500
                            For i_Ctr = 1 To .Columns.Count - 1
                                .Columns(i_Ctr).Width = 0
                            Next
                        End If
                    Else
                        .DataSource = Nothing
                        .Hide()
                        Exit Sub
                    End If
                Else
                    .DataSource = Nothing
                    .Hide()
                    Exit Sub
                End If
            End With
        Catch ex As Exception

        End Try
        
    End Sub
   

    Private Sub Txt_BankName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Txt_BankName.TextChanged

    End Sub
End Class
