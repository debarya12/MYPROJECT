﻿Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports System.Configuration
Imports HMS_Common.Common_Cls

Public Class ReportViewer_Cls

    Private Rpt_Frm As Reportviewer_Frm

    Public MDI_Form As Form

    Private _Show_Mode As Report_Showmode = Report_Showmode.Fulloption
    Public Property Show_Mode() As Report_Showmode
        Get
            Return _Show_Mode
        End Get
        Set(ByVal value As Report_Showmode)
            _Show_Mode = value
        End Set
    End Property

    Private _RptFrm_Width As Long = 1024
    Public Property RptFrm_Width() As Long
        Get
            Return _RptFrm_Width
        End Get
        Set(ByVal value As Long)
            _RptFrm_Width = value
        End Set
    End Property

    Private _RptFrm_Height As Long = 764
    Public Property RptFrm_Height() As Long
        Get
            Return _RptFrm_Height
        End Get
        Set(ByVal value As Long)
            _RptFrm_Height = value
        End Set
    End Property


    Public Function ShowReport(ByVal MainDataSet As DataSet, _
                               ByVal MainreportFieldDef As String, _
                               ByVal MainReportPath As String, _
                               ByVal MainReportName As String, _
                               Optional ByVal Subreportname As String = "", _
                               Optional ByVal SubreportDatasource As Collection = Nothing) _
                            As Boolean

        Try

            '-------------------------------------------------

            Rpt_Frm = New Reportviewer_Frm

            '-------------------------------------------------

            Dim StrFlf(50) As String
            Dim Subreports(50) As String
            Dim i As Integer
            Dim N, M As Integer
            Dim objReport As New CrystalDecisions.CrystalReports.Engine.ReportDocument
            Dim objsubReport As New CrystalDecisions.CrystalReports.Engine.ReportDocument



            '========================================================================================================
            '   M A I N  - R E P O R T
            '========================================================================================================

            '-------------------------------------------------

            objReport.Load(MainReportPath & MainReportName)

            '-------------------------------------------------

            objReport.SetDataSource(MainDataSet.Tables(0))
            Try

                StrFlf = Split(MainreportFieldDef, "|")
                N = StrFlf.Length
                For i = 0 To N - 1 Step 2
                    If objReport.DataDefinition.FormulaFields(StrFlf(i)).FormulaName <> StrFlf(i + 1) Then
                        objReport.DataDefinition.FormulaFields(StrFlf(i)).Text = "'" + StrFlf(i + 1) + "'"
                        If i > N - 1 Then
                            Exit For
                        End If
                    End If
                Next
            Catch ex As Exception

            End Try

            '========================================================================================================


            '========================================================================================================
            '   S U B  - R E P O R T
            '========================================================================================================

            If Subreportname.Length <> 0 Then


                Subreports = Split(Subreportname, "|")
                M = Subreports.Length

                For k = 0 To M - 1
                    objsubReport = objReport.OpenSubreport(Subreports(k).Trim)
                    objsubReport.SetDataSource(DirectCast(SubreportDatasource(k), DataTable))
                Next


            End If

            '========================================================================================================

            Rpt_Frm.CrystalReportViewer1.ReportSource = objReport
            Rpt_Frm.CrystalReportViewer1.Refresh()

            Call Set_Showmode()

            'Rpt_Frm.MdiParent = MDI_DCMGTS_Main
            If Not Me.MDI_Form Is Nothing And Me.Show_Mode = Report_Showmode.Condensedmode Then
                Rpt_Frm.MdiParent = HMS_MDIMain_Frm
                Rpt_Frm.Show()
            Else
                Rpt_Frm.Show()
            End If

            Return True

        Catch ex As Exception
            MessageBox.Show(ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False

        End Try

    End Function

    Public Function ShowReport(ByVal MainreportDatasource As DataTable, _
                               ByVal MainreportFieldDef As String, _
                               ByVal MainReportPath As String, _
                               ByVal MainReportName As String, _
                               Optional ByVal Subreportname As String = "", _
                               Optional ByVal SubreportDatasource As Collection = Nothing) _
                            As Boolean

        Try

            '-------------------------------------------------

            Rpt_Frm = New Reportviewer_Frm

            '-------------------------------------------------

            Dim StrFlf(50) As String
            Dim Subreports(50) As String
            Dim i As Integer
            Dim N, M As Integer
            Dim objReport As New CrystalDecisions.CrystalReports.Engine.ReportDocument
            Dim objsubReport As New CrystalDecisions.CrystalReports.Engine.ReportDocument



            '========================================================================================================
            '   M A I N  - R E P O R T
            '========================================================================================================

            '-------------------------------------------------

            objReport.Load(MainReportPath & MainReportName)

            '-------------------------------------------------

            objReport.SetDataSource(MainreportDatasource)
            Try

                StrFlf = Split(MainreportFieldDef, "|")
                N = StrFlf.Length
                For i = 0 To N - 1 Step 2
                    If objReport.DataDefinition.FormulaFields(StrFlf(i)).FormulaName <> StrFlf(i + 1) Then
                        objReport.DataDefinition.FormulaFields(StrFlf(i)).Text = "'" + StrFlf(i + 1) + "'"
                        If i > N - 1 Then
                            Exit For
                        End If
                    End If
                Next
            Catch ex As Exception

            End Try

            '========================================================================================================


            '========================================================================================================
            '   S U B  - R E P O R T
            '========================================================================================================

            If Subreportname.Length <> 0 Then


                Subreports = Split(Subreportname, "|")
                M = Subreports.Length

                For k = 1 To M
                    objsubReport = objReport.OpenSubreport(Subreports(k - 1).Trim)
                    objsubReport.SetDataSource(DirectCast(SubreportDatasource(k), DataTable))
                Next


            End If

            '========================================================================================================

            Rpt_Frm.CrystalReportViewer1.ReportSource = objReport
            Rpt_Frm.CrystalReportViewer1.Refresh()

            Call Set_Showmode()

            'Rpt_Frm.MdiParent = MDI_DCMGTS_Main
            If Not Me.MDI_Form Is Nothing And Me.Show_Mode = Report_Showmode.Condensedmode Then
                Rpt_Frm.MdiParent = HMS_MDIMain_Frm
                Rpt_Frm.Show()
            Else
                Rpt_Frm.Show()
            End If


            Return True

        Catch ex As Exception
            MessageBox.Show(ex.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False

        End Try

    End Function

    Private Sub Set_Showmode()
        Try
            With Rpt_Frm

                If Me.Show_Mode = Report_Showmode.Condensedmode Then
                    .Show_Mode = Me.Show_Mode
                    .MDI_Form = Me.MDI_Form
                    .Height = Me.RptFrm_Height
                    .Width = Me.RptFrm_Width
                End If

            End With
        Catch ex As Exception

        End Try
    End Sub
    
End Class
